package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =============================================================================
// GreenButton — 3-D chess.com style (retained & unchanged from original)
// =============================================================================

/** Big green button with the darker bottom-edge shadow used all over chess.com. */
@Composable
fun GreenButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(VilaColors.GreenShadow)
            .clickable(onClick = onClick)
            .padding(bottom = 4.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(shape)
                .background(VilaColors.Green),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text       = text,
                color      = VilaColors.Text,
                fontSize   = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

// =============================================================================
// TopHeader
// =============================================================================

/**
 * Chess.com-style top bar: avatar + username + Elo on the left,
 * notification bell + hamburger menu on the right.
 *
 * NOTE: Do NOT apply systemBarsPadding() here — Scaffold's innerPadding
 * already accounts for the status bar height via PaddingValues.
 */
@Composable
fun TopHeader(
    username: String = "vilaadmin",
    elo: Int = 1200,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment   = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        // ---- Left: avatar + username + elo ----
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Avatar placeholder — first initial on a green circle
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(VilaColors.Green),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text       = username.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                    color      = Color.White,
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
            }

            Spacer(Modifier.width(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    text       = username,
                    color      = Color.White,
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text     = "$elo Elo",
                    color    = VilaColors.TextDim,
                    fontSize = 12.sp,
                )
            }
        }

        // ---- Right: icons ----
        Row {
            IconButton(onClick = { /* TODO: notifications screen */ }) {
                Icon(
                    imageVector     = Icons.Default.Notifications,
                    contentDescription = "Thông báo",
                    tint            = Color.White,
                )
            }
            IconButton(onClick = { /* TODO: side-drawer */ }) {
                Icon(
                    imageVector     = Icons.Default.Menu,
                    contentDescription = "Menu",
                    tint            = Color.White,
                )
            }
        }
    }
}

// =============================================================================
// HeroPlayCard
// =============================================================================

/**
 * Large card at the top of the home feed.
 * Shows popular time-control chips and a prominent "Play Now" button.
 *
 * @param quickTimes    List of time presets to show as chips.
 * @param selectedChip  Index into [quickTimes] that is currently selected.
 * @param onChipSelect  Called with the new chip index when the user taps a chip.
 * @param onPlayNow     Called when the user taps "Play Now".
 */
@Composable
fun HeroPlayCard(
    quickTimes:   List<QuickTime>,
    selectedChip: Int,
    onChipSelect: (Int) -> Unit,
    onPlayNow:    () -> Unit,
    modifier:     Modifier = Modifier,
) {
    Card(
        modifier  = modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(containerColor = VilaColors.Panel),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(
            modifier  = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text(
                text       = "Play",
                color      = Color.White,
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
            )

            // Time-control chips
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                quickTimes.forEachIndexed { index, time ->
                    val isSelected = index == selectedChip
                    FilterChip(
                        selected  = isSelected,
                        onClick   = { onChipSelect(index) },
                        modifier  = Modifier.weight(1f),
                        shape     = RoundedCornerShape(8.dp),
                        label     = {
                            Text(
                                text      = time.label,
                                fontSize  = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center,
                                modifier  = Modifier.fillMaxWidth(),
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor         = VilaColors.PanelDark,
                            labelColor             = VilaColors.TextDim,
                            selectedContainerColor = Color.Transparent,
                            selectedLabelColor     = VilaColors.Green,
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled             = true,
                            selected            = isSelected,
                            selectedBorderColor = VilaColors.Green,
                            borderColor         = VilaColors.ClockIdle,
                            selectedBorderWidth = 1.5.dp,
                            borderWidth         = 1.dp,
                        ),
                    )
                }
            }

            // Play Now — reuses the 3-D GreenButton from the design system
            GreenButton(
                text     = "Play Now",
                modifier = Modifier.fillMaxWidth(),
                onClick  = onPlayNow,
            )
        }
    }
}

// =============================================================================
// FeatureGrid  —  2 × 2 Row/Column layout
// IMPORTANT: Never use LazyVerticalGrid inside a LazyColumn; it causes a
//            "nested scrollable with same orientation" crash at runtime.
// =============================================================================

private data class FeatureItem(
    val title:            String,
    val subtitle:         String,
    val icon:             ImageVector,
    val showProgress:     Boolean = false,
    val progressFraction: Float   = 0f,
)

private val FEATURE_ITEMS = listOf(
    FeatureItem(
        title            = "Puzzles",
        subtitle         = "Giải đố hàng ngày",
        icon             = Icons.Default.Extension,
        showProgress     = true,
        progressFraction = 0.6f,
    ),
    FeatureItem(
        title    = "Game Review",
        subtitle = "Phân tích ván đã chơi",
        icon     = Icons.Default.Search,
    ),
    FeatureItem(
        title    = "Watch",
        subtitle = "12K đang xem",
        icon     = Icons.Default.LiveTv,
    ),
    FeatureItem(
        title    = "Stats",
        subtitle = "Thống kê của bạn",
        icon     = Icons.Default.BarChart,
    ),
)

@Composable
fun FeatureGrid(modifier: Modifier = Modifier) {
    Column(
        modifier              = modifier.fillMaxWidth(),
        verticalArrangement   = Arrangement.spacedBy(10.dp),
    ) {
        for (rowStart in FEATURE_ITEMS.indices step 2) {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                for (i in rowStart until minOf(rowStart + 2, FEATURE_ITEMS.size)) {
                    FeatureCard(
                        item     = FEATURE_ITEMS[i],
                        modifier = Modifier.weight(1f),
                    )
                }
                // Guard: pad the row if the last row has only 1 card
                if (FEATURE_ITEMS.size - rowStart == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FeatureCard(item: FeatureItem, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(VilaColors.Panel)
            .clickable { /* TODO: navigate to feature */ }
            .padding(14.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
                imageVector        = item.icon,
                contentDescription = item.title,
                tint               = VilaColors.Green,
                modifier           = Modifier.size(28.dp),
            )
            Text(
                text       = item.title,
                color      = Color.White,
                fontSize   = 15.sp,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                text     = item.subtitle,
                color    = VilaColors.TextDim,
                fontSize = 12.sp,
            )
            if (item.showProgress) {
                LinearProgressIndicator(
                    progress    = { item.progressFraction },
                    modifier    = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(50)),
                    color       = VilaColors.Green,
                    trackColor  = VilaColors.PanelDark,
                )
            }
        }
    }
}

// =============================================================================
// BottomNavBar
// =============================================================================

private data class NavItem(val label: String, val icon: ImageVector)

private val NAV_ITEMS = listOf(
    NavItem("Home",   Icons.Default.Home),
    NavItem("Play",   Icons.Default.PlayArrow),
    NavItem("Learn",  Icons.Default.MenuBook),
    NavItem("Social", Icons.Default.People),
    NavItem("More",   Icons.Default.MoreHoriz),
)

/**
 * Material 3 bottom navigation bar styled to match chess.com dark mode.
 * NavigationBar automatically handles the navigation-bar window inset,
 * so there is no need to call navigationBarsPadding() separately.
 */
@Composable
fun BottomNavBar(
    selectedIndex:  Int,
    onItemSelected: (Int) -> Unit,
) {
    NavigationBar(
        containerColor = VilaColors.Panel,
        tonalElevation = 0.dp,
    ) {
        NAV_ITEMS.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = index == selectedIndex,
                onClick  = { onItemSelected(index) },
                icon = {
                    Icon(
                        imageVector        = item.icon,
                        contentDescription = item.label,
                    )
                },
                label = {
                    Text(
                        text     = item.label,
                        fontSize = 11.sp,
                        maxLines = 1,
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = VilaColors.Green,
                    selectedTextColor   = VilaColors.Green,
                    unselectedIconColor = VilaColors.TextDim,
                    unselectedTextColor = VilaColors.TextDim,
                    indicatorColor      = VilaColors.PanelDark,
                ),
            )
        }
    }
}
