package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.core.makePiece
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.UiState

private enum class Confirm { EXIT, NEW_GAME, RESIGN }

private enum class BarIcon { UNDO, FLIP, DRAW, RESIGN, NEW }

private val DisabledGrey = Color(0xFF6B6965)

@Composable
fun GameScreen(vm: GameViewModel) {
    val ui = vm.ui
    val images = vm.pieceImages
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showResult by remember(ui.over) { mutableStateOf(ui.over) }

    BackHandler {
        if (ui.over) vm.backToHome() else confirm = Confirm.EXIT
    }

    val topIsWhite = ui.flipped
    val engineName = vm.opponentName()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VilaColors.Bg)
            .systemBarsPadding()
    ) {
        TopBar(
            sans = ui.sans,
            onBack = { if (ui.over) vm.backToHome() else confirm = Confirm.EXIT }
        )

        PlayerBar(
            vm = vm,
            ui = ui,
            images = images,
            white = topIsWhite,
            name = if (topIsWhite == ui.humanWhite) "Bạn" else engineName
        )

        BoardView(vm = vm, ui = ui, images = images, modifier = Modifier.fillMaxWidth())

        PlayerBar(
            vm = vm,
            ui = ui,
            images = images,
            white = !topIsWhite,
            name = if (!topIsWhite == ui.humanWhite) "Bạn" else engineName
        )

        Spacer(Modifier.weight(1f))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(VilaColors.PanelDark)
        ) {
            BarItem("Đi lại", BarIcon.UNDO, ui.canUndo, Modifier.weight(1f)) { vm.undo() }
            BarItem("Lật bàn", BarIcon.FLIP, true, Modifier.weight(1f)) { vm.flipBoard() }
            BarItem("Hòa", BarIcon.DRAW, !ui.over, Modifier.weight(1f)) { vm.offerDraw() }
            BarItem("Đầu hàng", BarIcon.RESIGN, !ui.over, Modifier.weight(1f)) { confirm = Confirm.RESIGN }
            BarItem("Ván mới", BarIcon.NEW, true, Modifier.weight(1f)) {
                if (ui.over) vm.startGame() else confirm = Confirm.NEW_GAME
            }
        }
    }

    val pending = ui.promotion
    if (pending != null) {
        PromotionDialog(vm = vm, images = images, humanWhite = ui.humanWhite)
    }

    val c = confirm
    if (c != null) {
        val text = when (c) {
            Confirm.EXIT -> "Thoát về menu? Ván đang chơi sẽ mất."
            Confirm.NEW_GAME -> "Bỏ ván hiện tại và bắt đầu ván mới?"
            Confirm.RESIGN -> "Bạn muốn đầu hàng ván này?"
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = VilaColors.Panel,
            title = { Text("Xác nhận", color = VilaColors.Text) },
            text = { Text(text, color = VilaColors.TextDim) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    when (c) {
                        Confirm.EXIT -> vm.backToHome()
                        Confirm.NEW_GAME -> vm.startGame()
                        Confirm.RESIGN -> vm.resign()
                    }
                }) { Text("Đồng ý", color = VilaColors.Green) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = null }) { Text("Hủy", color = VilaColors.TextDim) }
            }
        )
    }

    if (ui.over && showResult) {
        AlertDialog(
            onDismissRequest = { showResult = false },
            containerColor = VilaColors.Panel,
            title = { Text(ui.resultTitle, color = VilaColors.Text, fontWeight = FontWeight.ExtraBold) },
            text = { Text(ui.resultDetail, color = VilaColors.TextDim) },
            confirmButton = {
                GreenButton("Ván mới", Modifier.width(150.dp)) { vm.startGame() }
            },
            dismissButton = {
                TextButton(onClick = { showResult = false }) { Text("Xem bàn cờ", color = VilaColors.TextDim) }
            }
        )
    }
}

/** Back arrow + horizontally scrolling move list, like the strip above the board on chess.com. */
@Composable
private fun TopBar(sans: List<String>, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(VilaColors.PanelDark),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(20.dp)) {
                val w = size.width
                val h = size.height
                val p = Path()
                p.moveTo(w * 0.65f, h * 0.12f)
                p.lineTo(w * 0.27f, h * 0.5f)
                p.lineTo(w * 0.65f, h * 0.88f)
                drawPath(
                    path = p,
                    color = VilaColors.Text,
                    style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
        MoveStrip(sans, Modifier.weight(1f))
    }
}

@Composable
private fun MoveStrip(sans: List<String>, modifier: Modifier) {
    val state = rememberLazyListState()
    LaunchedEffect(sans.size) {
        if (sans.isNotEmpty()) state.animateScrollToItem(sans.size - 1)
    }
    if (sans.isEmpty()) {
        Box(modifier = modifier.fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
            Text("Các nước đi sẽ hiện ở đây", color = VilaColors.TextDim, fontSize = 13.sp)
        }
        return
    }
    LazyRow(
        state = state,
        modifier = modifier.fillMaxHeight(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        itemsIndexed(sans) { index, san ->
            val isLast = index == sans.size - 1
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (index % 2 == 0) {
                    Text(
                        "" + (index / 2 + 1) + ".",
                        color = VilaColors.TextDim,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 6.dp, end = 3.dp)
                    )
                }
                Text(
                    san,
                    color = if (isLast) VilaColors.Text else VilaColors.TextDim,
                    fontSize = 13.sp,
                    fontWeight = if (isLast) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isLast) VilaColors.Panel else Color.Transparent)
                        .padding(horizontal = 5.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
private fun BarItem(
    label: String,
    icon: BarIcon,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val iconColor = if (enabled) VilaColors.Text else DisabledGrey
    val labelColor = if (enabled) VilaColors.TextDim else DisabledGrey
    Column(
        modifier = modifier
            .height(54.dp)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BarIconView(icon, iconColor)
        Spacer(Modifier.height(3.dp))
        Text(label, color = labelColor, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun BarIconView(kind: BarIcon, color: Color) {
    if (kind == BarIcon.DRAW) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            Text("½", color = color, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        return
    }
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            BarIcon.UNDO -> {
                val head = Path()
                head.moveTo(w * 0.36f, h * 0.2f)
                head.lineTo(w * 0.14f, h * 0.44f)
                head.lineTo(w * 0.36f, h * 0.68f)
                drawPath(head, color, style = stroke)
                val tail = Path()
                tail.moveTo(w * 0.14f, h * 0.44f)
                tail.lineTo(w * 0.62f, h * 0.44f)
                tail.quadraticBezierTo(w * 0.9f, h * 0.44f, w * 0.9f, h * 0.72f)
                drawPath(tail, color, style = stroke)
            }
            BarIcon.FLIP -> {
                val up = Path()
                up.moveTo(w * 0.32f, h * 0.86f)
                up.lineTo(w * 0.32f, h * 0.14f)
                up.moveTo(w * 0.14f, h * 0.32f)
                up.lineTo(w * 0.32f, h * 0.14f)
                up.lineTo(w * 0.5f, h * 0.32f)
                drawPath(up, color, style = stroke)
                val down = Path()
                down.moveTo(w * 0.68f, h * 0.14f)
                down.lineTo(w * 0.68f, h * 0.86f)
                down.moveTo(w * 0.5f, h * 0.68f)
                down.lineTo(w * 0.68f, h * 0.86f)
                down.lineTo(w * 0.86f, h * 0.68f)
                drawPath(down, color, style = stroke)
            }
            BarIcon.RESIGN -> {
                val pole = Path()
                pole.moveTo(w * 0.26f, h * 0.1f)
                pole.lineTo(w * 0.26f, h * 0.9f)
                drawPath(pole, color, style = stroke)
                val flag = Path()
                flag.moveTo(w * 0.26f, h * 0.14f)
                flag.lineTo(w * 0.86f, h * 0.34f)
                flag.lineTo(w * 0.26f, h * 0.54f)
                flag.close()
                drawPath(flag, color, style = Fill)
            }
            BarIcon.NEW -> {
                val plus = Path()
                plus.moveTo(w * 0.5f, h * 0.16f)
                plus.lineTo(w * 0.5f, h * 0.84f)
                plus.moveTo(w * 0.16f, h * 0.5f)
                plus.lineTo(w * 0.84f, h * 0.5f)
                drawPath(plus, color, style = stroke)
            }
            BarIcon.DRAW -> {}
        }
    }
}

@Composable
private fun PlayerBar(
    vm: GameViewModel,
    ui: UiState,
    images: Array<ImageBitmap?>,
    white: Boolean,
    name: String
) {
    val clock = vm.clocks
    val captured = if (white) ui.capturedByWhite else ui.capturedByBlack
    val advantage = if (white) ui.materialDiff else -ui.materialDiff
    val active = !ui.over && ui.whiteToMove == white
    val isEngine = white != ui.humanWhite
    val ms = if (white) clock.whiteMs else clock.blackMs

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val avatar = images[if (white) 6 else 14]
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(if (white) Color(0xFFB9B7B2) else Color(0xFF4A4743)),
            contentAlignment = Alignment.Center
        ) {
            if (avatar != null) {
                Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(36.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (active) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(VilaColors.Green)
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    name,
                    color = VilaColors.Text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    if (isEngine && ui.thinking) "  đang nghĩ…" else if (white) "  Trắng" else "  Đen",
                    color = VilaColors.TextDim,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Row(
                modifier = Modifier.height(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy((-7).dp)
            ) {
                for (p in captured) {
                    val img = images[p]
                    if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                if (advantage > 0) {
                    Spacer(Modifier.width(14.dp))
                    Text("+" + (advantage / 100), color = VilaColors.TextDim, fontSize = 12.sp)
                }
            }
        }
        if (clock.enabled) {
            val low = ms < 20_000L
            Box(
                modifier = Modifier
                    .widthIn(min = 88.dp)
                    .height(40.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (active) VilaColors.ClockActive else VilaColors.ClockIdle)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    formatClock(ms),
                    color = if (active) (if (low) VilaColors.Danger else Color(0xFF1F1E1B)) else (if (low) VilaColors.Danger else VilaColors.TextDim),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

private fun formatClock(ms: Long): String {
    val total = if (ms < 0L) 0L else ms
    if (total < 20_000L) {
        val tenths = (total / 100L) % 10L
        val secs = total / 1000L
        return "0:" + (if (secs < 10L) "0" else "") + secs + "." + tenths
    }
    val totalSec = (total + 999L) / 1000L
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "" + m + ":" + (if (s < 10L) "0" else "") + s
}

@Composable
private fun PromotionDialog(vm: GameViewModel, images: Array<ImageBitmap?>, humanWhite: Boolean) {
    Dialog(onDismissRequest = { vm.cancelPromotion() }) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(VilaColors.Panel)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Phong cấp thành", color = VilaColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (type in vm.pieceChoices()) {
                    val img = images[makePiece(type, humanWhite)]
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(VilaColors.BoardLight)
                            .clickable { vm.choosePromotion(type) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(58.dp))
                    }
                }
            }
        }
    }
}
