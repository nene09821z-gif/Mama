# v17w — Màn Câu đố theo ảnh mẫu 5 vùng + hiệu ứng từng chủ đề

## Giao diện (theo ảnh mẫu)
- Nút = **ô khối isometric 2.5D vẽ bằng Canvas** (`drawSlab`, PuzzleChapters.kt): xong = màu vùng + dấu tích trắng
  (xanh lục · đỏ · xanh ngọc · xanh lơ · hồng); hiện tại = ô vàng + số + vầng sáng nhịp thở; chưa mở = xám xanh.
- **Linh vật** đứng trên ô vừa xong (level − 1; level 1 đứng trên ô vàng), nhún nhẹ; mũ theo vùng: mầm cây / ông già Noel / cao bồi / phi hành gia / kính lặn.
- **Dải tên vùng cố định** dưới tiêu đề `VÙNG n · TÊN · a-b`, mờ chéo khi sang vùng khác. Nền HUD trên/dưới đổi màu mượt theo vùng (animateColorAsState, đọc trong draw ⇒ không recomposition).
- Đường zig-zag chéo (sóng tam giác chu kỳ 8, biên 22%–78%), ô đứng sát nhau, tắt đường mòn (`SHOW_TRAIL`). Bỏ HLV + bong bóng chat.
- **Chuyển vùng mượt**: 14% chân khối đầu vùng mờ dần sang màu nền vùng bên dưới (`drawRegionFade`) – không còn đường ranh gắt.

## Cảnh vật không thưa (`layoutAroundPath`)
1. Vật không đè ô khối → giữ nguyên. 2. Vật bị đè → DỜI tới chỗ trống gần nhất (ngang ±0,40, dọc ±0,09), không đè ô/vật khác.
3. Không dời được → bỏ, bù bằng vật nhỏ cùng chủ đề ở hai mép (+5 vật cho dày). 4. Sắp theo đáy vật (xa → gần) như phối cảnh isometric.

## Hiệu ứng theo chủ đề (PuzzleThemeEffects.kt)
- Lớp hạt phủ màn hình, không nhận chạm, mờ chéo 0,7 s khi đổi vùng:
  Rừng xanh = đom đóm nhấp nháy + lá rơi · Giáng sinh = tuyết rơi 3 lớp · Sa mạc = bụi cát bay + tàn lửa núi lửa ·
  Không gian = sao nhấp nháy (sao to có tia) + sao băng · Biển sâu = bong bóng nổi + tia nắng đung đưa.
- Vật cảnh chuyển động nhẹ (chỉ vài loại): cây/đèn lồng đung đưa, rong biển lắc, sứa/hành tinh/tiểu hành tinh lơ lửng, tên lửa/tinh thể nhấp nhô.
- Hiệu năng: MỘT đồng hồ 24 s/vòng cho cả màn (đọc trong draw/graphicsLayer, không recomposition); số chu kỳ nguyên ⇒ lặp vòng không giật;
  số hạt theo DeviceTier: yếu 40% · trung bình 70% · mạnh 100%.

## Test mới
- `PuzzleRegionsTest`: ranh giới vùng, chuỗi "a-b", sóng đường đi, bố trí vật cảnh ổn định/đủ dày.
