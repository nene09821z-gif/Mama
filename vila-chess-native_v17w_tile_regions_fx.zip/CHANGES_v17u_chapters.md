# v17u — Bản đồ Câu đố nhiều chặng (chủ đề)

- 300.000 câu đố chia VÙNG: mỗi vùng 31 khối x 16 = 496 câu (~500); 5 chủ đề lặp vòng theo vùng: Rừng xanh → Làng Giáng sinh → Sa mạc & Núi lửa → Không gian → Biển sâu.
- ui/PuzzleChapters.kt (mới): MapChapter, nền riêng từng chặng (gradient + ô kim cương + tuyết / cồn cát / sao / bong bóng), dải tên chặng ở chân khối,
  themedProps() đổi LOẠI vật cảnh theo nhóm (cây, đá, hoa cỏ, ghế, cột/cờ, nhân vật, vật lớn) nhưng giữ nguyên vị trí đã kiểm không đè nút/đường.
- 33 sprite 2.5D mới trong res/drawable-nodpi: hol_* (Kenney Holiday Kit, CC0), des_* / spc_* / sea_* (dựng low-poly cùng góc nhìn).
- PuzzleMapScreen.kt: PropKind thêm 33 mục; SceneryBlock nhận chương; ẩn vật cảnh gốc phẳng + nhân vật ở chặng Rừng; nút khoá đặc màu đá xám xanh.
- AnimatedAvatar.kt: sửa import animateFloat / drawOutline.
- Credits: Kenney Holiday Kit (CC0) — xem CREDITS_KENNEY.txt.
- Nền mỗi vùng liền một màu giữa các khối; dải tên "VÙNG n" chỉ hiện ở khối đầu vùng (BLOCKS_PER_REGION trong PuzzleChapters.kt để đổi độ dài vùng).
