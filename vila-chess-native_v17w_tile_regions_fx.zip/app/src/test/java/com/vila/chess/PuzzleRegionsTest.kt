package com.vila.chess

import com.vila.chess.ui.SceneVariants
import com.vila.chess.ui.layoutAroundPath
import com.vila.chess.ui.levelXFrac
import com.vila.chess.ui.mapChapterFor
import com.vila.chess.ui.regionOfLevel
import com.vila.chess.ui.regionRangeText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Vùng của bản đồ Câu đố (496 câu/vùng), đường zig-zag chéo và bố trí vật cảnh quanh đường. */
class PuzzleRegionsTest {

    @Test
    fun regionBoundaries() {
        assertEquals(0, regionOfLevel(1))
        assertEquals(0, regionOfLevel(496))
        assertEquals(1, regionOfLevel(497))
        assertEquals(4, regionOfLevel(1985))
        assertEquals(5, regionOfLevel(2481))
    }

    @Test
    fun regionRangeTextClampsToLastLevel() {
        assertEquals("1-496", regionRangeText(0, 300000))
        assertEquals("993-1488", regionRangeText(2, 300000))
        assertEquals("2977-3000", regionRangeText(6, 3000))
    }

    @Test
    fun pathIsTriangleWaveInsideTrack() {
        for (l in 1..64) {
            val x = levelXFrac(l)
            assertTrue("level $l x=$x", x in 0.2199f..0.7801f)
        }
        assertEquals(0.78f, levelXFrac(1), 1e-4f)   // level 1: mép phải
        assertEquals(0.22f, levelXFrac(5), 1e-4f)   // sau 4 bước chéo: mép trái
        assertEquals(0.78f, levelXFrac(9), 1e-4f)   // chu kỳ 8
        assertEquals(levelXFrac(3), levelXFrac(11), 1e-6f)
    }

    @Test
    fun sceneryLayoutIsDeterministicAndKeepsDensity() {
        for (theme in 0 until 5) {
            val c = mapChapterFor(theme)
            val a = layoutAroundPath(SceneVariants[0], c)
            val b = layoutAroundPath(SceneVariants[0], c)
            assertEquals(a.size, b.size)
            assertTrue("theme $theme chỉ còn ${a.size} vật", a.size >= 25)
            for (i in a.indices) assertEquals(a[i].x, b[i].x, 0f)
        }
    }
}
