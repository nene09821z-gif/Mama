package com.vila.chess.game

import com.vila.chess.core.EMPTY
import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo

// ════════════════════════════════════════════════════════════════════════════════════════════
//  LOGIC CÂU ĐỐ (thuần Kotlin, không phụ thuộc Android/Compose ⇒ test được bằng JVM)
//
//  Định dạng Lichess:
//    • FEN        = thế cờ TRƯỚC nước đi đầu tiên của đối thủ.
//    • Moves      = chuỗi UCI cách nhau bởi dấu cách:  moves[0] là nước của ĐỐI THỦ (đi tự động),
//                   moves[1] là nước người chơi phải tìm, moves[2] là đối thủ đáp lại, moves[3] … cứ thế xen kẽ.
//    • Người chơi cầm quân của bên đi sau nước moves[0].
// ════════════════════════════════════════════════════════════════════════════════════════════

/** 1 câu đố. [level] = số Level trên bản đồ (cột `id` trong puzzles.db). */
data class Puzzle(
    val level: Int,
    val puzzleId: String,
    val fen: String,
    val moves: List<String>,
    val rating: Int,
    val themes: List<String>,
)

/** Kết quả của một lần người chơi thả quân. */
sealed class PuzzleStep {
    /** Không phải nước hợp lệ (quân sai màu, đi không đúng luật…) ⇒ UI chỉ đưa quân về, không tính lỗi. */
    object Illegal : PuzzleStep()

    /** Hợp lệ nhưng không phải nước trong lời giải ⇒ UI lắc quân. Thế cờ KHÔNG đổi. */
    object Wrong : PuzzleStep()

    /**
     * Đúng. [reply] = nước đối thủ đáp lại (null nếu câu đố đã xong). [solved] = đã giải xong toàn bộ.
     * [boardAfterPlayer] = bàn cờ ngay sau nước của người chơi, TRƯỚC khi đối thủ đáp (để UI chạy animation từng nước).
     */
    class Correct(val playerMove: Int, val reply: Int?, val solved: Boolean, val boardAfterPlayer: IntArray) : PuzzleStep()
}

/** "e2e4" / "e7e8q" → nước đi mã hoá của engine, hoặc null nếu không hợp lệ trong [pos]. */
fun parseUciMove(pos: Position, uci: String): Int? {
    if (uci.length < 4) return null
    val ff = uci[0] - 'a'
    val fr = uci[1] - '1'
    val tf = uci[2] - 'a'
    val tr = uci[3] - '1'
    if (ff !in 0..7 || fr !in 0..7 || tf !in 0..7 || tr !in 0..7) return null
    val from = fr * 8 + ff
    val to = tr * 8 + tf
    val promo = if (uci.length >= 5) "??nbrq".indexOf(uci[4].lowercaseChar()).coerceAtLeast(0) else 0
    for (m in pos.legalMoves()) {
        if (moveFrom(m) == from && moveTo(m) == to && movePromo(m) == promo) return m
    }
    return null
}

class PuzzleSession(val puzzle: Puzzle) {
    private val pos: Position = Position.fromFen(puzzle.fen)

    /** Bàn cờ TRƯỚC nước đầu của đối thủ (để UI chạy animation đối thủ đi). */
    val boardBefore: IntArray = pos.board.copyOf()

    /** Nước đầu tiên của đối thủ (đã mã hoá), -1 nếu dữ liệu hỏng. */
    val setupMove: Int

    /** false ⇒ dữ liệu câu đố hỏng (FEN/Moves sai); UI báo lỗi và cho phép bỏ qua. */
    val valid: Boolean

    /** Người chơi cầm quân Trắng? (= bên đi sau nước đầu của đối thủ). */
    val playerWhite: Boolean

    private var next = 1
    var solved: Boolean = false
        private set

    init {
        val setup = if (puzzle.moves.size >= 2) parseUciMove(pos, puzzle.moves[0]) else null
        if (setup == null) {
            setupMove = -1
            valid = false
            playerWhite = pos.whiteToMove
        } else {
            setupMove = setup
            valid = true
            pos.make(setup)
            playerWhite = pos.whiteToMove
        }
    }

    /** Bàn cờ hiện tại (bản sao – UI được phép giữ). */
    fun board(): IntArray = pos.board.copyOf()

    /** Quân tại [sq] có phải của người chơi không. */
    fun isPlayerPiece(sq: Int): Boolean {
        val pc = pos.board[sq]
        return pc != EMPTY && isWhitePiece(pc) == playerWhite
    }

    /** Các ô đến hợp lệ của quân ở [from] (để hiện chấm gợi ý). */
    fun legalTargets(from: Int): List<Int> {
        if (!valid || solved || !isPlayerPiece(from)) return emptyList()
        val out = ArrayList<Int>()
        for (m in pos.legalMoves()) if (moveFrom(m) == from && moveTo(m) !in out) out.add(moveTo(m))
        return out
    }

    /** (ô đi, ô đến) của nước đúng kế tiếp – dùng cho nút Gợi ý. */
    fun hint(): Pair<Int, Int>? {
        if (!valid || solved || next >= puzzle.moves.size) return null
        val m = parseUciMove(pos, puzzle.moves[next]) ?: return null
        return moveFrom(m) to moveTo(m)
    }

    private fun deliversMate(m: Int): Boolean {
        val side = pos.whiteToMove
        pos.make(m)
        val mate = pos.inCheck(!side) && pos.legalMoves().isEmpty()
        pos.unmake()
        return mate
    }

    /**
     * Người chơi đi quân từ [from] sang [to].
     * Đúng ⇔ trùng nước trong lời giải, HOẶC (giống Lichess) là một nước chiếu hết bất kỳ.
     */
    fun submit(from: Int, to: Int): PuzzleStep {
        if (!valid || solved || next >= puzzle.moves.size) return PuzzleStep.Illegal
        val candidates = pos.legalMoves().filter { moveFrom(it) == from && moveTo(it) == to }
        if (candidates.isEmpty()) return PuzzleStep.Illegal

        val expected = parseUciMove(pos, puzzle.moves[next])
        // Phong cấp: nếu trúng lời giải thì lấy đúng quân phong, ngược lại mặc định Hậu.
        val m = candidates.firstOrNull { it == expected }
            ?: candidates.firstOrNull { movePromo(it) == QUEEN || movePromo(it) == 0 }
            ?: candidates[0]

        val mate = deliversMate(m)
        if (m != expected && !mate) return PuzzleStep.Wrong

        pos.make(m)
        val afterPlayer = pos.board.copyOf()
        next++
        if (mate || next >= puzzle.moves.size) {
            solved = true
            return PuzzleStep.Correct(m, null, true, afterPlayer)
        }
        val reply = parseUciMove(pos, puzzle.moves[next])
        if (reply == null) {          // dữ liệu hỏng ở giữa chuỗi: coi như đã xong để người chơi không bị kẹt
            solved = true
            return PuzzleStep.Correct(m, null, true, afterPlayer)
        }
        pos.make(reply)
        next++
        if (next >= puzzle.moves.size) solved = true
        return PuzzleStep.Correct(m, reply, solved, afterPlayer)
    }
}

// ───────────────────────────────────────────────────────────── Văn bản hiển thị

/** "Trắng" / "Đen" – bên người chơi cầm. */
fun puzzleSideName(playerWhite: Boolean): String = if (playerWhite) "Trắng" else "Đen"

/** Mục tiêu hiển thị, lấy từ cột `themes` (vd "mateIn2 short" ⇒ "Chiếu hết trong 2 nước"). */
fun puzzleGoalText(p: Puzzle): String {
    val t = p.themes
    val mateIn = t.firstOrNull { it.startsWith("mateIn") }?.removePrefix("mateIn")?.toIntOrNull()
    return when {
        mateIn != null -> "Chiếu hết trong $mateIn nước"
        "mate" in t -> "Chiếu hết đối thủ"
        "fork" in t || "pin" in t || "skewer" in t || "hangingPiece" in t || "trappedPiece" in t -> "Giành quân"
        "promotion" in t -> "Phong cấp"
        "equality" in t -> "Cầm hòa"
        "advantage" in t || "crushing" in t -> "Giành lợi thế"
        else -> "Tìm nước đi tốt nhất"
    }
}
