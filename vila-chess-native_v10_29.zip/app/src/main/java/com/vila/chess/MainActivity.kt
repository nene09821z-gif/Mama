package com.vila.chess

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.vila.chess.auth.AccountStore
import com.vila.chess.billing.BillingRepository
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Screen
import com.vila.chess.game.GameKind
import com.vila.chess.ui.BotGameScreen
import com.vila.chess.ui.GameReviewScreen
import com.vila.chess.ui.PvpGameScreen
import com.vila.chess.ui.GoogleLoginGate
import com.vila.chess.ui.HomeScreen
import com.vila.chess.ui.SkillLevelSetupScreen
import com.vila.chess.ui.ViLaTheme
import com.vila.chess.ui.VilaColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AccountStore.load(this)   // nạp tài khoản trước khi vẽ UI để không nháy trang đăng nhập
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            ViLaTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val vm: GameViewModel = viewModel()
    val ctx = LocalContext.current
    // Đồng bộ gói với Google Play lúc mở app (offline thì giữ gói đã lưu).
    LaunchedEffect(Unit) { BillingRepository.get(ctx).refreshEntitlements() }
    // Cổng đăng nhập Google: chưa có tài khoản thì chỉ hiện trang đăng nhập.
    // Nếu google_web_client_id chưa được điền (còn YOUR_...) thì bỏ qua cổng để không bị kẹt ngoài app.
    val gateOn = !ctx.getString(R.string.google_web_client_id).startsWith("YOUR_")
    if (gateOn && AccountStore.current == null) {
        GoogleLoginGate()
        return
    }
    // Sau đăng nhập: chọn trình độ một lần (lưu Elo khởi điểm) rồi vào màn hình chính.
    if (!vm.skillSetupDone) {
        SkillLevelSetupScreen(onSelect = { vm.completeSkillSetup(it) })
        return
    }
    // Crossfade + nền đặc: chuyển Dialog tổng kết -> Game Review không bị nháy trắng/đen giữa hai màn.
    Box(Modifier.fillMaxSize().background(VilaColors.Bg)) {
        Crossfade(targetState = vm.screen, animationSpec = tween(220), label = "root") { screen ->
            when (screen) {
                Screen.HOME -> HomeScreen(vm)
                // Chơi với máy -> BotGameScreen; chơi với người -> PvpGameScreen (cùng một GameViewModel)
                Screen.GAME -> if (vm.ui.kind == GameKind.FRIEND) PvpGameScreen(vm) else BotGameScreen(vm)
                Screen.REVIEW -> GameReviewScreen(vm)
            }
        }
    }
}
