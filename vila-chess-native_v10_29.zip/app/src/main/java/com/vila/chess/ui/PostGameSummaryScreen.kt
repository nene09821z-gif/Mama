package com.vila.chess.ui

import android.content.Intent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.R
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.OpponentType
import com.vila.chess.game.PostGameViewModel
import com.vila.chess.game.Tournament
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val DlgBg = Color(0xFF262522)
private val DlgHeader = Color(0xFF302E2B)
private val SecBtn = Color(0xFF3C3A37)
private val SecBtnEdge = Color(0xFF2A2927)

// =====================================================================================
// PostGameDialog — dùng chung cho Bot / Người. "Xem lại ván đấu" đóng hộp thoại rồi chuyển sang
// GameReviewScreen (vm.openReview); các nút còn lại gọi đúng hàm cũ của GameViewModel
// (rematch / backToHome / dismiss), không tạo luồng điều hướng mới.
// =====================================================================================
@Composable
fun PostGameDialog(
    vm: GameViewModel,
    onDismiss: () -> Unit,
    pg: PostGameViewModel = viewModel(),
) {
    val ui = vm.ui
    val ctx = LocalContext.current
    var unavailable by remember { mutableStateOf<String?>(null) }

    val opponent = if (ui.kind == GameKind.FRIEND) OpponentType.HUMAN else OpponentType.BOT
    val localFriend = ui.kind == GameKind.FRIEND            // 2 người cùng máy: không có "phía của bạn"
    val coachText = remember(ui.humanWon, ui.draw, opponent, localFriend) {
        if (localFriend) "Ván đấu hay! Hãy xem lại để cùng tìm ra nước đi quyết định nhé."
        else pg.getCoachFeedback(ui.humanWon, -1f, opponent, vm.botLevelId, ui.draw)
    }
    val subtitle = if (ui.draw || ui.resultDetail.isBlank()) ui.resultDetail
    else "do " + ui.resultDetail.replaceFirstChar { it.lowercase() }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 760.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DlgBg)
        ) {
            PgHeader(
                title = ui.resultTitle, subtitle = subtitle, soundOn = vm.soundOn,
                onShare = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${ui.resultTitle} — $subtitle · ChessPlus")
                    }
                    ctx.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
                onSound = { vm.setSound(!vm.soundOn) },
                onClose = onDismiss,
            )
            Column(
                Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                CoachBubble(coachText)
                Spacer(Modifier.height(24.dp))
                PgPrimaryButton("Xem lại ván đấu") {
                    if (vm.reviewRequest != null) {
                        // Đóng hộp thoại trước, rồi chuyển cảnh (Crossfade ở AppRoot) sang màn Review.
                        onDismiss()
                        vm.openReview()
                    } else {
                        unavailable = vm.reviewSkipReason ?: "Ván này không có dữ liệu phân tích."
                    }
                }
                unavailable?.let {
                    Text(
                        it, color = Color(0xFFFFA459), fontSize = 14.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    when {
                        ui.kind == GameKind.TOURNAMENT -> {
                            val next = if (Tournament.nextRound(vm.tournament) >= 0) "Vòng tiếp theo" else "Xem kết quả"
                            PgSecondaryButton("Xem bàn cờ", Modifier.weight(1f), onDismiss)
                            PgSecondaryButton(next, Modifier.weight(1f)) { vm.rematch() }
                        }
                        opponent == OpponentType.BOT -> {
                            PgSecondaryButton("Bot mới", Modifier.weight(1f)) { vm.openBotSetupFromResult() }
                            PgSecondaryButton("Tái đấu", Modifier.weight(1f)) { vm.rematch() }
                        }
                        else -> {
                            // Chưa có matchmaking Online: "Tìm trận mới" = ván mới cùng chế độ.
                            PgSecondaryButton("Tìm trận mới", Modifier.weight(1f)) { vm.rematch() }
                            // "Phân tích" = đóng hộp thoại để xem/duyệt bàn cờ (không trùng nút Xem lại ván đấu).
                            PgSecondaryButton("Phân tích", Modifier.weight(1f), onDismiss)
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                FinalBoardCard(vm, Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

// ------------------------------------------------------------------ Header

@Composable
private fun PgHeader(title: String, subtitle: String, soundOn: Boolean, onShare: () -> Unit, onSound: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(DlgHeader).padding(horizontal = 12.dp, vertical = 14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Row(Modifier.width(88.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            PgIcon(Icons.Filled.Share, "Chia sẻ", onShare)
            PgIcon(if (soundOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff, "Âm thanh", onSound)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, lineHeight = 32.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = Color(0xFFBABABA), fontSize = 15.sp, textAlign = TextAlign.Center)
        }
        Box(Modifier.width(88.dp), contentAlignment = Alignment.TopEnd) { PgIcon(Icons.Filled.Close, "Đóng", onClose) }
    }
}

@Composable
private fun PgIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = Color(0xFFBABABA), modifier = Modifier.size(26.dp))
    }
}

// ------------------------------------------------------------------ HLV + bong bóng + typewriter

/** Avatar HLV + bong bóng thoại vẽ bằng Canvas (mũi nhọn chỉ vào avatar) + chữ gõ dần. */
@Composable
fun CoachBubble(text: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Image(
            painter = painterResource(R.drawable.coach),   // ảnh HLV dùng chung với bản đồ câu đố
            contentDescription = "Huấn luyện viên",
            contentScale = ContentScale.Fit,
            modifier = Modifier.width(92.dp).aspectRatio(349f / 290f),
        )
        Box(Modifier.weight(1f).padding(bottom = 14.dp)) {
            val tailW = 12.dp
            Canvas(Modifier.matchParentSize()) {
                val tw = tailW.toPx(); val r = 14.dp.toPx(); val ty = size.height - 26.dp.toPx()
                val body = Path().apply { addRoundRect(RoundRect(tw, 0f, size.width, size.height, CornerRadius(r))) }
                val tail = Path().apply {          // tam giác nhọn hướng sang trái, về phía avatar
                    moveTo(tw + 2f, ty - 9.dp.toPx()); lineTo(0f, ty + 2.dp.toPx()); lineTo(tw + 2f, ty + 9.dp.toPx()); close()
                }
                drawPath(body, Color.White); drawPath(tail, Color.White)
            }
            TypewriterText(
                text = text,
                style = TextStyle(color = Color(0xFF262421), fontSize = 17.sp, lineHeight = 23.sp, fontWeight = FontWeight.Medium),
                modifier = Modifier.padding(start = tailW + 12.dp, end = 12.dp, top = 12.dp, bottom = 12.dp),
            )
        }
    }
}

/**
 * Chữ hiện dần từng ký tự mà KHÔNG recomposition mỗi ký tự: đo layout MỘT lần, rồi mỗi frame chỉ
 * clip theo path của n ký tự đầu (getPathForRange) trong draw phase. Chiều cao đã chiếm đủ từ đầu nên bong bóng không giật.
 */
@Composable
fun TypewriterText(
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    charDelayMs: Int = 28,
    startDelayMs: Long = 350,
    onFinished: () -> Unit = {},
) {
    val measurer = rememberTextMeasurer()
    val progress = remember(text) { androidx.compose.animation.core.Animatable(0f) }
    val finish by rememberUpdatedState(onFinished)
    LaunchedEffect(text) {
        delay(startDelayMs)
        progress.animateTo(1f, tween((text.length * charDelayMs).coerceAtLeast(1), easing = LinearEasing))
        finish()
    }
    BoxWithConstraints(modifier.semantics { contentDescription = text }) {
        val layout = remember(text, style, constraints.maxWidth) {
            measurer.measure(AnnotatedString(text), style, constraints = Constraints(maxWidth = constraints.maxWidth))
        }
        val h = with(androidx.compose.ui.platform.LocalDensity.current) { layout.size.height.toDp() }
        var lastN = -1
        var cached: Path? = null
        Canvas(Modifier.fillMaxWidth().height(h)) {
            val n = (progress.value * text.length).roundToInt().coerceIn(0, text.length)
            if (n == 0) return@Canvas
            if (n != lastN) { cached = layout.getPathForRange(0, n); lastN = n }
            clipPath(cached!!) { drawText(layout) }
        }
    }
}

// ------------------------------------------------------------------ Nút

@Composable
private fun PgPrimaryButton(text: String, onClick: () -> Unit) {
    PgChunky(onClick, VilaColors.Green, VilaColors.GreenShadow, Modifier.fillMaxWidth(), 58.dp) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Star, null, tint = VilaColors.Green, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun PgSecondaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    PgChunky(onClick, SecBtn, SecBtnEdge, modifier, 46.dp) {
        Text(text, color = Color(0xFFE6E6E6), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

/** Nút "dày" kiểu chess.com: cạnh dưới tối, nhấn thì lún xuống. */
@Composable
private fun PgChunky(
    onClick: () -> Unit, face: Color, edge: Color, modifier: Modifier, height: androidx.compose.ui.unit.Dp,
    content: @Composable RowScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier.height(height + 4.dp).clip(shape).background(edge)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
    ) {
        Row(
            Modifier.fillMaxWidth().height(height).offset(y = if (pressed) 2.dp else 0.dp).clip(shape).background(face),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, content = content,
        )
    }
}

// ------------------------------------------------------------------ Bàn cờ cuối ván

@Composable
private fun FinalBoardCard(vm: GameViewModel, modifier: Modifier = Modifier) {
    val ui = vm.ui
    val images = vm.pieceImages
    Box(modifier.size(208.dp).padding(bottom = 8.dp)) {
        Box(Modifier.fillMaxSize().offset(y = 8.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF3A3936)))
        Canvas(Modifier.fillMaxSize().clip(RoundedCornerShape(26.dp))) {
            val cell = size.width / 8f
            fun tl(sq: Int): Offset {
                val f = sq and 7; val r = sq shr 3
                val col = if (ui.flipped) 7 - f else f
                val row = if (ui.flipped) r else 7 - r
                return Offset(col * cell, row * cell)
            }
            for (sq in 0 until 64) {
                val light = ((sq and 7) + (sq shr 3)) % 2 == 1
                drawRect(if (light) Color(0xFF6A6966) else Color(0xFF52514E), tl(sq), Size(cell, cell))
            }
            for (sq in intArrayOf(ui.lastFrom, ui.lastTo)) if (sq in 0..63) drawRect(Color(0x55F5F682), tl(sq), Size(cell, cell))
            for (sq in 0 until 64) {
                val code = ui.board[sq]
                val img = if (code > 0 && code < images.size) images[code] else null
                if (img != null) {
                    val o = tl(sq)
                    drawImage(img, dstOffset = IntOffset(o.x.roundToInt(), o.y.roundToInt()), dstSize = IntSize(cell.roundToInt() + 1, cell.roundToInt() + 1))
                }
            }
        }
    }
}
