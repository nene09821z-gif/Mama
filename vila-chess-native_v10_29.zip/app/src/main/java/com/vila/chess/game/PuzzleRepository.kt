package com.vila.chess.game

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File

/**
 * Nguồn câu đố. Thứ tự ưu tiên:
 *   1. assets/puzzles.db (tạo bằng scripts/generate_puzzles.py; cột `id` = số Level, `fen`, `moves`, `rating`, `themes`).
 *      Asset được chép 1 lần ra bộ nhớ app rồi mở read-only bằng SQLiteDatabase.
 *   2. [BuiltInPuzzles] – bộ dự phòng dựng sẵn, dùng khi thiếu/hỏng database ⇒ bàn cờ không bao giờ trống.
 *
 * Gọi [load] trên luồng IO (đọc file + truy vấn SQLite).
 */
object PuzzleRepository {
    private const val ASSET_NAME = "puzzles.db"
    private const val STAMP_SUFFIX = ".stamp"

    @Volatile
    private var db: SQLiteDatabase? = null

    @Volatile
    private var dbUnavailable = false

    fun load(context: Context, level: Int): Puzzle {
        val fromDb = if (dbUnavailable) null else try {
            query(context.applicationContext, level)
        } catch (e: Exception) {
            null
        }
        return fromDb ?: BuiltInPuzzles.forLevel(level)
    }

    private fun query(ctx: Context, level: Int): Puzzle? {
        val database = openDb(ctx) ?: return null
        database.rawQuery(
            "SELECT puzzle_id, fen, moves, rating, themes FROM puzzles WHERE id = ?",
            arrayOf(level.toString()),
        ).use { c ->
            if (!c.moveToFirst()) return null
            val moves = c.getString(2).trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (moves.size < 2) return null
            return Puzzle(
                level = level,
                puzzleId = c.getString(0),
                fen = c.getString(1),
                moves = moves,
                rating = c.getInt(3),
                themes = (c.getString(4) ?: "").trim().split(Regex("\\s+")).filter { it.isNotEmpty() },
            )
        }
    }

    @Synchronized
    private fun openDb(ctx: Context): SQLiteDatabase? {
        db?.let { if (it.isOpen) return it }
        if (dbUnavailable) return null
        return try {
            val target = ctx.getDatabasePath(ASSET_NAME)
            val stamp = File(target.path + STAMP_SUFFIX)
            // Chép lại khi file chưa có hoặc bản cài mới (lastUpdateTime đổi) ⇒ cập nhật app là cập nhật câu đố.
            val version = try {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime.toString()
            } catch (e: Exception) {
                "0"
            }
            if (!target.exists() || !stamp.exists() || stamp.readText() != version) {
                target.parentFile?.mkdirs()
                ctx.assets.open(ASSET_NAME).use { input ->
                    target.outputStream().use { out -> input.copyTo(out) }
                }
                stamp.writeText(version)
            }
            SQLiteDatabase.openDatabase(target.path, null, SQLiteDatabase.OPEN_READONLY).also { db = it }
        } catch (e: Exception) {
            dbUnavailable = true   // không có asset (hoặc hỏng) ⇒ không thử lại mỗi lần mở câu đố
            null
        }
    }
}
