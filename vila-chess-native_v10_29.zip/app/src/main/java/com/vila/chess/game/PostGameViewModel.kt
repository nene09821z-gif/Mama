package com.vila.chess.game

import androidx.lifecycle.ViewModel

/** Đối thủ: Bot hay Người (bạn bè cùng máy; sau này gắn thêm Online). */
enum class OpponentType { BOT, HUMAN }

/**
 * Lời nhận xét của HLV trên hộp thoại tổng kết. Việc phân tích ván nằm ở GameReviewViewModel (màn Game Review);
 * hộp thoại chỉ điều hướng sang đó.
 */
class PostGameViewModel : ViewModel() {

    // ------------------------------------------------------------------ Lời HLV

    /**
     * Câu nhận xét của HLV (mock). accuracy: 0..100, đưa số âm nếu CHƯA có (chưa phân tích xong).
     * botLevel > 0 sẽ chèn "Bot cấp N" và gợi ý cấp N+1 khi thắng.
     */
    fun getCoachFeedback(
        isWin: Boolean,
        accuracy: Float,
        opponentType: OpponentType,
        botLevel: Int = 0,
        isDraw: Boolean = false,
    ): String {
        val known = accuracy >= 0f
        return when {
            isDraw -> when {
                known && accuracy >= 80f -> "Ván hòa rất chặt chẽ, độ chính xác ${accuracy.toInt()}%. Chỉ cần thêm một nước mạnh là bạn đã thắng!"
                else -> "Một ván hòa đáng giá. Hãy xem lại để tìm khoảnh khắc bạn có thể đã thắng!"
            }
            isWin && opponentType == OpponentType.BOT -> {
                val who = if (botLevel > 0) "Bot cấp $botLevel" else "Bot"
                val next = if (botLevel in 1..7) " Hãy thử thách Bot cấp ${botLevel + 1} nhé!" else " Hãy thử thách mình ở cấp cao hơn nhé!"
                if (known && accuracy >= 90f) "Tuyệt vời! Bạn chơi gần như hoàn hảo trước $who (${accuracy.toInt()}%).$next"
                else "Bạn đã chơi rất tốt trước $who.$next"
            }
            isWin -> when {
                known && accuracy >= 90f -> "Chiến thắng thuyết phục với ${accuracy.toInt()}% chính xác! Đối thủ khó có cơ hội nào."
                else -> "Chúc mừng chiến thắng! Xem lại ván để biết đâu là nước đi quyết định."
            }
            opponentType == OpponentType.BOT ->
                if (known && accuracy < 60f) "Có vài nước đi sai lầm ở giữa ván. Hãy xem lại và cải thiện nhé!"
                else "Đối thủ có khai cuộc tốt hơn. Hãy xem lại và cải thiện!"
            else ->
                if (known && accuracy < 60f) "Ván này có vài sai lầm lớn. Xem lại để rút kinh nghiệm cho trận sau nhé!"
                else "Đối thủ có khai cuộc tốt hơn. Hãy xem lại và cải thiện!"
        }
    }
}
