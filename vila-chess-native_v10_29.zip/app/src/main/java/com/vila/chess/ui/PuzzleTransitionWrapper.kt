package com.vila.chess.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.view.HapticFeedbackConstants
import android.view.SoundEffectConstants
import androidx.activity.compose.BackHandler
import androidx.annotation.RawRes
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.game.PuzzleMapViewModel
import androidx.compose.ui.layout.onSizeChanged
import kotlin.math.roundToInt

private const val DURATION_MS = 350
private val Ease = FastOutSlowInEasing

/**
 * Bọc Map + Solve. Mọi animation chỉ đọc `progress` trong khối graphicsLayer / draw
 * (tầng Render) => không recomposition, không relayout trong lúc chạy.
 */
@Composable
fun PuzzleTransitionWrapper(
    modifier: Modifier = Modifier,
    @RawRes whooshRes: Int? = null,
    nodeState: (level: Int) -> NodeState = { NodeState.Done },   // trạng thái THẬT của nút để "bóng nút" khi chuyển cảnh trông giống nút gốc
    onSolved: (level: Int) -> Unit = {},                         // gọi SAU khi màn Solve đóng xong vì thắng ⇒ ViewModel đặt justCompletedLevel
    onSolveVisibleChange: (Boolean) -> Unit = {},                // true khi đang mở màn giải đố ⇒ HomeScreen ẩn thanh điều hướng đáy
    map: @Composable (
        onNodeClick: (level: Int, centerInRoot: Offset) -> Unit,
        hiddenLevel: State<Int?>,
    ) -> Unit,
    solve: @Composable (level: Int, onBack: () -> Unit, onSolved: () -> Unit) -> Unit,
) {
    var selectedLevel by remember { mutableStateOf<Int?>(null) }
    var lastLevel by remember { mutableStateOf(1) }          // giữ level để chạy animation đảo ngược
    var showSolve by remember { mutableStateOf(false) }      // chỉ đổi 2 lần mỗi lượt chuyển cảnh
    var origin by remember { mutableStateOf(Offset.Zero) }   // tâm nút, toạ độ cục bộ
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    var solvedOnClose by remember { mutableStateOf(false) }  // đóng màn Solve vì THẮNG (không phải bấm Back)
    val currentOnSolved by rememberUpdatedState(onSolved)
    val currentOnSolveVisible by rememberUpdatedState(onSolveVisibleChange)
    LaunchedEffect(selectedLevel != null) { currentOnSolveVisible(selectedLevel != null) }
    val playWhoosh = rememberWhoosh(whooshRes)
    // Nút gốc bị ẩn suốt lúc chuyển cảnh (bóng nút thay thế), hiện lại khi đã đóng xong.
    val hiddenLevel = remember { derivedStateOf { if (showSolve) lastLevel else null } }

    val progress = animateFloatAsState(
        targetValue = if (selectedLevel != null) 1f else 0f,
        animationSpec = tween(DURATION_MS, easing = Ease),
        finishedListener = {
            if (selectedLevel == null) {
                showSolve = false
                // Bản đồ đã hiện lại ⇒ lúc này mới phát animation quân cờ nhảy.
                if (solvedOnClose) { solvedOnClose = false; currentOnSolved(lastLevel) }
            }
        },
        label = "puzzleTransition",
    )

    fun open(level: Int, centerInRoot: Offset) {
        origin = centerInRoot - rootPos
        lastLevel = level
        showSolve = true
        selectedLevel = level
        playWhoosh()
    }

    fun close(solved: Boolean = false) {
        if (selectedLevel == null) return
        solvedOnClose = solved
        selectedLevel = null
        playWhoosh()
    }

    BackHandler(enabled = selectedLevel != null) { close() }

    Box(
        modifier
            .fillMaxSize()
            .onSizeChanged { boxSize = it }
            .onGloballyPositioned { rootPos = it.positionInRoot() },
    ) {
        // 1) Bản đồ
        map({ level, center -> if (selectedLevel == null) open(level, center) }, hiddenLevel)

        if (showSolve) {
            // 2) Overlay đen 50%: đọc progress trong draw phase.
            Box(
                Modifier
                    .fillMaxSize()
                    .drawBehind { drawRect(Color.Black.copy(alpha = 0.5f * progress.value)) }
            )

            // 3) Bóng nút gỗ: phóng 1 -> 1.2 và mờ dần. Offset là hằng số (không animate).
            Box(
                Modifier
                    .offset { IntOffset((origin.x - NodeW.toPx() / 2).roundToInt(), (origin.y - NodeH.toPx() / 2).roundToInt()) }
                    .graphicsLayer {
                        val p = progress.value
                        scaleX = 1f + 0.2f * p
                        scaleY = 1f + 0.2f * p
                        alpha = 1f - p
                    }
            ) { WoodenNode(level = lastLevel, state = nodeState(lastLevel)) }

            // 4) Màn Solve: phóng 0.8 -> 1 từ tâm nút, mờ -> rõ.
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val p = progress.value
                        val s = 0.8f + 0.2f * p
                        scaleX = s
                        scaleY = s
                        alpha = p
                        transformOrigin = TransformOrigin(
                            origin.x / boxSize.width.coerceAtLeast(1),
                            origin.y / boxSize.height.coerceAtLeast(1),
                        )
                    }
                    .pointerInput(Unit) {} // chặn chạm xuyên xuống map
            ) { solve(lastLevel, { close() }, { close(solved = true) }) }
        }
    }
}

/** Âm thanh "whoosh": dùng res/raw nếu có, không thì fallback click + haptic hệ thống. */
@Composable
fun rememberWhoosh(@RawRes resId: Int?): () -> Unit {
    val context: Context = LocalContext.current
    val view = LocalView.current
    val pool = remember(resId) {
        resId?.let {
            val sp = SoundPool.Builder()
                .setMaxStreams(2)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                ).build()
            sp to sp.load(context, it, 1)
        }
    }
    DisposableEffect(pool) { onDispose { pool?.first?.release() } }
    return {
        if (pool != null) pool.first.play(pool.second, 0.6f, 0.6f, 1, 0, 1f)
        else {
            view.playSoundEffect(SoundEffectConstants.CLICK)
            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }
}

/** Tab "Câu đố" của HomeScreen: 50.000 level từ PuzzleMapViewModel + chuyển cảnh Zoom & Fade sang màn giải. */
@Composable
fun PuzzleTab(
    bottomPad: Dp,
    images: Array<ImageBitmap?>,
    onSolvingChange: (Boolean) -> Unit = {},
    vm: PuzzleMapViewModel = viewModel(),
) {
    val currentLevel by vm.currentLevel.collectAsStateWithLifecycle()
    val justCompleted by vm.justCompletedLevel.collectAsStateWithLifecycle()
    // Rời tab (hoặc thoát màn) thì luôn trả thanh điều hướng về trạng thái hiện.
    val currentOnSolving by rememberUpdatedState(onSolvingChange)
    DisposableEffect(Unit) { onDispose { currentOnSolving(false) } }
    PuzzleTransitionWrapper(
        whooshRes = com.vila.chess.R.raw.move,
        nodeState = { level ->
            when {
                level < currentLevel -> NodeState.Done
                level == currentLevel -> NodeState.Current
                else -> NodeState.Locked
            }
        },
        onSolved = vm::onPuzzleSolved,
        onSolveVisibleChange = onSolvingChange,
        map = { onNodeClick, hiddenLevel ->
            PuzzleMapScreen(
                levels = vm.levels,
                currentLevel = currentLevel,
                progress = (currentLevel - 1) / PuzzleMapViewModel.TOTAL_LEVELS.toFloat(),
                hiddenLevel = hiddenLevel,
                justCompletedLevel = justCompleted,
                onCelebrationFinished = vm::onCelebrationShown,
                onNodeClick = onNodeClick,
                bottomPad = bottomPad,
            )
        },
        solve = { level, onBack, onSolved -> PuzzleSolveScreen(level = level, images = images, onBack = onBack, onSolved = onSolved) },
    )
}
