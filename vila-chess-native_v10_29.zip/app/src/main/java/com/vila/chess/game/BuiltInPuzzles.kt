package com.vila.chess.game

/**
 * Bộ câu đố DỰ PHÒNG, dựng sẵn trong code: chỉ dùng khi không đọc được assets/puzzles.db
 * (chưa chạy scripts/generate_puzzles.py) ⇒ bàn cờ KHÔNG BAO GIỜ trống.
 * Cùng định dạng Lichess: FEN trước nước đối thủ · moves[0] = nước đối thủ · rating tăng dần.
 * Mọi câu đã được kiểm bằng PuzzleSession + engine của dự án (luật đi, chiếu hết, lời giải ép buộc).
 */
object BuiltInPuzzles {

    private class Raw(val fen: String, val moves: String, val rating: Int, val themes: String)

    private val all: List<Raw> = listOf(
        Raw("6k1/p4ppp/8/8/8/8/5PPP/3R2K1 b - - 0 1", "a7a6 d1d8", 400, "mate mateIn1 backRankMate"),
        Raw("r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 5 3", "g8f6 h5f7", 450, "mate mateIn1"),
        Raw("3r2k1/5ppp/8/8/8/8/P4PPP/6K1 w - - 0 1", "a2a3 d8d1", 460, "mate mateIn1 backRankMate"),
        Raw("rnbqkbnr/pppp1ppp/8/4p3/8/5P2/PPPPP1PP/RNBQKBNR w KQkq - 0 2", "g2g4 d8h4", 500, "mate mateIn1 opening"),
        Raw("6rk/p5pp/8/4N3/8/8/8/6K1 b - - 0 1", "a7a6 e5f7", 520, "mate mateIn1 smotheredMate"),
        Raw("5rk1/p4ppp/8/7Q/8/3B4/5PPP/6K1 b - - 0 1", "a7a6 h5h7", 550, "mate mateIn1"),
        Raw("6k1/R7/7p/8/8/8/8/1R4K1 b - - 0 1", "h6h5 b1b8", 600, "mate mateIn1"),
        Raw("r3k3/p7/8/3N4/8/8/5PPP/6K1 b - - 0 1", "a7a6 d5c7 e8d8 c7a8", 700, "fork advantage short"),
        Raw("5r1k/p5pp/4Q3/4N3/2B5/8/8/6K1 b - - 0 1", "a7a6 e6g8 f8g8 e5f7", 800, "mate mateIn2 smotheredMate"),
        Raw("3r2k1/p4ppp/8/8/4Q3/8/5PPP/4R1K1 b - - 0 1", "a7a6 e4e8 d8e8 e1e8", 900, "mate mateIn2 backRankMate"),
        Raw("4r1k1/5ppp/8/4q3/8/8/P4PPP/3R2K1 w - - 0 1", "a2a3 e5e1 d1e1 e8e1", 950, "mate mateIn2 backRankMate"),
        Raw("rn1qkbnr/ppp2p1p/3p2p1/4N3/2B1P1b1/2N5/PPPP1PPP/R1BQK2R b KQkq - 0 5", "g4d1 c4f7 e8e7 c3d5", 1000, "mate mateIn2 opening"),
    )

    val size: Int get() = all.size

    /** Câu đố dự phòng cho [level] (lặp vòng khi level vượt quá số câu có sẵn). */
    fun forLevel(level: Int): Puzzle {
        val r = all[(level - 1).mod(all.size)]
        return Puzzle(
            level = level,
            puzzleId = "builtin-" + ((level - 1).mod(all.size) + 1),
            fen = r.fen,
            moves = r.moves.split(' '),
            rating = r.rating,
            themes = r.themes.split(' '),
        )
    }

    /** Dùng cho kiểm thử: toàn bộ câu dự phòng, mỗi câu 1 level 1..size. */
    fun everything(): List<Puzzle> = List(all.size) { forLevel(it + 1) }
}
