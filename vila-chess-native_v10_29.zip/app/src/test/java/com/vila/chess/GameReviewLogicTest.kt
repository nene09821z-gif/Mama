package com.vila.chess

import com.vila.chess.review.MoveLabel
import com.vila.chess.review.MoveReview
import com.vila.chess.review.MoveRow
import com.vila.chess.review.ReviewDisplay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GameReviewLogicTest {
    private fun mv(ply: Int, white: Boolean) = MoveReview(ply, white, MoveLabel.GOOD, 0.0, 0, null)

    @Test
    fun uciSquares() {
        assertEquals(Pair(12, 28), ReviewDisplay.parseUciSquares("e2e4"))
        assertEquals(Pair(6, 21), ReviewDisplay.parseUciSquares("g1f3"))
        assertNull(ReviewDisplay.parseUciSquares(null))
        assertNull(ReviewDisplay.parseUciSquares("zz"))
    }

    @Test
    fun evalTextAndFraction() {
        assertEquals("0.0", ReviewDisplay.evalText(0, null))
        assertEquals("+0.3", ReviewDisplay.evalText(30, null))
        assertEquals("-1.2", ReviewDisplay.evalText(-120, null))
        assertEquals("M3", ReviewDisplay.evalText(0, 3))
        assertEquals("-M2", ReviewDisplay.evalText(0, -2))
        assertEquals(0.5f, ReviewDisplay.evalFraction(0, null), 0.001f)
        assertEquals(1f, ReviewDisplay.evalFraction(0, 3), 0f)
        assertEquals(0f, ReviewDisplay.evalFraction(0, -1), 0f)
    }

    @Test
    fun moveRows() {
        val white = listOf(mv(1, true), mv(2, false), mv(3, true))
        assertEquals(listOf(MoveRow(1, 1, 2), MoveRow(2, 3, null)), ReviewDisplay.buildMoveRows(white))
        val black = listOf(mv(1, false), mv(2, true))
        assertEquals(listOf(MoveRow(1, null, 1), MoveRow(2, 2, null)), ReviewDisplay.buildMoveRows(black))
        assertEquals(1, ReviewDisplay.rowIndexOf(ReviewDisplay.buildMoveRows(white), 3))
    }
}
