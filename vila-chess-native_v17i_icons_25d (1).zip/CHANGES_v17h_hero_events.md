# v17h — Banner trang chủ nhiều sự kiện

- Carousel hero từ 2 slide lên 6: Học → Cờ Phép Thuật → Giải đấu 8 vòng → Giải câu đố → Danh hiệu CM·FM·GM → Huấn luyện viên.
- Mỗi slide chạm vào là mở đúng màn (Magic, Tournament, tab Câu đố, Titles).
- Tự lướt sang slide kế sau 5 giây; người dùng tự vuốt thì đếm lại.
- Thêm `HeroEvent` + `EventCard` (HomeParts.kt). Muốn thêm sự kiện: thêm 1 `HeroEvent` vào `heroEvents` và 1 nhánh trong `when (page)` (HomeScreen.kt).
- File đổi: ui/HomeScreen.kt, ui/HomeParts.kt (chép đè vào app/src/main/java/com/vila/chess/ui/).
