# v17d — Sửa build, mã Anbo, chuyển mục, thêm mana

- Sửa lỗi build: thiếu import `fillMaxSize` trong ProfileComponents.kt.
- Mã dùng thử Diamond đổi từ ANCUTO37 thành ANBO (LicenseManager.kt).
- Tab "Thêm" > mục Tài khoản: thêm dòng "Bảng xếp hạng" và "Cờ Phép Thuật" (đã bỏ khỏi "Các tùy chỉnh"). Thoát Cờ Phép Thuật về Trang chủ.
- Cờ Phép Thuật: mana tối đa 10 -> 20, mana đầu ván 2 -> 4, mỗi lượt +1 -> +2, bỏ qua 3 lá / tái chế +1 -> +2.
- Tái chế không còn giới hạn 1 lá mỗi lượt, nên bài không dùng được không còn bị kẹt trên tay.
- Cờ Phép Thuật có hiệu ứng khi dùng bài: biểu ngữ icon + tên lá giữa màn hình, các ô bị ảnh hưởng nháy vàng và vòng sáng lan ra (cả khi đối thủ online dùng bài).
- Bài «Nghi lễ mana»: bỏ bản +1, thêm +3/+5/+8 và chỉnh giá để luôn lời hơn «Tái chế» (+2).
- Mục Tài khoản có thêm "Đăng ký danh hiệu CM · FM · GM" (màn TitlesScreen). Phải đạt Elo >= 2000 (cao nhất 3 thể loại) và đã mở các thành tựu yêu cầu (CM: Cao thủ · FM: + Chinh phục Bot tối thượng · GM: + Bách chiến bách thắng + Bất khả chiến bại). Đăng ký xong, huy hiệu 🎖 hiện cạnh danh hiệu trên hồ sơ và trong tab Thêm. Bảng yêu cầu nằm ở `game/PlayerTitles.kt`.
- Danh hiệu đồng bộ Supabase: chạy `supabase/titles.sql` TRƯỚC khi cài bản mới (thêm cột `users.chess_title` + trigger chặn đặt danh hiệu khi Elo < 2000 và chặn hạ danh hiệu). Bạn bè thấy huy hiệu trên hồ sơ của bạn.
