-- =============================================================================
-- DANH HIỆU CM / FM / GM — chạy 1 lần trong Supabase → SQL Editor (chạy lại được, không mất dữ liệu).
-- PHẢI chạy TRƯỚC khi cài bản app mới (bản app mới đọc/ghi cột chess_title; thiếu cột thì đồng bộ hồ sơ báo lỗi 400).
-- =============================================================================

-- 1) Cột danh hiệu: '' = chưa có.
alter table public.users add column if not exists chess_title text not null default '';
alter table public.users drop constraint if exists users_chess_title_check;
alter table public.users add constraint users_chess_title_check check (chess_title in ('', 'cm', 'fm', 'gm'));

-- 2) Kiểm tra phía server (chống sửa bừa từ client):
--    - chỉ được đặt danh hiệu khi Elo cao nhất >= 2000 (khớp ChessTitle.minElo trong app),
--    - chỉ được NÂNG danh hiệu (cm < fm < gm), không hạ / xoá.
--    Elo vẫn do client tự ghi nên đây chỉ là lớp chặn cơ bản, không thay cho máy chủ xác thực ván.
create or replace function public.users_check_chess_title() returns trigger
language plpgsql as $$
declare
  old_rank int := 0;
  new_rank int;
begin
  new_rank := case new.chess_title when 'cm' then 1 when 'fm' then 2 when 'gm' then 3 else 0 end;
  if tg_op = 'UPDATE' then
    old_rank := case old.chess_title when 'cm' then 1 when 'fm' then 2 when 'gm' then 3 else 0 end;
    if new_rank = old_rank then return new; end if;
    if new_rank < old_rank then
      new.chess_title := old.chess_title;   -- không cho hạ / xoá danh hiệu: giữ nguyên thay vì báo lỗi
      return new;
    end if;
  end if;
  if new_rank > 0 and greatest(new.bullet_elo, new.blitz_elo, new.rapid_elo) < 2000 then
    raise exception 'Cần Elo từ 2000 để đăng ký danh hiệu' using errcode = 'check_violation';
  end if;
  return new;
end $$;

drop trigger if exists users_chess_title_guard on public.users;
create trigger users_chess_title_guard
  before insert or update of chess_title on public.users
  for each row execute function public.users_check_chess_title();

-- 3) Kiểm tra: select id, display_name, chess_title from public.users where chess_title <> '';
