# v17i — Icon 2.5D thật cho Trang chủ + chỉnh bố cục

Vấn đề: nhiều icon Trang chủ chỉ là hình phẳng có bóng đổ 1 lớp (chuỗi ngày, kim cương, bạn bè, chuông, đạn/chớp/đồng hồ/mặt trời,
5 icon thanh điều hướng, mũi tên + quân tốt ở thẻ Học), hai slide sự kiện dùng emoji, đồng hồ/nút X dùng icon Material.

## Hệ icon mới (ui/Kit25D.kt — file mới)
Mỗi icon là một "vật thể" 4 lớp: bóng tiếp đất → đế dày (nhiều bản sao dịch xuống, không hở) → mặt gradient sáng/đậm → ánh kính + viền sáng mép trên.
Quả cầu (đầu người, quả cầu mặt trời, núm chuông) dùng gradient tròn lệch sáng. Hình viết bằng chuỗi SVG path, dựng một lần ở top-level (không parse lại mỗi khung hình).
Lưới 48 x 48, tự co theo kích thước Modifier.

## Icon vẽ lại (ui/HomeIcons.kt — giữ nguyên tên hàm, chỗ gọi cũ vẫn chạy)
- FlameIcon, DiamondIcon (nhiều mặt cắt), FriendsIcon, BellIcon
- BulletIcon, BoltIcon, StopwatchIcon, SunIcon (4 icon thể loại: cũng tự đổi ở Ván mới / Lobby / Hồ sơ)
- PawnIcon(color, modifier) thành quân tốt 3D tô theo màu truyền vào; UpArrowIcon; MedalIcon (màn Giải đấu)
- 5 icon điều hướng (NavHome/Puzzle/Learn/Friends/More): vẫn có khối khi chưa chọn, chỉ bớt màu
- DiamondIcon có động (3,4 giây/vòng): lơ lửng nhẹ + bóng co giãn, dải sáng chéo quét qua rồi nghỉ một nhịp, 3 tia lấp lánh bật lần lượt.
  Hoạt hoạ chỉ đọc ở pha vẽ (không recomposition). Muốn đứng yên: DiamondIcon(modifier, animated = false)
- Mới: ClockIcon (chip thời gian), CloseIcon25D (nút ẩn thẻ gợi ý)
- BenefitKind.MAGIC (đũa phép) và BenefitKind.TITLE (huy chương) thay emoji 🪄 🎖 ở hai slide banner

## Bố cục (ui/HomeParts.kt, HomeScreen.kt, Components.kt)
- Modifier.lipBehind(): đế dày 2.5D dùng chung cho thẻ/nút
- Header: ba nút thành "phím bấm" 42dp có đế dày, icon 32dp; chip chuỗi ngày cùng ngôn ngữ, ngọn lửa 28dp; hàng cao 52dp
- Thẻ "Trận đấu đề nghị": sửa lỗi chip "ĐỐI THỦ GỢI Ý" bị bóp thành "ĐỐ" và tên đối thủ bị cắt sớm.
  Nay xếp 3 dòng: nhãn nhỏ · "Cấp N" + tên (chỉ phần tên bị cắt nếu dài) · chip thời gian có đồng hồ 2.5D.
  Đổi chữ ký SuggestedGameCard: title -> level + name
- Ô Hệ số: icon 42dp, chip tăng/giảm Elo đưa lên góc phải (mũi tên vẽ bằng Canvas, không dùng ký tự ▲▼), biểu đồ nhỏ chạy hết bề ngang, ô rộng 128dp
- Thẻ Học: quân tốt + mũi tên cùng tâm ngang thành một cụm; thẻ Huấn luyện viên dùng icon 2.5D thay icon Material
- Slide sự kiện: icon bắt buộc là BenefitKind (bỏ trường emoji của HeroEvent), có bóng tiếp đất dưới icon
- Thẻ bạn bè / ô hệ số / thẻ gợi ý có đế dày; nút "+" xanh có đế
- Thanh dưới: nền đặc nhanh hơn (hết cảnh thẻ cuộn lộ mờ qua nút Chơi), icon điều hướng 32dp, NAV_HEIGHT 62dp

File đổi: ui/Kit25D.kt (mới), ui/HomeIcons.kt, ui/HomeParts.kt, ui/HomeScreen.kt, ui/Components.kt, ui/BenefitIcons25D.kt
Lưu ý: bản này chưa được build thử trong môi trường soạn (không có Android SDK); nếu Gradle báo lỗi biên dịch, gửi lại log để sửa.

## Bảng xếp hạng tự cập nhật (ui/LeaderboardScreen.kt)
Trước: chỉ tải một lần khi mở màn, muốn thấy thay đổi phải bấm "Làm mới".
Nay:
- Tự làm mới nền mỗi 20 giây (LeaderboardViewModel.POLL_MS) khi màn đang hiện; ra nền/khoá máy thì dừng, quay lại thì tải bù ngay nếu dữ liệu đã cũ hơn 10 giây.
- Làm mới nền "im lặng": không hiện vòng tải, không xoá danh sách, không báo lỗi khi mất mạng (giữ bảng cũ, lần sau thử lại) nên không bị nháy.
- Kéo xuống để làm mới (PullToRefreshBox) + nút "Làm mới"; làm mới chủ động còn đẩy hồ sơ của mình lên máy chủ trước để dòng của mình không bị cũ.
- Hạng đổi thì các dòng trượt mượt sang vị trí mới (animateItem).
- Elo ai đó đổi so với lần tải trước: dòng nháy xanh/đỏ và hiện +8 / −5 trong 8 giây.
- Dòng "● Tự cập nhật · x giây trước" (chấm xanh nhấp nháy) cho người xem biết bảng đang sống.
Giới hạn: dựa trên việc mỗi người chơi đẩy Elo lên Supabase sau ván (đã có sẵn, ~1,5 giây sau ván). Người chơi offline/chưa đăng nhập thì Elo chưa lên bảng cho tới khi có mạng.
