package com.vila.chess

import com.vila.chess.game.Achievements
import com.vila.chess.game.ChessTitle
import com.vila.chess.game.TitleRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlayerTitlesTest {
    @Test
    fun requiredAchievementsExist() {
        val ids = Achievements.all.map { it.id }.toSet()
        for (t in ChessTitle.values()) assertTrue(t.name, ids.containsAll(t.needAchievements))
    }

    @Test
    fun cmNeedsEloAndAchievement() {
        assertFalse(TitleRules.eligible(ChessTitle.CM, 1999, setOf("elo_1800")))
        assertFalse(TitleRules.eligible(ChessTitle.CM, 2000, emptySet()))
        assertTrue(TitleRules.eligible(ChessTitle.CM, 2000, setOf("elo_1800")))
    }

    @Test
    fun gmNeedsEveryRequirement() {
        val all = ChessTitle.GM.needAchievements.toSet()
        assertTrue(TitleRules.eligible(ChessTitle.GM, 2300, all))
        assertFalse(TitleRules.eligible(ChessTitle.GM, 2300, all - "streak_10"))
        assertEquals(1 + all.size, TitleRules.requirements(ChessTitle.GM, 2300, all).size)
    }
}
