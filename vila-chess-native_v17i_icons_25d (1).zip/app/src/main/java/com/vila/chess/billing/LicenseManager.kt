package com.vila.chess.billing

import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class Redeemed(val tier: MembershipTier, val period: BillingPeriod, val expiresAt: Long)

/**
 * Mã kích hoạt offline: 24 ký tự hex = 7 byte nội dung + 5 byte chữ ký HMAC-SHA256.
 * Nội dung: [gói<<4 | chu kỳ] [ngày cấp (2 byte, tính từ 2024-01-01)] [mã thiết bị (4 byte)].
 * Tạo mã bằng scripts/gen_license.py. Mã gắn với 1 thiết bị và chỉ dùng được 1 lần.
 */
object LicenseManager {
    private const val DAY_MS = 86_400_000L
    private const val BASE_EPOCH_DAY = 19_723L        // 2024-01-01
    private const val REDEEM_WINDOW_DAYS = 90

    // Mã dùng thử cố định: mỗi thiết bị nhập được 1 lần. Muốn đổi gói / số ngày thì sửa 3 dòng dưới.
    private const val TRIAL_CODE = "ANBO"
    private val TRIAL_TIER = MembershipTier.DIAMOND
    private const val TRIAL_DAYS = 7

    fun deviceCode(ctx: Context): String {
        val id = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        val src = if (id.isBlank()) ctx.packageName else id
        val h = MessageDigest.getInstance("SHA-256").digest(("vila:" + src).toByteArray())
        return h.copyOfRange(0, 4).toHex()
    }

    fun redeem(ctx: Context, input: String): Result<Redeemed> {
        if (input.uppercase(Locale.ROOT).filter { it.isLetterOrDigit() } == TRIAL_CODE) return redeemTrial(ctx)
        val hex = input.uppercase(Locale.ROOT).filter { it in '0'..'9' || it in 'A'..'F' }
        if (hex.length != 24) return fail("Mã không đúng định dạng (cần 24 ký tự)")
        val bytes = ByteArray(12) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val payload = bytes.copyOfRange(0, 7)
        val sig = bytes.copyOfRange(7, 12)
        if (!MessageDigest.isEqual(sig, sign(payload))) return fail("Mã không hợp lệ")

        val head = payload[0].toInt() and 0xFF
        val tier = MembershipTier.values().firstOrNull { it != MembershipTier.FREE && it.rank == (head ushr 4) }
            ?: return fail("Mã không hợp lệ")
        val period = if ((head and 0x0F) == 1) BillingPeriod.YEARLY else BillingPeriod.MONTHLY
        val issueDay = ((payload[1].toInt() and 0xFF) shl 8) or (payload[2].toInt() and 0xFF)
        if (payload.copyOfRange(3, 7).toHex() != deviceCode(ctx)) return fail("Mã này dành cho thiết bị khác")
        val today = System.currentTimeMillis() / DAY_MS - BASE_EPOCH_DAY
        if (today - issueDay > REDEEM_WINDOW_DAYS) return fail("Mã đã quá hạn nhập (90 ngày kể từ lúc cấp)")

        val prefs = ctx.applicationContext.getSharedPreferences("vila_license", Context.MODE_PRIVATE)
        val used = prefs.getStringSet("used", emptySet()).orEmpty()
        if (hex in used) return fail("Mã này đã được sử dụng")

        val store = MembershipStore.get(ctx)
        val now = System.currentTimeMillis()
        val duration = (if (period == BillingPeriod.YEARLY) 366L else 31L) * DAY_MS
        val base = if (store.licenseTier() == tier) maxOf(now, store.licenseExpiry() ?: 0L) else now   // cùng gói → cộng dồn
        val expiry = base + duration
        prefs.edit().putStringSet("used", used + hex).apply()
        store.setLicense(tier, expiry)
        return Result.success(Redeemed(tier, period, expiry))
    }

    /** Mã dùng thử: cấp [TRIAL_TIER] trong [TRIAL_DAYS] ngày, mỗi thiết bị một lần, không hạ gói đang có. */
    private fun redeemTrial(ctx: Context): Result<Redeemed> {
        val prefs = ctx.applicationContext.getSharedPreferences("vila_license", Context.MODE_PRIVATE)
        val used = prefs.getStringSet("used", emptySet()).orEmpty()
        val key = "TRIAL:$TRIAL_CODE"
        if (key in used) return fail("Mã dùng thử này đã được sử dụng trên thiết bị này")
        val store = MembershipStore.get(ctx)
        val cur = store.licenseTier()
        if (cur != null && cur.rank >= TRIAL_TIER.rank) return fail("Bạn đang có gói ${cur.displayName} nên không cần mã dùng thử")
        val expiry = System.currentTimeMillis() + TRIAL_DAYS * DAY_MS
        prefs.edit().putStringSet("used", used + key).apply()
        store.setLicense(TRIAL_TIER, expiry)
        return Result.success(Redeemed(TRIAL_TIER, BillingPeriod.MONTHLY, expiry))
    }

    // ---------------------------------------------------------------- server (Cloudflare Worker)

    /**
     * Hỏi server gói của thiết bị này (server tự cấp khi SePay báo tiền về). Trả về null nếu chưa có gói / chưa cấu hình server.
     * Lỗi mạng → Result.failure (gói đã lưu trên máy giữ nguyên).
     */
    suspend fun syncFromServer(ctx: Context): Result<Redeemed?> = withContext(Dispatchers.IO) {
        if (ManualPay.SERVER_URL.isBlank()) return@withContext Result.success(null)
        runCatching {
            val conn = URL(ManualPay.SERVER_URL.trimEnd('/') + "/api/entitlement?device=" + deviceCode(ctx)).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            val j = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tier = MembershipTier.fromId(j.optString("tier"))
            val exp = j.optLong("expiresAt", 0L)
            val now = System.currentTimeMillis()
            if (tier == MembershipTier.FREE || exp <= now) return@runCatching null
            val store = MembershipStore.get(ctx)
            val cur = store.licenseTier()
            val curExp = store.licenseExpiry() ?: 0L
            if (cur == null || tier.rank > cur.rank || (tier == cur && exp > curExp)) store.setLicense(tier, exp)
            Redeemed(tier, if (exp - now > 60 * DAY_MS) BillingPeriod.YEARLY else BillingPeriod.MONTHLY, exp)
        }
    }

    // ---------------------------------------------------------------- admin

    fun checkAdminPin(pin: String): Boolean {
        val h = MessageDigest.getInstance("SHA-256").digest(pin.trim().toByteArray()).toHex().lowercase(Locale.ROOT)
        return MessageDigest.isEqual(h.toByteArray(), ManualPay.ADMIN_PIN_SHA256.lowercase(Locale.ROOT).toByteArray())
    }

    /** Tạo mã kích hoạt cho một thiết bị (giống scripts/gen_license.py). */
    fun generate(deviceHex: String, tier: MembershipTier, period: BillingPeriod): Result<String> {
        val hex = deviceHex.uppercase(Locale.ROOT).filter { it in '0'..'9' || it in 'A'..'F' }
        if (hex.length != 8) return Result.failure(IllegalArgumentException("Mã thiết bị phải đủ 8 ký tự (0-9, A-F)"))
        if (tier == MembershipTier.FREE) return Result.failure(IllegalArgumentException("Chọn gói Gold / Platinum / Diamond / Friends & Family"))
        val dev = ByteArray(4) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
        val day = (System.currentTimeMillis() / DAY_MS - BASE_EPOCH_DAY).toInt()
        val head = ((tier.rank shl 4) or (if (period == BillingPeriod.YEARLY) 1 else 0)).toByte()
        val payload = byteArrayOf(head, (day shr 8).toByte(), day.toByte()) + dev
        val code = (payload + sign(payload)).toHex().chunked(6).joinToString("-")
        return Result.success(code)
    }

    /** Admin tự cấp gói cho máy này (để thử), không qua mã. */
    fun grantSelf(ctx: Context, tier: MembershipTier, days: Int): Long {
        val exp = System.currentTimeMillis() + days * DAY_MS
        MembershipStore.get(ctx).setLicense(tier, exp)
        return exp
    }

    /** Gỡ gói cấp bằng mã/admin trên máy này (không ảnh hưởng gói Google Play). */
    fun revokeSelf(ctx: Context) = MembershipStore.get(ctx).setLicense(MembershipTier.FREE, 0L)

    fun formatDate(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date(ms))

    private fun sign(payload: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(ManualPay.LICENSE_SECRET.toByteArray(), "HmacSHA256"))
        return mac.doFinal(payload).copyOfRange(0, 5)
    }

    private fun fail(msg: String): Result<Redeemed> = Result.failure(IllegalArgumentException(msg))
    private fun ByteArray.toHex(): String = joinToString("") { "%02X".format(it) }
}
