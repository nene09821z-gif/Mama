package com.vila.chess.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.animation.core.animateFloatAsState
import kotlinx.coroutines.launch
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.RatingMode
import kotlin.math.ceil

// =============================================================================
// Chunky green button (the chess.com "3D" button: lighter face, darker bottom edge)
// =============================================================================

@Composable
fun ChunkyBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    edge: Dp = 4.dp,
    radius: Dp = 10.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val press = remember { Animatable(0f) }
    val feedback = LocalHapticFeedback.current
    val last = remember { longArrayOf(0L) }
    // Hiệu ứng nhấn chạy ở pha draw/graphicsLayer: không recomposition khi chạm.
    LaunchedEffect(source) {
        source.interactions.collect { i ->
            when (i) {
                is PressInteraction.Press -> launch { press.animateTo(1f, tween(70)) }
                is PressInteraction.Release, is PressInteraction.Cancel -> launch {
                    press.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow))
                }
            }
        }
    }
    Box(
        modifier = modifier
            .height(height + edge)
            .clickable(interactionSource = source, indication = null, role = Role.Button) {
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - last[0] >= 350L) {
                    last[0] = now
                    feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            }
            // Cạnh dưới đậm cố định (độ dày 3D)
            .drawBehind {
                drawRoundRect(
                    color = VilaColors.GreenShadow,
                    topLeft = Offset(0f, edge.toPx()),
                    size = Size(size.width, height.toPx()),
                    cornerRadius = CornerRadius(radius.toPx()),
                )
            },
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .graphicsLayer { translationY = press.value * edge.toPx() * 0.75f }
                .drawBehind {
                    val r = CornerRadius(radius.toPx())
                    drawRoundRect(brush = VilaBrushes.ButtonFace, cornerRadius = r)
                    // vệt sáng mảnh ở mép trên + tối nhẹ khi nhấn
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.16f),
                        topLeft = Offset(radius.toPx() * 0.6f, 1.dp.toPx()),
                        size = Size(size.width - radius.toPx() * 1.2f, 1.5.dp.toPx()),
                        cornerRadius = CornerRadius(1.dp.toPx()),
                    )
                    if (press.value > 0f) {
                        drawRoundRect(color = Color.Black.copy(alpha = 0.10f * press.value), cornerRadius = r)
                    }
                },
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

@Composable
fun ChunkyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    edge: Dp = 4.dp,
    radius: Dp = 10.dp,
    fontSize: TextUnit = 20.sp,
) {
    ChunkyBox(onClick = onClick, modifier = modifier, height = height, edge = edge, radius = radius) {
        Text(
            text = text,
            color = Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.2.sp,
            maxLines = 1,
        )
    }
}

// =============================================================================
// Header: avatar, streak, diamond, friends, bell
// =============================================================================

@Composable
private fun HeaderIcon(
    description: String,
    badge: Int,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    // Nút "phím bấm" 2.5D: mặt gradient xanh navy + đế tối dày 3dp; chạm thì cả nút lún xuống.
    val shape = RoundedCornerShape(14.dp)
    val lip = 3.dp
    Box(
        modifier = Modifier
            .size(width = 42.dp, height = 42.dp + lip)
            .pressable(onClickLabel = description, pressedScale = 0.9f, onClick = onClick)
            .lipBehind(14.dp, lip, Color(0xFF0A1325))
            .padding(bottom = lip)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF2E4A78), Color(0xFF1B2F52))))
            .border(1.dp, VilaBrushes.GlassStroke, shape),
        contentAlignment = Alignment.Center,
    ) {
        Box(modifier = Modifier.size(32.dp)) { content() }
        if (badge > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 4.dp, end = 4.dp)
                    .size(10.dp)
                    .background(VilaColors.Badge, CircleShape)
                    .border(1.5.dp, Color(0xFF1B2F52), CircleShape),
            )
        }
    }
}

@Composable
fun HomeHeader(
    name: String,
    avatarKey: String,
    streak: Int,
    bellCount: Int,
    friendsCount: Int,
    onAvatar: () -> Unit,
    onStreak: () -> Unit,
    onDiamond: () -> Unit,
    onFriends: () -> Unit,
    onBell: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Ảnh đại diện của CHÍNH BẠN; chạm để mở Hồ sơ.
        Box(
            modifier = Modifier
                .size(44.dp)
                .pressable(onClickLabel = "Hồ sơ", pressedScale = 0.9f, onClick = onAvatar)
                .clip(CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            ProfileAvatar(name = name, avatarKey = avatarKey, size = 44.dp)
        }
        Spacer(Modifier.width(10.dp))
        // Chip chuỗi ngày: cùng ngôn ngữ 2.5D với các nút (mặt gradient + đế dày)
        val pill = RoundedCornerShape(20.dp)
        val pillLip = 3.dp
        Row(
            modifier = Modifier
                .height(36.dp + pillLip)
                .pressable(onClickLabel = "Chuỗi ngày chơi", pressedScale = 0.92f, onClick = onStreak)
                .lipBehind(20.dp, pillLip, Color(0xFF2A1809))
                .padding(bottom = pillLip)
                .clip(pill)
                .background(Brush.verticalGradient(listOf(Color(0xFF6A4220), Color(0xFF422812))))
                .border(1.dp, Color(0x66FFA43A), pill)
                .padding(start = 6.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FlameIcon(Modifier.size(28.dp))
            Spacer(Modifier.width(3.dp))
            Text(
                text = streak.toString(),
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
        Spacer(Modifier.weight(1f))
        HeaderIcon("Kim cương", 0, onDiamond) { DiamondIcon(Modifier.fillMaxSize()) }
        Spacer(Modifier.width(8.dp))
        HeaderIcon("Bạn bè", friendsCount, onFriends) { FriendsIcon(Modifier.fillMaxSize()) }
        Spacer(Modifier.width(8.dp))
        HeaderIcon("Thông báo", bellCount, onBell) { BellIcon(Modifier.fillMaxSize()) }
    }
}

// =============================================================================
// Hero cards (horizontal carousel): Learn + Coach
// =============================================================================

private val HERO_SHAPE = RoundedCornerShape(22.dp)

/** Vẽ bàn cờ xanh/kem nhìn xiên (phối cảnh): hàng gần đáy to hơn hàng xa trên đỉnh. */
private fun DrawScope.drawPerspectiveBoard() {
    val w = size.width
    val h = size.height
    val cols = 10
    val rows = 6
    fun yAt(r: Int): Float {
        val t = r / rows.toFloat()
        return h * (0.04f + 1.0f * (0.45f * t + 0.55f * t * t))
    }
    fun xAt(c: Int, r: Int): Float {
        val t = r / rows.toFloat()
        val spread = 1.05f + 1.5f * t
        return w * (0.42f + (c / cols.toFloat() - 0.5f) * spread)
    }
    drawRect(Color(0xFF1B2E1F))
    for (r in 0 until rows) {
        for (c in 0 until cols) {
            val path = Path()
            path.moveTo(xAt(c, r), yAt(r))
            path.lineTo(xAt(c + 1, r), yAt(r))
            path.lineTo(xAt(c + 1, r + 1), yAt(r + 1))
            path.lineTo(xAt(c, r + 1), yAt(r + 1))
            path.close()
            drawPath(path, if (((r + c) and 1) == 0) Color(0xFF4A7A3A) else Color(0xFFC9D6AE))
        }
    }
}

@Composable
fun LearnCard(onStart: () -> Unit, modifier: Modifier = Modifier) {
    val textShadow = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 2f), 6f))
    Box(modifier = modifier.clip(HERO_SHAPE).border(1.dp, VilaBrushes.GlassStroke, HERO_SHAPE)) {
        Canvas(modifier = Modifier.matchParentSize()) {
            drawPerspectiveBoard()
            // tối dần về bên trái + phía trên để chữ dễ đọc
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xCC0B1530), Color(0x660B1530), Color(0x10000000)),
                ),
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0x66000000), Color.Transparent),
                    endY = size.height * 0.5f,
                ),
            )
        }
        // Hình minh họa: ngôi sao vàng, mũi tên xanh, quân tốt
        Box(Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 70.dp)) {
            Benefit25D(BenefitKind.REVIEW, Modifier.size(78.dp).rotate(12f))
        }
        // Quân tốt đứng trên bàn cờ, mũi tên xanh chỉ lên phía trên: cùng tâm ngang để thành một "cụm" gọn
        UpArrowIcon(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 42.dp, bottom = 40.dp)
                .size(52.dp),
        )
        PawnIcon(
            color = Color(0xFFE6EEFA),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 41.dp, bottom = 4.dp)
                .size(54.dp),
        )
        Column(modifier = Modifier.padding(start = 18.dp, top = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Benefit25D(BenefitKind.LEARN, Modifier.size(22.dp))
                Spacer(Modifier.width(7.dp))
                Text(
                    text = "BÀI HỌC TIẾP THEO",
                    color = Color(0xFF9CC9F5),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp,
                )
            }
            Text(
                text = "Học",
                color = Color.White,
                fontSize = 38.sp,
                lineHeight = 42.sp,
                fontWeight = FontWeight.ExtraBold,
                style = textShadow,
            )
            Text(
                text = "The King",
                color = Color(0xFFE9EEF7),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                style = textShadow,
            )
        }
        ChunkyButton(
            text = "Bắt đầu",
            onClick = onStart,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 18.dp, bottom = 14.dp)
                .width(112.dp),
            height = 36.dp,
            edge = 4.dp,
            radius = 11.dp,
            fontSize = 16.sp,
        )
    }
}

@Composable
fun CoachCard(on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .pressable(pressedScale = 0.98f, onClick = onClick)
            .clip(HERO_SHAPE)
            .background(Brush.verticalGradient(listOf(Color(0xFF2C4468), Color(0xFF1A2842))))
            .border(1.dp, VilaBrushes.GlassStroke, HERO_SHAPE),
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Benefit25D(BenefitKind.COACH, Modifier.size(64.dp))
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (on) "Huấn luyện viên: Bật" else "Bật huấn luyện viên",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = if (on) "Chạm Gợi ý trong ván cờ" else "Nhận gợi ý từng nước đi",
                    color = VilaColors.TextDim,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
    }
}

/** Dữ liệu một slide sự kiện trong carousel hero (trang chủ). */
data class HeroEvent(
    val kicker: String,
    val title: String,
    val subtitle: String,
    val button: String,
    val top: Color,
    val bottom: Color,
    val kickerColor: Color,
    val kind: BenefitKind,           // icon 2.5D lớn bên phải thẻ
)

/** Slide sự kiện chung: nền chuyển màu, icon lớn bên phải, chữ + nút bên trái. Chạm cả thẻ hoặc nút đều mở. */
@Composable
fun EventCard(event: HeroEvent, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val textShadow = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 2f), 6f))
    Box(
        modifier = modifier
            .pressable(pressedScale = 0.98f, onClick = onClick)
            .clip(HERO_SHAPE)
            .background(Brush.linearGradient(listOf(event.top, event.bottom)))
            .border(1.dp, VilaBrushes.GlassStroke, HERO_SHAPE),
    ) {
        // vòng sáng trang trí phía sau icon
        Canvas(modifier = Modifier.matchParentSize()) {
            drawCircle(Color(0x22FFFFFF), radius = size.height * 0.62f, center = Offset(size.width * 0.80f, size.height * 0.45f))
            drawCircle(Color(0x18FFFFFF), radius = size.height * 0.95f, center = Offset(size.width * 0.80f, size.height * 0.45f))
            // bóng tiếp đất dưới icon lớn: làm icon "đứng" trên thẻ thay vì dán phẳng
            drawOval(
                Color(0x40000000),
                topLeft = Offset(size.width - 78.dp.toPx() - 38.dp.toPx(), size.height / 2f + 50.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(76.dp.toPx(), 12.dp.toPx()),
            )
            drawRect(
                brush = Brush.horizontalGradient(listOf(Color(0x66000000), Color.Transparent)),
            )
        }
        Box(Modifier.align(Alignment.CenterEnd).padding(end = 30.dp)) {
            Benefit25D(event.kind, Modifier.size(96.dp).rotate(10f))
        }
        Column(modifier = Modifier.padding(start = 18.dp, top = 14.dp, end = 120.dp)) {
            Text(
                text = event.kicker,
                color = event.kickerColor,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.8.sp,
                maxLines = 1,
            )
            Text(
                text = event.title,
                color = Color.White,
                fontSize = 28.sp,
                lineHeight = 34.sp,
                fontWeight = FontWeight.ExtraBold,
                style = textShadow,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp),
            )
            Text(
                text = event.subtitle,
                color = Color(0xFFE9EEF7),
                fontSize = 13.sp,
                lineHeight = 17.sp,
                fontWeight = FontWeight.SemiBold,
                style = textShadow,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 2.dp),
            )
        }
        ChunkyButton(
            text = event.button,
            onClick = onClick,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 18.dp, bottom = 14.dp)
                .width(112.dp),
            height = 36.dp,
            edge = 4.dp,
            radius = 11.dp,
            fontSize = 16.sp,
        )
    }
}

/** Chấm phân trang của carousel hero: trang hiện tại là viên thuốc xanh dài. */
@Composable
fun HeroDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until count) {
            val on = i == current
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .width(if (on) 20.dp else 6.dp)
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(if (on) VilaColors.Green else Color(0x40FFFFFF)),
            )
        }
    }
}

// =============================================================================
// Section header ("Hệ số" ........ "Xem hết")
// =============================================================================

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    action: String? = null,
    onAction: () -> Unit = {},
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(30.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.2).sp,
            modifier = Modifier.weight(1f),
        )
        if (action != null) {
            Text(
                text = action + " ›",
                color = Color(0xFF8DC351),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .pressable(pressedScale = 0.92f, onClick = onAction)
                    .clip(RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

// =============================================================================
// Suggested game: opponent avatar, name, time control, green "start" button
// =============================================================================

@Composable
fun SuggestedGameCard(
    avatar: ImageBitmap?,
    level: String,
    name: String,
    timeLabel: String,
    onPlay: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(20.dp)
    val lip = 4.dp
    Box(modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(96.dp + lip)
                .lipBehind(20.dp, lip, Color(0xFF08101F))
                .padding(bottom = lip)
                .glass(shape)
                .padding(start = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val s = size.width / 4f
                    for (r in 0 until 4) {
                        for (c in 0 until 4) {
                            drawRect(
                                color = if ((r + c) % 2 == 0) VilaColors.BoardLight else VilaColors.BoardDark,
                                topLeft = Offset(c * s, r * s),
                                size = Size(s, s),
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color.White)
                        .padding(2.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(Color(0xFF2B2926)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (avatar != null) {
                        Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(42.dp))
                    }
                }
            }
            // Ba dòng xếp dọc: nhãn nhỏ · "Cấp N" + tên đối thủ (cắt bớt phần tên nếu dài) · chip thời gian.
            // Trước đây nhãn "ĐỐI THỦ GỢI Ý" nằm ngang cạnh chip nên bị bóp thành "ĐỐ" và tên bị cắt sớm.
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp, end = 8.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically),
            ) {
                Text(
                    text = "ĐỐI THỦ GỢI Ý",
                    color = VilaColors.Green,
                    fontSize = 10.5.sp,
                    letterSpacing = 0.6.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = level,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                    )
                    Text(
                        text = " · " + name,
                        color = VilaColors.TextDim,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                }
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x26FFFFFF))
                        .padding(start = 5.dp, end = 8.dp, top = 3.dp, bottom = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ClockIcon(Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = timeLabel,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                }
            }
            Benefit25D(
                BenefitKind.NEWGAME,
                Modifier
                    .padding(end = 14.dp)
                    .size(50.dp)
                    .pressable(onClickLabel = "Chơi", pressedScale = 0.9f, onClick = onPlay),
            )
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 8.dp, y = (-8).dp)
                .size(30.dp)
                .pressable(onClickLabel = "Ẩn", pressedScale = 0.8f, onClick = onDismiss),
            contentAlignment = Alignment.Center,
        ) {
            CloseIcon25D(Modifier.size(26.dp))
        }
    }
}

// =============================================================================
// Rating tile (92 x 92): icon, number, label
// =============================================================================

private fun ratingAccent(mode: RatingMode): Color = when (mode) {
    RatingMode.BULLET -> Color(0xFFFFB347)
    RatingMode.BLITZ -> Color(0xFFFFD84A)
    RatingMode.RAPID -> Color(0xFF7CCB4C)
    RatingMode.DAILY -> Color(0xFFFFC857)
}

/** Đường xu hướng nhỏ (sparkline) từ danh sách Elo; ít hơn 2 điểm thì vẽ đường phẳng. */
@Composable
private fun Sparkline(values: List<Int>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val pad = 2.dp.toPx()
        val path = Path()
        if (values.size < 2) {
            path.moveTo(0f, h / 2f)
            path.lineTo(w, h / 2f)
        } else {
            val lo = values.min()
            val hi = values.max()
            val span = (hi - lo).coerceAtLeast(1)
            for (i in values.indices) {
                val x = w * i / (values.size - 1)
                val y = pad + (h - 2 * pad) * (1f - (values[i] - lo) / span.toFloat())
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
        }
        drawPath(
            path,
            color,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

/** Mũi tên nhỏ vẽ bằng Canvas (thay ký tự ▲ ▼ phụ thuộc phông chữ hệ thống). */
@Composable
private fun DeltaArrow(up: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val p = Path()
        if (up) {
            p.moveTo(w / 2f, 0f); p.lineTo(w, h); p.lineTo(0f, h)
        } else {
            p.moveTo(0f, 0f); p.lineTo(w, 0f); p.lineTo(w / 2f, h)
        }
        p.close()
        drawPath(p, color)
    }
}

@Composable
fun RatingTile(
    mode: RatingMode,
    rating: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    delta: Int = 0,
    history: List<Int> = emptyList(),
) {
    val shape = RoundedCornerShape(18.dp)
    val lip = 4.dp
    val accent = ratingAccent(mode)
    Column(
        modifier = modifier
            .width(128.dp)
            .height(132.dp + lip)
            .pressable(pressedScale = 0.95f, onClick = onClick)
            .lipBehind(18.dp, lip, Color(0xFF08101F))
            .padding(bottom = lip)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.30f), Color(0xCC1B2D4A), Color(0xCC15233D)),
                ),
            )
            .border(1.dp, VilaBrushes.GlassStroke, shape)
            .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 10.dp),
    ) {
        // Hàng trên: icon 2.5D lớn bên trái, chip tăng/giảm Elo 7 ngày bên phải
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            ModeIcon(mode, Modifier.size(42.dp))
            val up = delta >= 0
            val tone = if (up) Color(0xFF8DDB4F) else Color(0xFFFF7A66)
            Row(
                modifier = Modifier
                    .padding(top = 5.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Color(0x40000000))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                DeltaArrow(up, tone, Modifier.size(width = 8.dp, height = 7.dp))
                Spacer(Modifier.width(3.dp))
                Text(
                    text = kotlin.math.abs(delta).toString(),
                    color = tone,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                )
            }
        }
        Text(
            text = rating.toString(),
            color = Color.White,
            fontSize = 28.sp,
            lineHeight = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 2.dp),
        )
        Text(
            text = mode.label,
            color = VilaColors.TextDim,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 2.dp),
        )
        Spacer(Modifier.weight(1f))
        Sparkline(history, accent, Modifier.fillMaxWidth().height(18.dp))
    }
}

// =============================================================================
// Friend card (ngang: biểu tượng bên trái, chữ bên phải)
// =============================================================================

@Composable
fun FriendCard(
    title: String,
    subtitle: String,
    kind: BenefitKind,
    showPlus: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(18.dp)
    val lip = 4.dp
    Box(
        modifier = modifier
            .widthIn(min = 168.dp, max = 220.dp)
            .height(72.dp + lip)
            .pressable(pressedScale = 0.96f, onClick = onClick)
            .lipBehind(18.dp, lip, Color(0xFF08101F))
            .padding(bottom = lip)
            .glass(shape),
    ) {
        Row(
            modifier = Modifier.fillMaxSize().padding(start = 12.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Benefit25D(kind, Modifier.size(46.dp))
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.widthIn(min = 80.dp)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = subtitle,
                    color = VilaColors.TextDim,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (showPlus) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 6.dp, end = 6.dp)
                    .size(22.dp)
                    .lipBehind(7.dp, 2.dp, VilaColors.GreenShadow)
                    .padding(bottom = 2.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF9AD15E), VilaColors.Green))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Thêm bạn",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

// =============================================================================
// Bottom dock: big green "Chơi" button + 5-tab navigation
// =============================================================================

private class NavItem(val label: String, val icon: @Composable (Color, Modifier) -> Unit)

private val NAV_ITEMS = listOf(
    NavItem("Trang chủ") { c, m -> NavHomeIcon(c, m) },
    NavItem("Câu đố") { c, m -> NavPuzzleIcon(c, m) },
    NavItem("Học") { c, m -> NavLearnIcon(c, m) },
    NavItem("Bạn bè") { c, m -> NavFriendsIcon(c, m) },
    NavItem("Thêm nữa") { c, m -> NavMoreIcon(c, m) },
)

val NAV_HEIGHT = 62.dp
val PLAY_AREA_HEIGHT = 82.dp // 14 top gap + 60 button + 8 gap

@Composable
fun HomeDock(
    showPlay: Boolean,
    selected: Int,
    onSelect: (Int) -> Unit,
    onPlay: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val navy = Color(0xFF0A1226)
    val backdrop = if (showPlay) {
        Brush.verticalGradient(
            0f to navy.copy(alpha = 0f),
            0.14f to navy.copy(alpha = 0.97f),   // đặc nhanh để thẻ cuộn phía sau không lộ mờ qua nút Chơi
            1f to navy.copy(alpha = 0.98f),
        )
    } else {
        Brush.verticalGradient(listOf(navy.copy(alpha = 0.97f), navy.copy(alpha = 0.97f)))
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(backdrop)
            .navigationBarsPadding(),
    ) {
        if (!showPlay) Box(Modifier.fillMaxWidth().height(1.dp).background(VilaColors.Hairline))
        if (showPlay) {
            ChunkyButton(
                text = "Chơi",
                onClick = onPlay,
                modifier = Modifier
                    .padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 8.dp)
                    .fillMaxWidth(),
                height = 56.dp,
                edge = 4.dp,
                radius = 16.dp,
                fontSize = 26.sp,
            )
        }
        Row(modifier = Modifier.fillMaxWidth().height(NAV_HEIGHT).padding(horizontal = 7.5.dp)) {
            for (i in NAV_ITEMS.indices) {
                NavTab(item = NAV_ITEMS[i], selected = i == selected, onClick = { onSelect(i) }, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun NavTab(item: NavItem, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tint by animateColorAsState(
        targetValue = if (selected) Color.White else VilaColors.NavIdle,
        animationSpec = tween(180),
        label = "navTint",
    )
    val iconScale by animateFloatAsState(
        targetValue = if (selected) 1.1f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "navScale",
    )
    val indicator by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(200),
        label = "navIndicator",
    )
    Column(
        modifier = modifier
            .fillMaxHeight()
            .pressable(pressedScale = 0.92f, haptic = !selected, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .width(22.dp)
                .height(3.dp)
                .graphicsLayer { alpha = indicator; scaleX = 0.4f + 0.6f * indicator }
                .clip(RoundedCornerShape(bottomStart = 3.dp, bottomEnd = 3.dp))
                .background(VilaColors.Green),
        )
        Spacer(Modifier.height(5.dp))
        item.icon(tint, Modifier.size(32.dp).graphicsLayer { scaleX = iconScale; scaleY = iconScale })
        Spacer(Modifier.height(1.dp))
        Text(
            text = item.label,
            color = tint,
            fontSize = 11.5.sp,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Bold,
            maxLines = 1,
        )
    }
}
