package com.vila.chess.game

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Danh hiệu kỳ thủ đăng ký được: CM < FM < GM.
 * Điều kiện: Elo cao nhất (3 thể loại) đạt [minElo] VÀ đã mở các thành tựu trong [needAchievements] (thành tựu nào cũng có huy hiệu).
 * Muốn đổi mức yêu cầu thì sửa ngay bảng dưới đây.
 */
enum class ChessTitle(
    val key: String,
    val abbr: String,
    val fullName: String,
    val rank: Int,
    val minElo: Int,
    val needAchievements: List<String>,
) {
    CM("cm", "CM", "Ứng viên Kiện tướng", 1, 2000, listOf("elo_1800")),
    FM("fm", "FM", "Kiện tướng FIDE", 2, 2000, listOf("elo_1800", "beat_lvl8")),
    GM("gm", "GM", "Đại kiện tướng", 3, 2000, listOf("elo_1800", "beat_lvl8", "wins_100", "streak_10"));

    companion object {
        fun fromKey(k: String?): ChessTitle? = values().firstOrNull { it.key == k }
    }
}

/** Một dòng yêu cầu và đã đạt hay chưa (để hiện dấu ✓ / ✗). */
class TitleReq(val label: String, val detail: String, val met: Boolean)

object TitleRules {
    fun requirements(t: ChessTitle, bestElo: Int, doneAchievements: Set<String>): List<TitleReq> {
        val out = ArrayList<TitleReq>()
        out += TitleReq("Elo từ ${t.minElo} trở lên", "Hiện tại $bestElo", bestElo >= t.minElo)
        for (id in t.needAchievements) {
            val def = Achievements.all.firstOrNull { it.id == id }
            out += TitleReq("Thành tựu «${def?.title ?: id}»", def?.desc ?: "", id in doneAchievements)
        }
        return out
    }

    fun eligible(t: ChessTitle, bestElo: Int, doneAchievements: Set<String>): Boolean =
        requirements(t, bestElo, doneAchievements).all { it.met }
}

/** Danh hiệu đã đăng ký của người dùng (lưu trên máy). Chỉ nâng lên được, không hạ xuống. */
class TitleStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_titles", Context.MODE_PRIVATE)
    private val _title = MutableStateFlow(ChessTitle.fromKey(prefs.getString("title", null)))
    val title: StateFlow<ChessTitle?> = _title.asStateFlow()

    /** Đăng ký [t]. Trả null nếu thành công, ngược lại là lý do. */
    @Synchronized
    fun register(t: ChessTitle, bestElo: Int, doneAchievements: Set<String>): String? {
        val cur = _title.value
        if (cur != null && cur.rank >= t.rank) return "Bạn đã có danh hiệu ${cur.abbr}"
        if (!TitleRules.eligible(t, bestElo, doneAchievements)) return "Chưa đủ điều kiện ${t.abbr}"
        prefs.edit().putString("title", t.key).putLong("at", System.currentTimeMillis()).apply()
        _title.value = t
        return null
    }

    companion object {
        @Volatile private var inst: TitleStore? = null
        fun get(context: Context): TitleStore =
            inst ?: synchronized(this) { inst ?: TitleStore(context).also { inst = it } }
    }
}
