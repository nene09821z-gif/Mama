package com.vila.chess.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.profile.AvatarPhotos
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.Countries
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.ProfileError
import com.vila.chess.profile.ProfileException
import com.vila.chess.profile.ProfileRepository
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// =============================================================================
// Thành phần dùng chung của hệ thống Hồ sơ (màn Hồ sơ, bottom sheet đối thủ, danh sách bạn bè)
// =============================================================================

/** Avatar tròn: avatar dựng sẵn (quân cờ + màu) hoặc chữ cái đầu của tên trên nền màu ổn định theo tên. */
@Composable
fun ProfileAvatar(name: String, avatarKey: String, size: Dp, modifier: Modifier = Modifier) {
    val preset = Avatars.byKey(avatarKey)
    val bg = Color(preset?.argb ?: Avatars.colorFor(name))
    // Ảnh lấy từ thư viện máy ("photo:…"): lấy từ cache ngay nếu có, chưa có thì nạp ở luồng nền.
    val ctx = LocalContext.current
    val photo by produceState<ImageBitmap?>(
        initialValue = if (AvatarPhotos.hasImage(avatarKey)) AvatarPhotos.peek(ctx, avatarKey)?.asImageBitmap() else null,
        avatarKey,
    ) {
        value = if (AvatarPhotos.hasImage(avatarKey)) {
            withContext(Dispatchers.IO) { AvatarPhotos.loadAny(ctx, avatarKey)?.asImageBitmap() }
        } else null
    }
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(bg)
            .border(2.dp, Color(0x33FFFFFF), CircleShape)
            .semantics { contentDescription = "Ảnh đại diện của $name" },
        contentAlignment = Alignment.Center,
    ) {
        val img = photo
        if (img != null) {
            Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                text = preset?.glyph ?: Avatars.initials(name),
                color = Color.White,
                fontSize = (size.value * if (preset != null) 0.55f else 0.42f).sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

/** Tên (đậm) + huy hiệu VIP ngay cạnh. FREE không hiện huy hiệu và không chiếm chỗ. */
@Composable
fun NameWithBadge(
    name: String,
    tier: MembershipTier,
    modifier: Modifier = Modifier,
    fontSize: Float = 16f,
    badgeSize: Dp = 18.dp,
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = name,
            color = Color.White,
            fontSize = fontSize.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
        )
        if (tier != MembershipTier.FREE) {
            Spacer(Modifier.width(6.dp))
            MembershipBadge(tier, size = badgeSize)
        }
    }
}

/** "🇻🇳 Việt Nam"; chưa chọn quốc gia → null (không vẽ gì). */
@Composable
fun CountryLine(code: String, modifier: Modifier = Modifier) {
    val c = Countries.byCode(code) ?: return
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(Countries.flag(c.code), fontSize = 18.sp)
        Spacer(Modifier.width(6.dp))
        Text(c.name, color = VilaColors.TextDim, fontSize = 14.sp)
    }
}

/** Thẻ Elo nhỏ (Bullet / Blitz / Rapid). [selected] = đang là thể loại của biểu đồ. */
@Composable
fun EloCard(
    title: String,
    subtitle: String,
    rating: Int,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(if (selected) Color(0x3381B64C) else VilaColors.Glass)
            .border(1.dp, if (selected) VilaColors.Green else VilaColors.GlassBorder, shape)
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Text(rating.toString(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, color = VilaColors.TextDim, fontSize = 11.sp)
    }
}

/** Số liệu + nhãn (Ván / Thắng / Hòa / Thua). */
@Composable
fun StatTile(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = VilaColors.TextDim, fontSize = 12.sp)
    }
}

val WinColor = Color(0xFF81B64C)
val DrawColor = Color(0xFFB0B7C3)
val LossColor = Color(0xFFE05A47)

/** Thanh thắng/hòa/thua theo tỉ lệ. Chưa có ván nào → thanh xám. */
@Composable
fun WdlBar(won: Int, drawn: Int, lost: Int, modifier: Modifier = Modifier) {
    val total = won + drawn + lost
    Row(modifier = modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0x22FFFFFF))) {
        if (total > 0) {
            if (won > 0) Box(Modifier.weight(won.toFloat()).height(8.dp).background(WinColor))
            if (drawn > 0) Box(Modifier.weight(drawn.toFloat()).height(8.dp).background(DrawColor))
            if (lost > 0) Box(Modifier.weight(lost.toFloat()).height(8.dp).background(LossColor))
        }
    }
}

@Composable
fun LoadingBlock(modifier: Modifier = Modifier, text: String = "Đang tải…") {
    Column(
        modifier = modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        CircularProgressIndicator(color = VilaColors.Green, modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
        Text(text, color = VilaColors.TextDim, fontSize = 14.sp)
    }
}

/** Lỗi + nút "Thử lại" (ẩn nút khi thử lại vô ích: chưa đăng nhập / chưa cấu hình). */
@Composable
fun ErrorBlock(kind: ProfileError, modifier: Modifier = Modifier, onRetry: (() -> Unit)? = null) {
    val retryable = kind == ProfileError.NETWORK || kind == ProfileError.SERVER
    Column(
        modifier = modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(kind.message(), color = VilaColors.TextDim, fontSize = 14.sp, textAlign = TextAlign.Center)
        if (retryable && onRetry != null) ChunkyButton(text = "Thử lại", onClick = onRetry, height = 42.dp, fontSize = 16.sp, modifier = Modifier.width(160.dp))
    }
}

/**
 * Tải hồ sơ người chơi khác theo [userId]. Trả (trạng thái, hàm tải lại).
 * Tự hủy khi rời màn hình; đổi userId hoặc gọi tải lại → quay về Loading rồi tải lần nữa.
 */
@Composable
fun rememberRemoteProfile(userId: String): Pair<LoadState<UserProfile>, () -> Unit> {
    val ctx = LocalContext.current
    var attempt by remember { mutableIntStateOf(0) }
    val state by produceState<LoadState<UserProfile>>(LoadState.Loading, userId, attempt) {
        value = LoadState.Loading
        value = ProfileRepository.fetchProfile(ctx, userId).fold(
            onSuccess = { LoadState.Success(it) },
            onFailure = { LoadState.Error((it as? ProfileException)?.kind ?: ProfileError.SERVER) },
        )
    }
    val retry: () -> Unit = { attempt++ }
    return state to retry
}

/** Dòng gọn "Thắng · Hòa · Thua" dùng trong thẻ nhỏ. */
@Composable
fun WdlRow(p: UserProfile, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        StatTile("Thắng", p.won.toString(), WinColor, Modifier.weight(1f))
        StatTile("Hòa", p.drawn.toString(), DrawColor, Modifier.weight(1f))
        StatTile("Thua", p.lost.toString(), LossColor, Modifier.weight(1f))
    }
}
