package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.rememberTier
import com.vila.chess.game.GameViewModel

private val GUTTER = 16.dp

// =============================================================================
// "Thêm nữa" — menu kiểu Chess.com: logo, banner Cao cấp, danh sách Tài khoản
// =============================================================================

@Composable
fun MoreTab(
    bottomPad: Dp,
    onUpgrade: () -> Unit,
    onStats: () -> Unit,
    onAchievements: () -> Unit,
    onFriends: () -> Unit,
    onPreferences: () -> Unit,
    onTheme: () -> Unit,
    onAccount: () -> Unit,
    onProfile: () -> Unit,
    onGames: () -> Unit = {},
    onLeaderboard: () -> Unit = {},
    onMagic: () -> Unit = {},
    onTitles: () -> Unit = {},
    onShare: () -> Unit,
) {
    val tier = rememberTier()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 14.dp, bottom = bottomPad + 12.dp),
    ) {
        item(key = "logo") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PawnIcon(VilaColors.Green, Modifier.size(34.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = Color.White)) { append("ViLa") }
                        withStyle(SpanStyle(color = VilaColors.Green)) { append(" Chess") }
                    },
                    fontSize = 30.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                )
            }
        }
        item(key = "banner") {
            PremiumBanner(tier = tier, onClick = onUpgrade, modifier = Modifier.padding(start = GUTTER, end = GUTTER, top = 18.dp))
        }
        item(key = "accountTitle") {
            Text(
                text = "Tài khoản",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.padding(start = GUTTER, end = GUTTER, top = 26.dp, bottom = 4.dp),
            )
        }
        item(key = "profile") {
            // Hồ sơ của mình: tên kèm huy hiệu VIP theo gói hiện tại
            MoreRow(
                label = com.vila.chess.profile.UserSessionManager.displayName,
                onClick = onProfile,
                trailingContent = {
                    val myTitle by com.vila.chess.game.TitleStore.get(androidx.compose.ui.platform.LocalContext.current).title.collectAsState()
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        myTitle?.let { TitleChip(it) }
                        if (tier != MembershipTier.FREE) MembershipBadge(tier, size = 22.dp)
                    }
                },
            ) { ProfileAvatar(name = com.vila.chess.profile.UserSessionManager.displayName, avatarKey = com.vila.chess.profile.UserSessionManager.avatarKey, size = 34.dp) }
        }
        item(key = "login") {
            val acc = com.vila.chess.auth.AccountStore.current
            MoreRow(
                label = "Đăng nhập (Google / Email)",
                trailing = acc?.email,
                onClick = onAccount,
            ) { Icon(Icons.Filled.Settings, null, tint = VilaColors.Green, modifier = Modifier.size(30.dp)) }
        }
        item(key = "member") {
            MoreRow(
                label = "Thành viên",
                trailing = if (tier == MembershipTier.FREE) null else tier.displayName,
                onClick = onUpgrade,
            ) { DiamondIcon(Modifier.size(32.dp)) }
        }
        item(key = "stats") {
            MoreRow("Các số liệu thống kê", onClick = onStats) {
                Benefit25D(BenefitKind.STATS, Modifier.size(34.dp))
            }
        }
        item(key = "games") {
            MoreRow("Ván đã chơi", onClick = onGames) {
                Icon(Icons.Filled.History, null, tint = Color(0xFF9CC0F0), modifier = Modifier.size(32.dp))
            }
        }
        item(key = "awards") {
            MoreRow("Giải thưởng", onClick = onAchievements) { Benefit25D(BenefitKind.TROPHY, Modifier.size(34.dp)) }
        }
        item(key = "leaderboard") {
            MoreRow("Bảng xếp hạng", onClick = onLeaderboard) { Text("🏆", fontSize = 26.sp) }
        }
        item(key = "magic") {
            MoreRow("Cờ Phép Thuật", onClick = onMagic) { Text("🪄", fontSize = 26.sp) }
        }
        item(key = "titles") {
            val myTitle by com.vila.chess.game.TitleStore.get(androidx.compose.ui.platform.LocalContext.current).title.collectAsState()
            MoreRow("Đăng ký danh hiệu CM · FM · GM", trailing = myTitle?.abbr, onClick = onTitles) { Text("🎖", fontSize = 26.sp) }
        }
        item(key = "friends") {
            MoreRow("Bạn bè", onClick = onFriends) { Benefit25D(BenefitKind.FAMILY, Modifier.size(34.dp)) }
        }
        item(key = "theme") {
            MoreRow("Chủ đề", onClick = onTheme) {
                Icon(Icons.Filled.Palette, null, tint = Color(0xFFE58FB0), modifier = Modifier.size(32.dp))
            }
        }
        item(key = "prefs") {
            MoreRow("Các tùy chỉnh", onClick = onPreferences) {
                Icon(Icons.Filled.Settings, null, tint = Color(0xFFB9C1CE), modifier = Modifier.size(32.dp))
            }
        }
        item(key = "share") {
            MoreRow("Mời bạn bè", onClick = onShare) {
                Benefit25D(BenefitKind.INVITE, Modifier.size(34.dp))
            }
        }
    }
}

/** Banner xanh dương: người dùng FREE thấy lời mời nâng cấp, người đã mua thấy gói hiện tại. */
@Composable
private fun PremiumBanner(tier: MembershipTier, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    val free = tier == MembershipTier.FREE
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 104.dp)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF1B94E4), Color(0xFF1469C0))))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (free) DiamondIcon(Modifier.size(68.dp)) else MembershipBadge(tier, size = 68.dp)
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = if (free) "Thử dùng gói Cao cấp" else "Gói " + tier.displayName,
                color = Color.White,
                fontSize = 22.sp,
                lineHeight = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = if (free) "Chơi thứ cờ vua tốt nhất của bạn!" else "Chạm để quản lý hoặc nâng cấp gói",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Một dòng menu: icon 36dp + nhãn; vùng chạm cao 56dp, nhãn dài sẽ cắt bằng "…" thay vì tràn. */
@Composable
private fun MoreRow(
    label: String,
    trailing: String? = null,
    onClick: () -> Unit,
    trailingContent: (@Composable () -> Unit)? = null,
    icon: @Composable () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clickable(onClick = onClick)
            .padding(horizontal = GUTTER),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) { icon() }
        Spacer(Modifier.width(16.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (trailingContent != null) {
            Spacer(Modifier.width(8.dp))
            trailingContent()
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                text = trailing,
                color = VilaColors.TextDim,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
        }
    }
}

// =============================================================================
// "Các tùy chỉnh": âm thanh, rung, đi trước, huấn luyện viên (bàn cờ / quân cờ / hình nền / bộ âm thanh nằm ở trang Chủ đề)
// =============================================================================

@Composable
fun PreferencesScreen(vm: GameViewModel, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Box(modifier = Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE))
            }
            Text(
                text = "Các tùy chỉnh",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                modifier = Modifier.align(Alignment.Center),
            )
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = GUTTER, end = GUTTER, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "feedback") {
                GlassSection("ÂM THANH & RUNG") {
                    SwitchRow("Âm thanh", vm.soundOn) { vm.setSound(it) }
                    SwitchRow("Rung khi đi quân", vm.hapticOn) { vm.setHaptic(it) }
                }
            }
            item(key = "premove") {
                GlassSection("ĐI TRƯỚC (PREMOVE)") {
                    PremoveSettingRow(vm.premoveMode, { vm.setPremoveMode(it) })
                }
            }
            item(key = "coach") {
                GlassSection("HUẤN LUYỆN VIÊN") {
                    SwitchRow("Nút Gợi ý trong ván cờ", vm.coachOn) { vm.setCoach(it) }
                }
            }
            item(key = "teacher") {
                GlassSection("THẦY GIÁO (khi bật huấn luyện viên)") {
                    TeacherSettingsContent(vm.teacher)
                }
            }
        }
    }
}
