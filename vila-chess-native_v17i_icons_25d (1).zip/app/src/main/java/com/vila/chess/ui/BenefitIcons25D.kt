package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Bộ icon quyền lợi 2.5D (thay emoji): ô vuông bo tròn, nền gradient, viền đế nổi bên dưới,
 * lớp bóng kính phía trên và biểu tượng trắng có đổ bóng. Vẽ hoàn toàn bằng Canvas nên sắc nét ở mọi kích thước
 * và không tốn bộ nhớ ảnh. Cách dùng: Benefit25D(BenefitKind.REVIEW, Modifier.size(40.dp)).
 */
enum class BenefitKind { REVIEW, EXPLAIN, STATS, PUZZLE, LEARN, COACH, BOT, NOADS, FAMILY, INVITE, DUEL, TROPHY, NEWGAME, MAGIC, TITLE }

private class Pal(val top: Color, val bottom: Color, val lip: Color)

private fun palette(k: BenefitKind): Pal = when (k) {
    BenefitKind.REVIEW -> Pal(Color(0xFFFBD24E), Color(0xFFE2A200), Color(0xFFB87A00))
    BenefitKind.EXPLAIN -> Pal(Color(0xFFF2615F), Color(0xFFD22C3C), Color(0xFF9E1C2C))
    BenefitKind.STATS -> Pal(Color(0xFF4E9DF2), Color(0xFF2163CB), Color(0xFF174A98))
    BenefitKind.PUZZLE -> Pal(Color(0xFFA97DF2), Color(0xFF6F40D2), Color(0xFF4F2AA0))
    BenefitKind.LEARN -> Pal(Color(0xFF52C4F8), Color(0xFF1F86E4), Color(0xFF1665B0))
    BenefitKind.COACH -> Pal(Color(0xFFFFA64F), Color(0xFFE5701A), Color(0xFFB04F0E))
    BenefitKind.BOT -> Pal(Color(0xFF41D2BA), Color(0xFF14917F), Color(0xFF0D6A5C))
    BenefitKind.NOADS -> Pal(Color(0xFFF26C88), Color(0xFFD03856), Color(0xFF9C2640))
    BenefitKind.FAMILY -> Pal(Color(0xFF8DD64F), Color(0xFF4E9A28), Color(0xFF38741B))
    BenefitKind.INVITE -> Pal(Color(0xFF58BDF8), Color(0xFF2080E0), Color(0xFF1562B0))
    BenefitKind.DUEL -> Pal(Color(0xFFFFA763), Color(0xFFE56E2A), Color(0xFFB04C16))
    BenefitKind.TROPHY -> Pal(Color(0xFFFBD24E), Color(0xFFE2A200), Color(0xFFB87A00))
    BenefitKind.NEWGAME -> Pal(Color(0xFF8DD64F), Color(0xFF4E9A28), Color(0xFF38741B))
    BenefitKind.MAGIC -> Pal(Color(0xFFB784F5), Color(0xFF7A3FD6), Color(0xFF53279E))
    BenefitKind.TITLE -> Pal(Color(0xFF3FD0A6), Color(0xFF14937A), Color(0xFF0C6A58))
}

@Composable
fun Benefit25D(kind: BenefitKind, modifier: Modifier = Modifier) {
    val pal = remember(kind) { palette(kind) }
    Canvas(modifier) {
        val w = size.minDimension
        val lip = w * 0.09f
        val th = w - lip
        val corner = CornerRadius(w * 0.3f, w * 0.3f)
        // đế nổi
        drawRoundRect(pal.lip, Offset(0f, lip), Size(w, th), corner)
        // mặt chính
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(pal.top, pal.bottom), startY = 0f, endY = th),
            topLeft = Offset.Zero, size = Size(w, th), cornerRadius = corner,
        )
        // bóng kính
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color(0x47FFFFFF), Color(0x00FFFFFF)), startY = 0f, endY = th * 0.55f),
            topLeft = Offset.Zero, size = Size(w, th * 0.55f), cornerRadius = corner,
        )
        val u = th * 0.62f / 24f
        val gx = (w - 24f * u) / 2f
        val gy = (th - 24f * u) / 2f
        // bóng đổ của biểu tượng rồi biểu tượng thật
        val shadow = Color(0x40000000)
        translate(gx, gy + w * 0.035f) { glyph(kind, u, shadow, shadow) }
        translate(gx, gy) { glyph(kind, u, Color.White, pal.bottom) }
    }
}

private fun poly(u: Float, vararg p: Float): Path {
    val path = Path()
    path.moveTo(p[0] * u, p[1] * u)
    var i = 2
    while (i < p.size) {
        path.lineTo(p[i] * u, p[i + 1] * u)
        i += 2
    }
    path.close()
    return path
}

private fun DrawScope.rr(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float, u: Float) =
    drawRoundRect(c, Offset(x * u, y * u), Size(w * u, h * u), CornerRadius(r * u, r * u))

private fun DrawScope.dot(c: Color, x: Float, y: Float, r: Float, u: Float) =
    drawCircle(c, radius = r * u, center = Offset(x * u, y * u))

/** c = màu biểu tượng, cut = màu "khoét" (mắt robot, nếp phong bì...). Lưới 24 x 24. */
private fun DrawScope.glyph(kind: BenefitKind, u: Float, c: Color, cut: Color) {
    when (kind) {
        BenefitKind.REVIEW -> {
            val p = Path()
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) 11.4f else 5f
                val a = (-90f + i * 36f) * PI.toFloat() / 180f
                val x = (12f + cos(a) * r) * u
                val y = (12.8f + sin(a) * r) * u
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            p.close()
            drawPath(p, c)
            drawPath(p, c, style = Stroke(width = 1.6f * u, join = StrokeJoin.Round))
        }
        BenefitKind.EXPLAIN -> {
            for (x in floatArrayOf(7.2f, 16.8f)) {
                rr(c, x - 2.1f, 2.2f, 4.2f, 12.6f, 2.1f, u)
                dot(c, x, 19.6f, 2.3f, u)
            }
        }
        BenefitKind.STATS -> {
            rr(c, 3f, 13f, 4.8f, 9f, 1.6f, u)
            rr(c, 9.6f, 7.6f, 4.8f, 14.4f, 1.6f, u)
            rr(c, 16.2f, 2.2f, 4.8f, 19.8f, 1.6f, u)
        }
        BenefitKind.PUZZLE -> {
            rr(c, 3.4f, 8.6f, 14f, 13.6f, 3.4f, u)
            dot(c, 10.4f, 6.9f, 3.2f, u)
            dot(c, 18.2f, 15.4f, 3.2f, u)
        }
        BenefitKind.LEARN -> {
            val body = Path().apply {
                moveTo(5.6f * u, 11.9f * u)
                lineTo(5.6f * u, 16.2f * u)
                cubicTo(5.6f * u, 18f * u, 8.4f * u, 19.6f * u, 12f * u, 19.6f * u)
                cubicTo(15.6f * u, 19.6f * u, 18.4f * u, 18f * u, 18.4f * u, 16.2f * u)
                lineTo(18.4f * u, 11.9f * u)
                lineTo(12f * u, 15f * u)
                close()
            }
            drawPath(body, c)
            val cap = poly(u, 12f, 3.2f, 22.8f, 8.8f, 12f, 14.4f, 1.2f, 8.8f)
            drawPath(cap, c)
            drawPath(cap, cut, style = Stroke(width = 1.1f * u, join = StrokeJoin.Round))
            drawLine(c, Offset(21.2f * u, 9.8f * u), Offset(21.2f * u, 15.6f * u), strokeWidth = 1.5f * u, cap = StrokeCap.Round)
            dot(c, 21.2f, 16.6f, 1.4f, u)
        }
        BenefitKind.COACH -> {
            rr(c, 7.4f, 10.5f, 9.2f, 3f, 1.2f, u)
            rr(c, 4.6f, 5.6f, 3.4f, 12.8f, 1.7f, u)
            rr(c, 16f, 5.6f, 3.4f, 12.8f, 1.7f, u)
            rr(c, 1.2f, 8.2f, 2.6f, 7.6f, 1.3f, u)
            rr(c, 20.2f, 8.2f, 2.6f, 7.6f, 1.3f, u)
        }
        BenefitKind.BOT -> {
            drawLine(c, Offset(12f * u, 7.2f * u), Offset(12f * u, 4f * u), strokeWidth = 1.6f * u, cap = StrokeCap.Round)
            dot(c, 12f, 3.2f, 1.9f, u)
            rr(c, 3.2f, 7f, 17.6f, 13.6f, 5.2f, u)
            rr(c, 0.8f, 11.4f, 2f, 5.4f, 1f, u)
            rr(c, 21.2f, 11.4f, 2f, 5.4f, 1f, u)
            dot(cut, 8.4f, 13.8f, 2.2f, u)
            dot(cut, 15.6f, 13.8f, 2.2f, u)
        }
        BenefitKind.NOADS -> {
            drawCircle(c, radius = 8.6f * u, center = Offset(12f * u, 12f * u), style = Stroke(width = 3.2f * u))
            drawLine(c, Offset(6.2f * u, 17.8f * u), Offset(17.8f * u, 6.2f * u), strokeWidth = 3.2f * u, cap = StrokeCap.Round)
        }
        BenefitKind.FAMILY -> {
            val back = c.copy(alpha = c.alpha * 0.82f)
            dot(back, 17.2f, 7.4f, 3f, u)
            val bb = Path().apply {
                moveTo(16.8f * u, 12.8f * u)
                cubicTo(20.2f * u, 12.8f * u, 22.6f * u, 15.2f * u, 22.6f * u, 19.8f * u)
                lineTo(17.8f * u, 19.8f * u)
                cubicTo(17.6f * u, 17.2f * u, 16.6f * u, 15.2f * u, 14.8f * u, 14f * u)
                cubicTo(15.4f * u, 13.3f * u, 16.1f * u, 12.8f * u, 16.8f * u, 12.8f * u)
                close()
            }
            drawPath(bb, back)
            dot(c, 9.6f, 8f, 3.6f, u)
            val fb = Path().apply {
                moveTo(1.8f * u, 21.6f * u)
                cubicTo(1.8f * u, 16.8f * u, 5.2f * u, 13.6f * u, 9.6f * u, 13.6f * u)
                cubicTo(14f * u, 13.6f * u, 17.4f * u, 16.8f * u, 17.4f * u, 21.6f * u)
                close()
            }
            drawPath(fb, c)
        }
        BenefitKind.INVITE -> {
            rr(c, 2.2f, 4.8f, 19.6f, 14.8f, 3f, u)
            val flap = Path().apply {
                moveTo(4.4f * u, 8f * u)
                lineTo(12f * u, 13.8f * u)
                lineTo(19.6f * u, 8f * u)
            }
            drawPath(flap, cut, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        BenefitKind.DUEL -> {
            dot(c, 7.8f, 6.4f, 3.2f, u)
            dot(c, 16.2f, 6.4f, 3.2f, u)
            val l = Path().apply {
                moveTo(1.8f * u, 19.8f * u)
                cubicTo(1.8f * u, 15.2f * u, 4.6f * u, 12.4f * u, 7.8f * u, 12.4f * u)
                cubicTo(11f * u, 12.4f * u, 13.6f * u, 15.2f * u, 13.6f * u, 19.8f * u)
                close()
            }
            val r = Path().apply {
                moveTo(10.4f * u, 19.8f * u)
                cubicTo(10.4f * u, 15.2f * u, 13f * u, 12.4f * u, 16.2f * u, 12.4f * u)
                cubicTo(19.4f * u, 12.4f * u, 22.2f * u, 15.2f * u, 22.2f * u, 19.8f * u)
                close()
            }
            drawPath(l, c)
            drawPath(r, c)
            rr(cut, 8.6f, 17.4f, 6.8f, 3.4f, 0.9f, u)
        }
        BenefitKind.TROPHY -> {
            val cup = Path().apply {
                moveTo(6.6f * u, 2.6f * u)
                lineTo(17.4f * u, 2.6f * u)
                lineTo(17.4f * u, 9.6f * u)
                cubicTo(17.4f * u, 12.6f * u, 15f * u, 14.6f * u, 12f * u, 14.6f * u)
                cubicTo(9f * u, 14.6f * u, 6.6f * u, 12.6f * u, 6.6f * u, 9.6f * u)
                close()
            }
            drawPath(cup, c)
            val hl = Path().apply {
                moveTo(6.8f * u, 5f * u)
                cubicTo(2.6f * u, 4.4f * u, 2f * u, 10.2f * u, 7.4f * u, 11f * u)
            }
            val hr = Path().apply {
                moveTo(17.2f * u, 5f * u)
                cubicTo(21.4f * u, 4.4f * u, 22f * u, 10.2f * u, 16.6f * u, 11f * u)
            }
            drawPath(hl, c, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round))
            drawPath(hr, c, style = Stroke(width = 1.9f * u, cap = StrokeCap.Round))
            rr(c, 10.7f, 14.2f, 2.6f, 4f, 0.6f, u)
            rr(c, 6.6f, 18.2f, 10.8f, 3.4f, 1.4f, u)
        }
        BenefitKind.NEWGAME -> {
            rr(c, 2.4f, 2.4f, 8.2f, 8.2f, 1.4f, u)
            rr(c, 13.4f, 2.4f, 8.2f, 8.2f, 1.4f, u)
            rr(c, 2.4f, 13.4f, 8.2f, 8.2f, 1.4f, u)
            drawLine(c, Offset(13.8f * u, 17.5f * u), Offset(21.4f * u, 17.5f * u), strokeWidth = 2.8f * u, cap = StrokeCap.Round)
            drawLine(c, Offset(17.6f * u, 13.7f * u), Offset(17.6f * u, 21.3f * u), strokeWidth = 2.8f * u, cap = StrokeCap.Round)
        }
        BenefitKind.MAGIC -> {
            // đũa phép + tia sáng 4 cánh + vài đốm nhỏ
            drawLine(c, Offset(4.6f * u, 20f * u), Offset(14.6f * u, 10f * u), strokeWidth = 3.4f * u, cap = StrokeCap.Round)
            val spark = Path().apply {
                moveTo(17.6f * u, 1.4f * u)
                quadraticBezierTo(18.3f * u, 5.8f * u, 22.8f * u, 6.6f * u)
                quadraticBezierTo(18.3f * u, 7.4f * u, 17.6f * u, 11.8f * u)
                quadraticBezierTo(16.9f * u, 7.4f * u, 12.4f * u, 6.6f * u)
                quadraticBezierTo(16.9f * u, 5.8f * u, 17.6f * u, 1.4f * u)
                close()
            }
            drawPath(spark, c)
            dot(c, 5.6f, 6f, 1.5f, u)
            dot(c, 19.8f, 17f, 1.7f, u)
            dot(c, 9.6f, 3.2f, 1f, u)
        }
        BenefitKind.TITLE -> {
            // huy chương: 2 dải ruy băng + đồng xu có ngôi sao khoét
            drawPath(poly(u, 5.6f, 1.6f, 10.6f, 1.6f, 12.8f, 9.4f, 7.6f, 10.8f), c)
            drawPath(poly(u, 18.4f, 1.6f, 13.4f, 1.6f, 11.2f, 9.4f, 16.4f, 10.8f), c)
            dot(c, 12f, 15.2f, 6.8f, u)
            val star = Path()
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) 3.9f else 1.7f
                val a = (-90f + i * 36f) * PI.toFloat() / 180f
                val x = (12f + cos(a) * r) * u
                val y = (15.5f + sin(a) * r) * u
                if (i == 0) star.moveTo(x, y) else star.lineTo(x, y)
            }
            star.close()
            drawPath(star, cut)
        }
    }
}

/** Viên ngọc nhỏ theo màu gói (dùng cho thanh tab Gold / Platinum / Diamond / Family). */
@Composable
fun TierGem(base: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val light = lerp(base, Color.White, 0.5f)
        val dark = lerp(base, Color.Black, 0.28f)
        val mid = lerp(base, Color.White, 0.12f)
        drawPath(poly(u, 6f, 3f, 18f, 3f, 23f, 9f, 1f, 9f), light)
        drawPath(poly(u, 1f, 9f, 12f, 9f, 12f, 22f), dark)
        drawPath(poly(u, 12f, 9f, 23f, 9f, 12f, 22f), mid)
        drawPath(poly(u, 6f, 3f, 9f, 9f, 12f, 3f), Color(0x66FFFFFF))
    }
}

/** Dấu tích tròn nhỏ ở cuối mỗi dòng quyền lợi. */
@Composable
fun CheckMark(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val p = Path().apply {
            moveTo(4.6f * u, 12.8f * u)
            lineTo(9.8f * u, 18f * u)
            lineTo(19.4f * u, 6.6f * u)
        }
        drawPath(p, color, style = Stroke(width = 3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
