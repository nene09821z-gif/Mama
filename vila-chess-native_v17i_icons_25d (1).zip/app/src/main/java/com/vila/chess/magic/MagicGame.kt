package com.vila.chess.magic

import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.KING
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.EMPTY
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.moveTo
import com.vila.chess.core.pieceType
import com.vila.chess.core.sqRank

sealed interface MagicResult {
    data class Win(val white: Boolean, val reason: String) : MagicResult
    data class Draw(val reason: String) : MagicResult
}

fun sideName(white: Boolean) = if (white) "Trắng" else "Đen"

/**
 * Luật Cờ Phép Thuật (2 người cùng máy). Mỗi lượt: +2 mana, rút 1 bài, dùng tối đa 1 bài (trừ bài Thần Tốc) rồi đi 1 nước cờ thường.
 * Thắng/hoà theo luật cờ vua thường (chiếu hết, bí, thiếu quân, 50 nước). Phép thuật không được để Vua mình bị chiếu.
 */
class MagicGame(seed: Long = System.nanoTime(), val tier: MembershipTier = MembershipTier.FREE) {
    var s: MagicState = MagicState(Position.start(), MagicRandom(seed), tier)
        private set
    var result: MagicResult? = null
        private set
    var notice: String? = null
        private set
    private var passes = 0

    /** Lá bài vừa dùng + các ô bị ảnh hưởng + số thứ tự lần dùng: giao diện dùng để vẽ hiệu ứng (cả ván cùng máy lẫn ván online). */
    var lastCastId: Int = -1
        private set
    var lastCastFx: List<Int> = emptyList()
        private set
    var castSeq: Int = 0
        private set

    val whiteToMove: Boolean get() = s.pos.whiteToMove

    init {
        s.mana[0] = MagicState.MANA_START; s.mana[1] = MagicState.MANA_START
        s.draw(true, 3); s.draw(false, 3)
        startTurn(s)
    }

    private fun startTurn(st: MagicState) {
        val white = st.pos.whiteToMove
        val i = idx(white)
        st.mana[i] = minOf(MagicState.MANA_MAX, st.mana[i] + MagicState.MANA_PER_TURN + st.bonusMana[i])
        st.bonusMana[i] = 0
        // Đầu lượt: mở 3 lá bài ngẫu nhiên, người chơi chọn 1 (thay cho rút 1 lá mù).
        st.offers[0].clear(); st.offers[1].clear()
        st.makeOffer(white)
        MagicUse.refineOffers(st, white)
        st.spellUsed = false
        st.recycled = false
        st.extraPending = -1
        st.extraNext = -1
    }

    /** [flip] = false khi Position.make đã đổi lượt rồi. */
    private fun endTurn(st: MagicState, flip: Boolean) {
        st.turnNo++
        if (flip) st.pos.whiteToMove = !st.pos.whiteToMove
        st.traps.entries.removeAll { it.value.expires <= st.turnNo }
        startTurn(st)
    }

    // ------------------------------------------------------------------ 3 lá bài đầu lượt

    /** 3 lá đang được mở cho bên đang đi (rỗng nếu đã chọn/bỏ qua hoặc tay bài đầy). */
    fun offers(): List<Int> = s.offers[idx(s.pos.whiteToMove)]

    /** Chọn lá thứ [index] trong 3 lá mở ra đưa vào tay. Trả null nếu thành công, ngược lại là lý do. */
    fun takeOffer(index: Int): String? {
        if (result != null) return "Ván đã kết thúc"
        val white = s.pos.whiteToMove
        val i = idx(white)
        val offer = s.offers[i]
        if (index !in offer.indices) return "Không có lá bài này"
        if (s.hands[i].size >= MagicState.HAND_MAX) return "Tay bài đã đầy"
        val card = MagicCatalog.get(offer[index])
        s.hands[i].add(card.id)
        offer.clear()
        notice = "${sideName(white)} nhận «${card.name}»"
        return null
    }

    /** Không lấy lá nào: đổi lại +[MagicState.MANA_SWAP] mana (tối đa [MagicState.MANA_MAX]). */
    fun skipOffer(): String? {
        if (result != null) return "Ván đã kết thúc"
        val white = s.pos.whiteToMove
        val i = idx(white)
        if (s.offers[i].isEmpty()) return "Không có lá bài nào để bỏ qua"
        s.offers[i].clear()
        s.mana[i] = minOf(MagicState.MANA_MAX, s.mana[i] + MagicState.MANA_SWAP)
        notice = "${sideName(white)} bỏ qua và nhận ${MagicState.MANA_SWAP} mana"
        return null
    }

    // ------------------------------------------------------------------ Nước đi

    fun allowedMoves(st: MagicState = s): IntArray {
        val white = st.pos.whiteToMove
        return st.pos.legalMoves().filter { m ->
            val from = moveFrom(m)
            val to = moveTo(m)
            val capSq = if (moveFlag(m) == FLAG_EP) (if (white) to - 8 else to + 8) else to
            val victim = st.pos.board[capSq]
            !st.isFrozen(from) &&
                (st.extraPending <= 0 || pieceType(st.pos.board[from]) == st.extraPending) &&
                !(victim != EMPTY && (st.isShielded(capSq) || pieceType(victim) == KING))
        }.toIntArray()
    }

    /** Các nước (kể cả các biến thể phong cấp) đi từ [from]. */
    fun movesFrom(from: Int): List<Int> = allowedMoves().filter { moveFrom(it) == from }

    fun playMove(m: Int): Boolean {
        if (result != null || m !in allowedMoves()) return false
        notice = null
        val st = s
        val white = st.pos.whiteToMove
        val from = moveFrom(m)
        val to = moveTo(m)
        val capSq = if (moveFlag(m) == FLAG_EP) (if (white) to - 8 else to + 8) else to
        val victim = st.pos.board[capSq]
        val wasExtra = st.extraPending >= 0
        st.pos.make(m)
        val sh = st.shield.remove(from)
        if (victim != EMPTY) { st.lost[idx(!white)].add(pieceType(victim)); st.shield.remove(capSq); st.frozen.remove(capSq) }
        if (sh != null) st.shield[to] = sh
        val trap = st.trapAt(to)
        if (trap != null && trap.ownerWhite != white) {
            st.traps.remove(to)
            if (!st.isKing(to)) { st.removePiece(to); notice = "Quân của ${sideName(white)} sập bẫy!" }
        }
        passes = 0
        val extra = st.extraNext
        st.extraNext = -1
        if (!wasExtra && extra >= 0 && !st.pos.inCheck(!white)) {
            st.pos.whiteToMove = white
            st.pos.epSquare = -1
            st.extraPending = extra
            if (allowedMoves(st).isNotEmpty()) { notice = "${sideName(white)} được đi thêm 1 nước"; updateResult(); return true }
            st.extraPending = -1
            st.pos.whiteToMove = !white
        }
        endTurn(st, flip = false)
        updateResult()
        return true
    }

    private fun updateResult() {
        if (result != null) return
        val st = s
        val white = st.pos.whiteToMove
        if (st.pos.insufficientMaterial()) { result = MagicResult.Draw("Không đủ quân để chiếu hết"); return }
        if (st.pos.halfmove >= 100) { result = MagicResult.Draw("Luật 50 nước"); return }
        if (st.pos.legalMoves().isEmpty()) {
            result = if (st.pos.inCheck(white)) MagicResult.Win(!white, "Chiếu hết") else MagicResult.Draw("Hết nước đi (bí)")
            return
        }
        if (allowedMoves(st).isEmpty()) {
            if (st.pos.inCheck(white)) { result = MagicResult.Win(!white, "Chiếu bí (quân bị đóng băng/khiên chắn)"); return }
            if (++passes >= 4) { result = MagicResult.Draw("Hai bên đều không thể đi"); return }
            notice = "${sideName(white)} không có nước đi hợp lệ — bỏ lượt"
            endTurn(st, flip = true)
            updateResult()
        }
    }

    fun resign(white: Boolean) {
        if (result == null) result = MagicResult.Win(!white, "Đối thủ đầu hàng")
    }

    // ------------------------------------------------------------------ Phép thuật

    fun card(handIndex: Int): MagicCard? =
        s.hands[idx(s.pos.whiteToMove)].getOrNull(handIndex)?.let { MagicCatalog.get(it) }

    fun costOf(card: MagicCard, st: MagicState = s): Int {
        val white = st.pos.whiteToMove
        var c = card.baseCost
        if (card.modifier == Modifier.UNDERDOG && st.material(white) < st.material(!white)) c--
        if (card.modifier == Modifier.FRUGAL && st.hands[idx(white)].size >= 4) c--
        return maxOf(0, c)
    }

    private fun validPosition(st: MagicState, casterWhite: Boolean): Boolean {
        var wk = 0
        var bk = 0
        for (sq in 0 until 64) {
            val p = st.pos.board[sq]
            if (p == EMPTY) continue
            val t = pieceType(p)
            if (t == KING) { if (p <= 6) wk++ else bk++ }
            if (t == PAWN && (sqRank(sq) == 0 || sqRank(sq) == 7)) return false
        }
        return wk == 1 && bk == 1 && !st.pos.inCheck(casterWhite)
    }

    private fun trial(card: MagicCard, targets: List<Int>): Boolean {
        if (targets.size != card.effect.picks.size) return false
        val white = s.pos.whiteToMove
        val t = s.copy()
        // Lá đang dùng rời tay trước khi phép chạy (để bài "rút thêm" vẫn dùng được khi tay đã đầy 7 lá).
        val hand = t.hands[idx(white)]
        val at = hand.indexOf(card.id)
        if (at >= 0) hand.removeAt(at)
        return card.effect.apply(t, white, targets) && validPosition(t, white)
    }

    /** Số lần chạm mục tiêu cần cho lá bài này. */
    fun stepsOf(card: MagicCard) = card.effect.picks.size

    /** Ô hợp lệ cho bước tiếp theo của lá bài [card], khi đã chọn [chosen]. */
    fun spellTargets(card: MagicCard, chosen: List<Int>): List<Int> {
        val white = s.pos.whiteToMove
        val step = chosen.size
        val picks = card.effect.picks
        if (step >= picks.size) return emptyList()
        val cands = card.effect.candidates(s, white, step, chosen)
        if (step < picks.size - 2) return cands
        if (step == picks.size - 2) {
            return cands.filter { c -> card.effect.candidates(s, white, step + 1, chosen + c).any { trial(card, chosen + c + it) } }
        }
        return cands.filter { trial(card, chosen + it) }
    }

    /** Lý do không dùng được (null = dùng được về mặt mana/lượt). */
    fun castBlocker(card: MagicCard): String? {
        val i = idx(s.pos.whiteToMove)
        return when {
            result != null -> "Ván đã kết thúc"
            s.turnNo < s.lockedUntil[i] -> "Bạn đang bị phong ấn"
            s.spellUsed -> "Mỗi lượt chỉ dùng 1 bài"
            s.extraPending >= 0 -> "Đang đi nước thêm"
            s.mana[i] < costOf(card) -> "Không đủ mana"
            else -> null
        }
    }

    /**
     * Trạng thái dùng được của lá [card] ở lượt này, kèm lý do bằng tiếng Việt khi chưa dùng được
     * (hết mana, bị phong ấn, chưa có mục tiêu trên bàn cờ, Vua đang bị chiếu…).
     */
    fun usability(card: MagicCard): CardUse {
        val white = s.pos.whiteToMove
        val i = idx(white)
        val cost = costOf(card)
        return when {
            result != null -> CardUse(UseState.ENDED, "Ván đã kết thúc")
            s.turnNo < s.lockedUntil[i] -> CardUse(UseState.LOCKED, "Bạn đang bị phong ấn")
            s.spellUsed -> CardUse(UseState.USED, "Mỗi lượt chỉ dùng 1 bài")
            s.extraPending >= 0 -> CardUse(UseState.EXTRA, "Đang đi nước thêm")
            s.mana[i] < cost -> CardUse(UseState.NO_MANA, "Cần $cost mana (đang có ${s.mana[i]})")
            !MagicUse.feasible(s, white, card) -> CardUse(UseState.NO_TARGET, MagicUse.whyNot(s, white, card))
            else -> CardUse(UseState.READY, "Dùng được")
        }
    }

    /** Dùng cho 3 lá mở đầu lượt: lá này có mục tiêu hợp lệ trên bàn cờ lúc này không (bỏ qua mana). */
    fun offerUse(card: MagicCard): CardUse {
        val white = s.pos.whiteToMove
        return if (MagicUse.feasible(s, white, card)) CardUse(UseState.READY, "Dùng được")
        else CardUse(UseState.NO_TARGET, MagicUse.whyNot(s, white, card))
    }

    /**
     * Tái chế lá thứ [handIndex] trên tay: bỏ lá đó, nhận +[MagicState.MANA_SWAP] mana (tối đa [MagicState.MANA_MAX]). Không tốn lượt dùng bài,
     * không giới hạn số lá mỗi lượt — để không lá nào thành "bài chết" khi chưa có mục tiêu. Trả null nếu thành công, ngược lại là lý do.
     */
    fun recycle(handIndex: Int): String? {
        if (result != null) return "Ván đã kết thúc"
        val white = s.pos.whiteToMove
        val i = idx(white)
        if (s.extraPending >= 0) return "Đang đi nước thêm"
        val id = s.hands[i].getOrNull(handIndex) ?: return "Không có lá bài này"
        val card = MagicCatalog.get(id)
        s.hands[i].removeAt(handIndex)
        s.mana[i] = minOf(MagicState.MANA_MAX, s.mana[i] + MagicState.MANA_SWAP)
        s.recycled = true
        notice = "${sideName(white)} tái chế «${card.name}» và nhận ${MagicState.MANA_SWAP} mana"
        return null
    }

    /** Hết giờ: bên [whiteLost] thua. Không làm gì nếu ván đã có kết quả. */
    fun flag(whiteLost: Boolean) {
        if (result == null) result = MagicResult.Win(!whiteLost, "Hết giờ")
    }

    /** Dùng bài ở vị trí [handIndex] với các mục tiêu [targets]. Trả null nếu thành công, ngược lại là lý do. */
    fun castSpell(handIndex: Int, targets: List<Int>): String? {
        val card = card(handIndex) ?: return "Không có lá bài này"
        castBlocker(card)?.let { return it }
        if (targets.size != card.effect.picks.size) return "Chưa chọn đủ mục tiêu"
        val white = s.pos.whiteToMove
        val i = idx(white)
        val cost = costOf(card)
        val t = s.copy()
        t.hands[i].removeAt(handIndex)
        if (!card.effect.apply(t, white, targets)) return "Không thể dùng lá bài này ở đây"
        if (!validPosition(t, white)) return "Phép này làm thế cờ không hợp lệ (Vua bị chiếu, Tốt ở hàng cuối…)"
        t.mana[i] -= cost
        applyModifier(card.modifier, t, white)
        if (!card.modifier.free) t.spellUsed = true
        t.sanitize()
        t.pos.halfmove = 0
        val fx = LinkedHashSet<Int>(targets)
        for (sq in 0 until 64) if (s.pos.board[sq] != t.pos.board[sq]) fx.add(sq)
        lastCastId = card.id; lastCastFx = fx.toList(); castSeq++
        s = t
        notice = "${sideName(white)} dùng «${card.name}»" + (t.log?.let { " — $it" } ?: "")
        passes = 0
        updateResult()
        return null
    }

    private fun applyModifier(m: Modifier, t: MagicState, white: Boolean) {
        val opp = idx(!white)
        when (m) {
            Modifier.ECHO -> t.draw(white, 1)
            Modifier.GREED -> t.draw(white, 2)
            Modifier.HEX -> t.mana[opp] = maxOf(0, t.mana[opp] - 1)
            Modifier.BURN -> t.mana[opp] = maxOf(0, t.mana[opp] - 2)
            Modifier.LOCK -> t.lockedUntil[opp] = maxOf(t.lockedUntil[opp], t.turnNo + 2)
            Modifier.FOCUS -> t.bonusMana[idx(white)] += 1
            Modifier.PURGE -> {
                t.shield.keys.filter { t.enemy(it, white) }.forEach { t.shield.remove(it) }
                t.traps.entries.removeAll { it.value.ownerWhite != white }
            }
            Modifier.BLESS -> t.frozen.keys.filter { t.own(it, white) }.forEach { t.frozen.remove(it) }
            else -> {}
        }
    }
}
