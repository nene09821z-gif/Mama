package com.vila.chess.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// All icons are drawn on a 24 x 24 unit grid and scaled to whatever size the caller gives them.

private fun Path.m(u: Float, x: Float, y: Float) = moveTo(x * u, y * u)
private fun Path.l(u: Float, x: Float, y: Float) = lineTo(x * u, y * u)
private fun Path.c(u: Float, a: Float, b: Float, c: Float, d: Float, e: Float, f: Float) =
    cubicTo(a * u, b * u, c * u, d * u, e * u, f * u)

private fun poly(u: Float, vararg p: Float): Path {
    val path = Path()
    path.moveTo(p[0] * u, p[1] * u)
    var i = 2
    while (i < p.size) {
        path.lineTo(p[i] * u, p[i + 1] * u)
        i += 2
    }
    path.close()
    return path
}

// =============================================================================
// Icon 2.5D (đế dày + mặt gradient + ánh kính + bóng tiếp đất). Dụng cụ vẽ nằm ở Kit25D.kt, lưới 48 x 48.
// Hình được dựng một lần ở top-level để không parse lại path mỗi khung hình.
// =============================================================================

// ---- Ngọn lửa (chuỗi ngày chơi)
private val flameOuter = svgItm("M24 2.5C26 11 38.5 17 38.5 30C38.5 39 32 45 24 45C16 45 9.5 39 9.5 30C9.5 25 12 21 14.8 18.2C15.6 22 17.4 24.4 19.6 25.4C19 17 21 9 24 2.5Z")
private val flameInner = svgItm("M24 23C27.4 27.4 31.5 30.6 31.5 36C31.5 40.4 28.2 43 24 43C19.8 43 16.5 40.4 16.5 36C16.5 31.4 21.4 29.4 24 23Z")

/** Ngọn lửa cam, lõi vàng. */
@Composable
fun FlameIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.2f, 12f, 2f)
            ext(hx(0xB5300F), 3.2f, flameOuter)
            face(flameOuter, hx(0xFFC93A), hx(0xF2491A), 2f, 45f, shine = 0.30f)
            face(flameInner, hx(0xFFF6B8), hx(0xFFC22E), 23f, 43f, shine = 0.2f, shade = 0.05f, rim = 0.8f)
        }
    }
}

// ---- Kim cương
private val gemAll = svgItm("M12 6H36L45.5 18.5L24 44L2.5 18.5Z", 1.2f)
private val gemFacets = listOf(
    Triple(svgItm("M2.5 18.5L12 6L17 18.5Z"), hx(0x7FDCFF), hx(0x3AA9F2)),
    Triple(svgItm("M12 6H24L17 18.5Z"), hx(0xD8F6FF), hx(0x8BE3FF)),
    Triple(svgItm("M24 6H36L31 18.5Z"), hx(0xB6EEFF), hx(0x5CC4F8)),
    Triple(svgItm("M36 6L45.5 18.5H31Z"), hx(0x5CC0F5), hx(0x2A94E8)),
)
private val gemLower = listOf(
    Triple(svgItm("M17 18.5H31L24 44Z"), hx(0x53B9F7), hx(0x1768C9)),
    Triple(svgItm("M2.5 18.5H17L24 44Z"), hx(0x3FA6EE), hx(0x1456B8)),
    Triple(svgItm("M31 18.5H45.5L24 44Z"), hx(0x2C8EE6), hx(0x0F4FB0)),
)
private val gemLines = svgItm("M2.5 18.5H45.5M12 6L17 18.5L24 6L31 18.5L36 6M17 18.5L24 44L31 18.5")
// Tia lấp lánh 4 cánh (đơn vị: bán kính 1, tâm gốc toạ độ) — scale/translate khi vẽ
private val gemSparkUnit = svgItm("M0 -1L0.24 -0.24L1 0L0.24 0.24L0 1L-0.24 0.24L-1 0L-0.24 -0.24Z")
// Dải sáng chéo quét ngang viên ngọc (hai lớp: quầng rộng mờ + lõi hẹp sáng)
private val gemSweepWide = svgItm("M0 0L13 0L1 50L-12 50Z")
private val gemSweepCore = svgItm("M4 0L8 0L-4 50L-8 50Z")

private fun bump(p: Float, center: Float, half: Float): Float =
    (1f - kotlin.math.abs(p - center) / half).coerceIn(0f, 1f)

/**
 * Viên kim cương xanh nhiều mặt cắt, CÓ ĐỘNG (chu kỳ 3,4 giây):
 *  - lơ lửng nhẹ lên xuống, bóng dưới chân co/giãn theo độ cao
 *  - dải sáng chéo quét qua viên ngọc rồi nghỉ một nhịp
 *  - ba tia lấp lánh bật lần lượt theo nhịp dải sáng đi qua
 * Giá trị hoạt hoạ chỉ đọc ở pha vẽ nên không làm recomposition mỗi khung hình.
 * [animated] = false: vẽ tĩnh (dùng khi cần icon đứng yên).
 */
@Composable
fun DiamondIcon(modifier: Modifier = Modifier, animated: Boolean = true) {
    val phase: State<Float> = if (animated) {
        rememberInfiniteTransition(label = "gem").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(3400, easing = LinearEasing), RepeatMode.Restart),
            label = "gemPhase",
        )
    } else {
        remember { mutableStateOf(0.45f) }
    }
    Canvas(modifier) {
        icon48 {
            val p = phase.value
            val bob = if (animated) sin(p * 2f * PI.toFloat()) * 1.2f else 0f
            // bóng nhỏ lại khi viên ngọc bay cao (bob âm = lên cao)
            shadowOval(24f, 46f, 14f + bob * 0.9f, 2f, 0.35f + bob * 0.05f)
            translate(0f, bob) {
                ext(hx(0x0B5FA8), 3.2f, gemAll)
                face(gemAll, hx(0x8BE3FF), hx(0x1C86E6), 6f, 44f, shine = 0.15f)
                for ((q, a, b) in gemFacets) face(q, a, b, 6f, 18.5f, shine = 0f, shade = 0f, rim = 0f)
                for ((q, a, b) in gemLower) face(q, a, b, 18.5f, 44f, shine = 0f, shade = 0f, rim = 0f)
                drawPath(gemLines.p, Color.White.copy(alpha = 0.55f), style = Stroke(width = 0.9f, join = StrokeJoin.Round))
                drawPath(gemAll.p, Color.White.copy(alpha = 0.7f), style = Stroke(width = 1.3f, join = StrokeJoin.Round))

                // dải sáng quét: chỉ trong 38% đầu chu kỳ, cắt theo hình viên ngọc
                if (animated && p < 0.38f) {
                    val x = -14f + (p / 0.38f) * 74f
                    clipPath(gemAll.p) {
                        translate(x, 0f) {
                            drawPath(gemSweepWide.p, Color.White.copy(alpha = 0.22f))
                            drawPath(gemSweepCore.p, Color.White.copy(alpha = 0.6f))
                        }
                    }
                }
            }
            // tia lấp lánh (vẽ sau cùng, cùng độ lơ lửng với viên ngọc)
            translate(0f, bob) {
                val idle = if (animated) 0f else 1f
                val s1 = if (animated) 0.12f + 0.88f * bump(p, 0.40f, 0.16f) else 0.9f
                val s2 = if (animated) 0.88f * bump(p, 0.62f, 0.14f) else 0f
                val s3 = if (animated) 0.88f * bump(p, 0.80f, 0.14f) else 0f
                drawSpark(37f, 12f, 6.8f * s1, 0.95f * (if (animated) minOf(1f, s1 * 1.4f) else idle))
                drawSpark(11f, 24f, 4.6f * s2, 0.9f * minOf(1f, s2 * 1.4f))
                drawSpark(31f, 36f, 3.8f * s3, 0.9f * minOf(1f, s3 * 1.4f))
            }
        }
    }
}

private fun DrawScope.drawSpark(cx: Float, cy: Float, r: Float, alpha: Float) {
    if (r <= 0.05f || alpha <= 0.01f) return
    withTransform({
        translate(cx, cy)
        scale(r, r, Offset.Zero)
    }) {
        drawPath(gemSparkUnit.p, Color.White.copy(alpha = alpha))
    }
}

// ---- Hai người (bạn bè). t = 1: đủ màu; t < 1: dịu dần (thanh điều hướng)
private val frBack = svgItm("M31 27C33 26 35 26 37 26C42.5 26 45.5 31 45.5 37.5C45.5 39 44.5 40 43 40H34C34 35 32.5 30.5 30 27Z", 1f)
private val frBackHead = circItm(34f, 14f, 6.3f)
private val frFront = svgItm("M3 41C3 31.5 9.5 26 18 26C26.5 26 33 31.5 33 41C33 42 32.2 42.8 31.2 42.8H4.8C3.8 42.8 3 42 3 41Z", 1f)
private val frFrontHead = circItm(18f, 15f, 7.6f)

private fun DrawScope.drawFriends(t: Float) {
    val f0 = tone(0xFFFFFF, t)
    val f1 = tone(0xBFD0EA, t)
    val g0 = tone(0xB8EC7C, t)
    val g1 = tone(0x4F9B26, t)
    shadowOval(24f, 46.3f, 17f, 1.8f)
    ext(tone(0x2F6B1A, t), 3f, frBack, frBackHead)
    face(frBack, g0, g1, 26f, 40f, shine = 0.3f)
    sphere(34f, 14f, 6.3f, g0, g0, g1)
    ext(tone(0x6C7FA3, t), 3f, frFront, frFrontHead)
    face(frFront, f0, f1, 26f, 43f, shine = 0.3f)
    sphere(18f, 15f, 7.6f, f0, f0, f1)
}

/** Hai người: bạn trước màu trắng, bạn sau màu xanh lá. */
@Composable
fun FriendsIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) { icon48 { drawFriends(1f) } }
}

// ---- Chuông vàng
private val bellBody = svgItm("M24 4.5C16.5 4.5 12 10.5 12 18.5V27L6.5 34.5C6 35.2 6.5 36 7.3 36H40.7C41.5 36 42 35.2 41.5 34.5L36 27V18.5C36 10.5 31.5 4.5 24 4.5Z", 1f)

/** Chuông thông báo vàng. */
@Composable
fun BellIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.3f, 11f, 1.8f)
            ext(hx(0xA55A00), 3f, bellBody)
            sphere(24f, 40.3f, 4.4f, hx(0xFFE27A), hx(0xF4A100), hx(0xB86A00))
            face(bellBody, hx(0xFFE680), hx(0xF29A00), 4.5f, 36f, shine = 0.34f)
            clipPath(bellBody.p) {
                drawRoundRect(Color.White.copy(alpha = 0.38f), Offset(15.4f, 10f), Size(3.2f, 15f), CornerRadius(1.6f, 1.6f))
                drawRect(Color(0x33783C00), Offset(6f, 31.2f), Size(36f, 1.2f))
            }
            sphere(24f, 4.6f, 2.8f, hx(0xFFF0A0), hx(0xF7B01A), hx(0xC97800))
        }
    }
}

// ---- Viên đạn vàng (Siêu chớp), nghiêng 45 độ
private val buTip = svgItm("M24 2C30.5 7 32.5 14 32.5 22H15.5C15.5 14 17.5 7 24 2Z", 1f)
private val buCase = svgItm("M15.5 22H32.5V38H15.5Z")
private val buRim = rrItm(13f, 38f, 22f, 5f, 2f)

/** Viên đạn vàng, thân trụ có cảm giác tròn (gradient ngang). */
@Composable
fun BulletIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val pivot = Offset(24f, 24f)
            shadowOval(24f, 46.5f, 13f, 1.8f, 0.3f)
            val side = hx(0x8A4A00)
            // đế dày theo trục màn hình: dịch xuống rồi mới xoay
            for (i in 1..6) {
                translate(0f, 3f * i / 6f) {
                    rotate(45f, pivot) {
                        fillItm(buTip, side)
                        fillItm(buCase, side)
                        fillItm(buRim, side)
                    }
                }
            }
            rotate(45f, pivot) {
                fillItm(buTip, Brush.horizontalGradient(0f to hx(0xFFE9A6), 0.35f to hx(0xFFC53A), 1f to hx(0xD98400), startX = 15.5f, endX = 32.5f))
                fillItm(buCase, Brush.horizontalGradient(0f to hx(0xFFD8A0), 0.3f to hx(0xF2995A), 1f to hx(0xB4561F), startX = 15.5f, endX = 32.5f))
                fillItm(buRim, Brush.horizontalGradient(0f to hx(0xFFEBB0), 0.4f to hx(0xE9B04A), 1f to hx(0xA56A14), startX = 13f, endX = 35f))
                drawRect(Color(0x40000000), Offset(15.5f, 21.4f), Size(17f, 1.4f))
                drawRoundRect(Color.White.copy(alpha = 0.55f), Offset(18.2f, 9f), Size(2.6f, 12f), CornerRadius(1.3f, 1.3f))
                drawRoundRect(Color.White.copy(alpha = 0.55f), Offset(18.2f, 25f), Size(2.6f, 11f), CornerRadius(1.3f, 1.3f))
            }
        }
    }
}

// ---- Tia chớp vàng (Chớp)
private val boltBody = svgItm("M28.5 2L8.5 27H21L16 46L39.5 18.5H26.5Z", 1.6f)
private val boltShine = svgItm("M26 6L14 23H20L24.5 8Z")

/** Tia chớp vàng. */
@Composable
fun BoltIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.3f, 11f, 1.8f)
            ext(hx(0xB26A00), 3.2f, boltBody)
            face(boltBody, hx(0xFFF58A), hx(0xFFB800), 2f, 46f, shine = 0.4f)
            clipPath(boltBody.p) { drawPath(boltShine.p, Color.White.copy(alpha = 0.55f)) }
        }
    }
}

// ---- Đồng hồ bấm giờ xanh (Nhanh)
private val swCrown = rrItm(19.5f, 2f, 9f, 5f, 2f)
private val swStem = rrItm(21.8f, 6f, 4.4f, 6f, 1f)
private val swSide = rrItm(34.9f, 7.4f, 5.2f, 7.2f, 1.6f)
private val swBody = circItm(24f, 27.5f, 18f)
private val swDial = circItm(24f, 27.5f, 13.6f)

/** Đồng hồ bấm giờ: vành xanh nổi, mặt số trũng, hai kim. */
@Composable
fun StopwatchIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.3f, 16f, 1.8f)
            val dark = hx(0x2F6B1A)
            ext(dark, 2.2f, swCrown, swStem)
            face(swCrown, hx(0xC5EF8D), hx(0x5BA52C), 2f, 7f, shine = 0.3f, rim = 0.6f)
            rotate(45f, Offset(37.5f, 11f)) {
                fillItm(swSide, dark)
                translate(0f, -1f) { face(swSide, hx(0xC5EF8D), hx(0x5BA52C), 6.4f, 13.6f, shine = 0.3f, rim = 0.5f) }
            }
            ext(dark, 3.2f, swBody)
            face(swBody, hx(0xBDEE82), hx(0x4C9A25), 9.5f, 45.5f, shine = 0.34f)
            // mặt số trũng: bóng đổ phía trên rồi mặt trắng
            drawCircle(Color(0x731E460F), radius = 13.6f, center = Offset(24f, 28.4f))
            fillItm(swDial, Brush.verticalGradient(listOf(hx(0xFFFFFF), hx(0xDCE6CC)), startY = 14f, endY = 41f))
            drawPath(swDial.p, hx(0x8FB866), style = Stroke(width = 0.8f))
            val tick = hx(0x5E8F3C)
            drawLine(tick, Offset(24f, 15.8f), Offset(24f, 18.2f), 1.6f, StrokeCap.Round)
            drawLine(tick, Offset(24f, 36.8f), Offset(24f, 39.2f), 1.6f, StrokeCap.Round)
            drawLine(tick, Offset(11.8f, 27.5f), Offset(14.2f, 27.5f), 1.6f, StrokeCap.Round)
            drawLine(tick, Offset(33.8f, 27.5f), Offset(36.2f, 27.5f), 1.6f, StrokeCap.Round)
            drawLine(dark, Offset(24f, 27.5f), Offset(24f, 19.5f), 2.6f, StrokeCap.Round)
            drawLine(dark, Offset(24f, 27.5f), Offset(29.8f, 31f), 2.2f, StrokeCap.Round)
            sphere(24f, 27.5f, 2.3f, hx(0x7CC243), hx(0x3F8A1E), hx(0x256010))
        }
    }
}

// ---- Mặt trời (Tự do / không giới hạn)
private val sunRay = rrItm(21f, 2f, 6f, 9f, 3f)
private val sunDisk = circItm(24f, 24f, 12.2f)

/** Mặt trời: quả cầu vàng có 8 tia nổi. */
@Composable
fun SunIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val pivot = Offset(24f, 24f)
            shadowOval(24f, 46.3f, 13f, 1.8f)
            for (k in 1..5) {
                translate(0f, 3f * k / 5f) {
                    for (i in 0 until 8) rotate(i * 45f, pivot) { fillItm(sunRay, hx(0xB86A00)) }
                }
            }
            for (i in 0 until 8) {
                rotate(i * 45f, pivot) { face(sunRay, hx(0xFFE680), hx(0xFFAE00), 2f, 11f, shine = 0.3f, shade = 0f, rim = 0.5f) }
            }
            ext(hx(0xB86A00), 3f, sunDisk)
            sphere(24f, 24f, 12.2f, hx(0xFFF3A6), hx(0xFFC21C), hx(0xF08A00))
            drawOval(Color.White.copy(alpha = 0.55f), Offset(15.2f, 15.6f), Size(8.8f, 5.2f))
        }
    }
}

// ---- Quân tốt 3D (thân trụ: gradient ngang). Dùng cho tab Trang chủ và hình minh họa thẻ Học.
private val pawnBody = svgItm("M17.6 24.6C18.2 31.5 15 35.5 12.5 41H35.5C33 35.5 29.8 31.5 30.4 24.6Z", 1f)
private val pawnCollar = rrItm(14f, 19.5f, 20f, 5.2f, 2.6f)
private val pawnBase = rrItm(9f, 40f, 30f, 6f, 3f)
private val pawnHead = circItm(24f, 11.5f, 7.8f)

private fun DrawScope.drawPawn(a: Color, b: Color, c: Color, side: Color) {
    shadowOval(24f, 46.4f, 16f, 1.8f)
    ext(side, 3f, pawnBody, pawnCollar, pawnBase, pawnHead)
    fillItm(pawnBody, Brush.horizontalGradient(0f to a, 0.45f to b, 1f to c, startX = 12.5f, endX = 35.5f))
    fillItm(pawnCollar, Brush.horizontalGradient(0f to a, 0.5f to b, 1f to c, startX = 14f, endX = 34f))
    fillItm(pawnBase, Brush.horizontalGradient(0f to a, 0.5f to b, 1f to c, startX = 9f, endX = 39f))
    drawRect(Color(0x1F000000), Offset(14f, 24.2f), Size(20f, 1.3f))
    drawRect(Color(0x1F000000), Offset(9f, 40f), Size(30f, 1.4f))
    sphere(24f, 11.5f, 7.8f, a, b, c)
}

/** Quân tốt 3D theo màu [color] (sáng ở trái-trên, đậm dần sang phải-dưới). */
@Composable
fun PawnIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            drawPawn(
                a = lerp(color, Color.White, 0.55f),
                b = color,
                c = lerp(color, Color.Black, 0.3f),
                side = lerp(color, Color.Black, 0.55f),
            )
        }
    }
}

// ---- Ngôi sao / mũi tên (hình minh họa thẻ Học)
private val upArrow = svgItm("M24 4L43 25H31V43H17V25H5Z", 3.2f)

/** Mũi tên xanh lá mập, có đế dày. */
@Composable
fun UpArrowIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.4f, 12f, 1.8f)
            ext(hx(0x2F6A18), 3.4f, upArrow)
            face(upArrow, hx(0xC6F27E), hx(0x4F9E27), 2f, 45f, shine = 0.38f)
        }
    }
}

// ---- Đồng hồ nhỏ (chip thời gian) và nút đóng
private val clockBody = circItm(24f, 24f, 21f)

/** Đồng hồ treo tường xanh nhỏ: vành xanh nổi, mặt trắng, 2 kim. */
@Composable
fun ClockIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val dark = hx(0x2F6B1A)
            ext(dark, 3f, clockBody)
            face(clockBody, hx(0xBDEE82), hx(0x4C9A25), 3f, 45f, shine = 0.34f)
            drawCircle(Brush.verticalGradient(listOf(hx(0xFFFFFF), hx(0xDCE6CC)), startY = 8f, endY = 40f), radius = 15.5f, center = Offset(24f, 24f))
            drawLine(dark, Offset(24f, 24f), Offset(24f, 13f), 3.4f, StrokeCap.Round)
            drawLine(dark, Offset(24f, 24f), Offset(31.5f, 28f), 3.4f, StrokeCap.Round)
        }
    }
}

private val closeBody = circItm(24f, 24f, 20f)

/** Nút tròn xám có dấu X: dùng để ẩn thẻ gợi ý. */
@Composable
fun CloseIcon25D(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            ext(hx(0x262B33), 3f, closeBody)
            face(closeBody, hx(0x6C7480), hx(0x4A5059), 4f, 44f, shine = 0.3f)
            val x = hx(0xF2F5F9)
            drawLine(x, Offset(16.5f, 16.5f), Offset(31.5f, 31.5f), 5f, StrokeCap.Round)
            drawLine(x, Offset(31.5f, 16.5f), Offset(16.5f, 31.5f), 5f, StrokeCap.Round)
        }
    }
}

// ---- Huy chương vàng, dải xanh (Các giải đấu)
private val mdLeft = svgItm("M10 2H20L26 20H15Z", 0.8f)
private val mdRight = svgItm("M38 2H28L22 20H33Z", 0.8f)
private val mdCoin = circItm(24f, 30f, 15.5f)
private val mdInner = circItm(24f, 30f, 10.8f)
private val mdStar = starItm(24f, 30.6f, 8f, 3.8f, w = 1f)

/** Huy chương vàng có ngôi sao, hai dải ruy băng xanh lá. */
@Composable
fun MedalIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            shadowOval(24f, 46.3f, 13f, 1.8f)
            ext(hx(0x18551E), 2.5f, mdLeft, mdRight, steps = 4)
            face(mdLeft, hx(0x6BCB6F), hx(0x2E8B3A), 2f, 20f, shine = 0.25f, rim = 0.7f)
            face(mdRight, hx(0x4FB35A), hx(0x1E6E2A), 2f, 20f, shine = 0.2f, rim = 0.7f)
            ext(hx(0xA86A00), 3f, mdCoin)
            face(mdCoin, hx(0xFFE27A), hx(0xF2A200), 14.5f, 45.5f, shine = 0.34f)
            drawPath(mdInner.p, Color(0x8CA86A00), style = Stroke(width = 1.6f))
            face(mdStar, hx(0xFFF6C0), hx(0xFFC42E), 22f, 38f, shine = 0.1f, shade = 0.05f, rim = 0.4f)
        }
    }
}


/** Gold five-point star used on the Learn card. */
@Composable
fun StarIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 11f else 4.9f
            val a = (-90f + i * 36f) * PI.toFloat() / 180f
            val x = (12f + cos(a) * r) * u
            val y = (12.6f + sin(a) * r) * u
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Color(0xFFFFC83D))
        drawPath(path, Color(0xFFB87A00), style = Stroke(width = 1.1f * u))
    }
}

/** Board with a plus: "start a game" button glyph on the suggested-game card. */
@Composable
fun AddBoardIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val cell = 5f * u
        for (r in 0 until 3) {
            for (col in 0 until 3) {
                val solid = (r + col) % 2 == 0
                drawRect(
                    color = if (solid) Color.White else Color(0x66FFFFFF),
                    topLeft = Offset((2f * u) + col * cell, (2f * u) + r * cell),
                    size = Size(cell, cell),
                )
            }
        }
        drawCircle(Color.White, radius = 6.2f * u, center = Offset(18f * u, 18f * u))
        drawLine(Color(0xFF45753C), Offset(14.8f * u, 18f * u), Offset(21.2f * u, 18f * u), strokeWidth = 2.2f * u, cap = StrokeCap.Round)
        drawLine(Color(0xFF45753C), Offset(18f * u, 14.8f * u), Offset(18f * u, 21.2f * u), strokeWidth = 2.2f * u, cap = StrokeCap.Round)
    }
}

/** Red count bubble. Callers only show it when [count] > 0. */
@Composable
fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(16.dp)
            .background(VilaColors.Badge, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (count > 9) "9+" else count.toString(),
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
        )
    }
}

/** The icon matching a rating bucket (bullet, bolt, stopwatch, sun). */
@Composable
fun ModeIcon(mode: com.vila.chess.game.RatingMode, modifier: Modifier = Modifier) {
    when (mode) {
        com.vila.chess.game.RatingMode.BULLET -> BulletIcon(modifier)
        com.vila.chess.game.RatingMode.BLITZ -> BoltIcon(modifier)
        com.vila.chess.game.RatingMode.RAPID -> StopwatchIcon(modifier)
        com.vila.chess.game.RatingMode.DAILY -> SunIcon(modifier)
    }
}

/** Little monitor with a smiling face ("Chơi với Bot"). */
@Composable
fun ComputerIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawRoundRect(Color(0xFFD5E4F2), topLeft = Offset(1.5f * u, 2.5f * u), size = Size(21f * u, 15f * u), cornerRadius = CornerRadius(2.4f * u, 2.4f * u))
        drawRoundRect(Color(0xFF6FB6F2), topLeft = Offset(3.5f * u, 4.5f * u), size = Size(17f * u, 11f * u), cornerRadius = CornerRadius(1.2f * u, 1.2f * u))
        drawCircle(Color(0xFF1B3A5C), radius = 1.2f * u, center = Offset(9f * u, 9f * u))
        drawCircle(Color(0xFF1B3A5C), radius = 1.2f * u, center = Offset(15f * u, 9f * u))
        val smile = Path().apply {
            m(u, 8.6f, 11.8f)
            c(u, 10f, 14f, 14f, 14f, 15.4f, 11.8f)
        }
        drawPath(smile, Color(0xFF1B3A5C), style = Stroke(width = 1.3f * u, cap = StrokeCap.Round))
        drawRect(Color(0xFFB4C8DA), topLeft = Offset(10f * u, 17.5f * u), size = Size(4f * u, 2.6f * u))
        drawRoundRect(Color(0xFFB4C8DA), topLeft = Offset(6.5f * u, 20f * u), size = Size(11f * u, 2.2f * u), cornerRadius = CornerRadius(1.1f * u, 1.1f * u))
    }
}

/** Bearded coach face ("Bật huấn luyện viên"). */
@Composable
fun CoachIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val hair = Color(0xFF6B4A2F)
        drawCircle(Color(0xFFE2AA7E), radius = 9.4f * u, center = Offset(12f * u, 12.4f * u))
        val beard = Path().apply {
            m(u, 2.8f, 13f)
            c(u, 2.8f, 19.6f, 7f, 22.4f, 12f, 22.4f)
            c(u, 17f, 22.4f, 21.2f, 19.6f, 21.2f, 13f)
            c(u, 19f, 15.4f, 15.2f, 16.4f, 12f, 16.4f)
            c(u, 8.8f, 16.4f, 5f, 15.4f, 2.8f, 13f)
            close()
        }
        drawPath(beard, hair)
        val top = Path().apply {
            m(u, 2.8f, 11f)
            c(u, 2.8f, 5f, 7f, 2f, 12f, 2f)
            c(u, 17f, 2f, 21.2f, 5f, 21.2f, 11f)
            c(u, 19.2f, 8.4f, 15.6f, 7.6f, 12f, 7.6f)
            c(u, 8.4f, 7.6f, 4.8f, 8.4f, 2.8f, 11f)
            close()
        }
        drawPath(top, hair)
        drawCircle(Color(0xFF2A1D12), radius = 1.1f * u, center = Offset(8.8f * u, 12f * u))
        drawCircle(Color(0xFF2A1D12), radius = 1.1f * u, center = Offset(15.2f * u, 12f * u))
    }
}

/** Thin chevron used for dropdowns and "show more". */
@Composable
fun ChevronIcon(up: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val path = Path()
        if (up) {
            path.moveTo(5f * u, 15f * u)
            path.lineTo(12f * u, 8f * u)
            path.lineTo(19f * u, 15f * u)
        } else {
            path.moveTo(5f * u, 9f * u)
            path.lineTo(12f * u, 16f * u)
            path.lineTo(19f * u, 9f * u)
        }
        drawPath(path, color, style = Stroke(width = 2.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}


/**
 * Tạo độ dày 2.5D: vẽ lại chính nội dung icon dưới dạng bóng tối (giữ alpha, đổi màu thành [side]) lệch xuống [depth],
 * rồi vẽ icon thật đè lên. Dùng được cho mọi Canvas icon mà không phải vẽ lại từng hình.
 */
internal fun Modifier.extrude(depth: Dp, side: Color): Modifier = this.drawWithContent {
    val d = depth.toPx()
    val self = this
    drawIntoCanvas { canvas ->
        val paint = Paint().apply { colorFilter = ColorFilter.tint(side, BlendMode.SrcIn) }
        canvas.saveLayer(Rect(0f, 0f, size.width, size.height + d), paint)
        canvas.translate(0f, d)
        self.drawContent()
        canvas.restore()
    }
    drawContent()
}

/** Màu icon điều hướng: tint trắng = đang chọn (t = 1), NavIdle = chưa chọn (t = 0); trung gian khi chuyển tab. */
private fun navT(c: Color): Float {
    val idle = VilaColors.NavIdle
    val d = 1f - idle.red
    return if (d <= 0f) 1f else ((c.red - idle.red) / d).coerceIn(0f, 1f)
}

/** Màu sặc sỡ khi chọn, xám xanh dịu khi chưa chọn. */

// =============================================================================
// Icon thanh điều hướng 2.5D. Vẫn giữ khối khi chưa chọn (chỉ bớt màu) để thanh dưới nhìn đồng nhất.
// =============================================================================

/** Trang chủ: quân tốt trắng. */
@Composable
fun NavHomeIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val t = navT(tint)
            drawPawn(tone(0xFFFFFF, t), tone(0xC9D8EE, t), tone(0x8FA6C6, t), tone(0x5F7599, t))
        }
    }
}

private val pzShape = svgItm("M9 18C9 15.8 10.8 14 13 14H17.6C17.2 13.2 17 12.4 17 11.5C17 8.5 19.2 6.2 22.2 6.2C25.2 6.2 27.4 8.5 27.4 11.5C27.4 12.4 27.2 13.2 26.8 14H31C33.2 14 35 15.8 35 18V22.6C35.8 22.2 36.6 22 37.5 22C40.5 22 42.8 24.2 42.8 27.2C42.8 30.2 40.5 32.4 37.5 32.4C36.6 32.4 35.8 32.2 35 31.8V38C35 40.2 33.2 42 31 42H13C10.8 42 9 40.2 9 38Z", 1f)

/** Câu đố: mảnh ghép tím. */
@Composable
fun NavPuzzleIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val t = navT(tint)
            shadowOval(24f, 46.3f, 15f, 1.8f)
            ext(tone(0x4B2A9A, t), 3.2f, pzShape)
            face(pzShape, tone(0xD2B6FF, t), tone(0x7B4FE0, t), 6f, 42f, shine = 0.34f)
            clipPath(pzShape.p) {
                drawRoundRect(Color.White.copy(alpha = 0.36f), Offset(12.5f, 19f), Size(10f, 3.2f), CornerRadius(1.6f, 1.6f))
            }
        }
    }
}

private val lnBody = svgItm("M11.5 22.5V31C11.5 35 17.2 38.4 24 38.4C30.8 38.4 36.5 35 36.5 31V22.5L24 29Z", 1f)
private val lnCap = svgItm("M24 6.5L45 16.5L24 26.5L3 16.5Z", 1.4f)
private val lnShine = svgItm("M24 9.6L10.5 16L15 18.2L24 14Z")

/** Học: mũ tốt nghiệp xanh dương có tua vàng. */
@Composable
fun NavLearnIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val t = navT(tint)
            val gold = tone(0xFFC83A, t)
            shadowOval(24f, 46f, 15f, 1.8f)
            ext(tone(0x164A94, t), 3.2f, lnBody, lnCap)
            face(lnBody, tone(0x5FB3F0, t), tone(0x1D5FB8, t), 22f, 38.4f, shine = 0.18f, shade = 0.18f)
            face(lnCap, tone(0xA6E2FF, t), tone(0x2F86E2, t), 6f, 27f, shine = 0.34f)
            drawLine(gold, Offset(41f, 18.6f), Offset(41f, 31f), 2f, StrokeCap.Round)
            sphere(41f, 33f, 3f, hx(0xFFE890), gold, tone(0xC98400, t))
            drawPath(lnShine.p, Color.White.copy(alpha = 0.4f))
        }
    }
}

/** Bạn bè: hai người (xanh lá phía sau, trắng phía trước). */
@Composable
fun NavFriendsIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) { icon48 { drawFriends(navT(tint)) } }
}

private val moreBars = listOf(5f, 17.5f, 30f).map { rrItm(5f, it, 38f, 9f, 4.5f) to it }

/** Thêm nữa: ba thanh vàng nổi. */
@Composable
fun NavMoreIcon(tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        icon48 {
            val t = navT(tint)
            shadowOval(24f, 46.3f, 16f, 1.8f)
            val side = tone(0xA85F00, t)
            for ((bar, _) in moreBars) ext(side, 3f, bar, steps = 4)
            for ((bar, y) in moreBars) face(bar, tone(0xFFE38F, t), tone(0xF29A1E, t), y, y + 9f, shine = 0.4f, rim = 0.8f)
        }
    }
}
