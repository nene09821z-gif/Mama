package com.vila.chess.magic

import com.vila.chess.core.CR_BK
import com.vila.chess.core.CR_BQ
import com.vila.chess.core.CR_WK
import com.vila.chess.core.CR_WQ
import com.vila.chess.core.EMPTY
import com.vila.chess.core.KING
import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.Position
import com.vila.chess.core.ROOK
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.makePiece
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue
import java.util.Random

/** 0 = Trắng, 1 = Đen. */
fun idx(white: Boolean): Int = if (white) 0 else 1

class TrapState(val ownerWhite: Boolean, val expires: Int)

/**
 * Toàn bộ trạng thái một ván Cờ Phép Thuật. Hiệu ứng luôn chạy trên một BẢN SAO ([copy]); chỉ khi thế cờ hợp lệ mới thay bản chính.
 *
 * Trạng thái có hạn (đóng băng, khiên, bẫy, phong ấn) lưu "hết hạn tại turnNo": còn hiệu lực khi turnNo < hạn.
 * turnNo tăng 1 mỗi khi quyền đi chuyển sang bên kia (nước đi thêm không làm tăng), nên "N lượt của đối thủ" = 2N.
 */
class MagicState(val pos: Position, val rng: Random, val tier: MembershipTier = MembershipTier.FREE) {
    companion object {
        const val MANA_MAX = 20
        /** Mana lúc bắt đầu ván, mana nhận thêm mỗi đầu lượt, và mana nhận khi bỏ qua 3 lá / tái chế 1 lá. */
        const val MANA_START = 4
        const val MANA_PER_TURN = 2
        const val MANA_SWAP = 2
        const val HAND_MAX = 7
    }

    val mana = IntArray(2)
    val hands = arrayOf(ArrayList<Int>(), ArrayList<Int>())
    /** Loại quân đã mất của từng bên (để hồi sinh). */
    val lost = arrayOf(ArrayList<Int>(), ArrayList<Int>())
    val frozen = HashMap<Int, Int>()
    val shield = HashMap<Int, Int>()
    val traps = HashMap<Int, TrapState>()
    val lockedUntil = IntArray(2)
    val bonusMana = IntArray(2)
    /** 3 lá bài được "mở ra" đầu lượt của từng bên (chỉ bên đang đi có lá); chọn 1 lá vào tay hoặc bỏ qua. */
    val offers = arrayOf(ArrayList<Int>(), ArrayList<Int>())
    /** Dòng kết quả của phép ngẫu nhiên vừa dùng (xúc xắc, đồng xu…) để giao diện hiển thị. */
    var log: String? = null
    var turnNo = 0
    var spellUsed = false
    /** Đã tái chế một lá trong lượt này (mỗi lượt tối đa 1 lá). */
    var recycled = false
    /** -1 = không có; ≥ 0 = đang đi nước thêm (0 = quân nào cũng được, 1..5 = chỉ loại quân đó). */
    var extraPending = -1
    /** Nước thêm đã xin bằng phép, sẽ cấp sau nước đi của lượt này. */
    var extraNext = -1

    /**
     * Bản sao để thử phép. Bộ ngẫu nhiên của bản sao là BẢN SAO ĐỘC LẬP khi ván dùng [MagicRandom] (hoặc [rngOverride] nếu có),
     * nên việc thử không làm trôi dãy số của ván thật — điều kiện để hai máy chơi online luôn khớp nhau.
     */
    fun copy(rngOverride: java.util.Random? = null): MagicState {
        val childRng: Random = rngOverride ?: ((rng as? MagicRandom)?.copyState() ?: rng)
        val c = MagicState(pos.copy(), childRng, tier)
        for (i in 0..1) {
            c.mana[i] = mana[i]
            c.hands[i].addAll(hands[i])
            c.lost[i].addAll(lost[i])
            c.lockedUntil[i] = lockedUntil[i]
            c.bonusMana[i] = bonusMana[i]
            c.offers[i].addAll(offers[i])
        }
        c.frozen.putAll(frozen)
        c.shield.putAll(shield)
        c.traps.putAll(traps)
        c.turnNo = turnNo
        c.spellUsed = spellUsed
        c.recycled = recycled
        c.extraPending = extraPending
        c.extraNext = extraNext
        return c
    }

    // ---- truy vấn ----
    fun own(sq: Int, white: Boolean): Boolean { val p = pos.board[sq]; return p != EMPTY && isWhitePiece(p) == white }
    fun enemy(sq: Int, white: Boolean): Boolean { val p = pos.board[sq]; return p != EMPTY && isWhitePiece(p) != white }
    fun isKing(sq: Int): Boolean = pos.board[sq] != EMPTY && pieceType(pos.board[sq]) == KING
    fun isFrozen(sq: Int): Boolean = (frozen[sq] ?: -1) > turnNo
    fun isShielded(sq: Int): Boolean = (shield[sq] ?: -1) > turnNo
    fun trapAt(sq: Int): TrapState? = traps[sq]?.takeIf { it.expires > turnNo }

    fun material(white: Boolean): Int {
        var sum = 0
        for (sq in 0 until 64) if (own(sq, white)) sum += pieceValue(pieceType(pos.board[sq]))
        return sum
    }

    // ---- thao tác trên bàn (luôn đi qua đây để trạng thái đi theo quân) ----
    private fun clearStatus(sq: Int) { frozen.remove(sq); shield.remove(sq) }

    fun placePiece(sq: Int, piece: Int) {
        clearStatus(sq)
        pos.board[sq] = piece
    }

    fun removePiece(sq: Int) {
        val p = pos.board[sq]
        if (p == EMPTY) return
        lost[idx(isWhitePiece(p))].add(pieceType(p))
        clearStatus(sq)
        pos.board[sq] = EMPTY
    }

    fun movePiece(from: Int, to: Int) {
        val f = frozen.remove(from)
        val sh = shield.remove(from)
        clearStatus(to)
        pos.board[to] = pos.board[from]
        pos.board[from] = EMPTY
        if (f != null) frozen[to] = f
        if (sh != null) shield[to] = sh
    }

    fun swapPieces(a: Int, b: Int) {
        clearStatus(a); clearStatus(b)
        val t = pos.board[a]
        pos.board[a] = pos.board[b]
        pos.board[b] = t
    }

    /** Mở [MagicCatalog.OFFER_SIZE] lá bài ngẫu nhiên (khác nhau) cho [white]; tay bài đầy thì không mở. Gói VIP luôn có lá đặc quyền. */
    fun makeOffer(white: Boolean) {
        val o = offers[idx(white)]
        o.clear()
        if (hands[idx(white)].size >= HAND_MAX) return
        o.addAll(MagicCatalog.offerIds(rng, tier, MagicCatalog.OFFER_SIZE))
    }

    fun draw(white: Boolean, count: Int) {
        val hand = hands[idx(white)]
        repeat(count) { if (hand.size < HAND_MAX) hand.add(MagicCatalog.randomId(rng, tier)) }
    }

    /** Sau phép thuật: xoá en passant và bỏ quyền nhập thành nếu Vua/Xe không còn ở ô gốc. */
    fun sanitize() {
        pos.epSquare = -1
        val b = pos.board
        val wk = makePiece(KING, true)
        val bk = makePiece(KING, false)
        val wr = makePiece(ROOK, true)
        val br = makePiece(ROOK, false)
        var c = pos.castling
        if (b[4] != wk || b[7] != wr) c = c and CR_WK.inv()
        if (b[4] != wk || b[0] != wr) c = c and CR_WQ.inv()
        if (b[60] != bk || b[63] != br) c = c and CR_BK.inv()
        if (b[60] != bk || b[56] != br) c = c and CR_BQ.inv()
        pos.castling = c
    }
}
