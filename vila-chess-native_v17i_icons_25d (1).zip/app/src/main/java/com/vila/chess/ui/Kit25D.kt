package com.vila.chess.ui

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.PathParser
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Bộ dụng cụ vẽ icon 2.5D (lưới 48 x 48), dùng chung cho mọi icon ở HomeIcons.kt.
 *
 * Mỗi icon là một "vật thể" gồm 4 lớp, vẽ theo thứ tự:
 *   1. bóng tiếp đất (hình elip mờ dưới chân)
 *   2. đế dày  : [ext] vẽ nhiều bản sao màu tối dịch xuống để lấp kín khe (không hở như một bản dịch)
 *   3. mặt     : [face] gradient dọc sáng -> đậm
 *   4. ánh kính: vệt sáng nửa trên + tối nhẹ nửa dưới + viền sáng mép trên (cắt theo hình, nên không tràn)
 * Quả cầu (đầu người, quả cầu mặt trời...) dùng [sphere] với gradient tròn lệch sáng về trên-trái.
 *
 * Hình dạng viết bằng chuỗi SVG path (PathParser) nên khớp 1-1 với bản mẫu thiết kế.
 * Hình được tạo MỘT LẦN ở top-level (không parse lại mỗi khung hình khi tab nav đang chạy hiệu ứng).
 */

/** Một hình: path + độ dày nét bo tròn góc (w > 0 => tô thêm một nét cùng màu để bo góc nhọn). */
internal class Itm(val p: Path, val w: Float = 0f)

internal fun svgItm(d: String, w: Float = 0f): Itm = Itm(PathParser().parsePathString(d).toPath(), w)

internal fun circItm(cx: Float, cy: Float, r: Float): Itm =
    Itm(Path().apply { addOval(Rect(Offset(cx, cy), r)) })

internal fun rrItm(x: Float, y: Float, w: Float, h: Float, r: Float): Itm =
    Itm(Path().apply { addRoundRect(RoundRect(x, y, x + w, y + h, r, r)) })

/** Ngôi sao 5 cánh: [ro] bán kính mũi, [ri] bán kính hõm. */
internal fun starItm(cx: Float, cy: Float, ro: Float, ri: Float, w: Float = 0f): Itm {
    val p = Path()
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) ro else ri
        val a = ((-90f + i * 36f) * PI / 180.0).toFloat()
        val x = cx + cos(a) * r
        val y = cy + sin(a) * r
        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
    }
    p.close()
    return Itm(p, w)
}

/** Màu từ 0xRRGGBB (alpha = 255). */
internal fun hx(v: Long): Color = Color(0xFF000000L or v)

/**
 * Icon điều hướng: [t] = 1 sặc sỡ (đang chọn), 0 xám xanh dịu (chưa chọn); giá trị giữa là lúc đang chuyển tab.
 * Vẫn giữ khối và gradient nên icon "chưa chọn" vẫn nhìn ra 2.5D, chỉ bớt màu.
 */
internal fun tone(v: Long, t: Float): Color {
    val c = hx(v)
    val g = c.red * 0.3f + c.green * 0.59f + c.blue * 0.11f
    val grey = Color(
        (g * 0.85f + 30f / 255f).coerceIn(0f, 1f),
        (g * 0.90f + 40f / 255f).coerceIn(0f, 1f),
        (g * 0.95f + 60f / 255f).coerceIn(0f, 1f),
    )
    val k = 0.18f + 0.82f * t.coerceIn(0f, 1f)
    return lerp(grey, c, k)
}

/** Chuyển hệ toạ độ về lưới 48 x 48, căn giữa trong vùng vẽ. */
internal fun DrawScope.icon48(block: DrawScope.() -> Unit) {
    val s = size.minDimension / 48f
    withTransform({
        translate((size.width - 48f * s) / 2f, (size.height - 48f * s) / 2f)
        scale(s, s, Offset.Zero)
    }) { block() }
}

internal fun DrawScope.fillItm(it: Itm, brush: Brush) {
    drawPath(it.p, brush)
    if (it.w > 0f) drawPath(it.p, brush, style = Stroke(width = it.w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

internal fun DrawScope.fillItm(it: Itm, color: Color) {
    drawPath(it.p, color)
    if (it.w > 0f) drawPath(it.p, color, style = Stroke(width = it.w, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Đế dày: các bản sao màu [side] dịch xuống từng bước nhỏ tới [depth]. */
internal fun DrawScope.ext(side: Color, depth: Float, vararg items: Itm, steps: Int = 6) {
    for (i in 1..steps) {
        translate(0f, depth * i / steps) {
            for (it in items) fillItm(it, side)
        }
    }
}

/** Mặt có khối: gradient dọc + ánh kính nửa trên + tối nhẹ nửa dưới + viền sáng mép trên. */
internal fun DrawScope.face(
    it: Itm,
    light: Color,
    dark: Color,
    y0: Float,
    y1: Float,
    shine: Float = 0.34f,
    shade: Float = 0.16f,
    rim: Float = 1.2f,
) {
    fillItm(it, Brush.verticalGradient(listOf(light, dark), startY = y0, endY = y1))
    val h = y1 - y0
    clipPath(it.p) {
        if (shine > 0f) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = shine), Color.White.copy(alpha = 0f)),
                    startY = y0,
                    endY = y0 + h * 0.55f,
                ),
                topLeft = Offset(-10f, y0 - 5f),
                size = Size(70f, h * 0.55f + 5f),
            )
        }
        if (shade > 0f) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0f), Color.Black.copy(alpha = shade)),
                    startY = y0 + h * 0.55f,
                    endY = y1,
                ),
                topLeft = Offset(-10f, y0 + h * 0.55f),
                size = Size(70f, h * 0.45f + 10f),
            )
        }
        if (rim > 0f) {
            drawPath(
                it.p,
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0f)),
                    startY = y0,
                    endY = y0 + h * 0.5f,
                ),
                style = Stroke(width = rim * 2f, join = StrokeJoin.Round),
            )
        }
    }
}

/** Quả cầu: sáng lệch về trên-trái, tối dần ra mép. */
internal fun DrawScope.sphere(cx: Float, cy: Float, r: Float, c0: Color, c1: Color, c2: Color) {
    drawCircle(
        brush = Brush.radialGradient(
            0f to c0, 0.38f to c1, 1f to c2,
            center = Offset(cx - r * 0.35f, cy - r * 0.4f),
            radius = r * 1.5f,
        ),
        radius = r,
        center = Offset(cx, cy),
    )
}

/** Bóng tiếp đất dưới chân vật thể. */
internal fun DrawScope.shadowOval(cx: Float, cy: Float, rx: Float, ry: Float, a: Float = 0.35f) {
    drawOval(Color.Black.copy(alpha = a), Offset(cx - rx, cy - ry), Size(rx * 2f, ry * 2f))
}

internal fun DrawScope.roundRectF(c: Color, x: Float, y: Float, w: Float, h: Float, r: Float) =
    drawRoundRect(c, Offset(x, y), Size(w, h), CornerRadius(r, r))
