package com.vila.chess.ui

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Big green button with the darker bottom-edge shadow used all over chess.com (game screen). */
@Composable
fun GreenButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(VilaColors.GreenShadow)
            .clickable(onClick = onClick)
            .padding(bottom = 4.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(shape)
                .background(VilaColors.Green),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = text,
                color = VilaColors.Text,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

// =============================================================================
// Bộ công cụ UI dùng chung (phong cách chess.com: mượt, có phản hồi khi chạm)
// =============================================================================

/**
 * Chạm là co nhẹ + nảy lại (spring), rung nhẹ, chống bấm đúp.
 * Toàn bộ hiệu ứng chạy ở pha DRAW (graphicsLayer) nên KHÔNG gây recomposition.
 * Đặt modifier này TRƯỚC clip/background để cả thẻ cùng co lại.
 */
fun Modifier.pressable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    pressedScale: Float = 0.97f,
    haptic: Boolean = true,
    onClick: () -> Unit,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val scale = remember { Animatable(1f) }
    val feedback = LocalHapticFeedback.current
    val last = remember { longArrayOf(0L) }
    LaunchedEffect(source) {
        source.interactions.collect { i ->
            when (i) {
                is PressInteraction.Press -> launch {
                    scale.animateTo(pressedScale, spring(stiffness = Spring.StiffnessHigh))
                }
                is PressInteraction.Release, is PressInteraction.Cancel -> launch {
                    scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
                }
            }
        }
    }
    this
        .graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
        }
        .clickable(
            interactionSource = source,
            indication = null,
            enabled = enabled,
            onClickLabel = onClickLabel,
            role = Role.Button,
        ) {
            val now = SystemClock.elapsedRealtime()
            if (now - last[0] >= 350L) {
                last[0] = now
                if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
        }
}

/**
 * Đế dày 2.5D cho thẻ/nút: vẽ một hình bo góc màu tối nằm thấp hơn [depth] phía sau mặt thẻ.
 * Đặt TRƯỚC `.padding(bottom = depth)` và clip/background: chiều cao tổng = mặt + depth.
 */
fun Modifier.lipBehind(radius: Dp, depth: Dp, color: Color): Modifier = this.drawBehind {
    val d = depth.toPx()
    drawRoundRect(
        color = color,
        topLeft = Offset(0f, d),
        size = Size(size.width, size.height - d),
        cornerRadius = CornerRadius(radius.toPx()),
    )
}

/** Thẻ kính có chiều sâu: nền gradient + viền sáng ở cạnh trên. */
fun Modifier.glass(shape: Shape): Modifier =
    this.clip(shape)
        .background(VilaBrushes.Glass)
        .border(1.dp, VilaBrushes.GlassStroke, shape)

/**
 * Hiện dần + trượt nhẹ từ dưới lên khi mục xuất hiện (chạy một lần).
 * [seen] (tuỳ chọn): tập chỉ số đã chạy, để mục cuộn ra vào trong LazyGrid không chạy lại.
 */
fun Modifier.staggerIn(index: Int, seen: MutableSet<Int>? = null): Modifier = composed {
    val already = remember { seen?.contains(index) == true }
    val progress = remember { Animatable(if (already) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!already) {
            seen?.add(index)
            delay(35L * (index % 5))
            progress.animateTo(1f, tween(280, easing = FastOutSlowInEasing))
        }
    }
    this.graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 16.dp.toPx()
    }
}

/** Thanh tiêu đề thống nhất: nút quay lại tròn + tiêu đề đậm ở giữa. */
@Composable
fun VilaTopBar(
    title: String,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    leading: (@Composable () -> Unit)? = null,
) {
    Box(modifier = modifier.fillMaxWidth().height(60.dp)) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 8.dp)
                .size(44.dp)
                .pressable(onClickLabel = "Quay lại", pressedScale = 0.86f, onClick = onBack)
                .clip(CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Quay lại",
                tint = Color(0xFFD5DCE8),
                modifier = Modifier.size(26.dp),
            )
        }
        Row(modifier = Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) {
                leading()
                Spacer(Modifier.width(8.dp))
            }
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-0.2).sp,
                maxLines = 1,
            )
        }
    }
}
