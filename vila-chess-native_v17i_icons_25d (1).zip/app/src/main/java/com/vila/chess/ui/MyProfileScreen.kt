package com.vila.chess.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.R
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.StatsStore
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.UserSessionManager
import kotlinx.coroutines.launch
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.offset
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.profile.AvatarPhotos
import com.vila.chess.profile.EloRange
import com.vila.chess.profile.rankTitle
import com.vila.chess.profile.streakLabel

// =============================================================================
// Màn hình Hồ sơ — hero banner + avatar vòng sáng theo gói, đổi ảnh từ thư viện (có cắt/zoom).
//   userId == null  → hồ sơ CỦA MÌNH: 3 tab vuốt ngang (Tổng quan · Thành tựu · Bạn bè) + Chỉnh sửa hồ sơ.
//   userId != null  → hồ sơ NGƯỜI KHÁC (đối thủ/bạn bè) tải từ Supabase — chỉ xem, không có tab.
// Tổng quan = hero (avatar, tên, danh hiệu, nút) + 3 thẻ Elo + biểu đồ Elo + thống kê thắng/hòa/thua.
// =============================================================================

private val PROFILE_TABS = listOf("Tổng quan", "Thành tựu", "Bạn bè")

@Composable
fun MyProfileScreen(
    vm: GameViewModel,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    userId: String? = null,
) {
    BackHandler(onBack = onBack)
    // Scaffold lo chừa chỗ thanh trạng thái/thanh điều hướng; nền để trong suốt cho SpaceBackground phía sau.
    Scaffold(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = { ProfileTopBar(title = if (userId == null) "Hồ sơ" else "Hồ sơ người chơi", onBack = onBack) },
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            if (userId == null) OwnProfile(vm) else RemoteProfile(userId)
        }
    }
}

// ------------------------------------------------------------------ Hồ sơ của mình

@Composable
private fun OwnProfile(vm: GameViewModel) {
    val ctx = LocalContext.current
    // Gói lấy từ MembershipStore (qua UserSessionManager): mua gói xong huy hiệu đổi ngay, không cần làm gì thêm.
    val tier by UserSessionManager.tier(ctx).collectAsState()
    val name = UserSessionManager.displayName
    val country = UserSessionManager.countryCode
    val avatar = UserSessionManager.avatarKey
    val stats = vm.stats
    val profile = remember(stats, tier, name, country, avatar) { UserSessionManager.profile(ctx, stats) }
    var editing by remember { mutableStateOf(false) }
    val pickPhoto = rememberAvatarPicker { key ->
        val err = UserSessionManager.updateProfile(ctx, name, country, key)
        if (err != null) { AvatarPhotos.delete(ctx, key); Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show() }
        else Toast.makeText(ctx, "Đã cập nhật ảnh đại diện", Toast.LENGTH_SHORT).show()
    }

    OwnTabs(profile = profile, onEdit = { editing = true }, onPickPhoto = pickPhoto)
    if (editing) EditProfileSheet(onDismiss = { editing = false })
}

// ------------------------------------------------------------------ Hồ sơ người khác

@Composable
private fun RemoteProfile(userId: String) {
    val (state, retry) = rememberRemoteProfile(userId)
    when (val s = state) {
        is LoadState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { LoadingBlock(text = "Đang tải hồ sơ…") }
        is LoadState.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ErrorBlock(s.kind, onRetry = retry) }
        is LoadState.Success -> OverviewTab(profile = s.data, isSelf = false, onEdit = {})
    }
}

// ------------------------------------------------------------------ 3 tab vuốt ngang

@Composable
private fun OwnTabs(profile: UserProfile, onEdit: () -> Unit, onPickPhoto: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = 0, pageCount = { PROFILE_TABS.size })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = pager.currentPage,
            containerColor = Color.Transparent,
            contentColor = Color.White,
            indicator = { positions ->
                if (pager.currentPage < positions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(positions[pager.currentPage]),
                        height = 3.dp,
                        color = VilaColors.Green,
                    )
                }
            },
            divider = {},
        ) {
            PROFILE_TABS.forEachIndexed { i, label ->
                val on = pager.currentPage == i
                Tab(
                    selected = on,
                    onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    selectedContentColor = Color.White,
                    unselectedContentColor = VilaColors.TextDim,
                    text = { Text(label, fontSize = 14.sp, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1) },
                )
            }
        }
        HorizontalPager(
            state = pager,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            key = { it },
        ) { page ->
            when (page) {
                0 -> OverviewTab(profile = profile, isSelf = true, onEdit = onEdit, onPickPhoto = onPickPhoto)
                1 -> AchievementsPanel()
                else -> FriendsTab(
                    friends = MockFriends,
                    onChallenge = { f -> Toast.makeText(ctx, "Đã gửi lời thách đấu tới ${f.name}", Toast.LENGTH_SHORT).show() },
                )
            }
        }
    }
}

// ------------------------------------------------------------------ Tab: Tổng quan

private val CardBase = Color(0xFF0F1B33)

private fun Modifier.glassCard(radius: Dp = 20.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this.clip(shape).background(VilaBrushes.Glass).border(1.dp, VilaBrushes.GlassStroke, shape)
}

/** Màu vòng avatar theo gói thành viên. */
private fun ringColors(tier: MembershipTier): List<Color> = when (tier) {
    MembershipTier.FREE -> listOf(Color(0xFF81B64C), Color(0xFF4FD1C5), Color(0xFF81B64C))
    MembershipTier.GOLD -> listOf(Color(0xFFFFE27A), Color(0xFFF5A800), Color(0xFFFFE27A))
    MembershipTier.PLATINUM -> listOf(Color(0xFFFFFFFF), Color(0xFF8FB6E3), Color(0xFFFFFFFF))
    MembershipTier.DIAMOND -> listOf(Color(0xFF8FE3FF), Color(0xFF3A7BFF), Color(0xFF8FE3FF))
    MembershipTier.FAMILY -> listOf(Color(0xFF9BEFA0), Color(0xFF2FA36B), Color(0xFF9BEFA0))
}

@Composable
private fun OverviewTab(profile: UserProfile, isSelf: Boolean, onEdit: () -> Unit, onPickPhoto: () -> Unit = {}) {
    var modeIdx by rememberSaveable { mutableIntStateOf(EloMode.BLITZ.ordinal) }
    var rangeIdx by rememberSaveable { mutableIntStateOf(EloRange.MONTH.ordinal) }
    val mode = EloMode.values()[modeIdx]
    val range = EloRange.values()[rangeIdx]

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        HeroCard(profile, isSelf, onEdit, onPickPhoto)

        SectionTitle("Xếp hạng Elo")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            for (m in EloMode.values()) {
                EloTile(
                    mode = m, rating = profile.elo(m), selected = m == mode,
                    modifier = Modifier.weight(1f), onClick = { modeIdx = m.ordinal },
                )
            }
        }

        Column(Modifier.fillMaxWidth().glassCard(20.dp).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Biến động · ${mode.title}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                for (r in EloRange.values()) {
                    RangeChip(r.label, selected = r == range) { rangeIdx = r.ordinal }
                    Spacer(Modifier.width(6.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
            EloChart(
                history = profile.eloHistory[mode].orEmpty(),
                currentRating = profile.elo(mode),
                range = range,
                modifier = Modifier.fillMaxWidth().height(190.dp),
            )
        }

        SectionTitle("Thống kê")
        StatsCard(profile)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(), color = VilaColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp),
    )
}

// ------------------------------------------------------------------ Hero

@Composable
private fun HeroCard(profile: UserProfile, isSelf: Boolean, onEdit: () -> Unit, onPickPhoto: () -> Unit) {
    val seed = Color(Avatars.byKey(profile.avatarKey)?.argb ?: Avatars.colorFor(profile.displayName))
    Column(Modifier.fillMaxWidth().glassCard(26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        // Banner 116dp + nửa dưới avatar nằm chung một Box cao 172dp (để nút máy ảnh vẫn nhận chạm).
        Box(Modifier.fillMaxWidth().height(172.dp)) {
            HeroBanner(seed, Modifier.fillMaxWidth().height(116.dp))
            RingAvatar(
                profile = profile, showCamera = isSelf, onCamera = onPickPhoto,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
        Spacer(Modifier.height(10.dp))
        NameWithBadge(name = profile.displayName, tier = profile.tier, fontSize = 24f, badgeSize = 24.dp, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CountryLine(profile.countryCode)
            RankChip(rankTitle(profile.bestElo))
            if (isSelf) {
                val myTitle by com.vila.chess.game.TitleStore.get(androidx.compose.ui.platform.LocalContext.current).title.collectAsState()
                myTitle?.let { TitleChip(it) }
            } else {
                profile.chessTitle?.let { TitleChip(it) }
            }
        }
        if (isSelf) {
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HeroButton("Chỉnh sửa hồ sơ", primary = true, modifier = Modifier.weight(1.3f), onClick = onEdit) {
                    Icon(ImageVector.vectorResource(id = R.drawable.ic_edit), null, tint = Color.White, modifier = Modifier.size(16.dp))
                }
                HeroButton("Đổi ảnh", primary = false, modifier = Modifier.weight(1f), onClick = onPickPhoto) {
                    Icon(Icons.Filled.PhotoLibrary, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
private fun HeroBanner(seed: Color, modifier: Modifier) {
    val deep = Color(0xFF0A1530)
    Canvas(modifier) {
        drawRect(
            Brush.linearGradient(
                listOf(lerp(seed, deep, 0.30f), lerp(seed, deep, 0.78f)),
                start = Offset.Zero, end = Offset(size.width, size.height),
            ),
        )
        // Hoa văn bàn cờ rất mờ
        val sq = 22.dp.toPx()
        val cols = (size.width / sq).toInt() + 1
        val rows = (size.height / sq).toInt() + 1
        for (r in 0 until rows) for (c in 0 until cols) {
            if ((r + c) % 2 == 0) drawRect(Color(0x0DFFFFFF), Offset(c * sq, r * sq), Size(sq, sq))
        }
        // Quầng sáng góc phải
        drawCircle(
            Brush.radialGradient(listOf(Color(0x40FFFFFF), Color.Transparent), center = Offset(size.width * 0.85f, size.height * 0.1f), radius = size.width * 0.5f),
            radius = size.width * 0.5f, center = Offset(size.width * 0.85f, size.height * 0.1f),
        )
        // Hòa vào thân thẻ ở đáy
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC182A47)), startY = size.height * 0.45f, endY = size.height))
    }
}

@Composable
private fun RingAvatar(profile: UserProfile, showCamera: Boolean, onCamera: () -> Unit, modifier: Modifier = Modifier) {
    val ring = ringColors(profile.tier)
    Box(modifier.size(116.dp)) {
        Box(
            Modifier
                .fillMaxSize()
                .shadow(20.dp, CircleShape, ambientColor = ring[0], spotColor = ring[0])
                .clip(CircleShape)
                .background(Brush.sweepGradient(ring))
                .padding(3.dp)
                .clip(CircleShape)
                .background(CardBase)
                .padding(3.dp),
        ) {
            ProfileAvatar(name = profile.displayName, avatarKey = profile.avatarKey, size = 104.dp)
        }
        if (showCamera) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .size(36.dp)
                    .border(3.dp, CardBase, CircleShape)
                    .clip(CircleShape)
                    .background(VilaBrushes.ButtonFace)
                    .clickable(onClick = onCamera),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.CameraAlt, "Đổi ảnh đại diện", tint = Color.White, modifier = Modifier.size(18.dp)) }
        }
    }
}

@Composable
private fun RankChip(text: String) {
    Text(
        text, color = Color(0xFFCDE8A8), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x2981B64C))
            .border(1.dp, Color(0x5581B64C), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
private fun HeroButton(text: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier
            .height(44.dp)
            .clip(shape)
            .then(if (primary) Modifier.background(VilaBrushes.ButtonFace) else Modifier.background(Color(0x1FFFFFFF)).border(1.dp, Color(0x33FFFFFF), shape))
            .clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        icon()
        Spacer(Modifier.width(7.dp))
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------ Elo + thống kê

@Composable
private fun EloTile(mode: EloMode, rating: Int, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val colors = if (selected) listOf(Color(0xFF2B4D3C), Color(0xFF132219)) else listOf(Color(0xFF223250), Color(0xFF111A2C))
    Column(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(colors))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) VilaColors.Green else VilaColors.GlassBorder, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val iconModifier = Modifier.size(28.dp)
        when (mode) {
            EloMode.BULLET -> BulletIcon(iconModifier)
            EloMode.BLITZ -> BoltIcon(iconModifier)
            EloMode.RAPID -> StopwatchIcon(iconModifier)
        }
        Spacer(Modifier.height(8.dp))
        Text(rating.toString(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(mode.title, color = if (selected) Color(0xFFCDE8A8) else VilaColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun RangeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        label, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        color = if (selected) Color.White else VilaColors.TextDim,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Color(0x4081B64C) else Color(0x14FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp, vertical = 5.dp),
    )
}

@Composable
private fun StatsCard(p: UserProfile) {
    Column(Modifier.fillMaxWidth().glassCard(20.dp).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            WinDonut(pct = p.winRatePct, modifier = Modifier.size(92.dp))
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text("Tổng số ván", color = VilaColors.TextDim, fontSize = 12.sp)
                Text(p.played.toString(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                StreakChip(p.resultStreak)
            }
        }
        Spacer(Modifier.height(16.dp))
        WdlBar(p.won, p.drawn, p.lost)
        Spacer(Modifier.height(12.dp))
        WdlRow(p)
    }
}

@Composable
private fun WinDonut(pct: Int, modifier: Modifier = Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 9.dp.toPx()
            val inset = w / 2f
            val arcSize = Size(size.width - w, size.height - w)
            drawArc(Color(0x1FFFFFFF), 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(w))
            if (pct > 0) drawArc(WinColor, -90f, 360f * pct / 100f, false, Offset(inset, inset), arcSize, style = Stroke(w, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$pct%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            Text("thắng", color = VilaColors.TextDim, fontSize = 11.sp)
        }
    }
}

@Composable
private fun StreakChip(streak: Int) {
    val c = when { streak > 0 -> WinColor; streak < 0 -> LossColor; else -> DrawColor }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (streak > 0) {
            Icon(Icons.Filled.LocalFireDepartment, null, tint = c, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(streakLabel(streak), color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------ Thanh trên

@Composable
private fun ProfileTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onBack).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White)
        Text("  $title", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ Chỉnh sửa hồ sơ

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val original = remember { UserSessionManager.avatarKey }
    var name by remember { mutableStateOf(UserSessionManager.displayName) }
    var avatar by remember { mutableStateOf(original) }
    var country by remember { mutableStateOf(UserSessionManager.countryCode) }
    var error by remember { mutableStateOf<String?>(null) }
    var pickCountry by remember { mutableStateOf(false) }
    var tempPhoto by remember { mutableStateOf<String?>(null) }   // ảnh vừa chọn trong phiên này, chưa lưu
    var saved by remember { mutableStateOf(false) }

    // Đóng sheet mà không lưu → xoá ảnh tạm.
    DisposableEffect(Unit) { onDispose { if (!saved) tempPhoto?.let { AvatarPhotos.delete(ctx, it) } } }

    val pickPhoto = rememberAvatarPicker { key ->
        tempPhoto?.let { AvatarPhotos.delete(ctx, it) }
        tempPhoto = key
        avatar = key
    }
    fun choosePreset(key: String) {
        tempPhoto?.let { AvatarPhotos.delete(ctx, it) }
        tempPhoto = null
        avatar = key
    }
    val photoKey = tempPhoto ?: original.takeIf { AvatarPhotos.isPhoto(it) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color(0xFF16233B),
        contentColor = Color.White,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Chỉnh sửa hồ sơ", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)

            // Xem trước + nút chọn ảnh
            Box(
                Modifier
                    .size(112.dp)
                    .clip(CircleShape)
                    .background(Brush.sweepGradient(ringColors(MembershipTier.FREE)))
                    .padding(3.dp).clip(CircleShape).background(CardBase).padding(3.dp),
            ) { ProfileAvatar(name = name, avatarKey = avatar, size = 100.dp) }

            HeroButton("Chọn ảnh từ thư viện", primary = true, modifier = Modifier.fillMaxWidth(), onClick = pickPhoto) {
                Icon(Icons.Filled.PhotoLibrary, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }

            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Hoặc chọn biểu tượng", color = VilaColors.TextDim, fontSize = 13.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (photoKey != null) item(key = "photo") { AvatarChoice(name, photoKey, selected = avatar == photoKey) { avatar = photoKey } }
                    item(key = "initial") { AvatarChoice(name, "", selected = avatar.isBlank()) { choosePreset("") } }
                    items(Avatars.presets, key = { it.key }) { pr -> AvatarChoice(name, pr.key, selected = avatar == pr.key) { choosePreset(pr.key) } }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(30); error = null },
                label = { Text("Tên hiển thị") },
                singleLine = true,
                isError = error != null,
                supportingText = { Text(error ?: "${name.trim().length}/20 ký tự · tối thiểu 2") },
                modifier = Modifier.fillMaxWidth(),
            )

            val c = Countries.byCode(country)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x14FFFFFF))
                    .clickable { pickCountry = true }.padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Quốc gia", color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(if (c != null) Countries.flag(c.code) + " " + c.name else "Chưa chọn", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            ChunkyButton(
                text = "Lưu",
                onClick = {
                    val err = UserSessionManager.updateProfile(ctx, name, country, avatar)
                    if (err != null) error = err
                    else { saved = true; Toast.makeText(ctx, "Đã lưu hồ sơ", Toast.LENGTH_SHORT).show(); onDismiss() }
                },
                modifier = Modifier.fillMaxWidth(), height = 48.dp, fontSize = 18.sp,
            )
        }
    }

    if (pickCountry) {
        AlertDialog(
            onDismissRequest = { pickCountry = false },
            title = { Text("Chọn quốc gia") },
            text = {
                LazyColumn(Modifier.height(360.dp)) {
                    items(Countries.all, key = { it.code }) { ct ->
                        Row(
                            Modifier.fillMaxWidth().clickable { country = ct.code; pickCountry = false }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(Countries.flag(ct.code), fontSize = 22.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(ct.name, fontSize = 16.sp, fontWeight = if (ct.code == country) FontWeight.ExtraBold else FontWeight.Normal)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickCountry = false }) { Text("Đóng") } },
        )
    }
}

@Composable
private fun AvatarChoice(name: String, key: String, selected: Boolean, onClick: () -> Unit) {
    ProfileAvatar(
        name = name, avatarKey = key, size = 52.dp,
        modifier = Modifier
            .border(if (selected) 3.dp else 0.dp, if (selected) VilaColors.Green else Color.Transparent, CircleShape)
            .clickable(onClick = onClick),
    )
}
