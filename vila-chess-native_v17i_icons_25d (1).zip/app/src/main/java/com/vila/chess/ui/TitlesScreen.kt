package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.AchievementStore
import com.vila.chess.game.ChessTitle
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.TitleRules
import com.vila.chess.game.TitleStore
import com.vila.chess.profile.UserSessionManager

fun titleColor(t: ChessTitle): Color = when (t) {
    ChessTitle.CM -> Color(0xFFD9985A)
    ChessTitle.FM -> Color(0xFFC9D3E6)
    ChessTitle.GM -> Color(0xFFF2B134)
}

/** Huy hiệu danh hiệu nhỏ (CM / FM / GM) hiện cạnh tên trên hồ sơ. */
@Composable
fun TitleChip(t: ChessTitle, modifier: Modifier = Modifier) {
    val c = titleColor(t)
    Text(
        "🎖 ${t.abbr}", color = c, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.16f))
            .border(1.dp, c.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

/** Đăng ký danh hiệu CM / FM / GM: phải đủ Elo và đã mở các thành tựu yêu cầu; đăng ký xong huy hiệu hiện trên hồ sơ. */
@Composable
fun TitlesScreen(vm: GameViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = TitleStore.get(ctx)
    val current by store.title.collectAsState()
    val states by AchievementStore.get(ctx).states.collectAsState()
    val done = states.filter { it.done }.map { it.def.id }.toSet()
    val bestElo = UserSessionManager.profile(ctx, vm.stats, withHistory = false).bestElo

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE))
            }
            Text(
                "Đăng ký danh hiệu", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                maxLines = 1, modifier = Modifier.align(Alignment.Center),
            )
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "intro") {
                Text(
                    "Đạt đủ Elo và mở các thành tựu bên dưới để đăng ký. Đăng ký xong, huy hiệu danh hiệu hiện trên hồ sơ của bạn. Elo hiện tại (cao nhất 3 thể loại): $bestElo.",
                    color = Color(0xFFB9C1CE), fontSize = 14.sp,
                )
            }
            items(ChessTitle.values().toList(), key = { it.key }) { t ->
                val reqs = TitleRules.requirements(t, bestElo, done)
                val ok = reqs.all { it.met }
                val owned = current != null && current!!.rank >= t.rank
                val c = titleColor(t)
                GlassSection("${t.abbr} · ${t.fullName.uppercase()}") {
                    for (r in reqs) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (r.met) "✅" else "⬜", fontSize = 18.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.label, color = if (r.met) Color.White else Color(0xFFB9C1CE), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                if (r.detail.isNotEmpty()) Text(r.detail, color = Color(0xFF8A94A6), fontSize = 12.sp)
                            }
                        }
                    }
                    val enabled = ok && !owned
                    Box(
                        Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (enabled) c else Color(0xFF3A3F4B))
                            .clickable(enabled = enabled) {
                                val err = store.register(t, bestElo, done)
                                if (err == null) UserSessionManager.requestSync(ctx, delayMs = 0)   // đẩy huy hiệu lên Supabase để bạn bè thấy
                                Toast.makeText(ctx, err ?: "Đã đăng ký danh hiệu ${t.abbr} 🎖", Toast.LENGTH_SHORT).show()
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            when {
                                owned && current == t -> "✔ Đang hiển thị trên hồ sơ"
                                owned -> "Đã có danh hiệu cao hơn"
                                ok -> "Đăng ký ${t.abbr}"
                                else -> "Chưa đủ điều kiện"
                            },
                            color = if (enabled) Color(0xFF1B1B1B) else Color(0xFFB9C1CE),
                            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}
