package com.vila.chess.magic

import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.moveUci

/**
 * Hành động của người chơi dạng chuỗi ngắn — dùng để đồng bộ ván Cờ Phép Thuật ONLINE.
 * Ván là hàm tất định của (hạt giống, chuỗi hành động): hai máy cùng chạy lại chuỗi này sẽ có đúng cùng thế cờ, bài và mana.
 *
 *  - `o<i>`            nhận lá thứ i (0..2) trong 3 lá mở ra
 *  - `s`               bỏ qua 3 lá, nhận +2 mana
 *  - `r<h>`            tái chế lá thứ h trên tay thành +2 mana
 *  - `c<h>:<t1>,<t2>`  dùng lá thứ h với các ô mục tiêu (có thể rỗng: `c3:`)
 *  - `m<uci>`          đi một nước cờ (vd `m e2e4` viết liền: `me2e4`, phong cấp `me7e8q`)
 */
object MagicActions {
    private val PATTERN = Regex("^(o[0-9]|s|r[0-9]|m[a-h][1-8][a-h][1-8][qrbn]?|c[0-9]{1,2}:([0-9]{1,2}(,[0-9]{1,2}){0,3})?)$")

    fun take(index: Int) = "o$index"
    const val SKIP = "s"
    fun recycle(handIndex: Int) = "r$handIndex"
    fun move(uci: String) = "m$uci"
    fun cast(handIndex: Int, targets: List<Int>) = "c$handIndex:" + targets.joinToString(",")

    fun isValid(action: String): Boolean = PATTERN.matches(action)

    /** 'w' nếu Trắng đang có lượt, 'b' nếu Đen. */
    fun sideToMove(g: MagicGame): Char = if (g.whiteToMove) 'w' else 'b'

    /** "1-0" | "0-1" | "1/2-1/2" nếu ván đã kết thúc theo luật, ngược lại null. */
    fun resultCode(g: MagicGame): String? = when (val r = g.result) {
        is MagicResult.Win -> if (r.white) "1-0" else "0-1"
        is MagicResult.Draw -> "1/2-1/2"
        null -> null
    }

    /** Áp dụng một hành động lên [g]. Trả null nếu thành công, ngược lại là lý do bị từ chối (ván không đổi). */
    fun apply(g: MagicGame, action: String): String? {
        if (!isValid(action)) return "Hành động không hợp lệ"
        return when (action[0]) {
            'o' -> g.takeOffer(action.substring(1).toInt())
            's' -> g.skipOffer()
            'r' -> g.recycle(action.substring(1).toInt())
            'c' -> {
                val colon = action.indexOf(':')
                val hand = action.substring(1, colon).toInt()
                val body = action.substring(colon + 1)
                val targets = if (body.isEmpty()) emptyList() else body.split(',').map { it.toInt() }
                g.castSpell(hand, targets)
            }
            'm' -> {
                val uci = action.substring(1)
                val mv = g.allowedMoves().firstOrNull { moveUci(it) == uci }
                when {
                    mv == null -> "Nước đi không hợp lệ"
                    g.playMove(mv) -> null
                    else -> "Nước đi bị từ chối"
                }
            }
            else -> "Hành động không hợp lệ"
        }
    }

    /** Dựng ván từ hạt giống + chuỗi hành động. Dừng ở hành động đầu tiên bị từ chối: trả (ván, số hành động đã áp dụng, lý do). */
    fun replay(seed: Long, actions: List<String>, tier: MembershipTier = MembershipTier.FREE): Replay {
        val g = MagicGame(seed, tier)
        var applied = 0
        for (a in actions) {
            val err = apply(g, a)
            if (err != null) return Replay(g, applied, err)
            applied++
        }
        return Replay(g, applied, null)
    }

    class Replay(val game: MagicGame, val applied: Int, val error: String?)
}
