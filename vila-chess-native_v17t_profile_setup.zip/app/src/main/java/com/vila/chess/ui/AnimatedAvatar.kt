package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

// =============================================================================
// Avatar chuyển động cho người chơi / bot trong ván cờ
//
// Không đổi file ảnh: bọc bất kỳ avatar nào (VectorDrawable của bot, ảnh hồ sơ, chữ cái đầu) bằng các chuyển động
// vẽ ở tầng graphicsLayer. Giá trị animation chỉ được ĐỌC trong khối graphicsLayer / draw => KHÔNG làm vẽ lại
// (recomposition) cả cây giao diện nên rất nhẹ, chạy ổn trên máy yếu.
//
//   • Thở: phóng to / thu nhỏ rất nhẹ + nhấp nhô ~1dp, chu kỳ hơi khác nhau giữa hai bên để không đồng bộ.
//   • Đến lượt (active): nghiêng đầu qua lại nhẹ + vòng sáng xanh nhấp nháy quanh avatar.
//   • Phản ứng (reaction): HAPPY = nhảy lên + phồng nhẹ (vừa ăn quân / thắng); SHAKE = rung ngang (bị chiếu / thua).
//     Đổi reactionKey (tăng lên) để kích hoạt lại phản ứng.
// =============================================================================

internal enum class AvatarReaction { NONE, HAPPY, SHAKE }

private val RingColor = Color(0xFF81B64C)

@Composable
internal fun AnimatedAvatarFrame(
    modifier: Modifier = Modifier,
    /** 0 / 1: hai bên dùng chu kỳ thở khác nhau. */
    seed: Int = 0,
    /** Đang đến lượt / đang nghĩ: nghiêng đầu + vòng sáng. */
    active: Boolean = false,
    reaction: AvatarReaction = AvatarReaction.NONE,
    /** Tăng giá trị này để chạy lại phản ứng (kể cả khi reaction giữ nguyên). */
    reactionKey: Int = 0,
    /** Hình dạng của vòng sáng (trùng hình dạng avatar bên trong). */
    ringShape: Shape,
    content: @Composable () -> Unit,
) {
    val inf = rememberInfiniteTransition(label = "avatarInf")
    val breath = inf.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2300 + 650 * (seed and 1), easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breath",
    )
    val sway = inf.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "sway",
    )
    val glow = inf.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow",
    )
    val activeF = animateFloatAsState(if (active) 1f else 0f, tween(250), label = "activeF")

    // Phản ứng: progress chạy 0 → 1 mỗi lần reactionKey đổi.
    val progress = remember { Animatable(1f) }
    val reactionNow by rememberUpdatedState(reaction)
    LaunchedEffect(reactionKey) {
        if (reactionKey > 0 && reactionNow != AvatarReaction.NONE) {
            progress.snapTo(0f)
            progress.animateTo(1f, tween(if (reactionNow == AvatarReaction.HAPPY) 620 else 520, easing = LinearOutSlowInEasing))
        }
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                val b = breath.value
                val a = activeF.value
                val p = progress.value
                var sc = 1f + 0.03f * b
                var ty = -1.2.dp.toPx() * b
                var tx = 0f
                val rot = sway.value * 3f * a
                if (p < 1f) {
                    val wave = sin(p * PI.toFloat())
                    if (reactionNow == AvatarReaction.HAPPY) {
                        ty -= 7.dp.toPx() * wave
                        sc += 0.12f * wave
                    } else if (reactionNow == AvatarReaction.SHAKE) {
                        tx = sin(p * PI.toFloat() * 7f) * 3.5.dp.toPx() * (1f - p)
                    }
                }
                scaleX = sc
                scaleY = sc
                translationX = tx
                translationY = ty
                rotationZ = rot
            }
            .drawWithContent {
                drawContent()
                val a = activeF.value
                if (a > 0.01f) {
                    val outline = ringShape.createOutline(size, layoutDirection, this)
                    drawOutline(
                        outline = outline,
                        color = RingColor.copy(alpha = 0.85f * glow.value * a),
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }
            },
    ) {
        content()
    }
}
