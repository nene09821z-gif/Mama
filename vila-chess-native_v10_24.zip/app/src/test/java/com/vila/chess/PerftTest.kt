package com.vila.chess

import com.vila.chess.core.MAX_MOVES
import com.vila.chess.core.Position
import org.junit.Assert.assertEquals
import org.junit.Test

class PerftTest {
    private fun perft(p: Position, depth: Int): Long {
        if (depth == 0) return 1L
        val buf = IntArray(MAX_MOVES)
        val n = p.generateLegal(buf)
        if (depth == 1) return n.toLong()
        var total = 0L
        for (i in 0 until n) {
            p.make(buf[i])
            total += perft(p, depth - 1)
            p.unmake()
        }
        return total
    }

    private fun check(fen: String, expected: LongArray) {
        val p = Position.fromFen(fen)
        for (i in expected.indices) {
            assertEquals("perft(" + (i + 1) + ") of " + fen, expected[i], perft(p, i + 1))
        }
        assertEquals("position must be restored after perft", fen, p.fen())
    }

    @Test
    fun startPosition() = check(
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        longArrayOf(20, 400, 8902, 197281)
    )

    @Test
    fun kiwipete() = check(
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        longArrayOf(48, 2039, 97862)
    )

    @Test
    fun position3EnPassantAndPins() = check(
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        longArrayOf(14, 191, 2812, 43238)
    )

    @Test
    fun position4PromotionsAndCastling() = check(
        "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
        longArrayOf(6, 264, 9467)
    )

    @Test
    fun position5() = check(
        "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
        longArrayOf(44, 1486, 62379)
    )

    @Test
    fun position6() = check(
        "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
        longArrayOf(46, 2079, 89890)
    )
}
