package com.vila.chess

import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.START_FEN
import com.vila.chess.core.generatePseudoCopyForPremove
import com.vila.chess.core.moveUci
import com.vila.chess.game.EndReason
import com.vila.chess.game.GameSession
import com.vila.chess.game.Outcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private fun GameSession.playUci(uci: String) {
    for (m in legalMoves()) {
        if (moveUci(m) == uci) {
            play(m)
            return
        }
    }
    throw AssertionError("illegal move " + uci + " in " + position.fen())
}

class RulesTest {
    @Test
    fun fenRoundTrip() {
        assertEquals(START_FEN, Position.fromFen(START_FEN).fen())
        val s = GameSession()
        s.playUci("e2e4")
        assertEquals("rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1", s.position.fen())
    }

    @Test
    fun sanSequence() {
        val s = GameSession()
        for (u in listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6", "b5a4", "g8f6", "e1g1")) s.playUci(u)
        val sans = s.records.map { it.san }
        assertEquals(listOf("e4", "e5", "Nf3", "Nc6", "Bb5", "a6", "Ba4", "Nf6", "O-O"), sans)
    }

    @Test
    fun sanDisambiguationAndPromotion() {
        val s = GameSession("4k3/8/8/8/8/8/8/R6R w - - 0 1")
        s.playUci("a1d1")
        assertEquals("Rad1", s.records[0].san)

        val p = GameSession("1n2k3/P7/8/8/8/8/8/4K3 w - - 0 1")
        val m = p.findMove(48, 57, QUEEN)
        assertTrue(m >= 0)
        p.play(m)
        assertEquals("axb8=Q+", p.records[0].san)
    }

    @Test
    fun foolsMate() {
        val s = GameSession()
        for (u in listOf("f2f3", "e7e5", "g2g4", "d8h4")) s.playUci(u)
        assertEquals(Outcome.BLACK_WINS, s.outcome)
        assertEquals(EndReason.CHECKMATE, s.reason)
        assertEquals("Qh4#", s.records[3].san)
    }

    @Test
    fun stalemateAtStart() {
        val s = GameSession("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
        assertEquals(Outcome.DRAW, s.outcome)
        assertEquals(EndReason.STALEMATE, s.reason)
    }

    @Test
    fun threefoldRepetition() {
        val s = GameSession()
        repeat(2) {
            for (u in listOf("g1f3", "g8f6", "f3g1", "f6g8")) s.playUci(u)
        }
        assertEquals(Outcome.DRAW, s.outcome)
        assertEquals(EndReason.REPETITION, s.reason)
    }

    @Test
    fun undoRestoresPosition() {
        val s = GameSession()
        s.playUci("e2e4")
        s.playUci("c7c5")
        assertTrue(s.undo())
        assertTrue(s.undo())
        assertEquals(START_FEN, s.position.fen())
        assertEquals(20, s.legalMoves().size)
        assertFalse(s.undo())
    }

    @Test
    fun insufficientMaterial() {
        assertTrue(Position.fromFen("8/8/8/8/8/8/8/K1k5 w - - 0 1").insufficientMaterial())
        assertTrue(Position.fromFen("8/8/8/8/8/8/8/KBk5 w - - 0 1").insufficientMaterial())
        assertFalse(Position.fromFen("8/8/8/8/8/8/P7/K1k5 w - - 0 1").insufficientMaterial())
    }

    @Test
    fun castlingRightsAndEnPassant() {
        val s = GameSession("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        s.playUci("a1a2")
        assertEquals("r3k2r/8/8/8/8/8/R7/4K2R b Kkq - 1 1", s.position.fen())
        val ep = GameSession("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 1")
        ep.playUci("e5d6")
        assertEquals("4k3/8/3P4/8/8/8/8/4K3 b - - 0 1", ep.position.fen())
    }

    @Test
    fun premoveTargetsIgnoreSideToMove() {
        val start = Position.fromFen(START_FEN)
        // it is White's turn, yet Black may pre-select its moves: 16 pawn moves + 4 knight moves
        assertEquals(20, generatePseudoCopyForPremove(start, false).size)
        assertEquals(START_FEN, start.fen())
    }
}
