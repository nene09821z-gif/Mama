package com.vila.chess

import com.vila.chess.core.START_FEN
import com.vila.chess.review.EngineResult
import com.vila.chess.review.GameReview
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.MoveReview
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewJson
import com.vila.chess.review.ReviewReplay
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReviewDataTest {

    private val foolsMate = listOf("f2f3", "e7e5", "g2g4", "d8h4")

    /** Ván test: engine giả (điểm theo góc nhìn bên đang đi), thế cuối tính bằng luật cờ. */
    private fun fakeGame(engine: String, multiPv: Int): GameReview {
        val replay = ReviewReplay.replay(START_FEN, foolsMate)!!
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
        val scoresStm = listOf(20, -30, 40, -900)
        val evals = fens.mapIndexed { i, fen ->
            ReviewReplay.terminalEval(fen) ?: EngineResult(
                bestMove = "e2e4", scoreCp = scoresStm[i], mate = null, depthReached = 12,
                timedOut = false, pv = listOf("e2e4", "e7e5", "g1f3"),
                secondMove = if (multiPv >= 2) "d2d4" else null,
                secondCp = if (multiPv >= 2) scoresStm[i] - 15 else null,
                secondMate = null, engine = engine, multiPv = multiPv,
            )
        }
        return ReviewAssembler.assemble("g1", replay.startFen, replay.plies, evals, "MEDIUM", 123L)
    }

    @Test
    fun jsonHasAllFields() {
        val review = fakeGame("native", 2)
        val root = JSONObject(ReviewJson.encode(review))
        assertEquals(ReviewJson.CURRENT_VERSION, root.getInt("version"))
        assertEquals("native", root.getString("engine"))
        assertEquals(2, root.getInt("mpv"))
        val m0 = root.getJSONArray("moves").getJSONObject(0)
        for (k in listOf(
            "ply", "white", "label", "loss", "eval", "best", "uci", "san", "fenB", "fenA",
            "evalB", "mateB", "mateA", "pv", "depthB", "depthA", "best2", "eval2", "mate2", "engine", "mpv",
        )) assertTrue("thiếu khóa $k", m0.has(k))

        val back = ReviewJson.decode(ReviewJson.encode(review))
        assertEquals(review, back)
    }

    @Test
    fun moveFieldsAreWhitePerspective() {
        val r = fakeGame("native", 2)
        assertEquals(4, r.moves.size)
        val m1 = r.moves[0]
        assertEquals("f2f3", m1.uci)
        assertEquals("f3", m1.san)
        assertEquals(START_FEN, m1.fenBefore)
        assertEquals(20, m1.evalBeforeCpWhite)
        assertEquals(30, m1.evalAfterCpWhite) // sau f3 đến lượt Đen: -30 theo Đen = +30 theo Trắng
        assertEquals("e2e4", m1.bestMoveBefore)
        assertEquals(listOf("e2e4", "e7e5", "g1f3"), m1.pv)
        assertEquals("d2d4", m1.secondBestMove)
        assertEquals(5, m1.secondBestCpWhite)
        assertEquals(12, m1.depthBefore)
        // Nước 2 là của Đen: điểm nước tốt nhì đổi dấu sang góc nhìn Trắng.
        assertEquals(-(-30 - 15), r.moves[1].secondBestCpWhite)
    }

    @Test
    fun finalCheckmateIsMateZero() {
        val last = fakeGame("native", 2).moves.last()
        assertEquals("Qh4#", last.san)
        assertEquals(0, last.mateAfterWhite)
        assertEquals(-10_000, last.evalAfterCpWhite)
        assertEquals(0, last.depthAfter)
    }

    @Test
    fun wasmHasNoMultiPvData() {
        val r = fakeGame("wasm", 1)
        assertEquals("wasm", r.engine)
        assertEquals(1, r.multiPv)
        r.moves.forEach {
            assertNull(it.secondBestMove)
            assertNull(it.secondBestCpWhite)
            assertEquals(1, it.multiPv)
            assertEquals("wasm", it.engine)
        }
        val back = ReviewJson.decode(ReviewJson.encode(r))!!
        assertNull(back.moves[0].secondBestMove)
    }

    @Test
    fun readsVersion1File() {
        val v1 = """
            {"gameId":"old","accW":88.5,"accB":71.0,"tier":"LOW","createdAt":1700000000000,
             "moves":[
               {"ply":1,"white":true,"label":"BEST","loss":0.4,"eval":25,"best":"e2e4"},
               {"ply":2,"white":false,"label":"BLUNDER","loss":35.0,"eval":310,"best":null}
             ]}
        """.trimIndent()
        val r = ReviewJson.decode(v1)
        assertNotNull(r)
        requireNotNull(r)
        assertEquals(1, r.version)
        assertEquals("old", r.gameId)
        assertEquals(2, r.moves.size)
        assertEquals(MoveLabel.BLUNDER, r.moves[1].label)
        assertNull(r.moves[1].bestMoveBefore)
        assertNull(r.moves[0].uci)
        assertNull(r.moves[0].fenBefore)
        assertNull(r.moves[0].evalBeforeCpWhite)
        assertTrue(r.moves[0].pv.isEmpty())
        assertEquals(MoveReview.ENGINE_UNKNOWN, r.moves[0].engine)
        assertEquals(MoveReview.ENGINE_UNKNOWN, r.engine)
    }

    @Test
    fun corruptFileReturnsNull() {
        assertNull(ReviewJson.decode("{not json"))
        assertNull(ReviewJson.decode("{\"gameId\":\"x\"}"))
    }

    @Test
    fun terminalEvalDetectsMateAndStalemate() {
        val mated = ReviewReplay.terminalEval("rnb1kbnr/pppp1ppp/8/4p3/6Pq/5P2/PPPPP2P/RNBQKBNR w KQkq - 1 3")!!
        assertEquals(0, mated.mate)
        assertEquals(-10_000, mated.scoreCp)
        val stale = ReviewReplay.terminalEval("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")!!
        assertNull(stale.mate)
        assertEquals(0, stale.scoreCp)
        assertNull(ReviewReplay.terminalEval(START_FEN))
    }

    @Test
    fun queueFormatsRoundTripAndLegacy() {
        val q = ReviewReplay.encodeQueue(START_FEN, foolsMate)
        val a = ReviewReplay.parseQueue(q.lines())!!
        assertEquals(4, a.plies.size)
        assertEquals("Qh4#", a.plies.last().san)

        // Định dạng cũ: mỗi dòng một FEN.
        val fens = listOf(a.startFen) + a.plies.map { it.fenAfter }
        val legacy = ReviewReplay.parseQueue(fens)!!
        assertEquals(a.plies.map { it.uci }, legacy.plies.map { it.uci })

        assertNull(ReviewReplay.parseQueue(listOf("#v2", START_FEN, "e2e5")))
        assertNull(ReviewReplay.parseQueue(emptyList()))
    }
}
