package com.vila.chess

import com.vila.chess.core.Engine
import com.vila.chess.core.Position
import com.vila.chess.core.SearchLimits
import com.vila.chess.core.moveUci
import com.vila.chess.game.GameSession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {
    @Test
    fun findsMateInOne() {
        val p = Position.fromFen("6k1/5ppp/8/8/8/8/5PPP/4R1K1 w - - 0 1")
        val m = Engine().findBestMove(p, SearchLimits(3, 3000, 0))
        assertEquals("e1e8", moveUci(m))
    }

    @Test
    fun winsHangingQueen() {
        val p = Position.fromFen("4k3/8/8/3q4/8/8/8/3RK3 w - - 0 1")
        val m = Engine().findBestMove(p, SearchLimits(3, 3000, 0))
        assertEquals("d1d5", moveUci(m))
    }

    @Test
    fun searchLeavesPositionUntouched() {
        val p = Position.fromFen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1")
        val before = p.fen()
        Engine().findBestMove(p, SearchLimits(3, 3000, 0))
        assertEquals(before, p.fen())
    }

    @Test
    fun selfPlayOnlyProducesLegalMoves() {
        val s = GameSession()
        var plies = 0
        while (!s.isOver && plies < 60) {
            val m = Engine().findBestMove(s.position, SearchLimits(2, 400, 60))
            assertTrue("engine returned no move in " + s.position.fen(), m != 0)
            var legal = false
            for (l in s.legalMoves()) if (l == m) legal = true
            assertTrue("illegal engine move " + moveUci(m) + " in " + s.position.fen(), legal)
            s.play(m)
            plies++
        }
        assertTrue(plies > 0)
    }

    @Test
    fun evaluationIsSymmetric() {
        val e = Engine()
        val white = e.evaluate(Position.fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"))
        val black = e.evaluate(Position.fromFen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR b KQkq - 0 1"))
        assertEquals(white, black)
    }
}
