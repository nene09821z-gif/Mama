package com.vila.chess.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClient.BillingResponseCode
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.acknowledgePurchase
import com.android.billingclient.api.queryProductDetails
import com.android.billingclient.api.queryPurchasesAsync
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

/** Một lựa chọn mua: (gói, chu kỳ) cùng giá do Google Play trả về (đã theo tiền tệ/quốc gia người dùng). */
data class PlanOption(
    val tier: MembershipTier,
    val period: BillingPeriod,
    val productDetails: ProductDetails,
    val offerToken: String,
    val formattedPrice: String,
    val priceMicros: Long,
    val currencyCode: String,
)

enum class BillingError {
    NETWORK,              // mất mạng / Play Store không phản hồi
    BILLING_UNAVAILABLE,  // máy không có Google Play hoặc không hỗ trợ
    PRODUCT_UNAVAILABLE,  // chưa tạo / chưa active sản phẩm trên Play Console
    PAYMENT_FAILED,       // thanh toán bị từ chối
    VERIFY_FAILED,        // server từ chối biên lai (nghi gian lận)
    UNKNOWN,
}

sealed interface BillingEvent {
    data class PurchaseSuccess(val tier: MembershipTier) : BillingEvent
    object Cancelled : BillingEvent
    object Pending : BillingEvent
    data class Failed(val error: BillingError) : BillingEvent
}

class BillingException(val error: BillingError) : Exception(error.name)

/**
 * Quản lý BillingClient (Play Billing Library 7.x): kết nối, truy vấn gói, mua, xác nhận (acknowledge),
 * đồng bộ quyền lợi. Dùng singleton qua [get]; gọi [refreshEntitlements] khi app khởi động và khi quay lại foreground.
 */
class BillingRepository private constructor(context: Context) : PurchasesUpdatedListener {
    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val store = MembershipStore.get(appContext)
    private val verifier: PurchaseVerifier? =
        BillingCatalog.VERIFY_ENDPOINT.takeIf { it.isNotBlank() }?.let { HttpPurchaseVerifier(it) }

    private val _plans = MutableStateFlow<List<PlanOption>>(emptyList())
    val plans: StateFlow<List<PlanOption>> = _plans.asStateFlow()

    private val _events = MutableSharedFlow<BillingEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<BillingEvent> = _events.asSharedFlow()

    /** Gói đang đăng ký (nếu có) — cần để nâng/hạ cấp đúng cách thay vì mua thêm gói thứ hai. */
    private var currentSub: Purchase? = null

    private val client: BillingClient = BillingClient.newBuilder(appContext)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    private val connectLock = Mutex()

    // ---------------------------------------------------------------- kết nối

    private suspend fun ensureConnected(): Boolean = connectLock.withLock {
        if (client.isReady) return@withLock true
        suspendCancellableCoroutine<Boolean> { cont ->
            client.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(result: BillingResult) {
                    if (cont.isActive) cont.resume(result.responseCode == BillingResponseCode.OK)
                }

                // Lần gọi tiếp theo của ensureConnected() sẽ tự kết nối lại.
                override fun onBillingServiceDisconnected() {
                    if (cont.isActive) cont.resume(false)
                }
            })
        }
    }

    // ---------------------------------------------------------------- truy vấn gói

    suspend fun loadPlans(): Result<List<PlanOption>> {
        return try {
            if (!ensureConnected()) return Result.failure(BillingException(BillingError.BILLING_UNAVAILABLE))
            val products = BillingCatalog.productIds.map {
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(it)
                    .setProductType(BillingClient.ProductType.SUBS)
                    .build()
            }
            val result = client.queryProductDetails(
                QueryProductDetailsParams.newBuilder().setProductList(products).build()
            )
            val code = result.billingResult.responseCode
            if (code != BillingResponseCode.OK) return Result.failure(BillingException(mapError(code)))
            val options = result.productDetailsList.orEmpty().flatMap { toOptions(it) }
            if (options.isEmpty()) return Result.failure(BillingException(BillingError.PRODUCT_UNAVAILABLE))
            _plans.value = options
            Result.success(options)
        } catch (e: Exception) {
            Result.failure(BillingException(BillingError.UNKNOWN))
        }
    }

    private fun toOptions(pd: ProductDetails): List<PlanOption> {
        val tier = BillingCatalog.tierOf(pd.productId) ?: return emptyList()
        return pd.subscriptionOfferDetails.orEmpty().mapNotNull { offer ->
            if (offer.offerId != null) return@mapNotNull null // bỏ qua offer khuyến mãi; chỉ lấy base plan
            val period = BillingPeriod.values().firstOrNull { it.basePlanId == offer.basePlanId }
                ?: return@mapNotNull null
            val phase = offer.pricingPhases.pricingPhaseList.lastOrNull() ?: return@mapNotNull null
            PlanOption(tier, period, pd, offer.offerToken, phase.formattedPrice, phase.priceAmountMicros, phase.priceCurrencyCode)
        }
    }

    // ---------------------------------------------------------------- mua

    /** Mở màn hình thanh toán của Google. Kết quả đến qua [events] (và [onPurchasesUpdated]). */
    suspend fun launchPurchase(activity: Activity, option: PlanOption): Boolean {
        if (!ensureConnected()) {
            _events.tryEmit(BillingEvent.Failed(BillingError.NETWORK))
            return false
        }
        val detailsParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(option.productDetails)
            .setOfferToken(option.offerToken)
            .build()
        val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(detailsParams))

        // Đang có gói khác → đổi gói (không tạo thêm subscription thứ hai).
        currentSub?.let { old ->
            val oldTier = old.products.mapNotNull { BillingCatalog.tierOf(it) }.maxByOrNull { it.rank }
            val mode = if (oldTier != null && option.tier.rank < oldTier.rank) {
                BillingFlowParams.SubscriptionUpdateParams.ReplacementMode.DEFERRED
            } else {
                BillingFlowParams.SubscriptionUpdateParams.ReplacementMode.CHARGE_PRORATED_PRICE
            }
            flow.setSubscriptionUpdateParams(
                BillingFlowParams.SubscriptionUpdateParams.newBuilder()
                    .setOldPurchaseToken(old.purchaseToken)
                    .setSubscriptionReplacementMode(mode)
                    .build()
            )
        }
        val result = client.launchBillingFlow(activity, flow.build())
        if (result.responseCode != BillingResponseCode.OK) {
            _events.tryEmit(BillingEvent.Failed(mapError(result.responseCode)))
            return false
        }
        return true
    }

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingResponseCode.OK -> scope.launch { applyPurchases(purchases.orEmpty(), authoritative = false) }
            BillingResponseCode.USER_CANCELED -> _events.tryEmit(BillingEvent.Cancelled)
            BillingResponseCode.ITEM_ALREADY_OWNED -> scope.launch { refreshEntitlements() }
            else -> _events.tryEmit(BillingEvent.Failed(mapError(result.responseCode)))
        }
    }

    // ---------------------------------------------------------------- quyền lợi

    /** Hỏi Google Play gói nào đang hiệu lực. Offline → giữ nguyên gói đã lưu (không hạ về FREE oan). */
    suspend fun refreshEntitlements() {
        try {
            if (!ensureConnected()) return
            val result = client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
            )
            if (result.billingResult.responseCode != BillingResponseCode.OK) return
            applyPurchases(result.purchasesList, authoritative = true)
        } catch (_: Exception) {
            // giữ nguyên trạng thái cũ
        }
    }

    /** Khôi phục giao dịch (đổi máy, cài lại app). */
    suspend fun restore(): Boolean {
        refreshEntitlements()
        val tier = store.tier.value
        if (tier != MembershipTier.FREE) _events.tryEmit(BillingEvent.PurchaseSuccess(tier))
        return tier != MembershipTier.FREE
    }

    /**
     * @param authoritative true khi [purchases] là danh sách ĐẦY ĐỦ từ Play (rỗng nghĩa là hết hạn → FREE);
     * false khi chỉ là giao dịch vừa phát sinh (không được hạ gói).
     */
    private suspend fun applyPurchases(purchases: List<Purchase>, authoritative: Boolean) {
        var best: MembershipTier? = null
        var newest: Purchase? = null
        for (p in purchases) {
            val tier = p.products.mapNotNull { BillingCatalog.tierOf(it) }.maxByOrNull { it.rank } ?: continue
            when (p.purchaseState) {
                Purchase.PurchaseState.PURCHASED -> {
                    if (!verifyAndAcknowledge(p)) {
                        _events.tryEmit(BillingEvent.Failed(BillingError.VERIFY_FAILED))
                        continue
                    }
                    if (best == null || tier.rank > best.rank) {
                        best = tier
                        newest = p
                    }
                }
                Purchase.PurchaseState.PENDING -> _events.tryEmit(BillingEvent.Pending) // chưa cấp quyền lợi
                else -> Unit
            }
        }
        if (authoritative) currentSub = newest
        else if (newest != null) currentSub = newest

        if (best != null) {
            val changed = store.tier.value != best
            store.set(best)
            if (!authoritative || changed) _events.tryEmit(BillingEvent.PurchaseSuccess(best))
        } else if (authoritative) {
            store.set(MembershipTier.FREE)
        }
    }

    /** @return true nếu được cấp quyền lợi. Chưa acknowledge trong 3 ngày thì Google tự hoàn tiền. */
    private suspend fun verifyAndAcknowledge(p: Purchase): Boolean {
        val v = verifier
        if (v != null) {
            when (v.verify(appContext.packageName, p.products.first(), p.purchaseToken)) {
                VerifyResult.INVALID -> return false
                VerifyResult.UNREACHABLE -> return true // đã được Play ký; chưa acknowledge, sẽ thử lại lần refresh sau
                VerifyResult.VALID -> Unit
            }
        }
        if (!p.isAcknowledged) {
            val r = client.acknowledgePurchase(
                AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()
            )
            if (r.responseCode != BillingResponseCode.OK) {
                // Không acknowledge được: vẫn cấp quyền (đã trả tiền), lần refresh sau sẽ thử lại.
            }
        }
        return true
    }

    private fun mapError(code: Int): BillingError = when (code) {
        BillingResponseCode.SERVICE_UNAVAILABLE,
        BillingResponseCode.NETWORK_ERROR,
        BillingResponseCode.SERVICE_DISCONNECTED,
        BillingResponseCode.SERVICE_TIMEOUT -> BillingError.NETWORK
        BillingResponseCode.BILLING_UNAVAILABLE,
        BillingResponseCode.FEATURE_NOT_SUPPORTED -> BillingError.BILLING_UNAVAILABLE
        BillingResponseCode.ITEM_UNAVAILABLE -> BillingError.PRODUCT_UNAVAILABLE
        BillingResponseCode.ERROR -> BillingError.PAYMENT_FAILED
        else -> BillingError.UNKNOWN
    }

    companion object {
        @Volatile private var instance: BillingRepository? = null
        fun get(context: Context): BillingRepository =
            instance ?: synchronized(this) { instance ?: BillingRepository(context).also { instance = it } }
    }
}
