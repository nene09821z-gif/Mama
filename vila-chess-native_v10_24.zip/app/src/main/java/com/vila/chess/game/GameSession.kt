package com.vila.chess.game

import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.makePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.core.moveToSan
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue

enum class Outcome { ONGOING, WHITE_WINS, BLACK_WINS, DRAW }

enum class EndReason { NONE, CHECKMATE, STALEMATE, INSUFFICIENT, FIFTY, REPETITION, TIMEOUT, RESIGN, AGREEMENT }

class MoveRecord(val move: Int, val san: String, val captured: Int, val whiteMoved: Boolean)

/** Pure game logic (no Android classes): rules, history, repetition and end-of-game detection. */
class GameSession(startFen: String = START_FEN) {
    val position: Position = Position.fromFen(startFen)
    val records = ArrayList<MoveRecord>()
    private val keys = ArrayList<String>()
    private var legal: IntArray = IntArray(0)

    var outcome: Outcome = Outcome.ONGOING
        private set
    var reason: EndReason = EndReason.NONE
        private set

    val isOver: Boolean
        get() = outcome != Outcome.ONGOING

    init {
        keys.add(position.repetitionKey())
        refreshLegal()
        if (legal.isEmpty()) endByNoMoves(!position.whiteToMove)
    }

    private fun refreshLegal() {
        legal = position.legalMoves()
    }

    fun legalMoves(): IntArray = legal

    fun movesFrom(sq: Int): List<Int> {
        val out = ArrayList<Int>()
        for (m in legal) if (moveFrom(m) == sq) out.add(m)
        return out
    }

    fun isPromotion(from: Int, to: Int): Boolean {
        for (m in legal) if (moveFrom(m) == from && moveTo(m) == to && movePromo(m) != 0) return true
        return false
    }

    /** Returns the legal move from->to (with the given promotion piece type, 0 if none) or -1. */
    fun findMove(from: Int, to: Int, promo: Int): Int {
        for (m in legal) {
            if (moveFrom(m) == from && moveTo(m) == to && movePromo(m) == promo) return m
        }
        return -1
    }

    fun play(move: Int): MoveRecord {
        val white = position.whiteToMove
        val san = moveToSan(position, move)
        val captured = if (moveFlag(move) == FLAG_EP) {
            makePiece(PAWN, !white)
        } else {
            position.board[moveTo(move)]
        }
        position.make(move)
        keys.add(position.repetitionKey())
        val rec = MoveRecord(move, san, captured, white)
        records.add(rec)
        refreshLegal()
        evaluateEnd(white)
        return rec
    }

    private fun endByNoMoves(moverWhite: Boolean) {
        if (position.inCheck()) {
            outcome = if (moverWhite) Outcome.WHITE_WINS else Outcome.BLACK_WINS
            reason = EndReason.CHECKMATE
        } else {
            outcome = Outcome.DRAW
            reason = EndReason.STALEMATE
        }
    }

    private fun evaluateEnd(moverWhite: Boolean) {
        if (legal.isEmpty()) {
            endByNoMoves(moverWhite)
            return
        }
        if (position.insufficientMaterial()) {
            outcome = Outcome.DRAW
            reason = EndReason.INSUFFICIENT
            return
        }
        if (position.halfmove >= 100) {
            outcome = Outcome.DRAW
            reason = EndReason.FIFTY
            return
        }
        val key = keys[keys.size - 1]
        var count = 0
        for (k in keys) if (k == key) count++
        if (count >= 3) {
            outcome = Outcome.DRAW
            reason = EndReason.REPETITION
        }
    }

    fun undo(): Boolean {
        if (records.isEmpty()) return false
        position.unmake()
        records.removeAt(records.size - 1)
        keys.removeAt(keys.size - 1)
        outcome = Outcome.ONGOING
        reason = EndReason.NONE
        refreshLegal()
        return true
    }

    fun resign(whiteResigns: Boolean) {
        if (isOver) return
        outcome = if (whiteResigns) Outcome.BLACK_WINS else Outcome.WHITE_WINS
        reason = EndReason.RESIGN
    }

    fun agreeDraw() {
        if (isOver) return
        outcome = Outcome.DRAW
        reason = EndReason.AGREEMENT
    }

    fun timeout(whiteFlagged: Boolean) {
        if (isOver) return
        reason = EndReason.TIMEOUT
        outcome = if (!position.hasMatingMaterial(!whiteFlagged)) {
            Outcome.DRAW
        } else if (whiteFlagged) {
            Outcome.BLACK_WINS
        } else {
            Outcome.WHITE_WINS
        }
    }

    /** Pieces captured by the given side, most valuable first. */
    fun capturedBy(white: Boolean): List<Int> {
        val out = ArrayList<Int>()
        for (r in records) if (r.whiteMoved == white && r.captured != EMPTY) out.add(r.captured)
        return out.sortedByDescending { pieceValue(pieceType(it)) }
    }
}
