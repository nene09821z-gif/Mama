package com.vila.chess.bots

import android.content.Context
import com.vila.chess.review.DeviceTierManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Thông số làm yếu Stockfish cho một Bot.
 *
 * Lưu ý quan trọng: UCI_Elo của Stockfish chỉ nhận 1320..3190. Giá trị ngoài khoảng bị engine bỏ qua
 * (giữ mặc định 3190 = mạnh tối đa), nên với Bot dưới 1320 Elo ta KHÔNG dùng UCI_LimitStrength mà làm yếu bằng
 * Skill Level thấp + giới hạn depth + thời gian nghĩ ngắn + thỉnh thoảng chọn nước tốt thứ 2/3 (MultiPV).
 */
data class BotTuning(
    val limitStrength: Boolean,
    val uciElo: Int,
    val skill: Int,
    val depthCap: Int,
    val moveTimeMs: Long,
    val multiPv: Int,
    val blunderChance: Double,
    val blunderWindowCp: Int,
) {
    companion object {
        const val UCI_ELO_MIN = 1320
        const val UCI_ELO_MAX = 3190

        /** Skill Level 0..20 tăng tuyến tính theo Elo 250..2800. */
        fun skillFor(elo: Int): Int = (((elo - 250) / 2550.0) * 20.0).roundToInt().coerceIn(0, 20)

        fun forBot(bot: BotProfile): BotTuning {
            val elo = bot.elo
            val skill = skillFor(elo)
            val moveMs = (150 + elo * 0.4).toLong()
            val depthCap = when {
                elo < 500 -> 2
                elo < 800 -> 3
                elo < 1100 -> 5
                elo < 1320 -> 7
                else -> 0
            }
            val weak = elo < UCI_ELO_MIN
            val blunder = if (weak) ((UCI_ELO_MIN - elo) / UCI_ELO_MIN.toDouble() * 0.6) else 0.0
            return BotTuning(
                limitStrength = elo in UCI_ELO_MIN until UCI_ELO_MAX,
                uciElo = elo.coerceIn(UCI_ELO_MIN, UCI_ELO_MAX),
                skill = if (elo >= UCI_ELO_MAX) 20 else skill,
                depthCap = depthCap,
                moveTimeMs = moveMs,
                multiPv = if (weak) 3 else 1,
                blunderChance = blunder,
                blunderWindowCp = if (weak) 150 + (UCI_ELO_MIN - elo) / 4 else 0,
            )
        }
    }
}

/**
 * Quản lý một tiến trình Stockfish native (libstockfish.so) dùng chung cho các Bot.
 * Toàn bộ I/O chạy trên Dispatchers.IO, không chạm UI thread. Một Mutex đảm bảo mỗi lúc chỉ một lệnh
 * cấu hình/tìm nước; huỷ coroutine sẽ gửi `stop` và xả hết dòng cũ nên lượt sau không bị lẫn kết quả.
 */
class BotEngineManager(context: Context) : AutoCloseable {

    private val app = context.applicationContext
    private val mutex = Mutex()
    private var process: Process? = null
    private var writer: BufferedWriter? = null
    private var lines: Channel<String> = Channel(Channel.UNLIMITED)
    private var bot: BotProfile? = null
    private var tuning: BotTuning? = null
    private var optionsApplied = false
    private var needNewGame = true

    private class Cand(val move: String, val cp: Int)

    val isNativeAvailable: Boolean
        get() = File(app.applicationInfo.nativeLibraryDir, BIN).exists()

    /** Đánh dấu ván mới: lần tìm nước kế tiếp sẽ gửi `ucinewgame` (xoá bảng băm). */
    fun newGame() { needNewGame = true }

    /** Gửi các lệnh UCI để Stockfish chơi đúng sức của [bot]. Trả về false nếu không có engine native. */
    suspend fun configureEngineForBot(bot: BotProfile): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            if (!ensureStarted()) return@withContext false
            if (this@BotEngineManager.bot?.id != bot.id) {
                this@BotEngineManager.bot = bot
                optionsApplied = false
            }
            applyOptions(bot)
            sync()
        }
    }

    /**
     * Nước đi (UCI, vd "e2e4") của Bot cho thế = [startFen] + [uciMoves]. Null nếu engine lỗi/không có.
     * [remainingMs] > 0 thì giới hạn thời gian nghĩ theo đồng hồ còn lại.
     */
    suspend fun bestMove(startFen: String, uciMoves: List<String>, remainingMs: Long = -1L): String? =
        mutex.withLock {
            withContext(Dispatchers.IO) {
                if (!ensureStarted()) return@withContext null
                val b = bot ?: return@withContext null
                if (!optionsApplied) applyOptions(b)       // engine vừa khởi động lại giữa ván
                val t = tuning ?: return@withContext null
                if (needNewGame) { send("ucinewgame"); needNewGame = false }
                if (!sync()) return@withContext null

                var ms = t.moveTimeMs
                if (remainingMs > 0) ms = minOf(ms, (remainingMs / 20).coerceAtLeast(120L))
                send("position fen $startFen" + if (uciMoves.isEmpty()) "" else " moves " + uciMoves.joinToString(" "))
                send("go movetime $ms" + if (t.depthCap > 0) " depth ${t.depthCap}" else "")

                val cands = HashMap<Int, Cand>()
                var best: String? = null
                try {
                    best = collect(ms + 2500, cands)
                    if (best == null) {
                        send("stop")
                        best = collect(1500, cands)
                    }
                } catch (e: CancellationException) {
                    withContext(NonCancellable) { send("stop"); collect(800, cands) }
                    throw e
                }
                pickHumanLike(best, cands, t)
            }
        }

    // ---------- nội bộ ----------

    private fun applyOptions(b: BotProfile) {
        val t = BotTuning.forBot(b)
        tuning = t
        send("setoption name UCI_LimitStrength value ${t.limitStrength}")
        if (t.limitStrength) send("setoption name UCI_Elo value ${t.uciElo}")
        send("setoption name Skill Level value ${t.skill}")
        send("setoption name MultiPV value ${t.multiPv}")
        optionsApplied = true
        needNewGame = true
    }

    private fun pickHumanLike(best: String?, cands: Map<Int, Cand>, t: BotTuning): String? {
        if (best == null || t.blunderChance <= 0.0) return best
        if (Random.nextDouble() >= t.blunderChance) return best
        val bestCp = cands[1]?.cp ?: return best
        val alt = cands.filter { it.key > 1 && it.value.cp >= bestCp - t.blunderWindowCp && it.value.cp > -9000 }
            .values.randomOrNull()
        return alt?.move ?: best
    }

    private suspend fun collect(timeoutMs: Long, cands: MutableMap<Int, Cand>): String? =
        withTimeoutOrNull(timeoutMs) {
            var best: String? = null
            var done = false
            while (!done) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith("bestmove")) {
                    best = l.split(' ').getOrNull(1)?.takeIf { it != "(none)" }
                    done = true
                } else {
                    parseInfo(l, cands)
                }
            }
            best
        }

    private fun parseInfo(line: String, cands: MutableMap<Int, Cand>) {
        if (!line.startsWith("info") || " lowerbound" in line || " upperbound" in line) return
        val sc = SCORE.find(line) ?: return
        val pv = PV.find(line)?.groupValues?.get(1)?.trim()?.split(' ')?.firstOrNull() ?: return
        val idx = MULTIPV.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 1
        val v = sc.groupValues[2].toInt()
        val cp = if (sc.groupValues[1] == "mate") (if (v > 0) 10_000 - v else -10_000 - v) else v
        cands[idx] = Cand(pv, cp)
    }

    private suspend fun ensureStarted(): Boolean {
        if (process?.isAlive == true) return true
        stopProcess()
        val bin = File(app.applicationInfo.nativeLibraryDir, BIN)
        if (!bin.exists()) return false
        val p = try {
            ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
        } catch (_: Exception) {
            return false
        }
        val ch = Channel<String>(Channel.UNLIMITED)
        process = p
        writer = p.outputStream.bufferedWriter()
        lines = ch
        Thread {
            try {
                p.inputStream.bufferedReader().forEachLine { ch.trySend(it) }
            } catch (_: IOException) {
            } finally {
                ch.close()
            }
        }.apply { isDaemon = true; name = "bot-engine-reader" }.start()

        send("uci")
        if (!waitFor("uciok", 8_000)) { stopProcess(); return false }
        val cfg = DeviceTierManager.getDeviceTier(app)
        send("setoption name Threads value ${cfg.threads}")
        send("setoption name Hash value ${minOf(cfg.hashMb, 64)}")
        optionsApplied = false
        needNewGame = true
        return sync()
    }

    /** isready/readyok: chắc chắn mọi dòng cũ (kể cả bestmove thừa sau stop) đã được xả. */
    private suspend fun sync(): Boolean {
        while (lines.tryReceive().isSuccess) { /* xả */ }
        send("isready")
        return waitFor("readyok", 3_000)
    }

    private suspend fun waitFor(prefix: String, timeoutMs: Long): Boolean =
        withTimeoutOrNull(timeoutMs) {
            var found = false
            while (!found) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith(prefix)) found = true
            }
            found
        } ?: false

    @Synchronized
    private fun send(cmd: String) {
        runCatching { writer?.apply { write(cmd); newLine(); flush() } }
    }

    private fun stopProcess() {
        val p = process
        val w = writer
        process = null
        writer = null
        if (p == null) return
        Thread {
            runCatching { w?.apply { write("stop"); newLine(); write("quit"); newLine(); flush() } }
            runCatching { if (!p.waitFor(300, java.util.concurrent.TimeUnit.MILLISECONDS)) p.destroy() }
            runCatching { p.destroyForcibly() }
            runCatching { w?.close() }
        }.apply { isDaemon = true }.start()
    }

    /** Giải phóng tiến trình (không chặn UI thread). Gọi lại configure/bestMove sẽ tự khởi động lại. */
    override fun close() {
        stopProcess()
        lines.close()
        bot = null
        optionsApplied = false
    }

    private companion object {
        const val BIN = "libstockfish.so"
        val SCORE = Regex("""\bscore (cp|mate) (-?\d+)""")
        val MULTIPV = Regex("""\bmultipv (\d+)""")
        val PV = Regex(""" pv (.+)$""")
    }
}
