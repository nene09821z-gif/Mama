package com.vila.chess.billing

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Bộ nhớ đệm gói hiện tại (SharedPreferences). Đây chỉ là CACHE để UI mở lên là đúng ngay, kể cả offline;
 * nguồn sự thật là Google Play (qua BillingRepository.refreshEntitlements) và server nếu bạn có.
 */
class MembershipStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_membership", Context.MODE_PRIVATE)
    private val _tier = MutableStateFlow(MembershipTier.fromId(prefs.getString("tier", null)))
    val tier: StateFlow<MembershipTier> = _tier.asStateFlow()

    fun set(tier: MembershipTier) {
        prefs.edit().putString("tier", tier.id).apply()
        _tier.value = tier
    }

    companion object {
        @Volatile private var instance: MembershipStore? = null
        fun get(context: Context): MembershipStore =
            instance ?: synchronized(this) { instance ?: MembershipStore(context).also { instance = it } }
    }
}

/** Đếm lượt dùng theo ngày (giờ máy). Muốn chống chỉnh đồng hồ thì đếm ở server. */
class UsageTracker private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_usage", Context.MODE_PRIVATE)

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun used(q: Quota): Int =
        if (prefs.getString("day_" + q.name, null) == today()) prefs.getInt("n_" + q.name, 0) else 0

    /** null = không giới hạn. */
    fun remaining(q: Quota, tier: MembershipTier): Int? =
        dailyLimit(q, tier)?.let { (it - used(q)).coerceAtLeast(0) }

    fun canUse(q: Quota, tier: MembershipTier): Boolean = remaining(q, tier)?.let { it > 0 } ?: true

    fun consume(q: Quota) {
        prefs.edit()
            .putString("day_" + q.name, today())
            .putInt("n_" + q.name, used(q) + 1)
            .apply()
    }

    companion object {
        @Volatile private var instance: UsageTracker? = null
        fun get(context: Context): UsageTracker =
            instance ?: synchronized(this) { instance ?: UsageTracker(context).also { instance = it } }
    }
}
