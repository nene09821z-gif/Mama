package com.vila.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.review.MoveLabel
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/**
 * Nhãn phân tích kiểu chess.com. Dùng cho cả hiệu ứng bay (loading) lẫn bảng đếm nước đi ở kết quả.
 * "!!" xanh ngọc · "?" cam · "??" đỏ, theo yêu cầu.
 */
enum class LabelBadge(val glyph: String, val color: Color, val title: String) {
    BRILLIANT("!!", Color(0xFF26C2A3), "Xuất sắc nhất"),
    BEST("★", Color(0xFF81B64C), "Nước tốt nhất"),
    EXCELLENT("!", Color(0xFF96BC4B), "Rất tốt"),
    GOOD("✓", Color(0xFFA3B18A), "Tốt"),
    INACCURACY("?!", Color(0xFFF7C631), "Thiếu chính xác"),
    MISTAKE("?", Color(0xFFFFA459), "Sai lầm"),
    BLUNDER("??", Color(0xFFCA3431), "Mắc lỗi nặng"),
}

fun MoveLabel.badge(): LabelBadge = when (this) {
    MoveLabel.BEST -> LabelBadge.BEST
    MoveLabel.EXCELLENT -> LabelBadge.EXCELLENT
    MoveLabel.GOOD -> LabelBadge.GOOD
    MoveLabel.INACCURACY -> LabelBadge.INACCURACY
    MoveLabel.MISTAKE -> LabelBadge.MISTAKE
    MoveLabel.BLUNDER -> LabelBadge.BLUNDER
}

/** Hình tròn có ký hiệu (!!, ?, ??…). */
@Composable
fun LabelGlyph(badge: LabelBadge, size: androidx.compose.ui.unit.Dp = 28.dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(CircleShape).background(badge.color), contentAlignment = Alignment.Center) {
        Text(badge.glyph, color = Color.White, fontSize = (size.value * 0.46f).sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

private class FloatSpec(val badge: LabelBadge, val xFrac: Float, val phase: Float, val delayMs: Long)

private val Specs = listOf(
    FloatSpec(LabelBadge.BRILLIANT, 0.04f, 0.00f, 0),
    FloatSpec(LabelBadge.MISTAKE, 0.52f, 0.17f, 250),
    FloatSpec(LabelBadge.BEST, 0.10f, 0.34f, 500),
    FloatSpec(LabelBadge.BLUNDER, 0.58f, 0.51f, 750),
    FloatSpec(LabelBadge.INACCURACY, 0.28f, 0.68f, 1000),
    FloatSpec(LabelBadge.BRILLIANT, 0.60f, 0.85f, 1250),
)

/**
 * Khu vực nhãn bay lơ lửng + hạt sáng. MỘT InfiniteTransition duy nhất chạy thời gian t (0..1);
 * mỗi nhãn/hạt tự suy ra pha của mình TRONG khối graphicsLayer / draw => không recomposition mỗi frame.
 */
@Composable
fun AnalysisLabelField(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "analysisLabels")
    val t = infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "t",
    )
    BoxWithConstraints(modifier) {
        val travelPx = constraints.maxHeight.toFloat()
        ParticleLayer(t, Modifier.matchParentSize())
        Specs.forEach { sp ->
            AnimatedAnalysisLabel(
                badge = sp.badge, time = t, phase = sp.phase, travelPx = travelPx, delayMs = sp.delayMs,
                modifier = Modifier.offset(x = maxWidth * sp.xFrac),
            )
        }
    }
}

/** Một nhãn: Fade-in + Slide-up lúc xuất hiện (AnimatedVisibility), sau đó trôi từ dưới lên liên tục. */
@Composable
fun AnimatedAnalysisLabel(
    badge: LabelBadge,
    time: State<Float>,
    phase: Float,
    travelPx: Float,
    modifier: Modifier = Modifier,
    delayMs: Long = 0,
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs); shown = true }
    AnimatedVisibility(
        visible = shown,
        modifier = modifier,
        enter = fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 2 },
    ) {
        Row(
            modifier = Modifier
                .graphicsLayer {
                    val p = (time.value + phase) % 1f                  // đọc state ở tầng layer
                    translationY = travelPx + (-size.height - travelPx) * p     // đáy -> đỉnh
                    translationX = sin(2f * PI.toFloat() * (p * 1.5f + phase)) * 10.dp.toPx()
                    rotationZ = sin(2f * PI.toFloat() * (p + phase)) * 4f
                    val pop = (p * 6f).coerceAtMost(1f)
                    scaleX = 0.8f + 0.2f * pop; scaleY = scaleX
                    alpha = sin(PI.toFloat() * p).coerceIn(0f, 1f)             // mờ ở hai đầu hành trình
                }
                .clip(RoundedCornerShape(50))
                .background(Color(0xE6302E2B))
                .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LabelGlyph(badge, 28.dp)
            Spacer(Modifier.width(8.dp))
            Text(badge.title, color = badge.color, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

/** Hạt sáng nhỏ bay lên; toàn bộ tính ở draw phase. */
@Composable
private fun ParticleLayer(time: State<Float>, modifier: Modifier = Modifier) {
    val seeds = remember { List(18) { i -> Triple((i * 0.137f) % 1f, (i * 0.291f) % 1f, 1.5f + (i % 4)) } }
    Canvas(modifier) {
        val t = time.value
        seeds.forEachIndexed { i, (xf, off, r) ->
            val p = (t * (1f + (i % 3) * 0.5f) + off) % 1f
            val a = sin(PI.toFloat() * p).coerceIn(0f, 1f) * 0.55f
            val c = when (i % 3) { 0 -> LabelBadge.BEST.color; 1 -> LabelBadge.BRILLIANT.color; else -> Color.White }
            drawCircle(c.copy(alpha = a), radius = r.dp.toPx(), center = Offset(size.width * xf + sin(p * 6f + i) * 8.dp.toPx(), size.height * (1f - p)))
        }
    }
}
