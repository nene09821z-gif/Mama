package com.vila.chess.bots

import androidx.annotation.DrawableRes
import com.vila.chess.R

/** Hồ sơ một Bot: elo là sức mạnh mục tiêu mà BotEngineManager sẽ ép Stockfish xuống. */
data class BotProfile(
    val id: String,
    val name: String,
    val elo: Int,
    @DrawableRes val avatarResId: Int,
    val description: String,
)

object BotRepository {

    /** Sắp xếp tăng dần theo Elo. */
    val bots: List<BotProfile> = listOf(
        BotProfile("martin", "Martin", 250, R.drawable.bot_martin, "Người mới tập chơi"),
        BotProfile("jimmy", "Jimmy", 600, R.drawable.bot_jimmy, "Luôn cố gắng hết mình"),
        BotProfile("nelson", "Nelson", 800, R.drawable.bot_nelson, "Thích đi quân ra giữa bàn"),
        BotProfile("emir", "Emir", 1000, R.drawable.bot_emir, "Chiến thuật gia"),
        BotProfile("lena", "Lena", 1200, R.drawable.bot_lena, "Tấn công không biết mệt"),
        BotProfile("antonio", "Antonio", 1500, R.drawable.bot_antonio, "Kiện tướng tập sự"),
        BotProfile("sofia", "Sofia", 1700, R.drawable.bot_sofia, "Phòng thủ chắc như đá"),
        BotProfile("hiro", "Hiro", 1900, R.drawable.bot_hiro, "Bậc thầy tàn cuộc"),
        BotProfile("viktor", "Viktor", 2100, R.drawable.bot_viktor, "Kỳ thủ giải đấu"),
        BotProfile("isabel", "Isabel", 2300, R.drawable.bot_isabel, "Ứng viên Kiện tướng"),
        BotProfile("magnus", "Magnus", 2500, R.drawable.bot_magnus, "Kiện tướng quốc tế"),
        BotProfile("olga", "Olga", 2700, R.drawable.bot_olga, "Đại kiện tướng"),
        BotProfile("daniel", "Daniel", 2900, R.drawable.bot_daniel, "Siêu đại kiện tướng"),
        BotProfile("nova", "Nova", 3050, R.drawable.bot_nova, "Tính trước hàng chục nước"),
        BotProfile("mittens", "Mittens", 3200, R.drawable.bot_mittens, "Cỗ máy không thể bị đánh bại"),
    )

    fun getById(id: String): BotProfile? = bots.firstOrNull { it.id == id }

    /** Bot có Elo gần [elo] nhất (hòa thì chọn bot yếu hơn). */
    fun nearest(elo: Int): BotProfile = bots.minByOrNull { kotlin.math.abs(it.elo - elo) } ?: bots.first()
}
