package com.vila.chess.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.vila.chess.review.GameReviewStore
import com.vila.chess.review.GameReviewWorker
import com.vila.chess.review.MoveLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Đối thủ: Bot hay Người (bạn bè cùng máy; sau này gắn thêm Online). */
enum class OpponentType { BOT, HUMAN }

/** Kết quả phân tích gom cho UI. Đã lọc theo "phía của bạn" khi chơi với Bot. */
data class ReviewSummary(
    val accuracyWhite: Float,
    val accuracyBlack: Float,
    /** Số nước theo nhãn của phía được hiển thị (humanWhite) hoặc cả hai phía (chơi với Người). */
    val counts: Map<MoveLabel, Int>,
    val totalMoves: Int,
)

sealed interface AnalysisState {
    data object Idle : AnalysisState
    /** progress null = chưa có tiến độ (đang chờ WorkManager: pin yếu/đang nóng máy). */
    data class Analyzing(val progress: Float?) : AnalysisState
    data class Finished(val summary: ReviewSummary) : AnalysisState
    /** Ván không đủ điều kiện (quá ngắn / hết lượt) hoặc engine lỗi. */
    data class Unavailable(val reason: String) : AnalysisState
}

class PostGameViewModel(app: Application) : AndroidViewModel(app) {

    private val _analysis = MutableStateFlow<AnalysisState>(AnalysisState.Idle)
    val analysis: StateFlow<AnalysisState> = _analysis.asStateFlow()

    private var job: Job? = null
    private var activeId: String? = null

    /** Gọi khi mở hộp thoại của ván mới: xoá trạng thái cũ. */
    fun reset() {
        job?.cancel(); job = null; activeId = null
        _analysis.value = AnalysisState.Idle
    }

    /**
     * Bấm "Xem lại ván đấu". Không chạy engine ở đây: Worker đã chạy nền từ lúc hết ván;
     * ta chỉ QUAN SÁT WorkManager + file kết quả => không chặn UI thread, bấm nhiều lần cũng không chạy lại.
     */
    fun startAnalysis(gameId: String?, skipReason: String?, humanWhite: Boolean?) {
        if (gameId == null) {
            _analysis.value = AnalysisState.Unavailable(skipReason ?: "Ván này không có dữ liệu phân tích.")
            return
        }
        if (activeId == gameId && _analysis.value !is AnalysisState.Unavailable) return
        activeId = gameId
        job?.cancel()
        _analysis.value = AnalysisState.Analyzing(null)
        val ctx = getApplication<Application>()
        val store = GameReviewStore(ctx)
        job = viewModelScope.launch {
            // Đã xong từ trước (ván ngắn / máy nhanh)?
            loadSummary(store, gameId, humanWhite)?.let { _analysis.value = AnalysisState.Finished(it); return@launch }

            WorkManager.getInstance(ctx).getWorkInfosForUniqueWorkFlow(GameReviewWorker.uniqueName(gameId))
                .collectLatest { infos ->
                    val info = infos.firstOrNull() ?: return@collectLatest
                    when (info.state) {
                        WorkInfo.State.SUCCEEDED -> {
                            val s = loadSummary(store, gameId, humanWhite)
                            _analysis.value = if (s != null) AnalysisState.Finished(s)
                            else AnalysisState.Unavailable("Không đọc được kết quả phân tích.")
                        }
                        WorkInfo.State.FAILED, WorkInfo.State.CANCELLED ->
                            _analysis.value = AnalysisState.Unavailable("Engine phân tích không chạy được trên máy này.")
                        else -> {
                            val done = info.progress.getInt(GameReviewWorker.KEY_DONE, -1)
                            val total = info.progress.getInt(GameReviewWorker.KEY_TOTAL, 0)
                            _analysis.value = AnalysisState.Analyzing(
                                if (done >= 0 && total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else null
                            )
                        }
                    }
                }
        }
    }

    /** Đọc + tính ở Dispatchers.IO, UI không bị chặn. */
    private suspend fun loadSummary(store: GameReviewStore, id: String, humanWhite: Boolean?): ReviewSummary? =
        withContext(Dispatchers.IO) {
            val r = store.load(id) ?: return@withContext null
            val mine = if (humanWhite == null) r.moves else r.moves.filter { it.whiteMoved == humanWhite }
            ReviewSummary(
                accuracyWhite = r.accuracyWhite.toFloat(),
                accuracyBlack = r.accuracyBlack.toFloat(),
                counts = mine.groupingBy { it.label }.eachCount(),
                totalMoves = r.moves.size,
            )
        }

    // ------------------------------------------------------------------ Lời HLV

    /**
     * Câu nhận xét của HLV (mock). accuracy: 0..100, đưa số âm nếu CHƯA có (chưa phân tích xong).
     * botLevel > 0 sẽ chèn "Bot cấp N" và gợi ý cấp N+1 khi thắng.
     */
    fun getCoachFeedback(
        isWin: Boolean,
        accuracy: Float,
        opponentType: OpponentType,
        botLevel: Int = 0,
        isDraw: Boolean = false,
    ): String {
        val known = accuracy >= 0f
        return when {
            isDraw -> when {
                known && accuracy >= 80f -> "Ván hòa rất chặt chẽ, độ chính xác ${accuracy.toInt()}%. Chỉ cần thêm một nước mạnh là bạn đã thắng!"
                else -> "Một ván hòa đáng giá. Hãy xem lại để tìm khoảnh khắc bạn có thể đã thắng!"
            }
            isWin && opponentType == OpponentType.BOT -> {
                val who = if (botLevel > 0) "Bot cấp $botLevel" else "Bot"
                val next = if (botLevel in 1..7) " Hãy thử thách Bot cấp ${botLevel + 1} nhé!" else " Hãy thử thách mình ở cấp cao hơn nhé!"
                if (known && accuracy >= 90f) "Tuyệt vời! Bạn chơi gần như hoàn hảo trước $who (${accuracy.toInt()}%).$next"
                else "Bạn đã chơi rất tốt trước $who.$next"
            }
            isWin -> when {
                known && accuracy >= 90f -> "Chiến thắng thuyết phục với ${accuracy.toInt()}% chính xác! Đối thủ khó có cơ hội nào."
                else -> "Chúc mừng chiến thắng! Xem lại ván để biết đâu là nước đi quyết định."
            }
            opponentType == OpponentType.BOT ->
                if (known && accuracy < 60f) "Có vài nước đi sai lầm ở giữa ván. Hãy xem lại và cải thiện nhé!"
                else "Đối thủ có khai cuộc tốt hơn. Hãy xem lại và cải thiện!"
            else ->
                if (known && accuracy < 60f) "Ván này có vài sai lầm lớn. Xem lại để rút kinh nghiệm cho trận sau nhé!"
                else "Đối thủ có khai cuộc tốt hơn. Hãy xem lại và cải thiện!"
        }
    }
}
