package com.vila.chess.review

import android.content.Context
import java.io.File
import kotlin.math.exp

object ReviewClassifier {
    /** Công thức win% kiểu Lichess từ centipawn (góc nhìn bên đang xét). */
    fun winPct(cp: Int): Double {
        val c = cp.coerceIn(-1000, 1000)
        return 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * c)) - 1.0)
    }

    // Ngưỡng là giả định của mình — chỉnh lại theo mức bạn đã bàn.
    fun classify(loss: Double): MoveLabel = when {
        loss <= 2.0 -> MoveLabel.BEST
        loss <= 5.0 -> MoveLabel.EXCELLENT
        loss <= 10.0 -> MoveLabel.GOOD
        loss <= 20.0 -> MoveLabel.INACCURACY
        loss <= 30.0 -> MoveLabel.MISTAKE
        else -> MoveLabel.BLUNDER
    }

    fun moveAccuracy(loss: Double): Double =
        (103.1668 * exp(-0.04354 * loss) - 3.1669).coerceIn(0.0, 100.0)
}

class GameReviewStore(context: Context) {
    private val dir = File(context.filesDir, "reviews").apply { mkdirs() }
    private fun file(id: String) = File(dir, "${id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}.json")

    fun exists(gameId: String) = file(gameId).exists()

    fun save(r: GameReview) {
        // Ghi tạm rồi đổi tên: không bao giờ để file review dở dang.
        val target = file(r.gameId)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(ReviewJson.encode(r))
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    /** null = chưa có (chưa phân tích xong) hoặc file hỏng. Đọc được cả file phiên bản 1. */
    fun load(gameId: String): GameReview? {
        val f = file(gameId)
        if (!f.exists()) return null
        return ReviewJson.decode(f.readText())
    }
}
