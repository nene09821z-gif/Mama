package com.vila.chess.game

import android.app.Application
import android.content.Context
import androidx.compose.runtime.Immutable
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 1 nút trên bản đồ. [id] = số Level hiển thị = cột `id` trong puzzles.db (1 = dễ nhất … 50.000 = khó nhất trong bộ).
 * Chỉ giữ id: trạng thái Done / Current / Locked suy ra từ [PuzzleMapViewModel.currentLevel] ⇒ tiến độ đổi
 * không phải dựng lại 50.000 đối tượng.
 */
@Immutable
data class PuzzleLevel(val id: Int)

/**
 * Trạng thái bản đồ câu đố.
 *  • [currentLevel]       level đang chơi (mọi level nhỏ hơn đã xong, lớn hơn bị khoá). Lưu SharedPreferences.
 *  • [justCompletedLevel] level VỪA thắng khi quay về từ màn chơi ⇒ bản đồ phát animation quân cờ nhảy, xong thì
 *                         gọi [onCelebrationShown] để về null (không phát lại khi cuộn / đổi tab).
 */
class PuzzleMapViewModel(app: Application) : AndroidViewModel(app) {

    companion object {
        const val TOTAL_LEVELS = 50_000
        private const val PREFS = "vila_puzzle_map"
        private const val KEY_CURRENT = "current_level"
    }

    private val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 50.000 level xếp GIẢM dần (50.000 → 1): LazyColumn vẽ từ trên xuống ⇒ level 1 nằm ở đáy. Tạo đúng 1 lần. */
    val levels: List<PuzzleLevel> = List(TOTAL_LEVELS) { PuzzleLevel(TOTAL_LEVELS - it) }

    private val _currentLevel = MutableStateFlow(prefs.getInt(KEY_CURRENT, 1).coerceIn(1, TOTAL_LEVELS))
    val currentLevel: StateFlow<Int> = _currentLevel.asStateFlow()

    private val _justCompletedLevel = MutableStateFlow<Int?>(null)
    val justCompletedLevel: StateFlow<Int?> = _justCompletedLevel.asStateFlow()

    /** Gọi khi quay về bản đồ sau khi THẮNG [level]: mở khoá level kế tiếp và kích hoạt animation trên nút [level]. */
    fun onPuzzleSolved(level: Int) {
        if (level !in 1..TOTAL_LEVELS) return
        if (level >= _currentLevel.value) {   // giải lại câu cũ không làm tiến độ lùi
            val next = (level + 1).coerceAtMost(TOTAL_LEVELS)
            _currentLevel.value = next
            prefs.edit().putInt(KEY_CURRENT, next).apply()
        }
        _justCompletedLevel.value = level
    }

    /** Bản đồ đã phát xong animation. */
    fun onCelebrationShown() {
        _justCompletedLevel.value = null
    }
}
