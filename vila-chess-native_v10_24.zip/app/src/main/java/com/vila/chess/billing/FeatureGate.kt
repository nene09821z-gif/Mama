package com.vila.chess.billing

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import com.vila.chess.ui.VilaColors

/** Gói hiện tại, tự cập nhật UI khi mua / hết hạn. */
@Composable
fun rememberTier(): MembershipTier = MembershipStore.get(LocalContext.current).tier.collectAsState().value

/**
 * Có quyền → hiện [content]; chưa đủ quyền → hiện thanh "Nâng cấp" (hoặc [locked] nếu bạn muốn giao diện khóa riêng).
 *
 *   FeatureGate(Feature.INSIGHTS, onUpgrade = { vm.navigate(HomeRoute.PAYWALL) }) { InsightsPanel() }
 */
@Composable
fun FeatureGate(
    feature: Feature,
    onUpgrade: () -> Unit,
    locked: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    if (hasAccess(feature, rememberTier())) content()
    else locked?.invoke() ?: UpgradeBar(
        text = feature.label + " · cần gói " + requiredTier(feature).displayName,
        onUpgrade = onUpgrade,
    )
}

@Composable
fun UpgradeBar(text: String, onUpgrade: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(VilaColors.Glass)
            .padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        UpgradeText(text)
        Button(onClick = onUpgrade) { Text("Nâng cấp", fontWeight = FontWeight.ExtraBold) }
    }
}

@Composable
private fun RowScope.UpgradeText(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f),
    )
}
