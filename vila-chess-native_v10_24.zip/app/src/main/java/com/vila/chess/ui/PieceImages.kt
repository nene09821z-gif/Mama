package com.vila.chess.ui

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.vila.chess.R

const val DEFAULT_PIECE_SET = "default"

class PieceSetInfo(val id: String, val label: String)

/** All selectable piece sets. "default" lives in res/drawable-nodpi, the others in assets/pieces/<id>/. */
object PieceSets {
    val all: List<PieceSetInfo> = listOf(
        PieceSetInfo(DEFAULT_PIECE_SET, "ViLa (mặc định)"),
        PieceSetInfo("alpha", "Alpha"),
        PieceSetInfo("anarcandy", "Anarcandy"),
        PieceSetInfo("caliente", "Caliente"),
        PieceSetInfo("california", "California"),
        PieceSetInfo("cardinal", "Cardinal"),
        PieceSetInfo("cburnett", "Cburnett"),
        PieceSetInfo("celtic", "Celtic"),
        PieceSetInfo("chess7", "Chess7"),
        PieceSetInfo("chessnut", "Chessnut"),
        PieceSetInfo("companion", "Companion"),
        PieceSetInfo("cooke", "Cooke"),
        PieceSetInfo("disguised", "Disguised"),
        PieceSetInfo("dubrovny", "Dubrovny"),
        PieceSetInfo("fantasy", "Fantasy"),
        PieceSetInfo("firi", "Firi"),
        PieceSetInfo("fresca", "Fresca"),
        PieceSetInfo("gioco", "Gioco"),
        PieceSetInfo("governor", "Governor"),
        PieceSetInfo("horsey", "Horsey"),
        PieceSetInfo("icpieces", "IC Pieces"),
        PieceSetInfo("kiwen-suwi", "Kiwen-suwi"),
        PieceSetInfo("kosal", "Kosal"),
        PieceSetInfo("leipzig", "Leipzig"),
        PieceSetInfo("letter", "Letter"),
        PieceSetInfo("maestro", "Maestro"),
        PieceSetInfo("merida", "Merida"),
        PieceSetInfo("minimal-warmth", "Minimal Warmth"),
        PieceSetInfo("monarchy", "Monarchy"),
        PieceSetInfo("mono", "Mono"),
        PieceSetInfo("mpchess", "MP Chess"),
        PieceSetInfo("papercut", "Papercut"),
        PieceSetInfo("pirouetti", "Pirouetti"),
        PieceSetInfo("pixel", "Pixel"),
        PieceSetInfo("reillycraig", "Reillycraig"),
        PieceSetInfo("rhosgfx", "RhosGFX"),
        PieceSetInfo("riohacha", "Riohacha"),
        PieceSetInfo("shahi-ivory-brown", "Shahi Ivory Brown"),
        PieceSetInfo("shapes", "Shapes"),
        PieceSetInfo("spatial", "Spatial"),
        PieceSetInfo("staunty", "Staunty"),
        PieceSetInfo("tatiana", "Tatiana"),
        PieceSetInfo("totoy", "Totoy"),
        PieceSetInfo("xkcd", "XKCD"),
    )

    fun exists(id: String): Boolean = all.any { it.id == id }

    fun get(id: String): PieceSetInfo = all.firstOrNull { it.id == id } ?: all[0]

    fun indexOf(id: String): Int = all.indexOfFirst { it.id == id }.coerceAtLeast(0)
}

private val TYPE_CHARS = charArrayOf(' ', 'P', 'N', 'B', 'R', 'Q', 'K')

private fun assetName(code: Int): String {
    val white = code <= 6
    val type = if (white) code else code - 8
    return (if (white) "w" else "b") + TYPE_CHARS[type] + ".png"
}

private fun decodeAsset(ctx: Context, path: String): ImageBitmap? {
    return try {
        val opts = BitmapFactory.Options()
        opts.inScaled = false
        ctx.assets.open(path).use { stream ->
            BitmapFactory.decodeStream(stream, null, opts)?.asImageBitmap()
        }
    } catch (e: Exception) {
        null
    }
}

private fun defaultPieceIds(): IntArray = intArrayOf(
    0,
    R.drawable.piece_wp, R.drawable.piece_wn, R.drawable.piece_wb,
    R.drawable.piece_wr, R.drawable.piece_wq, R.drawable.piece_wk,
    0, 0,
    R.drawable.piece_bp, R.drawable.piece_bn, R.drawable.piece_bb,
    R.drawable.piece_br, R.drawable.piece_bq, R.drawable.piece_bk
)

private fun decodeDefault(ctx: Context, code: Int): ImageBitmap? {
    val id = defaultPieceIds()[code]
    if (id == 0) return null
    val opts = BitmapFactory.Options()
    opts.inScaled = false
    val bmp = BitmapFactory.decodeResource(ctx.resources, id, opts)
    return bmp?.asImageBitmap()
}

private fun isPieceCode(code: Int): Boolean = code in 1..6 || code in 9..14

private fun decodePiece(ctx: Context, setId: String, code: Int): ImageBitmap? {
    if (!isPieceCode(code)) return null
    if (setId == DEFAULT_PIECE_SET) return decodeDefault(ctx, code)
    // A missing/corrupt file falls back to the default piece so the board never has holes.
    return decodeAsset(ctx, "pieces/" + setId + "/" + assetName(code)) ?: decodeDefault(ctx, code)
}

/** Bitmaps indexed by piece code (1..6 white P N B R Q K, 9..14 black). */
fun loadPieceImages(ctx: Context, setId: String = DEFAULT_PIECE_SET): Array<ImageBitmap?> {
    val arr = arrayOfNulls<ImageBitmap>(15)
    for (code in 1..14) arr[code] = decodePiece(ctx, setId, code)
    return arr
}

/** White knight + black knight, used for the preview cards in the piece-set picker. */
fun loadPiecePair(ctx: Context, setId: String): Pair<ImageBitmap?, ImageBitmap?> =
    Pair(decodePiece(ctx, setId, 2), decodePiece(ctx, setId, 10))
