package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private class SkillOption(val titleEn: String, val titleVi: String, val elo: Int, val desc: String)

private val SKILL_OPTIONS = listOf(
    SkillOption("New to chess", "Mới chơi cờ", 400, "Chỉ mới biết luật, chưa có kinh nghiệm thực chiến."),
    SkillOption("Beginner", "Người mới", 800, "Đã biết luật, có chơi qua nhưng còn mắc nhiều lỗi cơ bản."),
    SkillOption("Intermediate", "Trung cấp", 1200, "Hiểu các nguyên tắc khai cuộc cơ bản, biết một số đòn chiến thuật đơn giản."),
    SkillOption("Advanced", "Nâng cao", 1600, "Chơi cờ thành thạo, có chiến lược rõ ràng và thường xuyên tham gia các giải đấu phong trào."),
)

/**
 * Màn chọn trình độ sau đăng nhập. Chạm một thẻ -> thẻ viền xanh lá một nhịp ngắn,
 * rồi [onSelect] (lưu Elo khởi điểm) và vào màn hình chính.
 */
@Composable
fun SkillLevelSetupScreen(onSelect: (Int) -> Unit) {
    var selected by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(selected) {
        val elo = selected ?: return@LaunchedEffect
        delay(260)
        onSelect(elo)
    }

    Box(modifier = Modifier.fillMaxSize().background(VilaColors.Bg)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Trình độ cờ của bạn?", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Chọn mức gần đúng nhất để chúng tôi gợi ý đối thủ phù hợp. Bạn có thể đổi sau.",
                color = VilaColors.TextDim,
                fontSize = 14.sp,
            )
            Spacer(Modifier.height(4.dp))
            for (opt in SKILL_OPTIONS) {
                SkillCard(opt, chosen = selected == opt.elo) { if (selected == null) selected = opt.elo }
            }
        }
    }
}

@Composable
private fun SkillCard(opt: SkillOption, chosen: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val borderColor = if (chosen) VilaColors.Green else VilaColors.GlassBorder
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(VilaColors.Panel)
            .border(if (chosen) 2.5.dp else 1.dp, borderColor, shape)
            .clickable(onClick = onClick)   // ripple mặc định của Material
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.ExtraBold)) { append(opt.titleEn) }
                    withStyle(SpanStyle(color = VilaColors.TextDim, fontWeight = FontWeight.Medium)) { append(" (" + opt.titleVi + ")") }
                },
                fontSize = 18.sp,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = opt.elo.toString() + " Elo",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(VilaColors.GreenDeep).padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
        Text(opt.desc, color = VilaColors.TextDim, fontSize = 14.sp, lineHeight = 19.sp)
    }
}
