package com.vila.chess.auth

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class AuthProvider { EMAIL, GOOGLE, FACEBOOK }

data class Account(val email: String, val name: String, val provider: AuthProvider)

/** Lưu tài khoản đang đăng nhập (SharedPreferences). `current` là state của Compose nên UI tự cập nhật. */
object AccountStore {
    private const val PREFS = "vila_account"
    var current: Account? by mutableStateOf(null)
        private set
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val email = p.getString("email", null) ?: return
        current = Account(
            email = email,
            name = p.getString("name", "") ?: "",
            provider = runCatching { AuthProvider.valueOf(p.getString("provider", "EMAIL")!!) }.getOrDefault(AuthProvider.EMAIL),
        )
    }

    fun save(ctx: Context, a: Account) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("email", a.email).putString("name", a.name).putString("provider", a.provider.name).apply()
        current = a
    }

    fun signOut(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        current = null
    }

    fun isValidEmail(s: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(s.trim()).matches()
}
