package com.vila.chess.core

/** Standard algebraic notation for [move] in [pos] (move must be legal in pos). */
fun moveToSan(pos: Position, move: Int): String {
    val from = moveFrom(move)
    val to = moveTo(move)
    val piece = pos.board[from]
    val type = pieceType(piece)
    val flag = moveFlag(move)
    val sb = StringBuilder()
    if (flag == FLAG_CASTLE) {
        sb.append(if (sqFile(to) == 6) "O-O" else "O-O-O")
    } else {
        val capture = pos.board[to] != EMPTY || flag == FLAG_EP
        if (type == PAWN) {
            if (capture) sb.append('a' + sqFile(from)).append('x')
            sb.append(sqName(to))
            val promo = movePromo(move)
            if (promo != 0) sb.append('=').append("??NBRQ"[promo])
        } else {
            sb.append("??NBRQK"[type])
            val legal = pos.legalMoves()
            var sameFile = false
            var sameRank = false
            var ambiguous = false
            for (other in legal) {
                if (other == move) continue
                if (moveTo(other) != to) continue
                val otherFrom = moveFrom(other)
                if (otherFrom == from) continue
                if (pos.board[otherFrom] != piece) continue
                ambiguous = true
                if (sqFile(otherFrom) == sqFile(from)) sameFile = true
                if (sqRank(otherFrom) == sqRank(from)) sameRank = true
            }
            if (ambiguous) {
                if (!sameFile) {
                    sb.append('a' + sqFile(from))
                } else if (!sameRank) {
                    sb.append('1' + sqRank(from))
                } else {
                    sb.append('a' + sqFile(from)).append('1' + sqRank(from))
                }
            }
            if (capture) sb.append('x')
            sb.append(sqName(to))
        }
    }
    val side = pos.whiteToMove
    pos.make(move)
    if (pos.inCheck(!side)) {
        val buf = IntArray(MAX_MOVES)
        val replies = pos.generateLegal(buf)
        sb.append(if (replies == 0) '#' else '+')
    }
    pos.unmake()
    return sb.toString()
}
