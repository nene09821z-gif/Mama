package com.vila.chess.auth

import androidx.activity.ComponentActivity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.facebook.AccessToken
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.GraphRequest
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Kết quả đăng nhập MXH. `email` có thể null (Facebook không phải lúc nào cũng trả email) => UI cho nhập tay. */
data class SocialResult(val email: String?, val name: String)

object SocialSignIn {
    /** Đọc email/tên từ id_token (JWT) do Google trả về sau luồng trình duyệt. */
    fun parseGoogleIdToken(idToken: String?): SocialResult? = runCatching {
        val payload = idToken!!.split('.')[1]
        val json = org.json.JSONObject(String(android.util.Base64.decode(payload, android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP)))
        SocialResult(json.optString("email").takeIf { it.isNotBlank() }, json.optString("name"))
    }.getOrNull()

    /** Google: Credential Manager. serverClientId = Web client ID trong Google Cloud Console. */
    suspend fun google(activity: ComponentActivity, serverClientId: String): SocialResult {
        val req = GetCredentialRequest.Builder()
            .addCredentialOption(GetSignInWithGoogleOption.Builder(serverClientId).build())
            .build()
        val cred = CredentialManager.create(activity).getCredential(activity, req).credential
        require(cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "Không nhận được tài khoản Google"
        }
        val g = GoogleIdTokenCredential.createFrom(cred.data)
        return SocialResult(g.id, g.displayName ?: "")
    }

    /** Facebook: xin quyền email + public_profile rồi hỏi Graph API `/me`. */
    fun facebook(activity: ComponentActivity, onDone: (Result<SocialResult>) -> Unit) {
        val cb = CallbackManager.Factory.create()
        val lm = LoginManager.getInstance()
        lm.registerCallback(cb, object : FacebookCallback<LoginResult> {
            override fun onSuccess(result: LoginResult) {
                val req = GraphRequest.newMeRequest(result.accessToken) { obj, _ ->
                    onDone(Result.success(SocialResult(obj?.optString("email")?.takeIf { it.isNotBlank() }, obj?.optString("name") ?: "")))
                }
                req.parameters = android.os.Bundle().apply { putString("fields", "id,name,email") }
                req.executeAsync()
            }
            override fun onCancel() = onDone(Result.failure(IllegalStateException("Đã huỷ")))
            override fun onError(error: FacebookException) = onDone(Result.failure(error))
        })
        lm.logInWithReadPermissions(activity, cb, listOf("email", "public_profile"))
    }

    fun facebookSignOut() { runCatching { LoginManager.getInstance().logOut() } }
    @Suppress("unused") fun facebookTokenValid() = AccessToken.getCurrentAccessToken()?.isExpired == false
}
