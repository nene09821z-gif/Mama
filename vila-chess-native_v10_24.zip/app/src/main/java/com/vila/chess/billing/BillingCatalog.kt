package com.vila.chess.billing

/**
 * Khớp 1-1 với Google Play Console: mỗi gói = 1 subscription, mỗi subscription có 2 base plan "monthly" / "yearly".
 */
object BillingCatalog {
    private val productByTier = mapOf(
        MembershipTier.GOLD to "chessplus_gold",
        MembershipTier.PLATINUM to "chessplus_platinum",
        MembershipTier.DIAMOND to "chessplus_diamond",
    )
    val productIds: List<String> = productByTier.values.toList()
    fun tierOf(productId: String): MembershipTier? = productByTier.entries.firstOrNull { it.value == productId }?.key

    /** Để trống = không xác thực server (chỉ nên dùng khi dev). Xem docs/PAYWALL_GUIDE.md mục 5. */
    const val VERIFY_ENDPOINT: String = ""
}

enum class BillingPeriod(val basePlanId: String) { MONTHLY("monthly"), YEARLY("yearly") }
