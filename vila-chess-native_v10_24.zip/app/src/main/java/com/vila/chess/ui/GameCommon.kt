package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.core.makePiece
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Tournament
import com.vila.chess.game.UiState
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.runtime.getValue
import com.vila.chess.game.Levels
import com.vila.chess.game.levelRating

/** Các hộp xác nhận dùng chung cho màn Bot và màn PvP. */
internal enum class Confirm { EXIT, NEW_GAME, RESIGN, DRAW }

/** Bàn cờ dùng chung: kéo thả / chạm quân do BoardView xử lý, mọi nước đi vẫn đi qua GameViewModel. */
@Composable
internal fun ChessBoard(vm: GameViewModel, ui: UiState, modifier: Modifier = Modifier, evalBar: Boolean? = null) {
    // evalBar == null: màn không có Eval Bar (PvP). Khác null: luôn dùng khung Row để hiệu ứng ra/vào không làm dựng lại bàn cờ.
    if (evalBar == null) {
        BoardView(vm = vm, ui = ui, images = vm.pieceImages, modifier = modifier.fillMaxWidth())
        return
    }
    // Eval Bar trượt vào/ra từ trái (250ms). Chiều cao thanh = cạnh bàn cờ khi thanh đang hiện = bề rộng - bề rộng thanh.
    androidx.compose.foundation.layout.BoxWithConstraints(modifier.fillMaxWidth()) {
        val barW = EVAL_BAR_WIDTH
        val barH = maxWidth - barW   // đọc ở đây: trong Row (RowScope) không gọi được maxWidth của BoxWithConstraintsScope
        Row(Modifier.fillMaxWidth()) {
            AnimatedToolPanel(visible = evalBar) {
                EvalBar(
                    scoreCp = ui.evalCp,
                    ready = ui.evalReady,
                    whiteAtBottom = !ui.flipped,
                    modifier = Modifier.width(barW).height(barH),
                )
            }
            BoardView(vm = vm, ui = ui, images = vm.pieceImages, modifier = Modifier.weight(1f))
        }
    }
}

/** Thanh lịch sử nước đi cuộn ngang (dùng chung). */
@Composable
internal fun MoveHistory(sans: List<String>, modifier: Modifier = Modifier) {
    val state = rememberLazyListState()
    LaunchedEffect(sans.size) {
        if (sans.isNotEmpty()) state.animateScrollToItem(sans.size - 1)
    }
    if (sans.isEmpty()) {
        Box(modifier = modifier.fillMaxHeight(), contentAlignment = Alignment.CenterStart) {
            Text("Các nước đi sẽ hiện ở đây", color = VilaColors.TextDim, fontSize = 13.sp)
        }
        return
    }
    LazyRow(
        state = state,
        modifier = modifier.fillMaxHeight(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        itemsIndexed(sans) { index, san ->
            val isLast = index == sans.size - 1
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (index % 2 == 0) {
                    Text(
                        "" + (index / 2 + 1) + ".",
                        color = VilaColors.TextDim,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(start = 6.dp, end = 3.dp)
                    )
                }
                Text(
                    san,
                    color = if (isLast) VilaColors.Text else VilaColors.TextDim,
                    fontSize = 13.sp,
                    fontWeight = if (isLast) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isLast) VilaColors.Panel else Color.Transparent)
                        .padding(horizontal = 5.dp, vertical = 3.dp)
                )
            }
        }
    }
}

@Composable
internal fun PlayerBar(
    vm: GameViewModel,
    ui: UiState,
    images: Array<ImageBitmap?>,
    white: Boolean,
    name: String,
    subtitle: String? = null,
    avatarIcon: ImageVector? = null,
    avatarResId: Int? = null,
) {
    val clock = vm.clocks
    val captured = if (white) ui.capturedByWhite else ui.capturedByBlack
    val advantage = if (white) ui.materialDiff else -ui.materialDiff
    val active = !ui.over && ui.whiteToMove == white
    val isEngine = white != ui.humanWhite && ui.kind != GameKind.FRIEND
    val ms = if (white) clock.whiteMs else clock.blackMs

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val avatar = images[if (white) 6 else 14]
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(if (avatarResId != null) Color.Transparent else if (avatarIcon != null) Color(0xFF5E8F33) else if (white) Color(0xFFB9B7B2) else Color(0xFF4A4743)),
            contentAlignment = Alignment.Center
        ) {
            if (avatarResId != null) {
                Image(painter = androidx.compose.ui.res.painterResource(avatarResId), contentDescription = null, modifier = Modifier.size(40.dp))
            } else if (avatarIcon != null) {
                Icon(avatarIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
            } else if (avatar != null) {
                Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(36.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (active) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(VilaColors.Green)
                    )
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    name,
                    color = VilaColors.Text,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                Text(
                    if (isEngine && ui.thinking) "  đang nghĩ…" else if (subtitle != null) "  " + subtitle else if (white) "  Trắng" else "  Đen",
                    color = VilaColors.TextDim,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
            Row(
                modifier = Modifier.height(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy((-7).dp)
            ) {
                for (p in captured) {
                    val img = images[p]
                    if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                if (advantage > 0) {
                    Spacer(Modifier.width(14.dp))
                    Text("+" + (advantage / 100), color = VilaColors.TextDim, fontSize = 12.sp)
                }
            }
        }
        if (clock.enabled) {
            val low = ms < 20_000L
            Box(
                modifier = Modifier
                    .widthIn(min = 88.dp)
                    .height(40.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (active) VilaColors.ClockActive else VilaColors.ClockIdle)
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Text(
                    formatClock(ms),
                    color = if (active) (if (low) VilaColors.Danger else Color(0xFF1F1E1B)) else (if (low) VilaColors.Danger else VilaColors.TextDim),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

private fun formatClock(ms: Long): String {
    val total = if (ms < 0L) 0L else ms
    if (total < 20_000L) {
        val tenths = (total / 100L) % 10L
        val secs = total / 1000L
        return "0:" + (if (secs < 10L) "0" else "") + secs + "." + tenths
    }
    val totalSec = (total + 999L) / 1000L
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "" + m + ":" + (if (s < 10L) "0" else "") + s
}

@Composable
internal fun PromotionDialog(vm: GameViewModel, images: Array<ImageBitmap?>, humanWhite: Boolean) {
    Dialog(onDismissRequest = { vm.cancelPromotion() }) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(VilaColors.Panel)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Phong cấp thành", color = VilaColors.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (type in vm.pieceChoices()) {
                    val img = images[makePiece(type, humanWhite)]
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(VilaColors.BoardLight)
                            .clickable { vm.choosePromotion(type) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(58.dp))
                    }
                }
            }
        }
    }
}

/** Hộp thoại xác nhận chung. [onAccept] nhận loại xác nhận để màn hình tự gọi đúng hàm của ViewModel. */
@Composable
internal fun ConfirmDialog(confirm: Confirm?, friend: Boolean, onDismiss: () -> Unit, onAccept: (Confirm) -> Unit) {
    if (confirm == null) return
    val text = when (confirm) {
        Confirm.EXIT -> "Thoát về menu? Ván đang chơi sẽ mất."
        Confirm.NEW_GAME -> "Bỏ ván hiện tại và bắt đầu ván mới?"
        Confirm.RESIGN -> if (friend) "Người đang đến lượt muốn đầu hàng ván này?" else "Bạn muốn đầu hàng ván này?"
        Confirm.DRAW -> if (friend) "Gửi lời đề nghị hòa? Hai người chơi đồng ý hòa ván này." else "Bạn muốn xin hòa ván này?"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VilaColors.Panel,
        title = { Text("Xác nhận", color = VilaColors.Text) },
        text = { Text(text, color = VilaColors.TextDim) },
        confirmButton = { TextButton(onClick = { onAccept(confirm) }) { Text("Đồng ý", color = VilaColors.Green) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = VilaColors.TextDim) } }
    )
}

/** Khung thanh công cụ dưới cùng: các nút xếp đều. */
@Composable
internal fun GameToolbar(content: @Composable RowScope.() -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().background(VilaColors.PanelDark).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

/** Một nút: icon (tuỳ ý) + chữ nhỏ; mờ và không bấm được khi [enabled] = false. */
@Composable
internal fun ToolbarButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    active: Boolean = false,
    icon: @Composable () -> Unit,
) {
    // Đổi trạng thái bật/tắt/khả dụng: nền, màu icon+chữ, độ mờ đều chuyển mượt 200ms thay vì nhảy màu.
    val bg by animateColorAsState(if (active) VilaColors.GreenDeep else Color.Transparent, tween(200), label = "tbBg")
    val fg by animateColorAsState(if (active) VilaColors.Green else VilaColors.TextDim, tween(200), label = "tbFg")
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(200), label = "tbAlpha")
    Column(
        modifier = Modifier
            .graphicsLayer { alpha = a }
            .clip(RoundedCornerShape(10.dp))
            .drawBehind { drawRect(bg) }          // đọc màu ở pha draw: không recomposition mỗi frame
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CompositionLocalProvider(LocalContentColor provides fg) {
            Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) { icon() }
        }
        Text(label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
internal fun ToolbarVectorIcon(icon: ImageVector, label: String) {
    Icon(icon, contentDescription = label, tint = LocalContentColor.current, modifier = Modifier.size(26.dp))
}

/** Mũi tên quay lại + thanh lịch sử nước đi, như dải phía trên bàn cờ của chess.com. */
@Composable
internal fun GameTopBar(sans: List<String>, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(VilaColors.PanelDark),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(20.dp)) {
                val w = size.width
                val h = size.height
                val p = Path()
                p.moveTo(w * 0.65f, h * 0.12f)
                p.lineTo(w * 0.27f, h * 0.5f)
                p.lineTo(w * 0.65f, h * 0.88f)
                drawPath(
                    path = p,
                    color = VilaColors.Text,
                    style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
        MoveHistory(sans, Modifier.weight(1f))
    }
}
