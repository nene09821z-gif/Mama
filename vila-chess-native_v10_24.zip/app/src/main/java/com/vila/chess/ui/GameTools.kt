package com.vila.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.core.Engine
import kotlin.math.abs
import kotlin.math.exp

internal val EVAL_BAR_WIDTH = 16.dp
private const val TOOL_ANIM_MS = 250

/**
 * Khung bật/tắt công cụ (Eval Bar, bảng Gợi ý): trượt ngang + mờ, 250ms.
 * [fromStart] = true: vào/ra phía trái; false: phía phải.
 */
@Composable
internal fun AnimatedToolPanel(
    visible: Boolean,
    modifier: Modifier = Modifier,
    fromStart: Boolean = true,
    content: @Composable () -> Unit,
) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInHorizontally(tween(TOOL_ANIM_MS, easing = FastOutSlowInEasing)) { if (fromStart) -it else it } +
            fadeIn(tween(TOOL_ANIM_MS)),
        exit = slideOutHorizontally(tween(TOOL_ANIM_MS, easing = FastOutSlowInEasing)) { if (fromStart) -it else it } +
            fadeOut(tween(TOOL_ANIM_MS)),
    ) { content() }
}

/** Điểm cờ (Trắng) -> phần thanh thuộc về Trắng, 0..1 (đường sigmoid giống chess.com: +3 tốt đã gần kín). */
internal fun evalWhiteShare(cp: Int): Float {
    if (cp >= Engine.MATE - 100) return 1f
    if (cp <= -(Engine.MATE - 100)) return 0f
    return (1.0 / (1.0 + exp(-cp / 350.0))).toFloat()
}

/**
 * Thanh đánh giá dọc. Phần màu của bên dưới đáy được co giãn bằng graphicsLayer.scaleY (GPU),
 * giá trị mới được lò xo mềm kéo tới nên thanh trượt êm khi engine đổi số.
 */
@Composable
internal fun EvalBar(scoreCp: Int, ready: Boolean, whiteAtBottom: Boolean, modifier: Modifier = Modifier) {
    val white = Color(0xFFF2F2F2)
    val black = Color(0xFF403D39)
    val share = if (ready) evalWhiteShare(scoreCp) else 0.5f
    val bottomShare = if (whiteAtBottom) share else 1f - share
    val anim by animateFloatAsState(
        targetValue = bottomShare,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow),
        label = "evalFill",
    )
    val bottomColor = if (whiteAtBottom) white else black
    val topColor = if (whiteAtBottom) black else white
    val bottomAhead = bottomShare >= 0.5f
    val label = when {
        !ready -> ""
        abs(scoreCp) >= Engine.MATE - 100 -> "#"
        else -> String.format("%.1f", abs(scoreCp) / 100f)
    }
    Box(modifier = modifier.clip(RoundedCornerShape(3.dp)).background(topColor)) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleY = anim
                    transformOrigin = TransformOrigin(0.5f, 1f)
                }
                .background(bottomColor)
        )
        if (label.isNotEmpty()) {
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (bottomAhead == whiteAtBottom) black else white,
                modifier = Modifier.align(if (bottomAhead) Alignment.BottomCenter else Alignment.TopCenter).padding(vertical = 2.dp),
            )
        }
    }
}
