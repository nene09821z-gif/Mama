package com.vila.chess.billing

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

enum class VerifyResult { VALID, INVALID, UNREACHABLE }

/** Xác thực biên lai ở server của bạn (server gọi Google Play Developer API). Xem server/verify-purchase.js. */
interface PurchaseVerifier {
    suspend fun verify(packageName: String, productId: String, purchaseToken: String): VerifyResult
}

class HttpPurchaseVerifier(private val endpoint: String) : PurchaseVerifier {
    override suspend fun verify(packageName: String, productId: String, purchaseToken: String): VerifyResult =
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 10000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject()
                    .put("packageName", packageName)
                    .put("productId", productId)
                    .put("purchaseToken", purchaseToken)
                    .toString()
                conn.outputStream.use { it.write(body.toByteArray()) }
                when (conn.responseCode) {
                    200 -> {
                        val text = conn.inputStream.bufferedReader().use { it.readText() }
                        if (JSONObject(text).optBoolean("valid", false)) VerifyResult.VALID else VerifyResult.INVALID
                    }
                    in 400..499 -> VerifyResult.INVALID
                    else -> VerifyResult.UNREACHABLE
                }
            } catch (e: Exception) {
                VerifyResult.UNREACHABLE // mất mạng / timeout: không được coi là gian lận
            } finally {
                conn?.disconnect()
            }
        }
}
