package com.vila.chess.settings

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.roundToInt

/** Toàn bộ lựa chọn trong màn "Các tùy chỉnh". Immutable => Compose chỉ vẽ lại phần thực sự đổi. */
@Immutable
data class GameSettingsState(
    val sliderValue: Float = SLIDER_DEFAULT,        // "Kiểu chủ đề lớn nhất" (3200)
    val isEvalBarEnabled: Boolean = false,          // Thanh đánh giá
    val isMoveFeedbackEnabled: Boolean = false,     // Phản hồi nước đi
    val isEngineEnabled: Boolean = false,           // Bộ máy
    val isHintsEnabled: Boolean = true,             // Gợi ý
    val isSuggestionArrowsEnabled: Boolean = false, // Mũi tên gợi ý
    val isThreatArrowsEnabled: Boolean = false,     // Các mối đe doạ
    val isTakebackEnabled: Boolean = true,          // Takeback
) {
    companion object {
        const val SLIDER_MIN = 400f
        const val SLIDER_MAX = 3200f
        const val SLIDER_DEFAULT = 3200f
        const val SLIDER_STEP = 50
    }
}

/**
 * Giữ state bằng StateFlow. Mỗi lần gạt/kéo gọi một hàm bên dưới => StateFlow phát giá trị mới
 * ngay lập tức => UI cập nhật tức thì. Lấy bằng `viewModel()` trong Compose.
 */
class SettingsViewModel : ViewModel() {
    private val _state = MutableStateFlow(GameSettingsState())
    val state: StateFlow<GameSettingsState> = _state.asStateFlow()

    /** Kéo thanh trượt: làm tròn theo bước 50 cho số đẹp (3200, 3150...). */
    fun onSliderChange(raw: Float) = _state.update {
        val snapped = (raw / GameSettingsState.SLIDER_STEP).roundToInt() * GameSettingsState.SLIDER_STEP
        it.copy(sliderValue = snapped.toFloat().coerceIn(GameSettingsState.SLIDER_MIN, GameSettingsState.SLIDER_MAX))
    }

    fun onEvalBar(on: Boolean) = _state.update { it.copy(isEvalBarEnabled = on) }
    fun onMoveFeedback(on: Boolean) = _state.update { it.copy(isMoveFeedbackEnabled = on) }
    fun onEngine(on: Boolean) = _state.update { it.copy(isEngineEnabled = on) }
    fun onHints(on: Boolean) = _state.update { it.copy(isHintsEnabled = on) }
    fun onSuggestionArrows(on: Boolean) = _state.update { it.copy(isSuggestionArrowsEnabled = on) }
    fun onThreatArrows(on: Boolean) = _state.update { it.copy(isThreatArrowsEnabled = on) }
    fun onTakeback(on: Boolean) = _state.update { it.copy(isTakebackEnabled = on) }
}
