package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// All icons are drawn on a 24 x 24 unit grid and scaled to whatever size the caller gives them.

private fun Path.m(u: Float, x: Float, y: Float) = moveTo(x * u, y * u)
private fun Path.l(u: Float, x: Float, y: Float) = lineTo(x * u, y * u)
private fun Path.c(u: Float, a: Float, b: Float, c: Float, d: Float, e: Float, f: Float) =
    cubicTo(a * u, b * u, c * u, d * u, e * u, f * u)

private fun poly(u: Float, vararg p: Float): Path {
    val path = Path()
    path.moveTo(p[0] * u, p[1] * u)
    var i = 2
    while (i < p.size) {
        path.lineTo(p[i] * u, p[i + 1] * u)
        i += 2
    }
    path.close()
    return path
}

/** Streak flame: orange outside, yellow core. */
@Composable
fun FlameIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val outer = Path().apply {
            m(u, 12f, 1.2f)
            c(u, 13f, 6f, 19.5f, 8.8f, 19.5f, 15.2f)
            c(u, 19.5f, 19.4f, 16.2f, 22.8f, 12f, 22.8f)
            c(u, 7.8f, 22.8f, 4.5f, 19.4f, 4.5f, 15.2f)
            c(u, 4.5f, 12.6f, 5.9f, 10.6f, 7.4f, 9.1f)
            c(u, 7.9f, 11f, 8.7f, 12f, 9.8f, 12.5f)
            c(u, 9.4f, 8f, 10.4f, 4.2f, 12f, 1.2f)
            close()
        }
        drawPath(
            path = outer,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFA726), Color(0xFFFF5722)),
                startY = 0f,
                endY = size.height,
            ),
        )
        val inner = Path().apply {
            m(u, 12f, 12.6f)
            c(u, 13.4f, 14.6f, 15f, 15.8f, 15f, 18.2f)
            c(u, 15f, 20f, 13.7f, 21.3f, 12f, 21.3f)
            c(u, 10.3f, 21.3f, 9f, 20f, 9f, 18.2f)
            c(u, 9f, 16f, 11f, 15f, 12f, 12.6f)
            close()
        }
        drawPath(path = inner, color = Color(0xFFFFE082))
    }
}

/** Faceted blue gem. */
@Composable
fun DiamondIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawPath(poly(u, 6f, 3f, 18f, 3f, 23f, 9f, 1f, 9f), Color(0xFF6FD3FF))
        drawPath(poly(u, 1f, 9f, 12f, 9f, 12f, 22f), Color(0xFF1B8FE0))
        drawPath(poly(u, 12f, 9f, 23f, 9f, 12f, 22f), Color(0xFF38AEF5))
        drawPath(poly(u, 6f, 3f, 9f, 9f, 12f, 3f), Color(0x66FFFFFF))
        drawPath(poly(u, 12f, 3f, 15f, 9f, 18f, 3f), Color(0x33FFFFFF))
        drawLine(Color(0x55FFFFFF), Offset(1f * u, 9f * u), Offset(23f * u, 9f * u), strokeWidth = 0.6f * u)
    }
}

/** Two people (friends). */
@Composable
fun FriendsIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val back = Color(0xFF8CA3C2)
        drawCircle(back, radius = 2.9f * u, center = Offset(17.2f * u, 7.4f * u))
        val backBody = Path().apply {
            m(u, 16.8f, 12.8f)
            c(u, 20.2f, 12.8f, 22.4f, 15.2f, 22.4f, 19.8f)
            l(u, 17.8f, 19.8f)
            c(u, 17.6f, 17.2f, 16.6f, 15.2f, 14.8f, 14f)
            c(u, 15.4f, 13.3f, 16.1f, 12.8f, 16.8f, 12.8f)
            close()
        }
        drawPath(backBody, back)
        drawCircle(Color.White, radius = 3.5f * u, center = Offset(9.6f * u, 8f * u))
        val front = Path().apply {
            m(u, 2f, 21.5f)
            c(u, 2f, 16.9f, 5.2f, 13.6f, 9.6f, 13.6f)
            c(u, 14f, 13.6f, 17.2f, 16.9f, 17.2f, 21.5f)
            close()
        }
        drawPath(front, Color.White)
    }
}

/** Gold notification bell. */
@Composable
fun BellIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val body = Path().apply {
            m(u, 12f, 2.4f)
            c(u, 8.2f, 2.4f, 6f, 5.4f, 6f, 9.4f)
            l(u, 6f, 14f)
            l(u, 3.4f, 17.6f)
            l(u, 20.6f, 17.6f)
            l(u, 18f, 14f)
            l(u, 18f, 9.4f)
            c(u, 18f, 5.4f, 15.8f, 2.4f, 12f, 2.4f)
            close()
        }
        drawPath(
            path = body,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFD54F), Color(0xFFFFA000)),
                startY = 0f,
                endY = size.height,
            ),
        )
        drawCircle(Color(0xFFFFA000), radius = 2.3f * u, center = Offset(12f * u, 20.4f * u))
    }
}

/** Gold bullet, tilted 45 degrees (Siêu chớp). */
@Composable
fun BulletIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        rotate(degrees = 45f, pivot = Offset(size.width / 2f, size.height / 2f)) {
            val shell = Path().apply {
                m(u, 12f, 0.8f)
                c(u, 16f, 4.6f, 17.2f, 8.6f, 17.2f, 12.6f)
                l(u, 17.2f, 18.6f)
                l(u, 6.8f, 18.6f)
                l(u, 6.8f, 12.6f)
                c(u, 6.8f, 8.6f, 8f, 4.6f, 12f, 0.8f)
                close()
            }
            drawPath(
                path = shell,
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFFFFE082), Color(0xFFFFB300), Color(0xFFE59A00)),
                    startX = 6.8f * u,
                    endX = 17.2f * u,
                ),
            )
            drawRect(Color(0xFFB87A00), topLeft = Offset(6.8f * u, 18.6f * u), size = Size(10.4f * u, 3.2f * u))
            drawRect(Color(0x55FFFFFF), topLeft = Offset(8.6f * u, 7.2f * u), size = Size(1.6f * u, 8f * u))
        }
    }
}

/** Yellow lightning bolt (Chớp). */
@Composable
fun BoltIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawPath(
            path = poly(u, 14.2f, 0.8f, 4.6f, 13f, 10.6f, 13f, 8.6f, 23.2f, 19.4f, 9.8f, 13.4f, 9.8f),
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFFEB6B), Color(0xFFFFC107)),
                startY = 0f,
                endY = size.height,
            ),
        )
    }
}

/** Green stopwatch (Nhanh). */
@Composable
fun StopwatchIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val green = Color(0xFF81B64C)
        drawRect(green, topLeft = Offset(9.6f * u, 0.8f * u), size = Size(4.8f * u, 2.4f * u))
        drawRect(green, topLeft = Offset(11f * u, 3f * u), size = Size(2f * u, 2.4f * u))
        drawCircle(green, radius = 9f * u, center = Offset(12f * u, 14f * u))
        drawCircle(Color(0xFFEFF2E2), radius = 6.8f * u, center = Offset(12f * u, 14f * u))
        drawLine(
            color = Color(0xFF45753C),
            start = Offset(12f * u, 14f * u),
            end = Offset(12f * u, 9.4f * u),
            strokeWidth = 1.7f * u,
            cap = StrokeCap.Round,
        )
        drawLine(
            color = Color(0xFF45753C),
            start = Offset(12f * u, 14f * u),
            end = Offset(15f * u, 16f * u),
            strokeWidth = 1.5f * u,
            cap = StrokeCap.Round,
        )
        drawCircle(Color(0xFF45753C), radius = 1.1f * u, center = Offset(12f * u, 14f * u))
    }
}

/** Sun (Tự do / không giới hạn). */
@Composable
fun SunIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val cx = 12f * u
        val cy = 12f * u
        drawCircle(Color(0xFFFFC107), radius = 5f * u, center = Offset(cx, cy))
        for (i in 0 until 8) {
            val a = i * PI.toFloat() / 4f
            drawLine(
                color = Color(0xFFFFC107),
                start = Offset(cx + cos(a) * 8f * u, cy + sin(a) * 8f * u),
                end = Offset(cx + cos(a) * 10.8f * u, cy + sin(a) * 10.8f * u),
                strokeWidth = 2.2f * u,
                cap = StrokeCap.Round,
            )
        }
    }
}

/** Solid pawn silhouette, used for the Home tab. */
@Composable
fun PawnIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawCircle(color, radius = 3.7f * u, center = Offset(12f * u, 6.6f * u))
        drawRect(color, topLeft = Offset(8f * u, 10.2f * u), size = Size(8f * u, 2f * u))
        val body = Path().apply {
            m(u, 9.2f, 12.2f)
            c(u, 9.2f, 15.8f, 7.4f, 17.4f, 6.6f, 19.4f)
            l(u, 17.4f, 19.4f)
            c(u, 16.6f, 17.4f, 14.8f, 15.8f, 14.8f, 12.2f)
            close()
        }
        drawPath(body, color)
        drawRect(color, topLeft = Offset(5f * u, 19.4f * u), size = Size(14f * u, 3f * u))
    }
}

/** Gold five-point star used on the Learn card. */
@Composable
fun StarIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 11f else 4.9f
            val a = (-90f + i * 36f) * PI.toFloat() / 180f
            val x = (12f + cos(a) * r) * u
            val y = (12.6f + sin(a) * r) * u
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Color(0xFFFFC83D))
        drawPath(path, Color(0xFFB87A00), style = Stroke(width = 1.1f * u))
    }
}

/** Fat green up-arrow on the Learn card. */
@Composable
fun UpArrowIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawPath(
            path = poly(u, 12f, 1f, 22f, 12f, 16f, 12f, 16f, 23f, 8f, 23f, 8f, 12f, 2f, 12f),
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF9BD05C), Color(0xFF5F9A3A)),
                startY = 0f,
                endY = size.height,
            ),
        )
    }
}

/** Board with a plus: "start a game" button glyph on the suggested-game card. */
@Composable
fun AddBoardIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val cell = 5f * u
        for (r in 0 until 3) {
            for (col in 0 until 3) {
                val solid = (r + col) % 2 == 0
                drawRect(
                    color = if (solid) Color.White else Color(0x66FFFFFF),
                    topLeft = Offset((2f * u) + col * cell, (2f * u) + r * cell),
                    size = Size(cell, cell),
                )
            }
        }
        drawCircle(Color.White, radius = 6.2f * u, center = Offset(18f * u, 18f * u))
        drawLine(Color(0xFF45753C), Offset(14.8f * u, 18f * u), Offset(21.2f * u, 18f * u), strokeWidth = 2.2f * u, cap = StrokeCap.Round)
        drawLine(Color(0xFF45753C), Offset(18f * u, 14.8f * u), Offset(18f * u, 21.2f * u), strokeWidth = 2.2f * u, cap = StrokeCap.Round)
    }
}

/** Red count bubble. Callers only show it when [count] > 0. */
@Composable
fun CountBadge(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(16.dp)
            .background(VilaColors.Badge, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (count > 9) "9+" else count.toString(),
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
        )
    }
}

/** The icon matching a rating bucket (bullet, bolt, stopwatch, sun). */
@Composable
fun ModeIcon(mode: com.vila.chess.game.RatingMode, modifier: Modifier = Modifier) {
    when (mode) {
        com.vila.chess.game.RatingMode.BULLET -> BulletIcon(modifier)
        com.vila.chess.game.RatingMode.BLITZ -> BoltIcon(modifier)
        com.vila.chess.game.RatingMode.RAPID -> StopwatchIcon(modifier)
        com.vila.chess.game.RatingMode.DAILY -> SunIcon(modifier)
    }
}

/** Gold medal with a green ribbon ("Các giải đấu"). */
@Composable
fun MedalIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawPath(poly(u, 5.5f, 0.8f, 11.2f, 0.8f, 13.4f, 9.5f, 7.8f, 9.5f), Color(0xFF3E8E41))
        drawPath(poly(u, 12.8f, 0.8f, 18.5f, 0.8f, 16.2f, 9.5f, 10.6f, 9.5f), Color(0xFF256B2A))
        drawCircle(Color(0xFFE6A800), radius = 7.6f * u, center = Offset(12f * u, 15.6f * u))
        drawCircle(Color(0xFFFFC83D), radius = 6.4f * u, center = Offset(12f * u, 15.6f * u))
        drawCircle(Color(0xFFFFE082), radius = 4.2f * u, center = Offset(12f * u, 15.6f * u), style = Stroke(width = 1.1f * u))
    }
}

/** Little monitor with a smiling face ("Chơi với Bot"). */
@Composable
fun ComputerIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        drawRoundRect(Color(0xFFD5E4F2), topLeft = Offset(1.5f * u, 2.5f * u), size = Size(21f * u, 15f * u), cornerRadius = CornerRadius(2.4f * u, 2.4f * u))
        drawRoundRect(Color(0xFF6FB6F2), topLeft = Offset(3.5f * u, 4.5f * u), size = Size(17f * u, 11f * u), cornerRadius = CornerRadius(1.2f * u, 1.2f * u))
        drawCircle(Color(0xFF1B3A5C), radius = 1.2f * u, center = Offset(9f * u, 9f * u))
        drawCircle(Color(0xFF1B3A5C), radius = 1.2f * u, center = Offset(15f * u, 9f * u))
        val smile = Path().apply {
            m(u, 8.6f, 11.8f)
            c(u, 10f, 14f, 14f, 14f, 15.4f, 11.8f)
        }
        drawPath(smile, Color(0xFF1B3A5C), style = Stroke(width = 1.3f * u, cap = StrokeCap.Round))
        drawRect(Color(0xFFB4C8DA), topLeft = Offset(10f * u, 17.5f * u), size = Size(4f * u, 2.6f * u))
        drawRoundRect(Color(0xFFB4C8DA), topLeft = Offset(6.5f * u, 20f * u), size = Size(11f * u, 2.2f * u), cornerRadius = CornerRadius(1.1f * u, 1.1f * u))
    }
}

/** Bearded coach face ("Bật huấn luyện viên"). */
@Composable
fun CoachIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val hair = Color(0xFF6B4A2F)
        drawCircle(Color(0xFFE2AA7E), radius = 9.4f * u, center = Offset(12f * u, 12.4f * u))
        val beard = Path().apply {
            m(u, 2.8f, 13f)
            c(u, 2.8f, 19.6f, 7f, 22.4f, 12f, 22.4f)
            c(u, 17f, 22.4f, 21.2f, 19.6f, 21.2f, 13f)
            c(u, 19f, 15.4f, 15.2f, 16.4f, 12f, 16.4f)
            c(u, 8.8f, 16.4f, 5f, 15.4f, 2.8f, 13f)
            close()
        }
        drawPath(beard, hair)
        val top = Path().apply {
            m(u, 2.8f, 11f)
            c(u, 2.8f, 5f, 7f, 2f, 12f, 2f)
            c(u, 17f, 2f, 21.2f, 5f, 21.2f, 11f)
            c(u, 19.2f, 8.4f, 15.6f, 7.6f, 12f, 7.6f)
            c(u, 8.4f, 7.6f, 4.8f, 8.4f, 2.8f, 11f)
            close()
        }
        drawPath(top, hair)
        drawCircle(Color(0xFF2A1D12), radius = 1.1f * u, center = Offset(8.8f * u, 12f * u))
        drawCircle(Color(0xFF2A1D12), radius = 1.1f * u, center = Offset(15.2f * u, 12f * u))
    }
}

/** Thin chevron used for dropdowns and "show more". */
@Composable
fun ChevronIcon(up: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.minDimension / 24f
        val path = Path()
        if (up) {
            path.moveTo(5f * u, 15f * u)
            path.lineTo(12f * u, 8f * u)
            path.lineTo(19f * u, 15f * u)
        } else {
            path.moveTo(5f * u, 9f * u)
            path.lineTo(12f * u, 16f * u)
            path.lineTo(19f * u, 9f * u)
        }
        drawPath(path, color, style = Stroke(width = 2.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
