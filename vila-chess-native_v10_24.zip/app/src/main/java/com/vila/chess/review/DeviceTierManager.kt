package com.vila.chess.review

import android.app.ActivityManager
import android.content.Context

enum class DeviceTier { LOW, MEDIUM, HIGH }

/** Cấu hình engine cho một dòng máy. moveTimeoutMs = trần thời gian cho MỖI thế cờ. */
data class EngineConfig(
    val tier: DeviceTier,
    val depth: Int,
    val threads: Int,
    val hashMb: Int,
    val moveTimeoutMs: Long = 500L,
)

object DeviceTierManager {

    private const val GB = 1024.0 * 1024.0 * 1024.0

    /**
     * Tự chọn cấu hình theo RAM thật + số nhân CPU:
     *  - LOW    (RAM < 3GB, hoặc máy bật cờ isLowRamDevice): depth 10 (8 nếu <= 4 nhân), 1 thread, hash 16MB
     *  - MEDIUM (3–6GB): depth 14, 2 thread, hash 64MB
     *  - HIGH   (> 6GB): depth 18, 4 thread, hash 128MB
     * Threads luôn bị chặn trên bởi số nhân thực tế.
     * Lưu ý: máy quảng cáo "4GB" thường báo totalMem ~3.6GB nên vẫn rơi vào MEDIUM.
     */
    fun getDeviceTier(context: Context): EngineConfig {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = info.totalMem / GB
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

        val tier = when {
            am.isLowRamDevice || ramGb < 3.0 -> DeviceTier.LOW
            ramGb <= 6.0 -> DeviceTier.MEDIUM
            else -> DeviceTier.HIGH
        }
        return when (tier) {
            DeviceTier.LOW -> EngineConfig(
                tier, depth = if (cores <= 4) 8 else 10,
                threads = 1, hashMb = 16,
            )
            DeviceTier.MEDIUM -> EngineConfig(
                tier, depth = 14, threads = minOf(2, cores), hashMb = 64,
            )
            DeviceTier.HIGH -> EngineConfig(
                tier, depth = 18, threads = minOf(4, cores), hashMb = 128,
            )
        }
    }
}
