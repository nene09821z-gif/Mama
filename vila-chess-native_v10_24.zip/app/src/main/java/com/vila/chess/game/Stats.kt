package com.vila.chess.game

import android.content.SharedPreferences
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

/** Rating buckets shown in the "Hệ số" row of the home screen. */
enum class RatingMode(val label: String) {
    BULLET("Siêu chớp"),
    BLITZ("Chớp"),
    RAPID("Nhanh"),
    DAILY("Tự do"),
}

/** Maps a time control to its rating bucket (chess.com style: estimated duration = base + 40 * increment). */
fun modeFor(tc: TimeControl): RatingMode {
    if (tc.baseSec <= 0) return RatingMode.DAILY
    val est = tc.baseSec + 40 * tc.incSec
    return when {
        est < 180 -> RatingMode.BULLET
        est < 600 -> RatingMode.BLITZ
        else -> RatingMode.RAPID
    }
}

/** Time-control indices grouped by rating bucket, each group sorted from fastest to slowest. */
fun timeGroups(): List<Pair<RatingMode, List<Int>>> {
    val out = ArrayList<Pair<RatingMode, List<Int>>>()
    for (mode in RatingMode.values()) {
        val idx = TimeControls.all.indices
            .filter { modeFor(TimeControls.all[it]) == mode }
            .sortedBy { TimeControls.all[it].baseSec + 40 * TimeControls.all[it].incSec }
        if (idx.isNotEmpty()) out.add(Pair(mode, idx))
    }
    return out
}

class Achievement(val title: String, val desc: String, val done: Boolean)

fun achievements(s: PlayerStats, tournamentsDone: Int, today: Long): List<Achievement> = listOf(
    Achievement("Ván đầu tiên", "Chơi xong một ván cờ", s.played >= 1),
    Achievement("Chiến thắng đầu tiên", "Thắng một ván với máy", s.won >= 1),
    Achievement("Chăm chỉ", "Chơi xong 10 ván", s.played >= 10),
    Achievement("Chuỗi 3 ngày", "Chơi 3 ngày liên tiếp", s.activeStreak(today) >= 3),
    Achievement("Hệ số 1000", "Đạt hệ số 1000 ở một thể loại", s.ratings.any { it >= 1000 }),
    Achievement("Hoàn thành giải đấu", "Đấu hết 8 vòng giải đấu bot", tournamentsDone >= 1),
)

/** Approximate playing strength of each bot level, used for the Elo update and for suggesting an opponent. */
val LEVEL_RATING = intArrayOf(400, 600, 800, 1000, 1300, 1600, 1900, 2200)

fun levelRating(levelId: Int): Int = LEVEL_RATING[(levelId - 1).coerceIn(0, LEVEL_RATING.size - 1)]

/** The bot level whose strength is closest to [rating] (ties go to the weaker bot). */
fun suggestLevel(rating: Int): Int {
    var best = 0
    for (i in LEVEL_RATING.indices) {
        if (abs(LEVEL_RATING[i] - rating) < abs(LEVEL_RATING[best] - rating)) best = i
    }
    return best + 1
}

data class PlayerStats(
    val ratings: List<Int> = List(4) { 800 },
    val streak: Int = 0,
    val lastDay: Long = -1L,
    val played: Int = 0,
    val won: Int = 0,
    val drawn: Int = 0,
    val lost: Int = 0,
) {
    fun rating(mode: RatingMode): Int = ratings[mode.ordinal]

    /** Streak that is still alive today: it breaks if yesterday was missed. */
    fun activeStreak(today: Long): Int = if (lastDay >= 0L && lastDay >= today - 1) streak else 0
}

object StatsStore {
    private const val K_FACTOR = 32.0
    private const val MIN_RATING = 100

    /** Local calendar day number (days since epoch in the device time zone). */
    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    fun load(prefs: SharedPreferences): PlayerStats = PlayerStats(
        ratings = List(4) { prefs.getInt("rating_" + it, 800) },
        streak = prefs.getInt("streak", 0),
        lastDay = prefs.getLong("lastDay", -1L),
        played = prefs.getInt("played", 0),
        won = prefs.getInt("won", 0),
        drawn = prefs.getInt("drawn", 0),
        lost = prefs.getInt("lost", 0),
    )

    /** Pure Elo + streak update; [score] is 1.0 for a win, 0.5 for a draw, 0.0 for a loss. */
    fun applyResult(old: PlayerStats, mode: RatingMode, levelId: Int, score: Double, today: Long): PlayerStats {
        val r = old.rating(mode)
        val expected = 1.0 / (1.0 + 10.0.pow((levelRating(levelId) - r) / 400.0))
        val delta = (K_FACTOR * (score - expected)).roundToInt()
        val next = old.ratings.toMutableList()
        next[mode.ordinal] = (r + delta).coerceAtLeast(MIN_RATING)
        val streak = when {
            old.lastDay == today -> maxOf(old.streak, 1)
            old.lastDay == today - 1 -> old.streak + 1
            else -> 1
        }
        return old.copy(
            ratings = next,
            streak = streak,
            lastDay = today,
            played = old.played + 1,
            won = old.won + if (score == 1.0) 1 else 0,
            drawn = old.drawn + if (score == 0.5) 1 else 0,
            lost = old.lost + if (score == 0.0) 1 else 0,
        )
    }

    fun record(prefs: SharedPreferences, old: PlayerStats, mode: RatingMode, levelId: Int, score: Double): PlayerStats {
        val s = applyResult(old, mode, levelId, score, today())
        val e = prefs.edit()
        for (i in s.ratings.indices) e.putInt("rating_" + i, s.ratings[i])
        e.putInt("streak", s.streak)
        e.putLong("lastDay", s.lastDay)
        e.putInt("played", s.played)
        e.putInt("won", s.won)
        e.putInt("drawn", s.drawn)
        e.putInt("lost", s.lost)
        e.apply()
        return s
    }
}

/** Short onboarding tips behind the bell icon; the badge shows how many are unread. */
val HOME_TIPS: List<Pair<String, String>> = listOf(
    "Chào mừng đến ViLa Chess" to "Chơi xong một ván để nhận hệ số riêng cho từng thể loại: Siêu chớp, Chớp, Nhanh và Tự do.",
    "Mẹo đi quân" to "Kéo thả quân hoặc chạm để chọn rồi chạm ô đích. Khi chưa tới lượt, bạn có thể đặt trước nước đi.",
)
