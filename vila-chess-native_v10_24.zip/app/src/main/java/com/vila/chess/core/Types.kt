package com.vila.chess.core

// Piece codes: 0 empty, 1..6 = white P N B R Q K, +8 for black.
const val EMPTY = 0
const val PAWN = 1
const val KNIGHT = 2
const val BISHOP = 3
const val ROOK = 4
const val QUEEN = 5
const val KING = 6
const val BLACK_BIT = 8

const val CR_WK = 1
const val CR_WQ = 2
const val CR_BK = 4
const val CR_BQ = 8

const val FLAG_NONE = 0
const val FLAG_DOUBLE = 1
const val FLAG_EP = 2
const val FLAG_CASTLE = 3

// Squares: index = rank * 8 + file, a1 = 0, h1 = 7, a8 = 56, h8 = 63.
fun pieceType(p: Int): Int = p and 7
fun isWhitePiece(p: Int): Boolean = p in 1..6
fun isBlackPiece(p: Int): Boolean = p >= 9
fun makePiece(type: Int, white: Boolean): Int = if (white) type else type + BLACK_BIT

fun sqRank(sq: Int): Int = sq shr 3
fun sqFile(sq: Int): Int = sq and 7
fun sqName(sq: Int): String = "" + ('a' + (sq and 7)) + ((sq shr 3) + 1)

// Move = from | to << 6 | promoType << 12 | flag << 15
fun moveOf(from: Int, to: Int, promo: Int = 0, flag: Int = FLAG_NONE): Int =
    from or (to shl 6) or (promo shl 12) or (flag shl 15)

fun moveFrom(m: Int): Int = m and 63
fun moveTo(m: Int): Int = (m shr 6) and 63
fun movePromo(m: Int): Int = (m shr 12) and 7
fun moveFlag(m: Int): Int = (m shr 15) and 3

fun moveUci(m: Int): String {
    val promo = movePromo(m)
    val suffix = if (promo != 0) "??nbrq"[promo].toString() else ""
    return sqName(moveFrom(m)) + sqName(moveTo(m)) + suffix
}

fun pieceValue(type: Int): Int = when (type) {
    PAWN -> 100
    KNIGHT -> 320
    BISHOP -> 330
    ROOK -> 500
    QUEEN -> 900
    else -> 0
}
