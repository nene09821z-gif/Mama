package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

private class Star(val x: Float, val y: Float, val r: Float, val a: Float)

/** Deep-blue starfield behind the home screen. Drawn once, no animation (cheap on weak phones). */
@Composable
fun SpaceBackground(modifier: Modifier = Modifier) {
    val stars = remember {
        val rnd = Random(7)
        List(120) {
            Star(
                x = rnd.nextFloat(),
                y = rnd.nextFloat(),
                r = 0.5f + rnd.nextFloat() * 1.3f,
                a = 0.12f + rnd.nextFloat() * 0.55f,
            )
        }
    }
    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(VilaColors.SpaceTop, VilaColors.SpaceMid, VilaColors.SpaceBottom),
            ),
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x552F6FD0), Color.Transparent),
                center = Offset(size.width * 0.88f, size.height * 0.84f),
                radius = size.width * 0.95f,
            ),
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x33A24FD0), Color.Transparent),
                center = Offset(size.width * 0.08f, size.height * 0.36f),
                radius = size.width * 0.7f,
            ),
        )
        for (s in stars) {
            drawCircle(
                color = Color.White.copy(alpha = s.a),
                radius = s.r * density,
                center = Offset(s.x * size.width, s.y * size.height),
            )
        }
    }
}
