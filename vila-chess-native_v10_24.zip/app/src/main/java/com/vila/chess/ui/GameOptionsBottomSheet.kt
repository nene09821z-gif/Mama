package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Màu của 2 màn Tùy chọn / Tùy chỉnh – sửa ở đây là đổi cả hai. */
object OptionsColors {
    val Sheet = Color(0xFF2B2A28)       // nền xám đen của bottom sheet
    val Header = Color(0xFF22211F)      // nền thanh tiêu đề (đậm hơn một chút)
    val Divider = Color(0xFF3C3A37)
    val Green = Color(0xFF81B64C)       // xanh chess.com
    val GreenEdge = Color(0xFF45753C)
    val Text = Color.White
    val TextDisabled = Color(0x73FFFFFF) // trắng 45% => trạng thái disabled
    val TrackOff = Color(0xFF3C3A37)
    val BorderOff = Color(0xFF5A5856)
    val ThumbOff = Color(0xFFB9B7B4)
}

/**
 * Menu "Các tùy chọn" dạng BottomSheet.
 * [onOpenSettings] được gọi khi bấm "Các tùy chỉnh" (host sẽ mở màn GameSettingsScreen).
 * "Chia sẻ ván cờ" mặc định bị mờ + không bấm được (đổi bằng [shareEnabled]).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameOptionsBottomSheet(
    onDismiss: () -> Unit,
    onFlipBoard: () -> Unit,
    onExplore: () -> Unit,
    onShare: () -> Unit = {},
    onSaveGame: () -> Unit,
    onOpenSettings: () -> Unit,
    shareEnabled: Boolean = false,
    onOfferDraw: (() -> Unit)? = null,
    onNewGame: (() -> Unit)? = null,
) {
    // Mở thẳng ở trạng thái đầy đủ (menu ngắn, không cần nửa chừng).
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = OptionsColors.Sheet,
        contentColor = OptionsColors.Text,
        dragHandle = null,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            // Header: tiêu đề trái, nút X phải
            Row(
                Modifier.fillMaxWidth().background(OptionsColors.Header).padding(start = 24.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Các tùy chọn", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = OptionsColors.Text)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Đóng", tint = OptionsColors.TextDisabled)
                }
            }
            // Mỗi item: clickable => ripple mặc định của Material 3.
            OptionItem("Xoay bàn cờ", onClick = { onFlipBoard(); onDismiss() })
            OptionItem("Khám phá", onClick = { onExplore(); onDismiss() })
            OptionItem("Chia sẻ ván cờ", enabled = shareEnabled, onClick = { onShare(); onDismiss() })
            OptionItem("Lưu ván đấu", onClick = { onSaveGame(); onDismiss() })
            onOfferDraw?.let { act -> OptionItem("Xin hòa", onClick = { act(); onDismiss() }) }
            onNewGame?.let { act -> OptionItem("Ván mới", onClick = { act(); onDismiss() }) }
            OptionItem("Các tùy chỉnh", onClick = onOpenSettings)
        }
    }
}

@Composable
private fun OptionItem(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Text(
        text = text,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = if (enabled) OptionsColors.Text else OptionsColors.TextDisabled,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp),
    )
}
