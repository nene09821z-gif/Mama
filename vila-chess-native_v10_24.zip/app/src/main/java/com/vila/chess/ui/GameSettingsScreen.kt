package com.vila.chess.ui

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.settings.GameSettingsState
import com.vila.chess.settings.SettingsViewModel
import kotlin.math.roundToInt

private const val TAG = "GameSettings"

/**
 * Màn "Các tùy chỉnh": thanh trượt + 7 nút gạt + nút Lưu.
 * State nằm ở [SettingsViewModel] (StateFlow) nên kéo/gạt là UI đổi ngay.
 * [onClose] gọi sau khi bấm Lưu (host đóng màn hình).
 */
@Composable
fun GameSettingsScreen(
    onClose: () -> Unit,
    viewModel: SettingsViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Column(
        Modifier.fillMaxSize().background(OptionsColors.Sheet).statusBarsPadding().navigationBarsPadding(),
    ) {
        // Phần cuộn được (máy màn hình nhỏ vẫn thấy hết), nút Lưu ghim ở đáy.
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 16.dp),
        ) {
            SliderSetting(
                title = "Kiểu chủ đề lớn nhất",
                value = state.sliderValue,
                onValueChange = viewModel::onSliderChange,
            )
            Spacer(Modifier.height(8.dp))
            SettingsSwitchRow("Thanh đánh giá", state.isEvalBarEnabled, viewModel::onEvalBar)
            SettingsSwitchRow("Phản Hồi nước đi", state.isMoveFeedbackEnabled, viewModel::onMoveFeedback)
            SettingsSwitchRow("Bộ máy", state.isEngineEnabled, viewModel::onEngine)
            SettingsSwitchRow("Gợi ý", state.isHintsEnabled, viewModel::onHints)
            SettingsSwitchRow("Mũi tên gợi ý", state.isSuggestionArrowsEnabled, viewModel::onSuggestionArrows)
            SettingsSwitchRow("Các mối đe doạ", state.isThreatArrowsEnabled, viewModel::onThreatArrows)
            SettingsSwitchRow("Takeback", state.isTakebackEnabled, viewModel::onTakeback)
        }
        GreenSaveButton(
            text = "Tiết kiệm",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Log.d(TAG, "Saved: $state")   // in ra Logcat để test (lọc theo tag "GameSettings")
            onClose()
        }
    }
}

/** Tiêu đề trái + giá trị phải, bên dưới là Slider xanh. */
@Composable
private fun SliderSetting(title: String, value: Float, onValueChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = OptionsColors.TextDisabled.copy(alpha = 0.8f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(value.roundToInt().toString(), color = OptionsColors.TextDisabled.copy(alpha = 0.8f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        // Màu Slider: sửa 3 dòng trong SliderDefaults.colors bên dưới.
        val colors = SliderDefaults.colors(
            thumbColor = OptionsColors.Green,
            activeTrackColor = OptionsColors.Green,
            inactiveTrackColor = OptionsColors.TrackOff,
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = GameSettingsState.SLIDER_MIN..GameSettingsState.SLIDER_MAX,
            colors = colors,
        )
    }
}

/** Một hàng cài đặt dùng lại được: chữ bên trái, Switch bên phải. Bấm cả hàng cũng gạt được. */
@Composable
fun SettingsSwitchRow(
    title: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    // Màu Switch: bật = thumb trắng + track xanh; tắt = thumb xám + track xám đậm có viền.
    val colors = SwitchDefaults.colors(
        checkedThumbColor = androidx.compose.ui.graphics.Color.White,
        checkedTrackColor = OptionsColors.Green,
        checkedBorderColor = OptionsColors.Green,
        uncheckedThumbColor = OptionsColors.ThumbOff,
        uncheckedTrackColor = OptionsColors.TrackOff,
        uncheckedBorderColor = OptionsColors.BorderOff,
    )
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(role = Role.Switch) { onCheckedChange(!isChecked) }
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, color = OptionsColors.TextDisabled.copy(alpha = 0.8f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Switch(checked = isChecked, onCheckedChange = null, colors = colors)   // null: cả hàng nhận chạm, tránh xử lý 2 lần
    }
}

/** Nút xanh 3D bo 12dp, nhấn thì lún xuống (giống nút chess.com). */
@Composable
private fun GreenSaveButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val depth = if (pressed) 1.dp else 4.dp
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.fillMaxWidth().height(60.dp).clip(shape).background(OptionsColors.GreenEdge)
            .clickable(interactionSource = src, indication = null, role = Role.Button, onClick = onClick),
    ) {
        Box(
            Modifier.fillMaxWidth().height(60.dp - depth).clip(shape).background(OptionsColors.Green),
            contentAlignment = Alignment.Center,
        ) { Text(text, color = androidx.compose.ui.graphics.Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
    }
}
