package com.vila.chess.review

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.delay

class DeviceHealthMonitor(private val context: Context) {

    companion object {
        const val MAX_TEMP_C = 40f
        const val COOL_DOWN_MS = 60_000L
    }

    /** Nhiệt độ pin (°C). EXTRA_TEMPERATURE tính bằng 1/10 độ. Trả -1 nếu máy không báo. */
    fun batteryTempC(): Float {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return if (raw <= 0) -1f else raw / 10f
    }

    fun isTooHot(): Boolean = batteryTempC() > MAX_TEMP_C

    /**
     * Nếu máy nóng: gọi onHot() (dừng/giải phóng engine) rồi chờ 1 phút, lặp lại.
     * Trả true khi đã nguội; false nếu hết [maxRounds] vẫn nóng (worker nên retry sau).
     */
    suspend fun awaitCoolDown(maxRounds: Int = 5, onHot: suspend () -> Unit = {}): Boolean {
        var rounds = 0
        while (isTooHot()) {
            if (rounds++ >= maxRounds) return false
            onHot()
            delay(COOL_DOWN_MS)
        }
        return true
    }
}
