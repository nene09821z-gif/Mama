package com.vila.chess.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VilaColors {
    val Bg = Color(0xFF262522)
    val Panel = Color(0xFF302E2B)
    val PanelDark = Color(0xFF21201D)
    val Green = Color(0xFF81B64C)
    val GreenPressed = Color(0xFF6A9A3E)
    val GreenShadow = Color(0xFF45753C)
    val Text = Color(0xFFFFFFFF)
    val TextDim = Color(0xFFBABABA)
    val BoardLight = Color(0xFFEBECD0)
    val BoardDark = Color(0xFF739552)
    val Highlight = Color(0xBFF5F682)
    val PremoveRed = Color(0xA6EB6150)
    val ClockActive = Color(0xFFFFFFFF)
    val ClockIdle = Color(0xFF403D39)
    val Danger = Color(0xFFE05A47)

    // Home screen ("space" look)
    val SpaceTop = Color(0xFF0A1530)
    val SpaceMid = Color(0xFF10264A)
    val SpaceBottom = Color(0xFF0A1226)
    val Glass = Color(0xA61B2D4A)
    val GlassBorder = Color(0x22FFFFFF)
    val NavIdle = Color(0xFF9AA6BA)
    val Badge = Color(0xFFE5392B)
    val GreenDeep = Color(0xFF2C4A24)
}

@Composable
fun ViLaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VilaColors.Green,
            onPrimary = Color.White,
            secondary = VilaColors.Green,
            background = VilaColors.Bg,
            onBackground = VilaColors.Text,
            surface = VilaColors.Panel,
            onSurface = VilaColors.Text,
            surfaceVariant = VilaColors.PanelDark,
            onSurfaceVariant = VilaColors.TextDim
        ),
        content = content
    )
}
