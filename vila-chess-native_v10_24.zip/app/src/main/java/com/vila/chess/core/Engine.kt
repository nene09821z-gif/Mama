package com.vila.chess.core

class SearchLimits(val maxDepth: Int, val timeMs: Long, val noiseCp: Int)

/** Alpha-beta engine: iterative deepening, quiescence, MVV-LVA + killer ordering, simple PST evaluation. */
class Engine {
    companion object {
        const val MATE = 30000
        const val INF = 32000
        private const val MAX_PLY = 96
    }

    private lateinit var pos: Position
    private val moveBufs = Array(MAX_PLY) { IntArray(MAX_MOVES) }
    private val scoreBufs = Array(MAX_PLY) { IntArray(MAX_MOVES) }
    private val killers = Array(MAX_PLY) { IntArray(2) }
    private var nodes = 0L
    private var deadline = 0L
    private var stopped = false
    private var currentDepth = 1

    /** Polled during the search; return true to abort as soon as possible. */
    @Volatile
    var cancelled: () -> Boolean = { false }

    var lastDepth = 0
        private set
    var lastScore = 0
        private set
    var lastNodes = 0L
        private set

    /** Returns the chosen move (0 when the side to move has no legal move). */
    fun findBestMove(root: Position, limits: SearchLimits): Int {
        pos = root.copy()
        nodes = 0
        stopped = false
        currentDepth = 1
        deadline = System.currentTimeMillis() + limits.timeMs
        for (k in killers) {
            k[0] = 0
            k[1] = 0
        }
        val rootMoves = IntArray(MAX_MOVES)
        val rootCount = pos.generateLegal(rootMoves)
        if (rootCount == 0) return 0
        if (rootCount == 1) {
            lastDepth = 0
            lastScore = 0
            return rootMoves[0]
        }
        var bestMove = rootMoves[0]
        var bestScore = -INF
        var finalScores = IntArray(rootCount)
        var finalMoves = rootMoves.copyOf(rootCount)
        val useFullWindow = limits.noiseCp > 0

        for (depth in 1..limits.maxDepth) {
            currentDepth = depth
            orderRoot(rootMoves, rootCount, bestMove)
            val iterScores = IntArray(rootCount)
            var alpha = -INF
            var iterBest = rootMoves[0]
            var iterBestScore = -INF
            for (i in 0 until rootCount) {
                val m = rootMoves[i]
                pos.make(m)
                val score = if (useFullWindow) {
                    -negamax(depth - 1, 1, -INF, INF)
                } else {
                    -negamax(depth - 1, 1, -INF, -alpha)
                }
                pos.unmake()
                if (stopped && depth > 1) break
                iterScores[i] = score
                if (score > iterBestScore) {
                    iterBestScore = score
                    iterBest = m
                }
                if (score > alpha) alpha = score
            }
            if (stopped && depth > 1) break
            bestMove = iterBest
            bestScore = iterBestScore
            finalScores = iterScores
            finalMoves = rootMoves.copyOf(rootCount)
            lastDepth = depth
            lastScore = bestScore
            if (bestScore >= MATE - 100) break
            if (System.currentTimeMillis() > deadline && depth >= 2) break
        }
        lastNodes = nodes

        if (limits.noiseCp > 0) {
            // Pick randomly among the moves that are within noiseCp of the best one (weaker levels).
            val candidates = ArrayList<Int>()
            for (i in finalMoves.indices) {
                if (finalScores[i] >= bestScore - limits.noiseCp && finalScores[i] > -MATE + 200) {
                    candidates.add(finalMoves[i])
                }
            }
            if (candidates.isNotEmpty()) {
                return candidates[(Math.random() * candidates.size).toInt().coerceIn(0, candidates.size - 1)]
            }
        }
        return bestMove
    }

    private fun orderRoot(moves: IntArray, count: Int, first: Int) {
        for (i in 0 until count) {
            if (moves[i] == first) {
                val tmp = moves[0]
                moves[0] = moves[i]
                moves[i] = tmp
                break
            }
        }
        // order the rest by capture value so alpha rises quickly
        val scores = IntArray(count)
        for (i in 1 until count) scores[i] = captureScore(moves[i])
        for (i in 2 until count) {
            var j = i
            while (j > 1 && scores[j] > scores[j - 1]) {
                val ts = scores[j]
                scores[j] = scores[j - 1]
                scores[j - 1] = ts
                val tm = moves[j]
                moves[j] = moves[j - 1]
                moves[j - 1] = tm
                j--
            }
        }
    }

    private fun captureScore(m: Int): Int {
        val victim = if (moveFlag(m) == FLAG_EP) PAWN else pieceType(pos.board[moveTo(m)])
        val attacker = pieceType(pos.board[moveFrom(m)])
        var s = 0
        if (victim != 0) s += 10000 + victim * 16 - attacker
        if (movePromo(m) == QUEEN) s += 9000
        return s
    }

    private fun checkTime() {
        if (cancelled()) {
            stopped = true
        } else if (currentDepth > 1 && System.currentTimeMillis() > deadline) {
            stopped = true
        }
    }

    private fun scoreMoves(moves: IntArray, scores: IntArray, count: Int, ply: Int) {
        val k0 = killers[ply][0]
        val k1 = killers[ply][1]
        for (i in 0 until count) {
            val m = moves[i]
            var s = captureScore(m)
            if (s == 0) {
                if (m == k0) s = 8000 else if (m == k1) s = 7000
            }
            scores[i] = s
        }
    }

    private fun negamax(depthIn: Int, ply: Int, alphaIn: Int, beta: Int): Int {
        var depth = depthIn
        var alpha = alphaIn
        nodes++
        if ((nodes and 2047L) == 0L) checkTime()
        if (stopped) return 0
        val side = pos.whiteToMove
        val inCheck = pos.inCheck(side)
        if (inCheck && ply < MAX_PLY - 8) depth++
        if (depth <= 0) return quiesce(alpha, beta, ply)
        if (pos.halfmove >= 100) return 0
        if (ply >= MAX_PLY - 2) return evaluate()

        val moves = moveBufs[ply]
        val scores = scoreBufs[ply]
        val count = pos.generatePseudo(moves)
        scoreMoves(moves, scores, count, ply)
        var legal = 0
        var best = -INF
        for (i in 0 until count) {
            var bi = i
            var bs = scores[i]
            for (j in i + 1 until count) {
                if (scores[j] > bs) {
                    bs = scores[j]
                    bi = j
                }
            }
            if (bi != i) {
                val tm = moves[i]
                moves[i] = moves[bi]
                moves[bi] = tm
                val ts = scores[i]
                scores[i] = scores[bi]
                scores[bi] = ts
            }
            val m = moves[i]
            pos.make(m)
            if (pos.inCheck(side)) {
                pos.unmake()
                continue
            }
            legal++
            val score = -negamax(depth - 1, ply + 1, -beta, -alpha)
            pos.unmake()
            if (stopped) return 0
            if (score > best) {
                best = score
                if (score > alpha) {
                    alpha = score
                    if (alpha >= beta) {
                        if (pos.board[moveTo(m)] == EMPTY && movePromo(m) == 0 && moveFlag(m) != FLAG_EP) {
                            if (killers[ply][0] != m) {
                                killers[ply][1] = killers[ply][0]
                                killers[ply][0] = m
                            }
                        }
                        break
                    }
                }
            }
        }
        if (legal == 0) return if (inCheck) -MATE + ply else 0
        return best
    }

    private fun quiesce(alphaIn: Int, beta: Int, ply: Int): Int {
        var alpha = alphaIn
        nodes++
        if ((nodes and 2047L) == 0L) checkTime()
        if (stopped) return 0
        val stand = evaluate()
        if (ply >= MAX_PLY - 2) return stand
        if (stand >= beta) return stand
        if (stand > alpha) alpha = stand

        val side = pos.whiteToMove
        val moves = moveBufs[ply]
        val scores = scoreBufs[ply]
        val total = pos.generatePseudo(moves)
        var count = 0
        for (i in 0 until total) {
            val s = captureScore(moves[i])
            if (s > 0) {
                moves[count] = moves[i]
                scores[count] = s
                count++
            }
        }
        for (i in 0 until count) {
            var bi = i
            var bs = scores[i]
            for (j in i + 1 until count) {
                if (scores[j] > bs) {
                    bs = scores[j]
                    bi = j
                }
            }
            if (bi != i) {
                val tm = moves[i]
                moves[i] = moves[bi]
                moves[bi] = tm
                val ts = scores[i]
                scores[i] = scores[bi]
                scores[bi] = ts
            }
            val m = moves[i]
            pos.make(m)
            if (pos.inCheck(side)) {
                pos.unmake()
                continue
            }
            val score = -quiesce(-beta, -alpha, ply + 1)
            pos.unmake()
            if (stopped) return 0
            if (score >= beta) return score
            if (score > alpha) alpha = score
        }
        return alpha
    }

    /** Static evaluation in centipawns from the point of view of the side to move. */
    fun evaluate(): Int = evaluate(pos)

    fun evaluate(p: Position): Int {
        val b = p.board
        var nonPawn = 0
        var whiteBishops = 0
        var blackBishops = 0
        for (sq in 0 until 64) {
            val pc = b[sq]
            if (pc == EMPTY) continue
            val t = pieceType(pc)
            if (t != PAWN && t != KING) nonPawn += pieceValue(t)
            if (t == BISHOP) {
                if (isWhitePiece(pc)) whiteBishops++ else blackBishops++
            }
        }
        val endgame = nonPawn <= 2600
        var score = 0
        for (sq in 0 until 64) {
            val pc = b[sq]
            if (pc == EMPTY) continue
            val t = pieceType(pc)
            val white = isWhitePiece(pc)
            val idx = if (white) sq xor 56 else sq
            val table = when (t) {
                PAWN -> PST_PAWN_MG
                KNIGHT -> PST_KNIGHT_MG
                BISHOP -> PST_BISHOP_MG
                ROOK -> PST_ROOK_MG
                QUEEN -> PST_QUEEN_MG
                else -> if (endgame) PST_KING_EG else PST_KING_MG
            }
            val v = pieceValue(t) + table[idx]
            if (white) score += v else score -= v
        }
        if (whiteBishops >= 2) score += 30
        if (blackBishops >= 2) score -= 30
        return if (p.whiteToMove) score + 10 else -score + 10
    }
}
