package com.vila.chess.billing

/**
 * Định nghĩa gói thành viên + phân quyền tính năng.
 * BẢN NÀY PHẢI KHỚP với web-paywall/shared/membership-spec.js (nguồn sự thật dùng chung hai nền tảng).
 * Muốn đổi quyền lợi: sửa Ở HAI NƠI, không rải `if (tier == ...)` trong UI.
 */
enum class MembershipTier(val id: String, val displayName: String, val rank: Int) {
    FREE("free", "Miễn phí", 0),
    GOLD("gold", "Gold", 1),
    PLATINUM("platinum", "Platinum", 2),
    DIAMOND("diamond", "Diamond", 3);

    companion object {
        fun fromId(id: String?): MembershipTier = values().firstOrNull { it.id == id } ?: FREE
    }
}

/** Tính năng "có / không". Các gói cao hơn tự động gồm gói thấp hơn (so theo rank). */
enum class Feature(val minTier: MembershipTier, val label: String) {
    AD_FREE(MembershipTier.GOLD, "Không quảng cáo"),
    UNLIMITED_PUZZLES(MembershipTier.GOLD, "Câu đố không giới hạn"),
    UNLIMITED_LESSONS(MembershipTier.GOLD, "Bài học không giới hạn"),
    GAME_REVIEW(MembershipTier.PLATINUM, "Game Review không giới hạn"),
    COACH_EXPLANATIONS(MembershipTier.DIAMOND, "Huấn luyện viên giải thích nước đi"),
    INSIGHTS(MembershipTier.DIAMOND, "Insights"),
    ADVANCED_STATS(MembershipTier.DIAMOND, "Thống kê nâng cao"),
}

/** Hạn mức theo ngày cho gói chưa mở khóa [unlockedBy]. */
enum class Quota(val unlockedBy: Feature, val limitWhenLocked: Int) {
    PUZZLES(Feature.UNLIMITED_PUZZLES, 3),
    LESSONS(Feature.UNLIMITED_LESSONS, 3), // giả định: đề bài chưa nêu số bài học miễn phí
    GAME_REVIEW(Feature.GAME_REVIEW, 1),   // Free và Gold: 1 ván/ngày
}

fun hasAccess(feature: Feature, tier: MembershipTier): Boolean = tier.rank >= feature.minTier.rank

/** null = không giới hạn. */
fun dailyLimit(quota: Quota, tier: MembershipTier): Int? =
    if (hasAccess(quota.unlockedBy, tier)) null else quota.limitWhenLocked

fun showAds(tier: MembershipTier): Boolean = !hasAccess(Feature.AD_FREE, tier)

/** Gói rẻ nhất mở khóa tính năng này (dùng cho dòng "Cần gói Platinum"). */
fun requiredTier(feature: Feature): MembershipTier = feature.minTier

/** Nội dung hiển thị trên thẻ gói (đã cộng dồn kiểu "Gồm tất cả của gói trước"). */
object TierInfo {
    fun highlights(tier: MembershipTier): List<String> = when (tier) {
        MembershipTier.FREE -> listOf("Game Review 1 ván/ngày", "3 câu đố/ngày", "Có quảng cáo")
        MembershipTier.GOLD -> listOf(
            "Không quảng cáo",
            "Câu đố & bài học không giới hạn",
            "Game Review 1 ván/ngày",
        )
        MembershipTier.PLATINUM -> listOf(
            "Gồm tất cả quyền lợi Gold",
            "Game Review không giới hạn",
        )
        MembershipTier.DIAMOND -> listOf(
            "Gồm tất cả quyền lợi Platinum",
            "Huấn luyện viên giải thích nước đi",
            "Insights",
            "Thống kê nâng cao",
        )
    }
}
