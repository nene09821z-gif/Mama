package com.vila.chess.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.vila.chess.R

enum class Sfx { MOVE, CAPTURE, CASTLE, CHECK, PROMOTE, END }

class SoundPlayer(context: Context) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private val ids = HashMap<Sfx, Int>()

    var enabled: Boolean = true

    init {
        ids[Sfx.MOVE] = pool.load(context, R.raw.move, 1)
        ids[Sfx.CAPTURE] = pool.load(context, R.raw.capture, 1)
        ids[Sfx.CASTLE] = pool.load(context, R.raw.castle, 1)
        ids[Sfx.CHECK] = pool.load(context, R.raw.check, 1)
        ids[Sfx.PROMOTE] = pool.load(context, R.raw.promote, 1)
        ids[Sfx.END] = pool.load(context, R.raw.gameend, 1)
    }

    fun play(sfx: Sfx) {
        if (!enabled) return
        val id = ids[sfx] ?: return
        pool.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        pool.release()
    }
}

class Haptics(context: Context) {
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    var enabled: Boolean = true

    fun tick(strong: Boolean) {
        if (!enabled) return
        val v = vibrator ?: return
        try {
            val ms = if (strong) 22L else 10L
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, if (strong) 160 else 80))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) {
            // vibration is best-effort only
        }
    }
}
