package com.vila.chess.game

import com.vila.chess.core.SearchLimits

class Level(val id: Int, val name: String, val limits: SearchLimits)

object Levels {
    val all: List<Level> = listOf(
        Level(1, "Mới tập chơi", SearchLimits(1, 300, 250)),
        Level(2, "Người chơi nhí", SearchLimits(2, 500, 150)),
        Level(3, "Nghiệp dư", SearchLimits(3, 800, 80)),
        Level(4, "Câu lạc bộ", SearchLimits(4, 1200, 35)),
        Level(5, "Khá", SearchLimits(5, 2000, 0)),
        Level(6, "Mạnh", SearchLimits(6, 3000, 0)),
        Level(7, "Rất mạnh", SearchLimits(8, 5000, 0)),
        Level(8, "Bậc thầy", SearchLimits(10, 8000, 0))
    )

    fun get(id: Int): Level = all[(id - 1).coerceIn(0, all.size - 1)]
}

class TimeControl(val label: String, val baseSec: Int, val incSec: Int)

object TimeControls {
    val all: List<TimeControl> = listOf(
        TimeControl("Không giới hạn", 0, 0),
        TimeControl("3 phút", 180, 0),
        TimeControl("5 phút", 300, 0),
        TimeControl("10 phút", 600, 0),
        TimeControl("3 | 2", 180, 2),
        TimeControl("10 | 5", 600, 5),
        TimeControl("1 phút", 60, 0),
        TimeControl("1 | 1", 60, 1),
        TimeControl("2 | 1", 120, 1),
        TimeControl("5 | 5", 300, 5),
        TimeControl("15 | 10", 900, 10),
        TimeControl("30 phút", 1800, 0)
    )

    fun get(index: Int): TimeControl = all[index.coerceIn(0, all.size - 1)]
}
