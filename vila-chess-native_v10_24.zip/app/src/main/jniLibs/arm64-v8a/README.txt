libstockfish.so duoc tai ve boi GitHub Actions (xem workflow)
