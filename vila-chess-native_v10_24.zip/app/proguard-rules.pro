# No special rules: the app does not use reflection.
