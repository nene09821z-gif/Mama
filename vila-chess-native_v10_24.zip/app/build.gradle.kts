plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose")
}

android {
  namespace = "com.vila.chess"
  compileSdk = 35

  defaultConfig {
    applicationId = "com.vila.chessnative"
    minSdk = 24
    targetSdk = 35
    versionCode = 1
    versionName = "0.1.0"
    // AppAuth: scheme redirect của luồng đăng nhập Google toàn trang (= package name)
    manifestPlaceholders["appAuthRedirectScheme"] = "com.vila.chessnative"
  }

  // Keystore cố định => SHA-1 không đổi giữa các lần build CI (cần cho Google/Facebook).
  // Chỉ áp dụng khi file app/vila.keystore tồn tại; thiếu file thì build debug như cũ.
  signingConfigs {
    getByName("debug") {
      val ks = file("vila.keystore")
      if (ks.exists()) {
        storeFile = ks
        storePassword = "vila123"
        keyAlias = "vila"
        keyPassword = "vila123"
      }
    }
  }

  buildTypes {
    release {
      isMinifyEnabled = false
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  kotlinOptions {
    jvmTarget = "17"
  }

  buildFeatures {
    compose = true
  }

  // Giải nén libstockfish.so ra đĩa để chạy được bằng ProcessBuilder.
  packaging {
    jniLibs {
      useLegacyPackaging = true
    }
  }

  testOptions {
    unitTests.isReturnDefaultValues = true
  }
}

dependencies {
  val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
  implementation(composeBom)
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.activity:activity-compose:1.9.3")
  implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
  implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-graphics")
  implementation("androidx.compose.foundation:foundation")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.material:material-icons-extended")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
  implementation("androidx.work:work-runtime-ktx:2.9.1")
  // Google Play Billing 7.x (+ bản ktx cho suspend API)
  implementation("com.android.billingclient:billing-ktx:7.1.1")

  // Đăng nhập: Google (Credential Manager) + Facebook
  implementation("androidx.credentials:credentials:1.3.0")
  implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
  implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
  implementation("com.facebook.android:facebook-login:17.0.2")
  implementation("net.openid:appauth:0.11.1")

  testImplementation("junit:junit:4.13.2")
  // android.jar trong unit test chỉ có stub org.json (trả về rỗng): cần bản thật để test ReviewJson.
  testImplementation("org.json:json:20240303")
}
