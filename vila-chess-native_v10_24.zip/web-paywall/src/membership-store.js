import { dailyLimit, MembershipTier } from '../shared/membership-spec.js';

const TIER_KEY = 'chessplus.tier';
const USAGE_KEY = 'chessplus.usage';
const listeners = new Set();

function safeGet(k) { try { return localStorage.getItem(k); } catch { return null; } }
function safeSet(k, v) { try { localStorage.setItem(k, v); } catch { /* private mode */ } }

/** localStorage chỉ là CACHE để UI đúng ngay lúc mở app; nguồn sự thật là RevenueCat (xem purchase-service.js). */
export function getTier() {
  const t = safeGet(TIER_KEY);
  return Object.values(MembershipTier).includes(t) ? t : MembershipTier.FREE;
}

export function setTier(tier) {
  if (tier === getTier()) return;
  safeSet(TIER_KEY, tier);
  listeners.forEach((fn) => fn(tier));
}

export function onTierChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

const today = () => new Date().toISOString().slice(0, 10);
function readUsage() {
  try {
    const u = JSON.parse(safeGet(USAGE_KEY) || '{}');
    return u.day === today() ? u : { day: today() };
  } catch { return { day: today() }; }
}

export const usedToday = (quota) => readUsage()[quota.id] || 0;

/** null = không giới hạn */
export function remaining(quota, tier = getTier()) {
  const limit = dailyLimit(quota, tier);
  return limit === null ? null : Math.max(0, limit - usedToday(quota));
}
export const canUse = (quota, tier = getTier()) => { const r = remaining(quota, tier); return r === null || r > 0; };

export function consume(quota) {
  const u = readUsage();
  u[quota.id] = (u[quota.id] || 0) + 1;
  safeSet(USAGE_KEY, JSON.stringify(u));
}
