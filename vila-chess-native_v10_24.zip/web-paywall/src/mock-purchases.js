// Giả lập RevenueCat để dev/test giao diện không cần store (bật bằng ?mock=1 hoặc khi chưa có API key ở chế độ dev).
const listeners = [];
let active = {};
const price = { gold: [59000, 590000], platinum: [99000, 990000], diamond: [179000, 1790000] };
const fmt = (n) => n.toLocaleString('vi-VN') + ' ₫';
const info = () => ({ entitlements: { active } });

const packages = Object.entries(price).flatMap(([tier, [m, y]]) => [
  { identifier: `${tier}_monthly`, product: { priceString: fmt(m), price: m, currencyCode: 'VND' } },
  { identifier: `${tier}_yearly`, product: { priceString: fmt(y), price: y, currencyCode: 'VND' } },
]);
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export default {
  async configure() {},
  async addCustomerInfoUpdateListener(fn) { listeners.push(fn); },
  async getCustomerInfo() { return { customerInfo: info() }; },
  async getOfferings() { await wait(150); return { current: { availablePackages: packages } }; },
  async purchasePackage({ aPackage }) {
    await wait(400);
    if (location.search.includes('cancel')) throw { userCancelled: true };
    const tier = aPackage.identifier.split('_')[0];
    active = { [tier]: { isActive: true } };
    listeners.forEach((fn) => fn(info()));
    return { customerInfo: info() };
  },
  async restorePurchases() { return { customerInfo: info() }; },
};
