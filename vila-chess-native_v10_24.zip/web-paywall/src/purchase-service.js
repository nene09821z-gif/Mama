// RevenueCat cho Capacitor (Android/iOS) và Web Billing.
//   npm i @revenuecat/purchases-capacitor && npx cap sync
import { MembershipTier, PAID_TIERS, PERIODS, tierRank } from '../shared/membership-spec.js';
import { setTier, getTier } from './membership-store.js';

// Public SDK key (an toàn để đặt trong app). Lấy ở RevenueCat → Project → API keys.
const KEYS = {
  android: import.meta.env?.VITE_RC_ANDROID_KEY || '',
  ios: import.meta.env?.VITE_RC_IOS_KEY || '',
  web: import.meta.env?.VITE_RC_WEB_KEY || '',
};

export const PurchaseError = Object.freeze({
  CANCELLED: 'cancelled',   // người dùng hủy — KHÔNG hiện lỗi đỏ
  NETWORK: 'network',
  PAYMENT: 'payment',       // thanh toán bị từ chối / lỗi store
  PENDING: 'pending',       // chờ xử lý (thanh toán trì hoãn)
  UNAVAILABLE: 'unavailable',
  UNKNOWN: 'unknown',
});

export class PurchaseFailure extends Error {
  constructor(code, cause) { super(code); this.code = code; this.cause = cause; }
}

let Purchases = null;   // module RevenueCat (hoặc mock)
let mock = false;

const platform = () => globalThis.Capacitor?.getPlatform?.() ?? 'web';

/** Gọi 1 lần lúc khởi động app. appUserId nên là id tài khoản của bạn (để khôi phục giữa các thiết bị). */
export async function initPurchases({ appUserId = null } = {}) {
  const apiKey = KEYS[platform()];
  const wantMock = new URLSearchParams(location.search).has('mock') || (!apiKey && import.meta.env?.DEV);
  if (wantMock) {
    mock = true;
    Purchases = (await import('./mock-purchases.js')).default;
  } else {
    if (!apiKey) throw new PurchaseFailure(PurchaseError.UNAVAILABLE);
    ({ Purchases } = await import('@revenuecat/purchases-capacitor'));
    await Purchases.configure({ apiKey, appUserID: appUserId });
  }
  // Mọi thay đổi (mua, hết hạn, hoàn tiền, khôi phục) đều đi qua listener này.
  await Purchases.addCustomerInfoUpdateListener((info) => applyCustomerInfo(info));
  await refreshEntitlements();
}

/** RevenueCat đã xác thực biên lai phía server; ta chỉ đọc entitlement đang active. */
export function tierFromCustomerInfo(info) {
  const active = info?.entitlements?.active ?? {};
  return PAID_TIERS.filter((t) => active[t]).sort((a, b) => tierRank(b) - tierRank(a))[0] ?? MembershipTier.FREE;
}

function applyCustomerInfo(info) {
  const tier = tierFromCustomerInfo(info);
  setTier(tier); // lưu localStorage + báo UI
  return tier;
}

/** Offline → giữ gói đã lưu, không hạ về FREE oan. */
export async function refreshEntitlements() {
  try {
    const { customerInfo } = await Purchases.getCustomerInfo();
    return applyCustomerInfo(customerInfo);
  } catch {
    return getTier();
  }
}

/** → [{ tier, monthly: Option|null, yearly: Option|null }] với giá lấy từ store (đúng tiền tệ). */
export async function getTierPlans() {
  try {
    const offerings = await Purchases.getOfferings();
    const pkgs = offerings.current?.availablePackages ?? [];
    if (!pkgs.length) throw new PurchaseFailure(PurchaseError.UNAVAILABLE);
    return PAID_TIERS.map((tier) => {
      const plan = { tier };
      for (const period of PERIODS) {
        const pkg = pkgs.find((p) => p.identifier === `${tier}_${period}`);
        plan[period] = pkg && {
          tier, period, pkg,
          priceString: pkg.product.priceString,
          price: pkg.product.price,
          currency: pkg.product.currencyCode,
        };
      }
      return plan;
    });
  } catch (e) {
    throw e instanceof PurchaseFailure ? e : classify(e);
  }
}

export async function purchase(option) {
  try {
    const { customerInfo } = await Purchases.purchasePackage({ aPackage: option.pkg });
    return applyCustomerInfo(customerInfo);
  } catch (e) {
    throw classify(e);
  }
}

export async function restore() {
  try {
    const { customerInfo } = await Purchases.restorePurchases();
    return applyCustomerInfo(customerInfo);
  } catch (e) {
    throw classify(e);
  }
}

function classify(e) {
  if (e instanceof PurchaseFailure) return e;
  if (e?.userCancelled || e?.code === '1' || e?.code === 'PURCHASE_CANCELLED_ERROR') return new PurchaseFailure(PurchaseError.CANCELLED, e);
  const code = String(e?.code ?? '');
  if (code === '35' || code === 'NETWORK_ERROR' || code === 'OFFLINE_CONNECTION_ERROR' || !navigator.onLine) return new PurchaseFailure(PurchaseError.NETWORK, e);
  if (code === 'PAYMENT_PENDING_ERROR' || code === '20') return new PurchaseFailure(PurchaseError.PENDING, e);
  if (code === 'PRODUCT_NOT_AVAILABLE_FOR_PURCHASE_ERROR' || code === 'CONFIGURATION_ERROR') return new PurchaseFailure(PurchaseError.UNAVAILABLE, e);
  if (code.includes('PURCHASE') || code.includes('PAYMENT') || code.includes('STORE')) return new PurchaseFailure(PurchaseError.PAYMENT, e);
  return new PurchaseFailure(PurchaseError.UNKNOWN, e);
}

export const ERROR_TEXT = {
  [PurchaseError.NETWORK]: 'Không có kết nối mạng. Kiểm tra Internet rồi thử lại.',
  [PurchaseError.PAYMENT]: 'Thanh toán thất bại. Bạn chưa bị trừ tiền, hãy thử lại.',
  [PurchaseError.PENDING]: 'Giao dịch đang chờ xử lý. Gói sẽ được kích hoạt khi thanh toán hoàn tất.',
  [PurchaseError.UNAVAILABLE]: 'Các gói chưa sẵn sàng. Vui lòng thử lại sau.',
  [PurchaseError.UNKNOWN]: 'Đã xảy ra lỗi. Vui lòng thử lại.',
};

export const isMock = () => mock;
