import { hasAccess, requiredTier, tierName, FEATURE_LABEL } from '../shared/membership-spec.js';
import { getTier, onTierChange } from './membership-store.js';

/**
 * Hiện `el` nếu đủ quyền; nếu không thì thay bằng thanh "Nâng cấp". Tự cập nhật khi gói đổi.
 *   gateFeature(document.querySelector('#insights'), Feature.INSIGHTS, () => openPaywall());
 */
export function gateFeature(el, feature, onUpgrade) {
  const bar = document.createElement('div');
  bar.className = 'cp-upgrade-bar';
  bar.innerHTML = `<span></span><button class="cp-btn" type="button">Nâng cấp</button>`;
  bar.querySelector('span').textContent = `${FEATURE_LABEL[feature]} · cần gói ${tierName(requiredTier(feature))}`;
  bar.querySelector('button').addEventListener('click', onUpgrade);
  el.after(bar);

  const render = (tier = getTier()) => {
    const ok = hasAccess(feature, tier);
    el.hidden = !ok;
    bar.hidden = ok;
  };
  render();
  return onTierChange(render);
}

/** Dùng cho hạn mức: if (!guardQuota(Quota.GAME_REVIEW, openPaywall)) return; ...làm việc...; consume(Quota.GAME_REVIEW) */
import { canUse } from './membership-store.js';
export function guardQuota(quota, onUpgrade) {
  if (canUse(quota)) return true;
  onUpgrade();
  return false;
}
