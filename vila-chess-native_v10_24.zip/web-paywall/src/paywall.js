import { TIER_HIGHLIGHTS, tierName } from '../shared/membership-spec.js';
import { getTier, onTierChange } from './membership-store.js';
import { getTierPlans, purchase, restore, PurchaseError, ERROR_TEXT } from './purchase-service.js';

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

function perMonthHint(plan) {
  const y = plan.yearly, m = plan.monthly;
  if (!y) return '';
  let txt = '';
  try {
    txt = '≈ ' + new Intl.NumberFormat(undefined, { style: 'currency', currency: y.currency }).format(y.price / 12) + '/tháng';
  } catch { /* tiền tệ lạ */ }
  if (m && m.currency === y.currency && m.price > 0) {
    const pct = Math.round(100 - (y.price * 100) / (m.price * 12));
    if (pct > 0) txt += ` · tiết kiệm ${pct}%`;
  }
  return txt;
}

/** Vẽ màn hình Paywall vào `root`. Giá hiển thị lấy động từ RevenueCat (store trả về đúng tiền tệ người dùng). */
export function mountPaywall(root, { onClose } = {}) {
  const state = { plans: [], period: 'yearly', loading: true, busy: false, msg: null, tier: getTier() };

  async function load() {
    state.loading = true; state.msg = null; render();
    try { state.plans = await getTierPlans(); }
    catch (e) { state.msg = { err: true, text: ERROR_TEXT[e.code] || ERROR_TEXT.unknown }; }
    state.loading = false; render();
  }

  async function run(fn) {
    if (state.busy) return;
    state.busy = true; state.msg = null; render();
    try {
      const tier = await fn();
      state.msg = tier !== 'free' ? { err: false, text: `Đã kích hoạt gói ${tierName(tier)} 🎉` }
                                  : { err: false, text: 'Không tìm thấy gói nào để khôi phục' };
    } catch (e) {
      // Hủy giao dịch là hành động bình thường: chỉ báo nhẹ, không phải lỗi.
      state.msg = e.code === PurchaseError.CANCELLED ? { err: false, text: 'Bạn đã hủy giao dịch' }
                : e.code === PurchaseError.PENDING ? { err: false, text: ERROR_TEXT.pending }
                : { err: true, text: ERROR_TEXT[e.code] || ERROR_TEXT.unknown };
    }
    state.busy = false; render();
  }

  function render() {
    const cards = state.plans.map((plan) => {
      const opt = plan[state.period];
      const current = state.tier === plan.tier;
      return `
      <article class="cp-card cp-${plan.tier}">
        <header><h3>${esc(tierName(plan.tier))}</h3>${current ? '<span class="cp-badge">Gói hiện tại</span>' : ''}</header>
        ${opt ? `<p class="cp-price">${esc(opt.priceString)}<small> / ${state.period === 'monthly' ? 'tháng' : 'năm'}</small></p>
                 <p class="cp-hint">${state.period === 'yearly' ? esc(perMonthHint(plan)) : '&nbsp;'}</p>`
              : '<p class="cp-hint">Chưa có gói này</p>'}
        <ul>${TIER_HIGHLIGHTS[plan.tier].map((l) => `<li>${esc(l)}</li>`).join('')}</ul>
        <button class="cp-btn" data-buy="${plan.tier}" ${!opt || state.busy || current ? 'disabled' : ''}>${current ? 'Đang sử dụng' : 'Chọn gói'}</button>
      </article>`;
    }).join('');

    root.innerHTML = `
    <section class="cp-paywall">
      <div class="cp-top">${onClose ? '<button class="cp-back" data-close aria-label="Quay lại">←</button>' : ''}<h2>Nâng cấp ChessPlus</h2></div>
      <div class="cp-toggle" role="tablist">
        <button role="tab" class="${state.period === 'monthly' ? 'on' : ''}" data-period="monthly">Theo tháng</button>
        <button role="tab" class="${state.period === 'yearly' ? 'on' : ''}" data-period="yearly">Theo năm</button>
      </div>
      ${state.msg ? `<div class="cp-msg ${state.msg.err ? 'err' : 'ok'}" role="status">${esc(state.msg.text)}</div>` : ''}
      ${state.loading ? '<div class="cp-spin" aria-label="Đang tải"></div>'
        : state.plans.length ? cards : '<button class="cp-btn" data-retry>Thử lại</button>'}
      <button class="cp-link" data-restore ${state.busy ? 'disabled' : ''}>Khôi phục giao dịch</button>
      <p class="cp-fine">Gói tự động gia hạn cho đến khi bạn hủy. Quản lý hoặc hủy trong cài đặt gói đăng ký của Google Play / App Store.</p>
    </section>`;
  }

  root.addEventListener('click', (e) => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.period) { state.period = t.dataset.period; render(); }
    else if (t.dataset.buy) { const opt = state.plans.find((p) => p.tier === t.dataset.buy)?.[state.period]; if (opt) run(() => purchase(opt)); }
    else if ('restore' in t.dataset) run(restore);
    else if ('retry' in t.dataset) load();
    else if ('close' in t.dataset) onClose?.();
  });

  const off = onTierChange((tier) => { state.tier = tier; render(); });
  load();
  return () => { off(); root.innerHTML = ''; };
}
