// Server xác thực biên lai Google Play (Node 18+, express, googleapis).  npm i express googleapis
// Triển khai trên Cloud Run / Firebase Functions / VPS bất kỳ. KHÔNG đặt service-account key trong app.
import express from 'express';
import { google } from 'googleapis';

const PACKAGE = process.env.PLAY_PACKAGE_NAME;            // vd com.vila.chessnative
const PRODUCTS = new Set(['chessplus_gold', 'chessplus_platinum', 'chessplus_diamond']);
const auth = new google.auth.GoogleAuth({
  scopes: ['https://www.googleapis.com/auth/androidpublisher'], // dùng service account đã cấp quyền trong Play Console
});
const play = google.androidpublisher({ version: 'v3', auth });

const app = express();
app.use(express.json());

app.post('/verify', async (req, res) => {
  const { packageName, productId, purchaseToken } = req.body ?? {};
  if (packageName !== PACKAGE || !PRODUCTS.has(productId) || typeof purchaseToken !== 'string') {
    return res.status(400).json({ valid: false });
  }
  try {
    const { data } = await play.purchases.subscriptionsv2.get({ packageName, token: purchaseToken });
    const line = (data.lineItems ?? []).find((l) => l.productId === productId);
    const active = ['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD'].includes(data.subscriptionState);
    if (!line || !active) return res.status(403).json({ valid: false });
    // TODO: lưu (userId, purchaseToken, productId, expiry) vào DB; chống 1 token dùng cho nhiều tài khoản.
    // Acknowledge ở server (khuyến nghị) hoặc để app làm — cả hai đều được.
    return res.json({ valid: true, productId, expiry: line.expiryTime });
  } catch (e) {
    return res.status(e.code === 404 || e.code === 400 ? 403 : 502).json({ valid: false });
  }
});

// RevenueCat webhook (nếu dùng RevenueCat): xác thực header Authorization bằng secret bạn đặt trong dashboard.
app.post('/revenuecat-webhook', (req, res) => {
  if (req.get('Authorization') !== `Bearer ${process.env.RC_WEBHOOK_SECRET}`) return res.sendStatus(401);
  // req.body.event.type: INITIAL_PURCHASE | RENEWAL | CANCELLATION | EXPIRATION | BILLING_ISSUE ...
  // Cập nhật entitlement của app_user_id trong DB của bạn tại đây.
  res.sendStatus(200);
});

app.listen(process.env.PORT || 8080);
