#!/usr/bin/env python3
"""
Tạo puzzles.db (SQLite) cho bản đồ câu đố ViLa Chess.

  1. Tải kho câu đố của Lichess (lichess_db_puzzle.csv.zst) – hoặc dùng file có sẵn qua --input.
  2. Sắp xếp theo Rating TĂNG DẦN (dễ → khó).
  3. Giữ đúng 50.000 câu đầu tiên.
  4. Ghi vào SQLite với cột `id` chạy 1 … 50.000 (id 1 = dễ nhất)
     ⇒ id chính là số Level hiển thị trên nút gỗ của PuzzleMapScreen.

Dùng:
    python3 scripts/generate_puzzles.py                       # tải về, ghi app/src/main/assets/puzzles.db
    python3 scripts/generate_puzzles.py --input puzzles.csv.zst --out /tmp/puzzles.db

Giải nén .zst: ưu tiên module `zstandard` (pip install zstandard), nếu không có thì dùng lệnh `zstd`
(có sẵn trên runner ubuntu-latest của GitHub Actions).
"""
from __future__ import annotations

import argparse
import csv
import heapq
import io
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.request
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

LICHESS_URL = "https://database.lichess.org/lichess_db_puzzle.csv.zst"
DEFAULT_COUNT = 50_000
DEFAULT_OUT = Path(__file__).resolve().parent.parent / "app" / "src" / "main" / "assets" / "puzzles.db"

REQUIRED = ("PuzzleId", "FEN", "Moves", "Rating")

SCHEMA = """
CREATE TABLE puzzles (
    id               INTEGER PRIMARY KEY,   -- 1 … N, 1 = dễ nhất = số Level trên nút gỗ
    puzzle_id        TEXT    NOT NULL UNIQUE,
    fen              TEXT    NOT NULL,
    moves            TEXT    NOT NULL,
    rating           INTEGER NOT NULL,
    rating_deviation INTEGER NOT NULL DEFAULT 0,
    popularity       INTEGER NOT NULL DEFAULT 0,
    nb_plays         INTEGER NOT NULL DEFAULT 0,
    themes           TEXT    NOT NULL DEFAULT '',
    game_url         TEXT    NOT NULL DEFAULT '',
    opening_tags     TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX idx_puzzles_rating ON puzzles(rating);
CREATE TABLE android_metadata (locale TEXT);
INSERT INTO android_metadata VALUES ('en_US');
"""


# ───────────────────────────────────────────────────────────── Tải & đọc dữ liệu

def download(url: str, dest: Path) -> None:
    print(f"⬇️  Tải {url}", flush=True)
    req = urllib.request.Request(url, headers={"User-Agent": "vila-chess-puzzle-builder"})
    with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "wb") as f:
        shutil.copyfileobj(resp, f, length=1 << 20)
    print(f"✅ Đã tải {dest.stat().st_size / 1e6:.1f} MB", flush=True)


@contextmanager
def open_text(path: Path) -> Iterator[io.TextIOBase]:
    """Mở file CSV thường hoặc .zst thành luồng text (đọc streaming, không nạp cả file vào RAM)."""
    if path.suffix != ".zst":
        with open(path, "r", encoding="utf-8", newline="") as f:
            yield f
        return

    try:
        import zstandard  # type: ignore
    except ImportError:
        zstandard = None

    if zstandard is not None:
        with open(path, "rb") as raw:
            reader = zstandard.ZstdDecompressor().stream_reader(raw)
            yield io.TextIOWrapper(reader, encoding="utf-8", newline="")
        return

    if shutil.which("zstd") is None:
        sys.exit("❌ Cần `pip install zstandard` hoặc cài lệnh `zstd` để giải nén file .zst")
    proc = subprocess.Popen(["zstd", "-dc", str(path)], stdout=subprocess.PIPE)
    try:
        assert proc.stdout is not None
        yield io.TextIOWrapper(proc.stdout, encoding="utf-8", newline="")
    finally:
        if proc.stdout:
            proc.stdout.close()
        if proc.wait() != 0:
            sys.exit("❌ zstd giải nén thất bại")


def iter_rows(f: io.TextIOBase) -> Iterator[dict]:
    reader = csv.DictReader(f)
    missing = [c for c in REQUIRED if c not in (reader.fieldnames or [])]
    if missing:
        sys.exit(f"❌ File CSV thiếu cột: {', '.join(missing)} (có: {reader.fieldnames})")
    yield from reader


def to_int(value: str | None, default: int = 0) -> int:
    try:
        return int(value) if value not in (None, "") else default
    except ValueError:
        return default


# ───────────────────────────────────────────────────────────── Chọn câu đố

def sort_key(row: dict) -> tuple:
    """
    Rating tăng dần. Cùng Rating: câu được ưa chuộng hơn (Popularity cao) đứng trước,
    cuối cùng theo PuzzleId ⇒ kết quả ổn định giữa các lần chạy.
    """
    return (to_int(row["Rating"]), -to_int(row.get("Popularity")), row["PuzzleId"])


def pick_easiest(rows: Iterator[dict], count: int) -> list[dict]:
    """
    Tương đương `sorted(all_rows, key=sort_key)[:count]` nhưng chỉ giữ `count` dòng trong RAM
    (kho Lichess có vài triệu dòng).
    """
    total = 0

    def counted() -> Iterator[dict]:
        nonlocal total
        for r in rows:
            if not r["PuzzleId"] or not r["FEN"] or not r["Moves"] or not r["Rating"]:
                continue   # bỏ dòng hỏng
            total += 1
            yield r

    picked = heapq.nsmallest(count, counted(), key=sort_key)   # đã sắp tăng dần
    print(f"📊 Đọc {total:,} câu đố hợp lệ → giữ {len(picked):,} câu dễ nhất", flush=True)
    return picked


# ───────────────────────────────────────────────────────────── Ghi SQLite

def write_db(picked: list[dict], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    con = sqlite3.connect(out)
    try:
        con.executescript(SCHEMA)
        con.executemany(
            "INSERT INTO puzzles (id, puzzle_id, fen, moves, rating, rating_deviation, popularity, nb_plays,"
            " themes, game_url, opening_tags) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (
                (
                    n,                                   # id = 1 … N, thứ tự = Rating tăng dần
                    r["PuzzleId"], r["FEN"], r["Moves"], to_int(r["Rating"]),
                    to_int(r.get("RatingDeviation")), to_int(r.get("Popularity")), to_int(r.get("NbPlays")),
                    r.get("Themes") or "", r.get("GameUrl") or "", r.get("OpeningTags") or "",
                )
                for n, r in enumerate(picked, start=1)
            ),
        )
        con.commit()
        verify(con, len(picked))
        con.execute("VACUUM")
    finally:
        con.close()
    print(f"💾 {out} — {out.stat().st_size / 1e6:.1f} MB", flush=True)


def verify(con: sqlite3.Connection, expected: int) -> None:
    n, lo, hi = con.execute("SELECT COUNT(*), MIN(id), MAX(id) FROM puzzles").fetchone()
    if (n, lo, hi) != (expected, 1, expected):
        sys.exit(f"❌ id không liên tục: count={n} min={lo} max={hi}, cần 1…{expected}")
    bad = con.execute(
        "SELECT COUNT(*) FROM puzzles a JOIN puzzles b ON b.id = a.id + 1 WHERE b.rating < a.rating"
    ).fetchone()[0]
    if bad:
        sys.exit(f"❌ Có {bad} chỗ Rating giảm khi id tăng")
    r1, rn = con.execute(
        "SELECT (SELECT rating FROM puzzles WHERE id = 1), (SELECT rating FROM puzzles WHERE id = ?)", (expected,)
    ).fetchone()
    print(f"✅ id 1…{expected} liên tục · Rating tăng dần: level 1 = {r1}, level {expected} = {rn}", flush=True)


# ───────────────────────────────────────────────────────────── main

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", type=Path, help="file .csv / .csv.zst có sẵn (bỏ qua bước tải)")
    ap.add_argument("--url", default=LICHESS_URL)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--count", type=int, default=DEFAULT_COUNT)
    args = ap.parse_args()

    if args.input:
        src = args.input
        tmp = None
    else:
        tmp = tempfile.TemporaryDirectory()
        src = Path(tmp.name) / "lichess_db_puzzle.csv.zst"
        download(args.url, src)

    try:
        with open_text(src) as f:
            picked = pick_easiest(iter_rows(f), args.count)
    finally:
        if tmp:
            tmp.cleanup()

    if len(picked) < args.count:
        sys.exit(f"❌ Chỉ có {len(picked):,} câu đố hợp lệ, không đủ {args.count:,}")
    write_db(picked, args.out)


if __name__ == "__main__":
    main()
