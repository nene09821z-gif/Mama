# ViLa Chess Native

App Android native (Kotlin + Jetpack Compose) theo phong cách chess.com, dựa trên dự án web ViLa Chess.

## Giai đoạn 1 (bản này)
- Luật cờ đầy đủ: nhập thành, bắt tốt qua đường, phong cấp, chiếu hết, hòa pat, thiếu lực lượng, luật 50 nước, lặp thế 3 lần. Bộ sinh nước đi đã được kiểm bằng perft (số nước đi chuẩn quốc tế).
- Bàn cờ vẽ bằng Canvas: kéo thả (quân nổi lên khỏi ngón tay), chạm-chọn-chạm-đi, chấm nước đi hợp lệ, vòng tròn khi bắt quân, tô ô nước đi cuối, vầng đỏ khi bị chiếu, tọa độ trong ô, quân trượt mượt (có cả xe khi nhập thành).
- Premove kiểu chess.com: khi chưa tới lượt, kéo quân để đặt nước đi trước (ô đỏ), tự đi nếu còn hợp lệ.
- Chơi với máy 8 cấp (engine alpha-beta tự viết, chạy nền), đồng hồ (3, 5, 10 phút, 3|2, 10|5), đi lại, lật bàn, đề nghị hòa, đầu hàng.
- Âm thanh (SoundPool) và rung nhẹ khi đi quân.
- 44 bộ quân cờ (bộ mặc định + 43 bộ từ piece.zip: cburnett, merida, staunty, xkcd, pixel, ...), chọn ở màn hình chính, nhớ lựa chọn. Quân được render sẵn từ SVG sang PNG 256px trong `app/src/main/assets/pieces/<tên bộ>/`.
- Danh sách nước đi dạng SAN, quân đã bắt và chênh lệch vật chất.

## Build
Đẩy repo lên GitHub, workflow `Build APK` sẽ chạy unit test rồi build `app-debug.apk` (artifact `vila-chess-native-debug-apk`).

## Kế hoạch
2. Puzzle từ gói puzzle của bản web, lưu ván bằng Room.
3. Stockfish native (NDK) để phân tích/review.
4. Online, chat, tài khoản (nối backend Cloudflare).
