# v17r — Bộ lọc tên bậy (tiếng Việt + tiếng Anh)

## Trước đó
- Chỉ kiểm độ dài 2–20 ký tự và ký tự điều khiển (NameRules.validate); Supabase chỉ giới hạn độ dài 1–30. Đặt tên gì cũng được.

## Thêm
- profile/NameFilter.kt (thuần Kotlin, test được trên JVM). Cách lọc:
  - Chuẩn hóa: bỏ ký tự vô hình, chữ full-width, bỏ dấu tiếng Việt (đ->d), chữ Kirin giống Latin, kiểu viết lách (0->o 1->i 3->e 4->a 5->s 7->t @ $ !).
  - TOKENS khớp nguyên cả từ (nên "Hancock", "Dickson", "Takeshita", "Cún Tí" không bị chặn); PHRASES là cụm từ ("dit me", "con cho");
    STRONG tìm trong chuỗi dồn liền (bắt "f u c k", "xXfuckXx", "fuuuck"); chữ lẻ cách nhau ("đ.m", "s h i t") được ghép lại.
  - ORIGINAL_BAD: từ chỉ xấu khi ĐÚNG dấu (đĩ, đéo, đụ, điếm). ALLOW: bưởi, buổi, lớn, ngư, các (bỏ dấu sẽ trùng từ cấm nhưng là từ thường).
- supabase/name_filter.sql: cùng thuật toán + trigger trên public.users. Tên bậy bị thay bằng "Người chơi" (không làm lỗi lệnh ghi,
  nên đồng bộ Elo/ván cờ vẫn chạy). Chạy trong Supabase > SQL Editor; cuối file có câu tùy chọn dọn tên bậy đã có và vài câu tự kiểm.
- tools/namefilter/: lists.py (danh sách từ cấm, NGUỒN DUY NHẤT), gen.py (sinh NameFilter.kt + NameFilterTest.kt + name_filter.sql),
  ref.py + test_ref.py (bản Python để thử danh sách: 126 tên thật không bị chặn nhầm, 77 kiểu viết bậy/né lọc đều bị bắt).
  Sửa danh sách: sửa lists.py, chạy `python3 gen.py` trong thư mục đó, rồi chép 3 file sinh ra vào đúng chỗ
  (NameFilter.kt -> app/src/main/java/com/vila/chess/profile/, NameFilterTest.kt -> app/src/test/java/com/vila/chess/, name_filter.sql -> supabase/).
- app/src/test/.../NameFilterTest.kt: test tên thật không bị chặn / tên bậy bị chặn / mẹo ký tự vô hình / chữ có dấu / NameRules.

## Đổi
- profile/ProfileModels.kt: NameRules.validate thêm kiểm NameFilter => form Đổi tên (AccountScreen) và form Hồ sơ (MyProfileScreen)
  đều báo "Tên chứa từ không phù hợp, hãy chọn tên khác" (cả hai đã đi qua UserSessionManager.updateProfile).
- profile/UserSessionManager.kt: displayName thay tên bậy bằng "Người chơi". Bắt cả tên đặt từ bản cũ và tên lấy từ Google/email,
  nên tên bậy không hiện ra và không đẩy lên cloud.

## Giới hạn (nói thẳng)
- Không bộ lọc nào chặn 100%. Lọc cố ý thiên về không chặn nhầm tên thật; nên "Buoi Sang" (Buổi Sáng không dấu) bị chặn vì trùng từ cấm không dấu.
- Server dễ tính hơn app một chút (không ghép chữ cái lẻ, chỉ tách từ theo dấu ASCII) nhưng không bao giờ khắt khe hơn.
- Chỉ lọc TÊN hiển thị. Tin nhắn chat chưa lọc. Chưa có nút báo cáo tên.
- Chưa build/chạy trên máy (không có Android SDK, kotlinc, PostgreSQL ở đây): Kotlin/SQL chưa chạy thật. Thuật toán đã thử bằng bản Python
  tương đương; hãy chạy NameFilterTest và 7 câu tự kiểm cuối name_filter.sql.
