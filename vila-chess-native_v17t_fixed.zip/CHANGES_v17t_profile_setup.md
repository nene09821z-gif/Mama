# v17t — Màn "Hoàn thiện hồ sơ" sau đăng nhập (nhập tên + thêm ảnh, kiểu chess.com)

## Trước đó
- Đăng nhập xong vào thẳng chọn trình độ → màn chính. Tên lấy từ Google/email, ảnh đại diện chỉ đổi được trong Hồ sơ.

## Thêm
- ui/ProfileSetupScreen.kt: màn mới sau đăng nhập.
  - Avatar lớn 136dp: chạm để chọn ảnh từ thư viện (dùng lại rememberAvatarPicker + màn cắt ảnh có sẵn); hoặc chọn 1 trong 6 hình dựng sẵn.
  - Ô "Tên hiển thị": điền sẵn tên tài khoản, tối đa 20 ký tự, đếm ký tự, báo lỗi ngay bằng NameRules (gồm bộ lọc tên bậy v17r). Bàn phím nút Xong cũng lưu.
  - "Tiếp tục" lưu qua UserSessionManager.updateProfile (tự đồng bộ cloud, ảnh tự tải lên); "Bỏ qua" giữ tên tài khoản.
  - Mượt: các khối hiện lần lượt (mờ + trượt lên), avatar thở nhẹ và nảy khi đổi ảnh, nút co khi chạm, cả màn mờ dần rồi mới sang màn kế.
  - Ảnh tạm chưa lưu tự bị xoá khi đổi ảnh khác hoặc thoát màn.
- profile/UserSessionManager.kt: `profileSetupDone` (state) + `completeProfileSetup(ctx)`. Coi là xong nếu có cờ "setupDone" HOẶC đã có tên/ảnh tự đặt
  (người dùng cũ không bị hỏi lại; người dùng cũ chưa đặt tên sẽ thấy màn này một lần). Đăng xuất xoá cờ → tài khoản sau lại thấy màn.

## Đổi
- MainActivity.kt: AppRoot chèn ProfileSetupScreen giữa cổng đăng nhập và màn chọn trình độ; onCreate gọi UserSessionManager.init sớm để không nháy màn.
- Thứ tự mới: Đăng nhập → Hoàn thiện hồ sơ → Chọn trình độ → Màn chính.

## Lưu ý
- Chưa build/chạy trên máy (không có Android SDK / kotlinc ở đây): chỉ rà cú pháp bằng mắt và đếm ngoặc. Hãy build và thử bằng một tài khoản mới (hoặc đăng xuất rồi đăng nhập lại).
- Chọn quốc gia chưa có trong màn này (vẫn lấy theo ngôn ngữ máy, đổi được trong Hồ sơ).
