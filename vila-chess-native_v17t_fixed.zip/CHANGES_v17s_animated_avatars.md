# v17s — Avatar động + thẻ VS trong ván với máy

## Trước đó
- Màn ván với máy: bot chơi nhanh theo cấp ("Máy · Cấp 6") chỉ có icon robot xanh; bạn chỉ có ảnh quân vua. Avatar đứng yên.

## Thêm
- ui/AnimatedAvatar.kt: `AnimatedAvatarFrame` bọc bất kỳ avatar nào, chuyển động ở tầng graphicsLayer (không làm recomposition):
  - Thở (phóng nhẹ + nhấp nhô ~1dp, chu kỳ hai bên hơi khác nhau).
  - Đến lượt: nghiêng đầu nhẹ + vòng sáng xanh nhấp nháy.
  - Phản ứng: ăn quân = nhảy lên; bị chiếu = rung; hết ván = bên thắng nhảy, bên thua rung.
- ui/VsMatchCard.kt: `BotVsIntro` — thẻ VS (bot trên, hồ sơ của bạn dưới: ảnh, tên, cờ, Elo) khi vào ván mới với máy / giải đấu.
  Không chặn thao tác; tự tắt khi bạn đi nước đầu hoặc sau ~2,8 giây. Ván tàn cuộc (ENDGAME) không hiện.
- game/GameViewModel.kt: `gameSerial` (tăng mỗi ván mới, làm khóa cho thẻ VS) và `ratingModeNow` (thể loại Elo của ván).

## Đổi
- ui/GameCommon.kt PlayerBar: avatar bọc trong AnimatedAvatarFrame; thêm tham số `profileName` / `profileAvatarKey` để vẽ avatar hồ sơ người chơi (tròn) thay cho quân vua.
- ui/BotGameScreen.kt: bot chơi nhanh theo cấp dùng gương mặt bot có Elo gần cấp đó nhất (BotRepository.nearest) thay cho icon robot;
  người chơi dùng avatar + tên hồ sơ; gắn BotVsIntro lên bàn cờ.

## Chưa làm / giới hạn
- Chưa có chớp mắt / đổi biểu cảm miệng (cần tách mắt, miệng thành lớp riêng trong tools/botfaces.py).
- Các màn khác (PvP, online) chưa dùng avatar hồ sơ trong PlayerBar; online đã có thẻ VS riêng.
- Chưa build/chạy trên máy (không có Android SDK / kotlinc ở đây): chỉ kiểm cú pháp bằng mắt và đếm ngoặc. Hãy build và thử một ván.
