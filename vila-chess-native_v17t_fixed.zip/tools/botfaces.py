#!/usr/bin/env python3
"""Vẽ 15 khuôn mặt bot (lưới 48x48) -> SVG xem thử + VectorDrawable XML cho app Android.
Mỗi hình chỉ dùng: path tô màu (có độ trong suốt), nét vẽ bo tròn. Không dùng gradient/clip/xoay nên chạy ổn từ API 24."""
import sys
from pathlib import Path


def _rgb(h):
    h = h.lstrip('#')
    return [int(h[i:i + 2], 16) for i in (0, 2, 4)]


def mix(a, b, t):
    A, B = _rgb(a), _rgb(b)
    return '#%02X%02X%02X' % tuple(round(A[i] + (B[i] - A[i]) * t) for i in range(3))


def dk(c, t=0.25): return mix(c, '#000000', t)
def lt(c, t=0.25): return mix(c, '#FFFFFF', t)


def f(x):
    s = ('%.2f' % x).rstrip('0').rstrip('.')
    return s if s not in ('-0', '') else '0'


class Scene:
    def __init__(self):
        self.items = []

    def path(self, d, fill=None, op=1.0, stroke=None, sw=1.0, so=1.0):
        self.items.append(dict(d=d, fill=fill, op=op, stroke=stroke, sw=sw, so=so))

    def ell(self, cx, cy, rx, ry, fill, op=1.0):
        d = f"M{f(cx - rx)},{f(cy)} a{f(rx)},{f(ry)} 0 1,0 {f(2 * rx)},0 a{f(rx)},{f(ry)} 0 1,0 {f(-2 * rx)},0 Z"
        self.path(d, fill, op)

    def circ(self, cx, cy, r, fill, op=1.0):
        self.ell(cx, cy, r, r, fill, op)

    def rect(self, x, y, w, h, fill, op=1.0):
        self.path(f"M{f(x)},{f(y)} h{f(w)} v{f(h)} h{f(-w)} Z", fill, op)

    def line(self, d, color, sw=1.2, op=1.0):
        self.path(d, None, 1.0, color, sw, op)

    def svg(self, size=96, idp='x'):
        out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="{size}" height="{size}">']
        for it in self.items:
            if it['stroke']:
                out.append(f'<path d="{it["d"]}" fill="none" stroke="{it["stroke"]}" stroke-width="{f(it["sw"])}" stroke-linecap="round" stroke-linejoin="round" stroke-opacity="{f(it["so"])}"/>')
            else:
                o = '' if it['op'] >= 0.999 else f' fill-opacity="{f(it["op"])}"'
                out.append(f'<path d="{it["d"]}" fill="{it["fill"]}"{o}/>')
        out.append('</svg>')
        return ''.join(out)

    def android(self):
        out = ['<?xml version="1.0" encoding="utf-8"?>',
               '<vector xmlns:android="http://schemas.android.com/apk/res/android"',
               '    android:width="96dp" android:height="96dp" android:viewportWidth="48" android:viewportHeight="48">']
        for it in self.items:
            if it['stroke']:
                a = '' if it['so'] >= 0.999 else f' android:strokeAlpha="{f(it["so"])}"'
                out.append(f'    <path android:strokeColor="{it["stroke"]}" android:strokeWidth="{f(it["sw"])}" android:strokeLineCap="round" android:strokeLineJoin="round"{a} android:pathData="{it["d"]}"/>')
            else:
                a = '' if it['op'] >= 0.999 else f' android:fillAlpha="{f(it["op"])}"'
                out.append(f'    <path android:fillColor="{it["fill"]}"{a} android:pathData="{it["d"]}"/>')
        out.append('</vector>')
        return '\n'.join(out) + '\n'


# ───────────────────────────────────────── bộ phận dùng chung
INK = '#2A1B17'


def bg(s, c, glow=None):
    s.rect(0, 0, 48, 48, c)
    s.rect(0, 33, 48, 15, dk(c, 0.18), 0.5)
    s.circ(13, 9, 27, glow or '#FFFFFF', 0.15)
    s.circ(41, 45, 14, dk(c, 0.3), 0.25)


def body(s, cloth, skin, shade, neck_w=4.2):
    x0, x1 = 24 - neck_w, 24 + neck_w
    s.path(f"M{f(x0)},28 L{f(x1)},28 L{f(x1 + 1)},38 Q24,42 {f(x0 - 1)},38 Z", shade)
    s.path(f"M{f(x0)},28 L{f(x1)},28 L{f(x1)},33.5 Q24,37 {f(x0)},33.5 Z", skin, 0.0)
    s.path("M1,48 C1,40.5 8,36.8 18.6,35.6 Q24,41.2 29.4,35.6 C40,36.8 47,40.5 47,48 Z", cloth)
    s.path("M1,48 C1,40.5 8,36.8 18.6,35.6 L16,48 Z", dk(cloth, 0.2), 0.45)


def head(s, skin, shade, rx=11.6, ry=13.0, cy=22.2, ears=True):
    if ears:
        for sx in (-1, 1):
            s.ell(24 + sx * (rx + 0.1), cy + 1.9, 2.3, 3.0, shade)
            s.ell(24 + sx * (rx + 0.1), cy + 1.9, 1.3, 1.9, dk(skin, 0.18), 0.6)
    s.ell(24, cy, rx, ry, shade)
    s.ell(23.4, cy - 0.7, rx - 0.7, ry - 0.7, skin)


def blush(s, c='#FF7C7C', op=0.28, y=27.0, dx=7.0, rx=2.6, ry=1.6):
    s.ell(24 - dx, y, rx, ry, c, op)
    s.ell(24 + dx, y, rx, ry, c, op)


def nose(s, skin, y=24.6, sw=0.9):
    s.line(f"M24.3,{f(y)} Q25.9,{f(y + 2.5)} 23.4,{f(y + 3)}", dk(skin, 0.38), sw, 0.7)


def eyes_round(s, iris, y=22.6, dx=5.9, sz=1.0, lash=False, lashc=INK):
    for sx in (-1, 1):
        cx = 24 + sx * dx
        s.ell(cx, y, 2.8 * sz, 3.2 * sz, '#FFFFFF')
        s.circ(cx, y + 0.3 * sz, 2.15 * sz, iris)
        s.circ(cx, y + 0.35 * sz, 1.2 * sz, '#17110F')
        s.circ(cx - 0.8 * sz, y - 0.8 * sz, 0.8 * sz, '#FFFFFF')
        s.circ(cx + 0.8 * sz, y + 1.0 * sz, 0.4 * sz, '#FFFFFF', 0.9)
        s.line(f"M{f(cx - 2.9 * sz)},{f(y - 0.6 * sz)} Q{f(cx)},{f(y - 4.6 * sz)} {f(cx + 2.9 * sz)},{f(y - 0.6 * sz)}", lashc, 0.9)
        if lash:
            o = 1 if sx > 0 else -1
            s.line(f"M{f(cx + o * 2.7 * sz)},{f(y - 1.2 * sz)} l{f(o * 1.3)},-0.9", lashc, 0.8)


def eyes_dot(s, y=22.8, dx=5.9, rx=1.55, ry=2.1, c='#1E1512'):
    for sx in (-1, 1):
        cx = 24 + sx * dx
        s.ell(cx, y, rx, ry, c)
        s.circ(cx - 0.5, y - 0.8, 0.6, '#FFFFFF')


def eyes_calm(s, skin, y=22.6, dx=5.9, iris='#3B2A22'):
    for sx in (-1, 1):
        cx = 24 + sx * dx
        s.ell(cx, y, 2.6, 2.6, '#FFFFFF')
        s.circ(cx, y + 0.3, 1.9, iris)
        s.circ(cx, y + 0.35, 1.0, '#120D0B')
        s.circ(cx - 0.6, y - 0.4, 0.55, '#FFFFFF')
        # mi mắt rũ che nửa trên
        s.path(f"M{f(cx - 3.1)},{f(y - 0.9)} Q{f(cx)},{f(y - 4.8)} {f(cx + 3.1)},{f(y - 0.9)} L{f(cx + 3.1)},{f(y - 3.6)} L{f(cx - 3.1)},{f(y - 3.6)} Z", skin)
        s.line(f"M{f(cx - 2.9)},{f(y - 0.8)} Q{f(cx)},{f(y - 1.7)} {f(cx + 2.9)},{f(y - 0.8)}", INK, 1.0)


def eyes_happy(s, y=22.8, dx=5.9, c=INK):
    for sx in (-1, 1):
        cx = 24 + sx * dx
        s.line(f"M{f(cx - 2.6)},{f(y + 0.9)} Q{f(cx)},{f(y - 2.6)} {f(cx + 2.6)},{f(y + 0.9)}", c, 1.4)


def brows(s, color, y=18.3, dx=5.9, w=1.3, inner=0.0, arch=0.7, half=3.2, so=1.0):
    for sx in (-1, 1):
        cx = 24 + sx * dx
        outer_x, inner_x = cx + sx * half, cx - sx * half
        oy, iy = y - inner * 0.35, y + inner
        s.line(f"M{f(outer_x)},{f(oy)} Q{f(cx)},{f(y - arch - inner * 0.2)} {f(inner_x)},{f(iy)}", color, w, so)


def mouth(s, kind, c='#6B2A2A', y=29.0, skin='#F6D2B0'):
    if kind == 'smile':
        s.line(f"M19.8,{f(y - 0.3)} Q24,{f(y + 3.6)} 28.2,{f(y - 0.3)}", c, 1.25)
    elif kind == 'grin':
        s.path(f"M18.4,{f(y - 1.2)} Q24,{f(y - 0.2)} 29.6,{f(y - 1.2)} Q28.8,{f(y + 5.2)} 24,{f(y + 5.2)} Q19.2,{f(y + 5.2)} 18.4,{f(y - 1.2)} Z", '#7A2630')
        s.path(f"M19,{f(y - 0.9)} Q24,{f(y + 0.1)} 29,{f(y - 0.9)} Q28.8,{f(y + 1.5)} 28.2,{f(y + 1.8)} Q24,{f(y + 2.4)} 19.8,{f(y + 1.8)} Q19.2,{f(y + 1.5)} 19,{f(y - 0.9)} Z", '#FFFFFF')
        s.ell(24, y + 3.8, 2.4, 1.1, '#F0707F')
    elif kind == 'open':
        s.ell(24, y + 1.6, 2.7, 2.5, '#6B2230')
        s.ell(24, y + 2.7, 1.7, 1.0, '#EE7482')
    elif kind == 'smirk':
        s.line(f"M20,{f(y + 0.5)} Q24.5,{f(y + 2.6)} 29,{f(y - 0.7)}", c, 1.25)
        s.line(f"M29,{f(y - 0.7)} l0.9,-0.8", c, 1.0)
    elif kind == 'flat':
        s.line(f"M20.6,{f(y + 0.9)} L27.4,{f(y + 0.9)}", c, 1.25)
    elif kind == 'calm':
        s.line(f"M20.6,{f(y + 0.5)} Q24,{f(y + 1.9)} 27.4,{f(y + 0.5)}", c, 1.2)
    elif kind == 'tongue':
        s.path(f"M19,{f(y - 0.6)} Q24,{f(y + 5)} 29,{f(y - 0.6)} Z", '#7A2630')
        s.path(f"M22.4,{f(y + 2.2)} Q24.2,{f(y + 6.2)} 26.6,{f(y + 2.4)} Z", '#F0707F')
    elif kind == 'lips':   # môi tô son
        s.path(f"M19.6,{f(y + 0.6)} Q21.8,{f(y - 1.2)} 24,{f(y - 0.2)} Q26.2,{f(y - 1.2)} 28.4,{f(y + 0.6)} Q24,{f(y + 4.2)} 19.6,{f(y + 0.6)} Z", c)
        s.line(f"M19.8,{f(y + 0.7)} Q24,{f(y + 1.6)} 28.2,{f(y + 0.7)}", dk(c, 0.35), 0.7)


def shine(s, d, op=0.28, sw=1.2):
    s.line(d, '#FFFFFF', sw, op)


# ───────────────────────────────────────── 15 nhân vật
SKIN = dict(
    light=('#FAD9BC', '#E4AE88'), fair=('#F6D2B0', '#DFA77F'), tan=('#E7B68A', '#C98F63'),
    brown=('#B87B52', '#98603C'), dark=('#8B5A3C', '#6F4429'), pale=('#FCE4D0', '#E8B999'),
)


def martin(s):  # 250 — người mới tập chơi: mặt tròn, mắt to, miệng há
    sk, sh = SKIN['light']
    bg(s, '#7FC8B0', '#E8FFF5')
    body(s, '#F0B33C', sk, sh)
    s.path("M19,37 Q24,41 29,37 L28,36 Q24,39 20,36 Z", '#C98C1C', 0.9)
    head(s, sk, sh, rx=12.2, ry=12.4, cy=23)
    hair = '#6B4430'
    s.path("M11.6,21 C10.2,10 17,6.2 24,6.2 C31,6.2 37.8,10 36.4,21 C34.6,16.4 30,14.6 24,14.6 C18,14.6 13.4,16.4 11.6,21 Z", hair)
    s.path("M21.4,7 Q20.2,2.6 25.4,3.4 Q23.6,4.8 26.4,7 Z", hair)
    s.path("M28,8 Q31,5.2 33.4,7.4 Q31,7.6 30,9.6 Z", hair)
    shine(s, "M15.5,11.6 Q19,8 24.6,8", 0.3)
    brows(s, hair, y=18.6, inner=-0.5, arch=1.0)
    eyes_round(s, '#4B8F6B', y=23.6, sz=1.12)
    blush(s, y=28.0, op=0.4)
    nose(s, sk, y=25.6)
    mouth(s, 'open', y=29.6)


def jimmy(s):  # 600 — luôn cố gắng hết mình: băng đô đỏ, lè lưỡi tập trung
    sk, sh = SKIN['brown']
    bg(s, '#F2A04A', '#FFF0D4')
    body(s, '#2F6FD0', sk, sh)
    head(s, sk, sh, rx=12.0, ry=12.6, cy=23)
    hair = '#241A16'
    s.path("M11.8,17 C10.6,8.8 17,5.4 24,5.4 C31,5.4 37.4,8.8 36.2,17 Q24,12.2 11.8,17 Z", hair)
    s.path("M11.8,15.8 Q24,11 36.2,15.8 L36.4,19.6 Q24,14.8 11.6,19.6 Z", '#E0443A')
    s.path("M11.8,15.8 Q24,11 36.2,15.8 L36.3,17 Q24,12.4 11.7,17 Z", lt('#E0443A', 0.35), 0.7)
    s.path("M35.2,17.6 L40.4,15.4 L39.2,19.6 Z M35.4,18.4 L40,22.4 L37.2,18.4 Z", '#C73328')
    brows(s, hair, y=20.1, inner=1.0, arch=0.4, w=1.4)
    eyes_round(s, '#3A2418', y=24.0, sz=1.0)
    blush(s, y=28.2, c='#FF6E5A', op=0.3)
    nose(s, sk, y=25.4)
    s.path("M25.5,29.4 Q28.6,30 28,33.2 Q25.5,33.4 25.5,29.4 Z", '#F0707F')
    s.line("M20,29 Q24,31.6 28.4,29.2", '#5A1E1E', 1.2)
    # giọt mồ hôi
    s.path("M38.6,22.4 Q40.4,25.4 38.6,27 Q36.8,25.4 38.6,22.4 Z", '#8FD3FF', 0.95)


def nelson(s):  # 800 — thích đi quân ra giữa bàn: mũ lưỡi trai, tàn nhang
    sk, sh = SKIN['light']
    bg(s, '#6FA8E8', '#EAF4FF')
    body(s, '#E8E4D8', sk, sh)
    s.path("M12,33 L36,33 L37,48 L11,48 Z", '#FFFFFF', 0.0)
    s.path("M17,37 L24,42 L31,37", None, 1.0, '#C9C4B4', 1.0, 0.9)
    head(s, sk, sh, rx=11.9, ry=12.8, cy=22.6)
    hairc = '#E8B54A'
    s.path("M12,19 Q10.6,23 12.2,26.4 Q13,22.6 14.4,19.4 Z", hairc)
    s.path("M36,19 Q37.4,23 35.8,26.4 Q35,22.6 33.6,19.4 Z", hairc)
    cap, capd = '#E04B3C', '#B03226'
    s.path("M11.8,18 C11.6,7.2 17,4.4 24,4.4 C31,4.4 36.4,7.2 36.2,18 Q24,14.2 11.8,18 Z", cap)
    s.path("M24,4.4 L24,15.2", None, 1.0, capd, 0.9, 0.8)
    s.circ(24, 4.6, 1.3, capd)
    s.path("M10.6,17.6 Q24,13.4 37.4,17.6 Q40.6,19.4 36.8,20.6 Q24,17.2 11.2,20.6 Q7.8,19.6 10.6,17.6 Z", capd)
    shine(s, "M16,9 Q19.6,6.4 24,6.2", 0.35)
    brows(s, '#B8862E', y=20.6, inner=-0.4, arch=0.9)
    eyes_round(s, '#3C86D6', y=23.6, sz=1.0)
    for x, y in ((16.4, 27.2), (18.2, 28.2), (15.2, 28.8), (31.6, 27.2), (29.8, 28.2), (32.8, 28.8)):
        s.circ(x, y, 0.45, '#B9683A', 0.7)
    blush(s, y=27.8, op=0.28)
    nose(s, sk, y=25.3)
    mouth(s, 'grin', y=29.3)


def emir(s):  # 1000 — chiến thuật gia: kính tròn, nhướn mày, cười nhếch
    sk, sh = SKIN['tan']
    bg(s, '#2E9C98', '#D9FFFA')
    body(s, '#3B4A63', sk, sh)
    s.path("M17.6,36.2 L24,43 L30.4,36.2 L28,35.6 L24,39 L20,35.6 Z", '#EDEFF3')
    s.path("M24,38.6 L22.6,48 L25.4,48 Z", '#E0B13A')
    head(s, sk, sh, rx=11.4, ry=13.2, cy=22.2)
    hair = '#1F1816'
    s.path("M12,20 C10.6,9 17,5.4 24.6,5.4 C32,5.6 37.6,9.6 36,20 C34.6,15 30.6,12.8 25.6,12.6 C19.6,12.4 14.4,14.6 12,20 Z", hair)
    s.path("M12.4,19.4 C12.2,14 16,11.4 22,11.6 C17,12.6 14.4,15.4 14.2,20.4 Z", dk(hair, 0.0))
    shine(s, "M17,9.6 Q22,6.6 29,7.6", 0.28)
    brows(s, hair, y=18.0, inner=0.0, arch=0.9)
    s.line("M24.4,16.6 Q30,15.2 33.4,17.2", hair, 1.5)   # lông mày phải nhướn cao
    eyes_round(s, '#6B4A2A', y=22.6, sz=0.95)
    for sx in (-1, 1):
        s.circ(24 + sx * 5.9, 22.6, 4.4, '#FFFFFF', 0.14)
        s.path(f"M{f(24 + sx * 5.9 - 4.4)},22.6 a4.4,4.4 0 1,0 8.8,0 a4.4,4.4 0 1,0 -8.8,0 Z", None, 1.0, '#E3B53C', 1.0)
        s.path(f"M{f(24 + sx * 5.9 - 4.4)},22.6 a4.4,4.4 0 1,0 8.8,0 a4.4,4.4 0 1,0 -8.8,0 Z", None, 1.0, '#E3B53C', 1.0)
    s.line("M17.8,22.2 Q24,20.4 30.2,22.2", '#E3B53C', 1.0)
    nose(s, sk, y=24.8)
    mouth(s, 'smirk', y=29.2, c='#6A2E22')


def lena(s):  # 1200 — tấn công không biết mệt: tóc đỏ đuôi ngựa, mày xếch, cười thách thức
    sk, sh = SKIN['fair']
    bg(s, '#E5584B', '#FFE3DA')
    hairc = '#D9461E'
    s.path("M33,9 C42,8 46,18 43,28 C42,33 40,36 37,38 C39,32 38,26 36,22 Z", hairc)
    s.path("M33,9 C42,8 46,18 43,28 C42.4,31 41.6,33.4 40.6,35", None, 1.0, lt(hairc, 0.3), 1.0, 0.5)
    body(s, '#1F2430', sk, sh)
    s.path("M19,36 Q24,41 29,36 L27.6,35.4 Q24,38.6 20.4,35.4 Z", '#E5584B', 0.95)
    head(s, sk, sh, rx=11.3, ry=12.9, cy=22.4)
    s.path("M12,21 C10.4,10 17,5.6 24.6,5.8 C32,6 37.6,10.4 36,20.6 C33.6,14.6 27,12.6 20.8,14.6 C17,15.8 13.6,18 12,21 Z", hairc)
    s.path("M12,21 C11,16 13,13 16.6,11.4 C14.6,14.6 14,17.6 14.6,21 Z", dk(hairc, 0.2))
    shine(s, "M18,9 Q23,6.6 29,7.4", 0.32)
    s.circ(38.6, 11.6, 1.8, '#FFD23F')
    brows(s, dk(hairc, 0.35), y=18.6, inner=1.5, arch=0.4, w=1.5)
    eyes_round(s, '#2E9A6A', y=22.9, sz=0.98, lash=True)
    blush(s, y=27.4, c='#FF6B6B', op=0.3)
    nose(s, sk, y=24.8)
    mouth(s, 'grin', y=29.1)


def antonio(s):  # 1500 — kiện tướng tập sự: tóc vuốt ngược, ria mép
    sk, sh = SKIN['tan']
    bg(s, '#B8465A', '#FFDDE3')
    body(s, '#2B2B33', sk, sh)
    s.path("M17.6,36.2 L24,43 L30.4,36.2 L28,35.6 L24,39 L20,35.6 Z", '#F3F1EA')
    s.path("M24,39 L22.4,41.6 L24,43 L25.6,41.6 Z", '#B8465A')
    head(s, sk, sh, rx=11.5, ry=13.1, cy=22.2)
    hair = '#241915'
    s.path("M12,20.6 C10.4,9.4 17,5 24.4,5 C32,5 38,9.4 36,20.6 C35.4,15.4 31.4,11.6 24.6,11.4 C17.6,11.2 12.8,15 12,20.6 Z", hair)
    for d in ("M15,10.6 Q21,6.6 30,8", "M14,13.4 Q20,9.6 33,11.4"):
        shine(s, d, 0.22, 1.0)
    s.path("M12.2,20 Q12,16 13.6,13.6 L14.4,20 Z", '#B9B4B0', 0.8)
    s.path("M35.8,20 Q36,16 34.4,13.6 L33.6,20 Z", '#B9B4B0', 0.8)
    brows(s, hair, y=18.2, inner=0.2, arch=0.8, w=1.5)
    eyes_round(s, '#5A3A22', y=22.6, sz=0.92)
    blush(s, y=27.4, op=0.2)
    nose(s, sk, y=24.6)
    s.path("M17.2,28.4 Q20.6,26.2 24,27.8 Q27.4,26.2 30.8,28.4 Q28,30.6 24,28.8 Q20,30.6 17.2,28.4 Z", hair)
    s.line("M21,31.6 Q24,33.2 27,31.6", '#6A2E22', 1.1)


def sofia(s):  # 1700 — phòng thủ chắc như đá: tóc dài, băng đô xám đá, mắt điềm tĩnh
    sk, sh = SKIN['brown']
    bg(s, '#8190A5', '#F0F5FF')
    hairc = '#2E211D'
    s.path("M11,21 C8.6,32 9.6,41 14.6,45 L33.4,45 C38.4,41 39.4,32 37,21 C36.4,8 11.6,8 11,21 Z", hairc)
    body(s, '#5E6B80', sk, sh)
    s.path("M1,48 C1,40.5 8,36.8 18.6,35.6 L16,48 Z", dk('#5E6B80', 0.2), 0.0)
    s.path("M10.6,30 C9.6,36 11,41 15,44 L18,40 C14.4,38 12.6,34 12.6,30 Z", hairc)
    s.path("M37.4,30 C38.4,36 37,41 33,44 L30,40 C33.6,38 35.4,34 35.4,30 Z", hairc)
    head(s, sk, sh, rx=11.3, ry=13.0, cy=22.4)
    s.path("M12.2,21 C11,9.8 17.4,6 24,6 C30.6,6 37,9.8 35.8,21 C34.4,15.6 29.6,12.4 24,12.4 C18.4,12.4 13.6,15.6 12.2,21 Z", hairc)
    s.path("M24,6.2 Q23,10 19.6,12.8", None, 1.0, lt(hairc, 0.3), 0.9, 0.5)
    s.path("M12,14.4 Q24,7.6 36,14.4 L36.2,16.8 Q24,10.4 11.8,16.8 Z", '#A9B4C6')
    s.path("M12,14.4 Q24,7.6 36,14.4 L36.1,15.4 Q24,9 11.9,15.4 Z", '#E4EAF4', 0.7)
    brows(s, hairc, y=19.2, inner=0.0, arch=0.6, w=1.4)
    eyes_calm(s, sk, y=22.9, iris='#3A2A20')
    blush(s, y=27.6, c='#E8695A', op=0.26)
    nose(s, sk, y=25.0)
    mouth(s, 'calm', y=29.6, c='#6A2A2A')
    s.circ(11.8, 27, 1.0, '#F2C84B')
    s.circ(36.2, 27, 1.0, '#F2C84B')


def hiro(s):  # 1900 — bậc thầy tàn cuộc: búi tóc, mắt khép, nụ cười nhỏ
    sk, sh = SKIN['pale']
    bg(s, '#C8B556', '#FFF8D0')
    body(s, '#2B3A55', sk, sh)
    s.path("M16,35.8 L24,44 L32,35.8 L30,35.2 L24,40.6 L18,35.2 Z", '#F4F1E6')
    s.path("M18,35.4 L24,41.6 L30,35.4", None, 1.0, '#C94C4C', 1.0, 0.9)
    head(s, sk, sh, rx=11.2, ry=13.0, cy=22.4)
    hair = '#17120F'
    s.ell(24, 4.6, 3.3, 2.8, hair)
    s.path("M12.2,20.6 C10.8,9.2 17,6 24,6 C31,6 37.2,9.2 35.8,20.6 C34.4,15.6 30,13.2 24,13.2 C18,13.2 13.6,15.6 12.2,20.6 Z", hair)
    shine(s, "M16.4,10 Q20.4,7.6 26,7.8", 0.3)
    brows(s, hair, y=18.8, inner=-0.2, arch=0.5, w=1.2)
    for sx in (-1, 1):   # mắt khép lim dim
        cx = 24 + sx * 5.9
        s.line(f"M{f(cx - 2.8)},22.6 Q{f(cx)},24.6 {f(cx + 2.8)},22.6", INK, 1.3)
        s.line(f"M{f(cx - 2.8)},22.6 l-0.5,-0.4", INK, 0.9)
    blush(s, y=27.4, c='#E88A8A', op=0.2)
    nose(s, sk, y=24.8)
    mouth(s, 'smile', y=29.4, c='#6A3030')


def viktor(s):  # 2100 — kỳ thủ giải đấu: râu muối tiêu, mày dày, vest cà vạt
    sk, sh = SKIN['fair']
    bg(s, '#2F4A7A', '#CFE0FF')
    body(s, '#22262F', sk, sh)
    s.path("M17.4,36 L24,44 L30.6,36 L28.4,35.4 L24,40 L19.6,35.4 Z", '#F1EFEA')
    s.path("M24,39.6 L22.6,41.6 L24,48 L25.4,41.6 Z", '#C23B3B')
    head(s, sk, sh, rx=11.6, ry=13.3, cy=22.0)
    hair, beard = '#6D7078', '#7C7F87'
    s.path("M12.4,22.4 C13,30 17.4,35.6 24,36 C30.6,35.6 35,30 35.6,22.4 C34.4,28.6 31.6,29.4 28.6,28.4 Q24,30.4 19.4,28.4 C16.4,29.4 13.6,28.6 12.4,22.4 Z", beard)
    s.path("M12.4,22.4 C13,30 17.4,35.6 24,36", None, 1.0, dk(beard, 0.25), 0.8, 0.5)
    s.path("M12.2,18.4 C11.4,10.4 16.6,6.6 24,6.6 C31.4,6.6 36.6,10.4 35.8,18.4 C34.6,14.2 30.6,12.2 24,12.2 C17.4,12.2 13.4,14.2 12.2,18.4 Z", hair)
    shine(s, "M17,9.8 Q22,7.4 28.6,8.2", 0.3)
    brows(s, '#3B3D44', y=18.2, inner=1.5, arch=0.3, w=2.0)
    eyes_round(s, '#4C6C8A', y=22.4, sz=0.85)
    s.line("M16,25.2 Q18,26.4 20.2,25.4", dk(sk, 0.28), 0.8, 0.7)
    s.line("M27.8,25.4 Q30,26.4 32,25.2", dk(sk, 0.28), 0.8, 0.7)
    nose(s, sk, y=24.4)
    s.path("M18,28 Q21,26.2 24,27.6 Q27,26.2 30,28 Q27,30 24,28.6 Q21,30 18,28 Z", dk(beard, 0.1))
    s.line("M21.6,31.2 Q24,32 26.4,31.2", '#4A2C2C', 1.1)


def isabel(s):  # 2300 — ứng viên Kiện tướng: búi cao, môi son, hoa tai
    sk, sh = SKIN['fair']
    bg(s, '#8A4FC0', '#F2E0FF')
    body(s, '#F4F0EA', sk, sh)
    s.path("M16.6,37.2 Q24,44 31.4,37.2", None, 1.0, '#E3C25A', 0.9, 0.95)
    s.circ(24, 42.6, 1.1, '#E3C25A')
    hairc = '#6B2C22'
    s.ell(24, 5.4, 5.0, 3.8, hairc)
    s.path("M20,5.6 Q24,3 28,5.6", None, 1.0, lt(hairc, 0.35), 0.9, 0.5)
    head(s, sk, sh, rx=11.0, ry=13.2, cy=22.6)
    s.path("M12.6,21 C11.2,10.4 17.2,6.6 24,6.6 C30.8,6.6 36.8,10.4 35.4,21 C34.4,15.6 30,12.6 24.8,12.4 C19,12.4 14.2,15.6 12.6,21 Z", hairc)
    s.path("M12.6,21 C11.8,16 14,13 17.6,11.6 C15.6,14.6 14.8,17.6 15.4,22 Z", dk(hairc, 0.22))
    shine(s, "M17.4,9.8 Q22,7.4 29,8.4", 0.3)
    s.rect(21.2, 4.2, 5.6, 1.5, '#E3C25A')
    brows(s, dk(hairc, 0.2), y=18.6, inner=0.4, arch=1.0, w=1.2)
    eyes_round(s, '#7A4E9A', y=22.9, sz=0.98, lash=True)
    blush(s, y=27.6, c='#F07A8A', op=0.3)
    nose(s, sk, y=24.9)
    mouth(s, 'lips', c='#C7304A', y=29.5)
    for sx in (-1, 1):
        s.path(f"M{f(24 + sx * 11.6)},27 l0,2.4", None, 1.0, '#E3C25A', 0.8)
        s.circ(24 + sx * 11.6, 30.4, 1.2, '#E3C25A')


def magnus(s):  # 2500 — kiện tướng quốc tế: tóc rối, cười nhếch, áo hoodie
    sk, sh = SKIN['light']
    bg(s, '#4B86C8', '#E4F1FF')
    body(s, '#6C7686', sk, sh)
    s.path("M16,36 Q24,44 32,36 L30.6,35.2 Q24,40.6 17.4,35.2 Z", '#4F5865')
    s.line("M21,40 L21,45", '#F0F0F0', 1.0, 0.9)
    s.line("M27,40 L27,45", '#F0F0F0', 1.0, 0.9)
    head(s, sk, sh, rx=11.6, ry=13.0, cy=22.2)
    hair = '#9A6A3E'
    s.path("M11.8,21.4 C9.8,10 16.6,5.2 24.6,5.4 C32.6,5.6 38.4,10.6 36,21.4 C35.2,16.2 32,13.2 27.4,13 C23.6,12.8 20.6,14.4 17.8,15.2 C15.4,15.8 13,17.6 11.8,21.4 Z", hair)
    s.path("M16,8.4 Q17.4,4.4 21.6,5 Q20.4,6.6 22,8 Z", hair)
    s.path("M26,6.6 Q29.4,3.6 33,6.6 Q30.6,6.6 29.8,8.6 Z", hair)
    s.path("M12,17.6 Q10.4,13.8 13.6,11.6 Q13.2,14.6 14.6,16.6 Z", hair)
    shine(s, "M17,9.8 Q22,7 30,8.4", 0.3)
    brows(s, dk(hair, 0.3), y=18.4, inner=0.5, arch=0.7, w=1.4)
    eyes_round(s, '#5B9FD0', y=22.6, sz=0.95)
    blush(s, y=27.4, op=0.2)
    nose(s, sk, y=24.7)
    mouth(s, 'smirk', y=29.2, c='#6A3030')
    for x, y in ((16, 29), (18.6, 31), (21.6, 32.6), (26.4, 32.6), (29.4, 31), (32, 29)):
        s.circ(x, y, 0.35, '#9A6A3E', 0.45)


def olga(s):  # 2700 — đại kiện tướng: tóc bạc ngang vai, kính vuông, chuỗi ngọc trai
    sk, sh = SKIN['pale']
    bg(s, '#5B3D8F', '#E6D9FF')
    hairc = '#CDD1DA'
    s.path("M10.8,20 C8.8,28 9.2,36 12,40 L36,40 C38.8,36 39.2,28 37.2,20 C36.4,7 11.6,7 10.8,20 Z", hairc)
    body(s, '#2D2740', sk, sh)
    for i in range(7):
        a = i / 6
        s.circ(15.6 + a * 16.8, 38.0 + 4.2 * (1 - (2 * a - 1) ** 2), 0.95, '#F8F3EA')
    s.path("M10.8,28 C9.8,34 10.6,38 12.4,41 L15.6,38 C13.2,35 12.4,32 12.8,28 Z", hairc)
    s.path("M37.2,28 C38.2,34 37.4,38 35.6,41 L32.4,38 C34.8,35 35.6,32 35.2,28 Z", hairc)
    head(s, sk, sh, rx=11.2, ry=13.0, cy=22.4)
    s.path("M12.2,20.4 C11.2,10 17.4,6.8 24,6.8 C30.6,6.8 36.8,10 35.8,20.4 C34.6,16 29.4,12.8 23.4,13.4 C18.6,13.8 14,16 12.2,20.4 Z", hairc)
    shine(s, "M17,9.6 Q22,7.6 29,8.4", 0.55)
    brows(s, '#8E939F', y=18.8, inner=0.0, arch=0.8, w=1.2)
    eyes_round(s, '#3F6B8F', y=22.9, sz=0.88)
    fr = '#8C2F4A'
    for sx in (-1, 1):
        cx = 24 + sx * 5.9
        s.path(f"M{f(cx - 4.2)},20.2 L{f(cx + 4.2)},20.2 L{f(cx + 4.2)},25.6 Q{f(cx + 4.2)},26.4 {f(cx + 3.4)},26.4 L{f(cx - 3.4)},26.4 Q{f(cx - 4.2)},26.4 {f(cx - 4.2)},25.6 Z", '#FFFFFF', 0.14)
        s.path(f"M{f(cx - 4.2)},20.2 L{f(cx + 4.2)},20.2 L{f(cx + 4.2)},25.6 Q{f(cx + 4.2)},26.4 {f(cx + 3.4)},26.4 L{f(cx - 3.4)},26.4 Q{f(cx - 4.2)},26.4 {f(cx - 4.2)},25.6 Z", None, 1.0, fr, 1.1)
    s.line("M22.3,22 Q24,21 25.7,22", fr, 1.0)
    nose(s, sk, y=25.0)
    mouth(s, 'lips', c='#D0604E', y=29.6)
    blush(s, y=28.0, c='#F09A8A', op=0.24)


def daniel(s):  # 2900 — siêu đại kiện tướng: tóc vuốt gọn, ánh nhìn lạnh, ghim vàng
    sk, sh = SKIN['tan']
    bg(s, '#C9942A', '#FFF1C4')
    body(s, '#15161C', sk, sh)
    s.path("M17.4,36 L24,44 L30.4,36 L28.4,35.4 L24,40 L19.6,35.4 Z", '#F4F2EC')
    s.path("M24,40 L21.6,48 L26.4,48 Z", '#D4A62F')
    s.path("M33.6,41 l1.4,1.6 l2.1,-0.4 l-0.9,1.9 l1.3,1.7 l-2.1,-0.2 l-1.3,1.7 l-0.2,-2.1 l-1.9,-1 l1.9,-0.9 Z", '#F2C94C')
    head(s, sk, sh, rx=11.2, ry=13.4, cy=22.2)
    hair = '#15110F'
    s.path("M12.6,20 C11.2,9.6 17.4,5.2 25.2,5.4 C33,5.6 37.6,10.4 35.4,20 C34.4,16.2 32.4,12.4 25.6,12.2 C21,12 18.6,13.4 16.6,14.4 C14.6,15.4 13.2,17.2 12.6,20 Z", hair)
    s.path("M12.4,19.6 Q12.2,15.4 14.2,13.8 L14.8,20 Z", hair)
    shine(s, "M17.6,9.4 Q23,6.2 31,8.2", 0.32)
    brows(s, hair, y=18.4, inner=1.0, arch=0.4, w=1.6)
    eyes_round(s, '#2C2C34', y=22.6, sz=0.9)
    for sx in (-1, 1):
        s.path(f"M{f(24 + sx * 5.9 - 3.2)},19.4 L{f(24 + sx * 5.9 + 3.2)},19.4 L{f(24 + sx * 5.9 + 3.2)},21.2 L{f(24 + sx * 5.9 - 3.2)},21.2 Z", sk, 0.0)
    nose(s, sk, y=24.7)
    mouth(s, 'smirk', y=29.4, c='#5A2C26')
    s.line("M16.4,26.4 Q17.4,29.6 19.6,31", dk(sk, 0.3), 0.7, 0.5)


def nova(s):  # 3050 — tính trước hàng chục nước: android, kính ngắm phát sáng, ăng-ten
    sk, sh = '#C9D7E8', '#93A8C4'
    bg(s, '#0F1B3A', '#3CD7FF')
    s.circ(24, 24, 20, '#2FD2F5', 0.10)
    body(s, '#26324F', sk, sh)
    s.path("M18,36.5 Q24,42 30,36.5", None, 1.0, '#39D8FF', 1.2, 0.95)
    s.path("M12,41 L16,44 M36,41 L32,44", None, 1.0, '#39D8FF', 1.0, 0.6)
    s.line("M24,6 L24,2.8", '#7F93B2', 1.1)
    s.circ(24, 2.4, 1.9, '#FF5C7A')
    s.circ(24, 2.4, 3.2, '#FF5C7A', 0.25)
    for sx in (-1, 1):
        s.ell(24 + sx * 11.9, 23.4, 2.2, 3.6, '#2B3A5C')
        s.ell(24 + sx * 11.9, 23.4, 1.0, 2.2, '#39D8FF')
    head(s, sk, sh, rx=11.4, ry=12.8, cy=22.2, ears=False)
    s.path("M13.4,13.6 Q24,7.4 34.6,13.6 Q24,10.4 13.4,13.6 Z", '#FFFFFF', 0.5)
    s.path("M12.2,18.6 Q24,15.4 35.8,18.6 L35.8,26.2 Q24,29 12.2,26.2 Z", '#10192F')
    s.path("M12.2,18.6 Q24,15.4 35.8,18.6", None, 1.0, '#39D8FF', 0.9, 0.7)
    for sx in (-1, 1):
        cx = 24 + sx * 5.9
        s.ell(cx, 22.6, 3.3, 2.6, '#39D8FF', 0.28)
        s.ell(cx, 22.6, 2.5, 2.0, '#39D8FF')
        s.ell(cx, 22.6, 1.2, 1.2, '#FFFFFF')
    s.line("M17,27.4 L20,27.4 M28,27.4 L31,27.4", '#39D8FF', 0.8, 0.6)
    s.line("M20.4,31.2 L27.6,31.2", '#2B3A5C', 1.3)
    for i in range(3):
        s.circ(22.4 + i * 1.6, 31.2, 0.45, '#39D8FF')
    s.line("M14.4,29.6 L16.4,29.6 L17.6,31.4", '#39D8FF', 0.7, 0.6)
    s.line("M33.6,29.6 L31.6,29.6 L30.4,31.4", '#39D8FF', 0.7, 0.6)


def mittens(s):  # 3200 — cỗ máy không thể bị đánh bại: mèo đen mắt vàng, vòng cổ cyber
    bg(s, '#33305E', '#B4A7FF')
    fur, furd = '#2A2A33', '#1B1B22'
    s.path("M2,48 C2,41 9,37.6 17,36.6 Q24,40 31,36.6 C39,37.6 46,41 46,48 Z", furd)
    s.path("M14,32 L16,34 Q24,38 32,34 L34,32 Q34,37 24,40 Q14,37 14,32 Z", '#1B1B22', 0.0)
    s.path("M8.4,19 L9.2,3.4 L21,10.6 Z", fur)
    s.path("M39.6,19 L38.8,3.4 L27,10.6 Z", fur)
    s.path("M11.2,15.6 L11.6,7.4 L17.6,11.4 Z", '#F28AA6')
    s.path("M36.8,15.6 L36.4,7.4 L30.4,11.4 Z", '#F28AA6')
    s.ell(24, 24, 14.2, 12.0, furd)
    s.ell(23.5, 23.4, 13.6, 11.4, fur)
    s.ell(24, 29.2, 7.0, 5.0, '#44444F')
    shine(s, "M14.6,15.6 Q19,12.4 24,12.2", 0.2)
    for sx in (-1, 1):
        cx = 24 + sx * 6.2
        s.ell(cx, 21.8, 3.7, 3.7, '#F5C92B', 0.22)
        s.ell(cx, 21.8, 3.0, 3.2, '#F5C92B')
        s.ell(cx, 21.8, 0.95, 2.9, '#14141A')
        s.circ(cx - 0.9, 20.4, 0.7, '#FFFFFF')
        s.path(f"M{f(cx - 3.4)},19.8 Q{f(cx)},{f(17.6)} {f(cx + 3.4)},19.8", None, 1.0, '#14141A', 0.9, 0.8)
    s.path("M22.2,26.2 L25.8,26.2 L24,28.2 Z", '#F28AA6')
    s.line("M24,28.2 L24,29.6 M24,29.6 Q22,31.6 20.2,30.2 M24,29.6 Q26,31.6 27.8,30.2", '#14141A', 0.9)
    for dy, a in ((0, -0.6), (1.6, 0.4)):
        s.line(f"M16,{f(28.2 + dy)} L8.4,{f(27 + dy + a)}", '#C9C9D6', 0.7, 0.85)
        s.line(f"M32,{f(28.2 + dy)} L39.6,{f(27 + dy + a)}", '#C9C9D6', 0.7, 0.85)
    s.path("M13.4,35.8 Q24,41.2 34.6,35.8 L34,38.2 Q24,43.6 14,38.2 Z", '#3AD6FF')
    s.path("M13.4,35.8 Q24,41.2 34.6,35.8", None, 1.0, '#FFFFFF', 0.7, 0.4)
    s.circ(24, 41.4, 2.2, '#F5C92B')
    s.circ(24, 41.4, 1.0, '#FFF3B8')


BOTS = [
    ('martin', 'Martin', 250, martin), ('jimmy', 'Jimmy', 600, jimmy), ('nelson', 'Nelson', 800, nelson),
    ('emir', 'Emir', 1000, emir), ('lena', 'Lena', 1200, lena), ('antonio', 'Antonio', 1500, antonio),
    ('sofia', 'Sofia', 1700, sofia), ('hiro', 'Hiro', 1900, hiro), ('viktor', 'Viktor', 2100, viktor),
    ('isabel', 'Isabel', 2300, isabel), ('magnus', 'Magnus', 2500, magnus), ('olga', 'Olga', 2700, olga),
    ('daniel', 'Daniel', 2900, daniel), ('nova', 'Nova', 3050, nova), ('mittens', 'Mittens', 3200, mittens),
]


def build(only=None):
    res = {}
    for bid, name, elo, fn in BOTS:
        if only and bid not in only:
            continue
        s = Scene()
        fn(s)
        res[bid] = s
    return res


if __name__ == '__main__':
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('out')
    out.mkdir(parents=True, exist_ok=True)
    for bid, s in build().items():
        (out / f'bot_{bid}.xml').write_text(s.android(), encoding='utf-8')
        (out / f'bot_{bid}.svg').write_text(s.svg(), encoding='utf-8')
    print('ok', len(BOTS))
