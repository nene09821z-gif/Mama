# -*- coding: utf-8 -*-
# NGUỒN DUY NHẤT của danh sách từ cấm: gen.py sinh Kotlin + SQL từ đây.
# Mọi mục đã bỏ dấu, viết thường (trừ ORIGINAL_BAD/ALLOW giữ dấu).

# Khớp NGUYÊN CẢ TỪ (tách theo dấu cách/dấu câu). Dùng cho từ ngắn dễ trùng tên thật.
TOKENS = [
    # tiếng Việt (viết tắt / không dấu)
    "dit", "ditme", "dm", "dmm", "dcm", "dcmm", "dkm", "dkmm", "vcl", "vkl", "vl", "vlz",
    "cmm", "cmn", "clgt", "cac", "cak", "lon", "loz", "buoi", "concac",
    # tiếng Anh
    "dick", "cock", "ass", "porn", "sex", "hentai", "rape", "rapist", "nazi", "kkk", "tits", "boobs",
    "fag", "slut", "cum", "twat", "prick", "shit", "shitty", "chink", "gook", "spic", "tranny",
    "cunt", "cunts", "fck", "fuk", "fvck", "milf", "dildo", "nude", "nudes", "xxx", "horny", "bdsm", "pedo",
]

# Cụm từ (dãy từ liền nhau).
PHRASES = [
    "dit me", "dit con me", "dit cu", "du ma", "du me", "dau buoi", "me may", "con cho", "thang cho",
    "cho chet", "oc cho", "thang ngu", "con ngu", "do ngu", "suc vat", "khon nan", "vai lon",
    "white power",
]

# Chuỗi đủ dài/an toàn: chặn kể cả khi dính liền hoặc chen dấu cách/dấu chấm ("f u c k", "xXfuckXx").
STRONG = [
    "fuck", "bitch", "nigger", "nigga", "faggot", "whore", "asshole", "bastard", "bollocks", "wanker",
    "jizz", "pedophile", "paedophile", "retard", "hitler", "dickhead", "cocksucker", "bullshit",
    "shithead", "dipshit", "pussy",
    "ditme", "ditmay", "ditcon", "dumamay", "dumemay", "daubuoi",
]

# Từ có dấu mà khi bỏ dấu sẽ trùng chữ thường gặp: chỉ chặn khi viết ĐÚNG dấu.
ORIGINAL_BAD = ["đĩ", "đéo", "đụ", "điếm"]

# Từ có dấu hợp lệ nhưng bỏ dấu lại trùng từ cấm (bưởi/buổi -> buoi, lớn -> lon, ngư -> ngu, các -> cac).
ALLOW = ["bưởi", "buổi", "bưới", "lớn", "ngư", "các"]
