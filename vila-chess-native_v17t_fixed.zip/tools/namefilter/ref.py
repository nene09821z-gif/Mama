# -*- coding: utf-8 -*-
"""Bản tham chiếu bằng Python của NameFilter.kt (cùng thuật toán) để kiểm thử danh sách."""
import re, unicodedata
from lists import *

INVIS = re.compile('[\u200B-\u200D\u2060\uFEFF\u00AD]')
SPLIT_A = re.compile(r'[^\w]+|_+', re.U)         # \w của Python gồm chữ+số+_ ; thêm _ làm dấu tách
SPLIT_B = re.compile(r'[^\w@$!]+|_+', re.U)
RUN3 = re.compile(r'(.)\1{2,}')

def map_char(c):
    return {'đ':'d','0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s','!':'i',
            '\u0430':'a','\u0435':'e','\u043E':'o','\u0440':'p','\u0441':'c','\u0445':'x','\u0443':'y','\u0456':'i'}.get(c, c)

def strip_marks(s):
    return ''.join(ch for ch in unicodedata.normalize('NFD', s) if unicodedata.category(ch) != 'Mn')

def fold(tok):
    return ''.join(map_char(c) for c in strip_marks(tok))

def variants(t):
    return list(dict.fromkeys([t, RUN3.sub(lambda m: m.group(1), t), RUN3.sub(lambda m: m.group(1)*2, t)]))

def hits(toks):
    allt = list(toks); run = ''
    for t in toks + [None]:
        if t is not None and len(t) == 1 and t != '#': run += t
        else:
            if len(run) >= 3: allt.append(run)
            run = ''
    if len(toks) >= 2 and all(len(t) == 1 and t != '#' for t in toks): allt.append(''.join(toks))   # "đ.m", "v c l"
    if any(v in TOKENS for t in allt for v in variants(t)): return True
    line = ' ' + ' '.join(toks) + ' '
    return any(' ' + p + ' ' in line for p in PHRASES)

def strong(base):
    compact = ''.join(m for m in (map_char(c) for c in strip_marks(base)) if 'a' <= m <= 'z')
    return any(s in v for v in variants(compact) for s in STRONG)

def is_offensive(raw):
    base = unicodedata.normalize('NFKC', INVIS.sub('', raw)).lower()
    if any(t in ORIGINAL_BAD for t in SPLIT_A.split(base) if t): return True
    for sp in (SPLIT_A, SPLIT_B):
        orig = [t for t in sp.split(base) if t]
        toks = ['#' if t in ALLOW else fold(t) for t in orig]
        if hits(toks): return True
    return strong(base)
