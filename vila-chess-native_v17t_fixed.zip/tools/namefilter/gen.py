# -*- coding: utf-8 -*-
import re, sys
from lists import *
import test_ref_data as D

def ks(s):  # chuỗi Kotlin
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('$', '\\$') + '"'

def ksu(s):  # chuỗi Kotlin có \u cho ký tự vô hình/giả dạng, để file nguồn đọc được
    out = ''
    for ch in s:
        if ord(ch) > 0x2000 and ord(ch) < 0x2070 or ch == '\uFEFF' or '\u0400' <= ch <= '\u04FF':
            out += '\\u%04X' % ord(ch)
        else:
            out += ks(ch)[1:-1]
    return '"' + out + '"'

def klist(name, items, kind='setOf', width=96):
    parts = [ks(i) for i in items]
    lines, cur = [], '        '
    for p in parts:
        if len(cur) + len(p) + 2 > width:
            lines.append(cur.rstrip()); cur = '        '
        cur += p + ', '
    lines.append(cur.rstrip())
    return f'    private val {name} = {kind}(\n' + '\n'.join(lines) + '\n    )\n'

KT = r'''package com.vila.chess.profile

import java.text.Normalizer
import java.util.Locale

/**
 * Bộ lọc tên bậy (tiếng Việt + tiếng Anh) cho tên hiển thị. Thuần Kotlin, không phụ thuộc Android nên test được trên JVM.
 *
 * Cách làm (ưu tiên KHÔNG chặn nhầm tên thật, rồi mới đến bắt được nhiều kiểu né):
 *  1. Chuẩn hóa: bỏ ký tự vô hình, NFKC (chữ full-width), chữ thường, bỏ dấu tiếng Việt (đ -> d), đổi chữ Kirin giống Latin,
 *     đổi kiểu viết lách (0->o 1->i 3->e 4->a 5->s 7->t @->a $->s !->i).
 *  2. So khớp:
 *     - [TOKENS]: khớp NGUYÊN CẢ TỪ (tách theo dấu cách/dấu câu) -> "Hancock", "Dickson", "Takeshita" không bị chặn.
 *     - [PHRASES]: dãy từ liền nhau ("dit me", "con cho").
 *     - [STRONG]: chuỗi dài, tìm trong chuỗi đã dồn liền -> bắt "f u c k", "xXfuckXx", "fuuuck".
 *     - Chữ cái lẻ cách nhau ("đ.m", "s h i t") được ghép lại rồi mới so.
 *  3. [ORIGINAL_BAD]: từ chỉ xấu khi ĐÚNG dấu (đĩ, đéo, đụ...). [ALLOW]: từ hợp lệ bỏ dấu lại trùng từ cấm (bưởi, lớn, ngư...).
 *
 * Danh sách bên dưới được sinh từ nf/lists.py; sửa ở đó rồi sinh lại, hoặc sửa thẳng ở đây (nhớ sửa cả supabase/name_filter.sql).
 */
object NameFilter {
    const val MESSAGE = "Tên chứa từ không phù hợp, hãy chọn tên khác"

    // ----------------------------------------------------------------------------- DANH SÁCH
@@LISTS@@
    // ----------------------------------------------------------------------------- THUẬT TOÁN
    private val INVISIBLE = Regex("[\\u200B-\\u200D\\u2060\\uFEFF\\u00AD]")
    private val SPLIT_A = Regex("[^\\p{L}\\p{N}]+")            // mọi ký hiệu là dấu tách
    private val SPLIT_B = Regex("[^\\p{L}\\p{N}@\$!]+")        // @ $ ! được coi là chữ (kiểu viết lách)
    private val MARKS = Regex("\\p{Mn}+")
    private val RUN3 = Regex("(.)\\1{2,}")

    @Volatile private var memo: Pair<String, Boolean>? = null

    /** true nếu [raw] chứa từ không phù hợp. Có nhớ kết quả gần nhất vì UserSessionManager.displayName được đọc rất nhiều lần. */
    fun isOffensive(raw: String): Boolean {
        memo?.let { if (it.first == raw) return it.second }
        val r = check(raw)
        memo = raw to r
        return r
    }

    private fun check(raw: String): Boolean {
        val base = Normalizer.normalize(INVISIBLE.replace(raw, ""), Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        if (SPLIT_A.split(base).any { it in ORIGINAL_BAD }) return true
        for (split in listOf(SPLIT_A, SPLIT_B)) {
            val toks = split.split(base).filter { it.isNotEmpty() }.map { if (it in ALLOW) "#" else fold(it) }
            if (hits(toks)) return true
        }
        return strong(base)
    }

    private fun mapChar(c: Char): Char = when (c) {
        '\u0111' -> 'd'                         // đ
        '0' -> 'o'
        '1' -> 'i'
        '3' -> 'e'
        '4' -> 'a'
        '5' -> 's'
        '7' -> 't'
        '@' -> 'a'
        '\$' -> 's'
        '!' -> 'i'
        '\u0430' -> 'a'                         // Kirin giống Latin: а е о р с х у і
        '\u0435' -> 'e'
        '\u043E' -> 'o'
        '\u0440' -> 'p'
        '\u0441' -> 'c'
        '\u0445' -> 'x'
        '\u0443' -> 'y'
        '\u0456' -> 'i'
        else -> c
    }

    /** Bỏ dấu + đổi kiểu viết lách cho MỘT từ. */
    private fun fold(token: String): String {
        val sb = StringBuilder(token.length)
        for (ch in MARKS.replace(Normalizer.normalize(token, Normalizer.Form.NFD), "")) sb.append(mapChar(ch))
        return sb.toString()
    }

    /** "shiiit" -> "shit" / "shiit": gom chuỗi lặp 3+ ký tự về 1 hoặc 2 ký tự. */
    private fun variants(t: String): List<String> {
        val one = RUN3.replace(t) { it.groupValues[1] }
        val two = RUN3.replace(t) { it.groupValues[1] + it.groupValues[1] }
        return listOf(t, one, two).distinct()
    }

    private fun hits(toks: List<String>): Boolean {
        val all = ArrayList<String>(toks)
        // Cả tên chỉ gồm chữ cái lẻ ("đ.m", "v c l") hoặc một dãy 3+ chữ lẻ ("s h i t") -> ghép lại.
        if (toks.size >= 2 && toks.all { it.length == 1 && it != "#" }) all.add(toks.joinToString(""))
        val run = StringBuilder()
        for (t in toks + "") {                  // "" là mốc kết thúc
            if (t.length == 1 && t != "#") run.append(t)
            else {
                if (run.length >= 3) all.add(run.toString())
                run.setLength(0)
            }
        }
        if (all.any { t -> variants(t).any { it in TOKENS } }) return true
        val line = " " + toks.joinToString(" ") + " "
        return PHRASES.any { " $it " in line }
    }

    /** Dồn toàn tên thành một chuỗi a-z liền nhau rồi tìm các chuỗi dài trong [STRONG]. */
    private fun strong(base: String): Boolean {
        val sb = StringBuilder()
        for (ch in MARKS.replace(Normalizer.normalize(base, Normalizer.Form.NFD), "")) {
            val m = mapChar(ch)
            if (m in 'a'..'z') sb.append(m)
        }
        return variants(sb.toString()).any { v -> STRONG.any { it in v } }
    }
}
'''
lists_kt = (klist('TOKENS', TOKENS, 'hashSetOf') + '\n' + klist('PHRASES', PHRASES, 'listOf') + '\n' +
            klist('STRONG', STRONG, 'listOf') + '\n' + klist('ORIGINAL_BAD', ORIGINAL_BAD, 'hashSetOf') + '\n' +
            klist('ALLOW', ALLOW, 'hashSetOf'))
open('NameFilter.kt', 'w', encoding='utf-8').write(KT.replace('@@LISTS@@', lists_kt))

# ------------------------------------------------------------------ test Kotlin
def kt_arr(items):
    return ',\n        '.join(ksu(i) for i in items)
TEST = '''package com.vila.chess

import com.vila.chess.profile.NameFilter
import com.vila.chess.profile.NameRules
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NameFilterTest {
    /** Tên thật (có dấu / không dấu, tên Nhật, Anh, biệt danh) KHÔNG được bị chặn. */
    private val good = listOf(
        @@GOOD@@
    )

    /** Tên bậy và các kiểu né lọc: phải bị chặn. */
    private val bad = listOf(
        @@BAD@@
    )

    @Test fun real_names_are_not_blocked() {
        val wrong = good.filter { NameFilter.isOffensive(it) }
        assertTrue("Chặn nhầm: $wrong", wrong.isEmpty())
    }

    @Test fun offensive_names_are_blocked() {
        val missed = bad.filterNot { NameFilter.isOffensive(it) }
        assertTrue("Lọt: $missed", missed.isEmpty())
    }

    @Test fun invisible_and_fullwidth_tricks() {
        assertTrue(NameFilter.isOffensive("fu\\u200Bck"))
        assertTrue(NameFilter.isOffensive("\\uFF26\\uFF55\\uFF43\\uFF4B"))
        assertTrue(NameFilter.isOffensive("fu\\u0441k"))
    }

    @Test fun accent_sensitive_words() {
        assertFalse(NameFilter.isOffensive("B\\u01B0\\u1EDFi"))        // Bưởi
        assertFalse(NameFilter.isOffensive("Ng\\u01B0"))              // Ngư
        assertTrue(NameFilter.isOffensive("\\u0111\\u00E9o"))         // đéo
        assertTrue(NameFilter.isOffensive("\\u0111\\u0129"))          // đĩ
    }

    @Test fun name_rules_use_the_filter() {
        assertNotNull(NameRules.validate("Địt mẹ mày"))
        assertNotNull(NameRules.validate("f.u.c.k"))
        assertNull(NameRules.validate("Nguyễn Văn An"))
        assertNull(NameRules.validate("Cún Tí"))
        assertNotNull(NameRules.validate("A"))                         // luật độ dài cũ vẫn chạy
    }
}
'''
open('NameFilterTest.kt', 'w', encoding='utf-8').write(TEST.replace('@@GOOD@@', kt_arr(D.OK)).replace('@@BAD@@', kt_arr(D.BAD)))

# ------------------------------------------------------------------ SQL
def pg_arr(items):
    return 'array[' + ', '.join("'" + i.replace("'", "''") + "'" for i in items) + ']'

vi_from = 'àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ'
vi_to = ''
import unicodedata
for ch in vi_from:
    b = ''.join(c for c in unicodedata.normalize('NFD', ch) if unicodedata.category(c) != 'Mn')
    vi_to += 'd' if ch == 'đ' else b
cy_from, cy_to = '\u0430\u0435\u043E\u0440\u0441\u0445\u0443\u0456', 'aeopcxyi'
assert len(vi_from) == len(vi_to), (len(vi_from), len(vi_to))
assert all(c.isascii() and c.isalpha() for c in vi_to), vi_to
FROM, TO = vi_from + vi_from.upper() + cy_from, vi_to + vi_to + cy_to   # thêm chữ hoa phòng khi DB dùng locale C (lower() không hạ chữ có dấu)
assert len(FROM) == len(TO)

SQL = f'''-- Bộ lọc tên bậy cho cột public.users.display_name (lớp phòng thủ phía server).
-- Ứng dụng đã chặn ở phía máy (NameFilter.kt); file này để người sửa app / gọi thẳng API vẫn không đặt được tên bậy.
-- Thuật toán và danh sách GIỐNG NameFilter.kt (sinh từ cùng một danh sách). Khác biệt nhỏ: server KHÔNG ghép chữ cái lẻ
-- ("s h i t") và chỉ tách từ theo dấu ASCII, nên server dễ tính hơn một chút so với app — không bao giờ khắt khe hơn.
--
-- Cách chạy: Supabase > SQL Editor > dán toàn bộ file > Run (chạy lại nhiều lần vẫn an toàn). Cần PostgreSQL 13+ (normalize()).
-- Hành vi: tên bậy KHÔNG làm lỗi lệnh ghi (để việc đồng bộ Elo/ván cờ vẫn chạy) mà bị thay bằng 'Người chơi'.

-- 1) Bỏ dấu tiếng Việt + đổi chữ Kirin giống Latin (cùng số ký tự 2 vế, đã kiểm khi sinh file).
create or replace function public.vila_fold_vi(s text)
returns text language sql immutable as $fn$
  select translate(s, '{FROM}', '{TO}')
$fn$;

-- 2) Hàm kiểm tra.
create or replace function public.vila_is_offensive_name(raw text)
returns boolean language plpgsql immutable as $fn$
declare
  bad_tokens  constant text[] := {pg_arr(TOKENS)};
  phrases     constant text[] := {pg_arr(PHRASES)};
  strongs     constant text[] := {pg_arr(STRONG)};
  orig_bad    constant text[] := {pg_arr(ORIGINAL_BAD)};
  allow_words constant text[] := {pg_arr(ALLOW)};
  -- dấu tách từ: sep_a coi @ $ ! là dấu tách; sep_b coi chúng là chữ (kiểu viết lách)
  sep_a constant text := '[\\s.\\-_,;:!?@$#*+=~^/\\\\|(){{}}<>"''`&%\\[\\]]+';
  sep_b constant text := '[\\s.\\-_,;:?#*+=~^/\\\\|(){{}}<>"''`&%\\[\\]]+';
  lowered text; toks_o text[]; t text; x text; v text; p text; s text; compact text; toks text[];
  m int; k int;
begin
  if raw is null then return false; end if;
  lowered := lower(normalize(regexp_replace(raw, '[\\u200B-\\u200D\\u2060\\uFEFF\\u00AD]', '', 'g'), NFKC));
  if regexp_split_to_array(lowered, sep_a) && orig_bad then return true; end if;
  for m in 0..1 loop
    toks_o := regexp_split_to_array(lowered, case when m = 0 then sep_a else sep_b end);
    x := ' ';
    foreach t in array toks_o loop
      if t = '' then continue; end if;
      if t = any(allow_words) then
        x := x || '# ';
      else
        x := x || translate(public.vila_fold_vi(t), '013457$!@', 'oieastsia') || ' ';
      end if;
    end loop;
    for k in 0..2 loop            -- 0: nguyên văn, 1: gom chuỗi lặp 3+ về 1 ký tự, 2: về 2 ký tự
      v := case k
             when 0 then x
             when 1 then regexp_replace(x, '(.)\\1{{2,}}', '\\1', 'g')
             else regexp_replace(x, '(.)\\1{{2,}}', '\\1\\1', 'g')
           end;
      toks := string_to_array(btrim(v), ' ');
      if toks && bad_tokens then return true; end if;
      foreach p in array phrases loop
        if strpos(v, ' ' || p || ' ') > 0 then return true; end if;
      end loop;
      compact := regexp_replace(v, '[^a-z]', '', 'g');
      foreach s in array strongs loop
        if strpos(compact, s) > 0 then return true; end if;
      end loop;
    end loop;
  end loop;
  return false;
end
$fn$;

-- 3) Trigger: tên bậy -> 'Người chơi' (cả khi thêm mới lẫn khi sửa tên).
create or replace function public.vila_name_guard()
returns trigger language plpgsql as $fn$
begin
  if new.display_name is not null and public.vila_is_offensive_name(new.display_name) then
    new.display_name := 'Người chơi';
  end if;
  return new;
end
$fn$;

drop trigger if exists vila_name_guard on public.users;
create trigger vila_name_guard
  before insert or update of display_name on public.users
  for each row execute function public.vila_name_guard();

-- 4) (Tùy chọn) Dọn các tên bậy đã có sẵn. Bỏ dấu "--" đầu dòng rồi chạy:
-- update public.users set display_name = 'Người chơi' where public.vila_is_offensive_name(display_name);

-- 5) Tự kiểm tra (chạy riêng, kết quả mong đợi ghi bên phải):
-- select public.vila_is_offensive_name('Địt mẹ mày');   -- true
-- select public.vila_is_offensive_name('f u c k');      -- true
-- select public.vila_is_offensive_name('D1t me');       -- true
-- select public.vila_is_offensive_name('Cún Tí');       -- false
-- select public.vila_is_offensive_name('Bưởi');         -- false
-- select public.vila_is_offensive_name('Takeshita');    -- false
-- select public.vila_is_offensive_name('Nguyễn Văn An');-- false
'''
open('name_filter.sql', 'w', encoding='utf-8').write(SQL)
print('generated', len(KT), len(TEST), len(SQL))
