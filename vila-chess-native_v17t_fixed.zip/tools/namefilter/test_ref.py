# -*- coding: utf-8 -*-
from ref import is_offensive
OK = """Nguyễn Văn An|Trần Thị Hoa|Lê Quang Huy|Phạm Minh Đức|Hoàng Anh|Bùi Thị Cúc|Đặng Thu Hà|Võ Thành Long|Ngô Bảo Châu|
Đinh Công Tráng|Mạc Đăng Dung|Dũ Mạnh|Cún Tí|Cún Tin|Bưởi|Bé Bưởi|Buổi Sáng|Ngư|Lê Ngư|Anh Lớn|Hà Lan|Lân|Lộc|Cát Tường|
Đăng Khoa|Duy Tân|Thành Đạt|Điểm|Điềm|Dung|Dư|Dũ|Du|Mã Đức|Ma Văn Cường|Cao Văn Lộc|Đỗ Cao Lâm|Cự Lân|Tạ Thị Cẩm|Các Mác|
Nguyen Van An|Tran Thi Hoa|Pham Minh Duc|Bui Thi Cuc|Du Manh|Cun Ti|Dinh Cong|Dat|Diet|Dieu|Thu Thuy|Lan Huong|
Takeshita|Nishitani|Ishitani|Hancock|Dickson|Dickens|Scunthorpe|Cummings|Pornchai|Pussadee|Sextus|Assad|Classic|Assassin|Bassett|
Cassie|Massimo|Hitchcock|Magnus Carlsen|Hikaru|Fabiano|Kasparov|Niger|Nigeria|Nigel|Therapist|Shiitake|Pedro|Cumin|Titus|Fagan|Spicy|
Kike|Van Dyke|Coon|Player123|Pro2024|ChessKing|Vua Co|KingOfChess|Hà Nội|Sài Gòn|D. M. Tran|J K Rowling|Anna|Hannah|Cassandra|Peacock|Cocktail|Lonely|London|
Colon|Salon|Callon|Dittmar|Edith|Mom|DM Chess|Tom|Dm|Cho|Chợ|Con|Mẹ|May|Mày|Thằng|Ngu Nguyen|Nguyen|Ngụy|Đỗ|Do|Đô|Lê Đình Dit""".replace('\n','').split('|')
# hai mục cuối cố ý đặt để xem hành vi: "DM Chess","Dm","Lê Đình Dit" -> ghi lại, không assert
SOFT = {'DM Chess','Dm','Lê Đình Dit'}
BAD = """Địt mẹ mày|ditme|D1t me|d i t m e|đ.m|dmm|vcl|Lồn|l0n|cặc|Buồi|buoi|fuck|fuuuck|F U C K|f_u_c_k|Sh1t|$hit|b!tch|N1gger|nigga|ass|A$$|Hitler|Heil Hitl3r|
pussy|xXfuckXx|Con Chó|Thằng Ngu|Đồ Ngu|đĩ|Đéo|ĐỤ MÁ|sex|porn|Ｆｕｃｋ|fuсk|fu​ck|Dit.Me|d.m.m|Đ.M.M|ĐỊT|cunt|c u n t|DiTmE|dit_me|vkl|VCL|Lon|Cac|Concac|Con Cac|
Đồ Súc Vật|suc vat|Khốn Nạn|fuckyou|Motherfucker|n1gga|wh0re|Bi7ch|4ss|Dick|Cock|slut|5lut|shiiit|ditttt me|d1tm3|dcm|DKM|D M|V.C.L|v c l|Ｄｉｔ ｍｅ|đéo|Đĩ|điếm""".replace('\n','').split('|')
fp = [n for n in OK if is_offensive(n) and n not in SOFT]
fn = [n for n in BAD if not is_offensive(n)]
print('FALSE POSITIVES:', fp)
print('MISSED:', fn)
print('soft:', {n: is_offensive(n) for n in SOFT})
print(len(OK), 'ok names,', len(BAD), 'bad names')
