# v17k — Giao diện màn giải đố kiểu chess.com

- Sửa test `SocialFeaturesTest.recycleGivesSwapManaAndHasNoPerTurnLimit` cho khớp luật mana v17d (+2 mana, tối đa 20, không giới hạn lá/lượt).
- PuzzleSolveScreen.kt (dùng chung cho màn Câu đố và Bài học chiến thuật):
  - Thanh thông tin trên bàn cờ: ô màu bên đi, mục tiêu, bên đi trước, đồng hồ giải đố và số lần sai.
  - Bàn cờ rộng hết chiều ngang màn hình.
  - Thanh phản hồi dưới bàn cờ đổi màu: "Đến lượt …" (xám), "Chính xác!" (xanh), "Không phải nước đó" (đỏ), "Câu đố đã được giải!" (xanh đậm).
  - Thanh nút cố định ở đáy: "Gợi ý" khi đang giải, đổi thành nút xanh "Tiếp tục" khi giải xong (dữ liệu lỗi thì "Bỏ qua").
  - Thanh tiêu đề: chip "Độ khó".
  - Chạm quân sau khi đi sai sẽ tự trả thanh phản hồi về "Đến lượt …".
