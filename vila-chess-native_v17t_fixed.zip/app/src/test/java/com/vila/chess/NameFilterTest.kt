package com.vila.chess

import com.vila.chess.profile.NameFilter
import com.vila.chess.profile.NameRules
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NameFilterTest {
    /** Tên thật (có dấu / không dấu, tên Nhật, Anh, biệt danh) KHÔNG được bị chặn. */
    private val good = listOf(
        "Nguyễn Văn An",
        "Trần Thị Hoa",
        "Lê Quang Huy",
        "Phạm Minh Đức",
        "Hoàng Anh",
        "Bùi Thị Cúc",
        "Đặng Thu Hà",
        "Võ Thành Long",
        "Ngô Bảo Châu",
        "Đinh Công Tráng",
        "Mạc Đăng Dung",
        "Dũ Mạnh",
        "Cún Tí",
        "Cún Tin",
        "Bưởi",
        "Bé Bưởi",
        "Buổi Sáng",
        "Ngư",
        "Lê Ngư",
        "Anh Lớn",
        "Hà Lan",
        "Lân",
        "Lộc",
        "Cát Tường",
        "Đăng Khoa",
        "Duy Tân",
        "Thành Đạt",
        "Điểm",
        "Điềm",
        "Dung",
        "Dư",
        "Dũ",
        "Du",
        "Mã Đức",
        "Ma Văn Cường",
        "Cao Văn Lộc",
        "Đỗ Cao Lâm",
        "Cự Lân",
        "Tạ Thị Cẩm",
        "Các Mác",
        "Nguyen Van An",
        "Tran Thi Hoa",
        "Pham Minh Duc",
        "Bui Thi Cuc",
        "Du Manh",
        "Cun Ti",
        "Dinh Cong",
        "Dat",
        "Diet",
        "Dieu",
        "Thu Thuy",
        "Lan Huong",
        "Takeshita",
        "Nishitani",
        "Ishitani",
        "Hancock",
        "Dickson",
        "Dickens",
        "Scunthorpe",
        "Cummings",
        "Pornchai",
        "Pussadee",
        "Sextus",
        "Assad",
        "Classic",
        "Assassin",
        "Bassett",
        "Cassie",
        "Massimo",
        "Hitchcock",
        "Magnus Carlsen",
        "Hikaru",
        "Fabiano",
        "Kasparov",
        "Niger",
        "Nigeria",
        "Nigel",
        "Therapist",
        "Shiitake",
        "Pedro",
        "Cumin",
        "Titus",
        "Fagan",
        "Spicy",
        "Kike",
        "Van Dyke",
        "Coon",
        "Player123",
        "Pro2024",
        "ChessKing",
        "Vua Co",
        "KingOfChess",
        "Hà Nội",
        "Sài Gòn",
        "D. M. Tran",
        "J K Rowling",
        "Anna",
        "Hannah",
        "Cassandra",
        "Peacock",
        "Cocktail",
        "Lonely",
        "London",
        "Colon",
        "Salon",
        "Callon",
        "Dittmar",
        "Edith",
        "Mom",
        "DM Chess",
        "Tom",
        "Dm",
        "Cho",
        "Chợ",
        "Con",
        "Mẹ",
        "May",
        "Mày",
        "Thằng",
        "Ngu Nguyen",
        "Nguyen",
        "Ngụy",
        "Đỗ",
        "Do",
        "Đô",
        "Lê Đình Dit"
    )

    /** Tên bậy và các kiểu né lọc: phải bị chặn. */
    private val bad = listOf(
        "Địt mẹ mày",
        "ditme",
        "D1t me",
        "d i t m e",
        "đ.m",
        "dmm",
        "vcl",
        "Lồn",
        "l0n",
        "cặc",
        "Buồi",
        "buoi",
        "fuck",
        "fuuuck",
        "F U C K",
        "f_u_c_k",
        "Sh1t",
        "\$hit",
        "b!tch",
        "N1gger",
        "nigga",
        "ass",
        "A\$\$",
        "Hitler",
        "Heil Hitl3r",
        "pussy",
        "xXfuckXx",
        "Con Chó",
        "Thằng Ngu",
        "Đồ Ngu",
        "đĩ",
        "Đéo",
        "ĐỤ MÁ",
        "sex",
        "porn",
        "Ｆｕｃｋ",
        "fu\u0441k",
        "fu\u200Bck",
        "Dit.Me",
        "d.m.m",
        "Đ.M.M",
        "ĐỊT",
        "cunt",
        "c u n t",
        "DiTmE",
        "dit_me",
        "vkl",
        "VCL",
        "Lon",
        "Cac",
        "Concac",
        "Con Cac",
        "Đồ Súc Vật",
        "suc vat",
        "Khốn Nạn",
        "fuckyou",
        "Motherfucker",
        "n1gga",
        "wh0re",
        "Bi7ch",
        "4ss",
        "Dick",
        "Cock",
        "slut",
        "5lut",
        "shiiit",
        "ditttt me",
        "d1tm3",
        "dcm",
        "DKM",
        "D M",
        "V.C.L",
        "v c l",
        "Ｄｉｔ ｍｅ",
        "đéo",
        "Đĩ",
        "điếm"
    )

    @Test fun real_names_are_not_blocked() {
        val wrong = good.filter { NameFilter.isOffensive(it) }
        assertTrue("Chặn nhầm: $wrong", wrong.isEmpty())
    }

    @Test fun offensive_names_are_blocked() {
        val missed = bad.filterNot { NameFilter.isOffensive(it) }
        assertTrue("Lọt: $missed", missed.isEmpty())
    }

    @Test fun invisible_and_fullwidth_tricks() {
        assertTrue(NameFilter.isOffensive("fu\u200Bck"))
        assertTrue(NameFilter.isOffensive("\uFF26\uFF55\uFF43\uFF4B"))
        assertTrue(NameFilter.isOffensive("fu\u0441k"))
    }

    @Test fun accent_sensitive_words() {
        assertFalse(NameFilter.isOffensive("B\u01B0\u1EDFi"))        // Bưởi
        assertFalse(NameFilter.isOffensive("Ng\u01B0"))              // Ngư
        assertTrue(NameFilter.isOffensive("\u0111\u00E9o"))         // đéo
        assertTrue(NameFilter.isOffensive("\u0111\u0129"))          // đĩ
    }

    @Test fun name_rules_use_the_filter() {
        assertNotNull(NameRules.validate("Địt mẹ mày"))
        assertNotNull(NameRules.validate("f.u.c.k"))
        assertNull(NameRules.validate("Nguyễn Văn An"))
        assertNull(NameRules.validate("Cún Tí"))
        assertNotNull(NameRules.validate("A"))                         // luật độ dài cũ vẫn chạy
    }
}
