package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.profile.AvatarPhotos
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.NameRules
import com.vila.chess.profile.UserSessionManager
import kotlinx.coroutines.delay

// =============================================================================
// Màn "Hoàn thiện hồ sơ" ngay sau khi đăng nhập (giống chess.com): chọn ảnh đại diện + nhập tên hiển thị.
//
//   • Hiện một lần cho mỗi tài khoản mới (UserSessionManager.profileSetupDone = false); chưa đặt tên/ảnh thì mới hiện.
//   • Ảnh: chạm vòng avatar lớn → thư viện → màn cắt ảnh có sẵn (rememberAvatarPicker). Hoặc chọn 1 trong 6 hình dựng sẵn.
//   • Tên: điền sẵn tên tài khoản (Google / email), kiểm bằng NameRules (độ dài + bộ lọc tên bậy) như form Đổi tên.
//   • "Tiếp tục" lưu hồ sơ (UserSessionManager.updateProfile → tự đồng bộ cloud); "Bỏ qua" giữ tên tài khoản, đổi sau trong Hồ sơ.
//   • Mượt: các khối hiện lần lượt (mờ + trượt lên), avatar nảy khi đổi ảnh, cả màn mờ dần khi xong rồi mới sang màn kế.
// =============================================================================

@Composable
fun ProfileSetupScreen(onDone: () -> Unit = {}) {
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current

    // Điền sẵn tên tài khoản; "Người chơi" là tên mặc định nên để trống cho người dùng tự gõ.
    var name by remember { mutableStateOf(UserSessionManager.displayName.takeIf { it != "Người chơi" }.orEmpty().take(NameRules.MAX)) }
    var touched by remember { mutableStateOf(false) }
    var avatar by remember { mutableStateOf("") }
    var tempPhoto by remember { mutableStateOf<String?>(null) }   // ảnh vừa cắt trong phiên này, chưa lưu
    var saved by remember { mutableStateOf(false) }
    var finishing by remember { mutableStateOf(false) }
    var serverError by remember { mutableStateOf<String?>(null) }

    // Thoát màn mà không lưu → xoá ảnh tạm cho nhẹ máy.
    DisposableEffect(Unit) { onDispose { if (!saved) tempPhoto?.let { AvatarPhotos.delete(ctx, it) } } }

    val pickPhoto = rememberAvatarPicker { key ->
        tempPhoto?.let { AvatarPhotos.delete(ctx, it) }
        tempPhoto = key
        avatar = key
    }
    fun choosePreset(key: String) {
        tempPhoto?.let { AvatarPhotos.delete(ctx, it) }
        tempPhoto = null
        avatar = key
    }

    val validation = NameRules.validate(name)
    val shownError = serverError ?: if (touched) validation else null
    val canGo = validation == null && !finishing

    fun finish(save: Boolean) {
        if (finishing) return
        if (save) {
            val err = UserSessionManager.updateProfile(ctx, name, UserSessionManager.countryCode, avatar)
            if (err != null) {
                serverError = err
                Toast.makeText(ctx, err, Toast.LENGTH_SHORT).show()
                return
            }
            saved = true
        }
        focus.clearFocus()
        finishing = true
    }
    LaunchedEffect(finishing) {
        if (finishing) {
            delay(240)   // chờ màn mờ dần xong rồi mới đổi màn
            UserSessionManager.completeProfileSetup(ctx)
            onDone()
        }
    }
    val exit = animateFloatAsState(if (finishing) 0f else 1f, tween(220), label = "setupExit")

    // Avatar nảy nhẹ mỗi khi đổi ảnh / hình.
    val pop = remember { Animatable(1f) }
    LaunchedEffect(avatar) {
        if (avatar.isNotEmpty()) {
            pop.snapTo(0.82f)
            pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(VilaColors.Bg)
            .graphicsLayer { alpha = exit.value },
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Reveal(0) {
                Text("Hoàn thiện hồ sơ", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Thêm ảnh và chọn tên để bạn bè nhận ra bạn. Có thể đổi bất cứ lúc nào trong Hồ sơ.",
                    color = VilaColors.TextDim, fontSize = 14.sp, lineHeight = 19.sp, textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(28.dp))

            Reveal(1) {
                Box(
                    Modifier
                        .size(136.dp)
                        .graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                        .clip(CircleShape)
                        .clickable { pickPhoto() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedAvatarFrame(seed = 0, ringShape = CircleShape) {
                        ProfileAvatar(name = name.ifBlank { "?" }, avatarKey = avatar, size = 128.dp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Reveal(2) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(VilaColors.Panel)
                        .border(1.dp, VilaColors.GlassBorder, RoundedCornerShape(50))
                        .clickable { pickPhoto() }
                        .padding(horizontal = 16.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Filled.CameraAlt, contentDescription = null, tint = VilaColors.Green, modifier = Modifier.size(18.dp))
                    Text(
                        if (AvatarPhotos.isPhoto(avatar)) "Đổi ảnh" else "Thêm ảnh từ thư viện",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
                Spacer(Modifier.height(18.dp))
                Text("Hoặc chọn một hình", color = VilaColors.TextDim, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (p in Avatars.presets) {
                        val chosen = avatar == p.key
                        Box(
                            Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .border(if (chosen) 3.dp else 0.dp, if (chosen) VilaColors.Green else Color.Transparent, CircleShape)
                                .clickable { choosePreset(p.key) },
                            contentAlignment = Alignment.Center,
                        ) {
                            ProfileAvatar(name = name, avatarKey = p.key, size = 40.dp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(28.dp))

            Reveal(3) {
                Column(Modifier.fillMaxWidth()) {
                    Text("Tên hiển thị", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    TextField(
                        value = name,
                        onValueChange = { v ->
                            name = v.take(NameRules.MAX)
                            serverError = null
                        },
                        singleLine = true,
                        placeholder = { Text("Ví dụ: Minh Anh", color = Color(0xFF8B8987)) },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { touched = true; if (canGo) finish(true) }),
                        shape = RoundedCornerShape(10.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF3C3A37), unfocusedContainerColor = Color(0xFF3C3A37),
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            cursorColor = VilaColors.Green,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .onFocusChanged { if (it.isFocused) touched = true },
                    )
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            shownError ?: "",
                            color = Color(0xFFFF8A80), fontSize = 13.sp,
                            modifier = Modifier.weight(1f),
                        )
                        Text("${name.trim().length}/${NameRules.MAX}", color = VilaColors.TextDim, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))

            Reveal(4) {
                val shape = RoundedCornerShape(10.dp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer { alpha = if (canGo) 1f else 0.45f }
                        .pressable(enabled = canGo) { finish(true) }
                        .clip(shape)
                        .background(VilaColors.GreenShadow)
                        .padding(bottom = 4.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .clip(shape)
                            .background(VilaColors.Green),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("Tiếp tục", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Bỏ qua",
                    color = VilaColors.TextDim, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(enabled = !finishing) { finish(false) }.padding(horizontal = 16.dp, vertical = 10.dp),
                )
            }
        }
    }
}

/** Khối hiện dần (mờ + trượt lên 24dp), mỗi khối trễ thêm 90ms so với khối trước. */
@Composable
private fun Reveal(index: Int, content: @Composable ColumnScope.() -> Unit) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(90L * index)
        p.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
    }
    Column(
        modifier = Modifier.graphicsLayer {
            alpha = p.value
            translationY = (1f - p.value) * 24.dp.toPx()
        },
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content,
    )
}
