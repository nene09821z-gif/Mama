package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.rememberTier
import com.vila.chess.game.RatingMode
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.TimeControls
import com.vila.chess.game.modeFor
import com.vila.chess.online.ChatKind
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.toEloMode

private enum class OnlineConfirm { LEAVE, RESIGN, DRAW }

/**
 * Màn chơi ONLINE (người thật). Riêng biệt với BotGameScreen: không Gợi ý / Hoàn tác / Thanh đánh giá, không engine.
 * Dùng chung GameViewModel + BoardView (kéo thả, premove, hiệu ứng); đồng hồ và nước đi của đối thủ do máy chủ đẩy về.
 */
@Composable
fun OnlineGameScreen(vm: GameViewModel) {
    val ui = vm.ui
    val online = vm.online
    val images = vm.pieceImages
    var confirm by remember { mutableStateOf<OnlineConfirm?>(null) }
    var showResult by remember(ui.over) { mutableStateOf(ui.over) }
    var showOpponent by remember { mutableStateOf(false) }
    var chatOpen by remember { mutableStateOf(false) }
    val gameId = vm.onlineGameId
    val chat = rememberChat(gameId, ChatKind.CHESS, chatOpen)

    // Đang chơi: thoát = xử thua (hỏi lại). Hết ván: về menu thẳng. Đang mở chat: đóng chat trước.
    BackHandler {
        if (chatOpen) chatOpen = false
        else if (ui.over) vm.backToHome()
        else confirm = OnlineConfirm.LEAVE
    }

    val topIsWhite = ui.flipped
    val oppId = online.opponentId
    val oppName = online.opponentName.ifBlank { "Đối thủ" }
    val timeMode = modeFor(TimeControls.get(vm.onlineTimeIndex))

    @Composable
    fun Side(white: Boolean) {
        if (white != ui.humanWhite) {
            PlayerBar(
                vm, ui, images, white,
                name = oppName,
                subtitle = "Online",
                tier = online.opponentTier,
                onProfileClick = if (oppId != null) ({ showOpponent = true }) else null,
            )
        } else {
            PlayerBar(vm, ui, images, white, name = "Bạn", tier = rememberTier())
        }
    }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().background(GameScrim).systemBarsPadding()) {
        GameTopBar(sans = ui.sans, onBack = { if (ui.over) vm.backToHome() else confirm = OnlineConfirm.LEAVE })
        if (online.connectionLost && !ui.over) {
            Box(
                Modifier.fillMaxWidth().background(Color(0xFF6B3F12)).padding(vertical = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Mất kết nối — đang thử lại…", color = Color(0xFFFFC27A), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.weight(1f))
        Side(topIsWhite)
        androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth()) {
            ChessBoard(vm, ui)
            // Thẻ "VS" đầu ván (không chặn cảm ứng, tự tắt sau ~3 giây hoặc khi có nước đi đầu tiên)
            OnlineVsIntro(
                vm = vm,
                ui = ui,
                oppId = oppId,
                oppName = oppName,
                oppTier = online.opponentTier,
                mode = timeMode.toEloMode() ?: EloMode.RAPID,
                modifier = Modifier.matchParentSize(),
            )
        }
        Side(!topIsWhite)

        Spacer(Modifier.weight(1.3f))

        GameToolbar {
            if (ui.over) {
                ToolbarButton("Tìm trận mới", true, { vm.rematch() }) { ToolbarIcon(ToolIcon.REFRESH) }
            } else {
                ToolbarButton("Cầu hòa", ui.sans.size >= 2 && !online.drawOfferedByMe, { confirm = OnlineConfirm.DRAW }) { ToolbarIcon(ToolIcon.DRAW) }
            }
            ToolbarButton("Chat", gameId != null, { chatOpen = true }) {
                Box {
                    ToolbarIcon(ToolIcon.CHAT)
                    val unread = chat.unread
                    if (unread > 0) {
                        Box(
                            Modifier.align(Alignment.TopEnd).size(15.dp).clip(CircleShape).background(VilaColors.Danger),
                            contentAlignment = Alignment.Center,
                        ) { Text(if (unread > 9) "9+" else "$unread", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
                    }
                }
            }
            ToolbarButton("Đầu hàng", !ui.over, { confirm = OnlineConfirm.RESIGN }) { ToolbarIcon(ToolIcon.FLAG) }
        }
    }
    if (chatOpen && gameId != null) {
        ChatPanel(chat, gameId, ChatKind.CHESS, oppName) { chatOpen = false }
    }
    }

    if (ui.promotion != null) PromotionDialog(vm = vm, images = images, humanWhite = ui.humanWhite)

    // Hộp xác nhận
    val c = confirm
    if (c != null) {
        val text = when (c) {
            OnlineConfirm.LEAVE -> if (ui.sans.size < 2) "Thoát ván? Ván sẽ bị hủy (chưa tính thắng/thua)." else "Thoát ván online? Bạn sẽ bị xử thua."
            OnlineConfirm.RESIGN -> if (ui.sans.size < 2) "Hủy ván này? (chưa tính thắng/thua)" else "Bạn muốn đầu hàng ván này?"
            OnlineConfirm.DRAW -> "Gửi lời cầu hòa cho đối thủ?"
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = VilaColors.Panel,
            title = { Text("Xác nhận", color = VilaColors.Text) },
            text = { Text(text, color = VilaColors.TextDim) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    when (c) {
                        OnlineConfirm.LEAVE -> vm.leaveOnlineGame()
                        OnlineConfirm.RESIGN -> vm.resign()
                        OnlineConfirm.DRAW -> vm.offerDraw()
                    }
                }) { Text("Đồng ý", color = VilaColors.Green) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Hủy", color = VilaColors.TextDim) } },
        )
    }

    // Đối thủ cầu hòa
    if (online.drawOfferedByOpponent && !ui.over) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = VilaColors.Panel,
            title = { Text("Đối thủ cầu hòa", color = VilaColors.Text) },
            text = { Text(oppName + " đề nghị hòa ván này. Bạn có đồng ý không?", color = VilaColors.TextDim, textAlign = TextAlign.Start) },
            confirmButton = { TextButton(onClick = { vm.acceptOnlineDraw() }) { Text("Đồng ý hòa", color = VilaColors.Green) } },
            dismissButton = { TextButton(onClick = { vm.declineOnlineDraw() }) { Text("Từ chối", color = VilaColors.TextDim) } },
        )
    }

    // Hồ sơ nhanh của đối thủ (chạm tên / avatar)
    if (showOpponent && oppId != null) {
        OpponentProfileSheet(
            userId = oppId,
            fallbackName = oppName,
            onDismiss = { showOpponent = false },
            onViewFull = { showOpponent = false },
            fallbackTier = online.opponentTier,
            mode = when (timeMode) {
                RatingMode.BULLET -> EloMode.BULLET
                RatingMode.BLITZ -> EloMode.BLITZ
                else -> EloMode.RAPID
            },
        )
    }

    if (ui.over && showResult) PostGameDialog(vm = vm, onDismiss = { showResult = false })
}
