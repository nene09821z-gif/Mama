# v17o — 5 bộ âm thanh nhẹ nhàng (thêm vào Chủ đề > Âm thanh)

## Mới
- 5 bộ x 6 tiếng = 30 file res/raw/<bộ>_<tiếng>.wav (44,1 kHz, 16-bit, mono, tự tổng hợp, không bản quyền, ~3,2 MB):
  marble (Cẩm thạch) · nature (Thiên nhiên) · space (Vũ trụ) · musicbox (Hộp nhạc) · zen (Tre & chuông gió).
  Tiếng: move / capture / castle / check / promote / end (đúng tên như 7 bộ cũ nên SoundPacks.rawRes tự tìm được).
- scripts/gen_sounds_chill.py : trình tạo 5 bộ trên (chạy lại cho đúng từng byte, seed cố định).
- scripts/gen_sounds_lib.py   : công cụ tổng hợp dùng chung (lọc, vang, chuông FM, gió, nền ngân, chuẩn hoá, ghi WAV).
  gen_sounds_chill.py gốc import `gen_sounds_anime` nhưng file đó không có trong dự án => đổi thành import gen_sounds_lib.

## Sửa
- game/SoundPacks.kt : thêm 5 dòng SoundPackInfo vào [all], xếp ngay sau "Giọt nước" (bộ cũ giữ nguyên thứ tự).
- Không cần sửa giao diện: ui/ThemeScreen.kt (SoundTab) là LazyColumn đọc SoundPacks.all, khoảng cách giữa các ô (10dp),
  đệm mỗi ô (16dp ngang / 12dp dọc), viền xanh + dấu tích khi chọn đều dùng chung một mẫu ô nên 12 ô xếp đều nhau.
  Mô tả mỗi bộ <= 40 ký tự để nằm gọn 1 dòng như các bộ cũ. Nghe thử khi chạm = tiếng đi quân rồi tiếng ăn quân (như cũ).
- app/src/test/.../AppearanceTest.kt : thêm test 5 bộ mới đã đăng ký + kiểm tra rawName (everySoundPackHasAllSixFiles sẵn có sẽ tự kiểm 30 file mới).

## Lưu ý
- Chưa chạy gradle/test trong môi trường này (không có mạng/SDK); đã kiểm 12 bộ x 6 file đều có mặt và đúng định dạng.
- Tiếng đi quân của vài bộ khá dài so với bộ cũ (Hộp nhạc ~0,7 s, Vũ trụ ~0,8 s, Thiên nhiên ~0,5 s) vì có vang; SoundPool cho 4 luồng nên đi nhanh vẫn không mất tiếng.
- Một số tiếng (Cẩm thạch ăn quân, Thiên nhiên ăn quân / hết ván) có thân tiếng trầm ~200-240 Hz; loa điện thoại phát yếu phần này, phần còn lại vẫn rõ.
- File nghe thử tất cả (scripts/chill_preview.wav ~5 MB) không đóng kèm; chạy `python3 scripts/gen_sounds_chill.py` sẽ tạo lại.
