#!/usr/bin/env python3
"""
Bộ công cụ tổng hợp âm thanh dùng chung cho gen_sounds_chill.py (không chạy riêng).

Cung cấp: SR, OUT, t_, dec, noise, lp, hp, place, reverb, fmbell, whoosh, pad, master, trim_silence, write_wav.
44,1 kHz / 16-bit / mono. Mọi nguồn ngẫu nhiên đều có seed cố định => chạy lại cho đúng từng byte như cũ.
Cần numpy.
"""
from pathlib import Path
import wave

import numpy as np

SR = 44100
OUT = Path(__file__).resolve().parent.parent / "app" / "src" / "main" / "res" / "raw"
RNG = np.random.default_rng(20261116)


# ───────────────────────────────────────────── cơ bản
def t_(dur):
    """Trục thời gian (giây) dài dur giây."""
    return np.arange(int(SR * dur)) / SR


def dec(t, tau):
    """Suy giảm mũ exp(-t/tau)."""
    return np.exp(-t / tau)


def noise(dur):
    """Nhiễu trắng dài dur giây."""
    return RNG.standard_normal(int(SR * dur))


def lp(x, fc, taps=257):
    """Lọc thông thấp FIR (sinc + cửa sổ Hamming), cùng độ dài đầu vào."""
    n = np.arange(taps) - (taps - 1) / 2
    h = np.sinc(2 * fc / SR * n) * np.hamming(taps)
    h = h / h.sum()
    if len(x) < taps:  # np.convolve "same" trả về max(len) => đệm để giữ đúng độ dài
        y = np.convolve(np.concatenate([x, np.zeros(taps - len(x))]), h, mode="same")
        return y[: len(x)]
    return np.convolve(x, h, mode="same")


def hp(x, fc):
    """Lọc thông cao = tín hiệu trừ phần thông thấp."""
    return x - lp(x, fc)


def place(total, parts):
    """Trộn các (thời điểm bắt đầu, tín hiệu, độ lớn) vào một dải dài total giây (phần dư bị cắt)."""
    out = np.zeros(int(SR * total))
    for start, sig, gain in parts:
        i = int(SR * start)
        j = min(len(out), i + len(sig))
        if j > i:
            out[i:j] += sig[: j - i] * gain
    return out


# ───────────────────────────────────────────── âm sắc
def fmbell(f, dur=0.5, tau=0.15, ratio=3.5, index=1.5):
    """Chuông FM: sóng mang f, sóng điều biến f*ratio; độ "sáng" (index) tắt nhanh hơn thân tiếng cho giống chuông thật."""
    t = t_(dur)
    mod = index * dec(t, tau * 0.6) * np.sin(2 * np.pi * f * ratio * t)
    s = np.sin(2 * np.pi * f * t + mod) * dec(t, tau)
    return s * np.minimum(1.0, t / 0.002)


def whoosh(dur, f0, f1, peak=0.5, q=0.4):
    """Tiếng gió vút: nhiễu dải quét theo log từ f0 đến f1 Hz.
    peak = vị trí đỉnh to nhất (0..1 của độ dài), q = độ rộng dải (độ lệch chuẩn theo ln tần số)."""
    t = t_(dur)
    u = t / dur
    fc = f0 * (f1 / f0) ** u
    n = noise(dur)
    lo_f, hi_f = min(f0, f1), max(f0, f1)
    centers = np.geomspace(lo_f / 1.3, hi_f * 1.3, 14)
    out = np.zeros_like(t)
    for c in centers:
        band = lp(n, min(c * 1.25, SR * 0.45)) - lp(n, c / 1.25)
        out += band * np.exp(-0.5 * (np.log(fc / c) / q) ** 2)
    peak = min(max(peak, 0.05), 0.95)
    env = np.where(u < peak, np.sin(0.5 * np.pi * u / peak), np.cos(0.5 * np.pi * (u - peak) / (1 - peak))) ** 1.5
    out = out * env
    return out / (np.max(np.abs(out)) + 1e-9)


def pad(f, dur=1.0):
    """Nền ngân mềm: 3 sóng sin lệch nhẹ + 1 quãng tám dưới rất khẽ, vào chậm ra chậm."""
    t = t_(dur)
    s = sum(a * np.sin(2 * np.pi * f * r * t + p) for r, a, p in ((1.0, 1.0, 0.0), (1.004, 0.7, 1.3), (0.996, 0.7, 2.1), (0.5, 0.25, 0.6)))
    env = np.clip(np.minimum(t / (0.3 * dur), (dur - t) / (0.45 * dur)), 0.0, 1.0) ** 1.5
    s = lp(s * env, 3000)
    return s / (np.max(np.abs(s)) + 1e-9)


def reverb(x, room=0.15, wet=0.3):
    """Vang: nhân chập với đáp ứng xung nhiễu suy giảm mũ (hằng số room giây, dài 4*room), tối đi ở 5,5 kHz.
    wet = mức vang so với tiếng gốc (0.15 ~ -16 dB, 0.5 ~ -6 dB). Đuôi vang kéo dài thêm vào cuối tín hiệu."""
    n = int(SR * room * 4)
    rng = np.random.default_rng(int(room * 1000) + 1)  # mỗi cỡ phòng một đáp ứng cố định, không phụ thuộc thứ tự gọi
    tt = np.arange(n) / SR
    ir = lp(rng.standard_normal(n) * np.exp(-tt / room), 5500)
    ir = np.concatenate([np.zeros(int(SR * 0.008)), ir])  # trễ sớm 8 ms để giữ cú gõ đầu còn nét
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-12
    total = len(x) + len(ir) - 1
    nfft = 1 << (total - 1).bit_length()
    y = np.fft.irfft(np.fft.rfft(x, nfft) * np.fft.rfft(ir, nfft), nfft)[:total]
    out = np.concatenate([x, np.zeros(len(ir) - 1)])
    return out + wet * y


# ───────────────────────────────────────────── hoàn thiện + ghi file
def trim_silence(x, thr=0.004, tail_ms=8.0):
    """Cắt phần lặng đầu và cuối (dưới thr so với đỉnh, ~ -48 dB), chừa 1 ms đầu và tail_ms cuối."""
    a = np.abs(np.nan_to_num(x))
    m = a.max()
    if m <= 0:
        return x
    idx = np.where(a > thr * m)[0]
    i = max(0, int(idx[0]) - int(SR * 0.001))
    j = min(len(x), int(idx[-1]) + int(SR * tail_ms / 1000))
    return x[i:j]


def master(x, peak=0.8):
    """Bỏ lệch DC, chuẩn hoá đỉnh về peak, vào 1 ms và ra tối đa 30 ms cho khỏi lách tách."""
    x = np.nan_to_num(x)
    x = x - np.mean(x)
    y = x / (np.max(np.abs(x)) + 1e-12) * peak
    n_in = min(int(SR * 0.001), len(y) // 4)
    n_out = min(int(SR * 0.030), len(y) // 2)
    if n_in > 0:
        y[:n_in] *= np.linspace(0, 1, n_in)
    if n_out > 0:
        y[-n_out:] *= np.linspace(1, 0, n_out) ** 2
    return y


def write_wav(path, y):
    """Ghi WAV mono 16-bit tại SR."""
    pcm = (np.clip(np.nan_to_num(y), -1, 1) * 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
