#!/usr/bin/env python3
"""
5 bộ âm thanh NHẸ NHÀNG cho ViLa Chess (kiểu các chủ đề âm thanh của chess.com), mỗi bộ 6 tiếng, tự tổng hợp, không bản quyền:
  marble   (Cẩm thạch)      đá lạnh trong trẻo, rõ mà không chói
  nature   (Thiên nhiên)    gõ gỗ + lá xào xạc + chim hót + gió nhẹ
  space    (Vũ trụ)         ping sin mềm có vang dội, trôi giữa các vì sao
  musicbox (Hộp nhạc)       nốt hộp nhạc lanh canh, bài ru khi hết ván
  zen      (Tre & chuông gió)  gõ tre khẽ + chuông gió ngân dài

Ghi vào app/src/main/res/raw/<bộ>_<tiếng>.wav (44,1 kHz, 16-bit, mono) + scripts/chill_preview.wav (nghe thử tất cả).

  python3 scripts/gen_sounds_chill.py

Nguyên tắc chung: vào âm mềm, cắt chói, thân tiếng từ ~300 Hz trở lên (loa điện thoại không phát được dưới đó),
cao độ lấy từ âm giai ngũ cung trưởng (C D E G A) nên các tiếng nối nhau luôn hòa; tiếng đi quân ngắn và nhỏ hơn tiếng sự kiện.
Cần numpy. Dùng công cụ trong gen_sounds_lib.py (để cùng thư mục scripts/). Kết quả ổn định (seed cố định).
"""
from pathlib import Path
import numpy as np

import gen_sounds_lib as A

SR = A.SR
OUT = A.OUT
PREVIEW = Path(__file__).resolve().parent / "chill_preview.wav"
t_, dec, noise, lp, hp, place, reverb = A.t_, A.dec, A.noise, A.lp, A.hp, A.place, A.reverb
RNG = np.random.default_rng(20261116)


def pent(i):
    """Nốt thứ i của ngũ cung trưởng C D E G A (i=0 -> C5 523 Hz, 5 -> C6, -5 -> C4)."""
    return 523.25 * 2 ** ((12 * (i // 5) + (0, 2, 4, 7, 9)[i % 5]) / 12)


def echo(x, delay, fb, n, damp=3500):
    out = np.concatenate([x, np.zeros(int(SR * delay * n))])
    w = lp(x, damp)
    for k in range(1, n + 1):
        d = int(SR * delay * k)
        out[d:d + len(x)] += w * (fb ** k)
    return out


def soft_thud(f=240, dur=0.22):
    t = t_(dur)
    return np.sin(2 * np.pi * (f + 50 * dec(t, 0.02)) * t) * dec(t, 0.05) * np.minimum(1.0, t / 0.002)


# ───────────────────────────────────────────── CẨM THẠCH
def stone(f=1100, dur=0.14):
    t = t_(dur)
    click = lp(noise(dur), 7000) * dec(t, 0.0015) * 0.8
    ring = sum(a * np.sin(2 * np.pi * f * r * t) * dec(t, d) for r, a, d in ((1, 1.0, 0.014), (2.63, 0.6, 0.009), (4.7, 0.3, 0.005)))
    body = 0.5 * np.sin(2 * np.pi * 420 * t) * dec(t, 0.02)
    return (click + ring + body) * np.minimum(1.0, t / 0.0006)


def pack_marble():
    fb = A.fmbell
    return {
        "move": reverb(stone(1100), 0.10, 0.15),
        "capture": reverb(place(0.35, [(0, stone(800, 0.16), 1.0), (0.045, stone(1350), 0.8), (0, soft_thud(240), 0.6)]), 0.12, 0.2),
        "castle": reverb(place(0.3, [(0, stone(980), 0.9), (0.10, stone(1240), 1.0)]), 0.12, 0.2),
        "check": reverb(place(0.65, [(0, stone(1300), 0.9), (0.03, fb(1568, 0.4, 0.15, 3.5, 1.5), 0.5), (0.12, fb(2093, 0.45, 0.17, 3.5, 1.5), 0.4)]), 0.15, 0.3),
        "promote": reverb(place(0.95, [(i * 0.09, fb(pent(5 + i), 0.5, 0.16, 3.5, 1.2), 0.8) for i in range(5)] + [(i * 0.09, stone(1500), 0.35) for i in range(5)]), 0.18, 0.35),
        "end": reverb(place(1.7, [(0, stone(520, 0.3), 1.0), (0, soft_thud(200, 0.3), 0.8), (0.08, fb(pent(0), 1.4, 0.55, 3.5, 1.0), 0.55), (0.08, fb(pent(3), 1.2, 0.45, 3.5, 1.0), 0.35)]), 0.22, 0.5),
    }


# ───────────────────────────────────────────── THIÊN NHIÊN
def tok(f=420, dur=0.2):
    t = t_(dur)
    body = np.sin(2 * np.pi * (f + 30 * dec(t, 0.012)) * t) * dec(t, 0.04)
    mode = 0.4 * np.sin(2 * np.pi * f * 2.1 * t) * dec(t, 0.02)
    click = lp(noise(dur), 2500) * dec(t, 0.005) * 0.5
    return lp((body + mode + click) * np.minimum(1.0, t / 0.0012), 4500)


def rustle(dur=0.2):
    g = np.abs(lp(noise(dur), 180))
    g = g / (g.max() + 1e-9)
    u = t_(dur) / dur
    return hp(lp(noise(dur), 6500), 2500) * g * np.sin(np.pi * u) ** 1.2


def bird(f0=2700, notes=3):
    parts = []
    for k in range(notes):
        dur = 0.05
        t = t_(dur)
        u = t / dur
        fk = f0 * (1 + 0.1 * (k % 2))
        f = fk * (0.92 + 0.25 * u) * (1 + 0.02 * np.sin(2 * np.pi * 40 * t))
        parts.append((k * 0.075, np.sin(np.cumsum(2 * np.pi * f / SR)) * np.sin(np.pi * u) ** 2, 1.0))
    return place(notes * 0.075 + 0.06, parts)


def drip(f0=600, dur=0.2):
    t = t_(dur)
    f = f0 * (1 + 0.6 * (1 - dec(t, 0.04)))
    ph = np.cumsum(2 * np.pi * f / SR)
    return (np.sin(ph) + 0.25 * np.sin(2 * ph)) * dec(t, 0.05) * np.minimum(1.0, t / 0.002)


def pack_nature():
    return {
        "move": reverb(place(0.28, [(0, tok(400), 1.0), (0, rustle(0.13), 0.28)]), 0.12, 0.2),
        "capture": reverb(place(0.4, [(0, tok(300, 0.22), 1.0), (0, rustle(0.22), 0.5)]), 0.14, 0.25),
        "castle": reverb(place(0.45, [(0, tok(360), 0.9), (0.12, tok(450), 0.9), (0, rustle(0.25), 0.3)]), 0.14, 0.25),
        "check": reverb(place(0.6, [(0, bird(2600, 3), 0.55), (0.02, tok(500), 0.5)]), 0.16, 0.3),
        "promote": reverb(place(1.3, [(0.0, drip(450), 0.5), (0.1, drip(560), 0.5), (0.2, drip(700), 0.55), (0.3, drip(880), 0.55),
                                       (0.4, bird(3000, 2), 0.45), (0.62, bird(3300, 3), 0.45), (0.0, rustle(0.5), 0.2)]), 0.2, 0.4),
        "end": reverb(place(1.7, [(0.0, A.whoosh(1.2, 300, 1800, 0.5, 0.4), 0.35), (0.0, tok(240, 0.3), 0.8), (0.6, bird(2400, 2), 0.35)]), 0.25, 0.5),
    }


# ───────────────────────────────────────────── VŨ TRỤ
def ping(f, dur=0.6, tau=0.25):
    t = t_(dur)
    return (np.sin(2 * np.pi * f * t) + 0.18 * np.sin(2 * np.pi * 2 * f * t)) * dec(t, tau) * np.minimum(1.0, t / 0.004)


def glide(dur, f0, f1):
    t = t_(dur)
    f = f0 + (f1 - f0) * (t / dur)
    return np.sin(np.cumsum(2 * np.pi * f / SR)) * np.sin(np.pi * t / dur) ** 2


def pack_space():
    return {
        "move": reverb(echo(place(0.3, [(0, ping(pent(0), 0.3, 0.09), 1.0)]), 0.16, 0.35, 3), 0.15, 0.3),
        "capture": reverb(echo(place(0.5, [(0, glide(0.28, 900, 220), 0.6), (0.05, ping(pent(-3), 0.5, 0.18), 0.9)]), 0.18, 0.4, 3), 0.15, 0.3),
        "castle": reverb(echo(place(0.5, [(0, ping(pent(2), 0.3, 0.1), 0.9), (0.10, ping(pent(4), 0.35, 0.12), 1.0)]), 0.17, 0.4, 3), 0.15, 0.3),
        "check": reverb(echo(place(0.75, [(0, glide(0.18, 500, 1400), 0.35), (0.12, ping(pent(5), 0.4, 0.15), 1.0), (0.26, ping(pent(5), 0.5, 0.18), 0.9)]), 0.18, 0.4, 3), 0.18, 0.35),
        "promote": reverb(echo(place(1.3, [(i * 0.07, ping(pent(i), 0.5, 0.2), 0.7) for i in range(10)] + [(0.45, A.pad(pent(5), 1.0), 0.3)]), 0.2, 0.45, 4), 0.2, 0.45),
        "end": reverb(echo(place(2.0, [(0, A.pad(pent(0), 1.8), 0.5), (0, A.pad(pent(3), 1.7), 0.35), (0.2, ping(pent(5), 0.6, 0.25), 0.5),
                                       (0.55, ping(pent(3), 0.7, 0.3), 0.45), (0.95, ping(pent(0), 0.9, 0.4), 0.5)]), 0.22, 0.45, 4), 0.25, 0.5),
    }


# ───────────────────────────────────────────── HỘP NHẠC
def tine(f, dur=0.7, tau=0.28):
    t = t_(dur)
    s = (np.sin(2 * np.pi * f * t) * dec(t, tau) + 0.15 * np.sin(2 * np.pi * 4.0 * f * t) * dec(t, tau * 0.3)
         + 0.06 * np.sin(2 * np.pi * 9.2 * f * t) * dec(t, tau * 0.15))
    return s * np.minimum(1.0, t / 0.001) + lp(noise(dur), 5000) * dec(t, 0.002) * 0.12


def pack_musicbox():
    t = tine
    lull = [(0.00, pent(7), 0.6, 0.25), (0.24, pent(6), 0.6, 0.25), (0.50, pent(4), 0.7, 0.28), (0.80, pent(3), 0.8, 0.32), (1.20, pent(0), 1.3, 0.6)]
    ups = [0, 1, 2, 3, 4, 5, 6, 7, 8, 10]
    return {
        "move": reverb(t(pent(5), 0.35, 0.1), 0.15, 0.3),
        "capture": reverb(place(0.55, [(0, t(pent(7), 0.4, 0.12), 1.0), (0.09, t(pent(3), 0.5, 0.16), 0.9)]), 0.16, 0.3),
        "castle": reverb(place(0.5, [(0, t(pent(5), 0.35, 0.12), 0.9), (0.10, t(pent(7), 0.4, 0.14), 1.0)]), 0.16, 0.3),
        "check": reverb(place(0.75, [(0, t(pent(8), 0.3, 0.1), 0.9), (0.10, t(pent(8), 0.3, 0.1), 0.9), (0.20, t(pent(9), 0.5, 0.2), 1.0)]), 0.18, 0.3),
        "promote": reverb(place(1.4, [(k * 0.065, t(pent(i), 0.5 if k < 9 else 0.9, 0.18 if k < 9 else 0.4), 0.8) for k, i in enumerate(ups)]), 0.2, 0.4),
        "end": reverb(place(2.7, [(st, t(f, d, tau), 0.9) for st, f, d, tau in lull]), 0.25, 0.55),
    }


# ───────────────────────────────────────────── TRE & CHUÔNG GIÓ
def bamboo(f=720, dur=0.22):
    t = t_(dur)
    s = np.sin(2 * np.pi * f * t) * dec(t, 0.035) + 0.4 * np.sin(2 * np.pi * f * 2.1 * t) * dec(t, 0.02) + lp(noise(dur), 3200) * dec(t, 0.004) * 0.4
    return s * np.minimum(1.0, t / 0.001)


def chime(f, dur=1.0, tau=0.5):
    t = t_(dur)
    s = np.zeros_like(t)
    for r, a, m in ((1.0, 1.0, 1.0), (2.76, 0.45, 0.5), (5.4, 0.2, 0.25)):
        e = dec(t, tau * m)
        s += a * np.sin(2 * np.pi * f * r * t) * e + 0.5 * a * np.sin(2 * np.pi * f * r * 1.003 * t + 0.6) * e
    return s * np.minimum(1.0, t / 0.001)


def pack_zen():
    shower = sorted(RNG.random(10) * 0.85 + 0.15)
    return {
        "move": reverb(bamboo(700, 0.22), 0.12, 0.2),
        "capture": reverb(place(0.65, [(0, bamboo(520, 0.25), 1.0), (0, chime(pent(7), 0.5, 0.2), 0.35)]), 0.16, 0.3),
        "castle": reverb(place(0.45, [(0, bamboo(640), 0.9), (0.12, bamboo(790), 1.0)]), 0.14, 0.25),
        "check": reverb(place(1.2, [(0, bamboo(900, 0.15), 0.6), (0.02, chime(pent(5), 0.9, 0.4), 0.7), (0.12, chime(pent(7), 0.9, 0.4), 0.7), (0.24, chime(pent(9), 1.0, 0.45), 0.8)]), 0.2, 0.4),
        "promote": reverb(place(2.0, [(0, A.whoosh(0.8, 400, 3000, 0.7, 0.4), 0.35)] + [(float(s), chime(pent(int(RNG.integers(3, 13))), 0.8, 0.35), float(RNG.uniform(0.3, 0.7))) for s in shower]), 0.22, 0.45),
        "end": reverb(place(2.4, [(0, bamboo(480, 0.3), 0.9), (0.05, chime(pent(0), 2.0, 0.9), 0.7), (0.35, chime(pent(3), 1.7, 0.75), 0.5), (0.2, A.whoosh(1.5, 300, 1500, 0.5, 0.4), 0.2)]), 0.25, 0.5),
    }


PACKS = {"marble": pack_marble, "nature": pack_nature, "space": pack_space, "musicbox": pack_musicbox, "zen": pack_zen}
SFX_ORDER = ("move", "capture", "castle", "check", "promote", "end")
PEAK = {"move": 0.55, "capture": 0.70, "castle": 0.62, "check": 0.75, "promote": 0.78, "end": 0.78}


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    gap, gap_pack = np.zeros(int(SR * 0.5)), np.zeros(int(SR * 1.5))
    chunks = []
    total = 0
    for pack, fn in PACKS.items():
        sounds = fn()
        for sfx in SFX_ORDER:
            y = A.master(A.trim_silence(sounds[sfx]), PEAK[sfx])
            A.write_wav(OUT / f"{pack}_{sfx}.wav", y)
            chunks += [y, gap]
            total += 1
        chunks.append(gap_pack)
    A.write_wav(PREVIEW, np.concatenate(chunks))
    print(f"✅ {total} file trong {OUT} + {PREVIEW.name}")
