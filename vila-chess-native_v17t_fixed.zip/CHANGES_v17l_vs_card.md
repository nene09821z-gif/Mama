# v17l — Thẻ "VS" khi vào ván online (giống chess.com)

## Mới
- ui/VsMatchCard.kt : `OnlineVsIntro` — hai thẻ người chơi (avatar, tên + huy hiệu VIP, cờ quốc gia, Elo theo thể loại ván, ô màu quân)
  trượt vào từ trên/dưới bàn cờ, nút VS màu xanh VILA bật ra ở giữa, giữ ~2,8 giây rồi mờ dần.
  - Thẻ trên = đối thủ, thẻ dưới = bạn (khớp hai thanh PlayerBar).
  - Không chặn cảm ứng: bạn vẫn kéo quân được ngay; tự tắt khi có nước đi đầu tiên hoặc hết ván.
  - Chỉ hiện ở ván MỚI (chưa có nước đi). Vào lại ván đang dở thì không hiện.
  - Chờ tối đa 0,7 giây để tải hồ sơ đối thủ (ảnh/cờ/Elo) rồi mới chạy hiệu ứng, thẻ không đổi nội dung giữa chừng.
  - Elo đối thủ lấy từ hồ sơ (cùng nguồn với OpponentProfileSheet); lỗi mạng thì chỉ ẩn viên Elo, tên + huy hiệu vẫn hiện.
## Sửa
- ui/OnlineGameScreen.kt : đặt OnlineVsIntro chồng lên bàn cờ (matchParentSize).
## Lưu ý
- Chưa build được trong môi trường này (không có Android SDK) - chạy ./gradlew assembleDebug.
- Chưa áp dụng cho Cờ Phép Thuật online (MagicChessScreen) - làm tiếp được nếu muốn.
