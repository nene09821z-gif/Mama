# v17q — Thanh công cụ: icon phẳng một màu (Bot + Online + PvP)

## Đổi
- ui/ToolbarIcons25D.kt => ui/ToolbarIconsFlat.kt: bỏ bộ icon 2.5D nhiều màu, vẽ lại phẳng một màu trên lưới 24x24.
  Icon tô bằng LocalContentColor của ToolbarButton nên icon và chữ luôn cùng màu (xám TextDim; xanh lá khi nút đang bật).
  - Các tùy chọn: danh sách chấm + thanh · Hủy/Đầu hàng: cờ phấp phới · Gợi ý: bóng đèn có chấm tia sáng (phát sáng nhẹ khi bật)
  - Đánh giá: 3 cột · Hoàn tác: mũi tên cong dày · Tìm trận mới / Tái đấu: mũi tên vòng
  - Mới: DRAW (½ vẽ bằng nét) và CHAT (bong bóng chat phẳng).
- ui/OnlineGameScreen.kt: "Cầu hòa" bỏ chữ "½", "Chat" bỏ emoji 💬 => dùng ToolIcon.DRAW / ToolIcon.CHAT (huy hiệu tin chưa đọc giữ nguyên).
- ui/PvpGameScreen.kt: "Cầu hòa" dùng ToolIcon.DRAW cho đồng bộ; bỏ import không còn dùng.
- BotGameScreen.kt không phải sửa: vẫn gọi ToolbarIcon(ToolIcon.*) như cũ, chỉ khác hình.

## Giữ nguyên
- Nút "Đánh giá" (thanh Eval) ở trận Bot vẫn còn, chỉ đổi sang icon phẳng. Ảnh mẫu chỉ có 4 nút; nếu muốn bỏ thì xóa 1 dòng trong BotGameScreen.kt.
- Nền thanh công cụ vẫn là PanelDark như cũ (ảnh mẫu nền trong suốt trên nền sao).

## Lưu ý
- Chưa build/chạy trên máy (không có Android SDK ở đây). Hình dáng icon đã dựng thử bằng SVG cùng số liệu để kiểm tra.
