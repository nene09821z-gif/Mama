# v17m — Bộ quân "Anime Trắng Đen" (thêm vào Tùy chỉnh > Quân cờ)

## Mới
- assets/pieces/anime/{wP,wN,wB,wR,wQ,wK,bP,bN,bB,bR,bQ,bK}.png : 12 ảnh 256x256, nền trong suốt (cùng định dạng các bộ khác).
## Sửa
- ui/PieceImages.kt : thêm PieceSetInfo("anime", "Anime Trắng Đen") ngay sau bộ mặc định. Không cần sửa chỗ nào khác
  (BoardView / ThemeScreen / GameViewModel đã tự đọc danh sách PieceSets.all; ô xem trước dùng Mã trắng + Mã đen).
## Bố cục ảnh gốc (đã đối chiếu từng ô)
- Hàng trên = quân TRẮNG, hàng dưới = quân ĐEN. Thứ tự 6 cột từ trái sang phải: Tốt, Mã, Hậu, Vua, Tượng, Xe.
  (Mã = tai thú, Tượng = cầm súng + huy hiệu quân tượng trên tay áo, Xe = mũ lô cốt, Hậu = vương miện nhỏ dáng đứng,
  Vua = vương miện to + dây chuyền chữ thập.) Nếu muốn đổi Hậu <-> Vua: đổi tên wQ.png <-> wK.png và bQ.png <-> bK.png.
## Lưu ý
- Ảnh nguồn là ảnh chụp màn hình (mỗi ô ~120px) nên độ nét vừa phải; có ảnh gốc lớn hơn thì thay vào là đẹp hơn.
- Ô Xe ở mép phải ảnh bị cắt ~7px: đã giãn ngang ~14% cho vừa khít ô.

## v17n — Thêm bản "Anime Có Ký Hiệu" (dễ nhận biết quân)
- Lý do: tranh chân dung nên trên bàn nhỏ khó phân biệt quân nào là quân nào.
- assets/pieces/anime-icon/ : cùng 12 ảnh nhưng có huy hiệu tròn ở góc dưới-trái ghi hình quân (Tốt/Mã/Tượng/Xe/Hậu/Vua).
  Huy hiệu quân trắng = nền trắng, hình đen; quân đen = nền đen, hình trắng; có vòng viền tương phản nên đọc được trên mọi màu bàn.
- ui/PieceImages.kt : thêm PieceSetInfo("anime-icon", "Anime Có Ký Hiệu") ngay sau bộ mặc định. Bản gốc "Anime Trắng Đen" (không huy hiệu) vẫn giữ.
