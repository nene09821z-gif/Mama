# v17q — Bộ mặt mới cho 15 Bot

## Đổi
- app/src/main/res/drawable/bot_*.xml (15 file: martin, jimmy, nelson, emir, lena, antonio, sofia, hiro, viktor, isabel,
  magnus, olga, daniel, nova, mittens) được thay bằng bản sinh từ tools/botfaces.py.
  - Tên file, id và Elo giữ nguyên nên BotRepository.kt và mọi màn hình dùng `R.drawable.bot_*` không phải sửa.
  - Chỉ dùng path tô màu và nét bo tròn (không gradient/clip/xoay) => chạy được từ API 24.
  - Nền mới tràn hết ô vuông 48x48 (bản cũ là hình tròn); các chỗ hiển thị đều đã `clip` tròn / bo góc nên khớp.

## Thêm
- tools/botfaces.py: script sinh avatar. Chạy `python3 tools/botfaces.py <thư_mục>` để ra bot_*.xml (VectorDrawable) và bot_*.svg (xem thử).

## Lưu ý
- Chưa build/chạy trên máy (không có Android SDK ở đây). Đã kiểm tra XML hợp lệ và render thử SVG của cả 15 mặt.
