# v17p — Icon menu "Thêm nữa" + khung Thầy không bị cắt nút

## Sửa (theo ảnh chụp)
- ui/MoreTab.kt
  - "Cờ Phép Thuật" và "Đăng ký danh hiệu": bỏ emoji 🪄 / 🎖 (nét mảnh, khác hẳn các dòng còn lại), dùng ô 2.5D có sẵn
    Benefit25D(BenefitKind.MAGIC) (tím) và Benefit25D(BenefitKind.TITLE) (xanh ngọc), cùng cỡ 34dp, cùng đế nổi + bóng kính như
    Thống kê / Giải thưởng / Bạn bè. Hai icon này đã dùng ở Trang chủ nên hai nơi giờ giống nhau.
  - Nhãn "Đăng ký danh hiệu CM · FM · GM" bị cắt "…" => "Danh hiệu CM · FM · GM" (vừa một dòng, kể cả khi có huy hiệu bên phải).
  - Dòng đăng nhập: khi đã đăng nhập nhãn đổi thành "Tài khoản" (trước đây hiện "Đăng nhập (…" bị cắt vì email chiếm chỗ);
    chữ bên phải (email) giới hạn 170dp và tự cắt "…" ở chính nó, không bóp mất nhãn bên trái.
- ui/BotGameScreen.kt + ui/TeacherPanel.kt (hàng nút Hỏi thầy / Gợi ý / Sổ tay bị cắt mất nửa)
  - Nguyên nhân: vùng chứa khung Thầy chỉ được ~85dp (chia 1,3 / 2,1 với khoảng trống phía trên bàn cờ) trong khi khung cần ~103–115dp.
  - Khoảng trống phía trên bàn cờ giảm từ weight 0.8 xuống 0.25, vùng khung Thầy tăng từ 1.3 lên 1.75 (máy 720x1612: ~85dp => ~124dp).
    Bàn cờ nhích lên khoảng 40dp; bật/tắt huấn luyện viên vẫn không làm bàn cờ dịch chuyển.
  - Máy thấp hơn nữa (vùng < 116dp): TeacherPanel(compact = true) => chữ bong bóng 12sp/dòng 15sp, nút cao 26dp (thay vì 13sp / 28dp).
    Tổng chiều cao tối đa khi gọn ~104dp.

## Lưu ý
- Chưa build/chạy trên máy (không có Android SDK ở đây); các con số dp tính từ ảnh chụp màn hình 720x1612 bạn gửi.
- Các icon còn lại ở menu (Đăng nhập = bánh răng xanh, Ván đã chơi, Chủ đề, Các tùy chỉnh) vẫn là icon phẳng của Material; "Bảng xếp hạng" vẫn là emoji 🏆. Chưa đổi vì chưa được yêu cầu.
