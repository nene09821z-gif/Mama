package com.vila.chess.game

data class Slide(val from: Int, val to: Int)

data class PendingPromotion(val from: Int, val to: Int, val fromDrag: Boolean)

data class ClockState(val whiteMs: Long = 0L, val blackMs: Long = 0L, val enabled: Boolean = false)

/** Immutable snapshot of everything the board / bars need to draw. */
data class UiState(
    val board: IntArray = IntArray(64),
    val humanWhite: Boolean = true,
    val flipped: Boolean = false,
    val selected: Int = -1,
    val targets: Set<Int> = emptySet(),
    val lastFrom: Int = -1,
    val lastTo: Int = -1,
    val checkSquare: Int = -1,
    val premoveFrom: Int = -1,
    val premoveTo: Int = -1,
    val slides: List<Slide> = emptyList(),
    val animToken: Int = 0,
    val sans: List<String> = emptyList(),
    val whiteToMove: Boolean = true,
    val thinking: Boolean = false,
    val over: Boolean = false,
    val resultTitle: String = "",
    val resultDetail: String = "",
    /** Kết quả cho màn tổng kết: hòa / người chơi thắng (luôn false khi chơi 2 người). */
    val draw: Boolean = false,
    val humanWon: Boolean = false,
    val promotion: PendingPromotion? = null,
    val capturedByWhite: List<Int> = emptyList(),
    val capturedByBlack: List<Int> = emptyList(),
    val materialDiff: Int = 0,
    val canUndo: Boolean = false,
    val kind: GameKind = GameKind.BOT,
    val hintFrom: Int = -1,
    val hintTo: Int = -1,
    val hintText: String = "",
    val hintBusy: Boolean = false
)
