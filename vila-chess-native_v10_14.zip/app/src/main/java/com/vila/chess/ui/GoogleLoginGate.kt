package com.vila.chess.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.vila.chess.R
import com.vila.chess.auth.Account
import com.vila.chess.auth.AccountStore
import com.vila.chess.auth.AuthProvider
import com.vila.chess.auth.SocialSignIn
import kotlinx.coroutines.launch
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val Green = Color(0xFF81B64C)

/**
 * Trang đăng nhập Google hiện đầu tiên khi mở app.
 * - Có `google_android_client_id`: mở TRANG CHỌN TÀI KHOẢN TOÀN TRANG của Google (như "Chọn tài khoản để tiếp tục…").
 * - Chưa có: dùng bảng chọn tài khoản dạng bottom-sheet (Credential Manager) như trước.
 * Logo + chữ Chessplus.com vẽ bằng Canvas MỘT LẦN; chỉ lớp (layer) được dịch chuyển => không giật.
 */
@Composable
fun GoogleLoginGate() {
    val ctx = LocalContext.current
    val activity = ctx as? ComponentActivity
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }

    val androidClientId = ctx.getString(R.string.google_android_client_id)
    val useBrowser = !androidClientId.startsWith("YOUR_")

    fun signedIn(email: String?, name: String) {
        if (email != null) AccountStore.save(ctx, Account(email, name, AuthProvider.GOOGLE))
        else Toast.makeText(ctx, "Google", Toast.LENGTH_SHORT).show()
    }

    // ---- Luồng toàn trang (AppAuth + PKCE) ----
    val authService = remember { AuthorizationService(ctx) }
    DisposableEffect(Unit) { onDispose { authService.dispose() } }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        val resp = data?.let { AuthorizationResponse.fromIntent(it) }
        val ex = data?.let { AuthorizationException.fromIntent(it) }
        if (resp == null) {
            loading = false
            if (ex != null && ex.code != AuthorizationException.GeneralErrors.USER_CANCELED_AUTH_FLOW.code)
                Toast.makeText(ctx, ex.errorDescription ?: ex.error ?: "Lỗi", Toast.LENGTH_LONG).show()
            return@rememberLauncherForActivityResult
        }
        authService.performTokenRequest(resp.createTokenExchangeRequest()) { tr, e ->
            loading = false
            val r = SocialSignIn.parseGoogleIdToken(tr?.idToken)
            if (r != null) signedIn(r.email, r.name)
            else Toast.makeText(ctx, e?.errorDescription ?: "Lỗi", Toast.LENGTH_LONG).show()
        }
    }
    fun startBrowserFlow() {
        val cfg = AuthorizationServiceConfiguration(
            Uri.parse("https://accounts.google.com/o/oauth2/v2/auth"),
            Uri.parse("https://oauth2.googleapis.com/token"),
        )
        val req = AuthorizationRequest.Builder(cfg, androidClientId, ResponseTypeValues.CODE, Uri.parse("com.vila.chessnative:/oauth2redirect"))
            .setScope("openid email profile")
            .setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)   // luôn hiện danh sách chọn tài khoản
            .build()
        loading = true
        launcher.launch(authService.getAuthorizationRequestIntent(req))
    }
    fun startSheetFlow() {
        if (activity == null) return
        loading = true
        scope.launch {
            runCatching { SocialSignIn.google(activity, ctx.getString(R.string.google_web_client_id)) }
                .onSuccess { signedIn(it.email, it.name) }
                .onFailure { e ->
                    if (e !is GetCredentialCancellationException)
                        Toast.makeText(ctx, e.message ?: e.javaClass.simpleName, Toast.LENGTH_LONG).show()
                }
            loading = false
        }
    }

    // Thời gian dùng chung; chỉ được đọc trong graphicsLayer / draw
    val t = rememberInfiniteTransition(label = "gate").animateFloat(
        0f, 1f, infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "t",
    )
    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF141311), Color(0xFF22211E), Color(0xFF181715)))),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = 0.75f + 0.25f * sin(2f * PI.toFloat() * t.value) }) {
            val c = Offset(size.width / 2, size.height * 0.38f)
            drawCircle(Brush.radialGradient(listOf(Color(0x5581B64C), Color(0x1881B64C), Color.Transparent), center = c, radius = size.width * 0.9f), radius = size.width * 0.9f, center = c)
        }

        Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1.1f))

            // Logo + chữ: một khối tĩnh, chỉ trôi lên xuống bằng graphicsLayer
            Column(
                Modifier.graphicsLayer {
                    translationY = sin(2f * PI.toFloat() * t.value) * 6.dp.toPx() + (1f - enter.value) * 40.dp.toPx()
                    alpha = enter.value
                },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                ChessplusMark(Modifier.size(132.dp))
                Spacer(Modifier.height(22.dp))
                ChessplusWordmark(Modifier.fillMaxWidth().height(64.dp))
            }

            Spacer(Modifier.weight(1f))

            val src = remember { MutableInteractionSource() }
            val pressed by src.collectIsPressedAsState()
            val pressScale by animateFloatAsState(if (pressed) 0.96f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "press")
            Box(
                Modifier
                    .graphicsLayer { alpha = enter.value; scaleX = pressScale; scaleY = pressScale; translationY = (1f - enter.value) * 24.dp.toPx() }
                    .widthIn(max = 320.dp).fillMaxWidth().height(62.dp)
                    .shadow(14.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
                    .clip(CircleShape).background(Color.White)
                    .clickable(interactionSource = src, indication = null, enabled = !loading) {
                        if (useBrowser) startBrowserFlow() else startSheetFlow()
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(26.dp), color = Color(0xFF4285F4), strokeWidth = 3.dp)
                else GoogleG(Modifier.size(30.dp))
            }
            Spacer(Modifier.height(56.dp))
        }
    }
}

/** Biểu tượng app: ô vuông bo góc nền xanh + quân Mã trắng, vẽ bằng Canvas. */
@Composable
private fun ChessplusMark(modifier: Modifier = Modifier) {
    val knight: ImageBitmap = ImageBitmap.imageResource(R.drawable.piece_wn)
    Canvas(modifier) {
        val r = size.minDimension * 0.28f
        drawRoundRect(Color(0x6681B64C), Offset(0f, size.height * 0.04f), size, CornerRadius(r))                      // bóng đổ xanh
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFF9CCB5F), Color(0xFF5E8F33))), Offset.Zero, size, CornerRadius(r))
        drawRoundRect(Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color.Transparent), endY = size.height * 0.5f), Offset.Zero, size, CornerRadius(r))   // bóng sáng phía trên
        val k = size.minDimension * 0.70f
        val o = (size.minDimension - k) / 2f
        drawImage(knight, dstOffset = IntOffset(o.roundToInt(), o.roundToInt()), dstSize = IntSize(k.roundToInt(), k.roundToInt()))
    }
}

/** "Chessplus.com" chữ to: đo layout một lần, vẽ trực tiếp bằng Canvas, tự co nếu màn hình hẹp. */
@Composable
private fun ChessplusWordmark(modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    val text: AnnotatedString = remember {
        buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White)) { append("Chess") }
            withStyle(SpanStyle(color = Green)) { append("plus") }
            withStyle(SpanStyle(color = Color(0xFFB9BDC4), fontWeight = FontWeight.SemiBold)) { append(".com") }
        }
    }
    val layout = remember(text) {
        measurer.measure(text, TextStyle(fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp, shadow = androidx.compose.ui.graphics.Shadow(Color(0x66000000), Offset(0f, 4f), 10f)))
    }
    Canvas(modifier) {
        val w = layout.size.width.toFloat(); val h = layout.size.height.toFloat()
        val s = min(1f, size.width / w)
        scale(s, s, pivot = Offset(size.width / 2f, size.height / 2f)) {
            drawText(layout, topLeft = Offset((size.width - w) / 2f, (size.height - h) / 2f))
        }
    }
}

/** Logo "G" nhiều màu của Google vẽ bằng Canvas. */
@Composable
private fun GoogleG(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val stroke = size.minDimension * 0.2f
        val inset = stroke / 2f
        val arcSize = Size(size.width - stroke, size.height - stroke)
        val tl = Offset(inset, inset)
        fun arc(color: Color, start: Float, sweep: Float) =
            drawArc(color, start, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
        arc(Color(0xFFEA4335), 195f, 120f)
        arc(Color(0xFFFBBC05), 135f, 60f)
        arc(Color(0xFF34A853), 45f, 90f)
        arc(Color(0xFF4285F4), 0f, 45f)
        drawRect(Color(0xFF4285F4), Offset(size.width / 2f, size.height / 2f - stroke / 2f), Size(size.width / 2f, stroke))
    }
}
