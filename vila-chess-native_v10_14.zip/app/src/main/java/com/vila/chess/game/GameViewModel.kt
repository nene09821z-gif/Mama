package com.vila.chess.game

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vila.chess.core.BISHOP
import com.vila.chess.core.EMPTY
import com.vila.chess.core.Engine
import com.vila.chess.core.Position
import com.vila.chess.billing.MembershipStore
import com.vila.chess.billing.Quota
import com.vila.chess.billing.UsageTracker
import com.vila.chess.review.GameReviewWorker
import com.vila.chess.core.FLAG_CASTLE
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.SearchLimits
import com.vila.chess.core.START_FEN
import com.vila.chess.core.generatePseudoCopyForPremove
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.core.moveUci
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue
import com.vila.chess.ui.DEFAULT_PIECE_SET
import com.vila.chess.ui.PieceSets
import com.vila.chess.ui.loadPieceImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

enum class Screen { HOME, GAME }

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("vila_native", Context.MODE_PRIVATE)
    private val sounds = SoundPlayer(app)
    private val haptics = Haptics(app)

    // ---- settings (persisted) ----
    var level by mutableIntStateOf(prefs.getInt("level", 3))
        private set
    var colorChoice by mutableIntStateOf(prefs.getInt("color", 0)) // 0 white, 1 random, 2 black
        private set
    var timeIndex by mutableIntStateOf(prefs.getInt("time", 6))
        private set
    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set
    var hapticOn by mutableStateOf(prefs.getBoolean("haptic", true))
        private set
    var pieceSet by mutableStateOf(
        (prefs.getString("pieceSet2", "cburnett") ?: "cburnett")
            .let { if (PieceSets.exists(it)) it else "cburnett" }
    )
        private set
    var pieceImages by mutableStateOf(loadPieceImages(app, pieceSet))
        private set

    // ---- player stats (ratings per time bucket, daily streak) ----
    var stats by mutableStateOf(StatsStore.load(prefs))
        private set
    var tipsUnread by mutableIntStateOf(if (prefs.getBoolean("tipsSeen", false)) 0 else HOME_TIPS.size)
        private set

    // ---- coach, navigation and tournament ----
    var coachOn by mutableStateOf(prefs.getBoolean("coach", false))
        private set
    var route by mutableStateOf(HomeRoute.HOME)
        private set
    var tournament by mutableStateOf(Tournament.parse(prefs.getString("tourney", null)))
        private set
    var tournamentsDone by mutableIntStateOf(prefs.getInt("tourneyDone", 0))
        private set

    fun setCoach(v: Boolean) {
        coachOn = v
        prefs.edit().putBoolean("coach", v).apply()
        if (!v) {
            hintCancel.set(true)
            ui = ui.copy(hintFrom = -1, hintTo = -1, hintText = "", hintBusy = false)
        }
    }

    fun navigate(r: HomeRoute) {
        route = r
    }

    fun resetTournament() {
        tournament = Tournament.parse(null)
        prefs.edit().putString("tourney", Tournament.serialize(tournament)).apply()
    }

    fun markTipsSeen() {
        tipsUnread = 0
        prefs.edit().putBoolean("tipsSeen", true).apply()
    }

    init {
        sounds.enabled = soundOn
        haptics.enabled = hapticOn
    }

    fun updateLevel(v: Int) {
        level = v.coerceIn(1, 8)
        prefs.edit().putInt("level", level).apply()
    }

    fun updateColorChoice(v: Int) {
        colorChoice = v
        prefs.edit().putInt("color", v).apply()
    }

    fun updateTimeIndex(v: Int) {
        timeIndex = v
        prefs.edit().putInt("time", v).apply()
    }

    fun setSound(v: Boolean) {
        soundOn = v
        sounds.enabled = v
        prefs.edit().putBoolean("sound", v).apply()
    }

    fun updatePieceSet(id: String) {
        if (!PieceSets.exists(id) || id == pieceSet) return
        pieceImages = loadPieceImages(getApplication<Application>(), id)
        pieceSet = id
        prefs.edit().putString("pieceSet2", id).apply()
    }

    fun setHaptic(v: Boolean) {
        hapticOn = v
        haptics.enabled = v
        prefs.edit().putBoolean("haptic", v).apply()
    }

    // ---- game state ----
    var screen by mutableStateOf(Screen.HOME)
        private set
    var ui by mutableStateOf(UiState())
        private set
    var clocks by mutableStateOf(ClockState())
        private set

    private var session: GameSession? = null
    private var humanWhite = true
    private var flipped = false
    private var currentLevel: Level = Levels.get(3)
    private var timeControl: TimeControl = TimeControls.get(0)
    private var premove: Pair<Int, Int>? = null
    private var engineJob: Job? = null
    private var engineCancel = AtomicBoolean(false)
    private var clockJob: Job? = null
    private var resultAnnounced = false

    /** Id ván vừa kết thúc đã được xếp hàng phân tích ngầm (null = chưa/không đủ điều kiện). Màn tổng kết dùng id này. */
    var lastReviewId: String? by mutableStateOf(null)
        private set
    /** Lý do không phân tích được (ván quá ngắn / hết lượt trong ngày) để màn tổng kết báo đúng. */
    var reviewSkipReason: String? by mutableStateOf(null)
        private set
    val botLevelId: Int get() = currentLevel.id
    private var gameKind = GameKind.BOT
    private var startFen = START_FEN
    private var startHumanWhite: Boolean? = null
    private var startLevel = 3
    private var tournamentRound = -1
    private var engineMovesFirst = false
    private var hintCancel = AtomicBoolean(false)

    /** Quick play against the bot with the saved level / colour / time. */
    fun startGame() = beginGame(GameKind.BOT, START_FEN, null, level, -1)

    /** Two players on one device. */
    fun startFriendGame() = beginGame(GameKind.FRIEND, START_FEN, true, level, -1)

    /** Endgame practice from a ready-made position. */
    fun startEndgame(p: EndgamePreset) = beginGame(GameKind.ENDGAME, p.fen, p.humanWhite, level, -1)

    /** Play against the bot from a custom FEN. Returns an error message, or null when the game started. */
    fun startFromFen(fen: String, humanIsWhite: Boolean): String? {
        val err = FenCheck.validate(fen)
        if (err != null) return err
        beginGame(GameKind.ENDGAME, fen.trim(), humanIsWhite, level, -1)
        return null
    }

    /** Plays the next unplayed round of the bot tournament; false when the tournament is finished. */
    fun startTournamentRound(): Boolean {
        val r = Tournament.nextRound(tournament)
        if (r < 0) return false
        beginGame(GameKind.TOURNAMENT, START_FEN, Tournament.humanWhite(r), Tournament.levelFor(r), r)
        return true
    }

    /** "Ván mới" from the game screen: same kind of game again (next round in a tournament). */
    fun rematch() {
        when (gameKind) {
            GameKind.BOT -> startGame()
            GameKind.FRIEND -> startFriendGame()
            GameKind.ENDGAME -> beginGame(GameKind.ENDGAME, startFen, startHumanWhite, startLevel, -1)
            GameKind.TOURNAMENT -> {
                if (ui.over) {
                    if (!startTournamentRound()) backToHome()
                } else {
                    beginGame(GameKind.TOURNAMENT, START_FEN, Tournament.humanWhite(tournamentRound), startLevel, tournamentRound)
                }
            }
        }
    }

    private fun beginGame(kind: GameKind, fen: String, humanWhiteArg: Boolean?, lvl: Int, round: Int) {
        stopJobs()
        val s = GameSession(fen)
        session = s
        gameKind = kind
        startFen = fen
        startHumanWhite = humanWhiteArg
        startLevel = lvl
        tournamentRound = round
        humanWhite = humanWhiteArg ?: when (colorChoice) {
            0 -> true
            2 -> false
            else -> Random.nextBoolean()
        }
        flipped = if (kind == GameKind.FRIEND) false else !humanWhite
        engineMovesFirst = kind != GameKind.FRIEND && s.position.whiteToMove != humanWhite
        currentLevel = Levels.get(lvl)
        timeControl = TimeControls.get(timeIndex)
        premove = null
        resultAnnounced = false
        lastReviewId = null
        reviewSkipReason = null
        val base = timeControl.baseSec * 1000L
        clocks = ClockState(base, base, timeControl.baseSec > 0)
        ui = UiState(kind = kind)
        refreshUi()
        screen = Screen.GAME
        startClock()
        if (!finishIfOver()) startEngineIfNeeded()
    }

    fun backToHome() {
        stopJobs()
        route = if (gameKind == GameKind.TOURNAMENT) HomeRoute.TOURNAMENT else HomeRoute.HOME
        screen = Screen.HOME
    }

    /** Coach: ask the engine for the best move for the player to move. */
    fun requestHint() {
        val s = session ?: return
        if (!coachOn || gameKind == GameKind.FRIEND || gameKind == GameKind.TOURNAMENT) return
        if (s.isOver || !isHumanTurn(s) || ui.hintBusy || ui.promotion != null) return
        val ply = s.records.size
        val snapshot = s.position.copy()
        val cancel = AtomicBoolean(false)
        hintCancel = cancel
        ui = ui.copy(hintBusy = true, hintText = "Huấn luyện viên đang suy nghĩ…", hintFrom = -1, hintTo = -1)
        viewModelScope.launch {
            val h = withContext(Dispatchers.Default) { Coach.hint(snapshot) { cancel.get() } }
            if (cancel.get() || session !== s || s.records.size != ply || s.isOver) return@launch
            ui = if (h == null) {
                ui.copy(hintBusy = false, hintText = "Không còn nước đi hợp lệ")
            } else {
                ui.copy(hintBusy = false, hintFrom = moveFrom(h.move), hintTo = moveTo(h.move), hintText = Coach.describe(h))
            }
        }
    }

    private fun stopJobs() {
        hintCancel.set(true)
        engineCancel.set(true)
        engineJob?.cancel()
        engineJob = null
        clockJob?.cancel()
        clockJob = null
    }

    override fun onCleared() {
        stopJobs()
        sounds.release()
        super.onCleared()
    }

    // ---- board interaction ----

    private fun isHumanTurn(s: GameSession): Boolean = gameKind == GameKind.FRIEND || s.position.whiteToMove == humanWhite

    private fun isOwnPiece(s: GameSession, piece: Int): Boolean {
        if (piece == EMPTY) return false
        val mine = if (gameKind == GameKind.FRIEND) s.position.whiteToMove else humanWhite
        return isWhitePiece(piece) == mine
    }

    /** Pointer went down on [sq]. Returns true when a piece of the player was picked up (may be dragged). */
    fun pressSquare(sq: Int): Boolean {
        val s = session ?: return false
        if (sq < 0 || ui.over || ui.promotion != null) return false
        val piece = s.position.board[sq]
        val own = isOwnPiece(s, piece)
        val sel = ui.selected
        if (isHumanTurn(s)) {
            if (sel >= 0 && ui.targets.contains(sq)) {
                attemptMove(sel, sq, false)
                return false
            }
            if (own) {
                selectSquare(sq, premoveMode = false)
                return true
            }
            clearSelection()
            return false
        }
        // opponent's turn: premove mode
        if (sel >= 0 && ui.targets.contains(sq)) {
            setPremove(sel, sq)
            return false
        }
        if (own) {
            selectSquare(sq, premoveMode = true)
            return true
        }
        premove = null
        refreshUi()
        return false
    }

    /** Pointer released after dragging the piece that started on [from]; [dropSq] is the square it was dropped on. */
    fun releaseDrag(from: Int, dropSq: Int) {
        val s = session ?: return
        if (dropSq < 0 || dropSq == from || ui.over) return
        if (!ui.targets.contains(dropSq)) return
        if (isHumanTurn(s)) attemptMove(from, dropSq, true) else setPremove(from, dropSq)
    }

    fun deselect() {
        clearSelection()
    }

    private fun selectSquare(sq: Int, premoveMode: Boolean) {
        val s = session ?: return
        val targets: Set<Int> = if (premoveMode) premoveTargets(s, sq) else {
            val set = HashSet<Int>()
            for (m in s.movesFrom(sq)) set.add(moveTo(m))
            set
        }
        ui = ui.copy(selected = sq, targets = targets)
    }

    private fun premoveTargets(s: GameSession, sq: Int): Set<Int> {
        val set = HashSet<Int>()
        for (m in generatePseudoCopyForPremove(s.position, humanWhite)) {
            if (moveFrom(m) == sq) set.add(moveTo(m))
        }
        return set
    }

    private fun clearSelection() {
        ui = ui.copy(selected = -1, targets = emptySet())
    }

    private fun setPremove(from: Int, to: Int) {
        premove = Pair(from, to)
        ui = ui.copy(selected = -1, targets = emptySet())
        refreshUi()
    }

    private fun attemptMove(from: Int, to: Int, fromDrag: Boolean) {
        val s = session ?: return
        if (s.isPromotion(from, to)) {
            ui = ui.copy(promotion = PendingPromotion(from, to, fromDrag))
            return
        }
        val m = s.findMove(from, to, 0)
        if (m < 0) {
            clearSelection()
            return
        }
        playHuman(m, fromDrag)
    }

    fun choosePromotion(type: Int) {
        val s = session ?: return
        val p = ui.promotion ?: return
        ui = ui.copy(promotion = null)
        val m = s.findMove(p.from, p.to, type)
        if (m >= 0) playHuman(m, p.fromDrag) else clearSelection()
    }

    fun cancelPromotion() {
        ui = ui.copy(promotion = null, selected = -1, targets = emptySet())
    }

    private fun slidesFor(m: Int, whiteMoved: Boolean): List<Slide> {
        val list = ArrayList<Slide>()
        list.add(Slide(moveFrom(m), moveTo(m)))
        if (moveFlag(m) == FLAG_CASTLE) {
            val base = if (whiteMoved) 0 else 56
            if (moveTo(m) == base + 6) list.add(Slide(base + 7, base + 5)) else list.add(Slide(base, base + 3))
        }
        return list
    }

    private fun playHuman(m: Int, fromDrag: Boolean) {
        val s = session ?: return
        if (!isHumanTurn(s) || s.isOver) return
        premove = null
        val whiteMoved = s.position.whiteToMove
        val rec = s.play(m)
        addIncrement(whiteMoved)
        announce(rec, s)
        refreshUi(slides = if (fromDrag) emptyList() else slidesFor(m, whiteMoved))
        if (!finishIfOver()) startEngineIfNeeded()
    }

    private fun playEngine(m: Int) {
        val s = session ?: return
        if (isHumanTurn(s) || s.isOver) return
        val whiteMoved = s.position.whiteToMove
        val rec = s.play(m)
        addIncrement(whiteMoved)
        announce(rec, s)
        refreshUi(slides = slidesFor(m, whiteMoved))
        if (finishIfOver()) return
        val pm = premove
        if (pm != null) {
            premove = null
            var mv = s.findMove(pm.first, pm.second, 0)
            if (mv < 0) mv = s.findMove(pm.first, pm.second, QUEEN)
            if (mv >= 0) {
                viewModelScope.launch {
                    delay(60)
                    if (session === s) playHuman(mv, false)
                }
            } else {
                refreshUi()
            }
        }
    }

    // ---- engine ----

    private fun startEngineIfNeeded() {
        val s = session ?: return
        if (s.isOver || isHumanTurn(s)) return
        engineCancel.set(true)
        engineJob?.cancel()
        val cancel = AtomicBoolean(false)
        engineCancel = cancel
        val snapshot = s.position.copy()
        val engineWhite = !humanWhite
        val engineMs = if (engineWhite) clocks.whiteMs else clocks.blackMs
        var limits = currentLevel.limits
        if (clocks.enabled) {
            val budget = (engineMs / 25L).coerceAtLeast(200L)
            if (budget < limits.timeMs) limits = SearchLimits(limits.maxDepth, budget, limits.noiseCp)
        }
        val minDelay = if (currentLevel.id <= 3) 500L else 250L
        ui = ui.copy(thinking = true)
        engineJob = viewModelScope.launch {
            val started = System.currentTimeMillis()
            val lim = limits
            val move = withContext(Dispatchers.Default) {
                val e = Engine()
                e.cancelled = { cancel.get() }
                e.findBestMove(snapshot, lim)
            }
            val elapsed = System.currentTimeMillis() - started
            if (elapsed < minDelay) delay(minDelay - elapsed)
            if (cancel.get() || session !== s || move == 0) {
                if (session === s) ui = ui.copy(thinking = false)
                return@launch
            }
            ui = ui.copy(thinking = false)
            playEngine(move)
        }
    }

    // ---- clocks ----

    private fun startClock() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            var last = System.nanoTime()
            while (true) {
                delay(100)
                val now = System.nanoTime()
                val dt = (now - last) / 1_000_000L
                last = now
                tickClock(dt)
            }
        }
    }

    private fun tickClock(dt: Long) {
        val s = session ?: return
        val c = clocks
        if (!c.enabled || s.isOver || s.records.size < 2) return
        var w = c.whiteMs
        var b = c.blackMs
        if (s.position.whiteToMove) w -= dt else b -= dt
        if (w <= 0L || b <= 0L) {
            clocks = c.copy(whiteMs = w.coerceAtLeast(0L), blackMs = b.coerceAtLeast(0L))
            s.timeout(whiteFlagged = w <= 0L)
            finishIfOver()
            return
        }
        clocks = c.copy(whiteMs = w, blackMs = b)
    }

    private fun addIncrement(whiteMoved: Boolean) {
        val inc = timeControl.incSec * 1000L
        if (!clocks.enabled || inc <= 0L) return
        clocks = if (whiteMoved) clocks.copy(whiteMs = clocks.whiteMs + inc) else clocks.copy(blackMs = clocks.blackMs + inc)
    }

    // ---- results & feedback ----

    private fun announce(rec: MoveRecord, s: GameSession) {
        val m = rec.move
        val sfx = when {
            s.position.inCheck() -> Sfx.CHECK
            movePromo(m) != 0 -> Sfx.PROMOTE
            moveFlag(m) == FLAG_CASTLE -> Sfx.CASTLE
            rec.captured != EMPTY -> Sfx.CAPTURE
            else -> Sfx.MOVE
        }
        sounds.play(sfx)
        haptics.tick(rec.captured != EMPTY || sfx == Sfx.CHECK)
    }

    private fun finishIfOver(): Boolean {
        val s = session ?: return false
        if (!s.isOver) return false
        engineCancel.set(true)
        engineJob?.cancel()
        val friend = gameKind == GameKind.FRIEND
        val humanWon = !friend && ((s.outcome == Outcome.WHITE_WINS && humanWhite) || (s.outcome == Outcome.BLACK_WINS && !humanWhite))
        val title = when {
            s.outcome == Outcome.DRAW -> "Hòa cờ"
            friend -> if (s.outcome == Outcome.WHITE_WINS) "Trắng thắng!" else "Đen thắng!"
            humanWon -> "Bạn thắng!"
            else -> "Bạn thua"
        }
        val detail = when (s.reason) {
            EndReason.CHECKMATE -> "Chiếu hết"
            EndReason.STALEMATE -> "Hết nước đi hợp lệ (hòa pat)"
            EndReason.INSUFFICIENT -> "Không đủ lực lượng để chiếu hết"
            EndReason.FIFTY -> "Luật 50 nước không bắt quân/đi tốt"
            EndReason.REPETITION -> "Lặp lại thế cờ 3 lần"
            EndReason.TIMEOUT -> if (s.outcome == Outcome.DRAW) "Hết giờ nhưng đối thủ không đủ lực lượng chiếu hết" else "Hết giờ"
            EndReason.RESIGN -> if (friend) {
                if (s.outcome == Outcome.WHITE_WINS) "Đen đã đầu hàng" else "Trắng đã đầu hàng"
            } else if (humanWon) {
                "Máy đầu hàng"
            } else {
                "Bạn đã đầu hàng"
            }
            EndReason.AGREEMENT -> "Hai bên đồng ý hòa"
            EndReason.NONE -> ""
        }
        refreshUi()
        ui = ui.copy(over = true, thinking = false, resultTitle = title, resultDetail = detail, draw = s.outcome == Outcome.DRAW, humanWon = humanWon, selected = -1, targets = emptySet())
        if (!resultAnnounced) {
            resultAnnounced = true
            sounds.play(Sfx.END)
            haptics.tick(true)
            enqueueSilentReview(s)
            val score = if (s.outcome == Outcome.DRAW) 0.5 else if (humanWon) 1.0 else 0.0
            if (gameKind == GameKind.BOT || gameKind == GameKind.TOURNAMENT) {
                val mode = modeFor(timeControl)
                val before = stats.rating(mode)
                stats = StatsStore.record(prefs, stats, mode, currentLevel.id, score)
                val diff = stats.rating(mode) - before
                val sign = if (diff >= 0) "+" else ""
                Toast.makeText(
                    getApplication<Application>(),
                    "Hệ số " + mode.label + ": " + stats.rating(mode) + " (" + sign + diff + ")",
                    Toast.LENGTH_SHORT,
                ).show()
            }
            if (gameKind == GameKind.TOURNAMENT && tournamentRound >= 0) {
                tournament = Tournament.record(tournament, tournamentRound, score)
                val e = prefs.edit()
                e.putString("tourney", Tournament.serialize(tournament))
                if (Tournament.nextRound(tournament) == -1) {
                    tournamentsDone += 1
                    e.putInt("tourneyDone", tournamentsDone)
                }
                e.apply()
            }
        }
        return true
    }

    /** Game Review Ngầm: giao FEN đầu ván + các nước UCI cho WorkManager; không hiện UI nào. */
    private fun enqueueSilentReview(s: GameSession) {
        if (s.records.size < 4) { reviewSkipReason = "Ván quá ngắn để phân tích (cần ít nhất 4 nước)."; return }
        // Phân quyền: Free/Gold chỉ review 1 ván/ngày, Platinum+ không giới hạn.
        val tier = MembershipStore.get(getApplication<Application>()).tier.value
        val usage = UsageTracker.get(getApplication<Application>())
        if (!usage.canUse(Quota.GAME_REVIEW, tier)) { reviewSkipReason = "Bạn đã dùng hết lượt Game Review hôm nay. Nâng cấp để xem không giới hạn."; return }
        try {
            usage.consume(Quota.GAME_REVIEW)
            val id = java.util.UUID.randomUUID().toString()
            GameReviewWorker.enqueueAnalysis(
                getApplication<Application>(), id,
                startFen, s.records.map { moveUci(it.move) },
            )
            lastReviewId = id
        } catch (_: Throwable) {
            // Review ngầm không bao giờ được làm hỏng ván cờ.
            reviewSkipReason = "Không thể bắt đầu phân tích lúc này."
        }
    }

    /** Từ hộp thoại tổng kết: về menu rồi mở thẳng màn chọn Bot mới (không đụng tới luồng Giải đấu). */
    fun openBotSetupFromResult() {
        backToHome()
        navigate(HomeRoute.BOT_SETUP)
    }

    // ---- toolbar actions ----

    fun flipBoard() {
        flipped = !flipped
        refreshUi(keepSelection = true)
    }

    fun undo() {
        val s = session ?: return
        if (s.isOver || !ui.canUndo) return
        engineCancel.set(true)
        engineJob?.cancel()
        val n = if (gameKind == GameKind.FRIEND) 1 else if (isHumanTurn(s)) 2 else 1
        repeat(n) { s.undo() }
        premove = null
        ui = ui.copy(thinking = false, promotion = null)
        refreshUi()
        startEngineIfNeeded()
    }

    fun resign() {
        val s = session ?: return
        if (s.isOver) return
        s.resign(if (gameKind == GameKind.FRIEND) s.position.whiteToMove else humanWhite)
        finishIfOver()
    }

    fun offerDraw() {
        val s = session ?: return
        if (s.isOver) return
        if (gameKind == GameKind.FRIEND) {
            s.agreeDraw()
            finishIfOver()
            return
        }
        val whiteToMove = s.position.whiteToMove
        val raw = Engine().evaluate(s.position)
        val engineScore = if (whiteToMove != humanWhite) raw else -raw
        if (s.records.size >= 20 && engineScore <= 30) {
            s.agreeDraw()
            finishIfOver()
        } else {
            val msg = if (s.records.size < 20) "Máy từ chối: còn quá sớm để hòa" else "Máy từ chối hòa"
            Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    // ---- UI snapshot ----

    private fun refreshUi(slides: List<Slide> = emptyList(), keepSelection: Boolean = false) {
        val s = session ?: return
        val pos = s.position
        val last = if (s.records.isEmpty()) -1 else s.records[s.records.size - 1].move
        val capW = s.capturedBy(true)
        val capB = s.capturedBy(false)
        var diff = 0
        for (p in capW) diff += pieceValue(pieceType(p))
        for (p in capB) diff -= pieceValue(pieceType(p))
        if (!keepSelection) hintCancel.set(true)
        val n = if (gameKind == GameKind.FRIEND) 1 else if (isHumanTurn(s)) 2 else 1
        val minRemain = if (engineMovesFirst) 1 else 0
        val pm = premove
        ui = ui.copy(
            board = pos.board.copyOf(),
            humanWhite = humanWhite,
            flipped = flipped,
            selected = if (keepSelection) ui.selected else -1,
            targets = if (keepSelection) ui.targets else emptySet(),
            lastFrom = if (last >= 0) moveFrom(last) else -1,
            lastTo = if (last >= 0) moveTo(last) else -1,
            checkSquare = if (pos.inCheck()) pos.kingSquare(pos.whiteToMove) else -1,
            premoveFrom = pm?.first ?: -1,
            premoveTo = pm?.second ?: -1,
            slides = slides,
            animToken = if (slides.isNotEmpty()) ui.animToken + 1 else ui.animToken,
            sans = s.records.map { it.san },
            whiteToMove = pos.whiteToMove,
            capturedByWhite = capW,
            capturedByBlack = capB,
            materialDiff = diff,
            canUndo = !s.isOver && s.records.size >= n && s.records.size - n >= minRemain,
            kind = gameKind,
            hintFrom = if (keepSelection) ui.hintFrom else -1,
            hintTo = if (keepSelection) ui.hintTo else -1,
            hintText = if (keepSelection) ui.hintText else "",
            hintBusy = if (keepSelection) ui.hintBusy else false
        )
    }

    fun levelName(): String = Levels.get(level).name

    fun opponentName(): String =
        if (gameKind == GameKind.TOURNAMENT) "Vòng " + (tournamentRound + 1) + "/" + Tournament.ROUNDS + " · Cấp " + currentLevel.id
        else "Máy · Cấp " + currentLevel.id

    fun pieceChoices(): IntArray = intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)
}
