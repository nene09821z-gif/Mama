package com.vila.chess.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.HOME_TIPS
import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.PaywallScreen
import com.vila.chess.billing.UpgradeBar
import com.vila.chess.billing.rememberTier
import com.vila.chess.game.HomeRoute
import com.vila.chess.game.Levels
import com.vila.chess.game.RatingMode
import com.vila.chess.game.StatsStore
import com.vila.chess.game.TimeControls
import com.vila.chess.game.achievements
import com.vila.chess.game.modeFor
import com.vila.chess.game.suggestLevel
import com.vila.chess.profile.EloHistoryStore
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.EloRange
import com.vila.chess.profile.EloSeries
import com.vila.chess.profile.UserSessionManager

private val PAGE_PADDING = 16.dp

@Composable
fun HomeScreen(vm: GameViewModel) {
    // Học xong một bài thực hành (đấu Bot) thì quay lại đúng tab "Học" thay vì về Trang chủ.
    var tab by remember { mutableIntStateOf(if (vm.consumeReturnToLessons()) 2 else 0) }
    var showStats by remember { mutableStateOf(false) }
    var showTips by remember { mutableStateOf(false) }
    var showAchievements by remember { mutableStateOf(false) }
    var lessonPlaying by remember { mutableStateOf(false) }   // đang giải bài chiến thuật ⇒ ẩn thanh điều hướng
    var puzzleSolving by remember { mutableStateOf(false) }   // đang ở màn giải đố ⇒ ẩn thanh điều hướng để tập trung
    val ctx = LocalContext.current
    val route = vm.route
    // Mục đã chạy hiệu ứng hiện dần: đổi tab / cuộn không chạy lại, chỉ chạy khi quay về Trang chủ từ ván cờ.
    val seen = remember { mutableSetOf<Int>() }

    BackHandler(enabled = route != HomeRoute.HOME || tab != 0) {
        when (route) {
            HomeRoute.HOME -> tab = 0
            HomeRoute.NEW_GAME -> vm.navigate(HomeRoute.HOME)
            HomeRoute.BOT_SETUP -> vm.navigate(HomeRoute.NEW_GAME)
            HomeRoute.BOT_SELECT -> vm.navigate(HomeRoute.NEW_GAME)
            HomeRoute.ACCOUNT -> vm.navigate(HomeRoute.HOME)
            HomeRoute.TOURNAMENT -> vm.navigate(HomeRoute.NEW_GAME)
            HomeRoute.ONLINE -> {
                vm.cancelOnlineSearch()
                vm.navigate(HomeRoute.NEW_GAME)
            }
            HomeRoute.PAYWALL -> vm.navigate(HomeRoute.HOME)
            HomeRoute.PREFERENCES -> vm.navigate(HomeRoute.HOME)
            HomeRoute.PROFILE -> vm.navigate(HomeRoute.HOME)
            HomeRoute.ARCHIVE -> vm.navigate(HomeRoute.HOME)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        SpaceBackground()
        // Chuyển màn mượt: vào màn con thì trượt từ phải + mờ dần, quay về thì ngược lại.
        AnimatedContent(
            targetState = route,
            transitionSpec = {
                val forward = targetState != HomeRoute.HOME
                val dx = { w: Int -> if (forward) w / 5 else -w / 5 }
                (slideInHorizontally(tween(240)) { dx(it) } + fadeIn(tween(240))) togetherWith
                    (slideOutHorizontally(tween(240)) { -dx(it) } + fadeOut(tween(160)))
            },
            label = "homeRoute",
        ) { r ->
        Box(modifier = Modifier.fillMaxSize()) {
        when (r) {
            HomeRoute.NEW_GAME -> NewGameScreen(vm = vm, onBack = { vm.navigate(HomeRoute.HOME) })
            HomeRoute.BOT_SELECT -> BotSelectionScreen(vm = vm, onBack = { vm.navigate(HomeRoute.NEW_GAME) })
            HomeRoute.BOT_SETUP -> SetupScreen(vm = vm, onBack = { vm.navigate(HomeRoute.NEW_GAME) }, title = "Chơi với Bot")
            HomeRoute.TOURNAMENT -> TournamentScreen(vm = vm, onBack = { vm.navigate(HomeRoute.NEW_GAME) })
            HomeRoute.ONLINE -> OnlineLobbyScreen(vm = vm, onBack = {
                vm.cancelOnlineSearch()
                vm.navigate(HomeRoute.NEW_GAME)
            })
            HomeRoute.ARCHIVE -> GameArchiveScreen(vm = vm, onBack = { vm.navigate(HomeRoute.HOME) })
            HomeRoute.PAYWALL -> PaywallScreen(onBack = { vm.navigate(HomeRoute.HOME) })
            HomeRoute.ACCOUNT -> AccountScreen(onBack = { vm.navigate(HomeRoute.HOME) })
            HomeRoute.PREFERENCES -> PreferencesScreen(vm = vm, onBack = { vm.navigate(HomeRoute.HOME) })
            // Hồ sơ: profileUserId == null → của mình; khác null → hồ sơ đầy đủ của đối thủ/bạn bè
            HomeRoute.PROFILE -> MyProfileScreen(
                vm = vm,
                userId = vm.profileUserId,
                onBack = { vm.navigate(HomeRoute.HOME) },
                onOpenProfile = { id -> vm.openProfile(id) },
            )
            HomeRoute.HOME -> {
                val inset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                val dockHeight = NAV_HEIGHT + inset + (if (tab == 0) PLAY_AREA_HEIGHT else 0.dp)
                Box(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
                    when (tab) {
                        0 -> HomeTab(
                            vm = vm,
                            bottomPad = dockHeight,
                            seen = seen,
                            onOpenSettings = { vm.openProfile(null) },
                            onOpenFriends = { tab = 3 },
                            onOpenLessons = { tab = 2 },
                            onShowStats = { showStats = true },
                            onShowAchievements = { showAchievements = true },
                            onOpenPaywall = { vm.navigate(HomeRoute.PAYWALL) },
                            onBell = {
                                vm.markTipsSeen()
                                showTips = true
                            },
                            onStreak = {
                                val n = vm.stats.activeStreak(StatsStore.today())
                                val msg = if (n > 0) {
                                    "Chuỗi " + n + " ngày chơi liên tiếp"
                                } else {
                                    "Chơi một ván hôm nay để bắt đầu chuỗi ngày"
                                }
                                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                            },
                            onCoach = {
                                val on = !vm.coachOn
                                vm.setCoach(on)
                                val msg = if (on) "Đã bật huấn luyện viên: chạm Gợi ý trong ván để xem nước tốt nhất" else "Đã tắt huấn luyện viên"
                                Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                            },
                            onShare = { shareApp(ctx) },
                        )
                        1 -> PuzzleTab(dockHeight, images = vm.pieceImages, onSolvingChange = { puzzleSolving = it })
                        2 -> LessonsTab(
                            vm = vm,
                            bottomPad = dockHeight,
                            onPlayingChange = { lessonPlaying = it },
                            onUpgrade = { vm.navigate(HomeRoute.PAYWALL) },
                        )
                        3 -> FriendsTab(vm, dockHeight, onShare = { shareApp(ctx) }, onViewProfile = { id -> vm.openProfile(id) })
                        else -> MoreTab(
                            bottomPad = dockHeight,
                            onUpgrade = { vm.navigate(HomeRoute.PAYWALL) },
                            onStats = { showStats = true },
                            onGames = { vm.navigate(HomeRoute.ARCHIVE) },
                            onAchievements = { showAchievements = true },
                            onFriends = { tab = 3 },
                            onPreferences = { vm.navigate(HomeRoute.PREFERENCES) },
                            onAccount = { vm.navigate(HomeRoute.ACCOUNT) },
                            onProfile = { vm.openProfile(null) },
                            onShare = { shareApp(ctx) },
                        )
                    }
                }
                if (!(tab == 1 && puzzleSolving) && !(tab == 2 && lessonPlaying)) {
                    HomeDock(
                        showPlay = tab == 0,
                        selected = tab,
                        onSelect = { tab = it },
                        onPlay = { vm.navigate(HomeRoute.NEW_GAME) },
                        modifier = Modifier.align(Alignment.BottomCenter),
                    )
                }
            }
        }
        }
        }
    }

    if (showStats) {
        StatsDialog(vm = vm, onDismiss = { showStats = false })
    }
    if (showTips) {
        TipsDialog(onDismiss = { showTips = false })
    }
    if (showAchievements) {
        AchievementsDialog(vm = vm, onDismiss = { showAchievements = false })
    }
}

private fun shareApp(ctx: Context) {
    val send = Intent(Intent.ACTION_SEND)
    send.type = "text/plain"
    send.putExtra(Intent.EXTRA_TEXT, "Chơi cờ vua cùng mình trên ViLa Chess nhé!")
    try {
        ctx.startActivity(Intent.createChooser(send, "Mời bạn bè"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Không mở được hộp chia sẻ", Toast.LENGTH_SHORT).show()
    }
}

// =============================================================================
// Home tab
// =============================================================================

@Composable
private fun HomeTab(
    vm: GameViewModel,
    bottomPad: Dp,
    seen: MutableSet<Int>,
    onOpenSettings: () -> Unit,
    onOpenFriends: () -> Unit,
    onOpenLessons: () -> Unit,
    onShowStats: () -> Unit,
    onShowAchievements: () -> Unit,
    onOpenPaywall: () -> Unit,
    onBell: () -> Unit,
    onStreak: () -> Unit,
    onCoach: () -> Unit,
    onShare: () -> Unit,
) {
    val images = vm.pieceImages
    val stats = vm.stats
    val timeControl = TimeControls.get(vm.timeIndex)
    val mode = modeFor(timeControl)
    val suggested = suggestLevel(stats.rating(mode))
    var suggestionHidden by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    // Xu hướng Elo thật (7 ngày gần nhất) + đường biểu đồ nhỏ cho từng thể loại
    val trends = remember(stats.ratings) {
        val all = try { EloHistoryStore(ctx).loadAll() } catch (_: Exception) { emptyMap() }
        val now = System.currentTimeMillis()
        RatingMode.values().associateWith { m ->
            val em = EloMode.values().firstOrNull { it.name == m.name }
            val hist = if (em != null) all[em].orEmpty() else emptyList()
            val cur = stats.rating(m)
            val week = EloSeries.window(hist, EloRange.WEEK, now, cur)
            val month = EloSeries.window(hist, EloRange.MONTH, now, cur)
            val delta = if (week.size >= 2) week.last().rating - week.first().rating else 0
            delta to month.map { it.rating }
        }
    }
    val heroPager = rememberPagerState(initialPage = 0) { 2 }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 6.dp, bottom = bottomPad + 12.dp),
    ) {
        item(key = "header") {
            HomeHeader(
                name = UserSessionManager.displayName,
                avatarKey = UserSessionManager.avatarKey,
                streak = stats.activeStreak(StatsStore.today()),
                bellCount = vm.tipsUnread,
                friendsCount = 0,
                onAvatar = onOpenSettings,
                onStreak = onStreak,
                onDiamond = onOpenPaywall,
                onFriends = onOpenFriends,
                onBell = onBell,
                modifier = Modifier.staggerIn(0, seen),
            )
        }
        item(key = "hero") {
            Column(modifier = Modifier.padding(top = 14.dp).staggerIn(1, seen)) {
                HorizontalPager(
                    state = heroPager,
                    modifier = Modifier.fillMaxWidth().height(172.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    pageSpacing = 10.dp,
                ) { page ->
                    if (page == 0) {
                        LearnCard(onStart = onOpenLessons, modifier = Modifier.fillMaxSize())
                    } else {
                        CoachCard(on = vm.coachOn, onClick = onCoach, modifier = Modifier.fillMaxSize())
                    }
                }
                HeroDots(count = 2, current = heroPager.currentPage, modifier = Modifier.padding(top = 10.dp))
            }
        }
        if (!suggestionHidden) {
            item(key = "suggestedTitle") {
                SectionHeader("Trận đấu đề nghị", Modifier.padding(top = 18.dp).staggerIn(2, seen))
            }
            item(key = "suggestedCard") {
                SuggestedGameCard(
                    avatar = images[10],
                    title = "Cấp " + suggested + " · " + Levels.get(suggested).name,
                    timeLabel = timeControl.label,
                    onPlay = {
                        vm.updateLevel(suggested)
                        vm.startGame()
                    },
                    onDismiss = { suggestionHidden = true },
                    modifier = Modifier.padding(top = 12.dp).staggerIn(3, seen),
                )
            }
        }
        item(key = "premiumBanner") {
            val tier = rememberTier()
            if (tier == MembershipTier.FREE) {
                UpgradeBar(
                    text = "Nâng cấp ChessPlus: bỏ quảng cáo, Game Review không giới hạn",
                    onUpgrade = { vm.navigate(HomeRoute.PAYWALL) },
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 25.dp).staggerIn(4, seen),
                )
            }
        }
        item(key = "ratingTitle") {
            SectionHeader("Hệ số", Modifier.padding(top = 22.dp).staggerIn(5, seen), action = "Xem hết", onAction = onShowStats)
        }
        item(key = "ratings") {
            LazyRow(
                modifier = Modifier.padding(top = 10.dp).staggerIn(6, seen),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(RatingMode.values().toList(), key = { it.ordinal }) { m ->
                    val t = trends[m]
                    RatingTile(
                        mode = m,
                        rating = stats.rating(m),
                        onClick = onShowStats,
                        delta = t?.first ?: 0,
                        history = t?.second ?: emptyList(),
                    )
                }
            }
        }
        item(key = "friendsTitle") {
            SectionHeader("Bạn bè", Modifier.padding(top = 22.dp).staggerIn(7, seen))
        }
        item(key = "friends") {
            LazyRow(
                modifier = Modifier.padding(top = 10.dp).staggerIn(8, seen),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item(key = "invite") {
                    FriendCard("Mời bạn bè", "Chia sẻ ViLa Chess", BenefitKind.INVITE, showPlus = false, onClick = onShare)
                }
                item(key = "local") {
                    FriendCard("Chơi với bạn", "Chung một máy", BenefitKind.DUEL, showPlus = true, onClick = { vm.startFriendGame() })
                }
                item(key = "tournament") {
                    FriendCard("Giải đấu", "8 vòng với Bot", BenefitKind.TROPHY, showPlus = true, onClick = { vm.navigate(HomeRoute.TOURNAMENT) })
                }
            }
        }
    }
}

// =============================================================================
// Other tabs
// =============================================================================

@Composable
private fun FriendsTab(vm: GameViewModel, bottomPad: Dp, onShare: () -> Unit, onViewProfile: (String) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = PAGE_PADDING, end = PAGE_PADDING, top = 16.dp, bottom = bottomPad + 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(key = "title") {
            Text("Bạn bè", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        item(key = "local") {
            GlassSection("CHƠI VỚI BẠN") {
                Text(
                    text = "Hai người chơi chung một máy: lượt nào quân đó, có đồng hồ và phong cấp.",
                    color = VilaColors.TextDim,
                    fontSize = 14.sp,
                )
                ChunkyButton(
                    text = "Chơi ngay",
                    onClick = { vm.startFriendGame() },
                    modifier = Modifier.fillMaxWidth(),
                    height = 46.dp,
                    fontSize = 18.sp,
                )
            }
        }
        item(key = "invite") {
            GlassSection("MỜI BẠN BÈ") {
                Text(
                    text = "Gửi ViLa Chess cho bạn bè để cùng chơi cờ.",
                    color = VilaColors.TextDim,
                    fontSize = 14.sp,
                )
                ChunkyButton(text = "Mời bạn bè", onClick = onShare, modifier = Modifier.fillMaxWidth(), height = 46.dp, fontSize = 18.sp)
            }
        }
        // Danh sách bạn bè (Supabase) — tên kèm huy hiệu VIP; chạm để xem hồ sơ nhanh
        item(key = "friendList") {
            GlassSection("DANH SÁCH BẠN BÈ") {
                FriendsPanel(onViewProfile = onViewProfile)
            }
        }
    }
}

// =============================================================================
// Dialogs
// =============================================================================

private val DIALOG_BG = Color(0xFF16233B)

@Composable
private fun StatsDialog(vm: GameViewModel, onDismiss: () -> Unit) {
    val s = vm.stats
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DIALOG_BG,
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(16.dp),
        title = { Text("Hệ số của bạn", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (m in RatingMode.values()) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(m.label, modifier = Modifier.weight(1f), fontSize = 15.sp)
                        Text(s.rating(m).toString(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Số ván: " + s.played + " · Thắng " + s.won + " · Hòa " + s.drawn + " · Thua " + s.lost,
                    fontSize = 13.sp,
                )
                Text(
                    text = "Chuỗi ngày chơi: " + s.activeStreak(StatsStore.today()),
                    fontSize = 13.sp,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.Bold)
            }
        },
    )
}

@Composable
private fun AchievementsDialog(vm: GameViewModel, onDismiss: () -> Unit) {
    val list = achievements(vm.stats, vm.tournamentsDone, StatsStore.today())
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DIALOG_BG,
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(16.dp),
        title = { Text("Thành tích (" + list.count { it.done } + "/" + list.size + ")", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (a in list) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (a.done) "✓" else "○",
                            color = if (a.done) VilaColors.Green else VilaColors.TextDim,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.width(26.dp),
                        )
                        Column {
                            Text(
                                text = a.title,
                                color = if (a.done) Color.White else VilaColors.TextDim,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(a.desc, fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.Bold)
            }
        },
    )
}

@Composable
private fun TipsDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DIALOG_BG,
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BellIcon(Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Text("Thông báo", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            }
        },
        text = {
            if (HOME_TIPS.isEmpty()) {
                Text("Chưa có thông báo nào.", fontSize = 14.sp)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (tip in HOME_TIPS) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0x26FFFFFF))
                                .padding(12.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 5.dp)
                                    .size(8.dp)
                                    .background(VilaColors.Green, CircleShape),
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.weight(1f)) {
                                Text(tip.first, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                                Text(tip.second, fontSize = 13.sp, lineHeight = 18.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold)
            }
        },
    )
}
