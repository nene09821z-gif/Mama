package com.vila.chess

import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.findMoveBySan
import com.vila.chess.core.moveUci
import com.vila.chess.review.EngineResult
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import com.vila.chess.review.ReviewAnalyzer
import com.vila.chess.review.ReviewAnalyzer.MoveFacts
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewReplay
import com.vila.chess.review.SacrificeDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ReviewAnalyzerTest {

    private fun facts(
        loss: Double = 0.0, best: Boolean = false, book: Boolean = false, sac: Boolean = false,
        before: Double = 50.0, after: Double = 50.0, gap: Double? = null,
        recapture: Boolean = false, oppLoss: Double? = null,
    ) = MoveFacts(loss, best, book, { sac }, before, after, gap, recapture, oppLoss)

    @Test
    fun lossThresholds() {
        assertEquals(MoveLabel.EXCELLENT, ReviewAnalyzer.labelByLoss(0.0))
        assertEquals(MoveLabel.EXCELLENT, ReviewAnalyzer.labelByLoss(1.99))
        assertEquals(MoveLabel.GOOD, ReviewAnalyzer.labelByLoss(2.0))
        assertEquals(MoveLabel.GOOD, ReviewAnalyzer.labelByLoss(4.99))
        assertEquals(MoveLabel.INACCURACY, ReviewAnalyzer.labelByLoss(5.0))
        assertEquals(MoveLabel.INACCURACY, ReviewAnalyzer.labelByLoss(9.99))
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.labelByLoss(10.0))
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.labelByLoss(20.0))
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(20.01))
    }

    @Test
    fun bookBeatsEverything() {
        assertEquals(MoveLabel.BOOK, ReviewAnalyzer.classify(facts(loss = 50.0, book = true)))
    }

    @Test
    fun bestAndGreat() {
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, gap = 3.0)))
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, gap = null)))
        assertEquals(MoveLabel.GREAT, ReviewAnalyzer.classify(facts(best = true, gap = 25.0)))
        // ăn lại quân hiển nhiên không phải Great
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, gap = 60.0, recapture = true)))
        // không phải nước tốt nhất thì không bao giờ Great
        assertEquals(MoveLabel.EXCELLENT, ReviewAnalyzer.classify(facts(loss = 1.0, gap = 60.0)))
    }

    @Test
    fun brilliantNeedsSacrificeAndSafeContext() {
        assertEquals(MoveLabel.BRILLIANT, ReviewAnalyzer.classify(facts(best = true, sac = true, before = 55.0, after = 55.0)))
        // đã thắng đậm sẵn -> không Brilliant
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, sac = true, before = 96.0, after = 96.0)))
        // hy sinh xong thế xấu -> không Brilliant
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, sac = true, before = 30.0, after = 30.0)))
        // mất > 2% thì không Brilliant
        assertEquals(MoveLabel.GOOD, ReviewAnalyzer.classify(facts(loss = 3.0, sac = true)))
    }

    @Test
    fun missAfterOpponentError() {
        assertEquals(MoveLabel.MISS, ReviewAnalyzer.classify(facts(loss = 12.0, before = 75.0, after = 63.0, oppLoss = 25.0)))
        // đối thủ không sai -> theo EP loss
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.classify(facts(loss = 12.0, before = 75.0, after = 63.0, oppLoss = 3.0)))
        // sụp thành thế thua -> Blunder, không phải Miss
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.classify(facts(loss = 60.0, before = 90.0, after = 30.0, oppLoss = 25.0)))
        // mất ít (< 5%) -> không Miss
        assertEquals(MoveLabel.GOOD, ReviewAnalyzer.classify(facts(loss = 3.0, before = 75.0, after = 72.0, oppLoss = 25.0)))
        // nước tốt nhất luôn là Best dù đối thủ vừa sai
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(facts(best = true, before = 75.0, after = 75.0, oppLoss = 25.0)))
    }

    // ------------------------------------------------------------ hy sinh quân

    @Test
    fun queenForPawnIsSacrifice() {
        // Hậu ăn tốt d5 bị tốt c6 ăn lại: cho đi 800.
        val fen = "4k3/8/2p5/3p4/8/8/3Q4/4K3 w - - 0 1"
        assertTrue(SacrificeDetector.isSacrifice(fen, "d2d5"))
        assertFalse(SacrificeDetector.isSacrifice(fen, "d2d3"))
    }

    @Test
    fun freeCaptureAndAbandonedHangingPieceAreNotSacrifices() {
        // Ăn tốt không ai bảo vệ: không phải hy sinh.
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/8/3p4/8/8/3Q4/4K3 w - - 0 1", "d2d5"))
        // Hậu đang bị tốt e5 treo từ trước; đi vua chỗ khác không bị tính là "hy sinh hậu".
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/8/4p3/3Q4/8/8/4K3 w - - 0 1", "e1f1"))
        // Đổi xe lấy mã (mất 180 < 200): đổi chất, không phải hy sinh.
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/2p5/3n4/8/8/3R4/4K3 w - - 0 1", "d2d5"))
        // Xe ăn tốt bị bảo vệ (mất 400): là hy sinh.
        assertTrue(SacrificeDetector.isSacrifice("4k3/8/2p5/3p4/8/8/3R4/4K3 w - - 0 1", "d2d5"))
    }

    // ------------------------------------------------------------ SAN + khai cuộc

    @Test
    fun sanParser() {
        val p = Position.start()
        assertEquals("e2e4", moveUci(findMoveBySan(p, "e4")!!))
        assertEquals("g1f3", moveUci(findMoveBySan(p, "Nf3")!!))
        assertNull(findMoveBySan(p, "Nf6"))
        assertNull(findMoveBySan(p, "e5"))
        val castle = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        assertEquals("e1g1", moveUci(findMoveBySan(castle, "O-O")!!))
        assertEquals("e1c1", moveUci(findMoveBySan(castle, "O-O-O+")!!))
        // hai xe cùng tới d1: thiếu gợi ý thì mơ hồ (null), có gợi ý thì đúng quân
        val two = Position.fromFen("4k3/8/8/8/8/8/4K3/R6R w - - 0 1")
        assertNull(findMoveBySan(two, "Rd1"))
        assertEquals("a1d1", moveUci(findMoveBySan(two, "Rad1")!!))
        assertEquals("h1d1", moveUci(findMoveBySan(two, "Rhd1")!!))
        // phong cấp
        val promo = Position.fromFen("8/4P2k/8/8/8/8/8/4K3 w - - 0 1")
        assertEquals("e7e8q", moveUci(findMoveBySan(promo, "e8=Q")!!).lowercase())
        assertEquals("e7e8n", moveUci(findMoveBySan(promo, "e8=N")!!).lowercase())
    }

    @Test
    fun builtInBookParsesEveryLine() {
        val book = OpeningBook.fromBuiltIn()
        assertEquals(OpeningBook.BUILT_IN.size, book.lineCount)
    }

    @Test
    fun bookLookupNamesAndPrefixes() {
        val book = OpeningBook.fromBuiltIn()
        val najdorf = ReviewReplay.replay(START_FEN, listOf("e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3", "a7a6"))!!
        val hit = book.lookup(najdorf.plies.last().fenAfter)
        assertNotNull(hit)
        assertEquals("B90", hit!!.eco)
        assertTrue(hit.name.contains("Najdorf"))
        // thế trung gian có tên chung của dòng ngắn nhất
        assertEquals("B20", book.lookup(najdorf.plies[1].fenAfter)!!.eco)
        assertEquals("B00", book.lookup(najdorf.plies[0].fenAfter)!!.eco)
        // thế lạ không có tên
        val odd = ReviewReplay.replay(START_FEN, listOf("a2a3", "a7a6", "h2h3"))!!
        assertNull(book.lookup(odd.plies.last().fenAfter))
    }

    @Test
    fun tsvParsingAcceptsLichessFormat() {
        val tsv = listOf(
            "eco\tname\tpgn",
            "C20\tKing's Pawn Game\t1. e4 e5",
            "C40\tKing's Knight Opening\t1. e4 e5 2. Nf3",
            "X99\tGhi sai\t1. e4 e5 2. Nf6",
            "",
        )
        val book = OpeningBook.fromTsv(tsv.asSequence())
        assertEquals(2, book.lineCount)
        val r = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5", "g1f3"))!!
        assertEquals("C40", book.lookup(r.plies[2].fenAfter)!!.eco)
        assertEquals("C20", book.lookup(r.plies[1].fenAfter)!!.eco)
    }

    // ------------------------------------------------------------ ráp cả ván

    private fun ev(best: String?, cp: Int, second: String? = null, secondCp: Int? = null) = EngineResult(
        bestMove = best, scoreCp = cp, mate = null, depthReached = 14, timedOut = false,
        pv = listOfNotNull(best), secondMove = second, secondCp = secondCp, secondMate = null,
        engine = "native", multiPv = 2,
    )

    @Test
    fun bookMovesAreLabelledAndNamed() {
        val replay = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5", "g1f3", "a7a6"))!!
        val evals = listOf(ev("e2e4", 30), ev("e7e5", -30), ev("g1f3", 30), ev("b8c6", -40), ev("f1c4", 20))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L, OpeningBook.fromBuiltIn())
        assertEquals(listOf(MoveLabel.BOOK, MoveLabel.BOOK, MoveLabel.BOOK), r.moves.take(3).map { it.label })
        assertEquals("C40", r.moves[2].ecoCode)
        assertEquals(0.0, r.moves[0].winLoss, 0.0)
        // 2...a6 rời sổ khai cuộc: không còn Book, nhưng vẫn giữ tên khai cuộc cuối cùng
        assertTrue(r.moves[3].label != MoveLabel.BOOK)
        assertEquals("C40", r.moves[3].ecoCode)
        // không truyền book -> không có Book
        val nb = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertTrue(nb.moves.none { it.label == MoveLabel.BOOK })
    }

    @Test
    fun greatWhenOnlyMove() {
        val replay = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5"))!!
        val evals = listOf(ev("e2e4", 30, "a2a3", -200), ev("e7e5", -30), ev("g1f3", 30))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertEquals(MoveLabel.GREAT, r.moves[0].label)
        assertEquals(MoveLabel.BEST, r.moves[1].label)
    }

    @Test
    fun missAfterBlunder() {
        val replay = ReviewReplay.replay(START_FEN, listOf("f2f3", "e7e6"))!!
        // Trắng f3 (thế sau: Đen hơn 300), Đen đáng ra đi e5 nhưng đi e6 (Trắng +90 => Đen -90).
        val evals = listOf(ev("e2e4", 30), ev("e7e5", 300), ev("e2e4", 90))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertEquals(MoveLabel.BLUNDER, r.moves[0].label)
        assertEquals(MoveLabel.MISS, r.moves[1].label)
    }

    @Test
    fun equalSecondBestCountsAsBest() {
        val replay = ReviewReplay.replay(START_FEN, listOf("d2d4", "d7d5"))!!
        val evals = listOf(ev("e2e4", 30, "d2d4", 29), ev("d7d5", -30), ev("c2c4", 30))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        // d4 ngang điểm với nước tốt nhất (chênh < 0,25%) => vẫn là Best
        assertEquals(MoveLabel.BEST, r.moves[0].label)
        assertTrue(r.moves[0].winLoss < 0.25)
    }
}

/**
 * Nhãn theo luật Chess.com (Brilliant xét nước thay thế) + luật mate của Lichess.
 * Ván mẫu = chiếu hết bí (smothered mate) 10.Re1? Nf2+ 11.Kg1 Nh3+ 12.Kh1 Qg1+!! 13.Rxg1 Nf2#.
 */
class ReviewMateRulesTest {

    private val startFen = "r1b1kb1r/p1p1pppp/2p5/8/3q2n1/8/PPPN2PP/RNBQ1R1K w kq - 0 10"
    private val ucis = listOf("f1e1", "g4f2", "h1g1", "f2h3", "g1h1", "d4g1", "e1g1", "h3f2")

    private fun ev(
        best: String?, cp: Int, mate: Int? = null,
        second: String? = null, secondCp: Int? = null,
    ) = EngineResult(
        bestMove = best, scoreCp = if (mate != null && mate != 0) (if (mate > 0) 10_000 - 10 * mate else -10_000 - 10 * mate) else cp,
        mate = mate, depthReached = 18, timedOut = false, pv = listOfNotNull(best),
        secondMove = second, secondCp = secondCp, secondMate = null, engine = "native", multiPv = 2,
    )

    /** evals như Stockfish MultiPV 2 trả về (góc nhìn bên đang đi). [whiteCpBeforeRe1] = cp của Trắng trước 10.Re1. */
    private fun smotheredEvals(whiteCpBeforeRe1: Int, secondCpAtQg1: Int) = listOf(
        ev("d1f3", whiteCpBeforeRe1, second = "d2f3", secondCp = whiteCpBeforeRe1 - 20),
        ev("g4f2", 0, mate = 4, second = "d4f2", secondCp = 800),
        ev("h1g1", 0, mate = -3),
        ev("f2h3", 0, mate = 3, second = "d4g1", secondCp = 600),
        ev("g1h1", 0, mate = -2),
        ev("d4g1", 0, mate = 2, second = "d4d2", secondCp = secondCpAtQg1),
        ev("e1g1", 0, mate = -1),
        ev("h3f2", 0, mate = 1, second = "h3g1", secondCp = -300),
        EngineResult(null, -10_000, 0, 0, false, engine = "rules"),
    )

    private fun review(whiteCpBeforeRe1: Int, secondCpAtQg1: Int): List<MoveLabel> {
        val replay = ReviewReplay.replay(startFen, ucis)!!
        val r = ReviewAssembler.assemble("t", replay.startFen, replay.plies, smotheredEvals(whiteCpBeforeRe1, secondCpAtQg1), "x", 0L)
        return r.moves.map { it.label }
    }

    // ---- sàn mate của Lichess ----

    @Test
    fun mateCreatedFloorFollowsLichessCutoffs() {
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(0)))
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(-500)))
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(-700)))
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(-701)))
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(-999)))
        assertEquals(MoveLabel.INACCURACY, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateCreatedFloor(-1000)))
    }

    @Test
    fun mateLostFloorFollowsLichessCutoffs() {
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateLostFloor(0)))
        assertEquals(MoveLabel.BLUNDER, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateLostFloor(700)))
        assertEquals(MoveLabel.MISTAKE, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateLostFloor(701)))
        assertEquals(MoveLabel.INACCURACY, ReviewAnalyzer.labelByLoss(ReviewAnalyzer.mateLostFloor(1000)))
    }

    @Test
    fun mateRuleFloorCases() {
        // không liên quan mate
        assertEquals(0.0, ReviewAnalyzer.mateRuleFloor(null, 50, null, 40), 0.0)
        // đi vào thế bị mate từ thế -5
        assertEquals(ReviewAnalyzer.FLOOR_BLUNDER, ReviewAnalyzer.mateRuleFloor(null, -500, -4, -9960), 0.0)
        // đã bị mate sẵn (mate âm) mà đi nước khác: không phạt thêm
        assertEquals(0.0, ReviewAnalyzer.mateRuleFloor(-3, -9970, -2, -9980), 0.0)
        // đang có mate, mất mate, còn +3 => Blunder
        assertEquals(ReviewAnalyzer.FLOOR_BLUNDER, ReviewAnalyzer.mateRuleFloor(3, 9970, null, 300), 0.0)
        // đang có mate, chiếu hết luôn (mate sau = 0) hoặc mate chậm hơn: không phạt
        assertEquals(0.0, ReviewAnalyzer.mateRuleFloor(1, 9990, 0, 10_000), 0.0)
        assertEquals(0.0, ReviewAnalyzer.mateRuleFloor(2, 9980, 3, 9970), 0.0)
        // đang có mate, đi sai thành bị mate ngược
        assertEquals(ReviewAnalyzer.FLOOR_BLUNDER, ReviewAnalyzer.mateRuleFloor(2, 9980, -2, -9980), 0.0)
    }

    @Test
    fun allowingMateFromPlayableEvalIsBlunderNotMistake() {
        // Trước 10.Re1 Trắng -5.0 (win% ≈ 13,6): theo win% thuần chỉ là Mistake (loss 13,6) nhưng Lichess gọi là Blunder.
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.BLUNDER, labels[0])
    }

    @Test
    fun allowingMateWhenAlreadyHopelessIsOnlyInaccuracy() {
        val labels = review(whiteCpBeforeRe1 = -1200, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.INACCURACY, labels[0])
    }

    @Test
    fun smotheredMateQueenSacIsBrilliantWhenAlternativesDoNotWin() {
        // Hậu hy sinh 12...Qg1+!! : nước tốt nhì chỉ +3,5 (win% ≈ 78 < 85) => "không thắng đậm nếu không tìm ra nước này".
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.BRILLIANT, labels[5])
        // các nước ép buộc / đáp trả thường vẫn là Best
        assertEquals(MoveLabel.BEST, labels[1])
        assertEquals(MoveLabel.BEST, labels[2])
        assertEquals(MoveLabel.BEST, labels[6])
    }

    @Test
    fun noBrilliantWhenAlternativeAlsoWinsBig() {
        // Nước tốt nhì cũng +9 (win% ≈ 96): đã thắng đậm sẵn dù không có Qg1+ => chỉ là Best.
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 900)
        assertEquals(MoveLabel.BEST, labels[5])
    }

    @Test
    fun brilliantUsesAlternativeWinNotBestWin() {
        fun f(alt: Double?) = ReviewAnalyzer.MoveFacts(
            loss = 0.0, playedIsBest = true, inBook = false, isSacrifice = { true },
            winBefore = 100.0, winAfter = 100.0, gapToSecond = null, isRecapture = false,
            opponentPrevLoss = null, winIfNotPlayed = alt,
        )
        assertEquals(MoveLabel.BRILLIANT, ReviewAnalyzer.classify(f(60.0)))
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(f(90.0)))
        // không biết nước thay thế (không có MultiPV) => dùng win% trước nước đi => không Brilliant
        assertEquals(MoveLabel.BEST, ReviewAnalyzer.classify(f(null)))
    }

    @Test
    fun bestMoveIsNeverPenalisedByMateFloor() {
        // Mọi nước đều thua: nước engine chọn (kéo dài nhất) không bị sàn mate phạt.
        val replay = ReviewReplay.replay(startFen, ucis.take(1))!!
        val evals = listOf(ev("f1e1", -9990, mate = -5), ev("g4f2", 0, mate = 4))
        val r = ReviewAssembler.assemble("t", replay.startFen, replay.plies, evals, "x", 0L)
        assertEquals(0.0, r.moves[0].winLoss, 0.0)
    }
}
