package com.vila.chess.review

import com.vila.chess.core.Position
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveUci

/** Một nước đi đã dựng lại từ ván: UCI, SAN và FEN trước/sau. */
data class ReplayPly(val uci: String, val san: String, val fenBefore: String, val fenAfter: String)

data class ReplayResult(val startFen: String, val plies: List<ReplayPly>)

/** Hàm thuần (không Android, không engine): dựng lại ván và ráp dữ liệu review. */
object ReviewReplay {
    const val QUEUE_HEADER = "#v2"

    /** File hàng đợi: dòng 1 = "#v2", dòng 2 = FEN đầu ván, các dòng sau = nước đi UCI. */
    fun encodeQueue(startFen: String, ucis: List<String>): String =
        (listOf(QUEUE_HEADER, startFen) + ucis).joinToString("\n")

    /** Đọc file hàng đợi. Cũng đọc được định dạng cũ (mỗi dòng là một FEN). null nếu hỏng. */
    fun parseQueue(rawLines: List<String>): ReplayResult? {
        val lines = rawLines.map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        return runCatching {
            if (lines[0] == QUEUE_HEADER) {
                if (lines.size < 2) null else replay(lines[1], lines.drop(2))
            } else {
                replayFromFens(lines)
            }
        }.getOrNull()
    }

    fun replay(startFen: String, ucis: List<String>): ReplayResult? {
        val pos = Position.fromFen(startFen)
        val start = pos.fen()
        val out = ArrayList<ReplayPly>(ucis.size)
        for (uci in ucis) {
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci } ?: return null
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    /** Định dạng hàng đợi cũ: tìm nước đi nối từng cặp FEN liên tiếp. */
    private fun replayFromFens(fens: List<String>): ReplayResult? {
        val pos = Position.fromFen(fens[0])
        val start = pos.fen()
        val out = ArrayList<ReplayPly>()
        for (i in 1 until fens.size) {
            val target = key(fens[i])
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { m ->
                pos.make(m)
                val hit = key(pos.fen()) == target
                pos.unmake()
                hit
            } ?: return null
            val uci = moveUci(mv)
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    private fun key(fen: String) = fen.trim().split(Regex("\\s+")).take(4).joinToString(" ")

    /**
     * Thế đã kết thúc ván (chiếu hết, hết nước đi = hòa, không đủ quân chiếu) thì tính bằng luật cờ,
     * không hỏi engine. Điểm theo góc nhìn bên đang đi. Chiếu hết: mate = 0, cp = -10000.
     */
    fun terminalEval(fen: String): EngineResult? {
        val pos = Position.fromFen(fen)
        return when {
            pos.legalMoves().isEmpty() ->
                if (pos.inCheck()) EngineResult(null, -10_000, 0, 0, false, engine = MoveReview.ENGINE_RULES)
                else EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            pos.insufficientMaterial() ->
                EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            else -> null
        }
    }
}

object ReviewAssembler {

    /** Tăng khi cách phân loại thay đổi: kết quả cũ hơn bị coi là chưa phân tích (xem ReviewRepository). */
    const val ANALYSIS_VERSION = ReviewJson.CURRENT_VERSION

    /**
     * evals[i] = kết quả phân tích thế SAU i nước (evals[0] = thế đầu ván), tức evals.size == plies.size + 1.
     * Điểm trong evals là góc nhìn bên đang đi; ở đây đổi hết sang góc nhìn Trắng.
     * [book] = sổ khai cuộc (null = không gán Book / tên khai cuộc). Chỉ dùng khi ván bắt đầu từ thế cờ chuẩn.
     */
    fun assemble(
        gameId: String,
        startFen: String,
        plies: List<ReplayPly>,
        evals: List<EngineResult>,
        tier: String,
        createdAt: Long,
        book: OpeningBook? = null,
    ): GameReview {
        require(evals.size == plies.size + 1) { "evals phải nhiều hơn plies đúng 1 phần tử" }

        fun fenAt(i: Int) = if (i == 0) (plies.firstOrNull()?.fenBefore ?: startFen) else plies[i - 1].fenAfter
        fun whiteToMoveAt(i: Int) = fenAt(i).split(' ').getOrNull(1) != "b"

        val cpWhite = IntArray(evals.size) { i -> (if (whiteToMoveAt(i)) 1 else -1) * evals[i].scoreCp }
        val mateWhite = Array(evals.size) { i ->
            evals[i].mate?.let { m -> if (m == 0) 0 else (if (whiteToMoveAt(i)) m else -m) }
        }

        val useBook = book != null && OpeningBook.positionKey(fenAt(0)) == OpeningBook.START_KEY
        var inBookChain = useBook
        var lastOpening: OpeningInfo? = null

        val moves = ArrayList<MoveReview>(plies.size)
        val accDrops = ArrayList<Double>(plies.size)   // Win% bên đi đã mất (chuẩn Lichess) để tính độ chính xác
        for (i in 1..plies.size) {
            val p = plies[i - 1]
            val before = evals[i - 1]
            val whiteMoved = whiteToMoveAt(i - 1)
            val sign = if (whiteMoved) 1 else -1
            // Góc nhìn BÊN VỪA ĐI: nhân sign cho cả cp lẫn mate (mate == 0 giữ nguyên, bên thắng suy từ dấu cp).
            fun moverWin(k: Int) = ReviewClassifier.winPct(
                sign * cpWhite[k],
                mateWhite[k]?.let { m -> if (m == 0) 0 else sign * m },
            )
            val winBefore = moverWin(i - 1)     // = win% của nước TỐT NHẤT (engine tìm ở thế trước)
            val winAfter = moverWin(i)

            // Nước tốt nhì (MultiPV 2): cùng một lượt tìm kiếm với nước tốt nhất => so sánh sạch, không nhiễu độ sâu.
            val secondWin = if (before.secondMove != null && before.secondCp != null) {
                ReviewClassifier.winPct(before.secondCp, before.secondMate)
            } else null
            val gapToSecond = secondWin?.let { (winBefore - it).coerceAtLeast(0.0) }

            // EP loss theo lượt tìm kiếm ở thế SAU (sâu hơn 1 nước nên đáng tin hơn khi hai lượt mâu thuẫn).
            val lossAfter = (winBefore - winAfter).coerceAtLeast(0.0)
            // "Trùng Best Move" chỉ tính khi hai lượt tìm kiếm không mâu thuẫn nặng (nhiễu độ sâu ≤ ngưỡng Inaccuracy).
            val consistent = lossAfter < ReviewAnalyzer.INACCURACY_BELOW
            val playedIsBest = consistent && before.bestMove != null && before.bestMove == p.uci
            val tieWithBest = consistent && !playedIsBest && before.secondMove == p.uci &&
                gapToSecond != null && gapToSecond <= ReviewAnalyzer.BEST_TIE_EPS

            // Đi đúng nước tốt nhì: có HAI ước lượng độc lập (cùng lượt tìm kiếm = gap, và lượt tìm ở thế sau) -> lấy trung bình cho bớt nhiễu.
            val playedIsSecond = !playedIsBest && !tieWithBest && before.secondMove == p.uci && gapToSecond != null
            var loss = when {
                playedIsBest -> 0.0
                tieWithBest -> gapToSecond ?: 0.0
                playedIsSecond -> ((gapToSecond ?: lossAfter) + lossAfter) / 2.0
                else -> lossAfter
            }

            // Luật mate của Lichess (Advice.scala) áp thêm làm "sàn" cho EP loss: win% bão hòa ở 0/100 nên đi vào thế bị chiếu hết
            // (win% X -> 0) hay bỏ lỡ chiếu hết (100 -> ~96) bị chấm quá nhẹ. Nước tốt nhất của engine thì không bao giờ bị phạt.
            if (!playedIsBest && !tieWithBest) {
                val moverMateBefore = before.mate
                val moverMateAfter = evals[i].mate?.let { m -> if (m == 0) 0 else -m }   // đổi sang góc nhìn bên vừa đi
                val floor = ReviewAnalyzer.mateRuleFloor(
                    mateBefore = moverMateBefore,
                    cpBefore = before.scoreCp,
                    mateAfter = moverMateAfter,
                    cpAfter = -evals[i].scoreCp,
                )
                if (floor > loss) loss = floor
            }

            // Book: thế SAU nước đi còn nằm trong sổ, và mọi nước trước đó cũng vậy.
            var inBook = false
            if (useBook && inBookChain) {
                val hit = book!!.lookup(p.fenAfter)
                if (hit != null) { inBook = true; lastOpening = hit } else inBookChain = false
            }
            if (inBook) loss = 0.0   // lý thuyết khai cuộc không bị trừ điểm chính xác

            // Điểm chính xác theo Lichess: Win% (mate = ±1000cp) trước/sau nước đi. Đi đúng nước tốt nhất của engine hoặc nước trong sổ khai cuộc = không mất gì.
            val wb = LichessAccuracy.winWhitePct(cpWhite[i - 1], mateWhite[i - 1])
            val wa = LichessAccuracy.winWhitePct(cpWhite[i], mateWhite[i])
            val moverDrop = if (whiteMoved) wb - wa else wa - wb
            accDrops += if (playedIsBest || tieWithBest || inBook) 0.0 else moverDrop.coerceAtLeast(0.0)

            val prev = moves.lastOrNull()
            val prevPly = plies.getOrNull(i - 2)
            val isRecapture = prevPly != null && prevPly.san.contains('x') && p.san.contains('x') &&
                prevPly.uci.substring(2, 4) == p.uci.substring(2, 4)

            val label = ReviewAnalyzer.classify(
                ReviewAnalyzer.MoveFacts(
                    loss = loss,
                    playedIsBest = playedIsBest || tieWithBest,
                    inBook = inBook,
                    isSacrifice = { SacrificeDetector.isSacrifice(p.fenBefore, p.uci) },
                    winBefore = winBefore,
                    winAfter = winAfter,
                    gapToSecond = gapToSecond,
                    isRecapture = isRecapture,
                    opponentPrevLoss = prev?.winLoss,
                    // "Dù không tìm ra nước này thì mình còn thắng đậm không?": đã đi nước tốt nhất -> nhìn nước tốt nhì; ngược lại nước tốt nhất là phương án thay thế.
                    winIfNotPlayed = if (playedIsBest) secondWin else winBefore,
                ),
            )
            moves += MoveReview(
                ply = i,
                whiteMoved = whiteMoved,
                label = label,
                winLoss = loss,
                evalAfterCpWhite = cpWhite[i],
                bestMoveBefore = before.bestMove,
                uci = p.uci,
                san = p.san,
                fenBefore = p.fenBefore,
                fenAfter = p.fenAfter,
                evalBeforeCpWhite = cpWhite[i - 1],
                mateBeforeWhite = mateWhite[i - 1],
                mateAfterWhite = mateWhite[i],
                pv = before.pv,
                depthBefore = before.depthReached,
                depthAfter = evals[i].depthReached,
                secondBestMove = before.secondMove,
                secondBestCpWhite = before.secondCp?.let { sign * it },
                secondBestMateWhite = before.secondMate?.let { m -> if (m == 0) 0 else sign * m },
                engine = before.engine,
                multiPv = before.multiPv,
                ecoCode = lastOpening?.eco,
                openingName = lastOpening?.name,
            )
        }

        val winSeries = List(evals.size) { LichessAccuracy.winWhitePct(cpWhite[it], mateWhite[it]) }
        val (accW, accB) = LichessAccuracy.gameAccuracy(winSeries, accDrops, moves.map { it.whiteMoved })

        val main = evals.firstOrNull { it.engine != MoveReview.ENGINE_RULES }
        return GameReview(
            gameId = gameId,
            moves = moves,
            accuracyWhite = accW,
            accuracyBlack = accB,
            tier = tier,
            createdAt = createdAt,
            startFen = startFen,
            engine = main?.engine ?: "none",
            multiPv = main?.multiPv ?: 1,
        )
    }
}


/**
 * Chọn các thế cờ cần tìm kiếm lại SÂU HƠN (vòng kiểm chứng) sau lượt phân tích đầu.
 * Chỉ những nước nghi sai (không phải nước tốt nhất mà mất >= [SUSPECT_LOSS]% win) mới đáng tốn thêm thời gian:
 * kết luận Mistake/Blunder/Miss dựa trên số liệu sâu hơn nên ít bị "oan" do nhiễu độ sâu. Hàm thuần, test được trên JVM.
 */
object ReviewVerify {
    const val SUSPECT_LOSS = 6.0
    const val MAX_PLIES = 8   // tối đa 8 nước x 2 thế = 16 lượt tìm kiếm thêm

    /** Chỉ số thế (0..plies.size) cần tìm lại, tăng dần, không trùng. Thế kết thúc ván (engine = rules) bị bỏ qua. */
    fun suspectPositions(plies: List<ReplayPly>, evals: List<EngineResult>, maxPlies: Int = MAX_PLIES): List<Int> {
        if (evals.size != plies.size + 1) return emptyList()
        val scored = ArrayList<Pair<Int, Double>>()
        for (i in 1..plies.size) {
            val before = evals[i - 1]
            val after = evals[i]
            if (before.engine == MoveReview.ENGINE_RULES) continue
            if (before.bestMove == null || before.bestMove == plies[i - 1].uci) continue
            val winBefore = ReviewClassifier.winPct(before.scoreCp, before.mate)
            // Thế sau do đối thủ đi => đảo góc nhìn về bên vừa đi.
            val winAfter = ReviewClassifier.winPct(-after.scoreCp, after.mate?.let { m -> if (m == 0) 0 else -m })
            // Liên quan mate (đi vào thế bị mate / bỏ lỡ mate) cũng đáng tìm lại sâu hơn vì sàn Lichess có thể nâng nhãn lên Blunder.
            val mateFloor = ReviewAnalyzer.mateRuleFloor(
                mateBefore = before.mate,
                cpBefore = before.scoreCp,
                mateAfter = after.mate?.let { m -> if (m == 0) 0 else -m },
                cpAfter = -after.scoreCp,
            )
            val loss = maxOf(winBefore - winAfter, mateFloor)
            if (loss >= SUSPECT_LOSS) scored += i to loss
        }
        return scored.sortedByDescending { it.second }
            .take(maxPlies)
            .flatMap { (i, _) -> listOf(i - 1, i) }
            .filter { evals[it].engine != MoveReview.ENGINE_RULES }
            .distinct()
            .sorted()
    }
}
