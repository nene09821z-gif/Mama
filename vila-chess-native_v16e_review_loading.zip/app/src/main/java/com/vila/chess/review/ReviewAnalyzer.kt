package com.vila.chess.review

import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.Position
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveTo
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveUci
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue

/**
 * Phân loại nước đi thành 10 nhãn. Hàm thuần (không Android, không engine) -> test được trên JVM.
 *
 * Mọi con số "%" là EP loss = phần trăm xác suất thắng (win%) bên vừa đi đã mất so với nước tốt nhất của engine.
 *
 * Thứ tự ưu tiên:
 *  1. BOOK       — thế sau nước đi nằm trong sổ khai cuộc (và mọi nước trước đó cũng vậy).
 *  2. BRILLIANT  — hy sinh quân thật sự (mất ≥ 2 tốt vật chất sau khi đổi quân dứt điểm) mà EP loss < 2%,
 *                  thế sau vẫn không xấu (win% sau ≥ 40) và — đúng định nghĩa của Chess.com — "không thắng đậm
 *                  ngay cả khi KHÔNG tìm ra nước này": win% của nước thay thế tốt nhất ≤ 85
 *                  (nước tốt nhì nếu đã đi nước tốt nhất; nếu engine không có nước tốt nhì thì dùng win% trước nước đi).
 *  3. GREAT      — là nước tốt nhất VÀ nước tốt nhì kém hơn ≥ 15% (gần như nước duy nhất), thế còn chơi được
 *                  (win% ≥ 30), không phải ăn lại quân hiển nhiên.
 *  4. BEST       — trùng nước tốt nhất của engine (hoặc nước tốt nhì ngang điểm, chênh ≤ 0,25%).
 *  5. MISS       — đối thủ vừa đi sai (EP loss ≥ 10%), nước này mất ≥ 5% (không tận dụng) nhưng thế vẫn chưa xấu (win% sau ≥ 40).
 *  6. Còn lại theo EP loss: EXCELLENT < 2 · GOOD 2–5 · INACCURACY 5–10 · MISTAKE 10–20 · BLUNDER > 20.
 */
object ReviewAnalyzer {

    // ---- ngưỡng EP loss (điểm %) ----
    const val EXCELLENT_BELOW = 2.0
    const val GOOD_BELOW = 5.0
    const val INACCURACY_BELOW = 10.0
    const val MISTAKE_MAX = 20.0

    // ---- ngưỡng cho nhãn đặc biệt ----
    const val BRILLIANT_MIN_SACRIFICE_CP = 200
    /** Win% tối đa của nước thay thế tốt nhất: cao hơn = "đã thắng đậm sẵn dù không tìm ra nước này" => không Brilliant. */
    const val BRILLIANT_MAX_WIN_ALT = 85.0
    const val BRILLIANT_MIN_WIN_AFTER = 40.0
    const val GREAT_MIN_GAP = 15.0
    const val GREAT_MIN_WIN = 30.0
    const val BEST_TIE_EPS = 0.25
    const val MISS_OPPONENT_MIN_LOSS = 10.0
    const val MISS_MIN_LOSS = 5.0
    const val MISS_MIN_WIN_AFTER = 40.0
    // ---- luật chiếu hết của Lichess (lila Advice.scala): mate không đo bằng win% mà bằng cp "bên đi" đang có ----
    const val MATE_BIG_ADVANTAGE_CP = 700      // hơn/kém ≥ 7 tốt: sai lầm liên quan mate chỉ còn Mistake
    const val MATE_HUGE_ADVANTAGE_CP = 999     // hơn/kém ≥ ~10 tốt: chỉ còn Inaccuracy
    /** EP loss "sàn" tương ứng từng nhãn (labelByLoss(sàn) trả đúng nhãn đó). */
    const val FLOOR_INACCURACY = INACCURACY_BELOW / 2     // 5.0
    const val FLOOR_MISTAKE = INACCURACY_BELOW            // 10.0
    const val FLOOR_BLUNDER = MISTAKE_MAX + 0.01          // 20.01

    /**
     * Đi vào thế bị chiếu hết cưỡng bức (trước đó chưa bị mate). [prevCp] = cp của BÊN ĐI trước nước đi.
     * Lichess: ≥ -7 tốt => Blunder; -7…-10 => Mistake; thế vốn đã thua nặng (< -10) => Inaccuracy.
     */
    fun mateCreatedFloor(prevCp: Int): Double = when {
        prevCp < -MATE_HUGE_ADVANTAGE_CP -> FLOOR_INACCURACY
        prevCp < -MATE_BIG_ADVANTAGE_CP -> FLOOR_MISTAKE
        else -> FLOOR_BLUNDER
    }

    /**
     * Bỏ lỡ chiếu hết (đang có mate mà thế sau không còn mate). [nextCp] = cp của BÊN ĐI sau nước đi.
     * Lichess: vẫn hơn ≤ 7 tốt => Blunder; 7…10 => Mistake; hơn > 10 tốt => Inaccuracy.
     */
    fun mateLostFloor(nextCp: Int): Double = when {
        nextCp > MATE_HUGE_ADVANTAGE_CP -> FLOOR_INACCURACY
        nextCp > MATE_BIG_ADVANTAGE_CP -> FLOOR_MISTAKE
        else -> FLOOR_BLUNDER
    }

    /**
     * EP loss tối thiểu theo luật mate của Lichess cho một nước đi KHÔNG phải nước tốt nhất; 0 nếu không liên quan mate.
     * Tất cả theo góc nhìn BÊN ĐI. [mateBefore] = mate trước nước đi (dương = bên đi sắp chiếu hết, âm = sắp bị chiếu hết, null = không),
     * [cpBefore] = cp trước nước đi, [mateAfter] = mate sau nước đi (0 = bên đi vừa chiếu hết), [cpAfter] = cp sau nước đi.
     */
    fun mateRuleFloor(mateBefore: Int?, cpBefore: Int, mateAfter: Int?, cpAfter: Int): Double = when {
        // đang có mate -> giờ bị mate ngược lại: luôn Blunder
        mateBefore != null && mateBefore > 0 && mateAfter != null && mateAfter < 0 -> FLOOR_BLUNDER
        // đang có mate -> mất mate (không bị mate ngược)
        mateBefore != null && mateBefore > 0 && mateAfter == null -> mateLostFloor(cpAfter)
        // chưa bị mate -> tự đưa mình vào thế bị mate
        mateBefore == null && mateAfter != null && mateAfter < 0 -> mateCreatedFloor(cpBefore)
        else -> 0.0
    }

    /** Mọi dữ kiện cần để gán nhãn một nước đi. Win% đều theo góc nhìn BÊN VỪA ĐI. */
    data class MoveFacts(
        val loss: Double,
        val playedIsBest: Boolean,
        val inBook: Boolean,
        /** Chỉ được gọi khi các điều kiện rẻ của BRILLIANT đã đạt (tránh tính vật chất cho mọi nước). */
        val isSacrifice: () -> Boolean,
        val winBefore: Double,
        val winAfter: Double,
        /** win%(nước tốt nhất) − win%(nước tốt nhì). null = engine không chạy MultiPV (wasm) hoặc chỉ có 1 nước hợp lệ. */
        val gapToSecond: Double?,
        val isRecapture: Boolean,
        /** EP loss của nước đối thủ vừa đi trước đó. null = nước đầu tiên của ván. */
        val opponentPrevLoss: Double?,
        /**
         * win%(bên đi) của nước THAY THẾ tốt nhất nếu KHÔNG đi nước này: nước tốt nhì khi đã đi nước tốt nhất,
         * ngược lại là win% của nước tốt nhất. null = không biết (engine không có nước tốt nhì) -> dùng [winBefore].
         * Dùng cho điều kiện "không thắng đậm sẵn dù không tìm ra nước này" của Brilliant.
         */
        val winIfNotPlayed: Double? = null,
    )

    /** Chỉ theo EP loss (không ngữ cảnh). BEST/BOOK/... không xuất hiện ở đây. */
    fun labelByLoss(loss: Double): MoveLabel = when {
        loss < EXCELLENT_BELOW -> MoveLabel.EXCELLENT
        loss < GOOD_BELOW -> MoveLabel.GOOD
        loss < INACCURACY_BELOW -> MoveLabel.INACCURACY
        loss <= MISTAKE_MAX -> MoveLabel.MISTAKE
        else -> MoveLabel.BLUNDER
    }

    fun classify(f: MoveFacts): MoveLabel {
        if (f.inBook) return MoveLabel.BOOK

        if (f.loss < EXCELLENT_BELOW &&
            (f.winIfNotPlayed ?: f.winBefore) <= BRILLIANT_MAX_WIN_ALT &&
            f.winAfter >= BRILLIANT_MIN_WIN_AFTER &&
            f.isSacrifice()
        ) return MoveLabel.BRILLIANT

        val gap = f.gapToSecond
        if (f.playedIsBest && gap != null && gap >= GREAT_MIN_GAP &&
            f.winBefore >= GREAT_MIN_WIN && !f.isRecapture
        ) return MoveLabel.GREAT

        if (f.playedIsBest) return MoveLabel.BEST

        val opp = f.opponentPrevLoss
        if (opp != null && opp >= MISS_OPPONENT_MIN_LOSS &&
            f.loss >= MISS_MIN_LOSS && f.winAfter >= MISS_MIN_WIN_AFTER
        ) return MoveLabel.MISS

        return labelByLoss(f.loss)
    }
}

/**
 * Nhận diện hy sinh quân bằng "vật chất sau khi đổi quân dứt điểm" (quiescence chỉ xét nước ăn quân).
 *
 *   S0 = vật chất của bên đi nếu họ "bỏ lượt" (đối thủ ăn tự do những gì ăn được)
 *   S1 = vật chất của bên đi sau khi đi nước m rồi hai bên ăn qua lại đến khi yên
 *   hy sinh = S0 − S1   (≥ ~2 tốt = đã cho đi quân)
 *
 * So với S0 (chứ không phải vật chất tĩnh) để quân đang bị treo từ trước mà bỏ mặc KHÔNG bị tính là hy sinh.
 */
object SacrificeDetector {
    private const val INF = 1_000_000
    private const val MAX_Q_PLY = 10

    /** Số centipawn bên đi cho đi bởi nước [uci] ở thế [fenBefore]. ≤ 0 = không hy sinh. */
    fun materialSacrificed(fenBefore: String, uci: String): Int {
        val pos = Position.fromFen(fenBefore)
        val mover = pos.whiteToMove
        val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci } ?: return 0

        val s0 = if (pos.inCheck()) {
            material(pos)
        } else {
            val pass = pos.copy()
            pass.whiteToMove = !mover
            pass.epSquare = -1
            -qs(pass, -INF, INF, MAX_Q_PLY)
        }
        pos.make(mv)
        val s1 = -qs(pos, -INF, INF, MAX_Q_PLY)
        return s0 - s1
    }

    fun isSacrifice(fenBefore: String, uci: String): Boolean =
        materialSacrificed(fenBefore, uci) >= ReviewAnalyzer.BRILLIANT_MIN_SACRIFICE_CP

    /** Vật chất theo góc nhìn bên ĐANG ĐI của [pos] (tốt 100, mã 320, tượng 330, xe 500, hậu 900). */
    private fun material(pos: Position): Int {
        var white = 0
        var black = 0
        for (sq in 0 until 64) {
            val pc = pos.board[sq]
            if (pc == EMPTY) continue
            val v = pieceValue(pieceType(pc))
            if (isWhitePiece(pc)) white += v else black += v
        }
        return if (pos.whiteToMove) white - black else black - white
    }

    private fun isCapture(pos: Position, m: Int): Boolean =
        pos.board[moveTo(m)] != EMPTY || moveFlag(m) == FLAG_EP

    private fun qs(pos: Position, alpha0: Int, beta: Int, depth: Int): Int {
        var alpha = alpha0
        val stand = material(pos)
        if (depth <= 0 || stand >= beta) return stand
        if (stand > alpha) alpha = stand
        val caps = pos.legalMoves().filter { isCapture(pos, it) }
            .sortedByDescending { m ->
                val victim = if (moveFlag(m) == FLAG_EP) 100 else pieceValue(pieceType(pos.board[moveTo(m)]))
                victim * 10 + movePromo(m)
            }
        for (m in caps) {
            pos.make(m)
            val score = -qs(pos, -beta, -alpha, depth - 1)
            pos.unmake()
            if (score >= beta) return score
            if (score > alpha) alpha = score
        }
        return alpha
    }
}
