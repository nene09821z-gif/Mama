package com.vila.chess.review

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.exp

enum class MoveLabel { BEST, EXCELLENT, GOOD, INACCURACY, MISTAKE, BLUNDER }

/** ply 1 = nước đi đầu tiên của ván. winLoss = % xác suất thắng mất đi (0–100). */
data class MoveReview(
    val ply: Int,
    val whiteMoved: Boolean,
    val label: MoveLabel,
    val winLoss: Double,
    val evalAfterCpWhite: Int,
    val bestMoveBefore: String?,
)

data class GameReview(
    val gameId: String,
    val moves: List<MoveReview>,
    val accuracyWhite: Double,
    val accuracyBlack: Double,
    val tier: String,
    val createdAt: Long,
)

object ReviewClassifier {
    /** Công thức win% kiểu Lichess từ centipawn (góc nhìn bên đang xét). */
    fun winPct(cp: Int): Double {
        val c = cp.coerceIn(-1000, 1000)
        return 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * c)) - 1.0)
    }

    // Ngưỡng là giả định của mình — chỉnh lại theo mức bạn đã bàn.
    fun classify(loss: Double): MoveLabel = when {
        loss <= 2.0 -> MoveLabel.BEST
        loss <= 5.0 -> MoveLabel.EXCELLENT
        loss <= 10.0 -> MoveLabel.GOOD
        loss <= 20.0 -> MoveLabel.INACCURACY
        loss <= 30.0 -> MoveLabel.MISTAKE
        else -> MoveLabel.BLUNDER
    }

    fun moveAccuracy(loss: Double): Double =
        (103.1668 * exp(-0.04354 * loss) - 3.1669).coerceIn(0.0, 100.0)
}

class GameReviewStore(context: Context) {
    private val dir = File(context.filesDir, "reviews").apply { mkdirs() }
    private fun file(id: String) = File(dir, "${id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}.json")

    fun exists(gameId: String) = file(gameId).exists()

    fun save(r: GameReview) {
        val arr = JSONArray()
        r.moves.forEach { m ->
            arr.put(
                JSONObject()
                    .put("ply", m.ply).put("white", m.whiteMoved).put("label", m.label.name)
                    .put("loss", m.winLoss).put("eval", m.evalAfterCpWhite)
                    .put("best", m.bestMoveBefore ?: JSONObject.NULL)
            )
        }
        val json = JSONObject()
            .put("gameId", r.gameId).put("accW", r.accuracyWhite).put("accB", r.accuracyBlack)
            .put("tier", r.tier).put("createdAt", r.createdAt).put("moves", arr)
        // Ghi tạm rồi đổi tên: không bao giờ để file review dở dang.
        val target = file(r.gameId)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(json.toString())
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    fun load(gameId: String): GameReview? {
        val f = file(gameId)
        if (!f.exists()) return null
        return runCatching {
            val j = JSONObject(f.readText())
            val a = j.getJSONArray("moves")
            val moves = (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                MoveReview(
                    o.getInt("ply"), o.getBoolean("white"), MoveLabel.valueOf(o.getString("label")),
                    o.getDouble("loss"), o.getInt("eval"),
                    if (o.isNull("best")) null else o.getString("best"),
                )
            }
            GameReview(
                j.getString("gameId"), moves, j.getDouble("accW"), j.getDouble("accB"),
                j.getString("tier"), j.getLong("createdAt"),
            )
        }.getOrNull()
    }
}
