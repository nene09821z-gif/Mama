package com.vila.chess.review

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class GameReviewWorker(
    ctx: Context,
    params: WorkerParameters,
) : CoroutineWorker(ctx, params) {

    companion object {
        private const val KEY_GAME_ID = "gameId"

        private fun queueFile(context: Context, gameId: String) =
            File(File(context.filesDir, "review_queue").apply { mkdirs() }, "$gameId.txt")

        /**
         * Gọi khi ván kết thúc. FEN được ghi ra file thay vì nhét vào inputData vì Data của
         * WorkManager giới hạn 10KB (~140 FEN) — ván dài sẽ crash.
         *
         * KHÔNG gọi setExpedited(): không có hàm "setExpedited(false)", cách tắt là không gọi nó,
         * nên work chạy ở mức ưu tiên thường, nhường tài nguyên cho app đang mở.
         */
        fun enqueueAnalysis(context: Context, gameId: String, fens: List<String>) {
            val app = context.applicationContext
            queueFile(app, gameId).writeText(fens.joinToString("\n"))

            // WorkManager chỉ có AND giữa các constraint. "BatteryNotLow" (mức hệ thống ~15%)
            // tự được bỏ qua khi đang sạc, nên tương đương "đang sạc HOẶC pin > 15%".
            val constraints = Constraints.Builder().setRequiresBatteryNotLow(true).build()

            val req = OneTimeWorkRequestBuilder<GameReviewWorker>()
                .setInputData(workDataOf(KEY_GAME_ID to gameId))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(app)
                .enqueueUniqueWork("game_review_$gameId", ExistingWorkPolicy.KEEP, req)
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.Default) {
        val gameId = inputData.getString(KEY_GAME_ID) ?: return@withContext Result.failure()
        val store = GameReviewStore(applicationContext)
        if (store.exists(gameId)) return@withContext Result.success()

        val qf = queueFile(applicationContext, gameId)
        if (!qf.exists()) return@withContext Result.failure()
        val fens = qf.readLines().filter { it.isNotBlank() }
        if (fens.size < 2) { qf.delete(); return@withContext Result.success() }

        val config = DeviceTierManager.getDeviceTier(applicationContext)
        val monitor = DeviceHealthMonitor(applicationContext)
        val engine = SilentStockfishEngine(applicationContext, config)

        try {
            val evalWhite = IntArray(fens.size)
            val best = arrayOfNulls<String>(fens.size)

            for ((i, fen) in fens.withIndex()) {
                ensureActive()
                // Nóng > 40°C: stop + giải phóng engine, chờ 1 phút/lượt. Quá 5 lượt -> retry sau.
                val cool = monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })
                if (!cool) return@withContext Result.retry()

                val r = engine.analyzeSilently(fen, config.depth)
                val whiteToMove = fen.split(' ').getOrNull(1) != "b"
                evalWhite[i] = if (whiteToMove) r.scoreCp else -r.scoreCp
                best[i] = r.bestMove
            }

            val moves = ArrayList<MoveReview>()
            for (i in 1 until fens.size) {
                val whiteMoved = fens[i - 1].split(' ').getOrNull(1) != "b"
                val sign = if (whiteMoved) 1 else -1
                val before = ReviewClassifier.winPct(sign * evalWhite[i - 1])
                val after = ReviewClassifier.winPct(sign * evalWhite[i])
                val loss = (before - after).coerceAtLeast(0.0)
                moves += MoveReview(
                    ply = i, whiteMoved = whiteMoved, label = ReviewClassifier.classify(loss),
                    winLoss = loss, evalAfterCpWhite = evalWhite[i], bestMoveBefore = best[i - 1],
                )
            }
            fun acc(white: Boolean) = moves.filter { it.whiteMoved == white }
                .map { ReviewClassifier.moveAccuracy(it.winLoss) }
                .let { if (it.isEmpty()) 100.0 else it.average() }

            store.save(
                GameReview(gameId, moves, acc(true), acc(false), config.tier.name, System.currentTimeMillis())
            )
            qf.delete()
            Result.success()
        } catch (e: IllegalStateException) {
            // Thiếu libstockfish.so hoặc engine không khởi động: retry vô ích.
            Result.failure()
        } finally {
            engine.shutdown() // stop -> quit -> destroy
        }
    }
}
