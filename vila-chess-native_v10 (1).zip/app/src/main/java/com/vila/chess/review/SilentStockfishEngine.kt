package com.vila.chess.review

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** scoreCp luôn tính theo góc nhìn BÊN ĐANG ĐI của FEN được phân tích. */
data class EngineResult(
    val bestMove: String?,
    val scoreCp: Int,
    val mate: Int?,
    val depthReached: Int,
    val timedOut: Boolean,
)

/**
 * Engine không giao diện, hai backend theo thứ tự ưu tiên:
 *  1. NATIVE: libstockfish.so (Stockfish bản đầy đủ) chạy bằng ProcessBuilder từ nativeLibraryDir.
 *  2. WASM:   Stockfish 19 lite trong WebView ẩn (dự phòng khi không có/không chạy được bản native).
 * close() giải phóng hoàn toàn (stop -> quit -> destroy); analyze sau đó tự khởi động lại.
 */
class SilentStockfishEngine(
    context: Context,
    private val config: EngineConfig,
) : AutoCloseable {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()
    private var transport: Transport? = null
    private var lines: Channel<String> = Channel(Channel.UNLIMITED)

    /** "native", "wasm" hoặc "none": để log/gỡ lỗi. */
    @Volatile var backendName: String = "none"
        private set

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        const val BASE = "https://$HOST/assets/stockfish/"
        const val MAX_WASM_HASH_MB = 32
        val SCORE = Regex("""\bscore (cp|mate) (-?\d+)""")
        val DEPTH = Regex("""\bdepth (\d+)""")
        val BEST = Regex("""^bestmove (\S+)""")
    }

    // ---------- Transport ----------

    private abstract class Transport(val ch: Channel<String>, val isNative: Boolean) {
        abstract fun send(cmd: String)
        abstract fun close()
    }

    private class NativeTransport(ch: Channel<String>, private val process: Process) :
        Transport(ch, true) {
        private val writer: BufferedWriter = process.outputStream.bufferedWriter()

        init {
            Thread {
                try {
                    process.inputStream.bufferedReader().forEachLine { ch.trySend(it) }
                } catch (_: IOException) {
                } finally {
                    ch.close()
                }
            }.apply { isDaemon = true }.start()
        }

        @Synchronized
        override fun send(cmd: String) {
            runCatching { writer.write(cmd); writer.newLine(); writer.flush() }
        }

        override fun close() {
            send("stop"); send("quit")
            runCatching {
                if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroy()
                process.destroy()
                if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroyForcibly()
            }
            runCatching { writer.close() }
        }
    }

    private class WebTransport(
        ch: Channel<String>,
        val view: WebView,
        private val main: Handler,
    ) : Transport(ch, false) {
        override fun send(cmd: String) {
            val js = "send(" + JSONObject.quote(cmd) + ");"
            main.post { view.evaluateJavascript(js, null) }
        }

        override fun close() {
            main.post {
                view.evaluateJavascript("try{send('stop');send('quit');}catch(e){}", null)
                main.postDelayed({
                    view.loadUrl("about:blank")
                    view.removeJavascriptInterface("Bridge")
                    view.destroy()
                }, 300)
            }
        }
    }

    private inner class Bridge(private val ch: Channel<String>) {
        @JavascriptInterface
        fun line(s: String) { ch.trySend(s) }
    }

    private suspend fun createNative(): Transport? = withContext(Dispatchers.IO) {
        val bin = File(app.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!bin.exists()) return@withContext null
        try {
            val p = ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
            NativeTransport(Channel(Channel.UNLIMITED), p)
        } catch (_: Exception) {
            null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun createWeb(): Transport? = withContext(Dispatchers.Main) {
        try {
            val ch = Channel<String>(Channel.UNLIMITED)
            val wv = WebView(app)
            wv.settings.javaScriptEnabled = true
            wv.settings.allowFileAccess = false
            wv.settings.allowContentAccess = false
            wv.addJavascriptInterface(Bridge(ch), "Bridge")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest,
                ): WebResourceResponse? {
                    val u = request.url
                    if (u.host != HOST) return null
                    val name = u.lastPathSegment ?: return null
                    val mime = when {
                        name.endsWith(".html") -> "text/html"
                        name.endsWith(".js") -> "text/javascript"
                        name.endsWith(".wasm") -> "application/wasm"
                        else -> "application/octet-stream"
                    }
                    return try {
                        WebResourceResponse(mime, "utf-8", app.assets.open("stockfish/$name"))
                    } catch (_: IOException) {
                        WebResourceResponse(null, null, 404, "Not Found", emptyMap(), null)
                    }
                }
            }
            wv.onResume()
            wv.resumeTimers()
            wv.loadUrl(BASE + "engine.html")
            WebTransport(ch, wv, main)
        } catch (_: Exception) {
            null
        }
    }

    // ---------- Khởi động ----------

    private suspend fun ensureStarted() {
        if (transport != null) return
        val candidates: List<suspend () -> Transport?> = listOf(::createNative, ::createWeb)
        for (create in candidates) {
            val t = create() ?: continue
            transport = t
            lines = t.ch
            if (handshake(t)) {
                backendName = if (t.isNative) "native" else "wasm"
                return
            }
            t.close()
            transport = null
        }
        backendName = "none"
        error("Không khởi động được engine nào (native lẫn wasm)")
    }

    private suspend fun handshake(t: Transport): Boolean {
        if (!t.isNative && !waitFor("info string page-ready", 15_000)) return false
        t.send("uci")
        if (!waitFor("uciok", if (t.isNative) 10_000 else 30_000)) return false
        if (t.isNative) {
            t.send("setoption name Threads value ${config.threads}")
            t.send("setoption name Hash value ${config.hashMb}")
        } else {
            // Wasm không có đơn luồng đa nhân và bộ nhớ chặt: giữ Hash nhỏ.
            t.send("setoption name Hash value ${minOf(config.hashMb, MAX_WASM_HASH_MB)}")
        }
        t.send("isready")
        return waitFor("readyok", 15_000)
    }

    private fun send(cmd: String) { transport?.send(cmd) }

    private suspend fun waitFor(prefix: String, timeoutMs: Long): Boolean =
        withTimeoutOrNull(timeoutMs) {
            var found = false
            while (!found) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith(prefix)) found = true
            }
            found
        } ?: false

    // ---------- Phân tích ----------

    private class Acc {
        var cp = 0
        var mate: Int? = null
        var depth = 0
        var best: String? = null
    }

    private fun parse(line: String, acc: Acc): Boolean {
        BEST.find(line)?.let {
            acc.best = it.groupValues[1].takeIf { m -> m != "(none)" }
            return true
        }
        if (!line.startsWith("info") || " lowerbound" in line || " upperbound" in line) return false
        SCORE.find(line)?.let { m ->
            val v = m.groupValues[2].toInt()
            if (m.groupValues[1] == "mate") {
                acc.mate = v
                acc.cp = if (v > 0) 10_000 - minOf(v, 99) * 10 else -10_000 + minOf(-v, 99) * 10
            } else {
                acc.mate = null
                acc.cp = v
            }
            DEPTH.find(line)?.let { d -> acc.depth = d.groupValues[1].toInt() }
        }
        return false
    }

    /** Phân tích 1 thế cờ. Quá moveTimeoutMs -> gửi stop và lấy kết quả tạm thời. */
    suspend fun analyzeSilently(fen: String, depth: Int = config.depth): EngineResult =
        mutex.withLock {
            ensureStarted()
            while (lines.tryReceive().isSuccess) { /* xả dòng cũ */ }
            send("position fen $fen")
            send("go depth $depth")

            val acc = Acc()
            val done = withTimeoutOrNull(config.moveTimeoutMs) {
                var finished = false
                while (!finished) {
                    val l = lines.receiveCatching().getOrNull() ?: break
                    finished = parse(l, acc)
                }
                finished
            } ?: false

            var timedOut = false
            if (!done) {
                timedOut = true
                send("stop")
                withTimeoutOrNull(1_500) {
                    var finished = false
                    while (!finished) {
                        val l = lines.receiveCatching().getOrNull() ?: break
                        finished = parse(l, acc)
                    }
                }
            }
            EngineResult(acc.best, acc.cp, acc.mate, acc.depth, timedOut)
        }

    /** Dừng search đang chạy (vô hại nếu engine đang rảnh). */
    fun stopSearch() = send("stop")

    override fun close() {
        val t = transport ?: return
        transport = null
        backendName = "none"
        runCatching { t.close() }
        lines.close()
    }

    fun shutdown() = close()
}
