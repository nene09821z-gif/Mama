package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.RatingMode
import kotlin.math.ceil

// =============================================================================
// Chunky green button (the chess.com "3D" button: lighter face, darker bottom edge)
// =============================================================================

@Composable
fun ChunkyBox(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    edge: Dp = 4.dp,
    radius: Dp = 10.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    Box(
        modifier = modifier
            .height(height + edge)
            .clip(shape)
            .background(VilaColors.GreenShadow)
            .clickable(interactionSource = source, indication = null, onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(height)
                .offset(y = if (pressed) edge / 2 else 0.dp)
                .clip(shape)
                .background(if (pressed) VilaColors.GreenPressed else VilaColors.Green),
            contentAlignment = Alignment.Center,
            content = content,
        )
    }
}

@Composable
fun ChunkyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    edge: Dp = 4.dp,
    radius: Dp = 10.dp,
    fontSize: TextUnit = 20.sp,
) {
    ChunkyBox(onClick = onClick, modifier = modifier, height = height, edge = edge, radius = radius) {
        Text(
            text = text,
            color = Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
        )
    }
}

// =============================================================================
// Header: avatar, streak, diamond, friends, bell
// =============================================================================

@Composable
private fun HeaderIcon(
    description: String,
    badge: Int,
    width: Dp,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(width = width, height = 42.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = description, onClick = onClick),
    ) {
        Box(modifier = Modifier.align(Alignment.Center).size(26.dp)) { content() }
        if (badge > 0) {
            CountBadge(
                count = badge,
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 4.dp, end = 5.dp),
            )
        }
    }
}

@Composable
fun HomeHeader(
    avatar: ImageBitmap?,
    streak: Int,
    bellCount: Int,
    friendsCount: Int,
    onAvatar: () -> Unit,
    onStreak: () -> Unit,
    onDiamond: () -> Unit,
    onFriends: () -> Unit,
    onBell: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(42.dp)
            .padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val avatarShape = RoundedCornerShape(7.dp)
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(avatarShape)
                .background(VilaColors.BoardDark)
                .border(1.5.dp, Color(0x66FFFFFF), avatarShape)
                .clickable(onClickLabel = "Hồ sơ", onClick = onAvatar),
            contentAlignment = Alignment.Center,
        ) {
            if (avatar != null) {
                Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(30.dp))
            }
        }
        Row(
            modifier = Modifier
                .height(42.dp)
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClickLabel = "Chuỗi ngày chơi", onClick = onStreak),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FlameIcon(Modifier.size(28.dp))
            Text(
                text = streak.toString(),
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
        Spacer(Modifier.weight(1f))
        HeaderIcon("Kim cương", 0, 42.dp, onDiamond) { DiamondIcon(Modifier.fillMaxSize()) }
        HeaderIcon("Bạn bè", friendsCount, 36.dp, onFriends) { FriendsIcon(Modifier.fillMaxSize()) }
        HeaderIcon("Thông báo", bellCount, 42.dp, onBell) { BellIcon(Modifier.fillMaxSize()) }
    }
}

// =============================================================================
// Hero cards (horizontal carousel): Learn + Coach
// =============================================================================

private val HERO_SHAPE = RoundedCornerShape(12.dp)

@Composable
fun LearnCard(onStart: () -> Unit, modifier: Modifier = Modifier) {
    val textShadow = TextStyle(shadow = Shadow(Color(0x99000000), Offset(0f, 2f), 5f))
    Box(modifier = modifier.clip(HERO_SHAPE)) {
        // tilted green/cream board, darker on the left so the text stays readable
        Canvas(modifier = Modifier.matchParentSize()) {
            drawRect(Color(0xFFEEEED2))
            val s = 50.dp.toPx()
            rotate(degrees = -9f, pivot = Offset(size.width * 0.55f, size.height * 0.5f)) {
                val cols = ceil(size.width / s).toInt() + 4
                val rows = ceil(size.height / s).toInt() + 4
                for (r in -2 until rows) {
                    for (c in -2 until cols) {
                        if (((r + c) and 1) == 1) {
                            drawRect(
                                color = Color(0xFF769656),
                                topLeft = Offset(c * s - 14.dp.toPx(), r * s - 10.dp.toPx()),
                                size = Size(s, s),
                            )
                        }
                    }
                }
            }
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0x8C000000), Color(0x2E000000)),
                ),
            )
        }
        // art: star, arrow, pawn
        StarIcon(
            Modifier
                .offset(x = 68.dp, y = 38.dp)
                .size(47.dp)
                .rotate(14f),
        )
        UpArrowIcon(
            Modifier
                .offset(x = 81.dp, y = 85.dp)
                .size(width = 40.dp, height = 43.dp),
        )
        PawnIcon(
            color = Color.White,
            modifier = Modifier
                .offset(x = 94.dp, y = 95.dp)
                .size(34.dp),
        )
        // title
        Column(modifier = Modifier.padding(start = 15.dp, top = 13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.School,
                    contentDescription = null,
                    tint = Color(0xFF3E9BEA),
                    modifier = Modifier.size(34.dp),
                )
                Spacer(Modifier.width(9.dp))
                Text(
                    text = "Học",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    style = textShadow,
                )
            }
            Text(
                text = "The King",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                style = textShadow,
                modifier = Modifier.padding(start = 1.dp, top = 2.dp),
            )
        }
        ChunkyButton(
            text = "Bắt đầu",
            onClick = onStart,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 15.dp, bottom = 15.dp)
                .width(80.dp),
            height = 29.dp,
            edge = 3.dp,
            radius = 8.dp,
            fontSize = 15.sp,
        )
    }
}

@Composable
fun CoachCard(on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(HERO_SHAPE)
            .background(Brush.verticalGradient(listOf(Color(0xFF2C3E5B), Color(0xFF1C2941))))
            .border(1.dp, VilaColors.GlassBorder, HERO_SHAPE)
            .clickable(onClick = onClick),
    ) {
        Column(modifier = Modifier.padding(start = 14.dp, top = 14.dp, end = 14.dp)) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF5E86BD), Color(0xFF39598A))))
                    .border(2.dp, Color(0xFF9CC0F0), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = Color(0xFFDCE9FA),
                    modifier = Modifier.size(30.dp),
                )
            }
            Spacer(Modifier.height(9.dp))
            Text(
                text = if (on) "Huấn luyện viên: Bật" else "Bật huấn luyện viên",
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = if (on) "Chạm Gợi ý trong ván cờ" else "Nhận gợi ý từng nước đi",
                color = VilaColors.TextDim,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// =============================================================================
// Section header ("Hệ số" ........ "Xem hết")
// =============================================================================

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    action: String? = null,
    onAction: () -> Unit = {},
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(22.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f),
        )
        if (action != null) {
            Text(
                text = action,
                color = Color(0xFFE3ECFA),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable(onClick = onAction)
                    .padding(horizontal = 4.dp, vertical = 2.dp),
            )
        }
    }
}

// =============================================================================
// Suggested game: opponent avatar, name, time control, green "start" button
// =============================================================================

@Composable
fun SuggestedGameCard(
    avatar: ImageBitmap?,
    title: String,
    timeLabel: String,
    onPlay: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(8.dp)
    Box(modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(shape)
                .background(VilaColors.Glass)
                .border(1.dp, VilaColors.GlassBorder, shape),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(modifier = Modifier.size(80.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    val s = size.width / 4f
                    for (r in 0 until 4) {
                        for (c in 0 until 4) {
                            drawRect(
                                color = if ((r + c) % 2 == 0) VilaColors.BoardLight else VilaColors.BoardDark,
                                topLeft = Offset(c * s, r * s),
                                size = Size(s, s),
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.White)
                        .padding(2.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xFF4A4743)),
                    contentAlignment = Alignment.Center,
                ) {
                    if (avatar != null) {
                        Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(42.dp))
                    }
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = 12.dp, end = 6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp, Alignment.CenterVertically),
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = null,
                        tint = VilaColors.TextDim,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = timeLabel,
                        color = VilaColors.TextDim,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(VilaColors.GreenDeep)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                ) {
                    Text(
                        text = "ĐỐI THỦ GỢI Ý",
                        color = VilaColors.Green,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                    )
                }
            }
            ChunkyBox(
                onClick = onPlay,
                modifier = Modifier.padding(end = 12.dp).width(48.dp),
                height = 44.dp,
                edge = 4.dp,
                radius = 8.dp,
            ) {
                AddBoardIcon(Modifier.size(28.dp))
            }
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 10.dp, y = (-10).dp)
                .size(28.dp)
                .clip(CircleShape)
                .clickable(onClickLabel = "Ẩn", onClick = onDismiss),
            contentAlignment = Alignment.TopEnd,
        ) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .background(Color(0xFF4A4F57), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Close,
                    contentDescription = "Ẩn",
                    tint = Color(0xFFD8DCE2),
                    modifier = Modifier.size(13.dp),
                )
            }
        }
    }
}

// =============================================================================
// Rating tile (92 x 92): icon, number, label
// =============================================================================

@Composable
fun RatingTile(mode: RatingMode, rating: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = modifier
            .size(92.dp)
            .clip(shape)
            .background(VilaColors.Glass)
            .border(1.dp, VilaColors.GlassBorder, shape)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(5.dp))
        val iconMod = Modifier.size(37.dp)
        when (mode) {
            RatingMode.BULLET -> BulletIcon(iconMod)
            RatingMode.BLITZ -> BoltIcon(iconMod)
            RatingMode.RAPID -> StopwatchIcon(iconMod)
            RatingMode.DAILY -> SunIcon(iconMod)
        }
        Spacer(Modifier.height(7.dp))
        Text(
            text = rating.toString(),
            color = Color.White,
            fontSize = 19.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Text(
            text = mode.label,
            color = VilaColors.TextDim,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

// =============================================================================
// Friend card (127 wide)
// =============================================================================

@Composable
fun FriendCard(
    title: String,
    subtitle: String,
    showPlus: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .width(127.dp)
            .height(114.dp)
            .clip(shape)
            .background(VilaColors.Glass)
            .border(1.dp, VilaColors.GlassBorder, shape)
            .clickable(onClick = onClick),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(top = 12.dp, start = 6.dp, end = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF5E86BD), Color(0xFF39598A))))
                    .border(2.dp, Color(0xFF9CC0F0), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = Color(0xFFDCE9FA),
                    modifier = Modifier.size(38.dp),
                )
            }
            Spacer(Modifier.height(7.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = subtitle,
                color = VilaColors.TextDim,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (showPlus) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(VilaColors.Green),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "Thêm bạn",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
    }
}

// =============================================================================
// Bottom dock: big green "Chơi" button + 5-tab navigation
// =============================================================================

private class NavItem(val label: String, val icon: @Composable (Color, Modifier) -> Unit)

private val NAV_ITEMS = listOf(
    NavItem("Trang chủ") { c, m -> PawnIcon(c, m) },
    NavItem("Câu đố") { c, m -> Icon(Icons.Filled.Extension, null, m, c) },
    NavItem("Học") { c, m -> Icon(Icons.Filled.School, null, m, c) },
    NavItem("Bạn bè") { c, m -> Icon(Icons.Filled.People, null, m, c) },
    NavItem("Thêm nữa") { c, m -> Icon(Icons.Filled.Menu, null, m, c) },
)

val NAV_HEIGHT = 58.dp
val PLAY_AREA_HEIGHT = 77.dp // 14 top gap + 55 button + 8 gap

@Composable
fun HomeDock(
    showPlay: Boolean,
    selected: Int,
    onSelect: (Int) -> Unit,
    onPlay: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val navy = Color(0xFF0A1226)
    val backdrop = if (showPlay) {
        Brush.verticalGradient(
            0f to navy.copy(alpha = 0f),
            0.22f to navy.copy(alpha = 0.93f),
            1f to navy.copy(alpha = 0.97f),
        )
    } else {
        Brush.verticalGradient(listOf(navy.copy(alpha = 0.97f), navy.copy(alpha = 0.97f)))
    }
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(backdrop)
            .navigationBarsPadding(),
    ) {
        if (showPlay) {
            ChunkyButton(
                text = "Chơi",
                onClick = onPlay,
                modifier = Modifier
                    .padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 8.dp)
                    .fillMaxWidth(),
                height = 51.dp,
                edge = 4.dp,
                radius = 10.dp,
                fontSize = 24.sp,
            )
        }
        Row(modifier = Modifier.fillMaxWidth().height(NAV_HEIGHT).padding(horizontal = 7.5.dp)) {
            for (i in NAV_ITEMS.indices) {
                val item = NAV_ITEMS[i]
                val isSel = i == selected
                val tint = if (isSel) Color.White else VilaColors.NavIdle
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { onSelect(i) }
                        .padding(top = 13.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    item.icon(tint, Modifier.size(26.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = item.label,
                        color = tint,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}
