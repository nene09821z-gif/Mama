package com.vila.chess.game

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vila.chess.bots.BotEngineManager
import com.vila.chess.bots.BotProfile
import com.vila.chess.bots.BotRepository
import com.vila.chess.core.BISHOP
import com.vila.chess.profile.UserSessionManager
import com.vila.chess.core.EMPTY
import com.vila.chess.core.Engine
import com.vila.chess.core.Position
import com.vila.chess.billing.MembershipStore
import com.vila.chess.billing.Quota
import com.vila.chess.billing.UsageTracker
import com.vila.chess.review.GameAnalysisWorker
import com.vila.chess.review.ReviewRequest
import com.vila.chess.review.EngineResult
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import com.vila.chess.review.GameReviewStore
import com.vila.chess.profile.ArchivedGame
import com.vila.chess.profile.GameArchive
import com.vila.chess.core.FLAG_CASTLE
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.sqRank
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.SearchLimits
import com.vila.chess.core.START_FEN
import com.vila.chess.core.applyPremoveOnCopy
import com.vila.chess.core.generatePseudoCopyForPremove
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.core.moveUci
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue
import com.vila.chess.ui.DEFAULT_PIECE_SET
import com.vila.chess.ui.PieceSets
import com.vila.chess.ui.loadPieceImages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import android.util.Log
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.online.MatchResult
import com.vila.chess.online.OnlineGame
import com.vila.chess.online.OnlinePhase
import com.vila.chess.online.OnlineRepository
import com.vila.chess.online.OnlineUi
import com.vila.chess.profile.ProfileError
import com.vila.chess.profile.ProfileException
import com.vila.chess.profile.message
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.random.Random

enum class Screen { HOME, GAME, REVIEW }

/** Một nước premove đã xếp hàng; [promo] = quân phong cấp đã chọn (0 nếu không phải nước phong cấp). */
private data class Premove(val first: Int, val second: Int, val promo: Int = 0)

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("vila_native", Context.MODE_PRIVATE)
    private val sounds = SoundPlayer(app)
    private val haptics = Haptics(app)

    // ---- settings (persisted) ----
    var level by mutableIntStateOf(prefs.getInt("level", 3))
        private set
    var colorChoice by mutableIntStateOf(prefs.getInt("color", 0)) // 0 white, 1 random, 2 black
        private set
    var timeIndex by mutableIntStateOf(prefs.getInt("time", 6))
        private set
    var soundOn by mutableStateOf(prefs.getBoolean("sound", true))
        private set
    var hapticOn by mutableStateOf(prefs.getBoolean("haptic", true))
        private set
    var pieceSet by mutableStateOf(
        (prefs.getString("pieceSet2", "cburnett") ?: "cburnett")
            .let { if (PieceSets.exists(it)) it else "cburnett" }
    )
        private set
    var pieceImages by mutableStateOf(loadPieceImages(app, pieceSet))
        private set

    // ---- player stats (ratings per time bucket, daily streak) ----
    var stats by mutableStateOf(StatsStore.load(prefs))
        private set
    /** Elo khởi điểm người chơi tự chọn ở màn chọn trình độ (0 = chưa chọn). */
    var startElo by mutableIntStateOf(prefs.getInt("startElo", 0))
        private set
    /** Đã chọn trình độ, hoặc là người chơi cũ đã có ván (không bắt chọn lại). */
    val skillSetupDone: Boolean get() = startElo > 0 || stats.played > 0

    fun completeSkillSetup(elo: Int) {
        startElo = elo
        val e = prefs.edit().putInt("startElo", elo)
        if (stats.played == 0) for (i in 0 until 4) e.putInt("rating_" + i, elo)   // hệ số khởi điểm
        e.apply()
        stats = StatsStore.load(prefs)
        updateLevel(suggestLevel(elo))
    }

    var tipsUnread by mutableIntStateOf(if (prefs.getBoolean("tipsSeen", false)) 0 else HOME_TIPS.size)
        private set

    // ---- coach, navigation and tournament ----
    var coachOn by mutableStateOf(prefs.getBoolean("coach", false))
        private set
    /** Thanh đánh giá (Eval Bar) bên cạnh bàn cờ. */
    var evalBarOn by mutableStateOf(prefs.getBoolean("evalBar", false))
        private set
    private var evalCancel = AtomicBoolean(false)
    private var pendingCapture: IntArray? = null

    fun setEvalBar(on: Boolean) {
        evalBarOn = on
        prefs.edit().putBoolean("evalBar", on).apply()
        if (on) requestEval() else evalCancel.set(true)
    }

    // ---- nhãn chất lượng nước đi trực tiếp (Brilliant … Blunder) kiểu chess.com ----
    var moveLabelsOn by mutableStateOf(prefs.getBoolean("moveLabels", true))
        private set
    private val liveEvalCache = ConcurrentHashMap<String, EngineResult>()
    private var labelCancel = AtomicBoolean(false)
    @Volatile private var liveBook: OpeningBook? = null

    fun setMoveLabels(on: Boolean) {
        moveLabelsOn = on
        prefs.edit().putBoolean("moveLabels", on).apply()
        if (!on) {
            labelCancel.set(true)
            ui = ui.copy(moveLabels = emptyList())
        } else {
            session?.let { scheduleLiveLabels(it) }
        }
    }

    private fun liveLabelsAllowed(): Boolean =
        moveLabelsOn && (gameKind == GameKind.BOT || gameKind == GameKind.ENDGAME)

    /**
     * Phân tích nền để gán nhãn cho các nước đã đi. Mỗi nước mới chỉ tốn 1 lượt tìm (các thế trước nằm trong cache).
     * Nước nghi sai (Inaccuracy/Mistake/Miss/Blunder) được tìm lại sâu hơn rồi mới chốt nhãn, nên nhãn xấu có thể đổi nhẹ sau ~1-2 giây.
     */
    private fun scheduleLiveLabels(s: GameSession) {
        if (!liveLabelsAllowed()) return
        labelCancel.set(true)
        val cancel = AtomicBoolean(false)
        labelCancel = cancel
        val ucis = s.records.map { moveUci(it.move) }
        if (ucis.isEmpty()) return
        val start = startFen
        val n = ucis.size
        val app = getApplication<Application>()
        fun stale() = cancel.get() || session !== s || s.records.size != n
        viewModelScope.launch {
            val first = withContext(Dispatchers.Default) {
                runCatching {
                    val book = liveBook ?: OpeningBook.load(app).also { liveBook = it }
                    val evalOf = { fen: String ->
                        liveEvalCache[fen]
                            ?: LiveMoveLabeler.evaluate(fen, LiveMoveLabeler.FAST) { cancel.get() }?.also { liveEvalCache[fen] = it }
                    }
                    LiveMoveLabeler.labelGame(start, ucis, evalOf, book)
                }.getOrNull()
            }
            if (first == null || stale()) return@launch
            ui = ui.copy(moveLabels = first)
            if (first.lastOrNull() !in LiveMoveLabeler.SUSPECT) return@launch
            val deep = withContext(Dispatchers.Default) {
                runCatching {
                    val fens = LiveMoveLabeler.lastMoveFens(start, ucis) ?: return@runCatching null
                    for (fen in fens) {
                        val r = LiveMoveLabeler.evaluate(fen, LiveMoveLabeler.DEEP) { cancel.get() } ?: return@runCatching null
                        liveEvalCache[fen] = r
                    }
                    val evalOf = { fen: String -> liveEvalCache[fen] }
                    LiveMoveLabeler.labelGame(start, ucis, evalOf, liveBook)
                }.getOrNull()
            }
            if (deep == null || stale()) return@launch
            ui = ui.copy(moveLabels = deep)
        }
    }

    /** Đánh giá nền thế hiện tại (độ sâu của Coach) -> ui.evalCp theo góc nhìn Trắng. */
    private fun requestEval() {
        val s = session ?: return
        if (!evalBarOn || gameKind == GameKind.FRIEND || gameKind == GameKind.ONLINE || s.isOver) return
        evalCancel.set(true)
        val cancel = AtomicBoolean(false)
        evalCancel = cancel
        val snap = s.position.copy()
        val ply = s.records.size
        val whiteToMove = snap.whiteToMove
        viewModelScope.launch {
            val h = withContext(Dispatchers.Default) { Coach.hint(snap) { cancel.get() } }
            if (h == null || cancel.get() || session !== s || s.records.size != ply) return@launch
            ui = ui.copy(evalCp = if (whiteToMove) h.scoreCp else -h.scoreCp, evalReady = true)
        }
    }
    var route by mutableStateOf(HomeRoute.HOME)
        private set
    var tournament by mutableStateOf(Tournament.parse(prefs.getString("tourney", null)))
        private set
    var tournamentsDone by mutableIntStateOf(prefs.getInt("tourneyDone", 0))
        private set

    fun setCoach(v: Boolean) {
        coachOn = v
        prefs.edit().putBoolean("coach", v).apply()
        if (!v) {
            hintCancel.set(true)
            ui = ui.copy(hintFrom = -1, hintTo = -1, hintText = "", hintBusy = false)
        }
    }

    fun navigate(r: HomeRoute) {
        route = r
    }

    /** userId của hồ sơ đang xem ở route PROFILE; null = hồ sơ của chính mình. */
    var profileUserId by mutableStateOf<String?>(null)
        private set

    /** Mở màn Hồ sơ: [userId] = null → của mình; ngược lại → hồ sơ người chơi đó (đối thủ, bạn bè). */
    fun openProfile(userId: String? = null) {
        profileUserId = userId
        route = HomeRoute.PROFILE
    }

    fun resetTournament() {
        tournament = Tournament.parse(null)
        prefs.edit().putString("tourney", Tournament.serialize(tournament)).apply()
    }

    fun markTipsSeen() {
        tipsUnread = 0
        prefs.edit().putBoolean("tipsSeen", true).apply()
    }

    init {
        sounds.enabled = soundOn
        haptics.enabled = hapticOn
    }

    fun updateLevel(v: Int) {
        level = v.coerceIn(1, 8)
        prefs.edit().putInt("level", level).apply()
    }

    fun updateColorChoice(v: Int) {
        colorChoice = v
        prefs.edit().putInt("color", v).apply()
    }

    fun updateTimeIndex(v: Int) {
        timeIndex = v
        prefs.edit().putInt("time", v).apply()
    }

    fun setSound(v: Boolean) {
        soundOn = v
        sounds.enabled = v
        prefs.edit().putBoolean("sound", v).apply()
    }

    fun updatePieceSet(id: String) {
        if (!PieceSets.exists(id) || id == pieceSet) return
        pieceImages = loadPieceImages(getApplication<Application>(), id)
        pieceSet = id
        prefs.edit().putString("pieceSet2", id).apply()
    }

    /** "Đi trước": Nhiều / Đơn / Đã vô hiệu hóa (lưu bền). */
    var premoveMode by mutableStateOf(PremoveMode.fromId(prefs.getInt("premoveMode", PremoveMode.MULTI.id)))
        private set

    @JvmName("applyPremoveMode")
    fun setPremoveMode(m: PremoveMode) {
        if (m == premoveMode) return
        premoveMode = m
        prefs.edit().putInt("premoveMode", m.id).apply()
        when (m) {
            PremoveMode.OFF -> premoves.clear()
            PremoveMode.SINGLE -> while (premoves.size > 1) premoves.removeAt(0)
            PremoveMode.MULTI -> Unit
        }
        if (session != null) {
            ui = ui.copy(selected = -1, targets = emptySet())
            refreshUi()
        }
    }

    fun setHaptic(v: Boolean) {
        hapticOn = v
        haptics.enabled = v
        prefs.edit().putBoolean("haptic", v).apply()
    }

    // ---- game state ----
    var screen by mutableStateOf(Screen.HOME)
        private set
    var ui by mutableStateOf(UiState())
        private set
    var clocks by mutableStateOf(ClockState())
        private set

    private var session: GameSession? = null
    private var humanWhite = true
    private var flipped = false
    private var currentLevel: Level = Levels.get(3)
    private var timeControl: TimeControl = TimeControls.get(0)
    /** Hàng đợi premove: chế độ Nhiều giữ nhiều nước, chế độ Đơn tối đa 1. */
    private val premoves = ArrayList<Premove>()
    private val maxQueuedPremoves = 12
    private var engineJob: Job? = null
    private var engineCancel = AtomicBoolean(false)
    private var clockJob: Job? = null
    private var resultAnnounced = false

    /** Dữ liệu ván vừa kết thúc để mở màn Game Review (id + FEN đầu ván + nước đi). null = chưa/không đủ điều kiện phân tích. */
    var reviewRequest: ReviewRequest? by mutableStateOf(null)
        private set
    /**
     * true = lớp phủ "Đang phân tích" trên bàn cờ đã xong việc (đã tự mở Review hoặc người chơi bấm bỏ qua),
     * để quay lại từ màn Review KHÔNG hiện lại lớp phủ rồi tự nhảy sang Review lần nữa.
     */
    var progressHandled: Boolean by mutableStateOf(false)
    /** Lý do không phân tích được (ván quá ngắn / hết lượt trong ngày) để màn tổng kết báo đúng. */
    var reviewSkipReason: String? by mutableStateOf(null)
        private set
    val botLevelId: Int get() = currentLevel.id
    private var gameKind = GameKind.BOT

    /** Bot đang đấu (null = chơi nhanh theo cấp độ, dùng engine Kotlin). */
    var activeBot: BotProfile? by mutableStateOf(null)
        private set
    private var botEngine: BotEngineManager? = null
    private fun botEngine(): BotEngineManager =
        botEngine ?: BotEngineManager(getApplication<Application>()).also { botEngine = it }
    private fun releaseBotEngine() {
        botEngine?.close()
        botEngine = null
    }
    private var startFen = START_FEN
    private var startHumanWhite: Boolean? = null
    private var startLevel = 3
    private var tournamentRound = -1
    private var engineMovesFirst = false
    private var hintCancel = AtomicBoolean(false)

    /** Quick play against the bot with the saved level / colour / time. */
    fun startGame() {
        activeBot = null
        beginGame(GameKind.BOT, START_FEN, null, level, -1)
    }

    /** Đấu với một Bot trong BotRepository; Stockfish native được cấu hình theo Elo của bot (nền, không chặn UI). */
    fun startBotGame(botId: String) {
        val bot = BotRepository.getById(botId) ?: return
        activeBot = bot
        val mgr = botEngine()
        mgr.newGame()
        viewModelScope.launch { mgr.configureEngineForBot(bot) }   // khởi động sớm để nước đầu không bị trễ
        beginGame(GameKind.BOT, START_FEN, null, suggestLevel(bot.elo), -1)
    }

    /** Two players on one device. */
    fun startFriendGame() = beginGame(GameKind.FRIEND, START_FEN, true, level, -1)

    /** Endgame practice from a ready-made position. */
    fun startEndgame(p: EndgamePreset) = beginGame(GameKind.ENDGAME, p.fen, p.humanWhite, level, -1)

    /** Play against the bot from a custom FEN. Returns an error message, or null when the game started. */
    fun startFromFen(fen: String, humanIsWhite: Boolean): String? {
        val err = FenCheck.validate(fen)
        if (err != null) return err
        beginGame(GameKind.ENDGAME, fen.trim(), humanIsWhite, level, -1)
        return null
    }

    /** Plays the next unplayed round of the bot tournament; false when the tournament is finished. */
    fun startTournamentRound(): Boolean {
        val r = Tournament.nextRound(tournament)
        if (r < 0) return false
        beginGame(GameKind.TOURNAMENT, START_FEN, Tournament.humanWhite(r), Tournament.levelFor(r), r)
        return true
    }

    /** "Ván mới" from the game screen: same kind of game again (next round in a tournament). */
    fun rematch() {
        when (gameKind) {
            GameKind.BOT -> activeBot?.let { startBotGame(it.id) } ?: startGame()
            GameKind.FRIEND -> startFriendGame()
            GameKind.ONLINE -> if (ui.over) openOnlineLobby(autoSearch = true)   // "Tìm trận mới": về màn Chơi online và tìm tiếp
            GameKind.ENDGAME -> beginGame(GameKind.ENDGAME, startFen, startHumanWhite, startLevel, -1)
            GameKind.TOURNAMENT -> {
                if (ui.over) {
                    if (!startTournamentRound()) backToHome()
                } else {
                    beginGame(GameKind.TOURNAMENT, START_FEN, Tournament.humanWhite(tournamentRound), startLevel, tournamentRound)
                }
            }
        }
    }

    private fun beginGame(kind: GameKind, fen: String, humanWhiteArg: Boolean?, lvl: Int, round: Int) {
        stopJobs()
        if (kind != GameKind.BOT) activeBot = null
        val s = GameSession(fen)
        session = s
        gameKind = kind
        startFen = fen
        startHumanWhite = humanWhiteArg
        startLevel = lvl
        tournamentRound = round
        humanWhite = humanWhiteArg ?: when (colorChoice) {
            0 -> true
            2 -> false
            else -> Random.nextBoolean()
        }
        flipped = if (kind == GameKind.FRIEND) false else !humanWhite
        engineMovesFirst = kind != GameKind.FRIEND && s.position.whiteToMove != humanWhite
        currentLevel = Levels.get(lvl)
        timeControl = TimeControls.get(timeIndex)
        premoves.clear()
        liveEvalCache.clear()
        resultAnnounced = false
        reviewRequest = null
        reviewSkipReason = null
        val base = timeControl.baseSec * 1000L
        clocks = ClockState(base, base, timeControl.baseSec > 0)
        ui = UiState(kind = kind)
        refreshUi()
        screen = Screen.GAME
        startClock()
        if (!finishIfOver()) startEngineIfNeeded()
        requestEval()
    }

    fun backToHome() {
        stopJobs()
        releaseBotEngine()
        if (gameKind == GameKind.ONLINE) {
            onlineGame = null
            online = OnlineUi()
        }
        route = if (gameKind == GameKind.TOURNAMENT) HomeRoute.TOURNAMENT else HomeRoute.HOME
        screen = Screen.HOME
    }

    /** Coach: ask the engine for the best move for the player to move. */
    fun requestHint() {
        val s = session ?: return
        if (!coachOn || gameKind == GameKind.FRIEND || gameKind == GameKind.TOURNAMENT || gameKind == GameKind.ONLINE) return
        if (s.isOver || !isHumanTurn(s) || ui.hintBusy || ui.promotion != null) return
        val ply = s.records.size
        val snapshot = s.position.copy()
        val cancel = AtomicBoolean(false)
        hintCancel = cancel
        ui = ui.copy(hintBusy = true, hintText = "Huấn luyện viên đang suy nghĩ…", hintFrom = -1, hintTo = -1)
        viewModelScope.launch {
            val h = withContext(Dispatchers.Default) { Coach.hint(snapshot) { cancel.get() } }
            if (cancel.get() || session !== s || s.records.size != ply || s.isOver) return@launch
            ui = if (h == null) {
                ui.copy(hintBusy = false, hintText = "Không còn nước đi hợp lệ")
            } else {
                ui.copy(hintBusy = false, hintFrom = moveFrom(h.move), hintTo = moveTo(h.move), hintText = Coach.describe(h))
            }
        }
    }

    private fun stopJobs() {
        hintCancel.set(true)
        evalCancel.set(true)
        labelCancel.set(true)
        engineCancel.set(true)
        engineJob?.cancel()
        engineJob = null
        clockJob?.cancel()
        clockJob = null
        onlineSearchJob?.cancel()
        onlineSearchJob = null
        onlineSyncJob?.cancel()
        onlineSyncJob = null
        onlineClockJob?.cancel()
        onlineClockJob = null
    }

    override fun onCleared() {
        stopJobs()
        releaseBotEngine()
        sounds.release()
        super.onCleared()
    }

    // ---- board interaction ----

    private fun isHumanTurn(s: GameSession): Boolean = gameKind == GameKind.FRIEND || s.position.whiteToMove == humanWhite

    private fun isOwnPiece(s: GameSession, piece: Int): Boolean {
        if (piece == EMPTY) return false
        val mine = if (gameKind == GameKind.FRIEND) s.position.whiteToMove else humanWhite
        return isWhitePiece(piece) == mine
    }

    /** Pointer went down on [sq]. Returns true when a piece of the player was picked up (may be dragged). */
    fun pressSquare(sq: Int): Boolean {
        val s = session ?: return false
        if (sq < 0 || ui.over || ui.promotion != null) return false
        val piece = s.position.board[sq]
        val own = isOwnPiece(s, piece)
        val sel = ui.selected
        if (isHumanTurn(s)) {
            if (sel >= 0 && ui.targets.contains(sq)) {
                attemptMove(sel, sq, false)
                return false
            }
            if (own) {
                selectSquare(sq, forPremove = false)
                return true
            }
            clearSelection()
            return false
        }
        // Lượt đối thủ: chế độ "Đi trước"
        if (premoveMode == PremoveMode.OFF || gameKind == GameKind.FRIEND) {
            clearSelection()
            return false
        }
        val shown = ui.board[sq]                    // bàn cờ đang hiển thị (ở chế độ Nhiều là bàn cờ ảo sau các premove)
        val ownShown = isOwnPiece(s, shown)
        if (sel >= 0 && ui.targets.contains(sq)) {
            addPremove(sel, sq)
            return false
        }
        if (ownShown) {
            selectSquare(sq, forPremove = true)
            return true
        }
        // Chạm ô trống / quân đối thủ: hủy toàn bộ premove
        premoves.clear()
        ui = ui.copy(selected = -1, targets = emptySet())
        refreshUi()
        return false
    }

    /** Pointer released after dragging the piece that started on [from]; [dropSq] is the square it was dropped on. */
    fun releaseDrag(from: Int, dropSq: Int) {
        val s = session ?: return
        if (dropSq < 0 || dropSq == from || ui.over) return
        if (!ui.targets.contains(dropSq)) return
        if (isHumanTurn(s)) attemptMove(from, dropSq, true)
        else if (premoveMode != PremoveMode.OFF) addPremove(from, dropSq, fromDrag = true)
    }

    fun deselect() {
        clearSelection()
    }

    private fun selectSquare(sq: Int, forPremove: Boolean) {
        val s = session ?: return
        val targets: Set<Int> = if (forPremove) premoveTargets(s, sq) else {
            val set = HashSet<Int>()
            for (m in s.movesFrom(sq)) set.add(moveTo(m))
            set
        }
        ui = ui.copy(selected = sq, targets = targets)
    }

    /** Bàn cờ ảo = bàn cờ thật + các premove đã xếp hàng (chỉ dùng ở chế độ Nhiều). */
    private fun virtualPosition(s: GameSession): Position {
        val p = s.position.copy()
        if (premoveMode == PremoveMode.MULTI) {
            for (pm in premoves) {
                if (!applyPremoveOnCopy(p, humanWhite, pm.first, pm.second, if (pm.promo != 0) pm.promo else QUEEN)) break
            }
        }
        return p
    }

    private fun premoveTargets(s: GameSession, sq: Int): Set<Int> {
        val set = HashSet<Int>()
        val base = if (premoveMode == PremoveMode.MULTI && premoves.isNotEmpty()) virtualPosition(s) else s.position
        for (m in generatePseudoCopyForPremove(base, humanWhite)) {
            if (moveFrom(m) == sq) set.add(moveTo(m))
        }
        return set
    }

    private fun clearSelection() {
        ui = ui.copy(selected = -1, targets = emptySet())
    }

    /** Tốt (trên bàn cờ đang hiển thị, tức bàn cờ ảo ở chế độ Nhiều) đi tới hàng cuối => premove phong cấp. */
    private fun isPremovePromotion(from: Int, to: Int): Boolean {
        val piece = ui.board[from]
        if (piece == EMPTY || pieceType(piece) != PAWN) return false
        return sqRank(to) == (if (isWhitePiece(piece)) 7 else 0)
    }

    private fun addPremove(from: Int, to: Int, fromDrag: Boolean = false, promo: Int = 0) {
        if (premoveMode == PremoveMode.OFF) return
        // Premove phong cấp: hỏi chọn quân (như chess.com) rồi mới xếp hàng; choosePromotion gọi lại hàm này kèm [promo].
        if (promo == 0 && isPremovePromotion(from, to)) {
            ui = ui.copy(promotion = PendingPromotion(from, to, fromDrag))
            return
        }
        when (premoveMode) {
            PremoveMode.OFF -> return
            PremoveMode.SINGLE -> { premoves.clear(); premoves.add(Premove(from, to, promo)) }
            PremoveMode.MULTI -> {
                if (premoves.size >= maxQueuedPremoves) premoves.removeAt(0)
                premoves.add(Premove(from, to, promo))
            }
        }
        ui = ui.copy(selected = -1, targets = emptySet())
        // Chạm để đặt premove (Nhiều): quân trượt sang ô đích; kéo thả thì overlay đã tự lướt.
        val slide = if (!fromDrag && premoveMode == PremoveMode.MULTI) listOf(Slide(from, to)) else emptyList()
        refreshUi(slides = slide)
    }

    private fun attemptMove(from: Int, to: Int, fromDrag: Boolean) {
        val s = session ?: return
        if (s.isPromotion(from, to)) {
            ui = ui.copy(promotion = PendingPromotion(from, to, fromDrag))
            return
        }
        val m = s.findMove(from, to, 0)
        if (m < 0) {
            clearSelection()
            return
        }
        playHuman(m, fromDrag)
    }

    fun choosePromotion(type: Int) {
        val s = session ?: return
        val p = ui.promotion ?: return
        ui = ui.copy(promotion = null)
        if (!isHumanTurn(s)) {   // đang đặt premove phong cấp
            addPremove(p.from, p.to, p.fromDrag, promo = type)
            return
        }
        val m = s.findMove(p.from, p.to, type)
        if (m >= 0) playHuman(m, p.fromDrag) else clearSelection()
    }

    fun cancelPromotion() {
        ui = ui.copy(promotion = null, selected = -1, targets = emptySet())
    }

    private fun slidesFor(m: Int, whiteMoved: Boolean): List<Slide> {
        val list = ArrayList<Slide>()
        list.add(Slide(moveFrom(m), moveTo(m)))
        if (moveFlag(m) == FLAG_CASTLE) {
            val base = if (whiteMoved) 0 else 56
            if (moveTo(m) == base + 6) list.add(Slide(base + 7, base + 5)) else list.add(Slide(base, base + 3))
        }
        return list
    }

    private fun playHuman(m: Int, fromDrag: Boolean, fromPremove: Boolean = false) {
        val s = session ?: return
        if (!isHumanTurn(s) || s.isOver) return
        if (!fromPremove) premoves.clear()
        val whiteMoved = s.position.whiteToMove
        val rec = s.play(m)
        addIncrement(whiteMoved)
        announce(rec, s)
        // Premove ở chế độ Nhiều: bàn cờ ảo đã hiển thị quân ở ô đích rồi => không trượt lại (tránh nháy).
        val skipSlide = fromDrag || (fromPremove && premoveMode == PremoveMode.MULTI)
        refreshUi(slides = if (skipSlide) emptyList() else slidesFor(m, whiteMoved))
        if (gameKind == GameKind.ONLINE) onlineAfterLocalMove(s, whiteMoved)
        if (!finishIfOver()) startEngineIfNeeded()
    }

    private fun playEngine(m: Int) {
        val s = session ?: return
        if (isHumanTurn(s) || s.isOver) return
        val whiteMoved = s.position.whiteToMove
        val rec = s.play(m)
        addIncrement(whiteMoved)
        announce(rec, s)
        // Premove đang nhắm đúng ô đối thủ vừa đến (ăn quân): bàn cờ ảo đã vẽ quân của ta ở đó => không trượt để khỏi vẽ nhầm quân.
        val engineLandsOnPremove = premoves.any { it.second == moveTo(m) }
        refreshUi(slides = if (engineLandsOnPremove) emptyList() else slidesFor(m, whiteMoved))
        if (finishIfOver()) { premoves.clear(); return }
        if (premoves.isEmpty()) return
        val pm = premoves[0]
        var mv = s.findMove(pm.first, pm.second, pm.promo)
        if (mv < 0) mv = s.findMove(pm.first, pm.second, 0)
        if (mv < 0) mv = s.findMove(pm.first, pm.second, QUEEN)
        if (mv >= 0) {
            viewModelScope.launch {
                delay(60)
                if (session === s && premoves.isNotEmpty()) {
                    premoves.removeAt(0)
                    playHuman(mv, false, fromPremove = true)
                }
            }
        } else {
            // Nước đi trước không còn hợp lệ => hủy cả hàng đợi (giống chess.com)
            premoves.clear()
            refreshUi()
        }
    }

    // ---- engine ----

    private fun startEngineIfNeeded() {
        val s = session ?: return
        if (gameKind == GameKind.ONLINE) return   // đối thủ là người thật: nước đi đến từ máy chủ, không có engine
        if (s.isOver || isHumanTurn(s)) return
        engineCancel.set(true)
        engineJob?.cancel()
        val cancel = AtomicBoolean(false)
        engineCancel = cancel
        val snapshot = s.position.copy()
        val engineWhite = !humanWhite
        val engineMs = if (engineWhite) clocks.whiteMs else clocks.blackMs
        var limits = currentLevel.limits
        if (clocks.enabled) {
            val budget = (engineMs / 25L).coerceAtLeast(200L)
            if (budget < limits.timeMs) limits = SearchLimits(limits.maxDepth, budget, limits.noiseCp)
        }
        val minDelay = if (currentLevel.id <= 3) 500L else 250L
        ui = ui.copy(thinking = true)
        val bot = activeBot
        val sfFen = startFen
        val sfMoves = if (bot != null) s.records.map { moveUci(it.move) } else emptyList()
        engineJob = viewModelScope.launch {
            val started = System.currentTimeMillis()
            val lim = limits
            var move = 0
            if (bot != null) {
                // Stockfish native (IO thread). Lỗi/thiếu engine -> rơi về engine Kotlin ở dưới.
                val mgr = botEngine()
                if (mgr.isNativeAvailable) {
                    mgr.configureEngineForBot(bot)
                    val uci = mgr.bestMove(sfFen, sfMoves, if (clocks.enabled) engineMs else -1L)
                    if (uci != null && !cancel.get() && session === s) move = uciToMove(s, uci).coerceAtLeast(0)
                }
            }
            if (move == 0) move = withContext(Dispatchers.Default) {
                val e = Engine()
                e.cancelled = { cancel.get() }
                e.findBestMove(snapshot, lim)
            }
            val elapsed = System.currentTimeMillis() - started
            if (elapsed < minDelay) delay(minDelay - elapsed)
            if (cancel.get() || session !== s || move == 0) {
                if (session === s) ui = ui.copy(thinking = false)
                return@launch
            }
            ui = ui.copy(thinking = false)
            playEngine(move)
        }
    }

    /** "e2e4" / "e7e8q" -> mã nước đi nội bộ; -1 nếu không hợp lệ. */
    private fun uciToMove(s: GameSession, uci: String): Int {
        if (uci.length < 4) return -1
        fun sq(f: Char, r: Char): Int = (r - '1') * 8 + (f - 'a')
        val from = sq(uci[0], uci[1])
        val to = sq(uci[2], uci[3])
        if (from !in 0..63 || to !in 0..63) return -1
        val promo = if (uci.length >= 5) when (uci[4].lowercaseChar()) {
            'q' -> QUEEN; 'r' -> ROOK; 'b' -> BISHOP; 'n' -> KNIGHT; else -> 0
        } else 0
        return s.findMove(from, to, promo)
    }

    // ---- clocks ----

    private fun startClock() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            var last = System.nanoTime()
            while (true) {
                delay(100)
                val now = System.nanoTime()
                val dt = (now - last) / 1_000_000L
                last = now
                tickClock(dt)
            }
        }
    }

    private fun tickClock(dt: Long) {
        val s = session ?: return
        val c = clocks
        if (gameKind == GameKind.ONLINE) return   // đồng hồ online do máy chủ tính (onlineClockJob)
        if (!c.enabled || s.isOver || s.records.size < 2) return
        var w = c.whiteMs
        var b = c.blackMs
        if (s.position.whiteToMove) w -= dt else b -= dt
        if (w <= 0L || b <= 0L) {
            clocks = c.copy(whiteMs = w.coerceAtLeast(0L), blackMs = b.coerceAtLeast(0L))
            s.timeout(whiteFlagged = w <= 0L)
            finishIfOver()
            return
        }
        clocks = c.copy(whiteMs = w, blackMs = b)
    }

    private fun addIncrement(whiteMoved: Boolean) {
        if (gameKind == GameKind.ONLINE) return
        val inc = timeControl.incSec * 1000L
        if (!clocks.enabled || inc <= 0L) return
        clocks = if (whiteMoved) clocks.copy(whiteMs = clocks.whiteMs + inc) else clocks.copy(blackMs = clocks.blackMs + inc)
    }

    // ---- results & feedback ----

    private fun announce(rec: MoveRecord, s: GameSession) {
        val m = rec.move
        // Quân bị ăn (kể cả bắt tốt qua đường) -> refreshUi() ngay sau đây đưa vào UiState cho hiệu ứng mờ dần.
        pendingCapture = if (rec.captured != EMPTY) {
            val capSq = if (moveFlag(m) == FLAG_EP) (moveFrom(m) shr 3) * 8 + (moveTo(m) and 7) else moveTo(m)
            intArrayOf(capSq, rec.captured)
        } else null
        if (evalBarOn) requestEval()
        scheduleLiveLabels(s)
        val sfx = when {
            s.position.inCheck() -> Sfx.CHECK
            movePromo(m) != 0 -> Sfx.PROMOTE
            moveFlag(m) == FLAG_CASTLE -> Sfx.CASTLE
            rec.captured != EMPTY -> Sfx.CAPTURE
            else -> Sfx.MOVE
        }
        // SOUND SYNC: hàm này chạy cùng lúc UiState mới (slides / captureToken) được phát ra, tức là đúng frame animation bắt đầu.
        //   MOVE    = "Tách" (R.raw.move)    -> quân đặt xuống ô
        //   CAPTURE = "Bụp"  (R.raw.capture) -> khớp với hiệu ứng quân bị ăn mờ + thu nhỏ 150ms
        // Muốn chèn đúng lúc quân chạm ô (cuối spring ~250ms) thì chuyển sounds.play sang callback kết thúc animation của BoardView.
        sounds.play(sfx)
        // HAPTIC: Light Impact khi thả thành công (ăn quân/chiếu thì rung mạnh hơn). Rung khi bắt đầu kéo nằm ở BoardView (onDragStart).
        haptics.tick(rec.captured != EMPTY || sfx == Sfx.CHECK)
    }

    private fun finishIfOver(): Boolean {
        val s = session ?: return false
        if (!s.isOver) return false
        engineCancel.set(true)
        engineJob?.cancel()
        val friend = gameKind == GameKind.FRIEND
        val humanWon = !friend && ((s.outcome == Outcome.WHITE_WINS && humanWhite) || (s.outcome == Outcome.BLACK_WINS && !humanWhite))
        val title = when {
            s.outcome == Outcome.DRAW -> "Hòa cờ"
            friend -> if (s.outcome == Outcome.WHITE_WINS) "Trắng thắng!" else "Đen thắng!"
            humanWon -> "Bạn thắng!"
            else -> "Bạn thua"
        }
        val detail = when (s.reason) {
            EndReason.CHECKMATE -> "Chiếu hết"
            EndReason.STALEMATE -> "Hết nước đi hợp lệ (hòa pat)"
            EndReason.INSUFFICIENT -> "Không đủ lực lượng để chiếu hết"
            EndReason.FIFTY -> "Luật 50 nước không bắt quân/đi tốt"
            EndReason.REPETITION -> "Lặp lại thế cờ 3 lần"
            EndReason.TIMEOUT -> if (s.outcome == Outcome.DRAW) "Hết giờ nhưng đối thủ không đủ lực lượng chiếu hết" else "Hết giờ"
            EndReason.RESIGN -> if (friend) {
                if (s.outcome == Outcome.WHITE_WINS) "Đen đã đầu hàng" else "Trắng đã đầu hàng"
            } else if (humanWon) {
                if (gameKind == GameKind.ONLINE) "Đối thủ đã đầu hàng" else "Máy đầu hàng"
            } else {
                "Bạn đã đầu hàng"
            }
            EndReason.AGREEMENT -> "Hai bên đồng ý hòa"
            EndReason.NONE -> ""
        }
        refreshUi()
        ui = ui.copy(over = true, thinking = false, resultTitle = title, resultDetail = detail, draw = s.outcome == Outcome.DRAW, humanWon = humanWon, selected = -1, targets = emptySet())
        if (!resultAnnounced) {
            resultAnnounced = true
            sounds.play(Sfx.END)
            haptics.tick(true)
            enqueueSilentReview(s)
            val score = if (s.outcome == Outcome.DRAW) 0.5 else if (humanWon) 1.0 else 0.0
            var ratingDelta = 0
            if (gameKind == GameKind.BOT || gameKind == GameKind.TOURNAMENT) {
                val mode = modeFor(timeControl)
                val before = stats.rating(mode)
                stats = StatsStore.record(prefs, stats, mode, currentLevel.id, score)
                val diff = stats.rating(mode) - before
                ratingDelta = diff
                // Hồ sơ: ghi lịch sử Elo (biểu đồ) + lịch sử ván, rồi đồng bộ cloud (nền, không chặn UI)
                UserSessionManager.onGameFinished(
                    getApplication<Application>(), mode, before, stats.rating(mode), score, opponentName(), s.records.size,
                )
                val sign = if (diff >= 0) "+" else ""
                Toast.makeText(
                    getApplication<Application>(),
                    "Hệ số " + mode.label + ": " + stats.rating(mode) + " (" + sign + diff + ")",
                    Toast.LENGTH_SHORT,
                ).show()
            }
            archiveFinishedGame(s, friend, score, ratingDelta)
            if (gameKind == GameKind.TOURNAMENT && tournamentRound >= 0) {
                tournament = Tournament.record(tournament, tournamentRound, score)
                val e = prefs.edit()
                e.putString("tourney", Tournament.serialize(tournament))
                if (Tournament.nextRound(tournament) == -1) {
                    tournamentsDone += 1
                    e.putInt("tourneyDone", tournamentsDone)
                }
                e.apply()
            }
        }
        return true
    }

    /** Game Review Ngầm: giao FEN đầu ván + các nước UCI cho WorkManager; không hiện UI nào. */
    private fun enqueueSilentReview(s: GameSession) {
        if (s.records.size < 4) { reviewSkipReason = "Ván quá ngắn để phân tích (cần ít nhất 4 nước)."; return }
        // Phân quyền: Free/Gold chỉ review 1 ván/ngày, Platinum+ không giới hạn.
        val tier = MembershipStore.get(getApplication<Application>()).tier.value
        val usage = UsageTracker.get(getApplication<Application>())
        if (!usage.canUse(Quota.GAME_REVIEW, tier)) { reviewSkipReason = "Bạn đã dùng hết lượt Game Review hôm nay. Nâng cấp để xem không giới hạn."; return }
        try {
            usage.consume(Quota.GAME_REVIEW)
            val id = java.util.UUID.randomUUID().toString()
            val ucis = s.records.map { moveUci(it.move) }
            GameAnalysisWorker.enqueueAnalysis(getApplication<Application>(), id, startFen, ucis)
            progressHandled = false
            reviewRequest = ReviewRequest(
                gameId = id,
                startFen = startFen,
                ucis = ucis,
                humanWhite = if (gameKind == GameKind.FRIEND) null else humanWhite,
                opponentName = if (gameKind == GameKind.FRIEND) "Hai người chơi" else opponentName(),
            )
        } catch (_: Throwable) {
            // Review ngầm không bao giờ được làm hỏng ván cờ.
            reviewSkipReason = "Không thể bắt đầu phân tích lúc này."
        }
    }

    /** Lưu ván vừa xong vào kho (đủ nước đi) để xem lại / phân tích sau. Chạy nền, không bao giờ làm hỏng ván. */
    private fun archiveFinishedGame(s: GameSession, friend: Boolean, score: Double, delta: Int) {
        if (s.records.size < 2) return
        try {
            val app = getApplication<Application>()
            val id = reviewRequest?.gameId ?: java.util.UUID.randomUUID().toString()
            val ucis = s.records.map { moveUci(it.move) }
            GameArchive.add(
                app,
                ArchivedGame(
                    id = id,
                    ts = System.currentTimeMillis(),
                    opponent = if (friend) "Hai người chơi" else opponentName(),
                    score = if (friend) -1.0 else score,
                    modeName = modeFor(timeControl).name,
                    timeLabel = timeControl.label,
                    delta = delta,
                    moves = s.records.size,
                    humanWhite = if (friend) null else humanWhite,
                    startFen = startFen,
                    ucis = ucis,
                    reason = s.reason.name,
                    outcome = s.outcome.name,
                ),
            )
            // Review ngầm đã trừ lượt trong ngày -> mở lại từ kho không bị trừ thêm lần nữa.
            if (reviewRequest != null) GameArchive.markPaid(app, id)
        } catch (_: Throwable) {
            // Lưu kho là phụ: không được làm hỏng luồng kết thúc ván.
        }
    }

    /** true khi màn Review đang mở từ kho ván (không phải từ ván vừa xong): nút quay lại về danh sách. */
    var reviewFromArchive by mutableStateOf(false)
        private set

    /** Vị trí cuộn của danh sách kho ván, giữ lại để quay về từ màn phân tích vẫn đứng đúng chỗ. */
    var archiveScrollIndex = 0
    var archiveScrollOffset = 0

    /** Mở phân tích một ván trong kho. Trả về thông báo lỗi nếu không mở được (quá ngắn / hết lượt), null nếu mở được. */
    fun openArchivedReview(g: ArchivedGame): String? {
        if (g.ucis.size < 4) return "Ván quá ngắn để phân tích (cần ít nhất 4 nước)."
        val app = getApplication<Application>()
        val free = GameReviewStore(app).exists(g.id) || GameArchive.isPaid(app, g.id)
        if (!free) {
            val tier = MembershipStore.get(app).tier.value
            val usage = UsageTracker.get(app)
            if (!usage.canUse(Quota.GAME_REVIEW, tier)) return "Bạn đã dùng hết lượt Game Review hôm nay. Nâng cấp để xem không giới hạn."
            usage.consume(Quota.GAME_REVIEW)
            GameArchive.markPaid(app, g.id)
        }
        reviewRequest = ReviewRequest(
            gameId = g.id,
            startFen = g.startFen,
            ucis = g.ucis,
            humanWhite = g.humanWhite,
            opponentName = g.opponent,
        )
        reviewFromArchive = true
        screen = Screen.REVIEW
        return null
    }

    /** Từ hộp thoại tổng kết: sang màn Game Review của ván vừa xong. Không có dữ liệu phân tích thì không làm gì. */
    fun openReview() {
        if (reviewRequest != null && session?.isOver == true) { progressHandled = true; screen = Screen.REVIEW }
    }

    /** Từ màn Game Review quay lại bàn cờ của ván vừa xong. */
    fun closeReview() {
        if (screen != Screen.REVIEW) return
        if (reviewFromArchive) {
            reviewFromArchive = false
            reviewRequest = null
            screen = Screen.HOME
        } else {
            screen = Screen.GAME
        }
    }

    /** Từ hộp thoại tổng kết: về menu rồi mở thẳng màn chọn Bot mới (không đụng tới luồng Giải đấu). */
    fun openBotSetupFromResult() {
        backToHome()
        navigate(HomeRoute.BOT_SELECT)
    }

    // ---- toolbar actions ----

    fun flipBoard() {
        flipped = !flipped
        refreshUi(keepSelection = true)
    }

    fun undo() {
        val s = session ?: return
        if (gameKind == GameKind.ONLINE || s.isOver || !ui.canUndo) return
        engineCancel.set(true)
        engineJob?.cancel()
        val n = if (gameKind == GameKind.FRIEND) 1 else if (isHumanTurn(s)) 2 else 1
        repeat(n) { s.undo() }
        premoves.clear()
        ui = ui.copy(thinking = false, promotion = null)
        refreshUi()
        startEngineIfNeeded()
    }

    fun resign() {
        val s = session ?: return
        if (s.isOver) return
        if (gameKind == GameKind.ONLINE) {
            onlineResign()
            return
        }
        s.resign(if (gameKind == GameKind.FRIEND) s.position.whiteToMove else humanWhite)
        finishIfOver()
    }

    fun offerDraw() {
        val s = session ?: return
        if (s.isOver) return
        if (gameKind == GameKind.ONLINE) {
            onlineDraw("offer")
            return
        }
        if (gameKind == GameKind.FRIEND) {
            s.agreeDraw()
            finishIfOver()
            return
        }
        val whiteToMove = s.position.whiteToMove
        val raw = Engine().evaluate(s.position)
        val engineScore = if (whiteToMove != humanWhite) raw else -raw
        if (s.records.size >= 20 && engineScore <= 30) {
            s.agreeDraw()
            finishIfOver()
        } else {
            val msg = if (s.records.size < 20) "Máy từ chối: còn quá sớm để hòa" else "Máy từ chối hòa"
            Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_SHORT).show()
        }
    }

    // =========================================================================
    // CHƠI ONLINE — tách riêng khỏi Bot / Bạn bè: ghép trận + ván với người thật qua Supabase (supabase/online.sql).
    // Máy chủ giữ thứ tự nước đi và ĐỒNG HỒ; máy này đi nước của mình ngay (không chờ mạng) rồi vòng đồng bộ gửi lên,
    // đồng thời kéo nước của đối thủ về (nhanh ~0,5 giây khi đang chờ đối thủ).
    // =========================================================================

    var online by mutableStateOf(OnlineUi())
        private set
    /** Thể loại giờ chọn ở màn Chơi online (lưu riêng, không đụng tới giờ của ván với máy). */
    var onlineTimeIndex by mutableIntStateOf(prefs.getInt("onlineTime", 2))
        private set

    fun updateOnlineTimeIndex(v: Int) {
        onlineTimeIndex = v
        prefs.edit().putInt("onlineTime", v).apply()
    }

    private var onlineSearchJob: Job? = null
    private var onlineSyncJob: Job? = null
    private var onlineClockJob: Job? = null
    private var onlineGame: OnlineGame? = null
    private val onlineKick = Channel<Unit>(Channel.CONFLATED)
    private var onlineResignPending = false
    private var onlineFails = 0
    private var onlineClockPly = -1

    /** Gốc đồng hồ: giờ còn lại tại [atNanos]; từ đó bên đang đến lượt bị trừ dần nếu [running]. */
    private class OnlineClockBase(
        val whiteMs: Long, val blackMs: Long, val atNanos: Long, val running: Boolean, val whiteTurn: Boolean,
    )
    private var onlineClock = OnlineClockBase(0L, 0L, 0L, false, true)

    /** Mở màn Chơi online (từ hộp thoại kết thúc ván: tìm luôn trận mới cùng thể loại giờ). */
    fun openOnlineLobby(autoSearch: Boolean) {
        backToHome()
        navigate(HomeRoute.ONLINE)
        if (autoSearch) startOnlineSearch()
    }

    /** Bắt đầu ghép trận: gọi online_find_match mỗi 1,5 giây (đồng thời là nhịp "còn online") tới khi có đối thủ. */
    fun startOnlineSearch() {
        if (online.phase == OnlinePhase.SEARCHING) return
        val tc = TimeControls.get(onlineTimeIndex)
        val app = getApplication<Application>()
        onlineSearchJob?.cancel()
        online = OnlineUi(phase = OnlinePhase.SEARCHING, searchStartedAt = System.currentTimeMillis())
        onlineSearchJob = viewModelScope.launch {
            val t0 = System.currentTimeMillis()
            var fails = 0
            while (true) {
                val r = OnlineRepository.findMatch(app, tc.baseSec, tc.incSec)
                val m = r.getOrNull()
                if (m is MatchResult.Matched) {
                    beginOnlineGame(m.game)
                    return@launch
                }
                if (r.isFailure) {
                    val kind = (r.exceptionOrNull() as? ProfileException)?.kind ?: ProfileError.SERVER
                    fails++
                    if (kind == ProfileError.NOT_SIGNED_IN || kind == ProfileError.NOT_CONFIGURED || fails >= 4) {
                        val text = if (kind == ProfileError.SERVER) {
                            "Máy chủ online chưa phản hồi. Nếu bạn là người cài đặt: hãy chạy supabase/online.sql trong Supabase."
                        } else kind.message()
                        online = OnlineUi(phase = OnlinePhase.ERROR, error = text)
                        return@launch
                    }
                } else {
                    fails = 0
                }
                if (System.currentTimeMillis() - t0 > 120_000L) {
                    online = OnlineUi(
                        phase = OnlinePhase.ERROR,
                        error = "Chưa có đối thủ cùng thể loại giờ. Hãy thử lại hoặc chọn thể loại khác.",
                    )
                    return@launch   // ngừng gọi => máy chủ tự dọn khỏi hàng đợi sau ~20 giây
                }
                delay(1500)
            }
        }
    }

    /** Hủy tìm trận (nút Hủy / rời màn). Không làm gì khi không đang tìm, nên an toàn khi gọi lúc màn bị đóng vì đã có ván. */
    fun cancelOnlineSearch() {
        if (online.phase == OnlinePhase.ERROR) {
            online = OnlineUi()
            return
        }
        if (online.phase != OnlinePhase.SEARCHING) return
        val job = onlineSearchJob
        val app = getApplication<Application>()
        online = OnlineUi()
        onlineSearchJob = null
        viewModelScope.launch {
            job?.cancelAndJoin()
            val r = OnlineRepository.cancelSearch(app).getOrNull()
            // Đúng lúc hủy lại có người ghép trúng: hủy ván đó để người kia không phải chờ.
            if (r is MatchResult.Matched) OnlineRepository.resign(app, r.game.id)
        }
    }

    private fun beginOnlineGame(g: OnlineGame) {
        val me = SupabaseCloud.userId(getApplication<Application>())
        val whiteMe = g.whiteId.equals(me, ignoreCase = true)
        stopJobs()
        releaseBotEngine()
        activeBot = null
        val s = GameSession(START_FEN)
        session = s
        gameKind = GameKind.ONLINE
        onlineGame = g
        onlineResignPending = false
        onlineFails = 0
        onlineClockPly = -1
        onlineKick.tryReceive()
        startFen = START_FEN
        startHumanWhite = whiteMe
        humanWhite = whiteMe
        flipped = !whiteMe
        engineMovesFirst = false
        timeControl = TimeControl(g.baseSec.toString(), g.baseSec, g.incSec)
        premoves.clear()
        resultAnnounced = false
        reviewRequest = null
        reviewSkipReason = null
        online = OnlineUi(
            opponentId = if (whiteMe) g.blackId else g.whiteId,
            opponentName = if (whiteMe) g.blackName else g.whiteName,
            opponentTier = if (whiteMe) g.blackTier else g.whiteTier,
        )
        clocks = ClockState(g.whiteMs, g.blackMs, true)
        ui = UiState(kind = GameKind.ONLINE)
        refreshUi()
        screen = Screen.GAME
        applyServerMoves(s, g)            // vào lại ván đang dở: dựng lại các nước đã đi
        syncOnlineClock(g, g.moves.size)
        startOnlineLoops(g.id)
    }

    private fun startOnlineLoops(gameId: String) {
        val app = getApplication<Application>()
        onlineSyncJob?.cancel()
        onlineSyncJob = viewModelScope.launch {
            while (true) {
                val s = session ?: return@launch
                if (!onlineSyncOnce(app, gameId, s)) return@launch
                // Chờ đối thủ: hỏi dồn (0,45s). Đến lượt mình: chỉ cần bắt lời cầu hòa / đầu hàng / hết giờ (1,5s). Đi nước là gọi ngay.
                withTimeoutOrNull(if (isHumanTurn(s)) 1500L else 450L) { onlineKick.receive() }
            }
        }
        onlineClockJob?.cancel()
        onlineClockJob = viewModelScope.launch {
            var lastKick = 0L
            while (true) {
                delay(100)
                publishOnlineClock()
                val s = session ?: continue
                val b = onlineClock
                if (b.running && !s.isOver) {
                    val mover = if (b.whiteTurn) clocks.whiteMs else clocks.blackMs
                    val now = System.currentTimeMillis()
                    // Hiển thị chạm 0: hỏi máy chủ ngay để chốt kết quả hết giờ.
                    if (mover <= 0L && now - lastKick > 1000L) {
                        lastKick = now
                        onlineKick.trySend(Unit)
                    }
                }
            }
        }
    }

    /** Một vòng đồng bộ. Trả về false khi ván đã chốt xong (dừng vòng lặp). */
    private suspend fun onlineSyncOnce(app: Application, gid: String, s: GameSession): Boolean {
        var fetched: OnlineGame? = null
        if (onlineResignPending) {
            fetched = OnlineRepository.resign(app, gid).getOrNull()
            if (fetched != null) onlineResignPending = false
        }
        if (fetched == null) fetched = OnlineRepository.getGame(app, gid).getOrNull()
        if (fetched == null) {
            onlineConnectionFailed()
            return true
        }
        var g: OnlineGame = fetched
        onlineFails = 0
        if (online.connectionLost) online = online.copy(connectionLost = false)

        // Gửi các nước của mình mà máy chủ chưa nhận (thường 1 nước; nhiều hơn nếu vừa mất mạng).
        while (g.active && s.records.size > g.moves.size) {
            val idx = g.moves.size
            val isLast = idx == s.records.size - 1
            var result: String? = null
            var why: String? = null
            if (isLast && s.isOver) {
                when (s.reason) {
                    EndReason.CHECKMATE -> {
                        result = if (s.outcome == Outcome.WHITE_WINS) "1-0" else "0-1"
                        why = "checkmate"
                    }
                    EndReason.STALEMATE -> { result = "1/2-1/2"; why = "stalemate" }
                    EndReason.INSUFFICIENT -> { result = "1/2-1/2"; why = "insufficient" }
                    EndReason.FIFTY -> { result = "1/2-1/2"; why = "fifty" }
                    EndReason.REPETITION -> { result = "1/2-1/2"; why = "repetition" }
                    else -> Unit
                }
            }
            val sent = OnlineRepository.sendMove(app, gid, idx, moveUci(s.records[idx].move), result, why).getOrNull()
            if (sent == null) {
                onlineConnectionFailed()
                return true
            }
            g = sent
        }

        // Nước của đối thủ.
        if (g.moves.size > s.records.size) applyServerMoves(s, g)
        if (g.moves.size == s.records.size || !g.active) syncOnlineClock(g, g.moves.size)

        // Lời cầu hòa.
        val mine = if (humanWhite) "w" else "b"
        val offer = g.drawOfferBy
        val oppOffered = g.active && offer != null && offer != mine
        val iOffered = g.active && offer == mine
        if (oppOffered != online.drawOfferedByOpponent || iOffered != online.drawOfferedByMe) {
            online = online.copy(drawOfferedByOpponent = oppOffered, drawOfferedByMe = iOffered)
        }

        if (!g.active) {
            finishOnlineFromServer(app, s, g)
            return false
        }
        return true
    }

    private fun onlineConnectionFailed() {
        onlineFails++
        if (onlineFails >= 4 && !online.connectionLost) online = online.copy(connectionLost = true)
    }

    /** Áp các nước máy chủ có mà bàn cờ chưa có. Nước MỚI của đối thủ đi qua playEngine (âm thanh, hiệu ứng, thực thi premove). */
    private fun applyServerMoves(s: GameSession, g: OnlineGame) {
        var i = s.records.size
        var silent = false
        while (i < g.moves.size && !s.isOver) {
            val m = uciToMove(s, g.moves[i])
            if (m < 0) {
                Log.w("Online", "Nước từ máy chủ không hợp lệ: " + g.moves[i])
                break
            }
            val last = i == g.moves.size - 1
            if (last && !isHumanTurn(s)) {
                playEngine(m)
            } else {
                s.play(m)
                silent = true
            }
            i++
        }
        if (silent) {
            refreshUi()
            finishIfOver()
        }
    }

    /** Máy chủ báo ván đã kết thúc (hết giờ, đầu hàng, đồng ý hòa, hủy, hoặc kết thúc theo luật) → chốt kết quả trên bàn cờ. */
    private fun finishOnlineFromServer(app: Application, s: GameSession, g: OnlineGame) {
        syncOnlineClock(g, g.moves.size)
        onlineClockJob?.cancel()
        onlineClockJob = null
        publishOnlineClock()
        if (g.aborted) {
            Toast.makeText(app, "Ván đã bị hủy (chưa ai đi đủ nước hoặc có người rời đi).", Toast.LENGTH_LONG).show()
            backToHome()
            return
        }
        if (!s.isOver) {
            when (g.reason) {
                "timeout" -> s.timeout(whiteFlagged = g.result == "0-1")
                "agreement" -> s.agreeDraw()
                else -> when (g.result) {
                    "1-0" -> s.resign(whiteResigns = false)
                    "0-1" -> s.resign(whiteResigns = true)
                    else -> s.agreeDraw()
                }
            }
        }
        finishIfOver()
    }

    // ---- đồng hồ online ----

    private fun setOnlineClock(g: OnlineGame, ply: Int) {
        onlineClock = OnlineClockBase(g.whiteMs, g.blackMs, System.nanoTime(), g.active && ply >= 2, ply % 2 == 0)
        onlineClockPly = ply
        publishOnlineClock()
    }

    /** Chỉ chỉnh lại gốc đồng hồ khi có nước mới, ván kết thúc, hoặc lệch quá 0,4s (để số trên đồng hồ không giật theo độ trễ mạng). */
    private fun syncOnlineClock(g: OnlineGame, ply: Int) {
        val c = clocks
        val drift = maxOf(abs(c.whiteMs - g.whiteMs), abs(c.blackMs - g.blackMs))
        if (ply != onlineClockPly || !g.active || drift > 400L) setOnlineClock(g, ply)
    }

    private fun publishOnlineClock() {
        val b = onlineClock
        val el = if (b.running) (System.nanoTime() - b.atNanos) / 1_000_000L else 0L
        val w = if (b.whiteTurn) b.whiteMs - el else b.whiteMs
        val bl = if (b.whiteTurn) b.blackMs else b.blackMs - el
        clocks = ClockState(w.coerceAtLeast(0L), bl.coerceAtLeast(0L), true)
    }

    /** Vừa đi một nước: đồng hồ tự chuyển bên + cộng giờ thưởng ngay (máy chủ sẽ xác nhận), rồi đẩy nước lên. */
    private fun onlineAfterLocalMove(s: GameSession, whiteMoved: Boolean) {
        val g = onlineGame ?: return
        val ply = s.records.size
        publishOnlineClock()
        var w = clocks.whiteMs
        var b = clocks.blackMs
        if (ply >= 3) {   // đồng hồ đã chạy trong lúc mình suy nghĩ => được cộng giờ thưởng
            val inc = g.incSec * 1000L
            if (whiteMoved) w += inc else b += inc
        }
        onlineClock = OnlineClockBase(w, b, System.nanoTime(), ply >= 2, s.position.whiteToMove)
        onlineClockPly = ply
        publishOnlineClock()
        onlineKick.trySend(Unit)
    }

    // ---- hành động trong ván online ----

    private fun onlineResign() {
        val s = session ?: return
        if (s.records.size < 2) {   // chưa đi đủ nước: chỉ hủy ván, không có thắng/thua
            leaveOnlineGame()
            return
        }
        onlineResignPending = true
        s.resign(humanWhite)
        finishIfOver()
        onlineKick.trySend(Unit)
    }

    /** Nút quay lại khi đang chơi: ván dở thì xử thua (hoặc hủy nếu chưa đi đủ nước), rồi về menu. */
    fun leaveOnlineGame() {
        val g = onlineGame
        val s = session
        if (g != null && s != null && !s.isOver) {
            val app = getApplication<Application>()
            viewModelScope.launch { OnlineRepository.resign(app, g.id) }   // chạy ngoài vòng đồng bộ vì backToHome() sẽ dừng vòng đó
        }
        backToHome()
    }

    private fun onlineDraw(action: String) {
        val g = onlineGame ?: return
        val app = getApplication<Application>()
        viewModelScope.launch {
            val r = OnlineRepository.draw(app, g.id, action)
            val updated = r.getOrNull()
            if (updated == null) {
                Toast.makeText(app, "Không gửi được, hãy thử lại", Toast.LENGTH_SHORT).show()
            } else if (action == "offer" && updated.active) {
                online = online.copy(drawOfferedByMe = true)
                Toast.makeText(app, "Đã gửi lời cầu hòa", Toast.LENGTH_SHORT).show()
            }
            onlineKick.trySend(Unit)
        }
    }

    fun acceptOnlineDraw() {
        online = online.copy(drawOfferedByOpponent = false)
        onlineDraw("offer")   // đối thủ đã cầu hòa trước => máy chủ coi là chấp nhận
    }

    fun declineOnlineDraw() {
        online = online.copy(drawOfferedByOpponent = false)
        onlineDraw("decline")
    }

    // ---- UI snapshot ----

    private fun refreshUi(slides: List<Slide> = emptyList(), keepSelection: Boolean = false) {
        val s = session ?: return
        val pos = s.position
        val last = if (s.records.isEmpty()) -1 else s.records[s.records.size - 1].move
        val capW = s.capturedBy(true)
        val capB = s.capturedBy(false)
        var diff = 0
        for (p in capW) diff += pieceValue(pieceType(p))
        for (p in capB) diff -= pieceValue(pieceType(p))
        if (!keepSelection) hintCancel.set(true)
        val n = if (gameKind == GameKind.FRIEND) 1 else if (isHumanTurn(s)) 2 else 1
        val minRemain = if (engineMovesFirst) 1 else 0
        val queued = premoves.toList()
        val cap = pendingCapture
        pendingCapture = null
        ui = ui.copy(
            captureSq = cap?.get(0) ?: ui.captureSq,
            capturePiece = cap?.get(1) ?: ui.capturePiece,
            captureToken = if (cap != null) ui.captureToken + 1 else ui.captureToken,
            board = (if (premoveMode == PremoveMode.MULTI && queued.isNotEmpty()) virtualPosition(s).board else pos.board).copyOf(),
            humanWhite = humanWhite,
            flipped = flipped,
            selected = if (keepSelection) ui.selected else -1,
            targets = if (keepSelection) ui.targets else emptySet(),
            lastFrom = if (last >= 0) moveFrom(last) else -1,
            lastTo = if (last >= 0) moveTo(last) else -1,
            checkSquare = if (pos.inCheck()) pos.kingSquare(pos.whiteToMove) else -1,
            premoveFrom = queued.lastOrNull()?.first ?: -1,
            premoveTo = queued.lastOrNull()?.second ?: -1,
            premoves = queued.map { Slide(it.first, it.second) },
            slides = slides,
            animToken = if (slides.isNotEmpty()) ui.animToken + 1 else ui.animToken,
            sans = s.records.map { it.san },
            moveLabels = ui.moveLabels.take(s.records.size),
            whiteToMove = pos.whiteToMove,
            capturedByWhite = capW,
            capturedByBlack = capB,
            materialDiff = diff,
            canUndo = gameKind != GameKind.ONLINE && !s.isOver && s.records.size >= n && s.records.size - n >= minRemain,
            kind = gameKind,
            hintFrom = if (keepSelection) ui.hintFrom else -1,
            hintTo = if (keepSelection) ui.hintTo else -1,
            hintText = if (keepSelection) ui.hintText else "",
            hintBusy = if (keepSelection) ui.hintBusy else false
        )
    }

    fun levelName(): String = Levels.get(level).name

    fun opponentName(): String =
        if (gameKind == GameKind.ONLINE) online.opponentName.ifBlank { "Đối thủ" }
        else if (gameKind == GameKind.TOURNAMENT) "Vòng " + (tournamentRound + 1) + "/" + Tournament.ROUNDS + " · Cấp " + currentLevel.id
        else if (activeBot != null) activeBot!!.name
        else "Máy · Cấp " + currentLevel.id

    fun pieceChoices(): IntArray = intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)
}
