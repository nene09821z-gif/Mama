package com.vila.chess.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.review.GameReviewViewModel
import com.vila.chess.review.ReviewUiState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/**
 * Lớp phủ "Đang phân tích ván đấu" nằm TRÊN bàn cờ ngay khi ván kết thúc: vòng % + thanh các nước đi + nhãn 2.5D bay lơ lửng.
 *  - Tiến độ lấy từ GameAnalysisWorker (WorkManager progress) qua [GameReviewViewModel].
 *  - Xong (Room có kết quả): vòng đầy 100%, thanh các nước đổi sang màu theo nhãn, rồi TỰ MỞ màn Review 2 trang
 *    (Phân tích / Tóm tắt) bằng [GameViewModel.openReview].
 *  - [onSkip]: người chơi muốn xem bàn cờ / hộp thoại kết quả ngay; phân tích vẫn chạy ngầm.
 */
@Composable
fun AnalysisBoardOverlay(
    vm: GameViewModel,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier,
    rv: GameReviewViewModel = viewModel(),
) {
    val req = vm.reviewRequest ?: return
    val ui = vm.ui
    LaunchedEffect(req.gameId) { rv.startGameAnalysis(req.gameId, req.ucis, req.startFen) }
    val state by rv.state.collectAsStateWithLifecycle()
    val ready = state as? ReviewUiState.Ready
    val pending = state as? ReviewUiState.Pending
    val failed = state as? ReviewUiState.Failed

    val isReady = ready != null
    LaunchedEffect(isReady) {
        if (isReady) {
            delay(900)          // cho người chơi thấy 100% + màu các nước
            vm.openReview()
        }
    }

    val n = req.ucis.size.coerceAtLeast(1)
    val total = pending?.total ?: 0
    val indeterminate = ready == null && failed == null && total == 0
    val target = when {
        ready != null -> 1f
        pending != null && total > 0 -> (pending.done.toFloat() / total).coerceIn(0f, 0.97f)
        else -> 0f
    }
    val progress by animateFloatAsState(target, tween(450), label = "analysisProgress")
    val pct = (progress * 100f).toInt().coerceIn(0, 100)
    val doneShown = if (ready != null) n else (pending?.done ?: 0).coerceIn(0, n)

    val inf = rememberInfiniteTransition(label = "analysisOverlay")
    val bob = inf.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart), label = "bob",
    )
    val spin = inf.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart), label = "spin",
    )

    val friend = ui.kind == GameKind.FRIEND
    val neutral = friend || ui.draw
    val pillTop = if (neutral) Color(0xFF6B7A99) else if (ui.humanWon) Color(0xFF5F9A2F) else Color(0xFFB4483E)
    val pillBottom = if (neutral) Color(0xFF55627C) else if (ui.humanWon) Color(0xFF487A22) else Color(0xFF8E3128)
    val pillEdge = if (neutral) Color(0xFF39425A) else if (ui.humanWon) Color(0xFF2E5016) else Color(0xFF5A1E18)
    val pillBadge = if (neutral) LabelBadge.GOOD else if (ui.humanWon) LabelBadge.BEST else LabelBadge.MISTAKE
    val pillText = ui.resultTitle.trim('!', ' ').ifBlank { "Hết ván" }

    val title = when {
        ready != null -> "Phân tích xong!"
        failed != null -> "Chưa phân tích được"
        else -> "Đang phân tích ván đấu"
    }
    val subtitle = when {
        ready != null -> "Đang mở kết quả…"
        failed != null -> failed.reason
        pending != null && pending.waitingForCharge -> "Đang chờ máy sạc hoặc pin trên 15%…"
        else -> "Máy đang chấm từng nước đi…"
    }

    Box(
        modifier.background(
            Brush.radialGradient(listOf(Color(0x40141310), Color(0xB8141310))),
        ),
        contentAlignment = Alignment.Center,
    ) {
        // Kết quả ván
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .padding(top = 10.dp)
                .drawBehind {
                    drawRoundRect(pillEdge, Offset(0f, 3.dp.toPx()), size, CornerRadius(size.height / 2f))
                }
                .clip(RoundedCornerShape(50))
                .background(Brush.verticalGradient(listOf(pillTop, pillBottom)))
                .padding(start = 6.dp, end = 14.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LabelGlyph(pillBadge, 22.dp)
            Spacer(Modifier.width(7.dp))
            Text(pillText, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 200.dp))
        }

        // Nhãn 2.5D bay lơ lửng quanh thẻ
        FloatBadge(LabelBadge.BRILLIANT, 30.dp, bob, 0f, Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 58.dp))
        FloatBadge(LabelBadge.MISTAKE, 28.dp, bob, 0.25f, Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 72.dp))
        FloatBadge(LabelBadge.GOOD, 24.dp, bob, 0.5f, Modifier.align(Alignment.CenterStart).padding(start = 6.dp))
        FloatBadge(LabelBadge.GREAT, 24.dp, bob, 0.75f, Modifier.align(Alignment.CenterEnd).padding(end = 6.dp))
        FloatBadge(LabelBadge.BEST, 28.dp, bob, 0.4f, Modifier.align(Alignment.BottomStart).padding(start = 8.dp, bottom = 58.dp))
        FloatBadge(LabelBadge.BLUNDER, 30.dp, bob, 0.1f, Modifier.align(Alignment.BottomEnd).padding(end = 8.dp, bottom = 64.dp))

        // Thẻ tiến trình
        val cardShape = RoundedCornerShape(22.dp)
        Column(
            Modifier
                .fillMaxWidth(0.78f)
                .widthIn(max = 284.dp)
                .drawBehind {
                    drawRoundRect(Color(0xFF171613), Offset(0f, 6.dp.toPx()), size, CornerRadius(22.dp.toPx()))
                }
                .clip(cardShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF383632), Color(0xFF2A2825))))
                .border(1.dp, Color(0x1AFFFFFF), cardShape)
                .padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.size(112.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(112.dp)) {
                    val sw = 12.dp.toPx()
                    val r = (size.minDimension - sw) / 2f - 3.dp.toPx()
                    val tl = Offset((size.width - 2f * r) / 2f, (size.height - 2f * r) / 2f - 2.dp.toPx())
                    val sz = Size(2f * r, 2f * r)
                    val lift = Offset(0f, 3.dp.toPx())
                    drawArc(Color(0xFF1A1916), 0f, 360f, false, tl + lift, sz, style = Stroke(sw))
                    drawArc(Color(0xFF3A3834), 0f, 360f, false, tl, sz, style = Stroke(sw))
                    val sweep = if (indeterminate) 80f else 360f * progress
                    val startA = if (indeterminate) spin.value else -90f
                    if (sweep > 1f) {
                        drawArc(Color(0xFF3A6A1C), startA, sweep, false, tl + lift, sz, style = Stroke(sw, cap = StrokeCap.Round))
                        drawArc(
                            brush = Brush.linearGradient(
                                listOf(Color(0xFFB6EC7A), Color(0xFF4FA02B)),
                                start = Offset(0f, 0f), end = Offset(size.width, size.height),
                            ),
                            startAngle = startA, sweepAngle = sweep, useCenter = false,
                            topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round),
                        )
                    }
                    drawCircle(Color(0xFF262522), r - sw / 2f - 1.dp.toPx(), Offset(tl.x + r, tl.y + r))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (indeterminate) "…" else "$pct%", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    if (!indeterminate) Text("$doneShown/$n nước", color = VilaColors.TextDim, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Text(
                subtitle, color = VilaColors.TextDim, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 2,
                modifier = Modifier.padding(top = 2.dp, bottom = 10.dp),
            )

            // Thanh các nước đi: xanh dần theo tiến độ; xong thì đổi sang màu nhãn từng nước.
            val segs = minOf(n, 40)
            val moves = ready?.data?.review?.moves
            Row(Modifier.fillMaxWidth().height(11.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (i in 0 until segs) {
                    val col = when {
                        moves != null && moves.isNotEmpty() ->
                            moves[(i * n / segs).coerceIn(0, moves.lastIndex)].label.badge().color
                        i < progress * segs -> Color(0xFF81B64C)
                        else -> Color(0x24FFFFFF)
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(col))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                LabelGlyph(LabelBadge.BRILLIANT, 18.dp)
                LabelGlyph(LabelBadge.BEST, 18.dp)
                LabelGlyph(LabelBadge.GOOD, 18.dp)
                LabelGlyph(LabelBadge.MISTAKE, 18.dp)
                LabelGlyph(LabelBadge.BLUNDER, 18.dp)
                Text("$n nước", color = VilaColors.TextDim, fontSize = 11.sp, modifier = Modifier.padding(start = 4.dp))
            }
            if (failed != null) {
                Spacer(Modifier.height(10.dp))
                OverlayPill("Thử lại", Color(0xFF81B64C), onClick = rv::retry)
            }
        }

        OverlayPill(
            "Xem ngay bàn cờ", Color(0x1AFFFFFF), onClick = onSkip,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
        )
    }
}

@Composable
private fun OverlayPill(text: String, bg: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        text, color = Color(0xFFE8ECF1), fontSize = 13.sp, fontWeight = FontWeight.Bold,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, Color(0x24FFFFFF), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
    )
}

@Composable
private fun FloatBadge(badge: LabelBadge, size: Dp, t: State<Float>, phase: Float, modifier: Modifier) {
    LabelGlyph(
        badge, size,
        modifier.graphicsLayer {
            val a = ((t.value + phase) % 1f) * 2f * PI.toFloat()
            translationY = sin(a) * 6.dp.toPx()
            rotationZ = sin(a + 1f) * 5f
        },
    )
}
