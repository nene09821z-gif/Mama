package com.vila.chess.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.core.makePiece
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.UiState

/** Các hộp xác nhận dùng chung cho màn Bot và màn PvP. */
internal enum class Confirm { EXIT, NEW_GAME, RESIGN, DRAW }

/** Bàn cờ dùng chung: kéo thả / chạm quân do BoardView xử lý, mọi nước đi vẫn đi qua GameViewModel. */
@Composable
internal fun ChessBoard(vm: GameViewModel, ui: UiState, modifier: Modifier = Modifier, evalBar: Boolean? = null) {
    // evalBar == null: màn không có Eval Bar (PvP). Khác null: luôn dùng khung Row để hiệu ứng ra/vào không làm dựng lại bàn cờ.
    if (evalBar == null) {
        BoardView(vm = vm, ui = ui, images = vm.pieceImages, modifier = modifier.fillMaxWidth())
        return
    }
    // Eval Bar trượt vào/ra từ trái (250ms). Chiều cao thanh = cạnh bàn cờ khi thanh đang hiện = bề rộng - bề rộng thanh.
    androidx.compose.foundation.layout.BoxWithConstraints(modifier.fillMaxWidth()) {
        val barW = EVAL_BAR_WIDTH
        val barH = maxWidth - barW   // đọc ở đây: trong Row (RowScope) không gọi được maxWidth của BoxWithConstraintsScope
        Row(Modifier.fillMaxWidth()) {
            AnimatedToolPanel(visible = evalBar) {
                EvalBar(
                    scoreCp = ui.evalCp,
                    ready = ui.evalReady,
                    whiteAtBottom = !ui.flipped,
                    modifier = Modifier.width(barW).height(barH),
                )
            }
            BoardView(vm = vm, ui = ui, images = vm.pieceImages, modifier = Modifier.weight(1f))
        }
    }
}

// =============================================================================
// Lịch sử nước đi
// =============================================================================

/** Thanh lịch sử nước đi cuộn ngang (dùng chung). Nước mới nhất có nền nổi bật, tự cuộn tới. */
@Composable
internal fun MoveHistory(sans: List<String>, modifier: Modifier = Modifier, labels: List<com.vila.chess.review.MoveLabel> = emptyList()) {
    val state = rememberLazyListState()
    LaunchedEffect(sans.size) {
        if (sans.isNotEmpty()) state.animateScrollToItem(sans.size - 1)
    }
    if (sans.isEmpty()) {
        Box(modifier = modifier.fillMaxHeight().padding(start = 4.dp), contentAlignment = Alignment.CenterStart) {
            Text("Các nước đi sẽ hiện ở đây", color = VilaColors.TextDim, style = VilaText.Caption)
        }
        return
    }
    LazyRow(
        state = state,
        modifier = modifier.fillMaxHeight(),
        contentPadding = PaddingValues(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        itemsIndexed(sans) { index, san ->
            val isLast = index == sans.size - 1
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (index % 2 == 0) {
                    Text(
                        "" + (index / 2 + 1) + ".",
                        color = VilaColors.TextDim,
                        style = VilaText.Move,
                        modifier = Modifier.padding(start = 6.dp, end = 2.dp)
                    )
                }
                val label = labels.getOrNull(index)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isLast) VilaColors.PanelRaised else Color.Transparent)
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        san,
                        color = if (isLast) VilaColors.Text else VilaColors.TextDim,
                        style = VilaText.Move,
                        fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium,
                    )
                    if (label != null) {
                        Spacer(Modifier.width(3.dp))
                        LabelGlyph(label.badge(), 14.dp)
                    }
                }
            }
        }
    }
}

// =============================================================================
// Thanh người chơi + đồng hồ
// =============================================================================

/** Chấm báo "đến lượt": luôn chiếm chỗ cố định (tên không bị xô lệch), chỉ hiện/ẩn mượt ở pha draw. */
@Composable
private fun TurnDot(active: Boolean) {
    val a = animateFloatAsState(if (active) 1f else 0f, tween(180), label = "turnDot")
    Box(
        modifier = Modifier
            .size(8.dp)
            .graphicsLayer {
                alpha = a.value
                scaleX = 0.4f + 0.6f * a.value
                scaleY = 0.4f + 0.6f * a.value
            }
            .clip(CircleShape)
            .background(VilaColors.Green)
    )
}

/**
 * Đồng hồ. TỰ đọc vm.clocks ở đây (lá của cây compose) nên mỗi nhịp đồng hồ chỉ vẽ lại viên thuốc này,
 * không kéo theo cả thanh người chơi (ảnh đại diện, quân đã ăn...). Số dùng chữ số cùng bề rộng để không rung.
 */
@Composable
private fun ClockPill(vm: GameViewModel, white: Boolean, active: Boolean) {
    val clock = vm.clocks
    if (!clock.enabled) return
    val ms = if (white) clock.whiteMs else clock.blackMs
    val low = ms < 20_000L
    val bg by animateColorAsState(
        targetValue = if (active) (if (low) VilaColors.ClockLowActive else VilaColors.ClockActive) else VilaColors.ClockIdle,
        animationSpec = tween(160),
        label = "clockBg",
    )
    val fg by animateColorAsState(
        targetValue = if (low) VilaColors.Danger else if (active) VilaColors.ClockActiveText else VilaColors.ClockIdleText,
        animationSpec = tween(160),
        label = "clockFg",
    )
    Box(
        modifier = Modifier
            .widthIn(min = 92.dp)
            .height(42.dp)
            .clip(RoundedCornerShape(VilaDimens.ChipRadius))
            .drawBehind { drawRect(bg) }          // màu đọc ở pha draw: đổi màu không recomposition
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.CenterEnd
    ) {
        Text(formatClock(ms), style = VilaText.Clock, color = fg)
    }
}

@Composable
internal fun PlayerBar(
    vm: GameViewModel,
    ui: UiState,
    images: Array<ImageBitmap?>,
    white: Boolean,
    name: String,
    subtitle: String? = null,
    avatarIcon: ImageVector? = null,
    avatarResId: Int? = null,
    /** Gói của người chơi này → huy hiệu VIP cạnh tên (null/FREE = không hiện). Ván online: truyền gói của đối thủ. */
    tier: com.vila.chess.billing.MembershipTier? = null,
    /** Khác null → chạm avatar/tên mở hồ sơ nhanh (OpponentProfileSheet). */
    onProfileClick: (() -> Unit)? = null,
) {
    val captured = if (white) ui.capturedByWhite else ui.capturedByBlack
    val advantage = if (white) ui.materialDiff else -ui.materialDiff
    val active = !ui.over && ui.whiteToMove == white
    val isEngine = white != ui.humanWhite && ui.kind != GameKind.FRIEND
    val avatarShape = RoundedCornerShape(VilaDimens.AvatarRadius)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = VilaDimens.ScreenPad, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val avatar = images[if (white) 6 else 14]
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(avatarShape)
                .then(if (onProfileClick != null) Modifier.clickable(onClick = onProfileClick) else Modifier)
                .background(if (avatarResId != null) Color.Transparent else if (avatarIcon != null) Color(0xFF5E8F33) else if (white) Color(0xFFB9B7B2) else Color(0xFF4A4743))
                .border(1.dp, VilaColors.AvatarBorder, avatarShape),
            contentAlignment = Alignment.Center
        ) {
            if (avatarResId != null) {
                Image(painter = androidx.compose.ui.res.painterResource(avatarResId), contentDescription = null, modifier = Modifier.size(44.dp))
            } else if (avatarIcon != null) {
                Icon(avatarIcon, contentDescription = null, tint = Color.White, modifier = Modifier.size(30.dp))
            } else if (avatar != null) {
                Image(bitmap = avatar, contentDescription = null, modifier = Modifier.size(38.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = if (onProfileClick != null) Modifier.clickable(onClick = onProfileClick) else Modifier,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TurnDot(active)
                Spacer(Modifier.width(6.dp))
                Text(
                    name,
                    color = VilaColors.Text,
                    style = VilaText.PlayerName,
                    maxLines = 1
                )
                if (tier != null && tier != com.vila.chess.billing.MembershipTier.FREE) {
                    Spacer(Modifier.width(4.dp))
                    MembershipBadge(tier, size = 16.dp)
                }
                Text(
                    if (isEngine && ui.thinking) "  đang nghĩ…" else if (subtitle != null) "  " + subtitle else if (white) "  Trắng" else "  Đen",
                    color = VilaColors.TextDim,
                    style = VilaText.Caption,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }
            Row(
                modifier = Modifier.height(20.dp).padding(start = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy((-7).dp)
            ) {
                for (p in captured) {
                    val img = images[p]
                    if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(18.dp))
                }
                if (advantage > 0) {
                    Spacer(Modifier.width(14.dp))
                    Text("+" + (advantage / 100), color = VilaColors.TextDim, style = VilaText.Caption, fontWeight = FontWeight.Bold)
                }
            }
        }
        ClockPill(vm, white, active)
    }
}

private fun formatClock(ms: Long): String {
    val total = if (ms < 0L) 0L else ms
    if (total < 20_000L) {
        val tenths = (total / 100L) % 10L
        val secs = total / 1000L
        return "0:" + (if (secs < 10L) "0" else "") + secs + "." + tenths
    }
    val totalSec = (total + 999L) / 1000L
    val m = totalSec / 60L
    val s = totalSec % 60L
    return "" + m + ":" + (if (s < 10L) "0" else "") + s
}

// =============================================================================
// Hộp thoại
// =============================================================================

@Composable
internal fun PromotionDialog(vm: GameViewModel, images: Array<ImageBitmap?>, humanWhite: Boolean) {
    Dialog(onDismissRequest = { vm.cancelPromotion() }) {
        val shape = RoundedCornerShape(VilaDimens.DialogRadius)
        Column(
            modifier = Modifier
                .clip(shape)
                .background(VilaColors.Panel)
                .border(1.dp, VilaColors.AvatarBorder, shape)
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Phong cấp thành", color = VilaColors.Text, style = VilaText.DialogTitle)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (type in vm.pieceChoices()) {
                    val img = images[makePiece(type, humanWhite)]
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .pressable(pressedScale = 0.9f, onClick = { vm.choosePromotion(type) })
                            .clip(RoundedCornerShape(12.dp))
                            .background(VilaColors.BoardLight),
                        contentAlignment = Alignment.Center
                    ) {
                        if (img != null) Image(bitmap = img, contentDescription = null, modifier = Modifier.size(60.dp))
                    }
                }
            }
        }
    }
}

/** Hộp thoại xác nhận chung. [onAccept] nhận loại xác nhận để màn hình tự gọi đúng hàm của ViewModel. */
@Composable
internal fun ConfirmDialog(confirm: Confirm?, friend: Boolean, onDismiss: () -> Unit, onAccept: (Confirm) -> Unit) {
    if (confirm == null) return
    val text = when (confirm) {
        Confirm.EXIT -> "Thoát về menu? Ván đang chơi sẽ mất."
        Confirm.NEW_GAME -> "Bỏ ván hiện tại và bắt đầu ván mới?"
        Confirm.RESIGN -> if (friend) "Người đang đến lượt muốn đầu hàng ván này?" else "Bạn muốn đầu hàng ván này?"
        Confirm.DRAW -> if (friend) "Gửi lời đề nghị hòa? Hai người chơi đồng ý hòa ván này." else "Bạn muốn xin hòa ván này?"
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VilaColors.Panel,
        shape = RoundedCornerShape(VilaDimens.DialogRadius),
        title = { Text("Xác nhận", color = VilaColors.Text, style = VilaText.DialogTitle) },
        text = { Text(text, color = VilaColors.TextDim, fontSize = 15.sp) },
        confirmButton = {
            ChunkyButton(
                text = "Đồng ý",
                onClick = { onAccept(confirm) },
                modifier = Modifier.width(116.dp),
                height = 40.dp,
                edge = 3.dp,
                radius = 8.dp,
                fontSize = 16.sp,
            )
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = VilaColors.TextDim, fontWeight = FontWeight.Bold) } }
    )
}

// =============================================================================
// Thanh công cụ dưới + thanh trên
// =============================================================================

/** Khung thanh công cụ dưới cùng: đường kẻ mảnh ở trên, các nút xếp đều. */
@Composable
internal fun GameToolbar(content: @Composable RowScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(VilaColors.PanelDark)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(VilaColors.Hairline))
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) { content() }
    }
}

/** Một nút: icon + chữ nhỏ; co nhẹ khi chạm (lò xo, ở pha draw); mờ và không bấm được khi [enabled] = false. */
@Composable
internal fun ToolbarButton(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    active: Boolean = false,
    icon: @Composable () -> Unit,
) {
    // Đổi trạng thái bật/tắt/khả dụng: nền, màu icon+chữ, độ mờ đều chuyển mượt 200ms thay vì nhảy màu.
    val bg by animateColorAsState(if (active) VilaColors.GreenDeep else Color.Transparent, tween(200), label = "tbBg")
    val fg by animateColorAsState(if (active) VilaColors.Green else VilaColors.TextDim, tween(200), label = "tbFg")
    val a by animateFloatAsState(if (enabled) 1f else 0.4f, tween(200), label = "tbAlpha")
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && enabled) 0.9f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "tbScale",
    )
    Column(
        modifier = Modifier
            .graphicsLayer {
                alpha = a
                scaleX = scale.value
                scaleY = scale.value
            }
            .clip(RoundedCornerShape(12.dp))
            .drawBehind { drawRect(bg) }          // đọc màu ở pha draw: không recomposition mỗi frame
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        CompositionLocalProvider(
            LocalContentColor provides fg,
            LocalToolbarEnabled provides enabled,
            LocalToolbarActive provides active,
        ) {
            Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) { icon() }
        }
        Text(label, color = fg, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
internal fun ToolbarVectorIcon(icon: ImageVector, label: String) {
    Icon(icon, contentDescription = label, tint = LocalContentColor.current, modifier = Modifier.size(26.dp))
}

/** Mũi tên quay lại + thanh lịch sử nước đi, như dải phía trên bàn cờ của chess.com. */
@Composable
internal fun GameTopBar(sans: List<String>, onBack: () -> Unit, labels: List<com.vila.chess.review.MoveLabel> = emptyList()) {
    Column(Modifier.fillMaxWidth().background(VilaColors.PanelDark)) {
        Row(
            modifier = Modifier.fillMaxWidth().height(44.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .pressable(onClickLabel = "Quay lại", pressedScale = 0.86f, onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(20.dp)) {
                    val w = size.width
                    val h = size.height
                    val p = Path()
                    p.moveTo(w * 0.65f, h * 0.12f)
                    p.lineTo(w * 0.27f, h * 0.5f)
                    p.lineTo(w * 0.65f, h * 0.88f)
                    drawPath(
                        path = p,
                        color = VilaColors.Text,
                        style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                    )
                }
            }
            MoveHistory(sans, Modifier.weight(1f), labels)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(VilaColors.Hairline))
    }
}
