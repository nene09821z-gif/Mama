package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.core.Position
import com.vila.chess.game.GameViewModel
import com.vila.chess.review.GameReview
import com.vila.chess.review.GameReviewViewModel
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.MoveRow
import com.vila.chess.review.ReviewData
import com.vila.chess.review.ReviewDisplay
import com.vila.chess.review.ReviewRequest
import com.vila.chess.review.ReviewUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.math.sqrt

private val EvalDark = Color(0xFF403D39)
private val EvalLight = Color(0xFFF2F2F2)
private val ArrowGreen = Color(0xCC81B64C)
private val CardBg = Color(0xFF302E2B)
private val RowAlt = Color(0xFF2B2926)
private val BoardLabelStyle = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold)

private val SkeletonBase = Color(0xFF2B2926)
private val SkeletonHighlight = Color(0x33FFFFFF)

/** Thứ tự bảng thống kê (như chess.com): 10 nhãn. */
private val LabelOrder = listOf(
    MoveLabel.BRILLIANT, MoveLabel.GREAT, MoveLabel.BEST, MoveLabel.EXCELLENT, MoveLabel.GOOD,
    MoveLabel.BOOK, MoveLabel.INACCURACY, MoveLabel.MISTAKE, MoveLabel.MISS, MoveLabel.BLUNDER,
)

// =====================================================================================
// GameReviewScreen — 2 trang: [Phân tích] bàn cờ + thanh Eval + mũi tên + danh sách nước đi,
// [Tóm tắt] độ chính xác + biểu đồ đánh giá + thống kê nước đi.
// Dữ liệu do GameAnalysisWorker phân tích NGẦM và lưu vào Room; màn này chỉ đọc (Flow). Chưa xong -> khung chờ.
// =====================================================================================
@Composable
fun GameReviewScreen(vm: GameViewModel, rv: GameReviewViewModel = viewModel()) {
    val req = vm.reviewRequest
    if (req == null) {
        LaunchedEffect(Unit) { vm.closeReview() }
        return
    }
    LaunchedEffect(req.gameId) { rv.startGameAnalysis(req.gameId, req.ucis, req.startFen) }
    BackHandler { vm.closeReview() }

    val state by rv.state.collectAsStateWithLifecycle()
    val ply by rv.ply.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(VilaColors.Bg).systemBarsPadding()) {
        ReviewTopBar("Phân tích ván đấu", req.opponentName) { vm.closeReview() }
        when (val s = state) {
            ReviewUiState.Idle -> Box(Modifier.fillMaxSize())
            is ReviewUiState.Pending -> ReviewSkeleton(s.waitingForCharge)
            is ReviewUiState.Failed -> ReviewFailed(s.reason, onRetry = rv::retry) { vm.closeReview() }
            is ReviewUiState.Ready -> ReviewContent(
                data = s.data, req = req, ply = ply, images = vm.pieceImages,
                onSeek = rv::goTo, onStep = rv::step,
            )
        }
    }
}

// ------------------------------------------------------------------ Thanh trên + loading + lỗi

@Composable
private fun ReviewTopBar(title: String, subtitle: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(VilaColors.PanelDark).padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onBack), contentAlignment = Alignment.Center) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White)
        }
        Column(Modifier.padding(start = 4.dp)) {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            if (subtitle.isNotBlank()) Text(subtitle, color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1)
        }
    }
}

/**
 * Khung chờ (skeleton) khi Room chưa có kết quả — Worker nền đang hoàn tất. Không có thanh tiến độ/phần trăm:
 * phân tích chạy ngầm hoàn toàn. Khi Room phát kết quả, màn tự chuyển sang nội dung (trượt lên + hiện dần).
 * Một InfiniteTransition duy nhất; ánh sáng quét được vẽ ở draw phase nên không recomposition mỗi frame.
 */
@Composable
private fun ReviewSkeleton(waitingForCharge: Boolean) {
    val infinite = rememberInfiniteTransition(label = "reviewSkeleton")
    val sweep = infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep",
    )
    var showChargeHint by remember { mutableStateOf(false) }
    LaunchedEffect(waitingForCharge) {
        showChargeHint = false
        if (waitingForCharge) { delay(4_000); showChargeHint = true }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val evalW = 28.dp
        val gap = 6.dp
        val boardSide = minOf(maxWidth - evalW - gap - 16.dp, maxHeight - 268.dp).coerceAtLeast(160.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Đang hoàn tất phân tích…", color = VilaColors.TextDim, fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 6.dp),
            )
            Box(Modifier.fillMaxWidth().height(56.dp).padding(vertical = 4.dp).clip(RoundedCornerShape(10.dp)).shimmer(sweep))
            Spacer(Modifier.height(18.dp))
            Row(Modifier.height(boardSide)) {
                Box(Modifier.width(evalW).fillMaxHeight().clip(RoundedCornerShape(3.dp)).shimmer(sweep))
                Spacer(Modifier.width(gap))
                Box(Modifier.size(boardSide).clip(RoundedCornerShape(4.dp)).shimmer(sweep))
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(32.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                repeat(5) { Box(Modifier.size(32.dp).clip(CircleShape).shimmer(sweep)) }
            }
            Spacer(Modifier.height(10.dp))
            Column(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(10.dp)), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                repeat(4) { Box(Modifier.fillMaxWidth().height(36.dp).shimmer(sweep)) }
            }
            if (showChargeHint) {
                Text(
                    "Đang chờ máy sạc hoặc pin trên 15% để phân tích nền.",
                    color = Color(0xFF9E9C99), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(vertical = 8.dp),
                )
            }
        }
    }
}

/** Nền xám + vệt sáng chạy ngang. Đọc [t] trong draw phase (không gây recomposition). */
private fun Modifier.shimmer(t: State<Float>): Modifier = drawBehind {
    drawRect(SkeletonBase)
    val w = size.width
    val x = (t.value * 2f - 0.5f) * w
    drawRect(
        Brush.linearGradient(
            colors = listOf(Color.Transparent, SkeletonHighlight, Color.Transparent),
            start = Offset(x - w * 0.4f, 0f),
            end = Offset(x + w * 0.4f, size.height),
        ),
    )
}

/** Hiện dần + trượt lên sau [delayMs] (xếp tầng các khối khi kết quả vừa sẵn sàng). */
@Composable
private fun SlideUpIn(delayMs: Long, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(delayMs); shown = true }
    AnimatedVisibility(
        visible = shown,
        modifier = modifier,
        enter = fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 5 },
    ) { content() }
}

@Composable
private fun ReviewFailed(reason: String, onRetry: () -> Unit, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LabelGlyph(LabelBadge.MISTAKE, 48.dp)
        Spacer(Modifier.height(14.dp))
        Text(reason, color = Color.White, fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        ReviewButton("Thử lại", Modifier.fillMaxWidth(), onRetry)
        Spacer(Modifier.height(10.dp))
        ReviewButton("Quay lại", Modifier.fillMaxWidth(), onBack)
    }
}

@Composable
private fun ReviewButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(48.dp).clip(RoundedCornerShape(10.dp)).background(VilaColors.Green).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
    }
}

// ------------------------------------------------------------------ Nội dung 2 trang

@Composable
private fun ReviewContent(
    data: ReviewData,
    req: ReviewRequest,
    ply: Int,
    images: Array<ImageBitmap?>,
    onSeek: (Int) -> Unit,
    onStep: (Int) -> Unit,
) {
    val pager = rememberPagerState(pageCount = { 2 })
    val scope = rememberCoroutineScope()
    var flipped by rememberSaveable { mutableStateOf(req.humanWhite == false) }

    // Hiện dần khi kết quả vừa xong: chuyển Loading -> Review không giật.
    val fade = remember { Animatable(0f) }
    LaunchedEffect(Unit) { fade.animateTo(1f, tween(260)) }

    Column(Modifier.fillMaxSize().graphicsLayer { alpha = fade.value }) {
        ReviewTabs(selected = pager.currentPage, fraction = pager.currentPage + pager.currentPageOffsetFraction) { scope.launch { pager.animateScrollToPage(it) } }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            if (page == 0) {
                AnalysisPage(
                    data = data, rawPly = ply, images = images, flipped = flipped,
                    onFlip = { flipped = !flipped }, onSeek = onSeek, onStep = onStep,
                )
            } else {
                SummaryPage(
                    data = data, req = req, ply = ply,
                    onSeek = { p ->
                        onSeek(p)
                        scope.launch { pager.animateScrollToPage(0) }
                    },
                )
            }
        }
    }
}

@Composable
private fun ReviewTabs(selected: Int, fraction: Float, onSelect: (Int) -> Unit) {
    val titles = listOf("Phân tích", "Tóm tắt")
    Column(Modifier.fillMaxWidth().background(VilaColors.PanelDark)) {
        Row(Modifier.fillMaxWidth()) {
            titles.forEachIndexed { i, t ->
                val on = i == selected
                Text(
                    t, color = if (on) Color.White else VilaColors.TextDim, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f).clickable { onSelect(i) }.padding(vertical = 12.dp),
                )
            }
        }
        // Vạch xanh trượt mượt theo ngón vuốt giữa 2 trang (đọc fraction ở pha draw).
        Box(
            Modifier.fillMaxWidth().height(3.dp).drawBehind {
                val half = size.width / 2f
                val inset = 18.dp.toPx()
                drawRoundRect(
                    VilaColors.Green,
                    topLeft = Offset(half * fraction.coerceIn(0f, 1f) + inset, 0f),
                    size = Size(half - 2f * inset, size.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                )
            },
        )
    }
}

// ------------------------------------------------------------------ Trang 1: Phân tích

@Composable
private fun AnalysisPage(
    data: ReviewData,
    rawPly: Int,
    images: Array<ImageBitmap?>,
    flipped: Boolean,
    onFlip: () -> Unit,
    onSeek: (Int) -> Unit,
    onStep: (Int) -> Unit,
) {
    val review = data.review
    val total = review.moves.size
    val rows = remember(review) { ReviewDisplay.buildMoveRows(review.moves, ReviewDisplay.startFullmove(data.fens[0])) }
    val ply = rawPly.coerceIn(0, total)
    val board = remember(ply, data) {
        data.boards.getOrNull(ply) ?: runCatching { Position.fromFen(data.fens[ply]).board }
            .onFailure { Log.e("GameReview", "Lỗi dựng thế cờ ply=$ply: ${it.message}") }
            .getOrElse { IntArray(64) }
    }
    val eval = remember(ply, review) { ReviewDisplay.positionEval(review, ply) }

    val played = if (ply >= 1) review.moves.getOrNull(ply - 1) else null
    val lastMove = ReviewDisplay.parseUciSquares(played?.uci)
    val bestMove = ReviewDisplay.parseUciSquares(ReviewDisplay.bestMoveAt(review, ply))
    val badge = played?.label?.badge()
    val opening = ReviewDisplay.openingAt(review, ply)

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val evalW = 28.dp
        val gap = 6.dp
        // Dành chỗ cho thẻ nước đi (56) + tên khai cuộc (20) + nút tua (52) + danh sách nước đi tối thiểu (~110).
        val boardSide = minOf(maxWidth - evalW - gap - 16.dp, maxHeight - 270.dp).coerceAtLeast(160.dp)

        Column(Modifier.fillMaxSize().padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            // Kết quả đã nằm sẵn trong Room: các khối trượt lên lần lượt cho mượt.
            SlideUpIn(0, Modifier.fillMaxWidth()) {
                MoveInfoCard(
                    title = infoTitle(data, rows, ply),
                    badge = badge,
                    detail = infoDetail(data, ply),
                    evalText = ReviewDisplay.evalText(eval.first, eval.second),
                    modifier = Modifier.fillMaxWidth().height(56.dp).padding(vertical = 4.dp),
                )
            }
            // Tên khai cuộc (giữ tên cuối cùng tìm được kể cả khi đã rời sổ khai cuộc). Cao cố định: không nhảy layout.
            Text(
                opening.orEmpty(), color = Color(0xFFB9B7B4), fontSize = 12.sp, maxLines = 1,
                modifier = Modifier.fillMaxWidth().height(20.dp).padding(horizontal = 4.dp),
            )
            SlideUpIn(80) {
                Row(Modifier.height(boardSide)) {
                    EvalBar(
                        fraction = ReviewDisplay.evalFraction(eval.first, eval.second),
                        text = ReviewDisplay.evalText(eval.first, eval.second),
                        flipped = flipped,
                        modifier = Modifier.width(evalW).fillMaxHeight(),
                    )
                    Spacer(Modifier.width(gap))
                    ReviewBoard(
                        board = board, images = images, flipped = flipped,
                        lastMove = lastMove, bestMove = bestMove, badge = badge,
                        modifier = Modifier.size(boardSide),
                    )
                }
            }
            SlideUpIn(160, Modifier.fillMaxWidth()) {
                BoardControls(
                    ply = ply, total = total,
                    onFirst = { onSeek(0) }, onPrev = { onStep(-1) }, onNext = { onStep(1) }, onLast = { onSeek(total) },
                    onFlip = onFlip,
                )
            }
            SlideUpIn(240, Modifier.weight(1f).fillMaxWidth()) {
                MoveList(
                    rows = rows, review = review, sans = data.sans, ply = ply, onSelect = onSeek,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

private fun infoTitle(data: ReviewData, rows: List<MoveRow>, ply: Int): String {
    if (ply <= 0) return "Thế cờ ban đầu"
    val m = data.review.moves[ply - 1]
    val number = rows.getOrNull(ReviewDisplay.rowIndexOf(rows, ply))?.number ?: ((ply + 1) / 2)
    return "$number${if (m.whiteMoved) "." else "…"} ${data.sans.getOrNull(ply - 1) ?: m.san ?: m.uci.orEmpty()}"
}

private fun infoDetail(data: ReviewData, ply: Int): String {
    if (ply <= 0) return "Bấm ▶ hoặc chọn nước đi bên dưới"
    val m = data.review.moves[ply - 1]
    val title = m.label.badge().title
    val better = data.bestSans.getOrNull(ply - 1)
    return when {
        m.label == MoveLabel.BOOK && m.openingName != null -> "$title · ${m.openingName}"
        ReviewDisplay.isWeak(m.label) && better != null -> "$title · Nước tốt hơn: $better"
        else -> title
    }
}

@Composable
private fun MoveInfoCard(title: String, badge: LabelBadge?, detail: String, evalText: String, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(CardBg).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (badge != null) {
            LabelGlyph(badge, 40.dp)
            Spacer(Modifier.width(10.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(detail, color = badge?.color ?: VilaColors.TextDim, fontSize = 12.sp, maxLines = 1)
        }
        Text(
            evalText, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(EvalDark).padding(horizontal = 8.dp, vertical = 3.dp),
        )
    }
}

// ------------------------------------------------------------------ Thanh Eval

/** [fraction] = phần của Trắng (0..1). Trắng ở dưới khi bàn cờ không lật; số điểm nằm ở đầu bên đang hơn. */
@Composable
private fun EvalBar(fraction: Float, text: String, flipped: Boolean, modifier: Modifier = Modifier) {
    val anim = animateFloatAsState(fraction, tween(450, easing = FastOutSlowInEasing), label = "evalBar")
    val whiteAhead = fraction >= 0.5f
    Box(modifier.clip(RoundedCornerShape(3.dp))) {
        Canvas(Modifier.fillMaxSize()) {
            drawRect(EvalDark)
            val h = size.height * anim.value        // đọc ở draw phase: animate không gây recomposition
            val top = if (flipped) 0f else size.height - h
            drawRect(EvalLight, Offset(0f, top), Size(size.width, h))
        }
        Text(
            text,
            color = if (whiteAhead) Color(0xFF262421) else Color.White,
            fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .align(if (whiteAhead != flipped) Alignment.BottomCenter else Alignment.TopCenter)
                .padding(vertical = 3.dp),
        )
    }
}

// ------------------------------------------------------------------ Bàn cờ + mũi tên

@Composable
private fun ReviewBoard(
    board: IntArray,
    images: Array<ImageBitmap?>,
    flipped: Boolean,
    lastMove: Pair<Int, Int>?,
    bestMove: Pair<Int, Int>?,
    badge: LabelBadge?,
    modifier: Modifier = Modifier,
) {
    val measurer = rememberTextMeasurer()
    val fileLabels = remember(measurer) { List(8) { measurer.measure(('a' + it).toString(), BoardLabelStyle) } }
    val rankLabels = remember(measurer) { List(8) { measurer.measure(('1' + it).toString(), BoardLabelStyle) } }
    // Mũi tên "mọc" từ ô xuất phát mỗi khi nước tốt nhất đổi (tua nước đi).
    val reveal = remember(bestMove) { Animatable(0f) }
    LaunchedEffect(bestMove) { reveal.animateTo(1f, tween(220)) }

    Canvas(modifier.clip(RoundedCornerShape(4.dp))) {
        val s = size.width / 8f

        for (sq in 0 until 64) {
            val light = ((sq shr 3) + (sq and 7)) % 2 == 1
            drawRect(
                if (light) VilaColors.BoardLight else VilaColors.BoardDark,
                squareTopLeft(sq, s, flipped), Size(s, s),
            )
        }
        if (lastMove != null) {
            drawRect(VilaColors.Highlight, squareTopLeft(lastMove.first, s, flipped), Size(s, s))
            drawRect(VilaColors.Highlight, squareTopLeft(lastMove.second, s, flipped), Size(s, s))
        }

        // Tọa độ trong ô (cột a–h ở hàng dưới cùng, hàng 1–8 ở cột trái cùng).
        val pad = 2.dp.toPx()
        for (col in 0..7) {
            val f = if (flipped) 7 - col else col
            val r = if (flipped) 7 else 0
            val lay = fileLabels[f]
            drawText(
                lay, coordColor((r + f) % 2 == 1),
                Offset(col * s + s - lay.size.width - pad, 7 * s + s - lay.size.height - pad / 2f),
            )
        }
        for (row in 0..7) {
            val r = if (flipped) row else 7 - row
            val f = if (flipped) 7 else 0
            drawText(rankLabels[r], coordColor((r + f) % 2 == 1), Offset(pad, row * s + pad / 2f))
        }

        for (sq in 0 until 64) {
            val code = board[sq]
            val img = if (code > 0 && code < images.size) images[code] else null
            if (img != null) {
                val o = squareTopLeft(sq, s, flipped)
                drawImage(
                    image = img,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(img.width, img.height),
                    dstOffset = IntOffset(o.x.roundToInt(), o.y.roundToInt()),
                    dstSize = IntSize(s.roundToInt() + 1, s.roundToInt() + 1),
                    filterQuality = FilterQuality.High,
                )
            }
        }

        if (bestMove != null) drawBestMoveArrow(bestMove.first, bestMove.second, flipped, ArrowGreen, reveal.value)

        // Nhãn 2.5D (!!, ?, ??, ★…) ở góc trên-phải ô đích của nước vừa đi.
        if (lastMove != null && badge != null) {
            val o = squareTopLeft(lastMove.second, s, flipped)
            val d = s * 0.56f
            val bx = (o.x + s - d * 0.78f).coerceAtMost(size.width - d)
            val by = (o.y - d * 0.14f).coerceAtLeast(0f)
            drawLabelBadge(badge, Offset(bx, by), d)
        }
    }
}

private fun coordColor(lightSquare: Boolean): Color = if (lightSquare) VilaColors.BoardDark else VilaColors.BoardLight

/**
 * Mũi tên từ ô [from] tới ô [to] vẽ bằng một Path khép kín (thân + đầu tam giác) qua drawPath.
 * [progress] 0..1: độ dài đã "mọc" (animation). Mũi tên nằm đè lên quân cờ nhưng hơi trong suốt.
 */
private fun DrawScope.drawBestMoveArrow(from: Int, to: Int, flipped: Boolean, color: Color, progress: Float) {
    val s = size.width / 8f
    fun center(sq: Int): Offset {
        val o = squareTopLeft(sq, s, flipped)
        return Offset(o.x + s / 2f, o.y + s / 2f)
    }
    val a = center(from)
    val b = center(to)
    val dx = b.x - a.x
    val dy = b.y - a.y
    val len = sqrt(dx * dx + dy * dy)
    if (len < 1f) return
    val ux = dx / len
    val uy = dy / len
    val nx = -uy
    val ny = ux

    val startX = a.x + ux * s * 0.22f
    val startY = a.y + uy * s * 0.22f
    val fullTipX = b.x - ux * s * 0.10f
    val fullTipY = b.y - uy * s * 0.10f
    val p = progress.coerceIn(0f, 1f)
    val tipX = startX + (fullTipX - startX) * p
    val tipY = startY + (fullTipY - startY) * p

    val segX = tipX - startX
    val segY = tipY - startY
    val segLen = sqrt(segX * segX + segY * segY)
    if (segLen < 1f) return
    val headLen = minOf(s * 0.36f, segLen)
    val bodyHalf = s * 0.10f
    val headHalf = s * 0.25f
    val baseX = tipX - ux * headLen      // gốc đầu mũi tên
    val baseY = tipY - uy * headLen

    val path = Path().apply {
        moveTo(startX + nx * bodyHalf, startY + ny * bodyHalf)
        lineTo(baseX + nx * bodyHalf, baseY + ny * bodyHalf)
        lineTo(baseX + nx * headHalf, baseY + ny * headHalf)
        lineTo(tipX, tipY)
        lineTo(baseX - nx * headHalf, baseY - ny * headHalf)
        lineTo(baseX - nx * bodyHalf, baseY - ny * bodyHalf)
        lineTo(startX - nx * bodyHalf, startY - ny * bodyHalf)
        close()
    }
    drawPath(path, color)
}

// ------------------------------------------------------------------ Nút tua + danh sách nước đi

@Composable
private fun BoardControls(
    ply: Int, total: Int,
    onFirst: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit, onLast: () -> Unit, onFlip: () -> Unit,
) {
    Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
        ControlButton(Icons.Filled.SkipPrevious, "Về đầu ván", ply > 0, Modifier.weight(1f), onFirst)
        ControlButton(Icons.AutoMirrored.Filled.ArrowBack, "Nước trước", ply > 0, Modifier.weight(1f), onPrev)
        ControlButton(Icons.AutoMirrored.Filled.ArrowForward, "Nước sau", ply < total, Modifier.weight(1f), onNext)
        ControlButton(Icons.Filled.SkipNext, "Tới cuối ván", ply < total, Modifier.weight(1f), onLast)
        ControlButton(Icons.Filled.SwapVert, "Lật bàn cờ", true, Modifier.weight(1f), onFlip)
    }
}

@Composable
private fun ControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier.fillMaxHeight().alpha(if (enabled) 1f else 0.3f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun MoveList(
    rows: List<MoveRow>,
    review: GameReview,
    sans: List<String>,
    ply: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val listState = rememberLazyListState()
    val idx = ReviewDisplay.rowIndexOf(rows, ply)
    // Giữ nước đang xem trong tầm nhìn (chừa lại một dòng phía trên để thấy ngữ cảnh).
    // Chỉ cuộn khi dòng đang xem sắp ra khỏi tầm nhìn; tua liên tục (giữ nút) không chồng nhiều animation cuộn.
    LaunchedEffect(idx) {
        if (idx < 0) return@LaunchedEffect
        val visible = listState.layoutInfo.visibleItemsInfo
        val first = visible.firstOrNull()?.index ?: 0
        val last = visible.lastOrNull()?.index ?: 0
        if (visible.isEmpty() || idx <= first || idx >= last) {
            if (kotlin.math.abs(idx - first) > 6) listState.scrollToItem((idx - 1).coerceAtLeast(0))
            else listState.animateScrollToItem((idx - 1).coerceAtLeast(0))
        }
    }

    LazyColumn(modifier.clip(RoundedCornerShape(10.dp)).background(CardBg), state = listState) {
        items(rows.size, key = { rows[it].number }) { i ->
            val row = rows[i]
            Row(
                Modifier.fillMaxWidth().background(if (i % 2 == 0) CardBg else RowAlt),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "${row.number}.", color = VilaColors.TextDim, fontSize = 13.sp,
                    modifier = Modifier.width(40.dp).padding(start = 10.dp),
                )
                MoveCell(row.whitePly, review, sans, ply, onSelect, Modifier.weight(1f))
                MoveCell(row.blackPly, review, sans, ply, onSelect, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MoveCell(
    cellPly: Int?, review: GameReview, sans: List<String>, selectedPly: Int,
    onSelect: (Int) -> Unit, modifier: Modifier,
) {
    if (cellPly == null) {
        Box(modifier.height(36.dp))
        return
    }
    val m = review.moves[cellPly - 1]
    val selected = cellPly == selectedPly
    Row(
        modifier
            .height(36.dp)
            .background(if (selected) VilaColors.Green.copy(alpha = 0.35f) else Color.Transparent)
            .clickable { onSelect(cellPly) }
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LabelGlyph(m.label.badge(), 18.dp)
        Spacer(Modifier.width(6.dp))
        Text(
            sans.getOrNull(cellPly - 1) ?: m.san ?: m.uci.orEmpty(),
            color = Color.White, fontSize = 15.sp, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

// ------------------------------------------------------------------ Trang 2: Tóm tắt

@Composable
private fun SummaryPage(data: ReviewData, req: ReviewRequest, ply: Int, onSeek: (Int) -> Unit) {
    val review = data.review
    val whiteName = when (req.humanWhite) { null -> "Trắng"; true -> "Bạn"; false -> "Đối thủ" }
    val blackName = when (req.humanWhite) { null -> "Đen"; true -> "Đối thủ"; false -> "Bạn" }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AccuracyCard(whiteName, review.accuracyWhite, true, Modifier.weight(1f))
            AccuracyCard(blackName, review.accuracyBlack, false, Modifier.weight(1f))
        }
        SectionTitle("Biểu đồ đánh giá")
        EvalGraph(review, ply, onSeek)
        Text("Chạm vào biểu đồ để xem lại thế cờ tại điểm đó.", color = Color(0xFF9E9C99), fontSize = 12.sp)
        SectionTitle("Thống kê nước đi")
        StatsTable(review, whiteName, blackName)
        Text(engineNote(review), color = Color(0xFF9E9C99), fontSize = 12.sp)
    }
}

private fun engineNote(review: GameReview): String {
    val name = when (review.engine) {
        "native" -> "Stockfish (native)"
        "wasm" -> "Stockfish (wasm lite)"
        "none" -> "Luật cờ"
        else -> "Stockfish"
    }
    val depth = review.moves.maxOfOrNull { it.depthBefore } ?: 0
    return if (depth > 0) "Engine: $name · độ sâu $depth" else "Engine: $name"
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
}

@Composable
private fun AccuracyCard(label: String, value: Double, whiteSide: Boolean, modifier: Modifier = Modifier) {
    val fg = if (whiteSide) Color(0xFF262421) else Color.White
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(if (whiteSide) Color.White else EvalDark).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, color = fg.copy(alpha = 0.7f), fontSize = 13.sp)
        Text("%.1f".format(value), color = fg, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Độ chính xác", color = fg.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

/** Biểu đồ đánh giá vẽ bằng Canvas: vùng sáng = phần Trắng hơn, chấm đỏ/cam/hồng = Blunder/Mistake/Miss, vạch xanh = nước đang xem. */
@Composable
private fun EvalGraph(review: GameReview, ply: Int, onSeek: (Int) -> Unit) {
    val n = review.moves.size
    val fractions = remember(review) {
        FloatArray(n + 1) { i ->
            val e = ReviewDisplay.positionEval(review, i)
            ReviewDisplay.evalFraction(e.first, e.second)
        }
    }
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(10.dp))
            .pointerInput(n) {
                detectTapGestures { pos ->
                    if (n > 0) onSeek((pos.x / size.width * n).roundToInt().coerceIn(0, n))
                }
            },
    ) {
        val w = size.width
        val h = size.height
        fun xAt(i: Int) = if (n == 0) 0f else w * i / n
        fun yAt(i: Int) = h * (1f - fractions[i])

        drawRect(EvalDark)
        val area = Path().apply {
            moveTo(0f, h)
            for (i in 0..n) lineTo(xAt(i), yAt(i))
            lineTo(w, h)
            close()
        }
        drawPath(area, EvalLight.copy(alpha = 0.92f))
        drawLine(Color(0x66000000), Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1.dp.toPx())

        for (m in review.moves) {
            if (m.label == MoveLabel.BLUNDER || m.label == MoveLabel.MISTAKE || m.label == MoveLabel.MISS) {
                val c = Offset(xAt(m.ply), yAt(m.ply))
                drawCircle(m.label.badge().color, if (m.label == MoveLabel.BLUNDER) 4.5.dp.toPx() else 3.5.dp.toPx(), c)
            }
        }

        val sx = xAt(ply.coerceIn(0, n))
        drawLine(VilaColors.Green, Offset(sx, 0f), Offset(sx, h), strokeWidth = 2.dp.toPx())
        drawCircle(VilaColors.Green, 4.dp.toPx(), Offset(sx, yAt(ply.coerceIn(0, n))), style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun StatsTable(review: GameReview, whiteName: String, blackName: String) {
    val white = remember(review) { ReviewDisplay.countsByLabel(review, true) }
    val black = remember(review) { ReviewDisplay.countsByLabel(review, false) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(CardBg).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f))
            Text(whiteName, color = VilaColors.TextDim, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.width(72.dp))
            Text(blackName, color = VilaColors.TextDim, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.width(72.dp))
        }
        LabelOrder.forEach { l ->
            val b = l.badge()
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                LabelGlyph(b, 26.dp)
                Spacer(Modifier.width(10.dp))
                Text(b.title, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text(
                    "${white[l] ?: 0}", color = b.color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center, modifier = Modifier.width(72.dp),
                )
                Text(
                    "${black[l] ?: 0}", color = b.color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center, modifier = Modifier.width(72.dp),
                )
            }
        }
    }
}
