package com.vila.chess.game

import com.vila.chess.core.Engine
import com.vila.chess.core.Position
import com.vila.chess.core.SearchLimits
import com.vila.chess.core.moveUci
import com.vila.chess.review.EngineResult
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewReplay
import kotlin.math.abs

/**
 * Gán nhãn chất lượng (Brilliant … Blunder) NGAY TRONG ván đang chơi, kiểu chess.com.
 *
 * Dùng lại đúng bộ phân loại của màn xem lại ván ([ReviewAssembler] / ReviewAnalyzer) nên nhãn lúc chơi và nhãn
 * lúc xem lại cùng một luật. Engine ở đây là engine Kotlin nhẹ (không cần Stockfish native, không MultiPV) nên
 * không có nhãn Great (cần nước tốt nhì); các nhãn còn lại giữ nguyên.
 *
 * Hàm thuần (không Android) -> test được trên JVM.
 */
object LiveMoveLabeler {
    /** Lượt tìm nhanh cho mọi thế (mỗi nước đi chỉ tốn đúng 1 lượt tìm mới vì thế trước đã có trong cache). */
    val FAST = SearchLimits(7, 650L, 0)
    /** Lượt kiểm chứng sâu hơn, chỉ dùng cho nước nghi sai để tránh gán nhãn xấu "oan" do nhiễu độ sâu. */
    val DEEP = SearchLimits(10, 1800L, 0)

    const val ENGINE_NAME = "kotlin"

    /** Nhãn cần kiểm chứng sâu trước khi chốt. */
    val SUSPECT: Set<MoveLabel> = setOf(MoveLabel.INACCURACY, MoveLabel.MISTAKE, MoveLabel.BLUNDER, MoveLabel.MISS)

    /**
     * Phân tích thế [fen]. Điểm theo góc nhìn bên đang đi. Thế đã kết thúc ván tính bằng luật cờ.
     * null = bị huỷ hoặc không có nước đi.
     */
    fun evaluate(fen: String, limits: SearchLimits, cancelled: () -> Boolean): EngineResult? {
        ReviewReplay.terminalEval(fen)?.let { return it }
        val pos = Position.fromFen(fen)
        val engine = Engine()
        engine.cancelled = cancelled
        val move = engine.findBestMove(pos.copy(), limits)
        if (move == 0 || cancelled()) return null
        val s = engine.lastScore
        val uci = moveUci(move)
        return if (abs(s) >= Engine.MATE - 100) {
            val n = ((Engine.MATE - abs(s) + 1) / 2).coerceAtLeast(1)
            val sign = if (s > 0) 1 else -1
            // Quy ước của ReviewModels: có mate thì cp = ±(10000 - 10 * soNuocMate), mate dương = bên đang đi chiếu hết.
            EngineResult(uci, sign * (10_000 - 10 * n), sign * n, limits.maxDepth, false, listOf(uci), engine = ENGINE_NAME)
        } else {
            EngineResult(uci, s, null, limits.maxDepth, false, listOf(uci), engine = ENGINE_NAME)
        }
    }

    /**
     * Nhãn của mọi nước đã đi (phần tử i = nước thứ i + 1). [evalOf] trả về phân tích của một FEN (thường lấy từ cache,
     * chỉ tìm mới thế chưa có). null nếu ván không dựng lại được hoặc [evalOf] trả null (bị huỷ).
     */
    fun labelGame(
        startFen: String,
        ucis: List<String>,
        evalOf: (String) -> EngineResult?,
        book: OpeningBook? = null,
    ): List<MoveLabel>? {
        if (ucis.isEmpty()) return emptyList()
        val replay = ReviewReplay.replay(startFen, ucis) ?: return null
        val evals = ArrayList<EngineResult>(replay.plies.size + 1)
        evals += evalOf(replay.startFen) ?: return null
        for (p in replay.plies) evals += evalOf(p.fenAfter) ?: return null
        val review = ReviewAssembler.assemble("live", replay.startFen, replay.plies, evals, "live", 0L, book)
        return review.moves.map { it.label }
    }

    /** Hai thế quanh nước đi cuối (trước và sau) — các thế cần tìm sâu khi kiểm chứng. null nếu không dựng lại được. */
    fun lastMoveFens(startFen: String, ucis: List<String>): List<String>? {
        if (ucis.isEmpty()) return null
        val replay = ReviewReplay.replay(startFen, ucis) ?: return null
        val last = replay.plies.last()
        return listOf(last.fenBefore, last.fenAfter)
    }

    /** Câu nhận xét kiểu chess.com cho khung huấn luyện viên. */
    fun describe(san: String, label: MoveLabel): String = when (label) {
        MoveLabel.BRILLIANT -> "$san là nước đi xuất sắc nhất!"
        MoveLabel.GREAT -> "$san là nước đi tuyệt vời"
        MoveLabel.BEST -> "$san là nước đi tốt nhất"
        MoveLabel.EXCELLENT -> "$san là nước đi rất tốt"
        MoveLabel.GOOD -> "$san là nước đi tốt"
        MoveLabel.BOOK -> "$san là nước đi khai cuộc"
        MoveLabel.INACCURACY -> "$san là nước đi thiếu chính xác"
        MoveLabel.MISTAKE -> "$san là một sai lầm"
        MoveLabel.MISS -> "$san bỏ lỡ cơ hội"
        MoveLabel.BLUNDER -> "$san là một sai lầm nghiêm trọng"
    }
}
