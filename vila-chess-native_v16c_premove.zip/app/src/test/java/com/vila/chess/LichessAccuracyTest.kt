package com.vila.chess

import com.vila.chess.review.LichessAccuracy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Điểm chính xác theo chuẩn Lichess (lila AccuracyPercent.scala). Số kỳ vọng tính độc lập bằng bản port Python. */
class LichessAccuracyTest {

    @Test fun winPct_matchesLichessFormula() {
        assertEquals(50.0, LichessAccuracy.winPct(0), 1e-9)
        assertEquals(97.5447, LichessAccuracy.winPct(1000), 1e-3)
        assertEquals(LichessAccuracy.winPct(1000), LichessAccuracy.winPct(5000), 1e-12)     // kẹp ±1000
        assertEquals(100.0 - LichessAccuracy.winPct(300), LichessAccuracy.winPct(-300), 1e-9) // đối xứng
    }

    @Test fun mateCountsAsPlusMinus1000cp() {
        val m = LichessAccuracy.winPct(1000)
        assertEquals(m, LichessAccuracy.winWhitePct(30, 3), 1e-9)
        assertEquals(100.0 - m, LichessAccuracy.winWhitePct(-30, -2), 1e-9)
        assertEquals(m, LichessAccuracy.winWhitePct(-10_000 * -1, 0), 1e-9)     // đã bị chiếu hết, cp dương => Trắng thắng
        assertEquals(100.0 - m, LichessAccuracy.winWhitePct(-10_000, 0), 1e-9)
    }

    @Test fun moveAccuracy_hasPlusOneBonusAndClamps() {
        assertEquals(100.0, LichessAccuracy.moveAccuracy(0.0), 1e-9)       // 100,9999 kẹp về 100
        assertEquals(100.0, LichessAccuracy.moveAccuracy(-5.0), 1e-9)      // thế tốt lên cũng không quá 100
        assertEquals(25.772, LichessAccuracy.moveAccuracy(30.0), 1e-3)     // 103.1668*exp(-0.04354*30) - 3.1669 + 1
        assertTrue(LichessAccuracy.moveAccuracy(100.0) in 0.0..2.0)
    }

    @Test fun combine_matchesLichessForumExample() {
        // 9 nước 100 + 1 nước 25, trọng số bằng nhau: TB = 92,5 · TB điều hòa = 76,92 · trung bình hai số = 84,71
        val accs = List(9) { 100.0 } + 25.0
        assertEquals(84.7115, LichessAccuracy.combine(accs, List(10) { 1.0 }), 1e-3)
    }

    @Test fun windowSize_followsGameLength() {
        assertEquals(2, LichessAccuracy.windowSize(5))
        assertEquals(3, LichessAccuracy.windowSize(30))
        assertEquals(8, LichessAccuracy.windowSize(200))
    }

    @Test fun volatilityWeights_alignWithEveryMoveAndClamp() {
        val flat = List(21) { 50.0 }
        val w0 = LichessAccuracy.volatilityWeights(flat)
        assertEquals(20, w0.size)
        assertTrue(w0.all { it == LichessAccuracy.MIN_WEIGHT })

        val spike = MutableList(21) { 50.0 }.also { it[10] = 90.0 }
        val w = LichessAccuracy.volatilityWeights(spike)
        assertEquals(20, w.size)
        assertEquals(LichessAccuracy.MAX_WEIGHT, w[9], 1e-9)    // cửa sổ [50, 90] có độ lệch chuẩn 20 => kẹp 12
        assertEquals(LichessAccuracy.MAX_WEIGHT, w[10], 1e-9)
        assertEquals(LichessAccuracy.MIN_WEIGHT, w[0], 1e-9)

        val long = List(31) { 50.0 }                              // 30 nước => cửa sổ 3 (có phần đệm đầu)
        assertEquals(30, LichessAccuracy.volatilityWeights(long).size)
    }

    @Test fun gameAccuracy_matchesPythonReference() {
        // 30 nước: Trắng sai nặng ở nước 15 (mất 25% win), Đen sai nhẹ ở nước 22 (mất 8%).
        val win = ArrayList<Double>().apply { add(50.0) }
        val drops = ArrayList<Double>()
        val white = ArrayList<Boolean>()
        var cur = 50.0
        for (i in 0 until 30) {
            val w = i % 2 == 0
            val d = when (i) { 14 -> 25.0; 21 -> 8.0; else -> 0.0 }
            cur = if (w) cur - d else cur + d
            win += cur; drops += d; white += w
        }
        val (accW, accB) = LichessAccuracy.gameAccuracy(win, drops, white)
        assertEquals(75.9203, accW, 0.01)
        assertEquals(96.1439, accB, 0.01)
        assertTrue(accW < accB)
    }

    @Test fun perfectGameIs100_andSideWithoutMovesIs100() {
        val (w, b) = LichessAccuracy.gameAccuracy(List(11) { 50.0 }, List(10) { 0.0 }, List(10) { it % 2 == 0 })
        assertEquals(100.0, w, 1e-9)
        assertEquals(100.0, b, 1e-9)
        val (w1, b1) = LichessAccuracy.gameAccuracy(listOf(50.0, 50.0), listOf(0.0), listOf(true))
        assertEquals(100.0, w1, 1e-9)
        assertEquals(100.0, b1, 1e-9)   // Đen không có nước nào
    }
}
