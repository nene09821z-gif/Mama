package com.vila.chess.coach

import com.vila.chess.core.BISHOP
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.KING
import com.vila.chess.core.sqName
import com.vila.chess.game.EndReason
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import kotlin.random.Random

/** Dấu thầy vẽ lên bàn cờ để chỉ cho người học. */
enum class MarkKind { CIRCLE, ARROW }
data class Mark(val kind: MarkKind, val from: Int, val to: Int = -1)

/** Một câu thầy nói. */
data class TeacherLine(
    val id: Long,
    val text: String,
    val say: Say,
    val mood: Mood,
    val marks: List<Mark> = emptyList(),
    /** Số nước đã đi khi thầy nói (để ghi "Nước 12" trong sổ tay). 0 = ngoài ván. */
    val ply: Int = 0,
)

/** Thông tin một nước vừa đi để thầy phản ứng. */
class MoveContext(
    val before: Position,
    val after: Position,
    val move: Int,
    val san: String,
    val moves: List<Int>,
    val capturedType: Int,
    val humanWhite: Boolean,
    val byHuman: Boolean,
    val botName: String,
)

fun pieceNameVi(type: Int): String = when (type) {
    PAWN -> "Tốt"; KNIGHT -> "Mã"; BISHOP -> "Tượng"; ROOK -> "Xe"; QUEEN -> "Hậu"; KING -> "Vua"; else -> "quân"
}

private class Ctx(
    val san: String = "", val piece: String = "", val sq: String = "", val file: String = "",
    val n: Int = 0, val opening: String = "", val bot: String = "", val target: String = "",
)

private class Cand(val say: Say, val weight: Int, val ctx: Ctx, val marks: List<Mark> = emptyList())

/**
 * Bộ não của thầy. Thuần Kotlin (không Android) nên test được trên JVM.
 *
 *  - Đọc nước vừa đi ([MoveReader]) + đọc cả bàn cờ ([BoardReader]) rồi chọn lời nói.
 *  - Không bao giờ lặp một câu cho đến khi đã dùng hết cả nhóm (shuffle-bag).
 *  - Mỗi chủ đề có "thời gian nghỉ" để thầy không nói đi nói lại một điều.
 *  - [talkiness]: 0 = ít (chỉ chuyện quan trọng) · 1 = vừa · 2 = nhiều (gần như nước nào cũng nói).
 */
class TeacherBrain(
    var persona: Persona = Persona.GENTLE,
    var talkiness: Int = 2,
    private val rnd: Random = Random.Default,
    var book: OpeningBook? = null,
) {
    private var idSeq = 1L
    private val bags = HashMap<Say, ArrayList<Int>>()
    private val lastTopicPly = HashMap<Topic, Int>()
    private val repetition = HashMap<String, Int>()
    private var goodStreak = 0
    private var lastAdvClass = 0
    private var endgameAnnounced = false
    private var lastOpening: String? = null
    private var botShort = "Máy"

    /** Xóa trí nhớ ván cũ. */
    fun reset() {
        lastTopicPly.clear(); repetition.clear()
        goodStreak = 0; lastAdvClass = 0; endgameAnnounced = false; lastOpening = null
    }

    // ------------------------------------------------------------------ dựng câu

    private fun nextFrom(say: Say): String {
        val all = TeacherLines.lines(say)
        if (all.isEmpty()) return ""
        val bag = bags.getOrPut(say) { ArrayList() }
        if (bag.isEmpty()) {
            val idx = all.indices.toMutableList()
            idx.shuffle(rnd)
            bag.addAll(idx)
        }
        return all[bag.removeAt(bag.size - 1)]
    }

    private fun capFirst(s: String): String =
        if (s.isEmpty()) s else s.substring(0, 1).uppercase() + s.substring(1)

    private fun fill(template: String, c: Ctx): String {
        var s = template
        s = s.replace("{me}", persona.me).replace("{Me}", capFirst(persona.me))
            .replace("{you}", persona.you).replace("{You}", capFirst(persona.you))
            .replace("{san}", c.san).replace("{piece}", c.piece).replace("{sq}", c.sq)
            .replace("{file}", c.file).replace("{n}", c.n.toString())
            .replace("{opening}", c.opening).replace("{bot}", c.bot).replace("{target}", c.target)
        return capFirst(s.trim())
    }

    private fun make(say: Say, c: Ctx, marks: List<Mark>, ply: Int, mood: Mood = say.mood()): TeacherLine {
        val body = fill(nextFrom(say), c)
        val plain = say == Say.TIP || say == Say.JOKE
        val opener = if (plain) "" else TeacherLines.opener(persona, mood, rnd.nextDouble())
        return TeacherLine(idSeq++, opener + body, say, mood, marks, ply)
    }

    private fun make(c: Cand, ply: Int): TeacherLine = make(c.say, c.ctx, c.marks, ply)

    private fun circle(vararg sq: Int) = sq.filter { it in 0..63 }.take(3).map { Mark(MarkKind.CIRCLE, it) }

    // ------------------------------------------------------------------ mở / kết ván

    fun start(humanWhite: Boolean, endgameLesson: Boolean, botName: String): TeacherLine {
        reset()
        botShort = shortBot(botName)
        val say = when {
            endgameLesson -> Say.GAME_START_ENDGAME
            humanWhite -> Say.GAME_START_WHITE
            else -> Say.GAME_START_BLACK
        }
        return make(say, Ctx(bot = botShort), emptyList(), 0, Mood.CHEER)
    }

    fun gameOver(humanWon: Boolean, draw: Boolean, reason: EndReason, humanResigned: Boolean, ply: Int): TeacherLine {
        val say = when {
            draw && reason == EndReason.STALEMATE -> Say.END_STALEMATE
            draw -> Say.DRAW
            humanWon -> Say.WIN
            humanResigned -> Say.RESIGN
            else -> Say.LOSE
        }
        return make(say, Ctx(bot = botShort), emptyList(), ply)
    }

    private fun shortBot(name: String): String = if (name.startsWith("Máy") || name.isBlank()) "Máy" else name

    // ------------------------------------------------------------------ phản ứng với nước đi

    fun onMove(c: MoveContext): List<TeacherLine> {
        botShort = shortBot(c.botName)
        val f = MoveReader.read(c.before, c.move, c.after, c.san, c.byHuman, c.moves, c.capturedType)
        val ply = f.ply
        val me = c.humanWhite

        // ---- sổ sách ngầm ----
        val key = c.after.repetitionKey()
        val reps = (repetition[key] ?: 0) + 1
        repetition[key] = reps
        val diff = BoardReader.material(c.after.board, me) - BoardReader.material(c.after.board, !me)
        val advClass = if (diff >= 300) 1 else if (diff <= -300) -1 else 0
        val advChanged = advClass != lastAdvClass && ply >= 6
        val prevAdv = lastAdvClass
        lastAdvClass = advClass
        val endgameNow = !endgameAnnounced && ply >= 20 && BoardReader.isEndgame(c.after.board)
        if (endgameNow) endgameAnnounced = true
        if (c.byHuman) {
            val bad = f.movedIntoDanger || f.hangingLeft.isNotEmpty() || f.missedWin >= 0
            goodStreak = if (bad) 0 else goodStreak + 1
        }

        // ---- ứng viên chính ----
        val primary = if (c.byHuman) humanPrimary(f, c) else botPrimary(f, c)
        val out = ArrayList<TeacherLine>(2)
        val bar = when (talkiness) { 0 -> 55; 1 -> 30; else -> 0 }

        val speakPrimary = primary != null && primary.weight >= bar
        if (speakPrimary) out += make(primary!!, ply)

        // ---- ứng viên phụ: thế cờ / diễn biến ván ----
        if (talkiness >= 1 && !(speakPrimary && primary!!.weight >= 88 && talkiness == 1)) {
            val secondary = secondary(c, f, primary, advChanged, prevAdv, advClass, endgameNow, reps)
            if (secondary != null) out += make(secondary, ply)
        }

        // ---- không có gì để nói: câu đệm (mẹo / đùa) để thầy "nhiều lời" ----
        if (out.isEmpty()) {
            val chance = when (talkiness) { 0 -> 0.0; 1 -> 0.35; else -> 1.0 }
            if (rnd.nextDouble() < chance) {
                val r = rnd.nextDouble()
                out += if (c.byHuman) {
                    when {
                        r < 0.60 -> make(Say.H_QUIET, Ctx(san = c.san), emptyList(), ply)
                        r < 0.92 -> make(Say.TIP, Ctx(), emptyList(), ply, Mood.CALM)
                        else -> make(Say.JOKE, Ctx(), emptyList(), ply, Mood.HAPPY)
                    }
                } else {
                    if (r < 0.85) make(Say.B_QUIET, Ctx(san = c.san, bot = botShort), emptyList(), ply)
                    else make(Say.TIP, Ctx(), emptyList(), ply, Mood.CALM)
                }
            }
        }
        return out
    }

    private fun humanPrimary(f: MoveFacts, c: MoveContext): Cand? {
        val cs = ArrayList<Cand>(8)
        val cx = Ctx(san = f.san, piece = pieceNameVi(f.moved), sq = sqName(f.to), file = ('a' + (f.to and 7)).toString(), target = pieceNameVi(f.captured), bot = botShort)
        if (f.mate) return Cand(Say.H_MATE, 100, cx)
        if (f.movedIntoDanger) cs += Cand(Say.H_MOVED_INTO_DANGER, 92, cx, circle(f.to))
        if (f.hangingLeft.isNotEmpty()) {
            val sq = f.hangingLeft.maxByOrNull { BoardReader.value(com.vila.chess.core.pieceType(c.after.board[it])) }!!
            val p = pieceNameVi(com.vila.chess.core.pieceType(c.after.board[sq]))
            cs += Cand(Say.H_LEFT_HANGING, 86, Ctx(san = f.san, piece = p, sq = sqName(sq)), circle(sq))
        }
        if (f.missedWin >= 0) {
            val p = pieceNameVi(com.vila.chess.core.pieceType(c.before.board[f.missedWin]))
            cs += Cand(Say.H_MISSED_WIN, 82, Ctx(san = f.san, piece = p, sq = sqName(f.missedWin)), circle(f.missedWin))
        }
        if (f.ply == 1 && c.humanWhite) {
            val say = when (f.san) { "e4" -> Say.FIRST_E4; "d4" -> Say.FIRST_D4; "Nf3" -> Say.FIRST_NF3; "c4" -> Say.FIRST_C4; else -> Say.FIRST_OTHER }
            cs += Cand(say, 70, cx)
        }
        if (f.promo != 0) cs += Cand(Say.H_PROMOTE, 84, cx, circle(f.to))
        if (f.isEp) cs += Cand(Say.H_EP, 72, cx, circle(f.to))
        if (f.captured != 0) {
            val pawn = f.captured == PAWN
            cs += when {
                f.recapture -> Cand(Say.H_RECAPTURE, 58, cx)
                f.freeCapture && !pawn -> Cand(Say.H_CAPTURE_FREE, 76, cx)
                pawn -> Cand(Say.H_CAPTURE_PAWN, 42, cx)
                else -> Cand(Say.H_CAPTURE_TRADE, 56, cx)
            }
        }
        if (f.castle == 1) cs += Cand(Say.H_CASTLE_SHORT, 64, cx)
        if (f.castle == 2) cs += Cand(Say.H_CASTLE_LONG, 64, cx)
        if (f.check) cs += Cand(Say.H_CHECK, 57, cx)
        if (f.earlyQueen) cs += Cand(Say.H_EARLY_QUEEN, 68, cx)
        if (f.repeatedPiece) cs += Cand(Say.H_REPEAT_PIECE, 60, cx)
        if (f.rimKnight) cs += Cand(Say.H_RIM_KNIGHT, 46, cx)
        if (f.createdThreats.isNotEmpty() && f.captured == 0) {
            val t = f.createdThreats.first()
            val tp = pieceNameVi(com.vila.chess.core.pieceType(c.after.board[t]))
            cs += Cand(Say.H_THREATENS, 54, Ctx(san = f.san, piece = tp, sq = sqName(t)), listOf(Mark(MarkKind.ARROW, f.to, t)))
        }
        if (f.centerPawn) cs += Cand(Say.H_CENTER_PAWN, 38, cx)
        if (f.developing) cs += Cand(Say.H_DEVELOP, 36, cx)
        if (f.escapedCheck) cs += Cand(Say.H_ESCAPE_CHECK, 34, cx)
        if (goodStreak == 3 || (goodStreak > 3 && goodStreak % 5 == 0)) cs += Cand(Say.STREAK, 50, cx)
        return cs.maxByOrNull { it.weight }
    }

    private fun botPrimary(f: MoveFacts, c: MoveContext): Cand? {
        val cx = Ctx(san = f.san, piece = pieceNameVi(f.moved), sq = sqName(f.to), target = pieceNameVi(f.captured), bot = botShort)
        if (f.mate) return Cand(Say.B_MATE, 100, cx)
        val cs = ArrayList<Cand>(6)
        if (f.captured != 0) cs += Cand(Say.B_CAPTURE, 70, cx, circle(f.to))
        if (f.check) cs += Cand(Say.B_CHECK, 74, cx)
        if (f.promo != 0) cs += Cand(Say.B_PROMOTE, 80, cx, circle(f.to))
        if (f.isEp) cs += Cand(Say.B_EP, 60, cx)
        if (f.castle != 0) cs += Cand(Say.B_CASTLE, 46, cx)
        if (f.createdThreats.isNotEmpty() && f.captured == 0) {
            val t = f.createdThreats.first()
            val tp = pieceNameVi(com.vila.chess.core.pieceType(c.after.board[t]))
            cs += Cand(Say.B_THREATENS, 78, Ctx(san = f.san, piece = tp, sq = sqName(t), bot = botShort), listOf(Mark(MarkKind.ARROW, f.to, t)))
        }
        // máy để hở quân => cơ hội
        val hang = when {
            f.movedIntoDanger -> f.to
            f.hangingLeft.isNotEmpty() -> f.hangingLeft.first()
            else -> -1
        }
        if (hang >= 0) {
            val p = pieceNameVi(com.vila.chess.core.pieceType(c.after.board[hang]))
            cs += Cand(Say.B_BLUNDER, 84, Ctx(san = f.san, piece = p, sq = sqName(hang), bot = botShort), circle(hang))
        }
        if (f.developing) cs += Cand(Say.B_DEVELOP, 32, cx)
        return cs.maxByOrNull { it.weight }
    }

    private fun secondary(
        c: MoveContext, f: MoveFacts, primary: Cand?, advChanged: Boolean, prevAdv: Int, adv: Int,
        endgameNow: Boolean, reps: Int,
    ): Cand? {
        val ply = f.ply
        val cx = Ctx(bot = botShort)
        val dangerPrimary = primary != null && primary.weight >= 80 &&
            (primary.say == Say.H_MOVED_INTO_DANGER || primary.say == Say.H_LEFT_HANGING || primary.say == Say.B_THREATENS)
        val min = when (talkiness) { 1 -> 45; else -> 22 }

        // diễn biến ván: ưu tiên hơn quan sát tĩnh
        if (advChanged) {
            if (adv == 1) return Cand(Say.ADV_UP, 60, cx)
            if (adv == -1) return Cand(Say.ADV_DOWN, 60, cx)
            if (prevAdv == -1 && adv == 0) return Cand(Say.COMEBACK, 62, cx)
        }
        if (endgameNow) return Cand(Say.ENDGAME_ENTER, 58, cx)
        if (reps >= 2) return Cand(Say.REPETITION_WARN, 66, cx)
        if (c.after.halfmove >= 80) return Cand(Say.FIFTY_WARN, 64, cx)

        // khai cuộc có tên
        if (ply <= 20) {
            val info = book?.lookup(c.after.fen())
            if (info != null && info.name != lastOpening && talkiness >= 2) {
                lastOpening = info.name
                return Cand(Say.OPENING_NAME, 44, Ctx(opening = info.name, bot = botShort))
            }
        }

        // quan sát thế cờ
        val seen = BoardReader.read(c.after, c.humanWhite)
        for (s in seen) {
            if (s.weight < min) break
            val last = lastTopicPly[s.topic]
            val cooldown = if (s.weight >= 60) 3 else 10
            if (last != null && ply - last < cooldown) continue
            if (dangerPrimary && (s.topic == Topic.HANGING_YOURS || s.topic == Topic.ATTACKED_BY_LESSER_YOURS)) continue
            // đừng nói chuyện chiến thuật dành cho người chơi khi vừa là nước của đối thủ vô nghĩa
            if (s.topic == Topic.MATERIAL_EVEN && seen.size > 1) continue
            lastTopicPly[s.topic] = ply
            return seenToCand(s)
        }
        return null
    }

    private fun seenToCand(s: Seen): Cand {
        val say = Say.valueOf("T_" + s.topic.name)
        val piece = pieceNameVi(s.arg)
        val sqs = s.squares
        val primarySq = when (s.topic) {
            Topic.FORK_AVAILABLE, Topic.MATE_IN_ONE_AVAILABLE -> sqs.lastOrNull()
            else -> sqs.firstOrNull()
        }
        val ctx = Ctx(
            piece = piece,
            sq = if (primarySq != null) sqName(primarySq) else "",
            file = if (s.topic.name.contains("FILE") || s.topic.name.contains("DOUBLED")) ('a' + s.arg.coerceIn(0, 7)).toString() else "",
            n = s.arg,
            bot = botShort,
        )
        val marks = when (s.topic) {
            Topic.FORK_AVAILABLE, Topic.MATE_IN_ONE_AVAILABLE -> circle(sqs.lastOrNull() ?: -1)
            Topic.MATERIAL_UP, Topic.MATERIAL_DOWN, Topic.MATERIAL_EVEN, Topic.OPPONENT_CRAMPED -> emptyList()
            else -> circle(*sqs.toIntArray())
        }
        return Cand(say, s.weight, ctx, marks)
    }

    // ------------------------------------------------------------------ hỏi thầy / gợi ý / nhắc

    /** Người chơi bấm "Hỏi thầy": thầy kể những gì thầy THẤY trên bàn cờ (không giới hạn cooldown). */
    fun explain(pos: Position, humanWhite: Boolean, botName: String, ply: Int): List<TeacherLine> {
        botShort = shortBot(botName)
        val out = ArrayList<TeacherLine>(4)
        out += make(Say.ASK_INTRO, Ctx(bot = botShort), emptyList(), ply, Mood.THINK)
        val seen = BoardReader.read(pos, humanWhite)
        val used = HashSet<Topic>()
        var n = 0
        for (s in seen) {
            if (n >= 3) break
            if (s.topic == Topic.MATERIAL_EVEN && n > 0) continue
            if (!used.add(s.topic)) continue
            out += make(seenToCand(s), ply)
            n++
        }
        if (n == 0) out += make(Say.ASK_NOTHING, Ctx(), emptyList(), ply)
        return out
    }

    fun hintThinking(ply: Int): TeacherLine = make(Say.HINT_ASK, Ctx(), emptyList(), ply, Mood.THINK)

    fun hint(san: String, detail: String, ply: Int): TeacherLine {
        val l = make(Say.HINT_GIVEN, Ctx(san = san), emptyList(), ply, Mood.CHEER)
        return if (detail.isBlank()) l else l.copy(text = l.text + " (" + detail.replaceFirstChar { it.lowercase() } + ")")
    }

    /** Người chơi nghĩ lâu: [level] 1..3. */
    fun nudge(level: Int, ply: Int): TeacherLine =
        make(when (level) { 1 -> Say.IDLE1; 2 -> Say.IDLE2; else -> Say.IDLE3 }, Ctx(), emptyList(), ply)

    fun poke(ply: Int): TeacherLine {
        val r = rnd.nextDouble()
        return when {
            r < 0.45 -> make(Say.POKE, Ctx(), emptyList(), ply, Mood.WORRIED)
            r < 0.80 -> make(Say.TIP, Ctx(), emptyList(), ply, Mood.CALM)
            else -> make(Say.JOKE, Ctx(), emptyList(), ply, Mood.HAPPY)
        }
    }

    fun undo(ply: Int): TeacherLine = make(Say.UNDO, Ctx(), emptyList(), ply)

    /** Nhãn engine đến muộn: chỉ nhắc khi đáng nhắc và không trùng lời đã cảnh báo. */
    fun onLabel(label: MoveLabel, san: String, ply: Int, alreadyWarned: Boolean): TeacherLine? {
        val say = when (label) {
            MoveLabel.BRILLIANT -> Say.LABEL_BRILLIANT
            MoveLabel.GREAT -> Say.LABEL_GREAT
            MoveLabel.BLUNDER -> if (alreadyWarned) return null else Say.LABEL_BLUNDER
            MoveLabel.MISTAKE -> if (alreadyWarned) return null else Say.LABEL_MISTAKE
            MoveLabel.MISS -> Say.LABEL_MISS
            MoveLabel.INACCURACY -> if (talkiness >= 2) Say.LABEL_INACCURACY else return null
            MoveLabel.BEST -> if (talkiness >= 2 && rnd.nextDouble() < 0.4) Say.LABEL_BEST else return null
            MoveLabel.EXCELLENT, MoveLabel.GOOD, MoveLabel.BOOK -> return null
        }
        return make(say, Ctx(san = san), emptyList(), ply)
    }
}
