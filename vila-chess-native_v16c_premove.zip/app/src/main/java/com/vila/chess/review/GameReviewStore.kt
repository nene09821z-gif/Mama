package com.vila.chess.review

import android.content.Context
import java.io.File
import kotlin.math.exp

object ReviewClassifier {
    /** Công thức win% từ centipawn (góc nhìn bên đang xét): WP = 50 + 50 * (2 / (1 + e^(-0.00368208 * cp)) - 1). */
    fun winPct(cp: Int): Double = 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * cp)) - 1.0)

    /**
     * Win% có xét mate (không dùng cp khi engine báo mate). Cùng góc nhìn với [cp]/[mate]:
     * mate > 0 = bên xét sắp chiếu hết (100%), mate < 0 = sắp bị chiếu hết (0%),
     * mate == 0 = thế đã bị chiếu hết, bên thắng là bên có cp dương.
     */
    fun winPct(cp: Int, mate: Int?): Double = when {
        mate == null -> winPct(cp)
        mate > 0 -> 100.0
        mate < 0 -> 0.0
        else -> if (cp >= 0) 100.0 else 0.0
    }

    /** File review lưu từ lần engine hỏng (mọi thế depth 0, điểm 0) là rác: phải phân tích lại. */
    fun isUsable(r: GameReview): Boolean =
        r.moves.isEmpty() || r.moves.any { it.depthBefore > 0 || it.depthAfter > 0 || it.mateBeforeWhite != null }

    /** Nhãn chỉ theo EP loss (ngưỡng 2/5/10/20%). Nhãn cần ngữ cảnh (Book, Brilliant, Great, Best, Miss) nằm ở [ReviewAnalyzer]. */
    fun classify(loss: Double): MoveLabel = ReviewAnalyzer.labelByLoss(loss)

    fun moveAccuracy(loss: Double): Double = LichessAccuracy.moveAccuracy(loss)

    /**
     * (Dự phòng, không trọng số.) Cả ván từ danh sách EP loss: ReviewAssembler dùng [LichessAccuracy.gameAccuracy] (chuẩn Lichess).
     * Ở đây: trung bình cộng trộn với trung bình điều hòa.
     * Trung bình điều hòa kéo điểm xuống mạnh khi có vài nước sai nặng (một Blunder không bị "pha loãng" bởi 40 nước tốt),
     * sát cảm nhận thực tế hơn trung bình cộng thuần.
     */
    fun gameAccuracy(losses: List<Double>): Double {
        if (losses.isEmpty()) return 100.0
        val accs = losses.map { moveAccuracy(it).coerceAtLeast(1.0) }
        val arith = accs.average()
        val harmonic = accs.size / accs.sumOf { 1.0 / it }
        return ((arith + harmonic) / 2.0).coerceIn(0.0, 100.0)
    }
}

class GameReviewStore(context: Context) {
    private val app = context.applicationContext
    private val dir = File(app.filesDir, "reviews").apply { mkdirs() }
    private fun file(id: String) = File(dir, "${id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}.json")

    fun exists(gameId: String) = file(gameId).exists()

    /** Id của mọi ván đã có file phân tích (một lần liệt kê thư mục, nhanh hơn hàng nghìn lần exists). */
    fun ids(): Set<String> =
        dir.list()?.filter { it.endsWith(".json") }?.map { it.removeSuffix(".json") }?.toSet() ?: emptySet()

    /** Xóa cả file JSON lẫn kết quả trong Room. Gọi từ luồng nền (Room chặn luồng chính). */
    fun delete(gameId: String) {
        runCatching { file(gameId).delete() }
        runCatching { com.vila.chess.review.db.ReviewDatabase.get(app).analysisDao().deleteGameBlocking(gameId) }
    }

    fun save(r: GameReview) {
        // Ghi tạm rồi đổi tên: không bao giờ để file review dở dang.
        val target = file(r.gameId)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(ReviewJson.encode(r))
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    /** null = chưa có (chưa phân tích xong) hoặc file hỏng. Đọc được cả file phiên bản 1. */
    fun load(gameId: String): GameReview? {
        val f = file(gameId)
        if (!f.exists()) return null
        val r = runCatching { ReviewJson.decode(f.readText()) }.getOrNull()
        if (r == null || !ReviewClassifier.isUsable(r)) { f.delete(); return null }
        return r
    }
}
