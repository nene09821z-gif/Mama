package com.vila.chess.review

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveUci
import com.vila.chess.review.db.ReviewRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface ReviewUiState {
    /** Chưa bắt đầu (màn Review vẽ nền trống, không nháy khi kết quả có sẵn trong Room). */
    data object Idle : ReviewUiState

    /**
     * Room chưa có kết quả: Worker nền đang hoàn tất. [waitingForCharge] = work đang chờ điều kiện chạy
     * (pin thấp, chưa sạc). [done]/[total] = số thế đã chấm / tổng số thế (total = 0: chưa có tiến độ).
     */
    data class Pending(val waitingForCharge: Boolean = false, val done: Int = 0, val total: Int = 0) : ReviewUiState

    data class Ready(val data: ReviewData) : ReviewUiState

    data class Failed(val reason: String) : ReviewUiState
}

/**
 * ViewModel của màn Game Review. KHÔNG chạy engine, KHÔNG hiện tiến độ: phân tích do [GameAnalysisWorker] làm ngầm
 * từ lúc ván kết thúc; ViewModel chỉ đọc Room.
 *
 *  1. Room đã có kết quả -> Ready ngay (không qua Pending).
 *  2. Chưa có -> Pending (khung chờ), bảo đảm có một Worker đang xếp hàng (ván mở từ kho chưa từng phân tích),
 *     rồi quan sát Flow của Room: Worker ghi xong là tự chuyển sang Ready.
 */
class GameReviewViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Application = app
    private val repo = ReviewRepository.get(app)

    private val _state = MutableStateFlow<ReviewUiState>(ReviewUiState.Idle)
    val state: StateFlow<ReviewUiState> = _state.asStateFlow()

    /** Nước đang xem: 0 = thế đầu ván, n = thế sau n nước. */
    private val _ply = MutableStateFlow(0)
    val ply: StateFlow<Int> = _ply.asStateFlow()

    private var job: Job? = null
    private var activeId: String? = null

    private class Args(val gameId: String, val startFen: String, val ucis: List<String>)
    private var args: Args? = null

    /** Bắt đầu (hoặc nối lại) việc đọc kết quả của một ván. Gọi nhiều lần với cùng [gameId] là vô hại. */
    fun startGameAnalysis(gameId: String, moves: List<String>, startFen: String = START_FEN) {
        if (activeId == gameId && _state.value !is ReviewUiState.Failed) return
        job?.cancel()
        activeId = gameId
        args = Args(gameId, startFen, moves)
        _ply.value = 0
        _state.value = ReviewUiState.Idle
        job = viewModelScope.launch {
            try {
                run(gameId, moves, startFen)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.e("GameReview", "Lỗi đọc kết quả: ${e.message}", e)
                _state.value = ReviewUiState.Failed("Không mở được kết quả phân tích ván này.")
            }
        }
    }

    /** Nút "Thử lại" khi Worker đã thất bại: xếp lại work mới thay cho work cũ. */
    fun retry() {
        val a = args ?: return
        activeId = null
        job?.cancel()
        runCatching { GameAnalysisWorker.enqueueAnalysis(ctx, a.gameId, a.startFen, a.ucis, replace = true) }
        startGameAnalysis(a.gameId, a.ucis, a.startFen)
    }

    // ------------------------------------------------------------------ Tua nước đi

    fun goTo(target: Int) {
        val max = (_state.value as? ReviewUiState.Ready)?.data?.review?.moves?.size ?: return
        _ply.value = target.coerceIn(0, max)
    }

    fun step(delta: Int) = goTo(_ply.value + delta)

    // ------------------------------------------------------------------ Đọc kết quả

    private suspend fun run(gameId: String, moves: List<String>, startFen: String) {
        val replay = withContext(Dispatchers.Default) { ReviewReplay.replay(startFen, moves) }
        if (replay == null || replay.plies.isEmpty()) {
            _state.value = ReviewUiState.Failed("Không đọc được danh sách nước đi của ván này.")
            return
        }

        // 1) Đã phân tích xong từ trước: hiện kết quả ngay, không qua khung chờ.
        ready(gameId, replay, repo.load(gameId))?.let { _state.value = ReviewUiState.Ready(it); return }

        // 2) Chưa có: khung chờ + bảo đảm Worker đang xếp hàng (KEEP: đang chờ/chạy thì không đụng).
        _state.value = ReviewUiState.Pending()
        runCatching { GameAnalysisWorker.enqueueAnalysis(ctx, gameId, startFen, moves) }
            .onFailure { Log.e("GameReview", "Không xếp được Worker: ${it.message}") }

        val workState = WorkManager.getInstance(ctx)
            .getWorkInfosForUniqueWorkFlow(GameAnalysisWorker.uniqueName(gameId))
            .map { pickSnap(it) }

        // 3) Room Flow: Worker ghi xong là có review => Ready. collectLatest để mỗi lần đổi trạng thái hủy phép chờ cũ.
        combine(repo.observe(gameId), workState) { review, ws -> review to ws }
            .collectLatest { (review, snap) ->
                val ws = snap.state
                val data = ready(gameId, replay, review)
                when {
                    data != null -> _state.value = ReviewUiState.Ready(data)
                    ws == WorkInfo.State.FAILED || ws == WorkInfo.State.CANCELLED ->
                        _state.value = ReviewUiState.Failed("Không phân tích được ván này. Có thể thử lại.")
                    ws == WorkInfo.State.SUCCEEDED -> {
                        // Worker báo xong nhưng Flow chưa kịp phát: chờ một chút rồi đọc thẳng Room.
                        delay(1_500)
                        val again = ready(gameId, replay, repo.load(gameId))
                        _state.value = if (again != null) ReviewUiState.Ready(again)
                        else ReviewUiState.Failed("Không phân tích được ván này. Có thể thử lại.")
                    }
                    else -> _state.value =
                        ReviewUiState.Pending(
                            waitingForCharge = false,   // không còn chờ sạc/pin: phân tích luôn chạy ngay
                            done = snap.done, total = snap.total,
                        )
                }
            }
    }

    private class WorkSnap(val state: WorkInfo.State?, val done: Int, val total: Int)

    private fun pickSnap(list: List<WorkInfo>): WorkSnap {
        val active = list.firstOrNull { !it.state.isFinished }
        return WorkSnap(
            state = pickState(list),
            done = active?.progress?.getInt(GameAnalysisWorker.KEY_DONE, 0) ?: 0,
            total = active?.progress?.getInt(GameAnalysisWorker.KEY_TOTAL, 0) ?: 0,
        )
    }

    /** Trạng thái đáng quan tâm nhất trong các lần chạy của cùng tên work: đang hoạt động > thành công > thất bại. */
    private fun pickState(list: List<WorkInfo>): WorkInfo.State? =
        list.firstOrNull { !it.state.isFinished }?.state
            ?: list.firstOrNull { it.state == WorkInfo.State.SUCCEEDED }?.state
            ?: list.firstOrNull()?.state

    // ------------------------------------------------------------------ Dựng dữ liệu hiển thị

    /** null = không có kết quả dùng được (hoặc không khớp ván: dữ liệu cũ/hỏng thì xóa để phân tích lại). */
    private suspend fun ready(gameId: String, replay: ReplayResult, review: GameReview?): ReviewData? {
        if (review == null) return null
        if (review.moves.size != replay.plies.size) { repo.delete(gameId); return null }
        return withContext(Dispatchers.Default) { buildData(review, replay) }
    }

    private fun buildData(review: GameReview, replay: ReplayResult): ReviewData {
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
        val bestSans = replay.plies.indices.map { i -> sanOf(fens[i], review.moves[i].bestMoveBefore) }
        val boards = fens.map { f -> runCatching { Position.fromFen(f).board.copyOf() }.getOrElse { IntArray(64) } }
        return ReviewData(review, fens, replay.plies.map { it.san }, bestSans, boards)
    }

    private fun sanOf(fen: String, uci: String?): String? {
        if (uci == null) return null
        return runCatching {
            val pos = Position.fromFen(fen)
            val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci }
            if (mv == null) null else moveToSan(pos, mv)
        }.getOrNull()
    }
}
