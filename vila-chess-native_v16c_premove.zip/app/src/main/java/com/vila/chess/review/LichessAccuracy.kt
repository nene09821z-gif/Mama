package com.vila.chess.review

import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Độ chính xác (Accuracy%) theo ĐÚNG thuật toán của Lichess (mã nguồn mở, lila `AccuracyPercent.scala`,
 * trang mô tả https://lichess.org/page/accuracy). Hàm thuần, không Android => test được trên JVM.
 *
 *  1. Win%        = 50 + 50 * (2 / (1 + exp(-0.00368208 * cp)) - 1)        (cp kẹp ±1000; chiếu hết tính như ±1000cp)
 *  2. Accuracy%   = 103.1668 * exp(-0.04354 * (Win%trước - Win%sau)) - 3.1669 + 1 (bù +1 cho sai số), kẹp 0..100
 *  3. Cả ván      = trung bình của [trung bình trọng số theo "độ biến động" ] và [trung bình điều hòa]:
 *       - cửa sổ trượt cỡ clamp(số nước / 10, 2, 8) trên chuỗi Win% (góc nhìn Trắng) của mọi thế kể cả thế đầu;
 *       - trọng số mỗi nước = độ lệch chuẩn của cửa sổ, kẹp 0,5..12 (nước đi lúc thế cờ biến động mạnh nặng ký hơn);
 *       - mỗi bên tính riêng trên các nước của bên đó.
 * Phân loại nhãn (Best/Mistake/…) vẫn theo mô hình Expected Points của Chess.com (xem [ReviewAnalyzer]); module này chỉ lo ĐIỂM.
 */
object LichessAccuracy {
    const val CP_CEILING = 1000
    const val MIN_WEIGHT = 0.5
    const val MAX_WEIGHT = 12.0

    fun winPct(cp: Int): Double {
        val c = cp.coerceIn(-CP_CEILING, CP_CEILING)
        return 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * c)) - 1.0)
    }

    /** Win% góc nhìn TRẮNG. [mateWhite] > 0 Trắng chiếu hết, < 0 Đen chiếu hết, 0 = đã bị chiếu hết (bên thắng suy từ dấu cp). */
    fun winWhitePct(cpWhite: Int, mateWhite: Int?): Double {
        val cp = when {
            mateWhite == null -> cpWhite
            mateWhite > 0 -> CP_CEILING
            mateWhite < 0 -> -CP_CEILING
            else -> if (cpWhite >= 0) CP_CEILING else -CP_CEILING
        }
        return winPct(cp)
    }

    /** [winDrop] = Win% bên đi đã MẤT sau nước đi (âm = tăng thì coi như 0 mất). */
    fun moveAccuracy(winDrop: Double): Double =
        (103.1668100711649 * exp(-0.04354415386753951 * winDrop) - 3.166924740191411 + 1.0).coerceIn(0.0, 100.0)

    fun windowSize(plies: Int): Int = (plies / 10).coerceIn(2, 8)

    /** Trọng số "biến động" cho từng nước: trả đúng (winWhite.size - 1) phần tử, thẳng hàng với từng nước đi. */
    fun volatilityWeights(winWhite: List<Double>): List<Double> {
        val plies = winWhite.size - 1
        if (plies <= 0) return emptyList()
        val ws = windowSize(plies).coerceAtMost(winWhite.size)
        val windows = ArrayList<List<Double>>(plies)
        repeat(ws - 2) { windows += winWhite.take(ws) }                       // phần đệm đầu ván (như lila)
        for (i in 0..winWhite.size - ws) windows += winWhite.subList(i, i + ws)
        return windows.map { stdDev(it).coerceIn(MIN_WEIGHT, MAX_WEIGHT) }
    }

    private fun stdDev(xs: List<Double>): Double {
        val mean = xs.average()
        return sqrt(xs.sumOf { (it - mean) * (it - mean) } / xs.size)
    }

    /** Trung bình [trọng số] và [điều hòa] của các accuracy (mỗi nước sàn ở 1 để 0% không chia cho 0). */
    fun combine(accuracies: List<Double>, weights: List<Double>): Double {
        if (accuracies.isEmpty()) return 100.0
        val wSum = weights.sum()
        val weighted = if (weights.size == accuracies.size && wSum > 0.0) {
            accuracies.indices.sumOf { accuracies[it] * weights[it] } / wSum
        } else accuracies.average()
        val harmonic = accuracies.size / accuracies.sumOf { 1.0 / it.coerceAtLeast(1.0) }
        return ((weighted + harmonic) / 2.0).coerceIn(0.0, 100.0)
    }

    /**
     * @param winWhite  Win% (Trắng) của mọi thế: phần tử 0 = thế đầu ván, phần tử i = thế sau i nước (size = số nước + 1)
     * @param winDrops  Win% bên đi đã mất ở từng nước (size = số nước)
     * @param whiteMoved nước thứ i do Trắng đi?
     * @return (độ chính xác Trắng, độ chính xác Đen); bên không có nước nào = 100.
     */
    fun gameAccuracy(winWhite: List<Double>, winDrops: List<Double>, whiteMoved: List<Boolean>): Pair<Double, Double> {
        val n = winDrops.size
        require(whiteMoved.size == n) { "whiteMoved phải cùng cỡ winDrops" }
        val weights = if (winWhite.size == n + 1) volatilityWeights(winWhite) else List(n) { 1.0 }
        val accs = winDrops.map { moveAccuracy(it) }
        fun side(white: Boolean): Double {
            val idx = (0 until n).filter { whiteMoved[it] == white }
            return combine(idx.map { accs[it] }, idx.map { weights[it] })
        }
        return side(true) to side(false)
    }
}
