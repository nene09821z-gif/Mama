# v16b — Trang "Chủ đề" (theo ảnh mẫu) + cài đặt Tài khoản

## Mới
- ui/ThemeScreen.kt : trang "Chủ đề" riêng. Bàn cờ xem trước ở trên (đổi màu/bộ quân là đổi ngay), 4 tab
  Bàn cờ · Quân cờ · Hình nền · Âm thanh (vạch tab trượt theo ngón vuốt), dòng tên mục đang chọn,
  lưới 5 cột ô vuông bo góc (ô chọn có viền trắng + dấu tích xanh). Tab Âm thanh là danh sách, chạm để nghe thử.
- ui/Wallpapers.kt  : 10 hình nền (Không gian, Cực quang, Hoàng hôn, Đêm đen, Biển sâu, Rừng đêm, Anh đào,
  Thiên hà tím, Than chì, Dung nham). Wallpapers.current là state -> cả app đổi nền ngay.
- game/Modes.kt     : HomeRoute.THEME.

## Sửa
- ui/AccountScreen.kt : thêm "Cài đặt tài khoản": Đổi tên (hộp thoại, kiểm tra 2-20 ký tự, giữ quốc gia + avatar),
  Email, Đăng nhập bằng (chỉ xem), Đăng xuất có hỏi lại. KHÔNG có đổi mật khẩu vì app đăng nhập bằng Google/email.
- ui/MoreTab.kt      : thêm dòng "Chủ đề" (trước "Các tùy chỉnh"). "Các tùy chỉnh" bỏ phần bàn cờ / bộ âm thanh / bộ quân
                       (đã chuyển sang Chủ đề -> không trùng nhau). Âm thanh bật/tắt, rung, đi trước, huấn luyện viên vẫn ở đó.
- ui/HomeScreen.kt   : route THEME (+ nút Back về Trang chủ).
- ui/SpaceBackground.kt : đọc màu từ Wallpapers.current.
- ui/BoardThemes.kt  : thêm "Kẹo cao su" (hồng nhạt/trắng như ảnh mẫu) và "Than đen" -> 20 màu = 4 hàng x 5 cột.
- game/GameViewModel.kt : wallpaperId + updateWallpaper() (lưu "wallpaper" trong vila_native).
- auth/AccountData.kt : "wallpaper" là cài đặt thiết bị (đổi tài khoản vẫn giữ nền).
- test/AppearanceTest.kt : thêm test hình nền + số màu bàn cờ chia hết cho 5.

## Xoá
- ui/AppearancePickers.kt (BoardThemeSection / SoundPackSection) - đã thay bằng ThemeScreen.

## Lưu ý
- Chưa build được trong môi trường này (không có Gradle/Android SDK) - hãy chạy ./gradlew assembleDebug hoặc đẩy lên GitHub Actions.
