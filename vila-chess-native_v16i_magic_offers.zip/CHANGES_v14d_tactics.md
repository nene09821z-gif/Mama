# v14d — Câu đố có chiến thuật thật + khóa học theo chủ đề từ Lichess

## Nguyên nhân câu đố toàn "chiếu hết"
scripts/generate_puzzles.py cũ lấy 50.000 câu có Rating THẤP NHẤT. Vùng rating 400–900 của Lichess gần như chỉ có
mateIn1/oneMove ⇒ cả bản đồ không có đòn đôi, ghim, xiên, dụ quân …

## Sửa
- scripts/generate_puzzles.py : chia kho Lichess theo khoảng 25 rating (400→3300), lấy đều mỗi khoảng, giảm trọng số mateIn1/oneMove,
                                ưu tiên đòn chiến thuật tự do + câu nhiều người thích, lọc câu ít người chơi / rating chưa ổn định.
                                300.000 câu (--count), id = level, rating tăng dần, cùng rating thì xáo trộn để chủ đề xen kẽ.
                                In thống kê % chiếu hết mỗi đoạn để thấy ngay nếu lệch.
                                DB gọn hơn (bỏ GameUrl/OpeningTags/…): ~45 MB cho 300.000 câu.
- scripts/generate_puzzles.py : ghi thêm game/LessonLichessData.kt = ~27 khóa chiến thuật × ≤12 bài (dễ → khó) lấy từ Lichess.
- game/LessonCatalog.kt        : nối LessonLichessData.courses sau các khóa tự viết (LessonCatalogTest tự kiểm mọi lời giải).
- game/LessonLichessData.kt    : bản rỗng dự phòng, CI ghi đè.
- game/PuzzleMapViewModel.kt   : TOTAL_LEVELS 50.000 → 300.000 (PHẢI bằng --count); danh sách level là danh sách ảo, không tốn RAM.
- .github/workflows (main.yml) : chạy script với --count 300000 + --lessons-out; cài zstandard.

## Lưu ý
- puzzles.db và LessonLichessData.kt chỉ được tạo thật khi CI có mạng (tải ~300 MB từ database.lichess.org).
- Tiến độ cũ (current_level) vẫn giữ, nhưng level N giờ là câu khác với bản cũ.
- Muốn nhiều hơn: --count 1000000 (~150 MB) và đổi TOTAL_LEVELS tương ứng.
