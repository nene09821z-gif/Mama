# v16g — Viết lại bộ chấm nước đi (MoveClassifier)

- `review/MoveClassifier.kt` (mới, thay `ReviewAnalyzer.kt` + `ReviewClassifier` + `LichessAccuracy.kt`):
  `calculateWinProbability(cp, mate, isWhiteTurn)` (0–1, lượt Đen đảo 1 − WP), `classifyMove(...)`, `calculateAccuracy(epLoss)`, `calculateGameAccuracy(losses)`.
- Thế ngã ngũ (EP < 5% hoặc > 95%): loss × 0.5. Ngưỡng: ≤2% Excellent · ≤5% Good · ≤10% Inaccuracy · ≤20% Mistake · >20% Blunder.
- Best / Great (nước tốt nhì kém ≥ 15%) / Brilliant (hy sinh + nước thay thế chưa thắng đậm) / Miss (đối thủ vừa sai mà không tận dụng).
- Giữ luật mate của Lichess (sàn nhãn) và Book. `SacrificeDetector` tách ra file riêng.
- Accuracy cả ván = trung bình cộng accuracy từng nước của mỗi bên.
- Engine: MultiPV = 2 trên mọi máy (kể cả wasm máy yếu).
- Room: thêm `epBefore` / `epAfter` (DB version 2, destructive migration — chỉ là cache). `ReviewJson.CURRENT_VERSION` 6 → 7: ván cũ tự phân tích lại.
- Biểu đồ đánh giá: trung bình trượt (cửa sổ 3, ván > 60 nước dùng 5) + đường Bezier mượt.
- Test: `MoveClassifierTest` (thay `ReviewAnalyzerTest`), cập nhật `ReviewVerifyTest`, `GameReviewLogicTest`; xóa `LichessAccuracyTest`. 36 test qua trên JVM.
