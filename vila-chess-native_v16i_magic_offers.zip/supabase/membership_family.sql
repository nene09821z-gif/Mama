-- Thêm gói "family" (Friends & Family) cho cột users.tier. Chạy MỘT LẦN trong Supabase → SQL Editor.
alter table public.users drop constraint if exists users_tier_check;
alter table public.users
  add constraint users_tier_check check (tier in ('free','gold','platinum','diamond','family'));
