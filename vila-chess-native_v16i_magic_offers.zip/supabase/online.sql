-- =============================================================================
-- CHƠI ONLINE: ghép trận + ván online + đồng hồ do MÁY CHỦ tính.
-- Chạy 1 lần trong Supabase: SQL Editor -> New query -> dán -> Run (chạy lại được, không mất dữ liệu).
-- Cần đã chạy schema.sql trước (bảng public.users dùng để lấy tên + huy hiệu).
--
-- Cách hoạt động:
--   * App chỉ gọi các hàm RPC bên dưới; hai bảng không cho ghi trực tiếp (RLS bật, không có policy ghi).
--   * Đồng hồ: máy chủ lưu thời gian còn lại của mỗi bên + mốc turn_started_at. Thời gian đã trôi của bên đang
--     đến lượt luôn do máy chủ tính (clock_timestamp), nên hai máy không bao giờ lệch giờ nhau.
--     Đồng hồ chỉ chạy sau khi mỗi bên đã đi 1 nước (chuẩn chess.com/Lichess), cộng thêm giờ (increment) sau mỗi nước từ đó.
--   * Hết giờ: bất kỳ ai gọi online_get_game thấy bên đến lượt đã hết giờ thì máy chủ tự xử thua.
--   * Không ai đi nước đầu/nước hai trong 60 giây -> ván bị hủy (không tính thắng/thua).
-- Lưu ý bảo mật: máy chủ KHÔNG kiểm tra luật cờ (chỉ kiểm lượt đi, thứ tự nước, định dạng UCI). Nước đi bất hợp lệ
-- sẽ bị máy đối thủ từ chối hiển thị. Muốn chống gian lận hoàn toàn cần máy chủ cờ riêng (Edge Function + thư viện luật cờ).
-- =============================================================================

create table if not exists public.online_queue (
  user_id   uuid primary key references auth.users(id) on delete cascade,
  base_sec  int  not null,
  inc_sec   int  not null,
  game_id   uuid,                                  -- được điền khi người khác ghép trúng mình
  heartbeat timestamptz not null default now()
);
alter table public.online_queue enable row level security;   -- không có policy: chỉ truy cập qua RPC

create table if not exists public.online_games (
  id              uuid primary key default gen_random_uuid(),
  white_id        uuid not null references auth.users(id) on delete cascade,
  black_id        uuid not null references auth.users(id) on delete cascade,
  base_sec        int  not null,
  inc_sec         int  not null,
  moves           text not null default '',          -- các nước UCI cách nhau bằng dấu cách: "e2e4 e7e5 g1f3"
  ply             int  not null default 0,           -- số nước đã đi
  white_ms        bigint not null,                   -- giờ còn lại tại turn_started_at (chưa trừ thời gian đang chạy)
  black_ms        bigint not null,
  turn_started_at timestamptz not null default clock_timestamp(),
  status          text not null default 'active' check (status in ('active', 'finished', 'aborted')),
  result          text check (result in ('1-0', '0-1', '1/2-1/2')),
  reason          text,                              -- checkmate | stalemate | insufficient | fifty | repetition | timeout | resign | agreement
  draw_offer_by   text check (draw_offer_by in ('w', 'b')),
  created_at      timestamptz not null default now(),
  finished_at     timestamptz,
  check (white_id <> black_id)
);
alter table public.online_games enable row level security;
drop policy if exists "online_games_select_players" on public.online_games;
create policy "online_games_select_players" on public.online_games
  for select to authenticated using (auth.uid() in (white_id, black_id));
create index if not exists online_games_white  on public.online_games (white_id, created_at desc);
create index if not exists online_games_black  on public.online_games (black_id, created_at desc);
create index if not exists online_games_active on public.online_games (status) where status = 'active';

-- -----------------------------------------------------------------------------
-- Hàm nội bộ
-- -----------------------------------------------------------------------------

-- Xử ván hết giờ / bị bỏ dở (gọi khi đang giữ khóa dòng của ván). Trả về dòng đã cập nhật.
create or replace function public._online_settle(g public.online_games)
returns public.online_games
language plpgsql security definer set search_path = public as $$
declare
  el bigint;
  mover_ms bigint;
begin
  if g.status <> 'active' then return g; end if;
  el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
  if g.ply >= 2 then
    mover_ms := case when g.ply % 2 = 0 then g.white_ms else g.black_ms end;
    if el >= mover_ms then
      update public.online_games set
        status = 'finished', reason = 'timeout', finished_at = now(), draw_offer_by = null,
        result = case when g.ply % 2 = 0 then '0-1' else '1-0' end,
        white_ms = case when g.ply % 2 = 0 then 0 else g.white_ms end,
        black_ms = case when g.ply % 2 = 0 then g.black_ms else 0 end
      where id = g.id returning * into g;
    end if;
  elsif el >= 60000 then
    update public.online_games set status = 'aborted', reason = 'no_start', finished_at = now(), draw_offer_by = null
    where id = g.id returning * into g;
  end if;
  return g;
end $$;

-- JSON gửi về app: giờ còn lại đã trừ thời gian đang chạy của bên đến lượt (do máy chủ tính).
create or replace function public._online_view(g public.online_games)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  w bigint := g.white_ms;
  b bigint := g.black_ms;
  el bigint;
  wn text; wt text; bn text; bt text;
begin
  if g.status = 'active' and g.ply >= 2 then
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    if g.ply % 2 = 0 then w := greatest(0, w - el); else b := greatest(0, b - el); end if;
  end if;
  select display_name, tier into wn, wt from public.users where id = g.white_id;
  select display_name, tier into bn, bt from public.users where id = g.black_id;
  return jsonb_build_object(
    'id', g.id,
    'white_id', g.white_id, 'black_id', g.black_id,
    'white_name', coalesce(wn, 'Người chơi'), 'black_name', coalesce(bn, 'Người chơi'),
    'white_tier', coalesce(wt, 'free'), 'black_tier', coalesce(bt, 'free'),
    'base_sec', g.base_sec, 'inc_sec', g.inc_sec,
    'moves', g.moves, 'ply', g.ply,
    'white_ms', w, 'black_ms', b,
    'status', g.status, 'result', g.result, 'reason', g.reason,
    'draw_offer_by', g.draw_offer_by
  );
end $$;

-- -----------------------------------------------------------------------------
-- Ghép trận. App gọi lại hàm này mỗi ~1,5 giây trong lúc chờ (đồng thời là nhịp "còn online").
--   -> {"status":"waiting"}                  đang chờ đối thủ
--   -> {"status":"matched","game":{...}}     đã có ván (do mình tạo hoặc do người khác ghép trúng mình)
-- -----------------------------------------------------------------------------
create or replace function public.online_find_match(p_base int, p_inc int)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.online_queue;
  opp public.online_queue;
  g   public.online_games;
  wid uuid;
  bid uuid;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_base < 30 or p_base > 7200 or p_inc < 0 or p_inc > 60 then raise exception 'bad_time_control'; end if;

  -- Dọn người chờ đã mất kết nối (quá 20 giây không "đập nhịp")
  delete from public.online_queue where game_id is null and heartbeat < now() - interval '20 seconds';

  -- 1) Người khác đã ghép trúng mình
  select * into q from public.online_queue where user_id = uid for update;
  if found and q.game_id is not null then
    delete from public.online_queue where user_id = uid;
    select * into g from public.online_games where id = q.game_id for update;
    if found then
      g := public._online_settle(g);
      if g.status = 'active' then
        return jsonb_build_object('status', 'matched', 'game', public._online_view(g));
      end if;
    end if;
  end if;

  -- 2) Đang có ván dở -> vào lại đúng ván đó (một người không chơi hai ván cùng lúc)
  select * into g from public.online_games
    where status = 'active' and uid in (white_id, black_id)
    order by created_at desc limit 1 for update;
  if found then
    g := public._online_settle(g);
    if g.status = 'active' then
      delete from public.online_queue where user_id = uid;
      return jsonb_build_object('status', 'matched', 'game', public._online_view(g));
    end if;
  end if;

  -- 3) Tìm đối thủ đang chờ cùng thể loại giờ
  select * into opp from public.online_queue
    where user_id <> uid and game_id is null and base_sec = p_base and inc_sec = p_inc
      and heartbeat >= now() - interval '20 seconds'
    order by heartbeat limit 1 for update skip locked;
  if found then
    if random() < 0.5 then wid := uid; bid := opp.user_id; else wid := opp.user_id; bid := uid; end if;
    insert into public.online_games (white_id, black_id, base_sec, inc_sec, white_ms, black_ms)
      values (wid, bid, p_base, p_inc, p_base * 1000::bigint, p_base * 1000::bigint)
      returning * into g;
    update public.online_queue set game_id = g.id where user_id = opp.user_id;
    delete from public.online_queue where user_id = uid;
    return jsonb_build_object('status', 'matched', 'game', public._online_view(g));
  end if;

  -- 4) Chưa có ai: vào / giữ chỗ trong hàng đợi
  insert into public.online_queue (user_id, base_sec, inc_sec, heartbeat)
    values (uid, p_base, p_inc, now())
    on conflict (user_id) do update
      set base_sec = excluded.base_sec, inc_sec = excluded.inc_sec, heartbeat = now(), game_id = null;
  return jsonb_build_object('status', 'waiting');
end $$;

-- Hủy tìm trận. Nếu đúng lúc đó đã có người ghép trúng thì trả về ván đó để app hủy nó (người kia không phải chờ).
create or replace function public.online_cancel_search()
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.online_queue;
  g   public.online_games;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  delete from public.online_queue where user_id = uid returning * into q;
  if found and q.game_id is not null then
    select * into g from public.online_games where id = q.game_id;
    if found then return jsonb_build_object('status', 'matched', 'game', public._online_view(g)); end if;
  end if;
  return jsonb_build_object('status', 'cancelled');
end $$;

-- -----------------------------------------------------------------------------
-- Trong ván
-- -----------------------------------------------------------------------------

-- Lấy trạng thái ván (app gọi liên tục). Tự xử hết giờ / hủy ván bỏ dở.
create or replace function public.online_get_game(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  g public.online_games;
begin
  select * into g from public.online_games where id = p_id for update;
  if not found or auth.uid() is null or auth.uid() not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._online_settle(g);
  return public._online_view(g);
end $$;

-- Đi một nước. p_ply = số nước đã đi trước nước này (chống gửi trùng / lệch thứ tự).
-- p_result/p_reason: chỉ điền khi nước này kết thúc ván theo luật cờ (chiếu hết, hòa pat, ...).
create or replace function public.online_move(
  p_id uuid, p_ply int, p_uci text, p_result text default null, p_reason text default null
)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.online_games;
  white_turn boolean;
  el bigint;
  mover_ms bigint;
  new_w bigint;
  new_b bigint;
  fin boolean := false;
begin
  select * into g from public.online_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;

  g := public._online_settle(g);
  if g.status <> 'active' then return public._online_view(g); end if;   -- ván đã kết thúc (vd. hết giờ)
  if p_ply < g.ply then return public._online_view(g); end if;          -- nước này đã được ghi nhận trước đó
  if p_ply > g.ply then raise exception 'ply_gap'; end if;

  white_turn := (g.ply % 2 = 0);
  if (white_turn and uid <> g.white_id) or ((not white_turn) and uid <> g.black_id) then raise exception 'not_your_turn'; end if;
  if p_uci is null or p_uci !~ '^[a-h][1-8][a-h][1-8][qrbn]?$' then raise exception 'bad_move'; end if;

  new_w := g.white_ms;
  new_b := g.black_ms;
  if g.ply >= 2 then
    -- đồng hồ đang chạy: trừ thời gian đã suy nghĩ, rồi cộng giờ thưởng
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    mover_ms := case when white_turn then g.white_ms else g.black_ms end;
    mover_ms := mover_ms - el + g.inc_sec * 1000::bigint;
    if white_turn then new_w := mover_ms; else new_b := mover_ms; end if;
  end if;

  if p_result is not null then
    if p_result not in ('1-0', '0-1', '1/2-1/2') then raise exception 'bad_result'; end if;
    if p_result = '1-0' and not white_turn then raise exception 'bad_result'; end if;
    if p_result = '0-1' and white_turn then raise exception 'bad_result'; end if;
    fin := true;
  end if;

  update public.online_games set
    moves = case when moves = '' then p_uci else moves || ' ' || p_uci end,
    ply = ply + 1,
    white_ms = new_w, black_ms = new_b,
    turn_started_at = clock_timestamp(),
    draw_offer_by = null,
    status = case when fin then 'finished' else 'active' end,
    result = case when fin then p_result else null end,
    reason = case when fin then coalesce(nullif(p_reason, ''), 'rule') else null end,
    finished_at = case when fin then now() else null end
  where id = g.id returning * into g;

  return public._online_view(g);
end $$;

-- Đầu hàng. Trước khi mỗi bên đi 1 nước thì chỉ là hủy ván (không ai thắng/thua).
create or replace function public.online_resign(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.online_games;
begin
  select * into g from public.online_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._online_settle(g);
  if g.status <> 'active' then return public._online_view(g); end if;
  if g.ply < 2 then
    update public.online_games set status = 'aborted', reason = 'abort', finished_at = now(), draw_offer_by = null
      where id = g.id returning * into g;
  else
    update public.online_games set
      status = 'finished', reason = 'resign', finished_at = now(), draw_offer_by = null,
      result = case when uid = g.white_id then '0-1' else '1-0' end
    where id = g.id returning * into g;
  end if;
  return public._online_view(g);
end $$;

-- Cầu hòa: p_action = 'offer' (nếu đối thủ đã cầu hòa trước thì đây là CHẤP NHẬN -> hòa luôn) | 'decline'.
create or replace function public.online_draw(p_id uuid, p_action text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.online_games;
  me text;
begin
  select * into g from public.online_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._online_settle(g);
  if g.status <> 'active' then return public._online_view(g); end if;
  me := case when uid = g.white_id then 'w' else 'b' end;

  if p_action = 'offer' then
    if g.ply < 2 then raise exception 'too_early'; end if;
    if g.draw_offer_by is not null and g.draw_offer_by <> me then
      update public.online_games set
        status = 'finished', result = '1/2-1/2', reason = 'agreement', finished_at = now(), draw_offer_by = null
      where id = g.id returning * into g;
    else
      update public.online_games set draw_offer_by = me where id = g.id returning * into g;
    end if;
  elsif p_action = 'decline' then
    if g.draw_offer_by is not null and g.draw_offer_by <> me then
      update public.online_games set draw_offer_by = null where id = g.id returning * into g;
    end if;
  else
    raise exception 'bad_action';
  end if;
  return public._online_view(g);
end $$;

-- -----------------------------------------------------------------------------
-- Quyền: chỉ người đã đăng nhập được gọi RPC; hàm nội bộ (_online_*) không mở cho ai.
-- -----------------------------------------------------------------------------
revoke all on function public._online_settle(public.online_games) from public, anon, authenticated;
revoke all on function public._online_view(public.online_games) from public, anon, authenticated;

revoke all on function public.online_find_match(int, int) from public, anon;
revoke all on function public.online_cancel_search() from public, anon;
revoke all on function public.online_get_game(uuid) from public, anon;
revoke all on function public.online_move(uuid, int, text, text, text) from public, anon;
revoke all on function public.online_resign(uuid) from public, anon;
revoke all on function public.online_draw(uuid, text) from public, anon;

grant execute on function public.online_find_match(int, int) to authenticated;
grant execute on function public.online_cancel_search() to authenticated;
grant execute on function public.online_get_game(uuid) to authenticated;
grant execute on function public.online_move(uuid, int, text, text, text) to authenticated;
grant execute on function public.online_resign(uuid) to authenticated;
grant execute on function public.online_draw(uuid, text) to authenticated;
