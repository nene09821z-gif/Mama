# v16i — Cờ Phép Thuật: 3 lá chọn 1, bài VIP mạnh, bài giải trí

## Mỗi lượt mở 3 lá bài (thay cho rút 1 lá mù)
- Đầu lượt: +1 mana và **3 lá bài khác nhau hiện ra ngẫu nhiên** (theo độ hiếm). Chọn 1 lá vào tay, hoặc **Bỏ qua để nhận +1 mana**.
- Tay bài đầy (7 lá) thì không mở lá mới.
- Giao diện thu gọn vừa khu tay bài: hàng 3 lá nhỏ (icon, mana, tên, nhãn). Chạm 1 lá → mô tả đầy đủ hiện ở dòng trạng thái → bấm «Nhận lá này». Phải chọn/bỏ qua trước khi đi quân.
- Chuyền máy: bài vẫn che, chạm để mở 3 lá.

## Bài VIP mạnh hơn
- Gói Gold trở lên: **luôn có ít nhất 1 lá đặc quyền ★** trong 3 lá; các ô còn lại có thêm cơ hội ra bài ★ (Gold 25% · Platinum 35% · Diamond/Family 45%).
- **Tuyệt kỹ** (12 lá gốc × 4 biến thể): giá thiết kế riêng, rẻ hơn mua rời nên mạnh thật.
  - Gold: Rồng Lửa, Thần Tài, Bão Tuyết, Sòng Bạc
  - Platinum: Hoán Đổi Hộ Mệnh, Hoàng Hôn Đỏ (diệt 2 quân), Quân Đoàn Bóng Tối, Tiệc Pháo Hoa
  - Diamond/Family: Ngày Tận Thế, Hoàng Đế Giáng Thế, Đại Phát Tài, Sao Băng Hoàng Gia
- Lá ★ viền vàng nhấp nháy, nhãn «★ Gói · Tuyệt kỹ».

## Bài giải trí 🎉 (mọi gói đều gặp)
Xúc xắc may rủi, Tung đồng xu, Gương soi (5 loại quân), Vòng quay may mắn, Mũ ảo thuật, Mưa sao băng. Kết quả ngẫu nhiên hiện trong thông báo (vd "🎲 Tung được 5!").

## Sửa lỗi
- `CardView` dùng `MagicCatalog.cards[id]` → sập khi cầm bài đặc quyền; đổi thành `MagicCatalog.get(id)`.

## File
- Sửa: `magic/MagicState.kt`, `magic/MagicGame.kt`, `magic/MagicCatalog.kt`, `magic/MagicEffects.kt`, `ui/MagicChessScreen.kt`, `ui/MoreTab.kt`, `test/.../MagicChessTest.kt`
- Test mới: 3 lá khác nhau, chọn/bỏ qua, tay đầy, VIP luôn có ★, gói cao ra ★ nhiều hơn, từng bài giải trí, Tuyệt kỹ.
