# v14 — Trang bài học kiểu chess.com (tab "Học")

## Mới
- game/LessonCatalog.kt  : kho bài học (24 bài / 6 khóa). Thêm bài = thêm 1 dòng practice(...) hoặc tactic(...).
                           PRACTICE = đấu Bot từ thế cờ có sẵn · TACTIC = tìm nước đi trên bàn cờ giải đố.
- game/LessonQuota.kt    : luật giới hạn: Free 5 bài MỚI/ngày (giờ máy), mở lại bài đã mở trong ngày không tốn lượt,
                           khóa PRO chỉ cho gói có UNLIMITED_LESSONS (Gold trở lên). Đếm ngược đến 0h.
- game/LessonProgress.kt : trạng thái thuần Kotlin (bài đã xong + bài đã bắt đầu hôm nay, tự làm mới khi sang ngày).
- game/LessonStore.kt    : lưu tiến độ bằng SharedPreferences "vila_lessons" (vài trăm byte) + StateFlow cho UI.
- ui/LessonsScreen.kt    : trang bài học: đầu trang (tiến độ + "Còn N/5 hôm nay" hoặc huy hiệu "Không giới hạn"),
                           thẻ "Tiếp tục học", thẻ hạn mức (5 vạch, đếm ngược khi hết), danh sách khóa → bài có bàn cờ nhỏ,
                           hộp thoại chi tiết bài, banner nâng cấp. Khóa PRO có ổ khóa.
- test/LessonCatalogTest.kt : id duy nhất, FEN hợp lệ, MỌI lời giải chạy được qua PuzzleSession, hạn mức 5/ngày, sang ngày mới
                           làm mới lượt, khóa PRO, mốc 0h, mã hóa tiến độ.

## Sửa
- ui/PuzzleSolveScreen.kt : thêm LessonPuzzleScreen (dùng lại bàn cờ giải đố + thẻ "Ý tưởng"); không đụng logic cũ.
- ui/HomeScreen.kt        : tab "Học" dùng LessonsTab mới; ẩn thanh điều hướng khi đang giải bài; học xong bài thực hành thì quay lại tab "Học".
- game/GameViewModel.kt   : startLesson(), ghi hoàn thành khi thắng Bot (hoặc hòa nếu bài cho phép), consumeReturnToLessons().
- billing/Membership.kt + web-paywall/shared/membership-spec.js : Quota.LESSONS 3 → 5 (giữ hai nơi khớp nhau), thẻ Free ghi "5 bài học/ngày".

## Nhẹ bộ nhớ
- Bàn cờ nhỏ vẽ bằng 1 Canvas, DÙNG LẠI bộ ảnh quân cờ đã nạp (không giải mã thêm ảnh).
- LazyColumn có key + contentType; bàn xem trước chỉ dựng khi cần và nhớ lại.
- Đồng hồ đếm ngược chỉ chạy khi hết lượt; làm mới ngày bằng 1 lần ngủ đến 0h (không polling).
- Không dùng cơ sở dữ liệu, không thư viện mới.

## Ghi chú
- Lượt/ngày đếm theo giờ máy (giống UsageTracker). Muốn chống chỉnh đồng hồ thì đếm ở server.
- Khóa "PRO" (Chiếu hết trong 2 nước, Tàn cuộc nâng cao) đổi sang miễn phí bằng cách đặt premium = false trong LessonCatalog.
