# v16h — Sửa nhãn Miss và Brilliant theo chuẩn Chess.com

Chỉ đổi logic gán nhãn trong `review/MoveClassifier.kt` (hàm thuần) + truyền thêm `mateAfter` ở `ReviewAssembler`.
Công thức Win%/Accuracy và các ngưỡng Excellent/Good/Inaccuracy/Mistake/Blunder (2 / 5 / 10 / 20%) giữ nguyên.

## 1. Miss
- Đối thủ vừa sai (`isOpponentJustBlundered`) mà mình đi ĐÚNG nước tốt nhất (hoặc nước tốt nhì ngang điểm) = đã trừng phạt
  => **Best / Great** (hoặc Brilliant), KHÔNG BAO GIỜ Miss.
- Miss chỉ khi đủ cả 4 điều kiện: đối thủ vừa sai · không phải nước tốt nhất · EP sụt **> 10%** (trước đây > 5%) · thế sau vẫn ≥ 40% EP.
  Thế sau < 40% là thế đã xấu thật => Mistake/Blunder chứ không phải "bỏ lỡ".
- Hằng: `MISS_MIN_LOSS` 0.05 → **0.10**. (`MISS_MIN_EP_AFTER` = 0.40 giữ nguyên.)
- Mất 5–10% sau lỗi của đối thủ nay là Inaccuracy (trước đây là Miss).

## 2. Brilliant
Vẫn cần: nước tốt nhất + hy sinh quân (`SacrificeDetector`). Sau đó một trong hai:
- **(mới) dẫn tới chiếu hết cho mình** (`mateAfter` ≥ 0: 0 = vừa chiếu hết, > 0 = có chiếu hết cưỡng bức) **hoặc thế sau áp đảo**
  (EP ≥ **95%**, hằng `BRILLIANT_OVERWHELMING_EP`) — **bất kể epBefore và bất kể nước thay thế**. Vd. smothered mate `12...Qg1+!!`
  vẫn là Brilliant dù nước tốt nhì cũng thắng đậm.
- (cũ, giữ nguyên) nước thay thế tốt nhất còn < 90% và hy sinh xong thế ≥ 40%.

`mateAfter` tính theo góc nhìn BÊN VỪA ĐI. Mate ÂM (mình sắp bị chiếu hết) và "không có mate" không tính —
hàm `MoveClassifier.leadsToMate()` kiểm dấu, không chỉ kiểm `!= null`.

## 3. ReviewJson.CURRENT_VERSION 7 → 8
Luật gán nhãn đổi nên ván đã phân tích tự phân tích lại (ngầm) khi mở.

## File đổi
- `review/MoveClassifier.kt` — hằng mới/đổi, tham số `mateAfter`, hàm `leadsToMate`, nhánh Miss/Brilliant.
- `review/ReviewAssembler.kt` — tính `mateAfterMover` một lần, dùng cho cả luật sàn mate lẫn `classifyMove`.
- `review/ReviewJson.kt` — phiên bản 8.
- `MoveClassifierTest.kt` — sửa `brilliantNeedsSacrificeAndSafeContext`, `brilliantUsesAlternativeNotBestWin`, `missAfterOpponentError`;
  đổi `noBrilliantWhenAlternativeAlsoWinsBig` → `smotheredMateQueenSacIsBrilliantEvenWhenAlternativeAlsoWinsBig` (luật cũ khẳng định điều ngược lại);
  thêm `brilliantAllowedForMatingSacrificeRegardlessOfEpBefore`, `leadsToMateCountsOnlyMatesInFavourOfTheMover`,
  `brilliantAllowedForOverwhelmingSacrificeRegardlessOfEpBefore`, `missNeedsMoreThanTenPercentLoss`,
  `bestMoveAfterOpponentBlunderPunishesAndIsNeverMiss`, `bestMoveAfterBlunderIsPunishedNotMiss` (ráp cả ván).
