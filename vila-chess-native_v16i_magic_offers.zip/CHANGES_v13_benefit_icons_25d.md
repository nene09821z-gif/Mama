# v13 — Bộ icon quyền lợi 2.5D + Trang chủ + Chọn gói thành viên

## Mới
- ui/BenefitIcons25D.kt: 13 icon 2.5D vẽ bằng Canvas (review, explain, stats, puzzle, learn, coach, bot, noads, family, invite, duel, trophy, newgame)
  - Benefit25D(kind, Modifier.size(..)) — sắc nét mọi kích thước, không dùng ảnh/emoji
  - TierGem (ngọc nhỏ theo màu gói cho tab), CheckMark (dấu tích cuối dòng)

## Sửa
- billing/PaywallScreen.kt: bỏ toàn bộ emoji; thanh tab Gold/Platinum/Diamond/Family đồng bộ với vuốt ngang (animateScrollToPage);
  nhóm "ĐỘC QUYỀN <GÓI>" và "BAO GỒM TRONG MỌI GÓI"; icon 2.5D + dấu tích mỗi dòng; dòng "2–6 thành viên" dùng icon Family
- billing/PaywallViewModel.kt, ManualPayDialog.kt: bỏ emoji 🎉 trong thông báo
- ui/HomeParts.kt: thẻ Học dùng ô sao vàng 2.5D + icon Học; nút bắt đầu trận gợi ý là ô New game 2.5D; FriendCard thêm tham số kind
- ui/HomeScreen.kt: Mời bạn bè = invite, Chơi với bạn = duel, Giải đấu = trophy
- ui/MoreTab.kt, ui/NewGameScreen.kt: đổi icon sang bộ 2.5D cho đồng bộ

## Lưu ý
- Chưa build được trong môi trường này (không có Gradle/Android SDK) — hãy chạy ./gradlew assembleDebug để kiểm tra.
