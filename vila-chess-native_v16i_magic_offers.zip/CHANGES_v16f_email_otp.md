# v16f – Đăng ký email bằng mã 6 số (Supabase OTP)

## Thay đổi code
- `SupabaseCloud.kt`: thêm `verifySignupOtp()` (POST /auth/v1/verify, type=signup) và `resendSignupOtp()` (POST /auth/v1/resend).
- `GoogleLoginGate.kt` (EmailForm): sau khi đăng ký, nếu Supabase yêu cầu xác nhận thì hiện màn "Nhập mã xác nhận":
  ô nhập 6 số (tự gửi khi đủ 6 số), nút Xác nhận, nút Gửi lại mã có đếm ngược 60 giây, nút ← quay lại.

## Cấu hình Supabase (bắt buộc)
1. Authentication → SMTP Settings: bật SMTP riêng (không có thì không sửa được mẫu email).
2. Authentication → Emails → Confirm signup: thay `{{ .ConfirmationURL }}` bằng `{{ .Token }}`.
3. Authentication → Providers → Email: giữ bật "Confirm email"; Email OTP Length = 6.
