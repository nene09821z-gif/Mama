# Hướng dẫn cấu hình Paywall ChessPlus

## 0. Tổng quan
| Gói | Quyền lợi |
|---|---|
| FREE | Game Review 1 ván/ngày, 3 câu đố/ngày, có quảng cáo |
| GOLD | + Không quảng cáo, câu đố & bài học không giới hạn (Review vẫn 1 ván/ngày) |
| PLATINUM | + Game Review không giới hạn |
| DIAMOND | + Coach Explanations, Insights, Advanced Stats |

Quy ước ID (phải khớp code):
- Google Play subscription: `chessplus_gold`, `chessplus_platinum`, `chessplus_diamond`
- Mỗi subscription có 2 base plan: `monthly`, `yearly`
- RevenueCat entitlement: `gold`, `platinum`, `diamond`
- RevenueCat package (trong offering `default`): `gold_monthly`, `gold_yearly`, `platinum_monthly`, ... (Custom identifier)

Đổi giá trị ở đâu: Android `billing/BillingCatalog.kt`; Web `shared/membership-spec.js` + package id trong RevenueCat. Bảng quyền lợi nằm ở `Membership.kt` và `membership-spec.js` — sửa cả hai.

## 1. Google Play Console
1. Tạo app, upload một bản build (AAB, track Internal testing) có chứa thư viện Billing. Subscription chỉ tạo được sau khi có build có quyền BILLING.
2. Hồ sơ thanh toán: Setup → Payments profile (cần để bán).
3. Monetize → Products → **Subscriptions** → Create subscription:
   - Product ID: `chessplus_gold` (không đổi được sau này), đặt tên/mô tả.
   - Add base plan: ID `monthly`, Auto-renewing, Billing period 1 month, đặt giá (Play tự quy đổi tiền tệ các nước); Activate.
   - Add base plan: ID `yearly`, 1 year, đặt giá (gợi ý ≈ 10 × giá tháng); Activate.
   - Lặp lại cho `chessplus_platinum`, `chessplus_diamond`.
4. Không tạo offer (free trial/giảm giá) nếu chưa cần: code hiện chỉ lấy base plan. Muốn dùng trial, chọn offer có `offerId != null` trong `BillingRepository.toOptions`.
5. Setup → License testing: thêm Gmail của bạn → mua thử không mất tiền. Cài app qua link Internal testing (không cài từ Android Studio nếu `applicationId`/chữ ký khác bản đã upload).
6. Nâng/hạ cấp giữa các gói đã được xử lý trong `launchPurchase` (CHARGE_PRORATED_PRICE khi nâng, DEFERRED khi hạ).

## 2. Cấu hình RevenueCat (bản Web/Capacitor)
1. app.revenuecat.com → Create project → Add app **Google Play** (nhập package name) → upload Service Account JSON (Play Console → Setup → API access → tạo service account, cấp quyền *View financial data* + *Manage orders and subscriptions*). Thêm app iOS nếu cần.
2. Products → Import products từ Play (chessplus_gold:monthly, ... mỗi base plan một product).
3. Entitlements → tạo `gold`, `platinum`, `diamond`; gắn các product tương ứng (gold: 2 product của Gold; platinum: 2 product của Platinum; diamond: 2 product của Diamond). Muốn Platinum "gồm" Gold thì không cần gắn thêm: code web tự lấy gói cao nhất đang active.
4. Offerings → `default` (Current) → thêm 6 package, **Custom identifier** = `gold_monthly`, `gold_yearly`, `platinum_monthly`, ... gắn đúng product.
5. API keys → copy **Public SDK key** của Android → `.env`: `VITE_RC_ANDROID_KEY=goog_xxx` (iOS: `VITE_RC_IOS_KEY`).
6. `npm i @revenuecat/purchases-capacitor && npx cap sync`. Gọi `initPurchases({ appUserId })` lúc khởi động.
7. Chạy thuần trình duyệt: dùng `?mock=1` để xem giao diện; bán trên web thật cần RevenueCat Web Billing (key `VITE_RC_WEB_KEY`).
8. Dùng chung 1 tài khoản giữa Android native và web: đặt cùng `appUserId` (id tài khoản của bạn) cho cả hai.

## 3. Cài vào dự án
- **Android**: đã tích hợp sẵn trong zip (`app/.../billing/*`, route `HomeRoute.PAYWALL`, banner "Nâng cấp" ở Trang chủ cho gói FREE, gate Game Review ở `GameViewModel.enqueueSilentReview`). Thêm `billing-ktx:7.1.1` + quyền INTERNET đã có trong gradle/manifest.
- **Web**: copy thư mục `web-paywall/` vào `src/` của app Vite; `import './paywall.css'`; xem `index.html` làm ví dụ.

## 4. Dùng phân quyền trong màn hình
Android:
```kotlin
FeatureGate(Feature.INSIGHTS, onUpgrade = { vm.navigate(HomeRoute.PAYWALL) }) { InsightsPanel() }
val usage = UsageTracker.get(ctx)
if (!usage.canUse(Quota.PUZZLES, tier)) { /* hiện UpgradeBar */ } else { startPuzzle(); usage.consume(Quota.PUZZLES) }
```
Web:
```js
gateFeature(document.querySelector('#insights'), Feature.INSIGHTS, openPaywall);
if (!guardQuota(Quota.PUZZLES, openPaywall)) return; startPuzzle(); consume(Quota.PUZZLES);
```
Quảng cáo: bọc mọi chỗ hiện quảng cáo bằng `showAds(tier)`.

## 5. Xử lý lỗi & bảo mật
- Hủy giao dịch: chỉ hiện thông báo nhẹ, không phải lỗi. Mất mạng: giữ gói đã lưu, không hạ về FREE; báo "Không có kết nối mạng".
- Thanh toán chờ (pending): không cấp quyền cho đến khi hoàn tất.
- **Chống gian lận**: gói lưu ở SharedPreferences/localStorage chỉ là cache, người dùng root có thể sửa. Cách làm:
  - Web/RevenueCat: RevenueCat tự xác thực biên lai với Google/Apple; app luôn đọc lại `customerInfo` khi mở. Nếu có backend, nhận webhook (`server/verify-purchase.js` → `/revenuecat-webhook`) và để **server** quyết định các tính năng đắt tiền (Insights, Coach...).
  - Native: deploy `server/verify-purchase.js`, điền URL vào `BillingCatalog.VERIFY_ENDPOINT`. App gửi `purchaseToken`, server gọi `purchases.subscriptionsv2.get`. Biên lai không hợp lệ → không cấp quyền, không acknowledge. Đừng bao giờ đặt service-account key trong app.
  - Hạn mức theo ngày đang đếm theo đồng hồ máy; muốn chặt chẽ thì đếm ở server.
- Bắt buộc acknowledge trong 3 ngày, nếu không Google tự hoàn tiền (code đã làm; nếu server không liên lạc được thì thử lại ở lần refresh sau).

## 6. Test checklist
1. Cài bản Internal testing, đăng nhập Gmail license tester. 2. Mua Gold tháng → banner "Nâng cấp" biến mất. 3. Nâng lên Platinum. 4. Hủy ở màn hình thanh toán → thông báo "đã hủy". 5. Bật chế độ máy bay → mở Paywall → thông báo mạng; gói đã mua vẫn giữ. 6. Cài lại app → "Khôi phục giao dịch". 7. Hủy sub trong Play → hết hạn thì app về FREE sau lần refresh kế tiếp (subscription test chạy gia hạn nhanh: 5 phút/tháng).

## 7. Ghi chú / giả định
- Billing Library 7.1.1. Nếu nâng lên 8.x cần kiểm tra lại các thay đổi API (xem release notes).
- Số bài học miễn phí/ngày (Free) đề chưa nêu: đang đặt 3, sửa ở `Quota.LESSONS`.
- Chưa có màn Câu đố / Insights / quảng cáo thật trong project nên mới tích hợp gate vào Game Review (có sẵn) và Trang chủ; các màn còn lại dùng `FeatureGate`/`Quota` như mục 4.

## 8. Thanh toán chuyển khoản + mã kích hoạt (không cần Google Play Console)
Dùng khi phát hành APK ngoài Google Play. Luồng: người dùng chọn gói → app hiện mã VietQR + nội dung chuyển khoản (có mã thiết bị) → bạn nhận tiền, chạy script tạo mã → người dùng nhập mã → gói có hạn 31 ngày (tháng) / 366 ngày (năm), mua lại cùng gói thì cộng dồn.

Thiết lập một lần, trong `billing/BillingCatalog.kt`:
- `ManualPay.BANK_BIN / BANK_NAME / ACCOUNT_NO / ACCOUNT_NAME / CONTACT`: thông tin ngân hàng của bạn và nơi người dùng gửi biên lai.
- `BillingCatalog.priceVnd`: bảng giá (VND).
- `ManualPay.LICENSE_SECRET`: khóa bí mật, nên đổi sang chuỗi của riêng bạn và không chia sẻ.

Tạo mã cho một khách (mã thiết bị 8 ký tự hex lấy từ nội dung chuyển khoản hoặc khách gửi):
```
python3 scripts/gen_license.py --device A1B2C3D4 --tier gold --period yearly
```
Mã gắn với 1 thiết bị, dùng 1 lần, phải nhập trong 90 ngày kể từ lúc cấp. Lưu ý: khóa bí mật nằm trong APK nên người rành kỹ thuật có thể giả mã; muốn chặt hơn thì cần server xác thực.

## Gói Friends & Family (v10_48)
- Thêm gói `family` (rank 4, gồm toàn bộ quyền lợi Diamond), chỉ bán theo năm.
- Google Play Console: tạo subscription `chessplus_family` chỉ với base plan `yearly`.
- Supabase: chạy `supabase/membership_family.sql` một lần (mở rộng ràng buộc cột `users.tier`).
- Cloudflare Worker + `scripts/gen_license.py` đã nhận tier `family` (nội dung CK: `VILA <mã> FAMILY Y`).
- Giá tham chiếu `BillingCatalog.priceVnd(FAMILY, YEARLY)` = 1.699.000 ₫ — sửa theo giá bạn muốn, nhớ sửa cả `PRICES.FAMILY.Y` trong cloudflare/src/index.js.
