# Hệ thống Hồ sơ (Profile)

## File mới
- `profile/ProfileModels.kt` – UserProfile, EloSeries (dữ liệu biểu đồ), chuỗi thắng/thua, quốc gia, avatar (logic thuần, có test).
- `profile/UserSessionManager.kt` – userId / elo / tier / tên / quốc gia / avatar; đồng bộ cloud. **Gói luôn đọc từ MembershipStore.**
- `profile/ProfileRepository.kt` – Supabase `users`, `friendships`. `profile/ProfileStores.kt` – lịch sử Elo + 50 ván gần nhất.
- `profile/FriendsViewModel.kt` – danh sách bạn bè (Loading/Error/Empty/Success).
- `ui/MembershipBadge.kt` – `MembershipBadge(tier: String)` (Gold ★ vàng, Platinum 👑 bạc, Diamond 💎 xanh lấp lánh, Free: ẩn).
- `ui/EloChart.kt` – biểu đồ Canvas 7 ngày / 30 ngày / 1 năm, chạm/kéo xem từng mốc.
- `ui/MyProfileScreen.kt` – hồ sơ của mình (userId=null) hoặc của người khác; 4 tab; Chỉnh sửa hồ sơ.
- `ui/OpponentProfileSheet.kt` – ModalBottomSheet đối thủ. `ui/FriendsPanel.kt`, `ui/ProfileComponents.kt`.

## Sửa file cũ
Stats.kt (resultStreak), SupabaseCloud (uid + restCall), GameViewModel (openProfile, ghi lịch sử sau ván), HomeScreen/MoreTab (route + mục Hồ sơ + danh sách bạn), GameCommon.PlayerBar (tier, onProfileClick), BotGameScreen, MainActivity, AccountStore.

## Việc cần làm
1. Chạy phần cuối `supabase/schema.sql` (bảng users, friendships + RLS).
2. Ván online (khi có): `PlayerBar(..., tier = opp.tier, onProfileClick = { show = true })` + `OpponentProfileSheet(...)` – ví dụ trong KDoc của OpponentProfileSheet.
3. Test: `./gradlew testDebugUnitTest` (ProfileLogicTest).
