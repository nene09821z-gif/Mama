# v14g — Bỏ chặn 15% pin + điểm phân tích chuẩn Lichess

## Bỏ chặn "15%"
"Đang chờ máy sạc hoặc pin trên 15%" là ràng buộc WorkManager `setRequiresBatteryNotLow(true)` trong GameAnalysisWorker.
- Đã xóa mọi ràng buộc: phân tích chạy NGAY, pin bao nhiêu cũng chạy.
- Máy nóng (>40°C) trước đây dừng 1 phút/lượt, quá 5 lượt thì bỏ dở và retry. Giờ chỉ nghỉ 4 giây, tối đa 2 lần (~8s) rồi LUÔN chạy tiếp.
- Bỏ chữ "chờ sạc/pin 15%" ở lớp phủ và màn chờ.

## Điểm phân tích (review/LichessAccuracy.kt — mới)
Port đúng thuật toán mã nguồn mở của Lichess (lila AccuracyPercent.scala, lichess.org/page/accuracy):
1. Win% = 50 + 50·(2/(1+exp(−0,00368208·cp)) − 1); cp kẹp ±1000; chiếu hết tính như ±1000cp.
2. Accuracy% mỗi nước = 103,1668·exp(−0,04354·(Win% trước − Win% sau)) − 3,1669 **+ 1** (bù sai số), kẹp 0–100. (Bản cũ thiếu "+1".)
3. Cả ván mỗi bên = (trung bình TRỌNG SỐ theo độ biến động + trung bình ĐIỀU HÒA) / 2.
   Trọng số = độ lệch chuẩn Win% trong cửa sổ trượt cỡ clamp(số nước/10, 2, 8), kẹp 0,5–12. (Bản cũ dùng trung bình cộng + điều hòa, không có trọng số biến động.)
- Nước trùng nước tốt nhất của Stockfish hoặc nằm trong sổ khai cuộc = không mất gì (giữ cách chống nhiễu độ sâu của app).
- Nhãn nước đi (Brilliant/Great/Best/Excellent/Good/Inaccuracy/Mistake/Blunder/Miss/Book) vẫn theo mô hình Expected Points của Chess.com:
  Excellent < 2% · Good 2–5% · Inaccuracy 5–10% · Mistake 10–20% · Blunder > 20% (đúng bảng Chess.com đã công bố).
- ReviewJson.CURRENT_VERSION 4 → 5: ván đã phân tích bằng cách tính cũ sẽ tự phân tích lại (ngầm) khi mở.
- test/LichessAccuracyTest.kt: công thức, +1, ví dụ trung bình điều hòa của diễn đàn Lichess (84,71), cửa sổ/trọng số, ván mẫu đối chiếu bản port Python.
