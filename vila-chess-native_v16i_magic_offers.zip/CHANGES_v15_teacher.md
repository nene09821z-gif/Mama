# v15 — THẦY GIÁO (ghép trên nền v14g_analysis): avatar Rive + nhìn bàn cờ + nói rất nhiều

Bật công tắc "Bật huấn luyện viên" (như cũ) ở ván Bot / Tàn cuộc là thầy xuất hiện thay cho thanh CoachStrip cũ.

## Thầy làm được gì
- Đọc thế cờ bằng luật cờ (KHÔNG engine, không tốn pin): quân treo, bị quân yếu hơn dọa, đòn đôi, chiếu hết 1 nước, ghim,
  hàng cuối bị bít, cột mở, Xe hàng 7, tốt thông/chồng/cô lập, cặp Tượng, trung tâm, Vua hở / chưa nhập thành,
  quân chưa ra, tàn cuộc, đối thủ gần bí, hơn/kém quân.
- Bình luận từng nước (của bạn VÀ của máy): ăn quân miễn phí, đổi quân, ăn lại, chiếu, nhập thành, bắt tốt qua đường,
  phong cấp, đưa quân vào chỗ bị ăn, bỏ quên quân treo, BỎ LỠ MIẾNG NGON, lặp quân khai cuộc, Hậu ra sớm, Mã ra rìa,
  nước đầu (e4/d4/Nf3/c4), tên khai cuộc (sách khai cuộc có sẵn), thế hơn/kém đổi chiều, chuỗi nước chắc tay…
- 400+ câu, 3 tính cách (Hiền / Nghiêm / Vui, đổi cả cách xưng hô), 3 mức nói nhiều (Ít/Vừa/Nhiều),
  chống lặp (shuffle-bag + thời gian nghỉ theo chủ đề), mẹo + chuyện vui khi không có gì đặc biệt.
- Vẽ lên bàn cờ: vòng vàng quanh ô thầy nói tới, mũi tên chỉ hướng dọa (tự tắt sau 9 giây).
- Avatar Rive (res/raw/teacher_avatar.riv): mắt liếc về ô cờ thầy đang nói, nhún/rung/nhảy theo tâm trạng, chạm vào thầy => mẹo/chuyện vui.
- Nút: Hỏi thầy (thầy kể những gì thấy trên bàn) · Gợi ý (engine, thầy đọc lời) · Sổ tay (xem lại mọi lời) · Cài đặt.
- Thầy nhắc khi bạn nghĩ lâu (28s/58s/98s), đọc thành tiếng (TextToSpeech vi-VN, tắt mặc định), lời kết ván.

## File
Mới : coach/BoardReader.kt, TeacherLines.kt, TeacherBrain.kt, TeacherController.kt · ui/TeacherAvatar.kt, TeacherPanel.kt
      res/raw/teacher_avatar.riv · test/TeacherBrainTest.kt
Sửa : GameViewModel (teacher, askTeacher, móc sync/hint/gameOver) · UiState.teacherMarks · BoardView (vẽ dấu)
      BotGameScreen (dùng TeacherPanel) · MoreTab (mục THẦY GIÁO) · build.gradle.kts (rive-android, startup)
      proguard-rules.pro · AndroidManifest.xml (<queries> TTS)

## CHƯA ĐƯỢC BUILD/CHẠY (môi trường soạn không có Kotlin/Gradle/mạng) — việc cần làm đầu tiên
1. Build thử. `app.rive:rive-android:9.+` là bản 9.x mới nhất; build xong nên ghim số cụ thể.
   Nếu bạn dùng Rive 10.x (API Compose mới) thì đổi phần TeacherFace trong ui/TeacherAvatar.kt.
2. Chạy `./gradlew testDebugUnitTest` (TeacherBrainTest kiểm: mọi nhóm câu có nội dung, không còn ký hiệu {..},
   phát hiện quân treo / chiếu hết 1 nước / đòn đôi Mã, thầy im khi để mức "Ít").
3. File Rive chỉ có input pressed/exited + listener Tap/Exit/Move (không có biểu cảm miệng).
   Mắt liếc dựa vào giả lập MotionEvent (aimPointer); nếu không thấy mắt đảo, báo mình sửa.
   Fit.COVER cắt giữa khung: nếu hình cắt lệch đầu, đổi Fit/Alignment ở TeacherFace.

## Ghép vào v14g
Patch khớp sạch vào v14g (premove Đơn/Nhiều, bộ âm thanh, màu bàn cờ): không xung đột, chỉ lệch số dòng.
Đã rà: khóa LazyColumn ở MoreTab không trùng, VilaColors dùng đủ, không trùng tên lớp/hàm với file mới của v14g.
