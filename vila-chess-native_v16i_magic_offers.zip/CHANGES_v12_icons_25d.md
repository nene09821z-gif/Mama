# v12 — Icon 2.5D + tiến trình phân tích trên bàn cờ

## Mới
- ui/Badge25D.kt           : 10 nhãn nước đi vẽ vector 2.5D (LabelGlyph + drawLabelBadge), không emoji/ký tự hệ thống
- ui/ToolbarIcons25D.kt    : icon thanh công cụ 2.5D (Tùy chọn, Hủy/Đầu hàng, Gợi ý có phát sáng, Đánh giá, Hoàn tác, Tái đấu)
- ui/AnalysisBoardOverlay.kt: lớp phủ "Đang phân tích" trên bàn cờ (vòng %, thanh nước đi, nhãn bay), tự mở Review 2 trang khi xong

## Sửa
- AnimatedAnalysisLabel.kt : bỏ LabelGlyph cũ (text), đồng bộ bảng màu nhãn
- GameCommon.kt            : ToolbarButton cấp LocalToolbarEnabled/Active cho icon 2.5D
- BotGameScreen / PvpGameScreen / OnlineGameScreen : dùng icon 2.5D + lớp phủ tiến trình trên bàn cờ
- BoardView.kt             : nhãn nảy lò xo lên ô vừa đi, to hơn
- GameReviewScreen.kt      : nhãn 2.5D trên bàn cờ review, thẻ nước đi lớn hơn, vạch tab trượt theo ngón vuốt giữa 2 trang
- HomeIcons.kt / HomeParts.kt : đế nổi 2.5D cho icon Home (kim cương, chuông, bạn bè, đạn, tia chớp, đồng hồ) + 5 icon thanh điều hướng mới
- review/GameAnalysisWorker.kt : setProgress(done,total) cho lớp phủ
- review/GameReviewViewModel.kt: ReviewUiState.Pending có done/total
- game/GameViewModel.kt    : progressHandled (tránh lặp lớp phủ khi quay lại từ Review)
