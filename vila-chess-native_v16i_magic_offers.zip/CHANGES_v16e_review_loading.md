# v16e — Sửa nút "Giải các câu đố" + Game Review kiểu chess.com (thay lớp phủ % cũ)

## Sửa lỗi
- ui/PuzzleMapScreen.kt : nút "Giải các câu đố" không làm gì vì PuzzleTab không truyền `onSolveClick` (mặc định `{}`).
  Nay `onSolveClick` mặc định null => nút mở thẳng level đang chơi bằng đúng luồng chạm nút trên bản đồ (onNodeClick).

## Xoá
- ui/AnalysisBoardOverlay.kt (vòng 97% + "Stockfish đang phân tích ngầm…" + "Xem ngay bàn cờ"). Bot / Online / PvP không còn
  lớp phủ này; hết ván là hiện thẳng hộp thoại kết quả.

## Mới
- ui/ReviewLoadingParts.kt
  · ReviewLabelCycler   : 3 nhãn nảy và đổi liên tục (~0,6s) trong lúc chờ.
  · KnightLoadingBoard  : bàn 3x3, con mã nhảy theo vòng 8 ô (ô đáp sáng xanh), dùng bộ quân đang chọn.
  · ReviewLabelResults  : xong thì 3 nhãn trên được thay bằng các nhãn THẬT của ván + số nước (tối đa 6, ưu tiên Brilliant/Great/Best/lỗi).
- ui/PostGameSummaryScreen.kt (PostGameDialog)
  · Chờ  : bong bóng "Đang tải Game Review…", hàng nhãn đổi liên tục, dòng "Stockfish đang phân tích · x/y thế cờ", con mã nhảy.
  · Xong : hàng nhãn thật + "Độ chính xác của bạn: xx%", sau ~2,6s TỰ chuyển sang màn Review 2 trang (Phân tích / Tóm tắt).
  · Lỗi  : nút "Thử lại".
  · Quay lại từ Review không tự nhảy lại (vm.progressHandled).
- review/GameReviewViewModel.kt : isFor(gameId).

## Engine
- Vẫn GameAnalysisWorker + SilentStockfishEngine: ưu tiên Stockfish NATIVE (libstockfish.so, MultiPV 2, depth theo máy,
  vòng kiểm chứng sâu hơn), chỉ rơi về wasm khi không chạy được native.
- libstockfish.so KHÔNG nằm trong zip (jniLibs/arm64-v8a chỉ có README) => do workflow "Build APK" tải về khi build.
  Thiếu file đó thì app âm thầm dùng wasm (yếu và chậm hơn).

## Lưu ý
- Chưa build được trong môi trường này (không có Gradle/Android SDK) - hãy chạy ./gradlew assembleDebug hoặc đẩy lên GitHub Actions.
