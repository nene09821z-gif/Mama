# v14e — Phân tích ngầm, tự nhận máy, hết nhãn từng nước khi đang chơi

## Bỏ
- Nhãn chất lượng từng nước khi đang chơi (huy hiệu trên bàn cờ, chữ ở thanh dưới, thanh nhãn trên cùng): GameViewModel.liveLabelsAllowed() luôn false,
  công tắc "Phản Hồi nước đi" ẩn khỏi Cài đặt ván. (Kể cả người dùng cũ đang bật cờ "moveLabels" trong SharedPreferences.)
- Lớp phủ "Đang phân tích" cuối ván không còn nhãn bay lơ lửng, thanh màu từng nước, đếm "x/n nước": chỉ còn vòng % + "Stockfish đang phân tích ngầm…".

## Giữ (đã có sẵn)
- Hết ván → GameAnalysisWorker chạy NGẦM bằng Stockfish native (libstockfish.so; dự phòng wasm) → xong tự mở màn Review 2 trang (Phân tích / Tóm tắt).

## Tự nhận máy (review/DeviceTierManager.kt)
| Máy   | Điều kiện                                   | Depth trần | Thread | Hash      | Thời gian/thế |
|-------|---------------------------------------------|-----------:|-------:|-----------|--------------:|
| Yếu   | RAM < 3GB, cờ low-RAM, hoặc CPU < 1,8GHz    | 14–16      | 1      | 16MB      | 0,8s          |
| Trung | RAM 3–6GB                                   | 18–20      | ≤ 2    | 64MB      | 1,3s          |
| Mạnh  | RAM > 6GB                                   | 20–30      | ≤ 4    | 128–256MB | 2,0s          |
Độ sâu cộng thêm theo số nhân (≥ 6/8) và xung nhịp nhân lớn nhất (đọc sysfs). Vòng kiểm chứng nước nghi sai: depth + 4, tối đa 30.
Depth là TRẦN, thời gian/thế là chốt chặn để luôn nhanh: thế đơn giản chạm depth trần, thế phức tạp dừng theo thời gian.
test/DeviceTierTest.kt kiểm các dải 14–16 / 18–20 / 20–30.
