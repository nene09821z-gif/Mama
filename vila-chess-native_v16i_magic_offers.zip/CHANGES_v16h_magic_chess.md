# v16h (gộp) — Miss/Brilliant + Cờ Phép Thuật

Gói này = v16h_miss_brilliant (giữ nguyên toàn bộ MoveClassifier/Review v8) + toàn bộ chế độ **Cờ Phép Thuật** (từ v16i_magic_exclusive_1).

# Cờ Phép Thuật (chế độ riêng)

- Mở từ **Các tùy chỉnh → Cờ Phép Thuật** (`HomeRoute.MAGIC`). 2 người cùng máy, màn và bàn cờ độc lập (`ui/MagicChessScreen.kt`), không đụng `GameViewModel`.
- Lõi luật thuần Kotlin trong `magic/`: mana (+1/lượt, tối đa 10), rút 1 bài/lượt (cầm tối đa 7), 1 bài/lượt, phép chạy trên bản sao và bị từ chối nếu Vua mình bị chiếu / mất Vua / Tốt ở hàng cuối.
- Kho bài tự sinh: 181 hiệu ứng gốc × 12 phần thưởng = hơn 2.000 lá, 5 độ hiếm theo giá mana.
- Chuyền máy: sau mỗi lượt bài được che, chạm để xem.
- `MagicChessTest`: test kho bài, từng hiệu ứng chính, 30 ván ngẫu nhiên kiểm bất biến.

## Bài đặc quyền theo gói
- `MagicCatalog.exclusive`: bài ★ Gold (5 lá gốc), Platinum (+6), Diamond (+6), mỗi lá × 4 biến thể (Thường/Vang Vọng/Lời Nguyền/Tiết Kiệm). Family = Diamond.
- Công bằng theo cấu trúc: mỗi lá là `Combo` gộp các phép thường; giá = tổng giá các lá thường tương ứng + 1 → không rẻ hơn mua rời, chỉ thêm lựa chọn.
- Bộ bài dùng chung cho CẢ HAI người chơi (cùng tài khoản/máy), tỉ lệ rút bài ★ 12%. Gói Free không rút được.
- `MagicGame(seed, tier)` / `MagicState.tier`; `MagicCatalog.randomId(rng, tier)`, `get(id)`, `exclusiveFor(tier)`.
- UI: viền vàng + nhãn "★ Gold…" trên bài; ván mới tự đồng bộ gói trước nước đi đầu tiên; dòng luật + phụ đề ở Tùy chỉnh.
- Test: 19 test (thêm: Free không rút ★, gói lồng nhau, giá ≥ tổng phần + 1, playout Diamond giữ bất biến).

## Các file thêm/sửa so với v16h_miss_brilliant
- Thêm: `magic/MagicCatalog.kt`, `magic/MagicEffects.kt`, `magic/MagicGame.kt`, `magic/MagicState.kt`, `ui/MagicChessScreen.kt`, `test/.../MagicChessTest.kt`
- Sửa: `game/Modes.kt` (thêm `HomeRoute.MAGIC`), `ui/HomeScreen.kt` (route MAGIC), `ui/MoreTab.kt` (mục "CỜ PHÉP THUẬT")
