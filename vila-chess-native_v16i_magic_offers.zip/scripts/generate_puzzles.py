#!/usr/bin/env python3
"""
Tạo puzzles.db (SQLite) + kho bài học chiến thuật cho ViLa Chess từ kho câu đố Lichess (CC0).

VÌ SAO BẢN CŨ TOÀN CÂU "CHIẾU HẾT 1 NƯỚC":
  Bản cũ lấy 50.000 câu có Rating THẤP NHẤT. Ở vùng rating 400-900 của Lichess gần như chỉ có
  mateIn1 / oneMove ⇒ bản đồ 50.000 level không có đòn chiến thuật tự do nào.

BẢN NÀY:
  1. Chia kho Lichess thành các khoảng Rating đều nhau (25 điểm) từ ~400 đến ~3300.
  2. Mỗi khoảng lấy một lượng bằng nhau (khoảng nào ít câu thì lấy hết, phần dư chia cho khoảng khác).
  3. Trong mỗi khoảng, lấy mẫu CÓ TRỌNG SỐ: mateIn1 / oneMove bị giảm trọng số, các đòn chiến thuật tự do
     (đòn đôi, ghim, xiên, dụ quân, hy sinh, nước yên lặng …) được ưu tiên; câu nhiều người thích (Popularity) được ưu tiên.
  4. Xếp Rating TĂNG DẦN (dễ → khó); cùng Rating thì xáo trộn ổn định để các chủ đề xen kẽ nhau.
     id = 1 … N chính là số Level trên bản đồ (PuzzleMapViewModel.TOTAL_LEVELS phải bằng N).
  5. Cùng lượt đọc, chọn ~12 bài/chủ đề (dễ → khó) ghi ra LessonLichessData.kt ⇒ các khóa học theo chủ đề ở tab "Học".

Dùng:
    python3 scripts/generate_puzzles.py                          # tải về, ghi puzzles.db + LessonLichessData.kt
    python3 scripts/generate_puzzles.py --input puzzles.csv.zst --out /tmp/puzzles.db --count 100000
    python3 scripts/generate_puzzles.py --count 1000000          # ~140 MB: cần sửa TOTAL_LEVELS cho khớp

Giải nén .zst: ưu tiên module `zstandard`, nếu không có thì dùng lệnh `zstd` (có sẵn trên runner ubuntu-latest).
"""
from __future__ import annotations

import argparse
import csv
import heapq
import io
import random
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import urllib.request
import zlib
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

LICHESS_URL = "https://database.lichess.org/lichess_db_puzzle.csv.zst"
DEFAULT_COUNT = 300_000          # PHẢI khớp PuzzleMapViewModel.TOTAL_LEVELS
ROOT = Path(__file__).resolve().parent.parent
DEFAULT_OUT = ROOT / "app" / "src" / "main" / "assets" / "puzzles.db"
DEFAULT_LESSONS = ROOT / "app" / "src" / "main" / "java" / "com" / "vila" / "chess" / "game" / "LessonLichessData.kt"

REQUIRED = ("PuzzleId", "FEN", "Moves", "Rating")

# ── Bộ lọc chất lượng (kho Lichess có nhiều câu ít người chơi / rating chưa ổn định)
MIN_POPULARITY = 70
MIN_PLAYS = 30
MAX_RD = 110

# ── Khoảng rating
BUCKET_W = 25
RATING_MIN = 400
RATING_MAX = 3300

# ── Trọng số lấy mẫu: <1 = giảm, >1 = ưu tiên
THEME_WEIGHT = {
    "mateIn1": 0.07,
    "oneMove": 0.15,
    "mateIn2": 0.45,
}
FREE_TACTIC_THEMES = {
    "fork", "pin", "skewer", "discoveredAttack", "doubleCheck", "deflection", "attraction", "sacrifice",
    "quietMove", "xRayAttack", "interference", "clearance", "capturingDefender", "intermezzo",
    "trappedPiece", "hangingPiece", "zugzwang", "exposedKing", "advancedPawn", "defensiveMove",
}
FREE_TACTIC_BONUS = 1.4

SCHEMA = """
CREATE TABLE puzzles (
    id        INTEGER PRIMARY KEY,   -- 1 … N, 1 = dễ nhất = số Level trên nút gỗ
    puzzle_id TEXT    NOT NULL,
    fen       TEXT    NOT NULL,
    moves     TEXT    NOT NULL,
    rating    INTEGER NOT NULL,
    themes    TEXT    NOT NULL DEFAULT ''
);
CREATE TABLE android_metadata (locale TEXT);
INSERT INTO android_metadata VALUES ('en_US');
"""

# ───────────────────────────────────────────────────────────── Khóa học theo chủ đề
# (theme Lichess, tên khóa, mô tả khóa, ý tưởng, mục tiêu)
COURSE_THEMES = [
    ("fork", "Đòn đôi", "Một quân tấn công hai mục tiêu cùng lúc",
     "Một quân tấn công hai mục tiêu cùng lúc, đối thủ chỉ cứu được một.", "Tìm nước tấn công hai quân cùng lúc"),
    ("pin", "Ghim quân", "Quân bị ghim không thể rời đi",
     "Quân bị ghim không thể rời đi vì sẽ để lộ quân quan trọng hơn phía sau. Hãy khai thác điều đó.", "Khai thác quân bị ghim"),
    ("skewer", "Xiên quân", "Ép quân lớn tránh đi rồi ăn quân phía sau",
     "Tấn công quân giá trị cao để nó phải rời đi, rồi ăn quân đứng sau nó.", "Tìm nước xiên quân"),
    ("discoveredAttack", "Tấn công lộ", "Mở đường cho quân phía sau tấn công",
     "Di chuyển một quân để mở đường cho quân phía sau, tạo hai mối đe dọa cùng lúc.", "Tìm đòn tấn công lộ"),
    ("doubleCheck", "Chiếu kép", "Hai quân cùng chiếu vua một lúc",
     "Khi hai quân cùng chiếu, vua bắt buộc phải di chuyển và không thể chặn hay ăn quân chiếu.", "Tìm nước chiếu kép"),
    ("deflection", "Dụ quân đi chỗ khác", "Ép quân phòng thủ rời vị trí quan trọng",
     "Ép quân phòng thủ rời khỏi vị trí quan trọng để mục tiêu bị bỏ hở.", "Dụ quân phòng thủ đi chỗ khác"),
    ("attraction", "Dẫn dụ", "Hy sinh để kéo quân đối phương vào thế xấu",
     "Hy sinh để kéo quân (thường là Vua) đến ô bất lợi rồi tung đòn quyết định.", "Tìm nước dẫn dụ"),
    ("sacrifice", "Hy sinh quân", "Bỏ quân để đổi lấy lợi thế lớn hơn",
     "Đôi khi bỏ một quân là cách nhanh nhất để chiếu hết hoặc thắng lợi thế lớn.", "Tìm nước hy sinh đúng"),
    ("hangingPiece", "Quân bị bỏ hở", "Tìm quân không được bảo vệ",
     "Luôn kiểm tra quân nào của đối thủ không được bảo vệ hoặc bảo vệ không đủ.", "Ăn quân bị bỏ hở"),
    ("trappedPiece", "Bẫy quân", "Quân đối phương hết đường thoát",
     "Quân bị kẹt không còn ô an toàn để đi. Hãy tấn công nó trước khi nó thoát.", "Bắt quân bị kẹt"),
    ("backRankMate", "Chiếu hết hàng cuối", "Vua bị chính tốt của mình chặn kín",
     "Vua bị tốt chặn ở hàng cuối là mục tiêu của Xe và Hậu. Đôi khi cần hy sinh để mở đường.", "Chiếu hết hàng cuối"),
    ("mateIn2", "Chiếu hết trong 2 nước", "Tính trước hai nước để chiếu hết",
     "Tìm nước đầu tiên khiến mọi phản ứng của đối thủ đều dẫn tới chiếu hết ở nước sau.", "Chiếu hết trong 2 nước"),
    ("mateIn3", "Chiếu hết trong 3 nước", "Tính sâu hơn để tìm chiếu hết",
     "Hãy liệt kê các nước chiếu và các nước ép buộc trước khi chọn nước đầu tiên.", "Chiếu hết trong 3 nước"),
    ("smotheredMate", "Chiếu hết ngạt", "Vua bị chính quân mình bao kín",
     "Mã chiếu hết vua bị quân mình vây kín. Thường cần hy sinh Hậu để kéo vua vào góc.", "Chiếu hết ngạt"),
    ("quietMove", "Nước đi yên lặng", "Không chiếu, không ăn quân nhưng không thể đỡ",
     "Một nước đi nhẹ nhàng tạo ra mối đe dọa mà đối thủ không thể chống đỡ hết.", "Tìm nước đi yên lặng"),
    ("xRayAttack", "Tấn công xuyên quân", "Quân tầm xa tác động qua quân khác",
     "Xe, Tượng và Hậu vẫn tạo áp lực lên ô phía sau một quân đang đứng chắn.", "Khai thác tấn công xuyên quân"),
    ("interference", "Chặn đường", "Cắt liên lạc giữa hai quân của đối thủ",
     "Đặt quân vào giữa hai quân đối thủ đang bảo vệ nhau để cắt đứt liên lạc.", "Tìm nước chặn đường"),
    ("clearance", "Dọn đường", "Nhường ô hoặc đường cho quân khác",
     "Di chuyển một quân (thường kèm đe dọa) để dọn đường cho quân đang chờ.", "Tìm nước dọn đường"),
    ("capturingDefender", "Ăn quân bảo vệ", "Loại bỏ quân đang bảo vệ mục tiêu",
     "Muốn ăn mục tiêu được bảo vệ, hãy ăn hoặc xua đuổi quân bảo vệ trước.", "Ăn quân đang bảo vệ"),
    ("intermezzo", "Nước xen giữa", "Chèn một đòn bất ngờ trước nước dự kiến",
     "Trước khi trả đòn theo thông thường, hãy tìm một nước chiếu hoặc đe dọa chen vào giữa.", "Tìm nước xen giữa"),
    ("advancedPawn", "Tốt tiến sâu", "Tốt gần hàng phong cấp rất nguy hiểm",
     "Tốt sắp phong cấp buộc đối thủ phải đối phó và mở ra nhiều đòn mạnh.", "Dùng tốt tiến sâu"),
    ("promotion", "Phong cấp", "Biến Tốt thành quân mạnh",
     "Đưa Tốt xuống hàng cuối (đôi khi bằng cách hy sinh) để có quân mới.", "Phong cấp thắng lợi"),
    ("exposedKing", "Vua bị hở", "Tấn công vua mất lớp bảo vệ",
     "Vua thiếu tốt che chắn rất dễ bị tấn công liên tục.", "Tấn công vua bị hở"),
    ("zugzwang", "Zugzwang", "Mọi nước đi đều làm thế cờ xấu đi",
     "Đôi khi lợi thế nhất là buộc đối thủ phải đi trong khi mọi nước đều có hại.", "Tìm thế zugzwang"),
    ("defensiveMove", "Nước phòng thủ", "Tìm nước duy nhất để cứu ván",
     "Khi bị tấn công, hãy tìm nước duy nhất để tránh thua hoặc giữ lợi thế.", "Tìm nước phòng thủ"),
    ("rookEndgame", "Tàn cuộc Xe", "Kỹ thuật tàn cuộc có Xe",
     "Xe tích cực hơn Xe thụ động. Hãy dùng vua và Xe phối hợp nhịp nhàng.", "Thắng tàn cuộc Xe"),
    ("pawnEndgame", "Tàn cuộc Tốt", "Đếm nước và đối vua",
     "Trong tàn cuộc Tốt từng nhịp đều quan trọng. Hãy đếm nước và để ý thế đối vua.", "Thắng tàn cuộc Tốt"),
]
ACCENTS = [0xFF81B64C, 0xFFE5A83B, 0xFF5B9BD5, 0xFFD9634C, 0xFF9C6BD6, 0xFF3FB8AF, 0xFFE06A9F, 0xFF8DA6B8]
LESSON_SLOTS = 12          # bài mỗi khóa (dễ → khó)
LESSON_RATING_LO = 700
LESSON_RATING_HI = 2300
LESSON_WINDOW = 80
LESSON_MAX_MOVES = 6       # moves[0] = đối thủ; tối đa 3 nước của người học
LESSON_MIN_POP = 90
LESSON_MIN_PLAYS = 200
LESSON_MAX_RD = 90


# ───────────────────────────────────────────────────────────── Tải & đọc dữ liệu

def download(url: str, dest: Path) -> None:
    print(f"⬇️  Tải {url}", flush=True)
    req = urllib.request.Request(url, headers={"User-Agent": "vila-chess-puzzle-builder"})
    with urllib.request.urlopen(req, timeout=60) as resp, open(dest, "wb") as f:
        shutil.copyfileobj(resp, f, length=1 << 20)
    print(f"✅ Đã tải {dest.stat().st_size / 1e6:.1f} MB", flush=True)


@contextmanager
def open_text(path: Path) -> Iterator[io.TextIOBase]:
    """Mở file CSV thường hoặc .zst thành luồng text (đọc streaming, không nạp cả file vào RAM)."""
    if path.suffix != ".zst":
        with open(path, "r", encoding="utf-8", newline="") as f:
            yield f
        return

    try:
        import zstandard  # type: ignore
    except ImportError:
        zstandard = None

    if zstandard is not None:
        with open(path, "rb") as raw:
            reader = zstandard.ZstdDecompressor().stream_reader(raw)
            yield io.TextIOWrapper(reader, encoding="utf-8", newline="")
        return

    if shutil.which("zstd") is None:
        sys.exit("❌ Cần `pip install zstandard` hoặc cài lệnh `zstd` để giải nén file .zst")
    proc = subprocess.Popen(["zstd", "-dc", str(path)], stdout=subprocess.PIPE)
    try:
        assert proc.stdout is not None
        yield io.TextIOWrapper(proc.stdout, encoding="utf-8", newline="")
    finally:
        if proc.stdout:
            proc.stdout.close()
        if proc.wait() != 0:
            sys.exit("❌ zstd giải nén thất bại")


def iter_rows(f: io.TextIOBase) -> Iterator[dict]:
    reader = csv.DictReader(f)
    missing = [c for c in REQUIRED if c not in (reader.fieldnames or [])]
    if missing:
        sys.exit(f"❌ File CSV thiếu cột: {', '.join(missing)} (có: {reader.fieldnames})")
    yield from reader


def to_int(value: str | None, default: int = 0) -> int:
    try:
        return int(value) if value not in (None, "") else default
    except ValueError:
        return default


# ───────────────────────────────────────────────────────────── Chọn câu đố

def weight_of(themes: list[str], popularity: int) -> float:
    w = 1.0
    for t in themes:
        if t in THEME_WEIGHT:
            w = min(w, THEME_WEIGHT[t])
    if w >= 1.0 and any(t in FREE_TACTIC_THEMES for t in themes):
        w = FREE_TACTIC_BONUS
    w *= max(0.3, popularity / 100.0)
    return max(w, 1e-3)


def bucket_of(rating: int, n_buckets: int) -> int:
    return min(max((rating - RATING_MIN) // BUCKET_W, 0), n_buckets - 1)


class LessonPicker:
    """Giữ MỘT bài tốt nhất cho mỗi (chủ đề, nấc độ khó) trong lúc đọc kho."""

    def __init__(self) -> None:
        self.themes = {c[0] for c in COURSE_THEMES}
        step = (LESSON_RATING_HI - LESSON_RATING_LO) / (LESSON_SLOTS - 1)
        self.targets = [round(LESSON_RATING_LO + i * step) for i in range(LESSON_SLOTS)]
        self.best: dict[tuple[str, int], tuple[tuple, tuple]] = {}

    def offer(self, pid: str, fen: str, moves: str, rating: int, themes: list[str], rd: int, pop: int, plays: int) -> None:
        if pop < LESSON_MIN_POP or plays < LESSON_MIN_PLAYS or rd > LESSON_MAX_RD:
            return
        n_moves = moves.count(" ") + 1
        if n_moves < 2 or n_moves > LESSON_MAX_MOVES:
            return
        hit = self.themes.intersection(themes)
        if not hit:
            return
        slot = min(range(LESSON_SLOTS), key=lambda i: abs(self.targets[i] - rating))
        if abs(self.targets[slot] - rating) > LESSON_WINDOW:
            return
        score = (pop, -abs(self.targets[slot] - rating), plays)
        for t in hit:
            cur = self.best.get((t, slot))
            if cur is None or score > cur[0]:
                self.best[(t, slot)] = (score, (pid, fen, moves, rating, " ".join(themes)))

    def courses(self) -> list[tuple[tuple, list[tuple]]]:
        used: set[str] = set()
        out = []
        for spec in COURSE_THEMES:
            items = []
            for slot in range(LESSON_SLOTS):
                cur = self.best.get((spec[0], slot))
                if cur is None or cur[1][0] in used:
                    continue
                items.append(cur[1])
            if len(items) < 4:
                print(f"⚠️  Chủ đề {spec[0]} chỉ có {len(items)} bài ⇒ bỏ khóa này", flush=True)
                continue
            used.update(i[0] for i in items)
            items.sort(key=lambda r: r[3])
            out.append((spec, items))
        return out


def select(rows: Iterator[dict], count: int, seed: int) -> tuple[list[tuple], LessonPicker, int]:
    """Một lượt đọc: chọn `count` câu phân bố đều theo rating + gom bài học. Trả về (câu đố, picker, tổng hợp lệ)."""
    rnd = random.Random(seed)
    n_buckets = (RATING_MAX - RATING_MIN) // BUCKET_W + 1
    cap = max(200, int(count / n_buckets * 2.2))          # dư để còn chia lại phần thiếu
    heaps: list[list] = [[] for _ in range(n_buckets)]
    picker = LessonPicker()
    total = 0
    seq = 0
    for r in rows:
        pid, fen, moves, rt = r["PuzzleId"], r["FEN"], r["Moves"], r["Rating"]
        if not pid or not fen or not moves or not rt:
            continue
        rating = to_int(rt)
        pop = to_int(r.get("Popularity"))
        plays = to_int(r.get("NbPlays"))
        rd = to_int(r.get("RatingDeviation"))
        if moves.count(" ") < 1:
            continue
        total += 1
        themes = (r.get("Themes") or "").split()
        picker.offer(pid, fen, moves, rating, themes, rd, pop, plays)
        if pop < MIN_POPULARITY or plays < MIN_PLAYS or rd > MAX_RD:
            continue
        w = weight_of(themes, pop)
        key = rnd.random() ** (1.0 / w)                    # lấy mẫu có trọng số (Efraimidis–Spirakis)
        h = heaps[bucket_of(rating, n_buckets)]
        seq += 1
        item = (key, seq, (rating, pid, fen, moves, " ".join(themes)))
        if len(h) < cap:
            heapq.heappush(h, item)
        elif key > h[0][0]:
            heapq.heapreplace(h, item)

    sizes = [len(h) for h in heaps]
    if sum(sizes) < count:
        sys.exit(f"❌ Sau khi lọc chỉ còn {sum(sizes):,} câu đố, không đủ {count:,} (hạ --count hoặc nới bộ lọc)")
    # "Đổ nước": tìm mức L sao cho tổng min(size, L) >= count, rồi lấy L câu tốt nhất mỗi khoảng.
    lo, hi = 1, max(sizes)
    while lo < hi:
        mid = (lo + hi) // 2
        if sum(min(s, mid) for s in sizes) >= count:
            hi = mid
        else:
            lo = mid + 1
    level = lo
    picked: list[tuple] = []
    for h in heaps:
        best = heapq.nlargest(level, h)
        picked.extend(x[2] for x in best)
    picked.sort(key=lambda x: x[0], reverse=False)        # tạm; xếp lại cho ổn định bên dưới
    # Có thể dư vài câu do làm tròn: bỏ bớt ở các khoảng đông nhất theo key thấp nhất.
    if len(picked) > count:
        extra = len(picked) - count
        drop = set(random.Random(seed + 1).sample(range(len(picked)), extra))
        picked = [p for i, p in enumerate(picked) if i not in drop]
    print(f"📊 Đọc {total:,} câu hợp lệ → giữ {len(picked):,} câu (tối đa {level:,} câu / khoảng {BUCKET_W} rating)", flush=True)
    return picked, picker, total


def stable_order(rows: list[tuple], seed: int) -> list[tuple]:
    """Rating tăng dần; cùng Rating thì xáo trộn ổn định (crc32) để các chủ đề xen kẽ nhau."""
    return sorted(rows, key=lambda x: (x[0], zlib.crc32(f"{seed}:{x[1]}".encode()), x[1]))


# ───────────────────────────────────────────────────────────── Ghi SQLite

def write_db(rows: list[tuple], out: Path) -> None:
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        out.unlink()
    con = sqlite3.connect(out)
    try:
        con.executescript(SCHEMA)
        con.executemany(
            "INSERT INTO puzzles (id, puzzle_id, fen, moves, rating, themes) VALUES (?,?,?,?,?,?)",
            ((n, pid, fen, moves, rating, themes) for n, (rating, pid, fen, moves, themes) in enumerate(rows, start=1)),
        )
        con.commit()
        verify(con, len(rows))
        con.execute("VACUUM")
    finally:
        con.close()
    print(f"💾 {out} — {out.stat().st_size / 1e6:.1f} MB", flush=True)


def verify(con: sqlite3.Connection, expected: int) -> None:
    n, lo, hi = con.execute("SELECT COUNT(*), MIN(id), MAX(id) FROM puzzles").fetchone()
    if (n, lo, hi) != (expected, 1, expected):
        sys.exit(f"❌ id không liên tục: count={n} min={lo} max={hi}, cần 1…{expected}")
    bad = con.execute(
        "SELECT COUNT(*) FROM puzzles a JOIN puzzles b ON b.id = a.id + 1 WHERE b.rating < a.rating"
    ).fetchone()[0]
    if bad:
        sys.exit(f"❌ Có {bad} chỗ Rating giảm khi id tăng")
    r1, rn = con.execute(
        "SELECT (SELECT rating FROM puzzles WHERE id = 1), (SELECT rating FROM puzzles WHERE id = ?)", (expected,)
    ).fetchone()
    print(f"✅ id 1…{expected} liên tục · Rating tăng dần: level 1 = {r1}, level {expected} = {rn}", flush=True)


def report(rows: list[tuple]) -> None:
    """In thống kê đa dạng để thấy ngay nếu bộ câu đố lại bị lệch về chiếu hết."""
    n = len(rows)
    c = Counter()
    for _, _, _, moves, themes in rows:
        ts = set(themes.split())
        if "mateIn1" in ts:
            c["mateIn1"] += 1
        elif "mate" in ts:
            c["mate khác"] += 1
        else:
            c["KHÔNG phải chiếu hết (chiến thuật tự do)"] += 1
    for k, v in c.most_common():
        print(f"   • {k}: {v:,} ({v * 100 / n:.1f}%)", flush=True)
    for a in range(0, n, max(1, n // 5)):
        seg = rows[a:a + max(1, n // 5)]
        free = sum(1 for r in seg if "mate" not in r[4].split())
        print(f"   level {a + 1:>7,}–{a + len(seg):>7,}: rating {seg[0][0]}–{seg[-1][0]} · không-chiếu-hết {free * 100 // len(seg)}%", flush=True)
    if c["mateIn1"] * 100 / n > 25:
        print("⚠️  mateIn1 vẫn chiếm >25% — kiểm tra lại dữ liệu đầu vào", flush=True)


# ───────────────────────────────────────────────────────────── Ghi LessonLichessData.kt

def kt(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$")


def level_label(items: list[tuple]) -> str:
    mid = items[len(items) // 2][3]
    return "Người mới" if mid < 1100 else "Trung cấp" if mid < 1600 else "Nâng cao"


def write_lessons(courses: list[tuple[tuple, list[tuple]]], out: Path) -> None:
    lines = [
        "package com.vila.chess.game",
        "",
        "// ════════════════════════════════════════════════════════════════════════════════════════════",
        "//  TỰ SINH bởi scripts/generate_puzzles.py từ kho câu đố Lichess (CC0). KHÔNG sửa tay – chạy lại script.",
        "//  Mỗi khóa = 1 chủ đề chiến thuật, ~12 bài xếp DỄ → KHÓ. LessonCatalog nối các khóa này sau các khóa tự viết.",
        "//  LessonCatalogTest kiểm: id duy nhất, FEN hợp lệ, MỌI lời giải chạy được qua PuzzleSession.",
        "// ════════════════════════════════════════════════════════════════════════════════════════════",
        "object LessonLichessData {",
        "",
        "    private fun t(",
        "        id: String, title: String, idea: String, goal: String, fen: String, moves: String, themes: String,",
        "    ) = Lesson(",
        "        id, title, idea, goal, LessonKind.TACTIC, fen,",
        "        moves = moves.split(' '), themes = themes.split(' '), minutes = 2,",
        "    )",
        "",
        "    val courses: List<Course> = listOf(",
    ]
    for ci, (spec, items) in enumerate(courses):
        theme, name, sub, idea, goal = spec
        lines += [
            "        Course(",
            f'            id = "lc_{theme}",',
            f'            title = "{kt(name)}",',
            f'            subtitle = "{kt(sub)}",',
            f'            level = "{level_label(items)}",',
            f"            accent = 0x{ACCENTS[ci % len(ACCENTS)]:X},",
            "            premium = false,",
            "            lessons = listOf(",
        ]
        for i, (pid, fen, moves, rating, themes) in enumerate(items, start=1):
            lines.append(
                f'                t("lc_{theme}_{i:02d}", "{kt(name)} {i} · {rating}", "{kt(idea)}", "{kt(goal)}", '
                f'"{kt(fen)}", "{kt(moves)}", "{kt(themes)}"),'
            )
        lines += ["            ),", "        ),"]
    lines += ["    )", "}", ""]
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines), encoding="utf-8")
    n = sum(len(i) for _, i in courses)
    print(f"📚 {out.name}: {len(courses)} khóa · {n} bài chiến thuật (dễ → khó)", flush=True)


# ───────────────────────────────────────────────────────────── main

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--input", type=Path, help="file .csv / .csv.zst có sẵn (bỏ qua bước tải)")
    ap.add_argument("--url", default=LICHESS_URL)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--lessons-out", type=Path, default=DEFAULT_LESSONS)
    ap.add_argument("--no-lessons", action="store_true", help="không ghi LessonLichessData.kt")
    ap.add_argument("--count", type=int, default=DEFAULT_COUNT)
    ap.add_argument("--seed", type=int, default=20261110)
    args = ap.parse_args()

    if args.input:
        src, tmp = args.input, None
    else:
        tmp = tempfile.TemporaryDirectory()
        src = Path(tmp.name) / "lichess_db_puzzle.csv.zst"
        download(args.url, src)

    try:
        with open_text(src) as f:
            picked, picker, _ = select(iter_rows(f), args.count, args.seed)
    finally:
        if tmp:
            tmp.cleanup()

    rows = stable_order(picked, args.seed)
    report(rows)
    write_db(rows, args.out)
    if not args.no_lessons:
        courses = picker.courses()
        if courses:
            write_lessons(courses, args.lessons_out)
        else:
            print("⚠️  Không đủ bài học ⇒ giữ nguyên LessonLichessData.kt cũ", flush=True)


if __name__ == "__main__":
    main()
