#!/usr/bin/env python3
"""
Tổng hợp các BỘ ÂM THANH cho ViLa Chess (không cần file ngoài, không bản quyền): 6 bộ x 6 tiếng.
Ghi vào app/src/main/res/raw/<bộ>_<tiếng>.wav  (22,05 kHz, 16-bit, mono). Bộ "classic" là 6 file move/capture/... có sẵn.

  python3 scripts/gen_sounds.py

Tiếng: move (đi quân) · capture (ăn quân) · castle (nhập thành) · check (chiếu) · promote (phong cấp) · end (hết ván)
Bộ:    wood (Gỗ) · glass (Pha lê) · arcade (Arcade 8-bit) · piano (Piano mềm) · drum (Trống) · water (Giọt nước)
Cần numpy. Kết quả ổn định (seed cố định) nên chạy lại không làm đổi file.
"""
from pathlib import Path
import wave
import numpy as np

SR = 22050
OUT = Path(__file__).resolve().parent.parent / "app" / "src" / "main" / "res" / "raw"
RNG = np.random.default_rng(20261110)


# ───────────────────────────────────────────── công cụ
def t_(dur): return np.arange(int(SR * dur)) / SR
def dec(t, tau): return np.exp(-t / tau)

def fade(x, ms=4.0):
    n = min(int(SR * ms / 1000), len(x) // 2)
    if n > 0:
        x = x.copy(); r = np.linspace(0, 1, n)
        x[:n] *= r; x[-n:] *= r[::-1]
    return x

def lp(x, fc, taps=129):
    n = np.arange(taps) - (taps - 1) / 2
    h = np.sinc(2 * fc / SR * n) * np.hamming(taps)
    return np.convolve(x, h / h.sum(), mode="same")

def hp(x, fc): return x - lp(x, fc)

def noise(dur): return RNG.standard_normal(int(SR * dur))

def place(total, parts):
    out = np.zeros(int(SR * total))
    for start, sig, gain in parts:
        i = int(SR * start); j = min(len(out), i + len(sig))
        if j > i: out[i:j] += sig[: j - i] * gain
    return out

def echo(x, delay=0.11, fb=0.35, n=3):
    out = np.concatenate([x, np.zeros(int(SR * delay * n))])
    for k in range(1, n + 1):
        d = int(SR * delay * k)
        out[d:d + len(x)] += x * (fb ** k)
    return out

def save(name, x, peak=0.85):
    x = np.nan_to_num(x)
    m = np.max(np.abs(x)) or 1.0
    y = fade(x / m * peak, 3)
    pcm = (np.clip(y, -1, 1) * 32767).astype("<i2")
    with wave.open(str(OUT / f"{name}.wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

def sine(f, dur, tau, partials=((1, 1.0),)):
    t = t_(dur)
    s = sum(a * np.sin(2 * np.pi * f * k * t) for k, a in partials)
    return s * dec(t, tau)

def square(f, dur, duty=0.5, slide=0.0):
    t = t_(dur)
    ph = np.cumsum(2 * np.pi * (f + slide * t / max(dur, 1e-6)) / SR)
    s = np.where((ph / (2 * np.pi)) % 1.0 < duty, 1.0, -1.0)
    return s * np.minimum(1.0, (dur - t) / 0.01) * 0.7

def chirp(f0, f1, dur, tau):
    t = t_(dur)
    f = f0 + (f1 - f0) * (t / dur)
    return np.sin(np.cumsum(2 * np.pi * f / SR)) * dec(t, tau)


# ───────────────────────────────────────────── bộ GỖ
def thock(f0=200, bright=2600, dur=0.14):
    t = t_(dur)
    body = np.sin(2 * np.pi * (f0 + 60 * dec(t, 0.02)) * t) * dec(t, 0.035)
    mode = 0.5 * np.sin(2 * np.pi * f0 * 2.6 * t) * dec(t, 0.022)
    click = lp(noise(dur), bright) * dec(t, 0.006) * 1.6
    return body + mode + click

def pack_wood():
    return {
        "move": thock(210),
        "capture": place(0.22, [(0, thock(150), 1.0), (0.025, thock(260, 3200), 0.9), (0.0, lp(noise(0.2), 1800) * dec(t_(0.2), 0.05), 0.5)]),
        "castle": place(0.3, [(0, thock(230), 0.9), (0.12, thock(190), 1.0)]),
        "check": place(0.3, [(0, thock(420, 4200), 1.0), (0.1, thock(520, 4200), 1.0)]),
        "promote": place(0.55, [(i * 0.1, sine(f, 0.4, 0.11, ((1, 1), (4, 0.35))), 1.0) for i, f in enumerate((440, 554, 659, 880))]),
        "end": place(0.9, [(0, thock(170), 1.0), (0.18, thock(150), 0.9), (0.36, thock(120), 1.0), (0.36, sine(110, 0.5, 0.2, ((1, 1), (2, 0.4))), 0.6)]),
    }


# ───────────────────────────────────────────── bộ PHA LÊ
def bell(f, dur=0.5, tau=0.12):
    t = t_(dur)
    parts = ((1, 1.0, 1.0), (2.76, 0.5, 0.6), (5.4, 0.25, 0.35), (8.93, 0.12, 0.2))
    return sum(a * np.sin(2 * np.pi * f * k * t) * dec(t, tau * d) for k, a, d in parts)

def pack_glass():
    return {
        "move": bell(1320, 0.3, 0.05),
        "capture": place(0.4, [(0, bell(880, 0.35, 0.07), 1.0), (0.0, bell(1760, 0.3, 0.04), 0.6)]),
        "castle": place(0.4, [(0, bell(1046, 0.3, 0.06), 0.9), (0.1, bell(1318, 0.3, 0.06), 1.0)]),
        "check": place(0.45, [(0, bell(1568, 0.25, 0.05), 1.0), (0.12, bell(1568, 0.3, 0.06), 1.0), (0.12, bell(2093, 0.3, 0.04), 0.5)]),
        "promote": place(0.8, [(i * 0.1, bell(f, 0.5, 0.1), 1.0) for i, f in enumerate((1046, 1318, 1568, 2093))]),
        "end": echo(place(0.9, [(0, bell(880, 0.8, 0.2), 1.0), (0.16, bell(659, 0.8, 0.2), 1.0), (0.32, bell(523, 1.0, 0.28), 1.1)]), 0.13, 0.3, 3),
    }


# ───────────────────────────────────────────── bộ ARCADE 8-bit
def pack_arcade():
    return {
        "move": square(880, 0.045, 0.25, -260),
        "capture": place(0.2, [(0, square(220, 0.14, 0.5, -120), 0.9), (0, lp(noise(0.12), 3500) * dec(t_(0.12), 0.03), 0.9)]),
        "castle": place(0.2, [(0, square(660, 0.05, 0.25), 1.0), (0.07, square(990, 0.06, 0.25), 1.0)]),
        "check": place(0.3, [(i * 0.06, square(f, 0.05, 0.5), 1.0) for i, f in enumerate((988, 784, 988, 784))]),
        "promote": place(0.4, [(i * 0.06, square(f, 0.06, 0.25), 1.0) for i, f in enumerate((523, 659, 784, 1047, 1319))]),
        "end": place(0.7, [(i * 0.13, square(f, 0.12, 0.5, -20), 1.0) for i, f in enumerate((784, 659, 523, 392))]),
    }


# ───────────────────────────────────────────── bộ PIANO MỀM
def pluck(f, dur=0.4, tau=0.16):
    t = t_(dur)
    s = np.sin(2 * np.pi * f * t) + 0.4 * np.sin(2 * np.pi * 2 * f * t) + 0.2 * np.sin(2 * np.pi * 3 * f * t)
    atk = np.minimum(1.0, t / 0.006)
    return s * atk * dec(t, tau) + lp(noise(dur), 1500) * dec(t, 0.01) * 0.25

def pack_piano():
    return {
        "move": pluck(523, 0.22, 0.07),
        "capture": place(0.4, [(0, pluck(392, 0.3, 0.09), 1.0), (0, pluck(196, 0.3, 0.11), 0.9)]),
        "castle": place(0.4, [(0, pluck(392, 0.3, 0.08), 0.9), (0.1, pluck(523, 0.3, 0.09), 1.0)]),
        "check": place(0.4, [(0, pluck(784, 0.2, 0.06), 1.0), (0.1, pluck(784, 0.25, 0.07), 1.0), (0.1, pluck(988, 0.25, 0.07), 0.6)]),
        "promote": place(0.8, [(i * 0.1, pluck(f, 0.5, 0.14), 1.0) for i, f in enumerate((523, 659, 784, 1047))]),
        "end": echo(place(1.0, [(0, pluck(262, 1.0, 0.3), 1.0), (0, pluck(330, 1.0, 0.3), 0.8), (0, pluck(392, 1.0, 0.3), 0.8)]), 0.15, 0.25, 2),
    }


# ───────────────────────────────────────────── bộ TRỐNG
def kick(f0=130, f1=45, dur=0.16):
    t = t_(dur)
    return np.sin(np.cumsum(2 * np.pi * (f1 + (f0 - f1) * dec(t, 0.03)) / SR)) * dec(t, 0.06)

def snare(dur=0.12):
    t = t_(dur)
    return hp(noise(dur), 1500) * dec(t, 0.035) + 0.6 * np.sin(2 * np.pi * 190 * t) * dec(t, 0.03)

def rim(dur=0.05):
    t = t_(dur)
    return np.sin(2 * np.pi * 950 * t) * dec(t, 0.008) + hp(noise(dur), 2500) * dec(t, 0.006) * 0.7

def tom(f, dur=0.12):
    t = t_(dur)
    return np.sin(np.cumsum(2 * np.pi * (f * 0.7 + f * 0.3 * dec(t, 0.04)) / SR)) * dec(t, 0.06)

def pack_drum():
    return {
        "move": rim(),
        "capture": place(0.22, [(0, kick(), 1.0), (0.0, snare(), 0.8)]),
        "castle": place(0.2, [(0, rim(), 0.9), (0.08, rim(), 1.0)]),
        "check": place(0.3, [(0, snare(0.08), 0.7), (0.07, snare(0.08), 0.85), (0.14, snare(0.1), 1.0)]),
        "promote": place(0.45, [(i * 0.08, tom(f), 1.0) for i, f in enumerate((110, 150, 200, 270))]),
        "end": place(0.8, [(0, kick(), 1.0), (0.0, hp(noise(0.7), 4500) * dec(t_(0.7), 0.18), 0.5)]),
    }


# ───────────────────────────────────────────── bộ GIỌT NƯỚC
def bloop(f0, dur=0.12, rise=1.8):
    return chirp(f0, f0 * rise, dur, dur * 0.55) * np.minimum(1.0, t_(dur) / 0.004)

def splash(dur=0.18):
    t = t_(dur)
    return lp(hp(noise(dur), 900), 4500) * dec(t, 0.05)

def pack_water():
    return {
        "move": bloop(520, 0.09),
        "capture": place(0.3, [(0, bloop(300, 0.14), 1.0), (0.0, splash(), 0.7)]),
        "castle": place(0.25, [(0, bloop(480, 0.08), 0.9), (0.09, bloop(620, 0.08), 1.0)]),
        "check": place(0.3, [(i * 0.07, bloop(f, 0.07, 1.5), 1.0) for i, f in enumerate((700, 850, 1000))]),
        "promote": place(0.55, [(i * 0.09, bloop(f, 0.1), 1.0) for i, f in enumerate((400, 500, 650, 800))]),
        "end": echo(place(0.7, [(0, bloop(600, 0.2, 0.6), 1.0), (0.2, bloop(450, 0.25, 0.6), 1.0), (0.45, bloop(330, 0.3, 0.6), 1.0)]), 0.12, 0.3, 3),
    }


PACKS = {"wood": pack_wood, "glass": pack_glass, "arcade": pack_arcade, "piano": pack_piano, "drum": pack_drum, "water": pack_water}

if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    total = 0
    for pack, fn in PACKS.items():
        for sfx, sig in fn().items():
            save(f"{pack}_{sfx}", sig)
            total += 1
    print(f"✅ {total} file trong {OUT}")
