package com.vila.chess

import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.findMoveBySan
import com.vila.chess.core.moveUci
import com.vila.chess.review.EngineResult
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import com.vila.chess.review.MoveClassifier
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewReplay
import com.vila.chess.review.SacrificeDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MoveClassifierTest {

    private fun cls(
        before: Double = 0.5, after: Double = 0.5, played: String = "a2a3", best: String? = "e2e4",
        second: String? = null, epSecond: Double? = null, sac: Boolean = false, opp: Boolean = false,
        recapture: Boolean = false, book: Boolean = false, floor: Double = 0.0, mate: Int? = null,
    ) = MoveClassifier.classifyMove(
        epBefore = before, epAfter = after, movePlayed = played, bestMove = best, secondBestMove = second,
        isSacrifice = sac, isOpponentJustBlundered = opp, epSecondBest = epSecond,
        isRecapture = recapture, inBook = book, lossFloor = floor, mateAfter = mate,
    )

    // ---- win probability ----

    @Test
    fun winProbabilityFormulaAndPerspective() {
        assertEquals(0.5, MoveClassifier.calculateWinProbability(0, null, true), 1e-9)
        val white300 = 0.5 + 0.5 * (2.0 / (1.0 + Math.exp(-0.00368208 * 300)) - 1.0)
        assertEquals(white300, MoveClassifier.calculateWinProbability(300, null, true), 1e-9)
        // lượt Đen: Trắng hơn 300 => Đen chỉ còn 1 - WP_White
        assertEquals(1.0 - white300, MoveClassifier.calculateWinProbability(300, null, false), 1e-9)
        assertEquals(white300, MoveClassifier.calculateWinProbability(-300, null, false), 1e-9)
        // mate (góc nhìn Trắng)
        assertEquals(1.0, MoveClassifier.calculateWinProbability(0, 3, true), 0.0)
        assertEquals(0.0, MoveClassifier.calculateWinProbability(0, -2, true), 0.0)
        assertEquals(0.0, MoveClassifier.calculateWinProbability(0, 3, false), 0.0)
        assertEquals(1.0, MoveClassifier.calculateWinProbability(0, -2, false), 0.0)
        // đã bị chiếu hết: bên thắng suy từ dấu cp
        assertEquals(0.0, MoveClassifier.calculateWinProbability(-10_000, 0, true), 0.0)
        assertEquals(1.0, MoveClassifier.calculateWinProbability(-10_000, 0, false), 0.0)
    }

    // ---- loss ----

    @Test
    fun lossThresholds() {
        assertEquals(MoveLabel.EXCELLENT, MoveClassifier.labelByLoss(0.02))
        assertEquals(MoveLabel.GOOD, MoveClassifier.labelByLoss(0.0201))
        assertEquals(MoveLabel.GOOD, MoveClassifier.labelByLoss(0.05))
        assertEquals(MoveLabel.INACCURACY, MoveClassifier.labelByLoss(0.0501))
        assertEquals(MoveLabel.INACCURACY, MoveClassifier.labelByLoss(0.10))
        assertEquals(MoveLabel.MISTAKE, MoveClassifier.labelByLoss(0.1001))
        assertEquals(MoveLabel.MISTAKE, MoveClassifier.labelByLoss(0.20))
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(0.2001))
        assertEquals(MoveLabel.MISTAKE, cls(before = 0.60, after = 0.45))
        assertEquals(MoveLabel.EXCELLENT, cls(before = 0.50, after = 0.60))   // thế tốt lên: loss = 0
    }

    @Test
    fun deadPositionsHalveThePenalty() {
        // đã thua chắc: 3% -> 0% chỉ còn 1.5% => Excellent
        assertEquals(MoveLabel.EXCELLENT, cls(before = 0.03, after = 0.0))
        // đang thắng chắc: mất 26% chỉ bị tính 13% => Mistake (thế thường là Blunder)
        assertEquals(MoveLabel.MISTAKE, cls(before = 0.96, after = 0.70))
        assertEquals(MoveLabel.BLUNDER, cls(before = 0.80, after = 0.54))
        // vẫn Blunder nếu sụp thật sự
        assertEquals(MoveLabel.BLUNDER, cls(before = 0.97, after = 0.50))
    }

    @Test
    fun bookBeatsEverything() {
        assertEquals(MoveLabel.BOOK, cls(before = 0.9, after = 0.1, book = true))
    }

    @Test
    fun bestAndGreat() {
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.6, after = 0.6))
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.6, after = 0.6, second = "d2d4", epSecond = 0.55))
        assertEquals(MoveLabel.GREAT, cls(played = "e2e4", before = 0.6, after = 0.6, second = "d2d4", epSecond = 0.40))
        // ăn lại quân hiển nhiên không phải Great
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.6, after = 0.6, second = "d2d4", epSecond = 0.1, recapture = true))
        // thế đã thua nặng thì không Great
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.2, after = 0.2, second = "d2d4", epSecond = 0.0))
        // nước tốt nhì ngang điểm vẫn là Best
        assertEquals(MoveLabel.BEST, cls(played = "d2d4", before = 0.6, after = 0.6, second = "d2d4", epSecond = 0.599))
        // không phải nước tốt nhất thì không bao giờ Great
        assertEquals(MoveLabel.EXCELLENT, cls(played = "a2a3", before = 0.6, after = 0.59, second = "d2d4", epSecond = 0.1))
    }

    @Test
    fun brilliantNeedsSacrificeAndSafeContext() {
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 0.55, after = 0.55))
        // đã thắng đậm sẵn (không biết nước thay thế), chưa áp đảo (< 95%), không chiếu hết -> không Brilliant
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.92, after = 0.92))
        // hy sinh xong thế xấu -> không Brilliant
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.30, after = 0.30))
        // không hy sinh -> không Brilliant
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = false, before = 0.55, after = 0.55))
        // không phải nước tốt nhất -> không Brilliant
        assertEquals(MoveLabel.GOOD, cls(played = "a2a3", sac = true, before = 0.5, after = 0.47))
    }

    @Test
    fun brilliantUsesAlternativeNotBestWin() {
        // thắng cưỡng bức (100%) nhưng nước tốt nhì chỉ 60% => "không thắng đậm nếu không tìm ra nước này" => Brilliant
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 1.0, after = 1.0, second = "d2d4", epSecond = 0.60))
        // nước tốt nhì cũng thắng đậm (92%), thế sau chưa áp đảo (< 95%), không chiếu hết -> chỉ là Best
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.93, after = 0.93, second = "d2d4", epSecond = 0.92))
        // không biết nước thay thế, chưa áp đảo -> thận trọng: Best
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.93, after = 0.93))
    }

    @Test
    fun brilliantAllowedForMatingSacrificeRegardlessOfEpBefore() {
        // hy sinh dẫn tới chiếu hết cưỡng bức: Brilliant dù đã thắng sẵn và nước tốt nhì cũng thắng đậm
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 1.0, after = 1.0, second = "d2d4", epSecond = 0.99, mate = 3))
        // vừa chiếu hết luôn (mate = 0) cũng tính
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 1.0, after = 1.0, mate = 0))
        // chiếu hết mà không hy sinh quân -> chỉ là Best
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = false, before = 1.0, after = 1.0, second = "d2d4", epSecond = 0.99, mate = 3))
        // mate ÂM (mình bị chiếu hết) hoặc không có mate -> không được nhánh chiếu hết (chỉ kiểm tra dấu của mate)
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.93, after = 0.93, second = "d2d4", epSecond = 0.92, mate = -3))
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.93, after = 0.93, second = "d2d4", epSecond = 0.92, mate = null))
        // không phải nước tốt nhất (chiếu hết chậm hơn) -> không Brilliant
        assertEquals(MoveLabel.EXCELLENT, cls(played = "a2a3", sac = true, before = 1.0, after = 1.0, mate = 5))
    }

    @Test
    fun leadsToMateCountsOnlyMatesInFavourOfTheMover() {
        assertTrue(MoveClassifier.leadsToMate(0))
        assertTrue(MoveClassifier.leadsToMate(4))
        assertFalse(MoveClassifier.leadsToMate(-1))
        assertFalse(MoveClassifier.leadsToMate(null))
    }

    @Test
    fun brilliantAllowedForOverwhelmingSacrificeRegardlessOfEpBefore() {
        // hy sinh xong thế áp đảo (≥ 95%): Brilliant bất kể epBefore / nước thay thế
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 0.96, after = 0.96))
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 0.97, after = 0.97, second = "d2d4", epSecond = 0.96))
        // chưa áp đảo (< 95%) mà nước thay thế cũng thắng đậm -> không Brilliant
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.94, after = 0.94, second = "d2d4", epSecond = 0.93))
        // áp đảo nhưng không hy sinh quân -> không Brilliant
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = false, before = 0.97, after = 0.97))
        // hy sinh xong thế vẫn xấu -> không Brilliant dù epBefore cao (nước tốt nhất nhưng đo lệch)
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", sac = true, before = 0.97, after = 0.30))
    }

    @Test
    fun missAfterOpponentError() {
        // bỏ lỡ cơ hội: mất 12% (> 10%) sau lỗi của đối thủ, thế vẫn chưa xấu => Miss
        assertEquals(MoveLabel.MISS, cls(before = 0.75, after = 0.63, opp = true))
        // đối thủ không sai -> theo loss
        assertEquals(MoveLabel.MISTAKE, cls(before = 0.75, after = 0.63, opp = false))
        // sụp thành thế thua -> Blunder, không phải Miss
        assertEquals(MoveLabel.BLUNDER, cls(before = 0.90, after = 0.30, opp = true))
        // mất ít (≤ 5%) -> không Miss
        assertEquals(MoveLabel.GOOD, cls(before = 0.75, after = 0.72, opp = true))
        // nước tốt nhất luôn là Best dù đối thủ vừa sai (epAfter không tăng vì đã là mức tối đa)
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.75, after = 0.75, opp = true))
    }

    @Test
    fun missNeedsMoreThanTenPercentLoss() {
        // 5%–10%: trước đây là Miss, nay chỉ là Inaccuracy
        assertEquals(MoveLabel.INACCURACY, cls(before = 0.80, after = 0.71, opp = true))   // mất 9%
        assertEquals(MoveLabel.INACCURACY, cls(before = 0.75, after = 0.68, opp = true))   // mất 7%
        // > 10% => Miss
        assertEquals(MoveLabel.MISS, cls(before = 0.80, after = 0.69, opp = true))          // mất 11%
        // đối thủ không sai thì vẫn theo loss thuần
        assertEquals(MoveLabel.MISTAKE, cls(before = 0.80, after = 0.69, opp = false))
    }

    @Test
    fun bestMoveAfterOpponentBlunderPunishesAndIsNeverMiss() {
        // đi đúng nước tốt nhất sau lỗi của đối thủ => đã trừng phạt: Best hoặc Great, KHÔNG BAO GIỜ Miss
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.80, after = 0.80, opp = true))
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.80, after = 0.80, second = "d2d4", epSecond = 0.75, opp = true))
        assertEquals(MoveLabel.GREAT, cls(played = "e2e4", before = 0.80, after = 0.80, second = "d2d4", epSecond = 0.50, opp = true))
        // nước tốt nhì ngang điểm với nước tốt nhất cũng là Best, không phải Miss
        assertEquals(MoveLabel.BEST, cls(played = "d2d4", before = 0.80, after = 0.80, second = "d2d4", epSecond = 0.799, opp = true))
        // kể cả khi số đo sau nước đi tụt (nhiễu độ sâu): nước tốt nhất vẫn không bị Miss
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.80, after = 0.60, opp = true))
        // trừng phạt bằng cú hy sinh dẫn tới chiếu hết => Brilliant (vẫn không phải Miss)
        assertEquals(MoveLabel.BRILLIANT, cls(played = "e2e4", sac = true, before = 0.99, after = 1.0, mate = 2, opp = true))
    }

    @Test
    fun mateFloorOnlyAffectsNonBestMoves() {
        assertEquals(MoveLabel.BLUNDER, cls(before = 0.3, after = 0.2, floor = MoveClassifier.FLOOR_BLUNDER))
        assertEquals(MoveLabel.BEST, cls(played = "e2e4", before = 0.3, after = 0.2, floor = MoveClassifier.FLOOR_BLUNDER))
    }

    // ---- accuracy ----

    @Test
    fun accuracyFormula() {
        assertEquals(100.0, MoveClassifier.calculateAccuracy(0.0), 1e-3)
        assertEquals(100.0, MoveClassifier.calculateAccuracy(-0.2), 1e-3)
        assertEquals(24.7756, MoveClassifier.calculateAccuracy(0.30), 1e-3)   // 103.1668*exp(-0.04354*30) - 3.1669
        assertEquals(0.0, MoveClassifier.calculateAccuracy(1.0), 0.0)         // clamp 0
    }

    @Test
    fun gameAccuracyIsArithmeticMean() {
        assertEquals(100.0, MoveClassifier.calculateGameAccuracy(emptyList()), 0.0)
        val losses = listOf(0.0, 0.0, 0.30, 0.05)
        val expected = losses.map { MoveClassifier.calculateAccuracy(it) }.average()
        assertEquals(expected, MoveClassifier.calculateGameAccuracy(losses), 1e-9)
    }

    // ------------------------------------------------------------ hy sinh quân

    @Test
    fun queenForPawnIsSacrifice() {
        // Hậu ăn tốt d5 bị tốt c6 ăn lại: cho đi 800.
        val fen = "4k3/8/2p5/3p4/8/8/3Q4/4K3 w - - 0 1"
        assertTrue(SacrificeDetector.isSacrifice(fen, "d2d5"))
        assertFalse(SacrificeDetector.isSacrifice(fen, "d2d3"))
    }

    @Test
    fun freeCaptureAndAbandonedHangingPieceAreNotSacrifices() {
        // Ăn tốt không ai bảo vệ: không phải hy sinh.
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/8/3p4/8/8/3Q4/4K3 w - - 0 1", "d2d5"))
        // Hậu đang bị tốt e5 treo từ trước; đi vua chỗ khác không bị tính là "hy sinh hậu".
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/8/4p3/3Q4/8/8/4K3 w - - 0 1", "e1f1"))
        // Đổi xe lấy mã (mất 180 < 200): đổi chất, không phải hy sinh.
        assertFalse(SacrificeDetector.isSacrifice("4k3/8/2p5/3n4/8/8/3R4/4K3 w - - 0 1", "d2d5"))
        // Xe ăn tốt bị bảo vệ (mất 400): là hy sinh.
        assertTrue(SacrificeDetector.isSacrifice("4k3/8/2p5/3p4/8/8/3R4/4K3 w - - 0 1", "d2d5"))
    }

    // ------------------------------------------------------------ SAN + khai cuộc

    @Test
    fun sanParser() {
        val p = Position.start()
        assertEquals("e2e4", moveUci(findMoveBySan(p, "e4")!!))
        assertEquals("g1f3", moveUci(findMoveBySan(p, "Nf3")!!))
        assertNull(findMoveBySan(p, "Nf6"))
        assertNull(findMoveBySan(p, "e5"))
        val castle = Position.fromFen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        assertEquals("e1g1", moveUci(findMoveBySan(castle, "O-O")!!))
        assertEquals("e1c1", moveUci(findMoveBySan(castle, "O-O-O+")!!))
        // hai xe cùng tới d1: thiếu gợi ý thì mơ hồ (null), có gợi ý thì đúng quân
        val two = Position.fromFen("4k3/8/8/8/8/8/4K3/R6R w - - 0 1")
        assertNull(findMoveBySan(two, "Rd1"))
        assertEquals("a1d1", moveUci(findMoveBySan(two, "Rad1")!!))
        assertEquals("h1d1", moveUci(findMoveBySan(two, "Rhd1")!!))
        // phong cấp
        val promo = Position.fromFen("8/4P2k/8/8/8/8/8/4K3 w - - 0 1")
        assertEquals("e7e8q", moveUci(findMoveBySan(promo, "e8=Q")!!).lowercase())
        assertEquals("e7e8n", moveUci(findMoveBySan(promo, "e8=N")!!).lowercase())
    }

    @Test
    fun builtInBookParsesEveryLine() {
        val book = OpeningBook.fromBuiltIn()
        assertEquals(OpeningBook.BUILT_IN.size, book.lineCount)
    }

    @Test
    fun bookLookupNamesAndPrefixes() {
        val book = OpeningBook.fromBuiltIn()
        val najdorf = ReviewReplay.replay(START_FEN, listOf("e2e4", "c7c5", "g1f3", "d7d6", "d2d4", "c5d4", "f3d4", "g8f6", "b1c3", "a7a6"))!!
        val hit = book.lookup(najdorf.plies.last().fenAfter)
        assertNotNull(hit)
        assertEquals("B90", hit!!.eco)
        assertTrue(hit.name.contains("Najdorf"))
        // thế trung gian có tên chung của dòng ngắn nhất
        assertEquals("B20", book.lookup(najdorf.plies[1].fenAfter)!!.eco)
        assertEquals("B00", book.lookup(najdorf.plies[0].fenAfter)!!.eco)
        // thế lạ không có tên
        val odd = ReviewReplay.replay(START_FEN, listOf("a2a3", "a7a6", "h2h3"))!!
        assertNull(book.lookup(odd.plies.last().fenAfter))
    }

    @Test
    fun tsvParsingAcceptsLichessFormat() {
        val tsv = listOf(
            "eco\tname\tpgn",
            "C20\tKing's Pawn Game\t1. e4 e5",
            "C40\tKing's Knight Opening\t1. e4 e5 2. Nf3",
            "X99\tGhi sai\t1. e4 e5 2. Nf6",
            "",
        )
        val book = OpeningBook.fromTsv(tsv.asSequence())
        assertEquals(2, book.lineCount)
        val r = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5", "g1f3"))!!
        assertEquals("C40", book.lookup(r.plies[2].fenAfter)!!.eco)
        assertEquals("C20", book.lookup(r.plies[1].fenAfter)!!.eco)
    }

    // ------------------------------------------------------------ ráp cả ván

    private fun ev(best: String?, cp: Int, second: String? = null, secondCp: Int? = null) = EngineResult(
        bestMove = best, scoreCp = cp, mate = null, depthReached = 14, timedOut = false,
        pv = listOfNotNull(best), secondMove = second, secondCp = secondCp, secondMate = null,
        engine = "native", multiPv = 2,
    )

    @Test
    fun bookMovesAreLabelledAndNamed() {
        val replay = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5", "g1f3", "a7a6"))!!
        val evals = listOf(ev("e2e4", 30), ev("e7e5", -30), ev("g1f3", 30), ev("b8c6", -40), ev("f1c4", 20))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L, OpeningBook.fromBuiltIn())
        assertEquals(listOf(MoveLabel.BOOK, MoveLabel.BOOK, MoveLabel.BOOK), r.moves.take(3).map { it.label })
        assertEquals("C40", r.moves[2].ecoCode)
        assertEquals(0.0, r.moves[0].winLoss, 0.0)
        // 2...a6 rời sổ khai cuộc: không còn Book, nhưng vẫn giữ tên khai cuộc cuối cùng
        assertTrue(r.moves[3].label != MoveLabel.BOOK)
        assertEquals("C40", r.moves[3].ecoCode)
        // không truyền book -> không có Book
        val nb = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertTrue(nb.moves.none { it.label == MoveLabel.BOOK })
    }

    @Test
    fun greatWhenOnlyMove() {
        val replay = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5"))!!
        val evals = listOf(ev("e2e4", 30, "a2a3", -200), ev("e7e5", -30), ev("g1f3", 30))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertEquals(MoveLabel.GREAT, r.moves[0].label)
        assertEquals(MoveLabel.BEST, r.moves[1].label)
    }

    @Test
    fun missAfterBlunder() {
        val replay = ReviewReplay.replay(START_FEN, listOf("f2f3", "e7e6"))!!
        // Trắng f3 (thế sau: Đen hơn 300), Đen đáng ra đi e5 nhưng đi e6 (Trắng +90 => Đen -90).
        val evals = listOf(ev("e2e4", 30), ev("e7e5", 300), ev("e2e4", 90))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertEquals(MoveLabel.BLUNDER, r.moves[0].label)
        assertEquals(MoveLabel.MISS, r.moves[1].label)
    }

    @Test
    fun bestMoveAfterBlunderIsPunishedNotMiss() {
        val replay = ReviewReplay.replay(START_FEN, listOf("f2f3", "e7e5"))!!
        // Trắng f3? (Đen hơn 300); Đen đi đúng e5 (nước tốt nhất) => đã trừng phạt: Best, KHÔNG phải Miss.
        val evals = listOf(ev("e2e4", 30), ev("e7e5", 300), ev("e2e4", -300))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        assertEquals(MoveLabel.BLUNDER, r.moves[0].label)
        assertEquals(MoveLabel.BEST, r.moves[1].label)
    }

    @Test
    fun equalSecondBestCountsAsBest() {
        val replay = ReviewReplay.replay(START_FEN, listOf("d2d4", "d7d5"))!!
        val evals = listOf(ev("e2e4", 30, "d2d4", 29), ev("d7d5", -30), ev("c2c4", 30))
        val r = ReviewAssembler.assemble("g", replay.startFen, replay.plies, evals, "LOW", 0L)
        // d4 ngang điểm với nước tốt nhất (chênh < 0,25%) => vẫn là Best
        assertEquals(MoveLabel.BEST, r.moves[0].label)
        assertTrue(r.moves[0].winLoss < 0.25)
    }
}

/**
 * Nhãn theo luật Chess.com (Brilliant xét nước thay thế) + luật mate của Lichess.
 * Ván mẫu = chiếu hết bí (smothered mate) 10.Re1? Nf2+ 11.Kg1 Nh3+ 12.Kh1 Qg1+!! 13.Rxg1 Nf2#.
 */
class MoveClassifierMateRulesTest {

    private val startFen = "r1b1kb1r/p1p1pppp/2p5/8/3q2n1/8/PPPN2PP/RNBQ1R1K w kq - 0 10"
    private val ucis = listOf("f1e1", "g4f2", "h1g1", "f2h3", "g1h1", "d4g1", "e1g1", "h3f2")

    private fun ev(
        best: String?, cp: Int, mate: Int? = null,
        second: String? = null, secondCp: Int? = null,
    ) = EngineResult(
        bestMove = best, scoreCp = if (mate != null && mate != 0) (if (mate > 0) 10_000 - 10 * mate else -10_000 - 10 * mate) else cp,
        mate = mate, depthReached = 18, timedOut = false, pv = listOfNotNull(best),
        secondMove = second, secondCp = secondCp, secondMate = null, engine = "native", multiPv = 2,
    )

    /** evals như Stockfish MultiPV 2 trả về (góc nhìn bên đang đi). [whiteCpBeforeRe1] = cp của Trắng trước 10.Re1. */
    private fun smotheredEvals(whiteCpBeforeRe1: Int, secondCpAtQg1: Int) = listOf(
        ev("d1f3", whiteCpBeforeRe1, second = "d2f3", secondCp = whiteCpBeforeRe1 - 20),
        ev("g4f2", 0, mate = 4, second = "d4f2", secondCp = 800),
        ev("h1g1", 0, mate = -3),
        ev("f2h3", 0, mate = 3, second = "d4g1", secondCp = 600),
        ev("g1h1", 0, mate = -2),
        ev("d4g1", 0, mate = 2, second = "d4d2", secondCp = secondCpAtQg1),
        ev("e1g1", 0, mate = -1),
        ev("h3f2", 0, mate = 1, second = "h3g1", secondCp = -300),
        EngineResult(null, -10_000, 0, 0, false, engine = "rules"),
    )

    private fun review(whiteCpBeforeRe1: Int, secondCpAtQg1: Int): List<MoveLabel> {
        val replay = ReviewReplay.replay(startFen, ucis)!!
        val r = ReviewAssembler.assemble("t", replay.startFen, replay.plies, smotheredEvals(whiteCpBeforeRe1, secondCpAtQg1), "x", 0L)
        return r.moves.map { it.label }
    }

    // ---- sàn mate của Lichess ----

    @Test
    fun mateCreatedFloorFollowsLichessCutoffs() {
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(0)))
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(-500)))
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(-700)))
        assertEquals(MoveLabel.MISTAKE, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(-701)))
        assertEquals(MoveLabel.MISTAKE, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(-999)))
        assertEquals(MoveLabel.INACCURACY, MoveClassifier.labelByLoss(MoveClassifier.mateCreatedFloor(-1000)))
    }

    @Test
    fun mateLostFloorFollowsLichessCutoffs() {
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(MoveClassifier.mateLostFloor(0)))
        assertEquals(MoveLabel.BLUNDER, MoveClassifier.labelByLoss(MoveClassifier.mateLostFloor(700)))
        assertEquals(MoveLabel.MISTAKE, MoveClassifier.labelByLoss(MoveClassifier.mateLostFloor(701)))
        assertEquals(MoveLabel.INACCURACY, MoveClassifier.labelByLoss(MoveClassifier.mateLostFloor(1000)))
    }

    @Test
    fun mateRuleFloorCases() {
        // không liên quan mate
        assertEquals(0.0, MoveClassifier.mateRuleFloor(null, 50, null, 40), 0.0)
        // đi vào thế bị mate từ thế -5
        assertEquals(MoveClassifier.FLOOR_BLUNDER, MoveClassifier.mateRuleFloor(null, -500, -4, -9960), 0.0)
        // đã bị mate sẵn (mate âm) mà đi nước khác: không phạt thêm
        assertEquals(0.0, MoveClassifier.mateRuleFloor(-3, -9970, -2, -9980), 0.0)
        // đang có mate, mất mate, còn +3 => Blunder
        assertEquals(MoveClassifier.FLOOR_BLUNDER, MoveClassifier.mateRuleFloor(3, 9970, null, 300), 0.0)
        // đang có mate, chiếu hết luôn (mate sau = 0) hoặc mate chậm hơn: không phạt
        assertEquals(0.0, MoveClassifier.mateRuleFloor(1, 9990, 0, 10_000), 0.0)
        assertEquals(0.0, MoveClassifier.mateRuleFloor(2, 9980, 3, 9970), 0.0)
        // đang có mate, đi sai thành bị mate ngược
        assertEquals(MoveClassifier.FLOOR_BLUNDER, MoveClassifier.mateRuleFloor(2, 9980, -2, -9980), 0.0)
    }

    @Test
    fun allowingMateFromPlayableEvalIsBlunderNotMistake() {
        // Trước 10.Re1 Trắng -5.0 (win% ≈ 13,6): theo win% thuần chỉ là Mistake (loss 13,6) nhưng Lichess gọi là Blunder.
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.BLUNDER, labels[0])
    }

    @Test
    fun allowingMateWhenAlreadyHopelessIsOnlyInaccuracy() {
        val labels = review(whiteCpBeforeRe1 = -1200, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.INACCURACY, labels[0])
    }

    @Test
    fun smotheredMateQueenSacIsBrilliantWhenAlternativesDoNotWin() {
        // Hậu hy sinh 12...Qg1+!! : nước tốt nhì chỉ +3,5 (win% ≈ 78 < 85) => "không thắng đậm nếu không tìm ra nước này".
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 350)
        assertEquals(MoveLabel.BRILLIANT, labels[5])
        // các nước ép buộc / đáp trả thường vẫn là Best
        assertEquals(MoveLabel.BEST, labels[1])
        assertEquals(MoveLabel.BEST, labels[2])
        assertEquals(MoveLabel.BEST, labels[6])
    }

    @Test
    fun smotheredMateQueenSacIsBrilliantEvenWhenAlternativeAlsoWinsBig() {
        // Nước tốt nhì cũng +9 (win% ≈ 96) nhưng 12...Qg1+!! hy sinh hậu để chiếu hết bí => vẫn Brilliant (nhánh chiếu hết không xét nước thay thế).
        val labels = review(whiteCpBeforeRe1 = -500, secondCpAtQg1 = 900)
        assertEquals(MoveLabel.BRILLIANT, labels[5])
        // nước ăn hậu 13.Rxg1 (không hy sinh) không bị kéo theo: vẫn là Best
        assertEquals(MoveLabel.BEST, labels[6])
    }

    @Test
    fun bestMoveIsNeverPenalisedByMateFloor() {
        // Mọi nước đều thua: nước engine chọn (kéo dài nhất) không bị sàn mate phạt.
        val replay = ReviewReplay.replay(startFen, ucis.take(1))!!
        val evals = listOf(ev("f1e1", -9990, mate = -5), ev("g4f2", 0, mate = 4))
        val r = ReviewAssembler.assemble("t", replay.startFen, replay.plies, evals, "x", 0L)
        assertEquals(0.0, r.moves[0].winLoss, 0.0)
    }
}
