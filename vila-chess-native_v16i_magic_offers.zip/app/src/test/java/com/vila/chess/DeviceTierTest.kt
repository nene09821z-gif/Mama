package com.vila.chess

import com.vila.chess.review.DeviceTier
import com.vila.chess.review.DeviceTierManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Tự nhận máy: yếu depth 14–16, trung 18–20, mạnh 20–30 (trần MAX_DEPTH). */
class DeviceTierTest {

    @Test
    fun weakPhoneGets14to16() {
        val a = DeviceTierManager.configFor(ramGb = 2.0, cores = 4, mhz = 0)
        assertEquals(DeviceTier.LOW, a.tier)
        assertEquals(14, a.depth)
        val b = DeviceTierManager.configFor(ramGb = 2.8, cores = 8, mhz = 0)
        assertEquals(16, b.depth)
        assertEquals(1, b.threads)
    }

    @Test
    fun slowCpuIsWeakEvenWithBigRam() {
        assertEquals(DeviceTier.LOW, DeviceTierManager.configFor(ramGb = 8.0, cores = 8, mhz = 1500).tier)
    }

    @Test
    fun midPhoneGets18to20() {
        assertEquals(18, DeviceTierManager.configFor(ramGb = 4.0, cores = 6, mhz = 0).depth)
        val top = DeviceTierManager.configFor(ramGb = 5.5, cores = 8, mhz = 2600)
        assertEquals(DeviceTier.MEDIUM, top.tier)
        assertEquals(20, top.depth)
        assertTrue(top.threads <= 2)
    }

    @Test
    fun strongPhoneGets20to30() {
        assertEquals(20, DeviceTierManager.configFor(ramGb = 6.5, cores = 4, mhz = 0).depth)
        val mid = DeviceTierManager.configFor(ramGb = 7.5, cores = 8, mhz = 3000)
        assertEquals(DeviceTier.HIGH, mid.tier)
        assertEquals(26, mid.depth)
        val flagship = DeviceTierManager.configFor(ramGb = 16.0, cores = 8, mhz = 3300)
        assertEquals(DeviceTierManager.MAX_DEPTH, flagship.depth)
        assertTrue(flagship.threads <= 4)
    }

    @Test
    fun depthNeverLeavesItsBand() {
        for (ram in listOf(1.0, 2.5, 3.0, 4.0, 6.0, 6.1, 8.0, 12.0, 24.0))
            for (cores in listOf(1, 4, 6, 8, 12))
                for (mhz in listOf(0, 1500, 2000, 2600, 3000, 3400)) {
                    val c = DeviceTierManager.configFor(ram, cores, mhz)
                    val range = when (c.tier) {
                        DeviceTier.LOW -> 14..16
                        DeviceTier.MEDIUM -> 18..20
                        DeviceTier.HIGH -> 20..30
                    }
                    assertTrue("ram=$ram cores=$cores mhz=$mhz depth=${c.depth}", c.depth in range)
                }
    }
}
