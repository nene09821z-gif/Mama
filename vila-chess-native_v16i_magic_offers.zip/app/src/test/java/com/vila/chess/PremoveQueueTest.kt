package com.vila.chess

import com.vila.chess.core.BISHOP
import com.vila.chess.core.EMPTY
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.applyPremoveOnCopy
import com.vila.chess.core.generatePremoveMoves
import com.vila.chess.core.makePiece
import com.vila.chess.core.moveUci
import com.vila.chess.game.PremoveMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PremoveQueueTest {
    @Test
    fun chainedPremovesBuildVirtualBoard() {
        val v = Position.start()
        assertTrue(applyPremoveOnCopy(v, true, 12, 28))   // e2-e4
        assertTrue(applyPremoveOnCopy(v, true, 6, 21))    // g1-f3
        assertTrue(applyPremoveOnCopy(v, true, 5, 26))    // f1-c4: chỉ hợp lệ vì e2 đã trống ở bàn cờ ảo
        assertEquals(makePiece(PAWN, true), v.board[28])
        assertEquals(makePiece(KNIGHT, true), v.board[21])
        assertEquals(makePiece(BISHOP, true), v.board[26])
        assertEquals(EMPTY, v.board[12])
    }

    @Test
    fun invalidPremoveIsRejected() {
        val v = Position.start()
        assertTrue(applyPremoveOnCopy(v, true, 12, 28))
        assertFalse(applyPremoveOnCopy(v, true, 12, 28))  // e2 đã trống
        assertFalse(applyPremoveOnCopy(v, true, 0, 40))   // xe a1 không nhảy qua tốt
    }

    @Test
    fun premovePathCoversEverySquareOnStraightAndDiagonalMoves() {
        assertEquals(listOf(12, 20, 28), com.vila.chess.ui.premovePath(12, 28))    // e2-e4: e2, e3, e4
        assertEquals(listOf(5, 12, 19, 26), com.vila.chess.ui.premovePath(5, 26))  // f1-c4: f1, e2, d3, c4
        assertEquals(listOf(6, 21), com.vila.chess.ui.premovePath(6, 21))          // g1-f3 (Mã): chỉ ô đi và ô đến
    }

    @Test
    fun premoveCanPromoteToChosenPiece() {
        val v = Position.fromFen("7k/P7/8/8/8/8/8/K7 w - - 0 1")
        assertTrue(applyPremoveOnCopy(v, true, 48, 56, KNIGHT))                    // a7-a8=N
        assertEquals(makePiece(KNIGHT, true), v.board[56])
    }

    @Test
    fun premoveModeIdsRoundTrip() {
        for (m in PremoveMode.values()) assertEquals(m, PremoveMode.fromId(m.id))
        assertEquals(PremoveMode.MULTI, PremoveMode.fromId(99))
    }

    private fun premoveUci(fen: String, white: Boolean): Set<String> =
        generatePremoveMoves(Position.fromFen(fen), white).map { moveUci(it) }.toSet()

    @Test
    fun premoveCanRecaptureOnOwnPieceThatIsAttacked() {
        // Tốt đen e5 đang đe dọa tốt trắng d4 => Hậu d1 được premove "ăn lại" vào d4 (ô đang có quân mình).
        val fen = "4k3/8/8/4p3/3P4/8/8/3QK3 b - - 0 1"
        val moves = premoveUci(fen, true)
        assertTrue(moves.contains("d1d4"))      // ăn lại trên ô quân mình đang bị đe dọa
        assertFalse(moves.contains("d1d5"))     // quân trượt không đi xuyên qua quân
        assertTrue(moves.contains("d4e5"))      // tốt chéo ăn quân địch
        assertFalse(moves.contains("d4c5"))     // tốt không chéo vào ô trống
        val v = Position.fromFen(fen)
        assertTrue(applyPremoveOnCopy(v, true, 3, 27))   // d1 -> d4
        assertEquals(makePiece(QUEEN, true), v.board[27])
        assertEquals(EMPTY, v.board[3])
    }

    @Test
    fun premoveCannotLandOnOwnPieceThatIsNotAttacked() {
        val moves = premoveUci("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", true)
        assertFalse(moves.contains("a1a2"))     // tốt a2 không bị ai đe dọa => không phải "ăn lại"
        assertFalse(moves.contains("g1e2"))
        assertTrue(moves.contains("g1f3"))
    }
}
