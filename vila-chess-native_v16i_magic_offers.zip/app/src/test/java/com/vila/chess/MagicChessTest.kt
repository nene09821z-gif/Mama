package com.vila.chess

import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.Position
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.makePiece
import com.vila.chess.core.moveUci
import com.vila.chess.magic.MagicCatalog
import com.vila.chess.magic.MagicGame
import com.vila.chess.magic.MagicResult
import com.vila.chess.magic.MagicState
import com.vila.chess.magic.Rarity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class MagicChessTest {

    private fun gameWith(fen: String, hand: List<Int>, mana: Int = 10): MagicGame {
        val g = MagicGame(1L)
        val f = MagicGame::class.java.getDeclaredField("s").apply { isAccessible = true }
        val st = MagicState(Position.fromFen(fen), Random(7))
        st.mana[0] = mana; st.mana[1] = mana
        st.hands[0].addAll(hand)
        f.set(g, st)
        return g
    }

    private fun idOf(title: String, mod: String = ""): Int =
        MagicCatalog.cards.first { it.effect.title == title && (if (mod.isEmpty()) it.modifier.name == "NONE" else it.modifier.name == mod) }.id

    @Test
    fun catalogHasThousandsOfUniqueCards() {
        assertTrue("size=${MagicCatalog.size}", MagicCatalog.size >= 2000)
        assertEquals(MagicCatalog.size, MagicCatalog.cards.map { it.name + "|" + it.description }.toSet().size)
        assertEquals(MagicCatalog.size, MagicCatalog.cards.map { it.id }.toSet().size)
        assertTrue(MagicCatalog.cards.all { it.baseCost in 0..9 })
        for (r in Rarity.values()) assertTrue(r.name, MagicCatalog.cards.any { it.rarity == r })
    }

    @Test
    fun randomDrawsAreValidIds() {
        val rng = Random(3)
        repeat(2000) { assertTrue(MagicCatalog.randomId(rng) in 0 until MagicCatalog.size) }
    }

    @Test
    fun startingStateIsSane() {
        val g = MagicGame(5L)
        assertTrue(g.whiteToMove)
        assertEquals(3, g.s.mana[0])               // 2 + 1 ở đầu lượt
        assertEquals(3, g.s.hands[0].size)         // 3 lá khởi đầu; lượt này được mở thêm 3 lá để chọn 1
        assertEquals(3, g.s.offers[0].size)
        assertEquals(3, g.s.hands[1].size)
        assertEquals(20, g.allowedMoves().size)
    }

    @Test
    fun playingAMoveGivesTurnToOpponentWithManaAndCard() {
        val g = MagicGame(5L)
        val m = g.allowedMoves().first { moveUci(it) == "e2e4" }
        assertTrue(g.playMove(m))
        assertFalse(g.whiteToMove)
        assertEquals(3, g.s.mana[1])
        assertEquals(3, g.s.hands[1].size)         // không còn rút mù: 3 lá mở ra để chọn 1
        assertEquals(3, g.offers().size)
        assertTrue(g.s.offers[0].isEmpty())
    }

    // ---------------------------------------------------------------- 3 lá bài đầu lượt

    @Test
    fun turnStartOpensThreeDistinctOffersAndPickingAddsToHand() {
        val g = MagicGame(9L)
        val offer = g.offers().toList()
        assertEquals(3, offer.size)
        assertEquals(3, offer.toSet().size)
        val before = g.s.hands[0].size
        assertNull(g.takeOffer(1))
        assertEquals(before + 1, g.s.hands[0].size)
        assertEquals(offer[1], g.s.hands[0].last())
        assertTrue(g.offers().isEmpty())
        assertEquals("Không có lá bài này", g.takeOffer(0))
    }

    @Test
    fun skippingOfferGivesOneMana() {
        val g = MagicGame(9L)
        val mana = g.s.mana[0]
        val hand = g.s.hands[0].size
        assertNull(g.skipOffer())
        assertEquals(mana + 1, g.s.mana[0])
        assertEquals(hand, g.s.hands[0].size)
        assertTrue(g.offers().isEmpty())
        assertNotNull(g.skipOffer())
    }

    @Test
    fun fullHandOpensNoOffer() {
        val g = MagicGame(5L)
        g.s.hands[1].clear()
        repeat(MagicState.HAND_MAX) { g.s.hands[1].add(0) }
        assertTrue(g.playMove(g.allowedMoves().first { moveUci(it) == "e2e4" }))
        assertTrue(g.offers().isEmpty())
    }

    @Test
    fun freeOffersHaveNoExclusiveAndVipAlwaysHaveOne() {
        val rng = Random(21)
        repeat(2000) {
            val f = MagicCatalog.offerIds(rng, MembershipTier.FREE)
            assertEquals(3, f.size); assertEquals(3, f.toSet().size)
            assertTrue(f.all { it < MagicCatalog.size })
        }
        for (t in listOf(MembershipTier.GOLD, MembershipTier.PLATINUM, MembershipTier.DIAMOND, MembershipTier.FAMILY)) repeat(2000) {
            val o = MagicCatalog.offerIds(rng, t)
            assertEquals(3, o.size); assertEquals(3, o.toSet().size)
            assertTrue("$t", o.any { it >= MagicCatalog.size })
            assertTrue(o.filter { it >= MagicCatalog.size }.all { MagicCatalog.get(it).tier.rank <= t.rank })
        }
    }

    @Test
    fun higherTiersSeeMoreExclusiveCards() {
        val rng = Random(33)
        fun share(t: MembershipTier): Double {
            var ex = 0; var tot = 0
            repeat(4000) { MagicCatalog.offerIds(rng, t).forEach { tot++; if (it >= MagicCatalog.size) ex++ } }
            return ex.toDouble() / tot
        }
        val g = share(MembershipTier.GOLD); val p = share(MembershipTier.PLATINUM); val d = share(MembershipTier.DIAMOND)
        assertTrue("$g $p $d", g < p && p < d)
    }

    @Test
    fun vipGameOpensExclusiveCardAtTurnStart() {
        repeat(20) { n ->
            val g = MagicGame(100L + n, MembershipTier.GOLD)
            assertTrue(g.offers().any { it >= MagicCatalog.size })
        }
    }

    // ---------------------------------------------------------------- Bài giải trí

    private fun exId(title: String): Int =
        MagicCatalog.exclusive.first { it.effect.title == title && it.modifier.name == "NONE" }.id

    @Test
    fun funAndSignatureCardsExist() {
        assertTrue(MagicCatalog.cards.any { it.isFun })
        assertTrue(MagicCatalog.exclusive.any { it.isSignature })
        assertTrue(MagicCatalog.exclusive.any { it.isFun })
        assertTrue(MagicCatalog.exclusive.all { it.baseCost in 0..9 })
    }

    @Test
    fun diceRollAlwaysPaysOffAndLogsResult() {
        val g = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(idOf("Xúc xắc may rủi")), mana = 5)
        assertNull(g.castSpell(0, emptyList()))
        assertTrue(g.s.mana[0] >= 3)               // 5 - 2, cộng thêm mana nếu ra mặt có mana
        assertNotNull(g.s.log)
    }

    @Test
    fun coinFlipEitherKillsOrGivesMana() {
        val g = gameWith("4k3/8/8/8/3q4/8/8/4K3 w - - 0 1", listOf(idOf("Tung đồng xu")), mana = 5)
        assertNull(g.castSpell(0, listOf(27)))
        val removed = g.s.pos.board[27] == 0
        assertTrue((removed && g.s.mana[0] == 2) || (!removed && g.s.mana[0] == 4))
    }

    @Test
    fun mirrorClonesToSymmetricSquare() {
        val g = gameWith("4k3/8/8/8/8/8/8/N3K3 w - - 0 1", listOf(idOf("Gương soi Mã")))
        assertNull(g.castSpell(0, listOf(0)))
        assertEquals(makePiece(KNIGHT, true), g.s.pos.board[7])
        assertEquals(makePiece(KNIGHT, true), g.s.pos.board[0])
    }

    @Test
    fun magicHatPlacesRandomOwnPieceOnlyInAllowedSquares() {
        val g = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(idOf("Mũ ảo thuật")))
        assertNotNull(g.castSpell(0, listOf(0)))   // hàng 1: không hợp lệ (tránh Tốt ở hàng cuối)
        assertNull(g.castSpell(0, listOf(9)))
        val p = g.s.pos.board[9]
        assertTrue(p != 0 && isWhitePiece(p))
    }

    @Test
    fun meteorDestroysUpToTwoEnemyPawns() {
        val g = gameWith("4k3/pp6/8/8/8/8/8/4K3 w - - 0 1", listOf(idOf("Mưa sao băng")))
        assertNull(g.castSpell(0, emptyList()))
        assertTrue(g.s.pos.board.none { it == 9 })
        val g2 = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(idOf("Mưa sao băng")))
        assertNotNull(g2.castSpell(0, emptyList()))
    }

    @Test
    fun luckyWheelFreezesOneEnemyAndShieldsOneOwn() {
        val g = gameWith("4k3/8/8/8/3q4/8/8/R3K3 w - - 0 1", listOf(idOf("Vòng quay may mắn")))
        assertNull(g.castSpell(0, emptyList()))
        assertTrue(g.s.isFrozen(27))
        assertTrue(g.s.isShielded(0))
    }

    // ---------------------------------------------------------------- Tuyệt kỹ VIP

    @Test
    fun signatureCardsAreNeverPricedAbovePartsAndAreStronger() {
        for (c in MagicCatalog.exclusive.filter { it.isSignature && it.modifier.name == "NONE" }) {
            val parts = (c.effect as com.vila.chess.magic.Combo).partsForTest()
            val sum = parts.sumOf { pe -> MagicCatalog.cards.first { it.effect.title == pe.title && it.modifier.name == "NONE" }.baseCost }
            assertTrue("${c.name}: ${c.baseCost} vs $sum", c.baseCost <= sum)
        }
    }

    @Test
    fun redDuskDestroysTwoEnemyPieces() {
        val g = gameWith("4k3/pp6/8/8/8/8/8/4K3 w - - 0 1", listOf(exId("Hoàng Hôn Đỏ")))
        assertNull(g.castSpell(0, listOf(48, 49)))
        assertTrue(g.s.pos.board.none { it == 9 })
        assertEquals(2, g.s.mana[0])               // 10 - 8
    }

    @Test
    fun fortuneGivesManaAndCard() {
        val g = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(exId("Thần Tài")), mana = 3)
        assertNull(g.castSpell(0, emptyList()))
        assertEquals(5, g.s.mana[0])               // 3 + 4 - 2
        assertEquals(1, g.s.hands[0].size)         // dùng 1, rút 1
    }

    @Test
    fun spawnQueenWorksAndPaysMana() {
        val id = idOf("Triệu hồi Hậu (2 hàng phía mình)")
        val g = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(id))
        val card = g.card(0)!!
        assertEquals(listOf(0, 1, 2, 3, 5, 6, 7) + (8..15).toList(), g.spellTargets(card, emptyList()).sorted())
        assertNull(g.castSpell(0, listOf(3)))
        assertEquals(5, g.s.pos.board[3])
        assertEquals(10 - card.baseCost, g.s.mana[0])
    }

    @Test
    fun smiteNeverTargetsKingAndRemoves() {
        val id = idOf("Thiêu đốt (bất kỳ đâu)")
        val g = gameWith("4k3/8/8/3p4/8/8/8/4K3 w - - 0 1", listOf(id))
        assertEquals(listOf(35), g.spellTargets(g.card(0)!!, emptyList()))
        assertNull(g.castSpell(0, listOf(35)))
        assertEquals(0, g.s.pos.board[35])
        assertEquals(listOf(1), g.s.lost[1])
    }

    @Test
    fun spellCannotLeaveOwnKingInCheck() {
        // Xe đen chiếu Vua trắng; Thiêu Tốt không giải được chiếu => phải bị từ chối
        val id = idOf("Thiêu đốt (bất kỳ đâu)")
        val g = gameWith("4k3/8/8/8/8/8/p7/r3K3 w - - 0 1", listOf(id))
        assertTrue(g.s.pos.inCheck(true))
        assertNotNull(g.castSpell(0, listOf(8)))
        assertEquals(1, g.s.hands[0].size)         // không mất bài
        assertEquals(10, g.s.mana[0])
        // nhưng thiêu chính Xe thì được
        val id2 = idOf("Thiêu Xe (bất kỳ đâu)")
        val g2 = gameWith("4k3/8/8/8/8/8/p7/r3K3 w - - 0 1", listOf(id2))
        assertNull(g2.castSpell(0, listOf(0)))
    }

    @Test
    fun freezeBlocksMovesForExactlyOneOpponentTurn() {
        val id = idOf("Đóng băng Hậu (1 lượt)")
        val g = gameWith("4k3/8/8/8/3q4/8/8/4K2R w - - 0 1", listOf(id))
        assertNull(g.castSpell(0, listOf(27)))
        assertTrue(g.playMove(g.allowedMoves().first { moveUci(it) == "h1h2" }))
        // Đen: Hậu bị đóng băng, chỉ Vua đi được
        assertTrue(g.allowedMoves().all { com.vila.chess.core.moveFrom(it) == 60 })
        assertTrue(g.playMove(g.allowedMoves().first()))
        assertTrue(g.playMove(g.allowedMoves().first { moveUci(it) == "h2h1" }))
        // lượt kế của Đen: hết băng
        assertTrue(g.allowedMoves().any { com.vila.chess.core.moveFrom(it) == 27 })
    }

    @Test
    fun shieldPreventsCaptureThenExpires() {
        val id = idOf("Khiên Xe (1 lượt)")
        val g = gameWith("4k3/8/8/8/8/8/8/R3K2r w - - 0 1", listOf(id))
        // Xe trắng a1 được khiên; Xe đen h1 không thể ăn nó (vua e1 chắn đường, nên kiểm bằng tình huống khác)
        val g2 = gameWith("r3k3/8/8/8/8/8/8/R3K3 w - - 0 1", listOf(id))
        assertNull(g2.castSpell(0, listOf(0)))
        assertTrue(g2.playMove(g2.allowedMoves().first { moveUci(it) == "e1e2" }))
        assertTrue(g2.allowedMoves().none { moveUci(it) == "a8a1" })
        assertNotNull(g)
    }

    @Test
    fun extraMoveGrantsSecondMoveOfSameSide() {
        val id = idOf("Thần tốc")
        val g = gameWith("4k3/8/8/8/8/8/PP6/4K3 w - - 0 1", listOf(id))
        assertNull(g.castSpell(0, emptyList()))
        assertTrue(g.playMove(g.allowedMoves().first { moveUci(it) == "a2a3" }))
        assertTrue(g.whiteToMove)
        assertTrue(g.playMove(g.allowedMoves().first { moveUci(it) == "b2b3" }))
        assertFalse(g.whiteToMove)
    }

    @Test
    fun lockPreventsCastingNextTurn() {
        val lock = idOf("Phong ấn (1 lượt)")
        val g = gameWith("4k3/8/8/8/8/8/PP6/4K3 w - - 0 1", listOf(lock))
        g.s.hands[1].add(idOf("Nghi lễ mana (2)"))
        assertNull(g.castSpell(0, emptyList()))
        g.playMove(g.allowedMoves().first { moveUci(it) == "a2a3" })
        assertEquals("Bạn đang bị phong ấn", g.castSpell(0, emptyList()))
        g.playMove(g.allowedMoves().first())
        g.playMove(g.allowedMoves().first { moveUci(it) == "b2b3" })
        // Đen hết bị phong ấn
        assertNull(g.castSpell(0, emptyList()))
    }

    @Test
    fun resurrectRestoresLostPiece() {
        val kill = idOf("Thiêu Hậu (bất kỳ đâu)")
        val res = idOf("Hồi sinh Hậu (2 hàng phía mình)")
        val g = gameWith("4k3/8/8/8/8/8/8/4K3 w - - 0 1", listOf(res))
        assertNotNull(g.castSpell(0, listOf(3)))                 // chưa mất Hậu nào
        assertNotNull(kill)
        g.s.lost[0].add(5)
        assertNull(g.castSpell(0, listOf(3)))
        assertEquals(5, g.s.pos.board[3])
    }

    @Test
    fun trapDestroysEnemyThatStepsOnIt() {
        val id = idOf("Bẫy sập (3 lượt)")
        val g = gameWith("4k3/8/8/8/8/8/8/R3K3 w - - 0 1", listOf(id))
        // Đặt bẫy ở e5 (36); Vua đen e8 tiến d7... dùng quân đen: thêm Xe đen để bước vào
        val g2 = gameWith("4k2r/8/8/8/8/8/8/4K3 w - - 0 1", listOf(id))
        assertNull(g2.castSpell(0, listOf(39)))                   // h5
        g2.playMove(g2.allowedMoves().first { moveUci(it) == "e1e2" })
        g2.playMove(g2.allowedMoves().first { moveUci(it) == "h8h5" })
        assertEquals(0, g2.s.pos.board[39])
        assertNotNull(g)
    }

    @Test
    fun checkmateStillEndsGame() {
        val g = gameWith("7k/5ppp/8/8/8/8/8/R5K1 w - - 0 1", emptyList())
        g.playMove(g.allowedMoves().first { moveUci(it) == "a1a8" })
        assertTrue(g.result is MagicResult.Win)
        assertTrue((g.result as MagicResult.Win).white)
    }

    @Test
    fun randomPlayoutsNeverBreakInvariants() {
        val rng = Random(42)
        repeat(30) { gameNo ->
            val g = MagicGame(1000L + gameNo)
            var plies = 0
            while (g.result == null && plies < 300) {
                // thử dùng một bài ngẫu nhiên có mục tiêu hợp lệ
                val hand = g.s.hands[if (g.whiteToMove) 0 else 1]
                if (hand.isNotEmpty() && rng.nextInt(3) > 0) {
                    val i = rng.nextInt(hand.size)
                    val card = g.card(i)!!
                    if (g.castBlocker(card) == null) {
                        val chosen = ArrayList<Int>()
                        var ok = true
                        for (step in 0 until g.stepsOf(card)) {
                            val t = g.spellTargets(card, chosen)
                            if (t.isEmpty()) { ok = false; break }
                            chosen += t[rng.nextInt(t.size)]
                        }
                        if (ok) {
                            val err = g.castSpell(i, chosen)
                            if (g.stepsOf(card) > 0) assertNull("${card.name}: $err", err)
                        }
                    }
                }
                if (g.result != null) break
                val mv = g.allowedMoves()
                assertTrue("no moves but game continues", mv.isNotEmpty())
                assertTrue(g.playMove(mv[rng.nextInt(mv.size)]))
                plies++
                val b = g.s.pos.board
                assertEquals(1, b.count { it == 6 })
                assertEquals(1, b.count { it == 14 })
                assertTrue((0..7).all { f -> b[f] != 1 && b[56 + f] != 1 && b[f] != 9 && b[56 + f] != 9 })
            }
        }
    }

    // ---------------------------------------------------------------- Bài đặc quyền

    @Test
    fun freePlayersNeverDrawExclusiveCards() {
        val rng = Random(11)
        repeat(5000) { assertTrue(MagicCatalog.randomId(rng, MembershipTier.FREE) < MagicCatalog.size) }
        val g = MagicGame(3L, MembershipTier.FREE)
        repeat(50) { g.s.draw(true, 1); g.s.hands[0].clear() }
        assertTrue(MagicCatalog.exclusiveFor(MembershipTier.FREE).isEmpty())
    }

    @Test
    fun exclusiveTiersAreNestedAndDrawable() {
        val g = MembershipTier.GOLD; val p = MembershipTier.PLATINUM; val d = MembershipTier.DIAMOND; val f = MembershipTier.FAMILY
        val ng = MagicCatalog.exclusiveFor(g).size; val np = MagicCatalog.exclusiveFor(p).size
        val nd = MagicCatalog.exclusiveFor(d).size; val nf = MagicCatalog.exclusiveFor(f).size
        assertTrue(ng > 0 && ng < np && np < nd)
        assertEquals(nd, nf)
        assertTrue(MagicCatalog.exclusive.all { it.tier != MembershipTier.FREE && it.id >= MagicCatalog.size })
        assertEquals(MagicCatalog.exclusive.size, MagicCatalog.exclusive.map { it.name + "|" + it.description }.toSet().size)
        val rng = Random(5)
        val seen = HashSet<Int>()
        repeat(20000) { seen += MagicCatalog.randomId(rng, d) }
        assertTrue(MagicCatalog.exclusiveFor(d).all { it.id in seen })
        val ids = MagicCatalog.exclusive.map { it.id }
        assertTrue(ids.all { MagicCatalog.get(it).id == it })
    }

    @Test
    fun exclusiveCardsAreNotCheaperThanTheirParts() {
        // Công bằng: giá mỗi lá đặc quyền >= tổng giá các lá thường cùng hiệu ứng + 1 (không rẻ hơn mua rời).
        for (c in MagicCatalog.exclusive) {
            val e = c.effect as com.vila.chess.magic.Combo
            if (e.signature) continue              // Tuyệt kỹ VIP được thiết kế mạnh hơn mua rời (có test riêng)
            val parts = e.partsForTest()
            val sum = parts.sumOf { pe -> MagicCatalog.cards.first { it.effect.title == pe.title && it.modifier.name == "NONE" }.baseCost }
            assertTrue("${c.name}", c.baseCost >= sum + 1 + minOf(0, c.modifier.costDelta))
        }
    }

    @Test
    fun exclusivePlayoutsKeepInvariants() {
        val rng = Random(77)
        var casts = 0
        repeat(25) { n ->
            val g = MagicGame(500L + n, MembershipTier.DIAMOND)
            var plies = 0
            while (g.result == null && plies < 200) {
                val white = g.whiteToMove
                val hand = g.s.hands[if (white) 0 else 1]
                val i = hand.indexOfFirst { it >= MagicCatalog.size }
                if (i >= 0) {
                    val card = g.card(i)!!
                    g.s.mana[if (white) 0 else 1] = 10
                    if (g.castBlocker(card) == null) {
                        val chosen = ArrayList<Int>()
                        var ok = true
                        for (st in 0 until g.stepsOf(card)) {
                            val t = g.spellTargets(card, chosen)
                            if (t.isEmpty()) { ok = false; break }
                            chosen += t[rng.nextInt(t.size)]
                        }
                        if (ok) { val err = g.castSpell(i, chosen); if (err == null) casts++ }
                    }
                }
                if (g.result != null) break
                val mv = g.allowedMoves()
                assertTrue(mv.isNotEmpty())
                assertTrue(g.playMove(mv[rng.nextInt(mv.size)]))
                plies++
                val b = g.s.pos.board
                assertEquals(1, b.count { it == 6 }); assertEquals(1, b.count { it == 14 })
                assertTrue((0..7).all { f -> b[f] != 1 && b[56 + f] != 1 && b[f] != 9 && b[56 + f] != 9 })
            }
        }
        assertTrue("casts=$casts", casts > 10)
    }
}
