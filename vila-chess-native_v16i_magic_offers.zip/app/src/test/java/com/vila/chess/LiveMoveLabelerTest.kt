package com.vila.chess

import androidx.compose.ui.geometry.Offset
import com.vila.chess.core.START_FEN
import com.vila.chess.game.LiveMoveLabeler
import com.vila.chess.review.EngineResult
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import com.vila.chess.ui.resolveDrop
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveMoveLabelerTest {

    private fun labels(ucis: List<String>, limits: com.vila.chess.core.SearchLimits = LiveMoveLabeler.FAST): List<MoveLabel> {
        val cache = HashMap<String, EngineResult>()
        val evalOf = { fen: String ->
            cache[fen] ?: LiveMoveLabeler.evaluate(fen, limits) { false }?.also { cache[fen] = it }
        }
        val out = LiveMoveLabeler.labelGame(START_FEN, ucis, evalOf, OpeningBook.fromBuiltIn())
        assertNotNull(out)
        return out!!
    }

    @Test
    fun movingIntoMateIsBlunderAndBookMovesAreBook() {
        // 1.e4 e5 2.Qh5 Nc6 3.Bc4 Nf6?? 4.Qxf7#
        val l = labels(listOf("e2e4", "e7e5", "d1h5", "b8c6", "f1c4", "g8f6", "h5f7"))
        assertEquals(7, l.size)
        assertEquals(MoveLabel.BOOK, l[0])
        assertEquals(MoveLabel.BLUNDER, l[5])   // Nf6 để bị chiếu hết
        assertEquals(MoveLabel.BEST, l[6])      // Qxf7#
    }

    @Test
    fun evaluateReportsMateWithSignConvention() {
        // Trắng chiếu hết sau 1 nước (Qxf7#): mate dương, cp dương.
        val r = LiveMoveLabeler.evaluate("r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4", LiveMoveLabeler.FAST) { false }
        assertNotNull(r)
        assertEquals("h5f7", r!!.bestMove)
        assertEquals(1, r.mate)
        assertTrue(r.scoreCp > 9000)
    }

    @Test
    fun describeMentionsMoveAndQuality() {
        assertEquals("Nxe5 là một sai lầm", LiveMoveLabeler.describe("Nxe5", MoveLabel.MISTAKE))
        assertTrue(LiveMoveLabeler.describe("Qh5", MoveLabel.BLUNDER).contains("nghiêm trọng"))
    }

    // ---- chốt ô thả quân (lỗi "kéo quân đến quân địch nhưng không ăn được") ----
    private val board = 800f   // mỗi ô 100px
    private fun centerOf(sq: Int): Offset = Offset((sq and 7) * 100f + 50f, (7 - (sq shr 3)) * 100f + 50f)

    @Test
    fun dropOnShownPieceSquareWins() {
        val target = 28   // e4
        assertEquals(target, resolveDrop(centerOf(target), centerOf(target), 4, setOf(target), board, false, -1, 9999))
    }

    @Test
    fun fingerSlidingOffOnLiftStillCapturesRecentTarget() {
        val target = 28
        val slipped = centerOf(target) + Offset(160f, 110f)   // trượt sang ô khác khi nhấc tay
        // Vừa ở trên ô đích 80ms trước => vẫn ăn được.
        assertEquals(target, resolveDrop(slipped, slipped, 4, setOf(target), board, false, target, 80))
        // Đã rời ô đích lâu (400ms) => đúng là thả chỗ khác, không hút.
        val far = resolveDrop(slipped, slipped, 4, setOf(target), board, false, target, 400)
        assertTrue(far != target)
    }

    @Test
    fun dropNearEdgeOfTargetSnapsToIt() {
        val target = 28
        val nearEdge = centerOf(target) + Offset(58f, 0f)   // vừa lọt sang ô bên cạnh, còn sát mép
        assertEquals(target, resolveDrop(nearEdge, nearEdge, 4, setOf(target), board, false, -1, 9999))
    }
}
