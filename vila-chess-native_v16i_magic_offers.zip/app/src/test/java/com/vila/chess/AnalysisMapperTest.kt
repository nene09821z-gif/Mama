package com.vila.chess

import com.vila.chess.core.START_FEN
import com.vila.chess.review.EngineResult
import com.vila.chess.review.OpeningBook
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewReplay
import com.vila.chess.review.db.AnalysisMapper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class AnalysisMapperTest {

    private fun game() = run {
        val replay = ReviewReplay.replay(START_FEN, listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6"))!!
        val evals = List(replay.plies.size + 1) { i ->
            EngineResult(
                bestMove = "e2e4", scoreCp = 20 - i * 7, mate = null, depthReached = 12, timedOut = false,
                pv = listOf("e2e4", "e7e5"), secondMove = "d2d4", secondCp = 5, secondMate = null,
                engine = "native", multiPv = 2,
            )
        }
        ReviewAssembler.assemble("g1", replay.startFen, replay.plies, evals, "MEDIUM", 99L, OpeningBook.fromBuiltIn())
    }

    @Test
    fun reviewSurvivesRoomRoundTrip() {
        val review = game()
        val summary = AnalysisMapper.toSummary(review)
        val rows = AnalysisMapper.toRows(review)
        assertEquals(review.moves.size, summary.moveCount)
        assertEquals(review.moves.size, rows.size)
        // Mỗi dòng lưu đủ FEN, Best Move, điểm và nhãn.
        assertEquals(review.moves[0].fenBefore, rows[0].fen)
        assertEquals(review.moves[0].bestMoveBefore, rows[0].bestMove)
        assertEquals(review.moves[0].label.name, rows[0].label)
        assertEquals(review, AnalysisMapper.toReview(summary, rows))
        // Thứ tự dòng bất kỳ vẫn dựng lại đúng.
        assertEquals(review, AnalysisMapper.toReview(summary, rows.reversed()))
    }

    @Test
    fun incompleteRowsAreRejected() {
        val review = game()
        val summary = AnalysisMapper.toSummary(review)
        assertNull(AnalysisMapper.toReview(summary, AnalysisMapper.toRows(review).dropLast(1)))
    }
}
