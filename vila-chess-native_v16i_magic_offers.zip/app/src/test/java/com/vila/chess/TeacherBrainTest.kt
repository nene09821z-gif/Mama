package com.vila.chess

import com.vila.chess.coach.BoardReader
import com.vila.chess.coach.MoveContext
import com.vila.chess.coach.Persona
import com.vila.chess.coach.Say
import com.vila.chess.coach.TeacherBrain
import com.vila.chess.coach.TeacherLines
import com.vila.chess.coach.Topic
import com.vila.chess.core.Position
import com.vila.chess.core.EMPTY
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveTo
import com.vila.chess.core.moveUci
import com.vila.chess.core.pieceType
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TeacherBrainTest {

    private fun find(pos: Position, uci: String): Int =
        pos.legalMoves().first { moveUci(it) == uci }

    private fun ctx(pos: Position, uci: String, moves: MutableList<Int>, humanWhite: Boolean): MoveContext {
        val before = pos.copy()
        val m = find(pos, uci)
        val san = moveToSan(before, m)
        val cap = if (before.board[moveTo(m)] == EMPTY) 0 else pieceType(before.board[moveTo(m)])
        val byHuman = before.whiteToMove == humanWhite
        pos.make(m)
        moves.add(m)
        return MoveContext(before, pos.copy(), m, san, moves.toList(), cap, humanWhite, byHuman, "Máy · Cấp 3")
    }

    @Test fun everySayHasLines_andEveryTopicHasASay() {
        for (s in Say.entries) assertTrue("Say $s trống", TeacherLines.lines(s).isNotEmpty())
        for (t in Topic.entries) Say.valueOf("T_" + t.name)
    }

    @Test fun placeholdersAreKnown() {
        val known = setOf("{me}", "{Me}", "{you}", "{You}", "{san}", "{piece}", "{sq}", "{file}", "{n}", "{opening}", "{bot}", "{target}")
        val re = Regex("\\{[A-Za-z]+\\}")
        for ((say, list) in TeacherLines.all()) for (l in list) for (m in re.findAll(l)) {
            assertTrue("Ký hiệu lạ ${m.value} trong $say: $l", m.value in known)
        }
    }

    @Test fun lineCountIsRich() {
        assertTrue(TeacherLines.all().values.sumOf { it.size } >= 300)
    }

    @Test fun detectsHangingQueen() {
        val pos = Position.fromFen("4k3/8/8/3q4/8/2N5/8/4K3 w - - 0 1")
        val seen = BoardReader.read(pos, humanWhite = true)
        assertTrue(seen.any { it.topic == Topic.HANGING_THEIRS })
    }

    @Test fun findsMateInOne() {
        val pos = Position.fromFen("6k1/5ppp/8/8/8/8/8/R3K3 w - - 0 1")
        assertTrue(BoardReader.mateInOne(pos) >= 0)
        assertTrue(BoardReader.read(pos, true).any { it.topic == Topic.MATE_IN_ONE_AVAILABLE })
    }

    @Test fun findsKnightFork() {
        val pos = Position.fromFen("2r1k3/8/8/8/2N5/8/8/4K3 w - - 0 1")
        val m = BoardReader.forkMove(pos)
        assertTrue(m >= 0)
        assertEquals("c4d6", moveUci(m))
    }

    @Test fun warnsWhenQueenWalksIntoPawn() {
        val pos = Position.fromFen("4k3/8/2p5/3p4/8/8/8/3QK3 w - - 0 1")
        val brain = TeacherBrain(Persona.STRICT, talkiness = 0, rnd = Random(1))
        val lines = brain.onMove(ctx(pos, "d1d5", mutableListOf(), humanWhite = true))
        assertTrue(lines.isNotEmpty())
        assertEquals(Say.H_MOVED_INTO_DANGER, lines[0].say)
    }

    @Test fun talksEveryMoveWhenTalkative_andNeverLeavesPlaceholders() {
        val pos = Position.start()
        val moves = mutableListOf<Int>()
        val brain = TeacherBrain(Persona.FUNNY, talkiness = 2, rnd = Random(7))
        for (u in listOf("e2e4", "e7e5", "g1f3", "b8c6", "f1c4", "g8f6", "f3g5", "d7d5", "e4d5", "f6d5")) {
            val lines = brain.onMove(ctx(pos, u, moves, humanWhite = true))
            assertTrue("Thầy im lặng ở nước $u", lines.isNotEmpty())
            for (l in lines) {
                assertFalse(l.text.isBlank())
                assertFalse("Còn ký hiệu: ${l.text}", l.text.contains("{") || l.text.contains("}"))
            }
        }
    }

    @Test fun quietModeIsQuieter() {
        val pos = Position.start()
        val moves = mutableListOf<Int>()
        val brain = TeacherBrain(Persona.GENTLE, talkiness = 0, rnd = Random(3))
        val lines = brain.onMove(ctx(pos, "a2a3", moves, humanWhite = true))
        assertTrue(lines.isEmpty())
    }

    @Test fun explainListsWhatTheTeacherSees() {
        val pos = Position.fromFen("4k3/8/8/3q4/8/2N5/8/4K3 w - - 0 1")
        val brain = TeacherBrain(Persona.GENTLE, 2, Random(5))
        val out = brain.explain(pos, true, "Máy", 0)
        assertTrue(out.size >= 2)
        assertEquals(Say.ASK_INTRO, out[0].say)
    }
}
