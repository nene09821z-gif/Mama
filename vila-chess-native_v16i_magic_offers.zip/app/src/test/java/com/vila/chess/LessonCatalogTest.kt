package com.vila.chess

import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.EMPTY
import com.vila.chess.core.Position
import com.vila.chess.game.LessonCatalog
import com.vila.chess.game.LessonKind
import com.vila.chess.game.LessonProgress
import com.vila.chess.game.LessonProgressCodec
import com.vila.chess.game.LessonQuota
import com.vila.chess.game.PuzzleSession
import com.vila.chess.game.PuzzleStep
import com.vila.chess.game.parseUciMove
import com.vila.chess.core.moveFrom
import com.vila.chess.core.moveTo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class LessonCatalogTest {

    @Test
    fun idsAreUniqueAndLookupWorks() {
        val ids = LessonCatalog.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        for (l in LessonCatalog.all) {
            assertNotNull(LessonCatalog.find(l.id))
            assertNotNull(LessonCatalog.courseOf(l.id))
        }
        assertTrue("cần nhiều bài", LessonCatalog.all.size >= 20)
        // id lưu thành chuỗi phân tách bằng dấu phẩy ⇒ không được chứa dấu phẩy
        assertTrue(ids.none { it.contains(',') || it.isEmpty() })
    }

    @Test
    fun everyFenIsValidAndPreviewHasPieces() {
        for (l in LessonCatalog.all) {
            val pos = Position.fromFen(l.fen)
            assertFalse("bên không đi bị chiếu: " + l.id, pos.inCheck(!pos.whiteToMove))
            assertTrue("preview rỗng: " + l.id, l.preview.any { it != EMPTY })
        }
    }

    @Test
    fun everyTacticSolutionPlaysThroughPuzzleSession() {
        for (l in LessonCatalog.all.filter { it.kind == LessonKind.TACTIC }) {
            val s = PuzzleSession(l.toPuzzle())
            assertTrue("dữ liệu hỏng: " + l.id, s.valid)
            val pos = Position.fromFen(l.fen)
            pos.make(parseUciMove(pos, l.moves[0])!!)
            var i = 1
            while (i < l.moves.size) {
                val m = parseUciMove(pos, l.moves[i])
                assertNotNull("nước không hợp lệ ở " + l.id + " #" + i, m)
                val r = s.submit(moveFrom(m!!), moveTo(m))
                assertTrue(l.id, r is PuzzleStep.Correct)
                pos.make(m)
                i++
                val reply = (r as PuzzleStep.Correct).reply
                if (reply != null) {
                    pos.make(reply)
                    i++
                }
            }
            assertTrue("chưa giải xong: " + l.id, s.solved)
        }
    }

    @Test
    fun freeGetsFivePerDayMembersUnlimited() {
        assertEquals(5, LessonQuota.limit(MembershipTier.FREE))
        assertNull(LessonQuota.limit(MembershipTier.GOLD))
        assertNull(LessonQuota.limit(MembershipTier.FAMILY))
    }

    @Test
    fun sixthNewLessonIsBlockedButRestartIsFree() {
        val started = setOf("a", "b", "c", "d", "e")
        assertEquals(0, LessonQuota.remaining(5, started.size))
        assertFalse(LessonQuota.canStart(5, started, "f"))
        assertTrue(LessonQuota.canStart(5, started, "c"))
        assertTrue(LessonQuota.canStart(null, started, "f"))
        assertEquals(3, LessonQuota.remaining(5, 2))
    }

    @Test
    fun newDayResetsStartedButKeepsDone() {
        val p = LessonProgress(done = setOf("kq"), day = "2026-11-09", startedToday = setOf("a", "b", "c", "d", "e"))
        assertEquals(p, p.rolled("2026-11-09"))
        val next = p.rolled("2026-11-10")
        assertEquals("2026-11-10", next.day)
        assertTrue(next.startedToday.isEmpty())
        assertEquals(setOf("kq"), next.done)
        assertTrue(LessonQuota.canStart(5, next.startedToday, "new_lesson"))
    }

    @Test
    fun premiumCoursesNeedMembership() {
        val pro = LessonCatalog.courses.first { it.premium }
        assertFalse(LessonQuota.canOpenCourse(pro, MembershipTier.FREE))
        assertTrue(LessonQuota.canOpenCourse(pro, MembershipTier.GOLD))
        val free = LessonCatalog.courses.first { !it.premium }
        assertTrue(LessonQuota.canOpenCourse(free, MembershipTier.FREE))
    }

    @Test
    fun nextUpSkipsDoneAndLockedCourses() {
        val first = LessonCatalog.nextUp(emptySet()) { true }!!
        assertEquals(LessonCatalog.all.first().id, first.id)
        val second = LessonCatalog.nextUp(setOf(first.id)) { true }!!
        assertEquals(LessonCatalog.all[1].id, second.id)
        val everyFree = LessonCatalog.courses.filter { !it.premium }.flatMap { it.lessons }.map { it.id }.toSet()
        assertNull(LessonCatalog.nextUp(everyFree) { !it.premium })
        assertNotNull(LessonCatalog.nextUp(everyFree) { true })
    }

    @Test
    fun midnightIsAfterNowAndWithinOneDay() {
        val c = Calendar.getInstance()
        c.set(2026, Calendar.NOVEMBER, 9, 23, 59, 30)
        c.set(Calendar.MILLISECOND, 0)
        val now = c.timeInMillis
        val mid = LessonQuota.nextMidnightMs(now)
        assertTrue(mid > now)
        assertTrue(mid - now <= 24L * 3600_000L)
        assertEquals("00:00:30", LessonQuota.countdownText(now))
        assertEquals(LessonQuota.dayKey(now).substring(0, 7), "2026-11")
        assertFalse(LessonQuota.dayKey(now) == LessonQuota.dayKey(mid))
    }

    @Test
    fun codecRoundTrip() {
        val s = setOf("kq", "m1_fool", "t_pin")
        assertEquals(s, LessonProgressCodec.decode(LessonProgressCodec.encode(s)))
        assertTrue(LessonProgressCodec.decode(null).isEmpty())
        assertTrue(LessonProgressCodec.decode("").isEmpty())
    }
}
