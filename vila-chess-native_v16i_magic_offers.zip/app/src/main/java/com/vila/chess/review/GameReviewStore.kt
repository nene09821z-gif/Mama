package com.vila.chess.review

import android.content.Context
import java.io.File

class GameReviewStore(context: Context) {
    private val app = context.applicationContext
    private val dir = File(app.filesDir, "reviews").apply { mkdirs() }
    private fun file(id: String) = File(dir, "${id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}.json")

    fun exists(gameId: String) = file(gameId).exists()

    /** Id của mọi ván đã có file phân tích (một lần liệt kê thư mục, nhanh hơn hàng nghìn lần exists). */
    fun ids(): Set<String> =
        dir.list()?.filter { it.endsWith(".json") }?.map { it.removeSuffix(".json") }?.toSet() ?: emptySet()

    /** Xóa cả file JSON lẫn kết quả trong Room. Gọi từ luồng nền (Room chặn luồng chính). */
    fun delete(gameId: String) {
        runCatching { file(gameId).delete() }
        runCatching { com.vila.chess.review.db.ReviewDatabase.get(app).analysisDao().deleteGameBlocking(gameId) }
    }

    fun save(r: GameReview) {
        // Ghi tạm rồi đổi tên: không bao giờ để file review dở dang.
        val target = file(r.gameId)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(ReviewJson.encode(r))
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    /** null = chưa có (chưa phân tích xong) hoặc file hỏng. Đọc được cả file phiên bản 1. */
    fun load(gameId: String): GameReview? {
        val f = file(gameId)
        if (!f.exists()) return null
        val r = runCatching { ReviewJson.decode(f.readText()) }.getOrNull()
        if (r == null || !r.isUsable()) { f.delete(); return null }
        return r
    }
}
