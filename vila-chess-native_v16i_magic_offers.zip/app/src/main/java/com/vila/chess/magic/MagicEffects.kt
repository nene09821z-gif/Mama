package com.vila.chess.magic

import com.vila.chess.core.BISHOP
import com.vila.chess.core.EMPTY
import com.vila.chess.core.KING
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.makePiece
import com.vila.chess.core.pieceType
import com.vila.chess.core.sqFile
import com.vila.chess.core.sqRank
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Loại ô người chơi phải chạm khi dùng bài. */
enum class Pick { OWN_PIECE, ENEMY_PIECE, EMPTY_SQUARE, ANY_SQUARE }

/** Vùng bàn cờ. HOME2 / HALF tính theo phía của người dùng bài; còn lại là tuyệt đối. */
enum class Region(val label: String) {
    ANY("bất kỳ đâu"),
    HOME2("2 hàng phía mình"),
    HALF("nửa bàn phía mình"),
    FILES_AD("cột a–d"),
    FILES_EH("cột e–h"),
    RANKS_LOW("hàng 1–4"),
    RANKS_HIGH("hàng 5–8");

    fun contains(sq: Int, white: Boolean): Boolean {
        val r = sqRank(sq)
        val f = sqFile(sq)
        return when (this) {
            ANY -> true
            HOME2 -> if (white) r <= 1 else r >= 6
            HALF -> if (white) r <= 3 else r >= 4
            FILES_AD -> f <= 3
            FILES_EH -> f >= 4
            RANKS_LOW -> r <= 3
            RANKS_HIGH -> r >= 4
        }
    }
}

fun pieceNameVi(type: Int): String = when (type) {
    PAWN -> "Tốt"
    KNIGHT -> "Mã"
    BISHOP -> "Tượng"
    ROOK -> "Xe"
    QUEEN -> "Hậu"
    KING -> "Vua"
    else -> "quân bất kỳ"
}

/** Một hiệu ứng phép thuật. Chỉ định nghĩa luật; việc kiểm tra thế cờ sau khi áp dụng do [MagicGame] làm trên bản sao. */
interface MagicEffect {
    val picks: List<Pick>
    val icon: String
    val title: String
    val description: String

    /** Ô có thể chọn cho bước [step] (0-based) khi đã chọn [chosen]. Lọc thô: kết quả cuối được kiểm lại bằng cách thử áp dụng. */
    fun candidates(s: MagicState, white: Boolean, step: Int, chosen: List<Int>): List<Int>

    /** Áp dụng lên [s] (luôn là bản sao). false = không áp dụng được. */
    fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean
}

abstract class Effect(final override val picks: List<Pick>) : MagicEffect {
    override fun candidates(s: MagicState, white: Boolean, step: Int, chosen: List<Int>): List<Int> =
        (0 until 64).filter { sq -> pickOk(s, white, picks[step], sq) && squareOk(s, white, step, chosen, sq) }

    private fun pickOk(s: MagicState, white: Boolean, pick: Pick, sq: Int): Boolean = when (pick) {
        Pick.OWN_PIECE -> s.own(sq, white) && !s.isKing(sq)
        Pick.ENEMY_PIECE -> s.enemy(sq, white) && !s.isKing(sq)
        Pick.EMPTY_SQUARE -> s.pos.board[sq] == EMPTY
        Pick.ANY_SQUARE -> true
    }

    protected open fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int): Boolean = true
    protected fun typeAt(s: MagicState, sq: Int) = pieceType(s.pos.board[sq])
}

private fun chebyshev(a: Int, b: Int) = max(abs(sqRank(a) - sqRank(b)), abs(sqFile(a) - sqFile(b)))
private fun typeOk(filter: Int, type: Int) = filter == 0 || type == filter
private fun rangeLabel(dist: Int) = if (dist == 0) "bất kỳ đâu" else "trong $dist ô"

/** Triệu hồi một quân của mình lên ô trống. */
class Spawn(val type: Int, val region: Region) : Effect(listOf(Pick.EMPTY_SQUARE)) {
    override val icon = "✨"
    override val title = "Triệu hồi ${pieceNameVi(type)} (${region.label})"
    override val description = "Đặt thêm 1 ${pieceNameVi(type)} của bạn lên ô trống ở ${region.label}."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = region.contains(sq, white)
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (s.pos.board[t[0]] != EMPTY || !region.contains(t[0], white)) return false
        s.placePiece(t[0], makePiece(type, white))
        return true
    }
}

/** Tiêu diệt một quân địch (không phải Vua). */
class Smite(val type: Int, val region: Region) : Effect(listOf(Pick.ENEMY_PIECE)) {
    override val icon = "🔥"
    override val title = (if (type == 0) "Thiêu đốt" else "Thiêu ${pieceNameVi(type)}") + " (${region.label})"
    override val description = "Tiêu diệt 1 ${pieceNameVi(type)} địch (không phải Vua) ở ${region.label}."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) =
        typeOk(type, typeAt(s, sq)) && region.contains(sq, white)
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || s.isKing(t[0]) || !typeOk(type, typeAt(s, t[0])) || !region.contains(t[0], white)) return false
        s.removePiece(t[0])
        return true
    }
}

/** Phong cấp Tốt của mình ngay lập tức. */
class Promote(val to: Int) : Effect(listOf(Pick.OWN_PIECE)) {
    override val icon = "👑"
    override val title = "Thăng cấp ${pieceNameVi(to)}"
    override val description = "Biến 1 Tốt của bạn thành ${pieceNameVi(to)}."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = typeAt(s, sq) == PAWN
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.own(t[0], white) || typeAt(s, t[0]) != PAWN) return false
        s.placePiece(t[0], makePiece(to, white))
        return true
    }
}

/** Hạ cấp một quân địch. */
class Demote(val from: Int, val to: Int) : Effect(listOf(Pick.ENEMY_PIECE)) {
    override val icon = "⬇️"
    override val title = "Giáng cấp ${pieceNameVi(from)} → ${pieceNameVi(to)}"
    override val description = "Biến 1 ${pieceNameVi(from)} địch thành ${pieceNameVi(to)}."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = typeAt(s, sq) == from
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || typeAt(s, t[0]) != from) return false
        s.placePiece(t[0], makePiece(to, !white))
        return true
    }
}

/** Thao túng: biến quân địch (cấp tối đa [maxType]) thành quân của mình. */
class Charm(val maxType: Int) : Effect(listOf(Pick.ENEMY_PIECE)) {
    override val icon = "💜"
    override val title = "Mê hoặc (≤ ${pieceNameVi(maxType)})"
    override val description = "Chiêu mộ 1 quân địch có cấp tối đa ${pieceNameVi(maxType)} về phe bạn."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = typeAt(s, sq) <= maxType
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || s.isKing(t[0]) || typeAt(s, t[0]) > maxType) return false
        s.placePiece(t[0], makePiece(typeAt(s, t[0]), white))
        return true
    }
}

/** Hoán đổi vị trí hai quân (không phải Vua): của mình với của mình, hoặc của mình với của địch. */
class Swap(val withEnemy: Boolean) : Effect(listOf(Pick.OWN_PIECE, if (withEnemy) Pick.ENEMY_PIECE else Pick.OWN_PIECE)) {
    override val icon = "🔄"
    override val title = if (withEnemy) "Hoán vị cưỡng đoạt" else "Hoán vị đồng minh"
    override val description = if (withEnemy) "Đổi chỗ 1 quân của bạn với 1 quân địch." else "Đổi chỗ 2 quân của bạn."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = step == 0 || sq != chosen[0]
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val a = t[0]
        val b = t[1]
        if (a == b || !s.own(a, white) || s.isKing(a) || s.isKing(b)) return false
        if (if (withEnemy) !s.enemy(b, white) else !s.own(b, white)) return false
        s.swapPieces(a, b)
        return true
    }
}

/** Dịch chuyển tức thời một quân của mình tới ô trống. */
class Teleport(val type: Int, val dist: Int) : Effect(listOf(Pick.OWN_PIECE, Pick.EMPTY_SQUARE)) {
    override val icon = "🌀"
    override val title = "Dịch chuyển ${pieceNameVi(type)} (${rangeLabel(dist)})"
    override val description = "Đưa 1 ${pieceNameVi(type)} của bạn tới ô trống ${rangeLabel(dist)} (cách quân đó)."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) =
        if (step == 0) typeAt(s, sq) == type else dist == 0 || chebyshev(chosen[0], sq) <= dist
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.own(t[0], white) || typeAt(s, t[0]) != type || s.isKing(t[0])) return false
        if (s.pos.board[t[1]] != EMPTY || (dist != 0 && chebyshev(t[0], t[1]) > dist)) return false
        s.movePiece(t[0], t[1])
        return true
    }
}

/** Hướng đẩy tính từ phía người dùng bài. */
enum class PushDir(val label: String) { AWAY("ra xa mình"), TOWARD("về phía mình"), LEFT("sang trái (về cột a)"), RIGHT("sang phải (về cột h)") }

/** Đẩy một quân địch [dist] ô theo hướng [dir]; đường đi và ô đến phải trống. */
class Push(val dir: PushDir, val dist: Int) : Effect(listOf(Pick.ENEMY_PIECE)) {
    override val icon = "💨"
    override val title = "Cuồng phong ${dir.label} ($dist ô)"
    override val description = "Đẩy 1 quân địch $dist ô ${dir.label} (đường đi phải trống)."
    private fun dest(from: Int, white: Boolean, step: Int): Int {
        val fwd = if (white) 1 else -1
        val r = sqRank(from) + when (dir) { PushDir.AWAY -> fwd * step; PushDir.TOWARD -> -fwd * step; else -> 0 }
        val f = sqFile(from) + when (dir) { PushDir.LEFT -> -step; PushDir.RIGHT -> step; else -> 0 }
        return if (r in 0..7 && f in 0..7) r * 8 + f else -1
    }
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int): Boolean =
        (1..dist).all { k -> val d = dest(sq, white, k); d >= 0 && s.pos.board[d] == EMPTY }
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || s.isKing(t[0]) || !squareOk(s, white, 0, emptyList(), t[0])) return false
        s.movePiece(t[0], dest(t[0], white, dist))
        return true
    }
}

/** Đóng băng một quân địch: không thể đi trong [turns] lượt của đối thủ. */
class Freeze(val type: Int, val turns: Int) : Effect(listOf(Pick.ENEMY_PIECE)) {
    override val icon = "❄️"
    override val title = "Đóng băng${if (type == 0) "" else " ${pieceNameVi(type)}"} ($turns lượt)"
    override val description = "1 ${pieceNameVi(type)} địch không thể di chuyển trong $turns lượt của đối thủ."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = typeOk(type, typeAt(s, sq))
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || s.isKing(t[0]) || !typeOk(type, typeAt(s, t[0]))) return false
        s.frozen[t[0]] = s.turnNo + 2 * turns
        return true
    }
}

/** Khiên: một quân của mình không bị ăn trong [turns] lượt của đối thủ. */
class Shield(val type: Int, val turns: Int) : Effect(listOf(Pick.OWN_PIECE)) {
    override val icon = "🛡️"
    override val title = "Khiên${if (type == 0) "" else " ${pieceNameVi(type)}"} ($turns lượt)"
    override val description = "1 ${pieceNameVi(type)} của bạn không thể bị ăn trong $turns lượt của đối thủ."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = typeOk(type, typeAt(s, sq))
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.own(t[0], white) || s.isKing(t[0]) || !typeOk(type, typeAt(s, t[0]))) return false
        s.shield[t[0]] = s.turnNo + 2 * turns
        return true
    }
}

/** Sau nước đi của lượt này, đi thêm 1 nước nữa (bị huỷ nếu nước đầu chiếu Vua địch hoặc không còn nước hợp lệ). */
class ExtraMove(val type: Int) : Effect(emptyList()) {
    override val icon = "⏩"
    override val title = "Thần tốc${if (type == 0) "" else " (${pieceNameVi(type)})"}"
    override val description = "Sau nước đi của lượt này, đi thêm 1 nước nữa${if (type == 0) "" else " bằng ${pieceNameVi(type)}"}. Huỷ nếu nước đầu chiếu Vua địch."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (s.extraNext >= 0) return false
        s.extraNext = type
        return true
    }
}

/** Phong ấn: đối thủ không được dùng bài trong [turns] lượt của họ. */
class SpellLock(val turns: Int) : Effect(emptyList()) {
    override val icon = "🔒"
    override val title = "Phong ấn ($turns lượt)"
    override val description = "Đối thủ không thể dùng bài trong $turns lượt của họ."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        s.lockedUntil[idx(!white)] = s.turnNo + 2 * turns
        return true
    }
}

class ManaDrain(val amount: Int) : Effect(emptyList()) {
    override val icon = "🧛"
    override val title = "Hút mana ($amount)"
    override val description = "Đối thủ mất $amount mana."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val i = idx(!white)
        if (s.mana[i] <= 0) return false
        s.mana[i] = max(0, s.mana[i] - amount)
        return true
    }
}

class ManaGain(val amount: Int) : Effect(emptyList()) {
    override val icon = "💧"
    override val title = "Nghi lễ mana ($amount)"
    override val description = "Nhận ngay $amount mana (tối đa ${MagicState.MANA_MAX})."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val i = idx(white)
        s.mana[i] = minOf(MagicState.MANA_MAX, s.mana[i] + amount)
        return true
    }
}

class DrawCards(val count: Int) : Effect(emptyList()) {
    override val icon = "🃏"
    override val title = "Tiên tri ($count bài)"
    override val description = "Rút thêm $count lá bài."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (s.hands[idx(white)].size >= MagicState.HAND_MAX) return false
        s.draw(white, count)
        return true
    }
}

class Discard(val count: Int) : Effect(emptyList()) {
    override val icon = "🌪️"
    override val title = "Bão bài ($count)"
    override val description = "Đối thủ bỏ ngẫu nhiên $count lá bài trên tay."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val hand = s.hands[idx(!white)]
        if (hand.isEmpty()) return false
        repeat(minOf(count, hand.size)) { hand.removeAt(s.rng.nextInt(hand.size)) }
        return true
    }
}

/** Hồi sinh quân đã mất của mình (type = 0: quân mất gần nhất). */
class Resurrect(val type: Int, val region: Region) : Effect(listOf(Pick.EMPTY_SQUARE)) {
    override val icon = "🕊️"
    override val title = "Hồi sinh${if (type == 0) "" else " ${pieceNameVi(type)}"} (${region.label})"
    override val description = "Đưa ${if (type == 0) "quân vừa mất gần nhất" else "1 ${pieceNameVi(type)} đã mất"} của bạn trở lại ô trống ở ${region.label}."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) = region.contains(sq, white)
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val lost = s.lost[idx(white)]
        val at = if (type == 0) lost.lastIndex else lost.lastIndexOf(type)
        if (at < 0 || s.pos.board[t[0]] != EMPTY || !region.contains(t[0], white)) return false
        val kind = lost.removeAt(at)
        s.placePiece(t[0], makePiece(kind, white))
        return true
    }
}

/** Dịch chuyển Vua tới ô trống (phải an toàn). */
class KingBlink(val dist: Int) : Effect(listOf(Pick.EMPTY_SQUARE)) {
    override val icon = "🏰"
    override val title = "Vương miện dịch chuyển (${rangeLabel(dist)})"
    override val description = "Đưa Vua của bạn tới ô trống ${rangeLabel(dist)} (phải an toàn)."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int): Boolean {
        val k = s.pos.kingSquare(white)
        return k >= 0 && (dist == 0 || chebyshev(k, sq) <= dist)
    }
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val k = s.pos.kingSquare(white)
        if (k < 0 || s.pos.board[t[0]] != EMPTY || (dist != 0 && chebyshev(k, t[0]) > dist)) return false
        s.movePiece(k, t[0])
        return true
    }
}

/** Bẫy: quân địch (không phải Vua) bước vào ô này sẽ bị tiêu diệt. */
class Trap(val turns: Int) : Effect(listOf(Pick.EMPTY_SQUARE)) {
    override val icon = "🕳️"
    override val title = "Bẫy sập ($turns lượt)"
    override val description = "Đặt bẫy lên ô trống: quân địch (trừ Vua) bước vào sẽ bị tiêu diệt. Tồn tại $turns lượt của mỗi bên."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (s.pos.board[t[0]] != EMPTY) return false
        s.traps[t[0]] = TrapState(white, s.turnNo + 2 * turns)
        return true
    }
}

/** Sét đánh: tiêu diệt mọi quân địch có cấp tối đa [maxType] trên cột được chọn. */
class Lightning(val maxType: Int) : Effect(listOf(Pick.ANY_SQUARE)) {
    override val icon = "⚡"
    override val title = "Sét đánh (≤ ${pieceNameVi(maxType)})"
    override val description = "Chọn 1 cột: tiêu diệt mọi quân địch cấp tối đa ${pieceNameVi(maxType)} trên cột đó (trừ Vua)."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val f = sqFile(t[0])
        var hit = false
        for (r in 0..7) {
            val sq = r * 8 + f
            if (s.enemy(sq, white) && !s.isKing(sq) && typeAt(s, sq) <= maxType) { s.removePiece(sq); hit = true }
        }
        return hit
    }
}

/** Nhân bản một quân của mình sang ô trống kề bên. */
class Clone(val type: Int) : Effect(listOf(Pick.OWN_PIECE, Pick.EMPTY_SQUARE)) {
    override val icon = "👥"
    override val title = "Phân thân ${pieceNameVi(type)}"
    override val description = "Nhân bản 1 ${pieceNameVi(type)} của bạn sang ô trống kề bên."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) =
        if (step == 0) typeAt(s, sq) == type else chebyshev(chosen[0], sq) == 1
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.own(t[0], white) || typeAt(s, t[0]) != type || s.isKing(t[0])) return false
        if (s.pos.board[t[1]] != EMPTY || chebyshev(t[0], t[1]) != 1) return false
        s.placePiece(t[1], makePiece(type, white))
        return true
    }
}

/** Mọi Tốt của mình (trong [region]) tiến 1 ô nếu ô phía trước trống (không phong cấp). */
class PawnStorm(val region: Region) : Effect(emptyList()) {
    override val icon = "🌊"
    override val title = "Triều dâng Tốt (${region.label})"
    override val description = "Mọi Tốt của bạn ở ${region.label} tiến 1 ô nếu ô phía trước trống (không tự phong cấp)."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val dir = if (white) 1 else -1
        val order = (0 until 64).filter { s.own(it, white) && typeAt(s, it) == PAWN && region.contains(it, white) }
            .sortedByDescending { sqRank(it) * dir }
        var moved = false
        for (sq in order) {
            val r = sqRank(sq) + dir
            if (r !in 1..6) continue
            val to = r * 8 + sqFile(sq)
            if (s.pos.board[to] == EMPTY) { s.movePiece(sq, to); moved = true }
        }
        return moved
    }
}

// ====================================================================== Bài giải trí (ngẫu nhiên / vui nhộn)

/** Đánh dấu các bài giải trí: kết quả có yếu tố may rủi hoặc vui nhộn. */
interface FunEffect

private fun mirrorSq(sq: Int) = sqRank(sq) * 8 + (7 - sqFile(sq))

/** Tung xúc xắc: phần thưởng ngẫu nhiên. */
class DiceRoll : Effect(emptyList()), FunEffect {
    override val icon = "🎲"
    override val title = "Xúc xắc may rủi"
    override val description = "Tung xúc xắc: 1–2 nhận 1 mana · 3–4 nhận 3 mana · 5 rút 2 bài · 6 nhận 5 mana và rút 1 bài."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val i = idx(white)
        val roll = s.rng.nextInt(6) + 1
        when (roll) {
            1, 2 -> s.mana[i] = min(MagicState.MANA_MAX, s.mana[i] + 1)
            3, 4 -> s.mana[i] = min(MagicState.MANA_MAX, s.mana[i] + 3)
            5 -> s.draw(white, 2)
            else -> { s.mana[i] = min(MagicState.MANA_MAX, s.mana[i] + 5); s.draw(white, 1) }
        }
        s.log = "🎲 Tung được $roll!"
        return true
    }
}

/** Tung đồng xu: ngửa thì diệt quân địch đã chọn, sấp thì nhận mana an ủi. */
class CoinFlip : Effect(listOf(Pick.ENEMY_PIECE)), FunEffect {
    override val icon = "🪙"
    override val title = "Tung đồng xu"
    override val description = "Chọn 1 quân địch (không phải Vua) rồi tung đồng xu: NGỬA tiêu diệt quân đó, SẤP bạn nhận 2 mana."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.enemy(t[0], white) || s.isKing(t[0])) return false
        if (s.rng.nextBoolean()) {
            s.removePiece(t[0])
            s.log = "🪙 NGỬA! Quân địch bị tiêu diệt."
        } else {
            val i = idx(white)
            s.mana[i] = min(MagicState.MANA_MAX, s.mana[i] + 2)
            s.log = "🪙 SẤP! Bạn nhận 2 mana."
        }
        return true
    }
}

/** Gương soi: nhân bản 1 quân của mình sang ô đối xứng qua trục dọc giữa bàn (nếu ô đó trống). */
class Mirror(val type: Int) : Effect(listOf(Pick.OWN_PIECE)), FunEffect {
    override val icon = "🎭"
    override val title = "Gương soi ${pieceNameVi(type)}"
    override val description = "Nhân bản 1 ${pieceNameVi(type)} của bạn sang ô đối xứng qua giữa bàn cờ (ô đó phải trống)."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) =
        typeAt(s, sq) == type && s.pos.board[mirrorSq(sq)] == EMPTY
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (!s.own(t[0], white) || s.isKing(t[0]) || typeAt(s, t[0]) != type) return false
        val m = mirrorSq(t[0])
        if (s.pos.board[m] != EMPTY) return false
        s.placePiece(m, makePiece(type, white))
        return true
    }
}

/** Vòng quay may mắn: 1 quân địch ngẫu nhiên bị đóng băng, 1 quân của bạn ngẫu nhiên được khiên (1 lượt). */
class LuckyWheel : Effect(emptyList()), FunEffect {
    override val icon = "🎡"
    override val title = "Vòng quay may mắn"
    override val description = "Vòng quay chọn ngẫu nhiên 1 quân địch để đóng băng và 1 quân của bạn để che khiên (đều 1 lượt, không tính Vua)."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val foes = (0 until 64).filter { s.enemy(it, white) && !s.isKing(it) }
        val mine = (0 until 64).filter { s.own(it, white) && !s.isKing(it) }
        if (foes.isEmpty() || mine.isEmpty()) return false
        val f = foes[s.rng.nextInt(foes.size)]
        val m = mine[s.rng.nextInt(mine.size)]
        s.frozen[f] = s.turnNo + 2
        s.shield[m] = s.turnNo + 2
        s.log = "🎡 Băng ${pieceNameVi(typeAt(s, f))} địch, khiên ${pieceNameVi(typeAt(s, m))} của bạn."
        return true
    }
}

/** Mũ ảo thuật: đặt một quân NGẪU NHIÊN (hiếm khi là Hậu) lên ô trống ở nửa bàn phía mình (hàng 2–7). */
class MagicHat : Effect(listOf(Pick.EMPTY_SQUARE)), FunEffect {
    override val icon = "🎩"
    override val title = "Mũ ảo thuật"
    override val description = "Đặt lên 1 ô trống ở nửa bàn phía bạn một quân ngẫu nhiên: Tốt 40% · Mã 25% · Tượng 20% · Xe 10% · Hậu 5%."
    override fun squareOk(s: MagicState, white: Boolean, step: Int, chosen: List<Int>, sq: Int) =
        Region.HALF.contains(sq, white) && sqRank(sq) in 1..6
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (s.pos.board[t[0]] != EMPTY || !Region.HALF.contains(t[0], white) || sqRank(t[0]) !in 1..6) return false
        val roll = s.rng.nextInt(100)
        val type = when {
            roll < 40 -> PAWN
            roll < 65 -> KNIGHT
            roll < 85 -> BISHOP
            roll < 95 -> ROOK
            else -> QUEEN
        }
        s.placePiece(t[0], makePiece(type, white))
        s.log = "🎩 Ra ${pieceNameVi(type)}!"
        return true
    }
}

/** Mưa sao băng: tiêu diệt ngẫu nhiên tối đa 2 Tốt địch. */
class Meteor : Effect(emptyList()), FunEffect {
    override val icon = "🌠"
    override val title = "Mưa sao băng"
    override val description = "Những ngôi sao rơi xuống: tiêu diệt ngẫu nhiên tối đa 2 Tốt địch."
    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        val pawns = (0 until 64).filter { s.enemy(it, white) && typeAt(s, it) == PAWN }.toMutableList()
        if (pawns.isEmpty()) return false
        java.util.Collections.shuffle(pawns, s.rng)
        val n = min(2, pawns.size)
        for (k in 0 until n) s.removePiece(pawns[k])
        s.log = "🌠 Trúng $n Tốt địch!"
        return true
    }
}

/** Gộp nhiều hiệu ứng độc lập thành một lá (dùng cho bài đặc quyền). Mục tiêu của các phần nối tiếp nhau. */
class Combo(
    private val parts: List<MagicEffect>,
    override val title: String,
    override val icon: String,
    /** true = "Tuyệt kỹ" VIP: giá do thiết kế riêng (mạnh hơn mua rời), không phải tổng giá + 1. */
    val signature: Boolean = false,
) : MagicEffect {
    override val picks: List<Pick> = parts.flatMap { it.picks }
    fun partsForTest(): List<MagicEffect> = parts
    override val description: String = (if (signature) "Tuyệt kỹ — " else "") + "Gồm: " + parts.joinToString(" + ") { it.title } + "."

    override fun candidates(s: MagicState, white: Boolean, step: Int, chosen: List<Int>): List<Int> {
        var off = 0
        // Mô phỏng các phần đã chọn xong trên bản sao để mục tiêu phần sau tính theo thế cờ mới.
        var cur = s
        for (p in parts) {
            val n = p.picks.size
            if (step < off + n) return p.candidates(cur, white, step - off, chosen.subList(off, minOf(chosen.size, off + n)))
            val sim = cur.copy()
            if (!p.apply(sim, white, chosen.subList(off, off + n))) return emptyList()
            cur = sim
            off += n
        }
        return emptyList()
    }

    override fun apply(s: MagicState, white: Boolean, t: List<Int>): Boolean {
        if (t.size != picks.size) return false
        var off = 0
        for (p in parts) {
            val n = p.picks.size
            if (!p.apply(s, white, t.subList(off, off + n))) return false
            off += n
        }
        return true
    }
}
