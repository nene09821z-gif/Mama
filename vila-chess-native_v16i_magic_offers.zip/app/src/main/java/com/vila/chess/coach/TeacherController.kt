package com.vila.chess.coach

import android.content.Context
import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vila.chess.core.EMPTY
import com.vila.chess.core.Position
import com.vila.chess.core.moveTo
import com.vila.chess.core.pieceType
import com.vila.chess.game.EndReason
import com.vila.chess.game.GameSession
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.OpeningBook
import java.util.Locale

/**
 * Trạng thái của thầy cho giao diện: lời đang nói, hàng đợi, sổ tay, dấu vẽ trên bàn, nơi thầy đang nhìn.
 * [onMarks] được gọi mỗi khi thầy đổi dấu chỉ trên bàn cờ (GameViewModel đẩy vào UiState).
 * Mọi hàm gọi trên luồng chính.
 */
class TeacherController(
    private val app: Context,
    private val prefs: SharedPreferences,
    private val onMarks: (List<Mark>) -> Unit,
) {
    var persona by mutableStateOf(readPersona())
        private set
    /** 0 = ít · 1 = vừa · 2 = nhiều. */
    var talkiness by mutableIntStateOf(prefs.getInt(KEY_TALK, 2).coerceIn(0, 2))
        private set
    var voiceOn by mutableStateOf(prefs.getBoolean(KEY_VOICE, false))
        private set

    var current by mutableStateOf<TeacherLine?>(null)
        private set
    var hasMore by mutableStateOf(false)
        private set
    /** Số nước đã đi (cho đồng hồ "thầy nhắc khi nghĩ lâu"). */
    var ply by mutableIntStateOf(0)
        private set
    /** Ô thầy đang nhìn (-1 = nhìn thẳng) => avatar liếc theo. */
    var lookSquare by mutableIntStateOf(-1)
        private set
    /** Tăng mỗi lần thầy có phản ứng mới => avatar nhún / rung. */
    var reaction by mutableIntStateOf(0)
        private set

    val history = mutableStateListOf<TeacherLine>()

    private val brain = TeacherBrain(persona, talkiness)
    private val queue = ArrayDeque<TeacherLine>()
    private var prevPos: Position? = null
    private var prevCount = 0
    private var voice: TeacherVoice? = null

    var book: OpeningBook?
        get() = brain.book
        set(v) { brain.book = v }

    private fun readPersona(): Persona =
        runCatching { Persona.valueOf(prefs.getString(KEY_PERSONA, Persona.GENTLE.name) ?: Persona.GENTLE.name) }
            .getOrDefault(Persona.GENTLE)

    // ------------------------------------------------------------------ cài đặt

    @JvmName("applyPersona")   // tránh trùng chữ ký JVM với setter private của thuộc tính `persona`
    fun setPersona(p: Persona) {
        persona = p
        brain.persona = p
        prefs.edit().putString(KEY_PERSONA, p.name).apply()
    }

    @JvmName("applyTalkiness")   // tránh trùng chữ ký JVM với setter private của thuộc tính `talkiness`
    fun setTalkiness(v: Int) {
        talkiness = v.coerceIn(0, 2)
        brain.talkiness = talkiness
        prefs.edit().putInt(KEY_TALK, talkiness).apply()
    }

    fun setVoice(on: Boolean) {
        voiceOn = on
        prefs.edit().putBoolean(KEY_VOICE, on).apply()
        if (on) { if (voice == null) voice = TeacherVoice(app) } else voice?.stop()
    }

    // ------------------------------------------------------------------ vòng đời ván

    /** Ván mới: xóa trí nhớ, chào hỏi. [session] đã được tạo (có thể đã có nước đi nếu máy đi trước). */
    fun newGame(session: GameSession, humanWhite: Boolean, endgameLesson: Boolean, botName: String) {
        queue.clear(); history.clear(); hasMore = false; current = null
        onMarks(emptyList())
        prevPos = session.position.copy()
        prevCount = session.records.size
        ply = prevCount
        speak(listOf(brain.start(humanWhite, endgameLesson, botName)))
    }

    /** Gọi sau mỗi lần thế cờ đổi (cuối refreshUi). Chỉ làm việc khi số nước đi thay đổi. */
    fun sync(s: GameSession, humanWhite: Boolean, botName: String) {
        val n = s.records.size
        val before = prevPos
        if (before != null && n == prevCount) return
        val oldCount = prevCount
        val after = s.position.copy()
        prevPos = after
        prevCount = n
        ply = n
        if (before == null || n > oldCount + 1) return      // lần đầu thấy ván (hoặc nhảy cóc): chỉ ghi nhớ thế cờ
        if (n < oldCount) {                                  // hoàn tác
            onMarks(emptyList())
            lookSquare = -1
            speak(listOf(brain.undo(n)))
            return
        }
        val rec = s.records[n - 1]
        val ctx = MoveContext(
            before = before, after = after, move = rec.move, san = rec.san,
            moves = s.records.map { it.move },
            capturedType = if (rec.captured == EMPTY) 0 else pieceType(rec.captured),
            humanWhite = humanWhite, byHuman = rec.whiteMoved == humanWhite, botName = botName,
        )
        lookSquare = moveTo(rec.move)
        val lines = try { brain.onMove(ctx) } catch (e: Exception) { emptyList() }   // thầy lỡ lời cũng không được làm sập ván
        if (lines.isEmpty()) onMarks(emptyList()) else speak(lines)
    }

    /** Bật thầy giữa ván: ghi nhớ thế cờ hiện tại làm mốc, không bình luận các nước đã đi. */
    fun rebase(session: GameSession) {
        prevPos = session.position.copy()
        prevCount = session.records.size
        ply = prevCount
    }

    /** Kết ván. Nếu thầy vừa nói về nước cuối (vd. "Chiếu hết!") thì câu kết ván xếp NGAY SAU, không đè lên. */
    fun gameOver(humanWon: Boolean, draw: Boolean, reason: EndReason, humanResigned: Boolean) {
        val l = brain.gameOver(humanWon, draw, reason, humanResigned, prevCount)
        val cur = current
        if (cur != null && cur.ply == prevCount && cur.ply > 0) {
            history.add(l)
            queue.addLast(l)
            hasMore = true
        } else {
            onMarks(emptyList())
            speak(listOf(l))
        }
    }

    // ------------------------------------------------------------------ tương tác

    fun ask(s: GameSession, humanWhite: Boolean, botName: String) {
        val lines = try { brain.explain(s.position.copy(), humanWhite, botName, prevCount) } catch (e: Exception) { emptyList() }
        if (lines.isNotEmpty()) speak(lines)
    }

    fun hintThinking() = speak(listOf(brain.hintThinking(prevCount)))

    fun hintGiven(san: String, detail: String) = speak(listOf(brain.hint(san, detail, prevCount)))

    fun poke() = speak(listOf(brain.poke(prevCount)))

    /** Người chơi nghĩ lâu. [level] 1..3. Không nói khi thầy đang ở chế độ "ít". */
    fun nudge(level: Int) {
        if (talkiness == 0 && level < 3) return
        speak(listOf(brain.nudge(level, prevCount)))
    }

    /** Nhãn engine đến muộn (chỉ khi bật phân tích từng nước). */
    fun onLabel(label: MoveLabel, san: String, atPly: Int) {
        val warned = current?.say.let { it == Say.H_MOVED_INTO_DANGER || it == Say.H_LEFT_HANGING }
        brain.onLabel(label, san, atPly, warned)?.let { speak(listOf(it)) }
    }

    /** Sang câu kế tiếp trong hàng đợi. true nếu còn câu để chuyển. */
    fun next(): Boolean {
        val n = queue.removeFirstOrNull() ?: return false
        show(n)
        hasMore = queue.isNotEmpty()
        return true
    }

    fun clearMarks() = onMarks(emptyList())

    fun release() {
        voice?.release(); voice = null
    }

    // ------------------------------------------------------------------ nội bộ

    private fun speak(lines: List<TeacherLine>) {
        if (lines.isEmpty()) return
        for (l in lines) history.add(l)
        while (history.size > MAX_HISTORY) history.removeAt(0)
        queue.clear()
        for (i in 1 until lines.size) queue.addLast(lines[i])
        show(lines[0])
        hasMore = queue.isNotEmpty()
    }

    private fun show(l: TeacherLine) {
        current = l
        reaction++
        onMarks(l.marks)
        if (voiceOn) {
            if (voice == null) voice = TeacherVoice(app)
            voice?.speak(l.text)
        }
    }

    companion object {
        private const val KEY_PERSONA = "teacher_persona"
        private const val KEY_TALK = "teacher_talk"
        private const val KEY_VOICE = "teacher_voice"
        private const val MAX_HISTORY = 150
    }
}

/** Giọng đọc tiếng Việt của hệ thống (TextToSpeech). Không có giọng thì im lặng, không báo lỗi. */
class TeacherVoice(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    @Volatile private var ready = false

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        val r = t.setLanguage(Locale("vi", "VN"))
        ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        if (ready) t.setSpeechRate(0.95f)
    }

    fun speak(text: String) {
        if (!ready) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "teacher")
    }

    fun stop() { tts?.stop() }

    fun release() {
        tts?.stop(); tts?.shutdown(); tts = null; ready = false
    }
}
