package com.vila.chess.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.vila.chess.cloud.EmailAuthResult
import com.vila.chess.cloud.SupabaseCloud
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.vila.chess.R
import com.vila.chess.auth.Account
import com.vila.chess.auth.AccountStore
import com.vila.chess.auth.AuthProvider
import com.vila.chess.auth.SocialSignIn
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.openid.appauth.AuthorizationException
import net.openid.appauth.AuthorizationRequest
import net.openid.appauth.AuthorizationResponse
import net.openid.appauth.AuthorizationService
import net.openid.appauth.AuthorizationServiceConfiguration
import net.openid.appauth.ResponseTypeValues
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val Green = Color(0xFF81B64C)

private val Bg = Color(0xFF262522)
private val Face = Color(0xFF3C3A37)
private val Edge = Color(0xFF2B2926)
private val GreenEdge = Color(0xFF45753C)
private val Dim = Color(0xFFBABABA)

/**
 * Trang đăng nhập kiểu chess.com: nền tối, logo, nút xanh "Đăng ký" 3D, nút xám "Đăng nhập",
 * rồi "hoặc tiếp tục với" Google. Nhập email là bước riêng.
 */
@Composable
fun GoogleLoginGate() {
    val ctx = LocalContext.current
    val activity = ctx as? ComponentActivity
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var emailMode by remember { mutableStateOf<Boolean?>(null) }   // null = màn chào; true = đăng ký; false = đăng nhập

    val androidClientId = ctx.getString(R.string.google_android_client_id)
    val useBrowser = !androidClientId.startsWith("YOUR_")

    fun signedIn(email: String?, name: String, provider: AuthProvider = AuthProvider.GOOGLE) {
        if (email != null) AccountStore.save(ctx, Account(email, name, provider))
        else Toast.makeText(ctx, "Tài khoản không cung cấp email", Toast.LENGTH_LONG).show()
    }

    // ---- Google toàn trang (AppAuth + PKCE) ----
    val authService = remember { AuthorizationService(ctx) }
    DisposableEffect(Unit) { onDispose { authService.dispose() } }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        val resp = data?.let { AuthorizationResponse.fromIntent(it) }
        val ex = data?.let { AuthorizationException.fromIntent(it) }
        if (resp == null) {
            loading = false
            if (ex != null && ex.code != AuthorizationException.GeneralErrors.USER_CANCELED_AUTH_FLOW.code)
                Toast.makeText(ctx, ex.errorDescription ?: ex.error ?: "Lỗi", Toast.LENGTH_LONG).show()
            return@rememberLauncherForActivityResult
        }
        authService.performTokenRequest(resp.createTokenExchangeRequest()) { tr, e ->
            loading = false
            val r = SocialSignIn.parseGoogleIdToken(tr?.idToken)
            if (r != null) {
                scope.launch { runCatching { com.vila.chess.cloud.SupabaseCloud.signInWithGoogle(ctx, tr?.idToken) } }
                signedIn(r.email, r.name)
            }
            else Toast.makeText(ctx, e?.errorDescription ?: "Lỗi", Toast.LENGTH_LONG).show()
        }
    }
    fun startBrowserFlow() {
        val cfg = AuthorizationServiceConfiguration(
            Uri.parse("https://accounts.google.com/o/oauth2/v2/auth"),
            Uri.parse("https://oauth2.googleapis.com/token"),
        )
        val req = AuthorizationRequest.Builder(cfg, androidClientId, ResponseTypeValues.CODE, Uri.parse("com.vila.chessnative:/oauth2redirect"))
            .setScope("openid email profile")
            .setPrompt(AuthorizationRequest.Prompt.SELECT_ACCOUNT)
            .build()
        loading = true
        launcher.launch(authService.getAuthorizationRequestIntent(req))
    }
    fun startSheetFlow() {
        if (activity == null) return
        loading = true
        scope.launch {
            val result = runCatching { SocialSignIn.google(activity, ctx.getString(R.string.google_web_client_id)) }
            val e = result.exceptionOrNull()
            when {
                e == null -> { loading = false; result.getOrNull()?.let { signedIn(it.email, it.name) } }
                e is GetCredentialCancellationException -> loading = false     // người dùng tự đóng bảng chọn tài khoản
                useBrowser -> startBrowserFlow()                                  // bảng chọn lỗi => dự phòng mở trình duyệt
                else -> {
                    loading = false
                    Toast.makeText(ctx, e.message ?: e.javaClass.simpleName, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    // Ưu tiên bảng chọn tài khoản gốc của Google (Credential Manager) như DeepSeek; chỉ khi lỗi mới mở trình duyệt.
    fun startGoogle() = startSheetFlow()

    val enter = remember { Animatable(0f) }
    LaunchedEffect(Unit) { enter.animateTo(1f, tween(500, easing = FastOutSlowInEasing)) }

    BackHandler(enabled = emailMode != null) { emailMode = null }

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (emailMode == null) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 24.dp)
                    .graphicsLayer { alpha = enter.value; translationY = (1f - enter.value) * 24.dp.toPx() },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.weight(1f))
                ChessplusMark(Modifier.size(104.dp))
                Spacer(Modifier.height(18.dp))
                ChessplusWordmark(Modifier.fillMaxWidth().height(56.dp))
                Spacer(Modifier.height(10.dp))
                Text("Chơi cờ vua. Vui vẻ. Giỏi hơn mỗi ngày.", color = Dim, fontSize = 15.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.weight(1f))

                Column(Modifier.widthIn(max = 380.dp).fillMaxWidth()) {
                    ChessButton("Đăng ký", Green, GreenEdge, big = true) { emailMode = true }
                    Spacer(Modifier.height(12.dp))
                    ChessButton("Đăng nhập", Face, Edge, big = true) { emailMode = false }
                    Spacer(Modifier.height(22.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF3C3A37)))
                        Text("  hoặc tiếp tục với  ", color = Dim, fontSize = 13.sp)
                        Box(Modifier.weight(1f).height(1.dp).background(Color(0xFF3C3A37)))
                    }
                    Spacer(Modifier.height(16.dp))
                    ChessButton("Google", Face, Edge, loading = loading, icon = { GoogleG(Modifier.size(22.dp)) }) { if (!loading) startGoogle() }
                }
                Spacer(Modifier.height(20.dp))
                Text(
                    "Khi tiếp tục, bạn đồng ý với Điều khoản dịch vụ và Chính sách quyền riêng tư.",
                    color = Color(0xFF8B8987), fontSize = 12.sp, textAlign = TextAlign.Center, lineHeight = 16.sp,
                    modifier = Modifier.widthIn(max = 320.dp),
                )
                Spacer(Modifier.height(24.dp))
            }
        } else {
            EmailForm(
                signUp = emailMode == true,
                onBack = { emailMode = null },
                onSuccess = { email ->
                    signedIn(email, email.substringBefore('@'), AuthProvider.EMAIL)
                    scope.launch { runCatching { SupabaseCloud.flushPending(ctx) } }
                },
                onSwitch = { emailMode = !(emailMode ?: true) },
            )
        }
    }
}

@Composable
private fun EmailForm(signUp: Boolean, onBack: () -> Unit, onSuccess: (String) -> Unit, onSwitch: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPw by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var otpEmail by remember { mutableStateOf<String?>(null) }   // != null => đang ở bước nhập mã 6 số
    var code by remember { mutableStateOf("") }
    var cooldown by remember { mutableStateOf(0) }               // giây chờ trước khi được gửi lại mã
    LaunchedEffect(cooldown) { if (cooldown > 0) { delay(1000); cooldown -= 1 } }
    // Chuyển giữa Đăng ký <-> Đăng nhập: xoá mật khẩu và thông báo cũ.
    LaunchedEffect(signUp) { error = null; info = null; password = ""; confirm = ""; showPw = false }

    val fieldColors = TextFieldDefaults.colors(
        focusedContainerColor = Face, unfocusedContainerColor = Face,
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        cursorColor = Green,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    )
    val hint = Color(0xFF8B8987)

    fun submit() {
        if (loading) return
        val e = email.trim()
        when {
            !AccountStore.isValidEmail(e) -> error = "Email không hợp lệ"
            signUp && password.length < 8 -> error = "Mật khẩu cần ít nhất 8 ký tự"
            !signUp && password.isEmpty() -> error = "Hãy nhập mật khẩu"
            signUp && password != confirm -> error = "Mật khẩu nhập lại không khớp"
            else -> {
                loading = true; error = null; info = null
                scope.launch {
                    val r = if (signUp) SupabaseCloud.signUpWithEmail(ctx, e, password)
                    else SupabaseCloud.signInWithEmail(ctx, e, password)
                    loading = false
                    when (r) {
                        is EmailAuthResult.Success -> onSuccess(r.email)
                        is EmailAuthResult.NeedConfirm -> { otpEmail = e; code = ""; cooldown = 60; info = "Đã gửi mã 6 số tới $e." }
                        is EmailAuthResult.Sent -> {}
                        is EmailAuthResult.Error -> error = r.message
                    }
                }
            }
        }
    }

    fun forgotPassword() {
        if (loading) return
        val e = email.trim()
        if (!AccountStore.isValidEmail(e)) { error = "Nhập email của bạn ở trên trước"; return }
        loading = true; error = null; info = null
        scope.launch {
            val r = SupabaseCloud.sendPasswordReset(ctx, e)
            loading = false
            when (r) {
                is EmailAuthResult.Error -> error = r.message
                else -> info = "Nếu $e đã có tài khoản, email đặt lại mật khẩu đã được gửi."
            }
        }
    }

    fun verifyOtp(c: String) {
        if (loading) return
        val e = otpEmail ?: return
        if (c.length != 6) { error = "Nhập đủ 6 số"; return }
        loading = true; error = null; info = null
        scope.launch {
            val r = SupabaseCloud.verifySignupOtp(ctx, e, c)
            loading = false
            when (r) {
                is EmailAuthResult.Success -> onSuccess(r.email)
                is EmailAuthResult.Error -> { error = r.message; code = "" }
                else -> {}
            }
        }
    }

    fun resendOtp() {
        if (loading || cooldown > 0) return
        val e = otpEmail ?: return
        loading = true; error = null; info = null
        scope.launch {
            val r = SupabaseCloud.resendSignupOtp(ctx, e)
            loading = false
            when (r) {
                is EmailAuthResult.Error -> error = r.message
                else -> { info = "Đã gửi lại mã tới $e."; cooldown = 60; code = "" }
            }
        }
    }

    // Bước 2 của đăng ký: nhập mã 6 số trong email.
    if (otpEmail != null) {
        BackHandler { otpEmail = null; code = ""; error = null; info = null }
        Column(
            Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        ) {
            Text(
                "←", color = Color.White, fontSize = 28.sp,
                modifier = Modifier.padding(vertical = 12.dp).clickable { otpEmail = null; code = ""; error = null; info = null },
            )
            Spacer(Modifier.height(16.dp))
            Text("Nhập mã xác nhận", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text("Mã 6 số đã được gửi tới ${otpEmail}. Hãy kiểm tra cả mục Spam nếu chưa thấy.", color = Dim, fontSize = 15.sp)
            Spacer(Modifier.height(28.dp))
            TextField(
                value = code,
                onValueChange = { v ->
                    val d = v.filter { it.isDigit() }.take(6)
                    code = d; error = null
                    if (d.length == 6) verifyOtp(d)
                },
                singleLine = true,
                placeholder = { Text("______", color = hint, fontSize = 28.sp, letterSpacing = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
                textStyle = TextStyle(color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 10.sp, textAlign = TextAlign.Center),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                shape = RoundedCornerShape(10.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth(),
            )
            error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
            info?.let { Text(it, color = Green, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 10.dp)) }
            Spacer(Modifier.height(20.dp))
            ChessButton("Xác nhận", Green, GreenEdge, big = true, loading = loading) { verifyOtp(code) }
            Spacer(Modifier.height(12.dp))
            Text(
                if (cooldown > 0) "Gửi lại mã sau ${cooldown}s" else "Gửi lại mã",
                color = if (cooldown > 0) Dim else Green, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.CenterHorizontally).clickable(enabled = cooldown == 0) { resendOtp() }.padding(8.dp),
            )
        }
        return
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
    ) {
        Text(
            "←", color = Color.White, fontSize = 28.sp,
            modifier = Modifier.padding(vertical = 12.dp).clickable(onClick = onBack),
        )
        Spacer(Modifier.height(16.dp))
        Text(if (signUp) "Tạo tài khoản" else "Đăng nhập", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(6.dp))
        Text(
            if (signUp) "Nhập email và đặt mật khẩu để bắt đầu chơi và xem lại các ván cờ."
            else "Nhập email và mật khẩu của bạn để tiếp tục.",
            color = Dim, fontSize = 15.sp,
        )
        Spacer(Modifier.height(28.dp))
        TextField(
            value = email, onValueChange = { email = it; error = null },
            singleLine = true,
            placeholder = { Text("Email", color = hint) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            shape = RoundedCornerShape(10.dp),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))
        TextField(
            value = password, onValueChange = { password = it; error = null },
            singleLine = true,
            placeholder = { Text(if (signUp) "Mật khẩu (ít nhất 8 ký tự)" else "Mật khẩu", color = hint) },
            visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                Text(
                    if (showPw) "Ẩn" else "Hiện", color = Green, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { showPw = !showPw }.padding(12.dp),
                )
            },
            shape = RoundedCornerShape(10.dp),
            colors = fieldColors,
            modifier = Modifier.fillMaxWidth(),
        )
        if (signUp) {
            Spacer(Modifier.height(12.dp))
            TextField(
                value = confirm, onValueChange = { confirm = it; error = null },
                singleLine = true,
                placeholder = { Text("Nhập lại mật khẩu", color = hint) },
                visualTransformation = if (showPw) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                shape = RoundedCornerShape(10.dp),
                colors = fieldColors,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
        info?.let { Text(it, color = Green, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(20.dp))
        ChessButton(if (signUp) "Đăng ký" else "Đăng nhập", Green, GreenEdge, big = true, loading = loading) { submit() }
        if (!signUp) {
            Text(
                "Quên mật khẩu?", color = Dim, fontSize = 14.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).clickable { forgotPassword() }.padding(top = 16.dp, bottom = 4.dp, start = 8.dp, end = 8.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            if (signUp) "Đã có tài khoản? Đăng nhập" else "Chưa có tài khoản? Đăng ký",
            color = Green, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.CenterHorizontally).clickable(onClick = onSwitch).padding(8.dp),
        )
    }
}

/** Nút 3D kiểu chess.com: mặt nút + cạnh dưới đậm hơn, nhấn thì lún xuống. */
@Composable
private fun ChessButton(
    text: String, face: Color, edge: Color, big: Boolean = false, loading: Boolean = false,
    icon: (@Composable () -> Unit)? = null, onClick: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val depth = if (pressed) 1.dp else 4.dp
    val h = if (big) 60.dp else 54.dp
    Box(
        Modifier.fillMaxWidth().height(h).clip(RoundedCornerShape(10.dp)).background(edge)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
    ) {
        Box(
            Modifier.fillMaxWidth().height(h - depth).clip(RoundedCornerShape(10.dp)).background(face),
            contentAlignment = Alignment.Center,
        ) {
            if (loading) CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 3.dp)
            else Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                if (icon != null) { icon(); Spacer(Modifier.width(12.dp)) }
                Text(text, color = Color.White, fontSize = if (big) 20.sp else 17.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** Biểu tượng app: ô vuông bo góc nền xanh + quân Mã trắng, vẽ bằng Canvas. */
@Composable
private fun ChessplusMark(modifier: Modifier = Modifier) {
    val knight: ImageBitmap = ImageBitmap.imageResource(R.drawable.piece_wn)
    Canvas(modifier) {
        val r = size.minDimension * 0.28f
        drawRoundRect(Color(0x6681B64C), Offset(0f, size.height * 0.04f), size, CornerRadius(r))                      // bóng đổ xanh
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFF9CCB5F), Color(0xFF5E8F33))), Offset.Zero, size, CornerRadius(r))
        drawRoundRect(Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color.Transparent), endY = size.height * 0.5f), Offset.Zero, size, CornerRadius(r))   // bóng sáng phía trên
        val k = size.minDimension * 0.70f
        val o = (size.minDimension - k) / 2f
        drawImage(knight, dstOffset = IntOffset(o.roundToInt(), o.roundToInt()), dstSize = IntSize(k.roundToInt(), k.roundToInt()))
    }
}

/** "Chessplus.com" chữ to: đo layout một lần, vẽ trực tiếp bằng Canvas, tự co nếu màn hình hẹp. */
@Composable
private fun ChessplusWordmark(modifier: Modifier = Modifier) {
    val measurer = rememberTextMeasurer()
    val text: AnnotatedString = remember {
        buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White)) { append("Chess") }
            withStyle(SpanStyle(color = Green)) { append("plus") }
            withStyle(SpanStyle(color = Color(0xFFB9BDC4), fontWeight = FontWeight.SemiBold)) { append(".com") }
        }
    }
    val layout = remember(text) {
        measurer.measure(text, TextStyle(fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp, shadow = androidx.compose.ui.graphics.Shadow(Color(0x66000000), Offset(0f, 4f), 10f)))
    }
    Canvas(modifier) {
        val w = layout.size.width.toFloat(); val h = layout.size.height.toFloat()
        val s = min(1f, size.width / w)
        scale(s, s, pivot = Offset(size.width / 2f, size.height / 2f)) {
            drawText(layout, topLeft = Offset((size.width - w) / 2f, (size.height - h) / 2f))
        }
    }
}

/** Logo "G" nhiều màu của Google vẽ bằng Canvas. */
@Composable
private fun GoogleG(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val stroke = size.minDimension * 0.2f
        val inset = stroke / 2f
        val arcSize = Size(size.width - stroke, size.height - stroke)
        val tl = Offset(inset, inset)
        fun arc(color: Color, start: Float, sweep: Float) =
            drawArc(color, start, sweep, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
        arc(Color(0xFFEA4335), 195f, 120f)
        arc(Color(0xFFFBBC05), 135f, 60f)
        arc(Color(0xFF34A853), 45f, 90f)
        arc(Color(0xFF4285F4), 0f, 45f)
        drawRect(Color(0xFF4285F4), Offset(size.width / 2f, size.height / 2f - stroke / 2f), Size(size.width / 2f, stroke))
    }
}
