package com.vila.chess.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.R
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.StatsStore
import com.vila.chess.game.achievements
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.UserSessionManager
import kotlinx.coroutines.launch

// =============================================================================
// Màn hình Hồ sơ — phong cách TỐI GIẢN.
//   userId == null  → hồ sơ CỦA MÌNH: 3 tab vuốt ngang (Tổng quan · Thành tựu · Bạn bè) + Chỉnh sửa hồ sơ.
//   userId != null  → hồ sơ NGƯỜI KHÁC (đối thủ/bạn bè) tải từ Supabase — chỉ xem, không có tab.
// Tổng quan = header (avatar, tên, quốc gia, nút chỉnh sửa) + 3 thẻ Elo, căn giữa màn hình. Không còn biểu đồ/thống kê/ván đấu.
// =============================================================================

private val PROFILE_TABS = listOf("Tổng quan", "Thành tựu", "Bạn bè")

@Composable
fun MyProfileScreen(
    vm: GameViewModel,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    userId: String? = null,
) {
    BackHandler(onBack = onBack)
    // Scaffold lo chừa chỗ thanh trạng thái/thanh điều hướng; nền để trong suốt cho SpaceBackground phía sau.
    Scaffold(
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = { ProfileTopBar(title = if (userId == null) "Hồ sơ" else "Hồ sơ người chơi", onBack = onBack) },
    ) { inner ->
        Box(Modifier.padding(inner).fillMaxSize()) {
            if (userId == null) OwnProfile(vm) else RemoteProfile(userId)
        }
    }
}

// ------------------------------------------------------------------ Hồ sơ của mình

@Composable
private fun OwnProfile(vm: GameViewModel) {
    val ctx = LocalContext.current
    // Gói lấy từ MembershipStore (qua UserSessionManager): mua gói xong huy hiệu đổi ngay, không cần làm gì thêm.
    val tier by UserSessionManager.tier(ctx).collectAsState()
    val name = UserSessionManager.displayName
    val country = UserSessionManager.countryCode
    val avatar = UserSessionManager.avatarKey
    val stats = vm.stats
    val profile = remember(stats, tier, name, country, avatar) { UserSessionManager.profile(ctx, stats) }
    val badges = remember(stats, vm.tournamentsDone) {
        profileAchievements(achievements(stats, vm.tournamentsDone, StatsStore.today()))
    }
    var editing by remember { mutableStateOf(false) }

    OwnTabs(profile = profile, badges = badges, onEdit = { editing = true })
    if (editing) EditProfileSheet(onDismiss = { editing = false })
}

// ------------------------------------------------------------------ Hồ sơ người khác

@Composable
private fun RemoteProfile(userId: String) {
    val (state, retry) = rememberRemoteProfile(userId)
    when (val s = state) {
        is LoadState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { LoadingBlock(text = "Đang tải hồ sơ…") }
        is LoadState.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ErrorBlock(s.kind, onRetry = retry) }
        is LoadState.Success -> OverviewTab(profile = s.data, isSelf = false, onEdit = {})
    }
}

// ------------------------------------------------------------------ 3 tab vuốt ngang

@Composable
private fun OwnTabs(profile: UserProfile, badges: List<Achievement>, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = 0, pageCount = { PROFILE_TABS.size })
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = pager.currentPage,
            containerColor = Color.Transparent,
            contentColor = Color.White,
            indicator = { positions ->
                if (pager.currentPage < positions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(positions[pager.currentPage]),
                        height = 3.dp,
                        color = VilaColors.Green,
                    )
                }
            },
            divider = {},
        ) {
            PROFILE_TABS.forEachIndexed { i, label ->
                val on = pager.currentPage == i
                Tab(
                    selected = on,
                    onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    selectedContentColor = Color.White,
                    unselectedContentColor = VilaColors.TextDim,
                    text = { Text(label, fontSize = 14.sp, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1) },
                )
            }
        }
        HorizontalPager(
            state = pager,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            key = { it },
        ) { page ->
            when (page) {
                0 -> OverviewTab(profile = profile, isSelf = true, onEdit = onEdit)
                1 -> AchievementsTab(items = badges)
                else -> FriendsTab(
                    friends = MockFriends,
                    onChallenge = { f -> Toast.makeText(ctx, "Đã gửi lời thách đấu tới ${f.name}", Toast.LENGTH_SHORT).show() },
                )
            }
        }
    }
}

// ------------------------------------------------------------------ Tab: Tổng quan (tối giản)

@Composable
private fun OverviewTab(profile: UserProfile, isSelf: Boolean, onEdit: () -> Unit) {
    var modeIdx by rememberSaveable { mutableIntStateOf(EloMode.BLITZ.ordinal) }
    val mode = EloMode.values()[modeIdx]

    // Box căn giữa: nội dung thấp hơn màn hình thì nằm giữa; cao hơn (máy nhỏ/chữ to) thì cuộn được.
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            GlowAvatar(name = profile.displayName, avatarKey = profile.avatarKey)
            Spacer(Modifier.height(14.dp))
            NameWithBadge(name = profile.displayName, tier = profile.tier, fontSize = 26f, badgeSize = 26.dp)
            CountryLine(profile.countryCode, Modifier.padding(top = 4.dp))
            if (isSelf) {
                Spacer(Modifier.height(12.dp))
                EditPill(onClick = onEdit)
            }
            Spacer(Modifier.height(32.dp))
            // 3 thẻ chia đều chiều ngang: weight(1f) → không bị cắt chữ.
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                for (m in EloMode.values()) {
                    MinimalEloCard(
                        mode = m, rating = profile.elo(m), selected = m == mode,
                        modifier = Modifier.weight(1f), onClick = { modeIdx = m.ordinal },
                    )
                }
            }
        }
    }
}

private val AvatarGlow = Color(0xFF81B64C)

/** Avatar tròn: viền mỏng phát sáng nhẹ (bóng màu xanh). */
@Composable
private fun GlowAvatar(name: String, avatarKey: String) {
    Box(
        Modifier
            .shadow(18.dp, CircleShape, ambientColor = AvatarGlow, spotColor = AvatarGlow)
            .border(1.dp, AvatarGlow.copy(alpha = 0.7f), CircleShape)
            .padding(4.dp),
    ) {
        ProfileAvatar(name = name, avatarKey = avatarKey, size = 104.dp)
    }
}

/** Nút nhỏ gọn bo tròn: nền xám mờ (alpha 0.2) + viền mỏng + icon cây bút. */
@Composable
private fun EditPill(onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .clip(shape)
            .background(Color(0xFF9AA3B2).copy(alpha = 0.2f))
            .border(1.dp, Color(0x33FFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(ImageVector.vectorResource(id = R.drawable.ic_edit), contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text("Chỉnh sửa hồ sơ", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Thẻ Elo: nền gradient tối, bo 16dp; thẻ đang chọn có viền xanh 1,5dp. Nội dung: icon · Elo to đậm · tên thể loại nhỏ xám. */
@Composable
private fun MinimalEloCard(mode: EloMode, rating: Int, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val colors = if (selected) listOf(Color(0xFF28463A), Color(0xFF132219)) else listOf(Color(0xFF223250), Color(0xFF111A2C))
    Column(
        modifier = modifier
            .clip(shape)
            .background(Brush.verticalGradient(colors))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) VilaColors.Green else VilaColors.GlassBorder, shape)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val iconModifier = Modifier.size(30.dp)
        when (mode) {
            EloMode.BULLET -> BulletIcon(iconModifier)
            EloMode.BLITZ -> BoltIcon(iconModifier)
            EloMode.RAPID -> StopwatchIcon(iconModifier)
        }
        Spacer(Modifier.height(10.dp))
        Text(rating.toString(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(mode.title, color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ------------------------------------------------------------------ Thanh trên

@Composable
private fun ProfileTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onBack).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White)
        Text("  $title", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ Chỉnh sửa hồ sơ

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserSessionManager.displayName) }
    var avatar by remember { mutableStateOf(UserSessionManager.avatarKey) }
    var country by remember { mutableStateOf(UserSessionManager.countryCode) }
    var error by remember { mutableStateOf<String?>(null) }
    var pickCountry by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color(0xFF16233B),
        contentColor = Color.White,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Chỉnh sửa hồ sơ", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            ProfileAvatar(name = name, avatarKey = avatar, size = 84.dp)

            // Avatar: chữ cái đầu của tên + 6 avatar quân cờ
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item(key = "initial") { AvatarChoice(name, "", selected = avatar.isBlank()) { avatar = "" } }
                items(Avatars.presets, key = { it.key }) { pr -> AvatarChoice(name, pr.key, selected = avatar == pr.key) { avatar = pr.key } }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(30); error = null },
                label = { Text("Tên hiển thị") },
                singleLine = true,
                isError = error != null,
                supportingText = { Text(error ?: "2–20 ký tự") },
                modifier = Modifier.fillMaxWidth(),
            )

            // Quốc gia
            val c = Countries.byCode(country)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x14FFFFFF))
                    .clickable { pickCountry = true }.padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Quốc gia", color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(if (c != null) Countries.flag(c.code) + " " + c.name else "Chưa chọn", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            ChunkyButton(
                text = "Lưu",
                onClick = {
                    val err = UserSessionManager.updateProfile(ctx, name, country, avatar)
                    if (err != null) error = err
                    else { Toast.makeText(ctx, "Đã lưu hồ sơ", Toast.LENGTH_SHORT).show(); onDismiss() }
                },
                modifier = Modifier.fillMaxWidth(), height = 48.dp, fontSize = 18.sp,
            )
        }
    }

    if (pickCountry) {
        AlertDialog(
            onDismissRequest = { pickCountry = false },
            title = { Text("Chọn quốc gia") },
            text = {
                LazyColumn(Modifier.height(360.dp)) {
                    items(Countries.all, key = { it.code }) { ct ->
                        Row(
                            Modifier.fillMaxWidth().clickable { country = ct.code; pickCountry = false }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(Countries.flag(ct.code), fontSize = 22.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(ct.name, fontSize = 16.sp, fontWeight = if (ct.code == country) FontWeight.ExtraBold else FontWeight.Normal)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickCountry = false }) { Text("Đóng") } },
        )
    }
}

@Composable
private fun AvatarChoice(name: String, key: String, selected: Boolean, onClick: () -> Unit) {
    ProfileAvatar(
        name = name, avatarKey = key, size = 48.dp,
        modifier = Modifier
            .border(if (selected) 3.dp else 0.dp, if (selected) VilaColors.Green else Color.Transparent, CircleShape)
            .clickable(onClick = onClick),
    )
}
