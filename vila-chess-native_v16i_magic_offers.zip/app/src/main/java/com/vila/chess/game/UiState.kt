package com.vila.chess.game

import androidx.compose.runtime.Immutable

@Immutable
data class Slide(val from: Int, val to: Int)

@Immutable
data class PendingPromotion(val from: Int, val to: Int, val fromDrag: Boolean)

@Immutable
data class ClockState(val whiteMs: Long = 0L, val blackMs: Long = 0L, val enabled: Boolean = false)

/** Immutable snapshot of everything the board / bars need to draw. */
@Immutable
data class UiState(
    val board: IntArray = IntArray(64),
    val humanWhite: Boolean = true,
    val flipped: Boolean = false,
    val selected: Int = -1,
    val targets: Set<Int> = emptySet(),
    val lastFrom: Int = -1,
    val lastTo: Int = -1,
    val checkSquare: Int = -1,
    val premoveFrom: Int = -1,
    val premoveTo: Int = -1,
    /** Toàn bộ hàng đợi premove (chế độ Nhiều có thể > 1) để bàn cờ tô đỏ. */
    val premoves: List<Slide> = emptyList(),
    val slides: List<Slide> = emptyList(),
    val animToken: Int = 0,
    val sans: List<String> = emptyList(),
    val whiteToMove: Boolean = true,
    val thinking: Boolean = false,
    val over: Boolean = false,
    val resultTitle: String = "",
    val resultDetail: String = "",
    /** Kết quả cho màn tổng kết: hòa / người chơi thắng (luôn false khi chơi 2 người). */
    val draw: Boolean = false,
    val humanWon: Boolean = false,
    val promotion: PendingPromotion? = null,
    val capturedByWhite: List<Int> = emptyList(),
    val capturedByBlack: List<Int> = emptyList(),
    val materialDiff: Int = 0,
    val canUndo: Boolean = false,
    val kind: GameKind = GameKind.BOT,
    val hintFrom: Int = -1,
    val hintTo: Int = -1,
    val hintText: String = "",
    val hintBusy: Boolean = false,
    /** Quân vừa bị ăn (để bàn cờ chạy hiệu ứng mờ + thu nhỏ 150ms). captureToken tăng mỗi lần có quân bị ăn. */
    val captureSq: Int = -1,
    val capturePiece: Int = 0,
    val captureToken: Int = 0,
    /** Điểm đánh giá theo góc nhìn Trắng (centipawn) cho thanh Eval; evalReady = false khi chưa có số liệu. */
    val evalCp: Int = 0,
    val evalReady: Boolean = false,
    /** Nhãn chất lượng từng nước đã đi (phần tử i = nước i+1); ngắn hơn [sans] khi nước mới nhất chưa phân tích xong. */
    val moveLabels: List<com.vila.chess.review.MoveLabel> = emptyList(),
    /** Dấu thầy vẽ lên bàn cờ (vòng tròn quanh ô, mũi tên) khi đang giảng. */
    val teacherMarks: List<com.vila.chess.coach.Mark> = emptyList()
)
