package com.vila.chess.coach

/** Tính cách của thầy: đổi cách xưng hô + giọng điệu, dùng chung một kho câu. */
enum class Persona(val label: String, val me: String, val you: String, val blurb: String) {
    GENTLE("Thầy Hiền", "thầy", "con", "Nhẹ nhàng, hay khen, chỉ bảo từ tốn"),
    STRICT("Thầy Nghiêm", "thầy", "em", "Thẳng thắn, đòi hỏi cao, ít khen"),
    FUNNY("Thầy Vui", "tui", "bạn", "Hài hước, hay trêu, nhiều biểu cảm");
}

/** Tâm trạng của thầy: quyết định màu bong bóng, điệu bộ avatar và "phụ họa" mở đầu câu. */
enum class Mood { CALM, HAPPY, PROUD, WORRIED, ALARM, THINK, SAD, CHEER }

/** Mỗi giá trị = một nhóm câu nói. Tiền tố T_ = điều thầy THẤY trên bàn (khớp [Topic]). */
enum class Say {
    GAME_START_WHITE, GAME_START_BLACK, GAME_START_ENDGAME,
    FIRST_E4, FIRST_D4, FIRST_NF3, FIRST_C4, FIRST_OTHER,
    // ---- người chơi vừa đi ----
    H_CAPTURE_FREE, H_CAPTURE_TRADE, H_CAPTURE_PAWN, H_RECAPTURE, H_CHECK, H_MATE,
    H_CASTLE_SHORT, H_CASTLE_LONG, H_EP, H_PROMOTE,
    H_MOVED_INTO_DANGER, H_LEFT_HANGING, H_MISSED_WIN, H_REPEAT_PIECE, H_EARLY_QUEEN, H_RIM_KNIGHT,
    H_DEVELOP, H_CENTER_PAWN, H_ESCAPE_CHECK, H_THREATENS, H_QUIET, H_STALEMATE_GIVEN,
    // ---- máy / đối thủ vừa đi ----
    B_CAPTURE, B_CHECK, B_MATE, B_CASTLE, B_PROMOTE, B_THREATENS, B_BLUNDER, B_DEVELOP, B_QUIET, B_EP,
    // ---- thế cờ ----
    T_HANGING_YOURS, T_HANGING_THEIRS, T_ATTACKED_BY_LESSER_YOURS, T_ATTACKED_BY_LESSER_THEIRS,
    T_FORK_AVAILABLE, T_MATE_IN_ONE_AVAILABLE, T_PIN_YOURS, T_PIN_THEIRS, T_BACK_RANK_YOURS, T_BACK_RANK_THEIRS,
    T_OPEN_FILE_ROOK_YOURS, T_OPEN_FILE_ROOK_THEIRS, T_OPEN_FILE_EMPTY, T_ROOK_SEVENTH_YOURS, T_ROOK_SEVENTH_THEIRS,
    T_PASSED_PAWN_YOURS, T_PASSED_PAWN_THEIRS, T_DOUBLED_PAWNS_YOURS, T_DOUBLED_PAWNS_THEIRS,
    T_ISOLATED_PAWN_YOURS, T_ISOLATED_PAWN_THEIRS, T_BISHOP_PAIR_YOURS, T_BISHOP_PAIR_THEIRS,
    T_CENTER_YOURS, T_CENTER_THEIRS, T_CENTER_EMPTY, T_KING_EXPOSED_YOURS, T_KING_EXPOSED_THEIRS,
    T_KING_STUCK_YOURS, T_KING_STUCK_THEIRS, T_UNDEVELOPED_YOURS, T_UNDEVELOPED_THEIRS,
    T_ENDGAME_KING, T_OPPONENT_CRAMPED, T_MATERIAL_UP, T_MATERIAL_DOWN, T_MATERIAL_EVEN,
    // ---- diễn biến ván ----
    OPENING_NAME, ENDGAME_ENTER, ADV_UP, ADV_DOWN, COMEBACK, STREAK, FIFTY_WARN, REPETITION_WARN,
    // ---- nhãn engine đến muộn ----
    LABEL_BRILLIANT, LABEL_GREAT, LABEL_BEST, LABEL_EXCELLENT, LABEL_GOOD, LABEL_BOOK,
    LABEL_INACCURACY, LABEL_MISTAKE, LABEL_BLUNDER, LABEL_MISS,
    // ---- tương tác ----
    UNDO, HINT_ASK, HINT_GIVEN, ASK_INTRO, ASK_NOTHING, IDLE1, IDLE2, IDLE3, POKE, TIP, JOKE,
    // ---- kết thúc ----
    WIN, LOSE, DRAW, RESIGN, END_STALEMATE
}

/** Cảm xúc mặc định của mỗi nhóm câu. */
fun Say.mood(): Mood = when (this) {
    Say.H_CAPTURE_FREE, Say.H_MATE, Say.H_PROMOTE, Say.WIN, Say.LABEL_BRILLIANT, Say.LABEL_GREAT, Say.T_MATE_IN_ONE_AVAILABLE,
    Say.T_FORK_AVAILABLE, Say.T_HANGING_THEIRS, Say.B_BLUNDER, Say.STREAK, Say.ADV_UP, Say.COMEBACK -> Mood.CHEER
    Say.H_CHECK, Say.H_CASTLE_SHORT, Say.H_CASTLE_LONG, Say.H_DEVELOP, Say.H_CENTER_PAWN, Say.H_RECAPTURE, Say.H_EP,
    Say.LABEL_BEST, Say.LABEL_EXCELLENT, Say.LABEL_GOOD, Say.LABEL_BOOK, Say.T_CENTER_YOURS, Say.T_BISHOP_PAIR_YOURS,
    Say.T_OPEN_FILE_ROOK_YOURS, Say.T_ROOK_SEVENTH_YOURS, Say.T_PASSED_PAWN_YOURS, Say.T_PIN_THEIRS, Say.T_MATERIAL_UP,
    Say.T_BACK_RANK_THEIRS, Say.T_KING_EXPOSED_THEIRS, Say.T_KING_STUCK_THEIRS, Say.T_UNDEVELOPED_THEIRS,
    Say.T_OPPONENT_CRAMPED, Say.T_ATTACKED_BY_LESSER_THEIRS, Say.T_DOUBLED_PAWNS_THEIRS, Say.T_ISOLATED_PAWN_THEIRS,
    Say.H_CAPTURE_TRADE, Say.H_CAPTURE_PAWN, Say.H_THREATENS, Say.H_ESCAPE_CHECK, Say.OPENING_NAME -> Mood.HAPPY
    Say.H_MOVED_INTO_DANGER, Say.H_LEFT_HANGING, Say.H_MISSED_WIN, Say.H_STALEMATE_GIVEN, Say.LABEL_BLUNDER, Say.LABEL_MISTAKE,
    Say.T_HANGING_YOURS, Say.T_ATTACKED_BY_LESSER_YOURS, Say.B_MATE, Say.B_CHECK, Say.B_THREATENS, Say.T_BACK_RANK_YOURS,
    Say.T_KING_EXPOSED_YOURS, Say.ADV_DOWN, Say.T_PIN_YOURS, Say.FIFTY_WARN, Say.REPETITION_WARN -> Mood.ALARM
    Say.H_REPEAT_PIECE, Say.H_EARLY_QUEEN, Say.H_RIM_KNIGHT, Say.LABEL_INACCURACY, Say.LABEL_MISS, Say.T_MATERIAL_DOWN,
    Say.T_KING_STUCK_YOURS, Say.T_UNDEVELOPED_YOURS, Say.T_DOUBLED_PAWNS_YOURS, Say.T_ISOLATED_PAWN_YOURS,
    Say.T_BISHOP_PAIR_THEIRS, Say.T_PASSED_PAWN_THEIRS, Say.T_OPEN_FILE_ROOK_THEIRS, Say.T_ROOK_SEVENTH_THEIRS,
    Say.T_CENTER_THEIRS, Say.IDLE2, Say.IDLE3 -> Mood.WORRIED
    Say.LOSE, Say.RESIGN, Say.END_STALEMATE -> Mood.SAD
    Say.B_QUIET, Say.H_QUIET, Say.IDLE1, Say.ASK_INTRO, Say.HINT_ASK, Say.T_CENTER_EMPTY, Say.T_OPEN_FILE_EMPTY, Say.T_ENDGAME_KING,
    Say.ENDGAME_ENTER, Say.UNDO -> Mood.THINK
    else -> Mood.CALM
}

/**
 * Kho câu nói. Ký hiệu thay thế:
 *  {me}/{Me} = thầy/Thầy · {you}/{You} = con/Con · {san} nước vừa đi · {piece} quân (Mã, Xe…) · {sq} ô · {file} cột
 *  {n} số · {opening} tên khai cuộc · {bot} tên đối thủ · {target} quân bị ăn
 */
object TeacherLines {

    private val bank: Map<Say, List<String>> = mapOf(
        Say.GAME_START_WHITE to listOf(
            "Vào ván nào! {You} cầm Trắng, đi trước. Nhớ ưu tiên trung tâm và đưa quân ra sớm nhé.",
            "Trắng đi trước là có lợi thế nhỏ. {Me} đứng đây xem {you} khai cuộc ra sao.",
            "Sẵn sàng chưa? Hít một hơi, nhìn cả bàn cờ rồi hãy đi nước đầu tiên.",
            "{Me} ngồi ngay cạnh {you} đây. Có gì sai {me} sẽ nhắc, còn đi đẹp thì {me} khen.",
            "Ván mới! Đánh {bot} thì đừng vội, cứ chắc từng nước một.",
        ),
        Say.GAME_START_BLACK to listOf(
            "{You} cầm Đen, đi sau. Đừng lo, quan sát nước đi của đối thủ rồi phản công cũng rất hay.",
            "Đen thì phải kiên nhẫn: giữ vững thế trận, chờ đối thủ sơ hở.",
            "Trắng đi trước rồi, giờ đến lượt {you} đáp trả. {Me} theo dõi từng nước nhé.",
            "Đen khó hơn một chút, nhưng nhiều cao thủ lại thích cầm Đen đấy. Bình tĩnh nào!",
            "Cứ để {bot} lộ ý đồ trước, rồi mình xử lý.",
        ),
        Say.GAME_START_ENDGAME to listOf(
            "Bài tàn cuộc: mỗi quân đều quý như vàng. Đếm nước thật kỹ trước khi đi.",
            "Tàn cuộc là nơi {you} học cách dùng Vua như một quân tấn công. Bắt đầu thôi!",
            "Thế này {me} cần {you} tính chính xác, không đoán mò. Từng nước một nhé.",
        ),
        Say.FIRST_E4 to listOf(
            "e4 — nước đi kinh điển, mở đường cho Tượng và Hậu. {Me} thích!",
            "Tốt vua tiến hai ô: chiếm trung tâm ngay từ đầu. Hay lắm.",
            "e4 là lựa chọn của rất nhiều đại kiện tướng. Giờ nhớ đưa Mã ra tiếp theo nhé.",
        ),
        Say.FIRST_D4 to listOf(
            "d4 — chắc chắn và vững vàng. Tốt hậu được bảo vệ ngay bởi Hậu đấy.",
            "Mở đầu bằng tốt hậu: lối chơi chậm mà sâu. Đúng gu của người thích chiến lược.",
            "d4: chiếm trung tâm mà không để lộ nhiều. {Me} khen.",
        ),
        Say.FIRST_NF3 to listOf(
            "Mã f3: linh hoạt, không cam kết sớm. Đây là kiểu khai cuộc rất 'tinh'.",
            "Đưa Mã ra trước là ổn — Mã nên ra trước Tượng, nhớ chưa?",
            "Nf3 giữ được nhiều khả năng cho {you} phía sau. Khôn đấy.",
        ),
        Say.FIRST_C4 to listOf(
            "c4 — Khai cuộc Anh! Nhắm vào ô d5 từ bên cánh. Cách chơi của người có chiều sâu.",
            "Tốt c tiến hai ô: kiềm chế trung tâm từ xa. Hay đấy!",
        ),
        Say.FIRST_OTHER to listOf(
            "Một nước đi hơi khác thường. Không sao, miễn là {you} nhớ chiếm trung tâm sau đó.",
            "Nước mở đầu ít gặp! {Me} tò mò xem {you} định làm gì tiếp.",
            "Nước đầu không quyết định ván cờ. Quan trọng là các nước sau cơ.",
        ),

        // ------------------------------------------------------------ người chơi vừa đi
        Say.H_CAPTURE_FREE to listOf(
            "{san} — ăn {target} mà không mất gì! Đẹp quá!",
            "Chuẩn rồi! {You} vừa ăn {target} của đối thủ, hết người bảo vệ luôn.",
            "{san} — thu hoạch {target} gọn ghẽ. Đó, nhìn kỹ thì sẽ thấy quân treo như vậy.",
            "Tuyệt! Quân {target} bị bỏ rơi thì cứ ăn thôi.",
            "{Me} khoái nước này: ăn {target} an toàn, lực lượng nghiêng hẳn về phía {you}.",
            "Mắt tinh thật! {You} không bỏ sót {target} nào cả.",
        ),
        Say.H_CAPTURE_TRADE to listOf(
            "{san} — một cuộc đổi quân công bằng. Khi đang hơn thì đổi bớt là cách hay.",
            "Đổi {target} lấy quân của mình. Hãy hỏi: đổi xong thế cờ của ai tốt hơn?",
            "Ăn quân rồi, giờ để ý xem đối thủ có ăn lại không nhé.",
            "Nước đổi quân đó làm thế cờ đơn giản hơn. Hơn quân thì nên đổi, kém quân thì tránh.",
            "{san}: đổi quân hợp lý. Đừng quên kiểm tra lại các quân còn lại.",
        ),
        Say.H_CAPTURE_PAWN to listOf(
            "Ăn được tốt rồi. Tốt nhỏ nhưng đủ để tạo lợi thế ở tàn cuộc.",
            "{san} — thêm một tốt. Cứ tích tiểu thành đại!",
            "Một tốt hơn là một lợi thế thật sự, miễn là Vua {you} vẫn an toàn.",
            "Ăn tốt đẹp đấy. Nhưng coi chừng bị đòn trả lại nhé.",
        ),
        Say.H_RECAPTURE to listOf(
            "Ăn lại ngay! Đó là phản xạ tốt: đòi lại đúng quân vừa mất.",
            "Ăn lại đúng ô — thế cờ trở về cân bằng. Gọn!",
            "{san}: đòi lại quân kịp thời, {me} thích kiểu phản ứng này.",
            "Đối thủ vừa ăn, {you} ăn lại liền. Đúng bài!",
        ),
        Say.H_CHECK to listOf(
            "Chiếu! Nhưng chiếu để làm gì? Hãy chắc nó dẫn tới lợi ích gì đó nhé.",
            "{san} — chiếu Vua! Đối thủ buộc phải đáp ngay, {you} nắm nhịp rồi.",
            "Chiếu liên tục chưa chắc đã hay, nhưng nước này thì có lý.",
            "Vua đối thủ bị chiếu: giờ thì họ không còn lựa chọn thoải mái nữa.",
            "Chiếu đúng lúc! Xem đối thủ đỡ thế nào rồi tính tiếp.",
        ),
        Say.H_MATE to listOf(
            "CHIẾU HẾT! {san} — Xuất sắc! Ván cờ là của {you}!",
            "Kết thúc đẹp! {You} đã chiếu hết đối thủ!",
            "Chiếu bí rồi! {Me} tự hào lắm!",
        ),
        Say.H_CASTLE_SHORT to listOf(
            "Nhập thành ngắn: Vua an toàn, Xe ra khỏi góc. Một công đôi việc!",
            "Đúng bài! Nhập thành sớm là thói quen của người chơi giỏi.",
            "Vua đã vào hầm trú ẩn. Giờ {you} yên tâm tấn công được rồi.",
            "O-O — {me} ưng cái bụng. Nhớ giữ các tốt phía trước Vua cho vững nhé.",
        ),
        Say.H_CASTLE_LONG to listOf(
            "Nhập thành dài: Xe vào giữa rất nhanh, nhưng Vua hơi 'hở' hơn. Cẩn thận cánh đó nhé.",
            "O-O-O! Một lựa chọn sắc bén: cả hai Xe đều lên chiến trường.",
            "Nhập thành dài thường đi kèm kế hoạch tấn công. {You} định đẩy tốt cánh nào?",
        ),
        Say.H_EP to listOf(
            "Bắt tốt qua đường! Luật hay bị quên mà {you} vẫn nhớ. Chuyên nghiệp!",
            "En passant! {Me} phải giơ ngón cái cho nước này.",
            "{san} — 'ăn tốt qua đường', món mà nhiều người chơi lâu năm vẫn chưa thạo.",
        ),
        Say.H_PROMOTE to listOf(
            "Phong cấp rồi! Cả hành trình dài của con tốt đã được đền đáp.",
            "{san} — Tốt đã hóa thân! Thế cờ đã đổi khác hoàn toàn.",
            "Phong Hậu! Giờ {you} có thêm một quân siêu mạnh.",
            "Tốt tới đích rồi. Nhớ kiểm tra xem đối thủ có đòn trả đũa nào không nhé.",
        ),
        Say.H_MOVED_INTO_DANGER to listOf(
            "Khoan! {piece} {you} vừa đi sẽ bị ăn đó. Nhìn vào ô {sq} xem.",
            "Ối, {san} đưa {piece} vào chỗ bị tấn công. Có thể hoàn tác nếu {you} muốn.",
            "Nước này để {piece} ở ô {sq} mà không ai bảo vệ cả. Coi chừng!",
            "{Me} lo cho {piece} của {you} đấy. Ô {sq} đang bị đối thủ nhắm tới.",
            "Trước khi thả quân, hãy hỏi: 'Ai tấn công ô này?'. Lần này thì có người rồi.",
        ),
        Say.H_LEFT_HANGING to listOf(
            "Chú ý! {piece} ở {sq} của {you} đang bị treo, và nước vừa đi chưa cứu nó.",
            "Đối thủ có thể ăn {piece} ở {sq} đấy. {You} có thấy không?",
            "Có quân của {you} đang không được bảo vệ — {piece} ở ô {sq}. Đừng bỏ quên nó.",
            "Nhìn lại cả bàn cờ nào: {piece} ở {sq} đang gặp nguy hiểm.",
        ),
        Say.H_MISSED_WIN to listOf(
            "{Me} thấy có miếng ngon ở {sq} mà {you} bỏ qua đó. Quân đó ăn được lời đấy!",
            "Ồ, có thể ăn quân ở ô {sq} nhưng {you} chọn nước khác. Lần sau nhớ quét hết các nước ăn quân trước nhé.",
            "Bỏ lỡ cơ hội rồi! Quân ở {sq} đang chờ {you} ăn mà.",
            "Trước khi đi, luôn kiểm tra: 'Có quân nào của đối thủ bị treo không?'. Lần này là {sq} đấy.",
        ),
        Say.H_REPEAT_PIECE to listOf(
            "Lại đi con vừa đi à? Ở khai cuộc, hãy đưa quân MỚI ra trận thay vì đi lại một quân.",
            "Một quân đi hai lần trong khai cuộc thì đối thủ sẽ phát triển nhanh hơn {you}. Đó!",
            "Nhớ nguyên tắc: mỗi quân ra một lần, rồi tới quân khác. Còn Tượng và Mã chưa ra kìa.",
        ),
        Say.H_EARLY_QUEEN to listOf(
            "Hậu ra sớm quá! Đối thủ sẽ vừa phát triển quân vừa đuổi Hậu của {you}.",
            "Hậu mạnh nhưng đừng ra sớm. Hãy để Mã và Tượng ra trước đã.",
            "Hậu một mình ngoài trận rất dễ bị săn. {Me} khuyên cho Hậu về vị trí an toàn.",
        ),
        Say.H_RIM_KNIGHT to listOf(
            "Mã ra rìa bàn rồi. Câu nói quen thuộc: 'Mã ở rìa là Mã yếu' — ở giữa mới nhiều nước đi.",
            "Mã ở biên chỉ kiểm soát được ít ô. Thử đưa nó vào trung tâm xem!",
            "{piece} ở cột {file} khá lạc lõng. Hãy tìm cách đưa nó về giữa bàn.",
        ),
        Say.H_DEVELOP to listOf(
            "Phát triển quân ra rồi — đúng nguyên tắc khai cuộc.",
            "{san} — đưa {piece} ra khỏi chuồng. {Me} gật gù.",
            "Quân ra càng sớm càng có nhiều lựa chọn. Làm tốt lắm!",
            "Đúng hướng! Mã và Tượng ra hết, rồi nhập thành.",
            "{piece} đã vào vị trí hoạt động. Nhớ nhìn xem nó đang dọa gì nhé.",
        ),
        Say.H_CENTER_PAWN to listOf(
            "Tốt vào trung tâm! Đây là bước chiếm thế quan trọng nhất ở khai cuộc.",
            "{san} — kiểm soát trung tâm là kiểm soát bàn cờ. Hay!",
            "Trung tâm vững là nền tảng mọi kế hoạch sau này. Đúng bài.",
        ),
        Say.H_ESCAPE_CHECK to listOf(
            "Đỡ chiếu gọn ghẽ. Nhớ ba cách: ăn quân chiếu, chắn đường, hoặc chạy Vua.",
            "Thoát chiếu rồi. Giờ nhìn lại xem đối thủ còn dọa gì nữa không.",
            "{san} — xử lý chiếu bình tĩnh, {me} thích.",
        ),
        Say.H_THREATENS to listOf(
            "Nước này dọa ăn {piece} ở {sq}. Đối thủ phải phản ứng rồi!",
            "Tạo thế dọa rồi: quân ở {sq} đang bị nhắm tới. Giờ xem đối thủ trả lời sao.",
            "{san} — {you} vừa tạo một mối đe dọa. Áp lực lên đối thủ nào!",
            "Hay đấy, {piece} ở {sq} giờ phải lo thân rồi.",
        ),
        Say.H_STALEMATE_GIVEN to listOf(
            "Cẩn thận! Nước này khiến đối thủ hết nước đi: hòa pat chứ không phải thắng!",
        ),
        Say.H_QUIET to listOf(
            "{san} — một nước đi bình thường, không có gì sai. Tiếp tục nào.",
            "Ổn rồi. Nhớ luôn tự hỏi: đối thủ vừa dọa gì, và {me} có thể dọa lại gì?",
            "Chưa có gì để chê. Giữ nhịp độ này nhé.",
            "Nước kín đáo nhưng hợp lý. Ván cờ còn dài.",
            "{san}. {Me} thấy {you} đang chơi khá chắc tay.",
            "Hãy kiểm tra từng quân: quân nào đang đứng chơi, đưa nó vào việc!",
            "Bình tĩnh, ván này {you} chưa thua đâu. Tiếp tục suy nghĩ cẩn thận.",
            "Nước này không ồn ào, nhưng cờ vua mà — nhiều khi nước kín mới là nước hay.",
        ),

        // ------------------------------------------------------------ máy vừa đi
        Say.B_CAPTURE to listOf(
            "{bot} vừa ăn {target} của {you}. Giờ xem có ăn lại được không?",
            "Mất {target} rồi. Bình tĩnh, nhìn xem có nước nào đòi lại được.",
            "{bot} ăn quân bằng {san}. Hãy kiểm tra xem quân vừa ăn có đang bị treo không.",
            "Mất quân là chuyện thường. Quan trọng là phản ứng tiếp theo của {you}.",
        ),
        Say.B_CHECK to listOf(
            "{bot} chiếu Vua! Nhớ ba cách đỡ: ăn, chắn, hoặc chạy.",
            "Chiếu rồi! Bình tĩnh, tìm cách đỡ tốt nhất, đừng chạy bừa.",
            "Vua bị chiếu: kiểm tra hết các nước đỡ rồi mới chọn.",
        ),
        Say.B_MATE to listOf(
            "Chiếu hết rồi... Không sao, thua ván này là bài học cho ván sau.",
            "{bot} thắng ván này. {You} đừng buồn, mình cùng xem lại chỗ nào sai nhé.",
        ),
        Say.B_CASTLE to listOf(
            "{bot} nhập thành. Vua máy đã an toàn, bây giờ nó có thể lo tấn công.",
            "Đối thủ đã nhập thành. Đến lượt {you} lo cho Vua của mình chưa?",
            "{bot} đưa Vua vào hầm. Nếu {you} chưa nhập thành, hãy nghĩ tới nó.",
        ),
        Say.B_PROMOTE to listOf(
            "{bot} phong cấp! Nguy hiểm đấy, hãy xem có cách nào chặn bù lại.",
            "Con tốt của máy đã tới đích. Thế cờ đã đổi, {you} cần tính cẩn thận.",
        ),
        Say.B_THREATENS to listOf(
            "{bot} vừa dọa quân ở {sq} của {you} đấy. Nhìn kỹ nhé!",
            "Có đòn dọa vào {piece} ở {sq}! {You} cần bảo vệ, di chuyển hoặc phản công.",
            "Nước {san} của máy nhắm vào ô {sq}. Hỏi ngay: 'Nó dọa gì?'",
            "Cẩn thận, {piece} ở {sq} đang bị tấn công.",
        ),
        Say.B_BLUNDER to listOf(
            "Ồ! {bot} vừa để hở quân ở {sq}. Cơ hội của {you} rồi, nhìn kỹ đi!",
            "Đối thủ sơ hở: {piece} ở {sq} đang bị treo. Đừng bỏ lỡ!",
            "{Me} thấy có miếng ăn. Quét hết các nước ăn quân xem sao.",
            "Máy vừa đi một nước không chắc. Kiểm tra ô {sq} nhé!",
        ),
        Say.B_DEVELOP to listOf(
            "{bot} đưa {piece} ra: {san}. {You} cũng nên phát triển quân của mình đi.",
            "Máy đang phát triển quân. Đừng để nó đi trước nhịp của {you}.",
            "{san} — nước phát triển hợp lý. Mình cũng ra quân thôi.",
        ),
        Say.B_QUIET to listOf(
            "{bot} đi {san}. Thử đoán xem nó đang muốn làm gì?",
            "Nước {san} của máy: có vẻ chuẩn bị gì đó. Nhìn xem nó mở đường cho quân nào.",
            "Đoán ý đối thủ là kỹ năng quan trọng. {san} nhắm vào đâu nhỉ?",
            "Máy đi {san}. Đến lượt {you} — đừng vội, nhìn cả bàn trước.",
            "{Me} thấy {bot} đi {san} khá thận trọng. {You} chọn kế hoạch nào đây?",
            "Mỗi nước của đối thủ đều có lý do. Tìm lý do của {san} đi!",
            "Lượt của {you}. Thử liệt kê: nước chiếu, nước ăn, nước dọa — rồi chọn.",
        ),
        Say.B_EP to listOf(
            "Máy vừa bắt tốt qua đường! Luật này khá tinh vi đấy.",
        ),

        // ------------------------------------------------------------ thế cờ
        Say.T_HANGING_YOURS to listOf(
            "{piece} ở {sq} của {you} đang bị treo — không ai bảo vệ cả. Cứu nó đi!",
            "Báo động! {piece} ở {sq} có thể bị ăn không. Bảo vệ hoặc di chuyển ngay.",
            "Đối thủ có thể ăn {piece} ở {sq} mà không mất gì. Đừng để chuyện đó xảy ra!",
        ),
        Say.T_HANGING_THEIRS to listOf(
            "Nhìn kìa! {piece} đối thủ ở {sq} đang bị treo. Ăn được!",
            "Cơ hội: {piece} ở {sq} không ai bảo vệ. {You} thấy chưa?",
            "{Me} thấy một quân treo của đối thủ ở ô {sq}. Ăn ngay trước khi nó chạy!",
        ),
        Say.T_ATTACKED_BY_LESSER_YOURS to listOf(
            "{piece} ở {sq} đang bị quân yếu hơn dọa. Đổi như vậy thì lỗ đấy, tránh đi!",
            "Quân nhỏ đang đuổi {piece} của {you} ở {sq}. Đừng để bị đổi lỗ nhé.",
            "{piece} ở {sq} nên di chuyển: có quân nhẹ hơn đang nhắm nó.",
        ),
        Say.T_ATTACKED_BY_LESSER_THEIRS to listOf(
            "{piece} đối thủ ở {sq} đang bị quân nhẹ hơn dọa. Nếu ăn thì {you} có lời!",
            "Ô {sq}: quân của đối thủ bị quân yếu hơn tấn công. Thử ăn xem!",
            "Đối thủ có {piece} ở {sq} đang lúng túng: bị dọa bởi quân nhỏ.",
        ),
        Say.T_FORK_AVAILABLE to listOf(
            "Ồ, {me} thấy một đòn đôi đang chờ {you}! Quân nào đi tới ô {sq} sẽ dọa hai quân cùng lúc.",
            "Có đòn chĩa hai quân ở đây. Tìm ô mà một quân dọa được cả hai nhé!",
            "Thế cờ có đòn đôi! Gợi ý: nhìn ô {sq}.",
            "Chú ý các quân đối thủ nằm 'cùng tầm': có nước đi dọa cùng lúc hai quân. Tìm đi!",
        ),
        Say.T_MATE_IN_ONE_AVAILABLE to listOf(
            "CÓ CHIẾU HẾT trong một nước! Nhìn kỹ lại bàn cờ đi, chỉ một nước thôi!",
            "{Me} thấy nước chiếu hết rồi đấy. {You} tìm ra không? Hãy xem các nước chiếu.",
            "Đừng bỏ lỡ! Có một nước chiếu hết ngay. Thử từng nước chiếu một.",
            "Chiếu hết trong 1! Gợi ý: nhìn ô {sq}.",
        ),
        Say.T_PIN_YOURS to listOf(
            "{piece} ở {sq} của {you} đang bị ghim: nếu nó đi, Vua bị lộ. Giải phóng nó đi.",
            "Bị ghim rồi! Quân ở {sq} không thể rời vị trí vì đứng giữa Vua và quân tấn công.",
            "Thế ghim làm {piece} ở {sq} 'tê liệt'. Hãy chặn hoặc ăn quân ghim.",
        ),
        Say.T_PIN_THEIRS to listOf(
            "Đối thủ có {piece} bị ghim ở {sq}! Dồn thêm quân vào đó là ăn được.",
            "Quân ở {sq} của đối thủ không thể di chuyển — nó đang bị ghim. Khai thác đi!",
            "Ghim đẹp! Tấn công quân bị ghim bằng tốt là chiêu rất hay.",
        ),
        Say.T_BACK_RANK_YOURS to listOf(
            "Vua {you} bị bít ở hàng cuối, không có ô thoát. Hãy đi một tốt để tạo 'lỗ thoát' (luft).",
            "Cảnh báo: chiếu hết ở hàng cuối là cách thua rất phổ biến. Tạo đường thoát cho Vua nhé.",
            "Vua {you} đang tự nhốt mình bằng chính các tốt phía trước. Đi h3 hoặc h6 đi!",
        ),
        Say.T_BACK_RANK_THEIRS to listOf(
            "Vua đối thủ không có ô thoát ở hàng cuối. Một Xe hay Hậu cắm vào hàng đó có thể rất nguy hiểm!",
            "Hàng cuối của đối thủ bị bít. {You} có để ý đòn chiếu hết hàng cuối không?",
        ),
        Say.T_OPEN_FILE_ROOK_YOURS to listOf(
            "Xe của {you} đang đứng trên cột {file} thoáng — rất tốt! Xe thích cột mở.",
            "Xe chiếm cột mở rồi. Giờ tính đưa nó vào hàng 7 hoặc hàng 8 của đối thủ.",
            "Cột {file} thông thoáng, Xe {you} tha hồ hoạt động.",
        ),
        Say.T_OPEN_FILE_ROOK_THEIRS to listOf(
            "Xe đối thủ chiếm cột {file}. Hãy cẩn thận những quân của {you} nằm trên cột đó.",
            "Đối thủ có Xe trên cột mở. Hãy tranh chấp hoặc chặn bằng quân nhẹ.",
        ),
        Say.T_OPEN_FILE_EMPTY to listOf(
            "Cột {file} đang mở mà chưa có Xe nào. Đặt Xe lên đó đi!",
            "Có cột mở bỏ trống: Xe là quân thích hợp nhất để chiếm lấy.",
        ),
        Say.T_ROOK_SEVENTH_YOURS to listOf(
            "Xe lên hàng 7! Đây là vị trí 'vàng': Xe ăn tốt và dồn Vua đối thủ.",
            "Xe chiếm hàng 7 rồi — rất khó chịu cho đối thủ!",
        ),
        Say.T_ROOK_SEVENTH_THEIRS to listOf(
            "Xe đối thủ đã lên hàng 7 của {you}. Hãy lo cho các tốt ở hàng đó.",
            "Xe địch xâm nhập hàng 7. Cần đuổi nó đi hoặc đổi Xe.",
        ),
        Say.T_PASSED_PAWN_YOURS to listOf(
            "{You} có tốt thông ở {sq}! Không còn tốt nào chặn đường. Đẩy nó đi, nhưng có quân hỗ trợ.",
            "Tốt thông là vũ khí ở tàn cuộc. Hãy bảo vệ và đẩy tốt ở {sq} lên dần.",
            "Tốt ở {sq} chẳng còn ai ngăn: một tài sản quý, đừng để mất.",
        ),
        Say.T_PASSED_PAWN_THEIRS to listOf(
            "Đối thủ có tốt thông ở {sq}. Phải chặn nó bằng quân, đừng để nó lên cao.",
            "Cẩn thận tốt thông ở {sq} của đối thủ: 'chặn' nó bằng Mã hoặc Vua là tốt nhất.",
        ),
        Say.T_DOUBLED_PAWNS_YOURS to listOf(
            "Tốt cột {file} của {you} bị chồng lên nhau. Cấu trúc tốt hơi yếu, hãy cẩn thận.",
            "Tốt chồng khiến {you} thiếu linh hoạt. Có thể bù lại bằng cột mở cho Xe.",
        ),
        Say.T_DOUBLED_PAWNS_THEIRS to listOf(
            "Tốt đối thủ bị chồng ở cột {file}: một điểm yếu để nhắm tới.",
            "Cấu trúc tốt của đối thủ không đẹp (tốt chồng). Về lâu dài {you} có lợi.",
        ),
        Say.T_ISOLATED_PAWN_YOURS to listOf(
            "Tốt ở {sq} bị cô lập — không còn tốt bạn bên cạnh. Hãy bảo vệ bằng quân.",
            "Tốt cô lập thường là mục tiêu tấn công. Đừng để nó thành 'mồi'.",
        ),
        Say.T_ISOLATED_PAWN_THEIRS to listOf(
            "Tốt đối thủ ở {sq} bị cô lập! Hãy nhắm vào nó.",
            "Con tốt đơn độc ở {sq} của đối thủ là điểm yếu. Dồn quân vào đó!",
        ),
        Say.T_BISHOP_PAIR_YOURS to listOf(
            "{You} còn cặp Tượng, đối thủ thì không. Cặp Tượng rất mạnh khi bàn cờ thoáng.",
            "Cặp Tượng là lợi thế dài hạn. Mở bàn cờ ra để chúng phát huy nhé.",
        ),
        Say.T_BISHOP_PAIR_THEIRS to listOf(
            "Đối thủ có cặp Tượng. Giữ bàn cờ khép kín để hạn chế chúng.",
            "Cặp Tượng của đối thủ rất khó chịu khi bàn cờ mở. Cẩn thận nhé.",
        ),
        Say.T_CENTER_YOURS to listOf(
            "{You} đang giữ trung tâm vững. Đây là nền tảng cho mọi kế hoạch!",
            "Tốt giữa bàn của {you} rất đẹp. Giờ đưa quân ra hỗ trợ.",
        ),
        Say.T_CENTER_THEIRS to listOf(
            "Đối thủ đang chiếm trung tâm. Hãy tìm cách tranh chấp bằng tốt c hoặc f nhé.",
            "Tốt giữa bàn của đối thủ đang chiếm không gian. {You} phản công trung tâm đi.",
        ),
        Say.T_CENTER_EMPTY to listOf(
            "Trung tâm còn bỏ trống. Ai chiếm trước người đó có lợi thế!",
            "Bốn ô giữa bàn đang chưa ai chiếm. {You} đưa tốt hoặc quân vào kiểm soát đi.",
        ),
        Say.T_KING_EXPOSED_YOURS to listOf(
            "Vua {you} hơi trống trải: thiếu tốt che chắn. Cẩn thận các đòn tấn công trực tiếp.",
            "An toàn của Vua là số 1! Tốt phía trước Vua {you} đang thưa quá.",
            "Vua {you} đang 'hở sườn'. Đừng để đối thủ lợi dụng.",
        ),
        Say.T_KING_EXPOSED_THEIRS to listOf(
            "Vua đối thủ thiếu tốt che chắn. Có thể tấn công được đấy!",
            "Hàng rào tốt quanh Vua đối thủ đã bị thủng. Dồn quân vào cánh đó nhé!",
        ),
        Say.T_KING_STUCK_YOURS to listOf(
            "Vua {you} vẫn kẹt giữa bàn mà chưa nhập thành. Nhanh nhập thành trước khi bị tấn công.",
            "Vua ở giữa bàn rất nguy hiểm khi các quân lớn còn đầy. Nhập thành đi!",
        ),
        Say.T_KING_STUCK_THEIRS to listOf(
            "Vua đối thủ chưa nhập thành và vẫn ở giữa bàn. Mở các cột để tấn công nó!",
            "Vua đối thủ đang ở chỗ nguy hiểm: mở đường và dồn quân vào.",
        ),
        Say.T_UNDEVELOPED_YOURS to listOf(
            "{You} còn {n} quân nhẹ chưa ra khỏi chuồng. Đưa chúng ra đi!",
            "Quân chưa phát triển sẽ làm {you} chậm hơn đối thủ. Mã và Tượng đang chờ kìa.",
        ),
        Say.T_UNDEVELOPED_THEIRS to listOf(
            "Đối thủ còn {n} quân chưa ra. Tấn công nhanh vào trung tâm lúc này có lợi!",
            "Đối thủ phát triển chậm. {You} nên mở thế cờ để khai thác.",
        ),
        Say.T_ENDGAME_KING to listOf(
            "Sang tàn cuộc rồi. Đưa Vua ra giữa bàn: Vua lúc này là quân chiến đấu!",
            "Tàn cuộc: Vua không còn phải trốn. Đưa nó lên hỗ trợ tốt thông nhé.",
            "Ít quân thì Vua thành quân mạnh. Hãy dùng nó!",
        ),
        Say.T_OPPONENT_CRAMPED to listOf(
            "Đối thủ chỉ còn {n} nước đi hợp lệ. Chú ý hòa pat: đừng làm họ hết nước khi mình đang hơn!",
            "Đối thủ bị dồn vào góc. Tiếp tục siết, nhưng tránh bí nước!",
        ),
        Say.T_MATERIAL_UP to listOf(
            "{You} đang hơn quân. Đổi bớt quân và giữ an toàn là cách thắng chắc nhất.",
            "Lực lượng nghiêng về phía {you}. Đơn giản hóa thế cờ nhé.",
        ),
        Say.T_MATERIAL_DOWN to listOf(
            "{You} đang kém quân. Hãy tìm đòn chiến thuật hoặc tạo bẫy: đừng đổi quân lúc này.",
            "Thế kém quân thì phải phức tạp hóa. Nhìn kỹ các đòn dọa nhé!",
        ),
        Say.T_MATERIAL_EVEN to listOf(
            "Lực lượng cân bằng. Ván cờ được quyết định bởi các chi tiết nhỏ.",
            "Hai bên bằng quân. Hãy tìm kế hoạch dài hạn: cột mở, tốt thông, an toàn Vua.",
        ),

        // ------------------------------------------------------------ diễn biến ván
        Say.OPENING_NAME to listOf(
            "Đây là {opening}. Biết tên khai cuộc giúp {you} nhớ cách chơi!",
            "{opening} — một khai cuộc có tên tuổi. Hãy đào sâu nó sau ván này.",
            "Ồ, {opening}. Quen thuộc đấy! Các nước tiếp theo đã có sách giải sẵn.",
        ),
        Say.ENDGAME_ENTER to listOf(
            "Ván cờ bước vào tàn cuộc. Đếm tốt, tìm tốt thông, đưa Vua ra trận.",
            "Tàn cuộc đến rồi. Mọi nước đều quan trọng gấp đôi.",
        ),
        Say.ADV_UP to listOf(
            "Bây giờ {you} đang hơn rõ rệt. Đừng chủ quan, cứ chắc từng nước một.",
            "Thế cờ nghiêng về {you}! Giữ bình tĩnh và đơn giản hóa.",
        ),
        Say.ADV_DOWN to listOf(
            "Hơi khó rồi, nhưng chưa hết! Cố tạo bẫy cho đối thủ.",
            "{You} đang bị dồn. Đừng hoảng: tìm nước phòng thủ chắc nhất.",
        ),
        Say.COMEBACK to listOf(
            "Lật ngược thế cờ rồi! Đây mới là tinh thần chiến binh.",
            "Hay lắm, từ thế kém đã gỡ lại. Đó là điều làm nên người chơi giỏi!",
        ),
        Say.STREAK to listOf(
            "Ba nước liên tiếp đều chắc! {You} đang vào phong độ.",
            "Đi liên tục những nước tốt, {me} thấy rõ tiến bộ.",
        ),
        Say.FIFTY_WARN to listOf(
            "Sắp chạm luật 50 nước không ăn quân hay đi tốt. Nếu muốn thắng, phải đẩy tốt hoặc đổi quân.",
        ),
        Say.REPETITION_WARN to listOf(
            "Thế cờ đang lặp lại. Ba lần là hòa. Nếu muốn thắng thì phải đổi kế hoạch.",
        ),

        // ------------------------------------------------------------ nhãn engine
        Say.LABEL_BRILLIANT to listOf(
            "{san} là nước TUYỆT DIỆU! Chính {me} cũng phải ngả mũ.",
            "Nước đi xuất sắc nhất! {You} vừa chơi như đại kiện tướng.",
        ),
        Say.LABEL_GREAT to listOf(
            "{san} — nước đi rất hay, chỉ có một nước tốt như vậy thôi!",
            "Rất sắc! {You} tìm được nước khó tìm.",
        ),
        Say.LABEL_BEST to listOf(
            "{san} là nước tốt nhất. Máy cũng chọn như {you}!",
            "Chuẩn không cần chỉnh: nước tốt nhất trên bàn.",
        ),
        Say.LABEL_EXCELLENT to listOf(
            "{san} — nước rất tốt, gần với lựa chọn hoàn hảo.",
            "Gần như hoàn hảo. {Me} chấm cao!",
        ),
        Say.LABEL_GOOD to listOf(
            "{san} — nước tốt, vững vàng.",
            "Ổn áp! {You} không mất gì ở nước này.",
        ),
        Say.LABEL_BOOK to listOf(
            "{san} là nước trong sách khai cuộc. {You} đã học bài!",
            "Nước quen thuộc của lý thuyết. Tốt lắm.",
        ),
        Say.LABEL_INACCURACY to listOf(
            "{san} hơi thiếu chính xác. Vẫn có nước tốt hơn, nhưng chưa nghiêm trọng.",
            "Nước đó chưa tối ưu. Lần sau hãy thử so sánh thêm một phương án.",
        ),
        Say.LABEL_MISTAKE to listOf(
            "{san} là một sai lầm. Đối thủ có thể lợi dụng, cẩn thận nhé.",
            "Nước này làm thế cờ xấu đi. Đừng nản, tìm cách sửa ngay.",
        ),
        Say.LABEL_BLUNDER to listOf(
            "{san} là sai lầm nghiêm trọng! Hãy thử tìm xem đối thủ có thể làm gì.",
            "Ối, nước này tệ rồi. Nhưng cờ chưa kết thúc — cố gắng gỡ lại!",
        ),
        Say.LABEL_MISS to listOf(
            "{san} bỏ lỡ cơ hội. Trước đó có nước mạnh hơn nhiều đấy!",
            "Có một đòn tốt hơn mà {you} chưa thấy. Xem lại sau ván nhé.",
        ),

        // ------------------------------------------------------------ tương tác
        Say.UNDO to listOf(
            "Đi lại nào. Lần này hãy nghĩ kỹ trước khi thả quân.",
            "Hoàn tác rồi. Nhớ lại: vì sao nước trước không ổn?",
            "Cho {you} đi lại, nhưng đừng thành thói quen nhé!",
            "Tốt, nhìn lại thế cờ rồi chọn nước khác.",
        ),
        Say.HINT_ASK to listOf(
            "Để {me} nghĩ xem… Chờ chút nhé.",
            "Hừm, {me} đang tính toán…",
            "Đang soi thế cờ… đợi {me} tí.",
        ),
        Say.HINT_GIVEN to listOf(
            "Đây rồi! Nước tốt nhất theo {me}: {san}. Hãy hiểu vì sao nó tốt nhé.",
            "{me} khuyên {san}. Nhìn mũi tên trên bàn, và tự hỏi tại sao.",
            "{san}! Thử đoán xem nó giải quyết vấn đề gì.",
            "Nên đi {san} — {you} xem mũi tên chỉ cho rõ nhé.",
        ),
        Say.ASK_INTRO to listOf(
            "Để {me} nhìn bàn cờ cho {you}…",
            "Ừm, {me} xem một lượt nào.",
            "Được, {me} nói những gì {me} thấy.",
        ),
        Say.ASK_NOTHING to listOf(
            "{Me} chưa thấy điều gì đặc biệt. Thế cờ khá yên ả. Cứ phát triển quân và giữ an toàn nhé.",
            "Bàn cờ lúc này chưa có đòn nào nổi bật. Đừng vội, cứ tìm nước hợp lý nhất.",
        ),
        Say.IDLE1 to listOf(
            "Đang nghĩ à? Cứ thong thả, nhưng nhớ nhìn các nước chiếu, nước ăn, nước dọa.",
            "Không vội đâu. Hãy kiểm tra: quân nào của {you} đang bị dọa?",
            "Mất thời gian là bình thường. Tính từng nước một nhé.",
        ),
        Say.IDLE2 to listOf(
            "{You} nghĩ lâu rồi đó. Nếu bí, bấm Gợi ý để {me} chỉ cho.",
            "Hơi lâu rồi nhé. Thử tìm quân nào của {you} chưa ra trận.",
            "Nếu chưa biết đi đâu, hãy đưa quân tệ nhất của {you} vào vị trí tốt hơn.",
        ),
        Say.IDLE3 to listOf(
            "Lâu thế! {Me} sắp ngủ gật rồi đó. Bấm Gợi ý nếu cần nhé.",
            "{You} còn đó không? Đối thủ đang chờ kìa.",
            "Cứ chọn một nước hợp lý rồi đi, đừng sợ sai. Sai thì học!",
        ),
        Say.POKE to listOf(
            "Ái! Đừng chọc thầy chứ. À mà {you} có biết: tốt thông cần Vua hỗ trợ mới thắng không?",
            "Gọi {me} à? Nhớ này: 'Đi quân phải có mục đích'.",
            "Hả? À, {me} đang xem bàn cờ. {You} cần gì cứ hỏi nhé.",
            "Nhột quá! Nhưng cũng được, {me} nhắc {you}: luôn nhìn nước dọa của đối thủ trước.",
            "Chạm {me} làm gì? Mà thôi, cho {you} một mẹo nhỏ nhé!",
        ),
        Say.TIP to listOf(
            "Mẹo: trước mỗi nước đi, hãy hỏi 'Đối thủ đang dọa gì?'",
            "Mẹo: Mã mạnh nhất ở giữa bàn, yếu nhất ở rìa.",
            "Mẹo: Xe thích cột mở và hàng 7.",
            "Mẹo: Đừng đi Hậu quá sớm, để Mã và Tượng ra trước.",
            "Mẹo: Nhập thành sớm để bảo vệ Vua và đưa Xe vào cuộc.",
            "Mẹo: Đổi quân khi đang hơn, tránh đổi khi đang kém.",
            "Mẹo: Tốt không thể đi lùi, nên mỗi nước tốt đi là một cam kết.",
            "Mẹo: Ở tàn cuộc, Vua là quân mạnh — hãy đưa nó ra giữa bàn.",
            "Mẹo: Kiểm tra theo thứ tự: chiếu, ăn quân, dọa. Thói quen này giúp tránh nhiều sai lầm.",
            "Mẹo: Tượng và Mã đều trị giá khoảng 3 tốt. Xe 5, Hậu 9.",
            "Mẹo: Hai Tượng thường mạnh hơn Tượng và Mã khi bàn cờ thoáng.",
            "Mẹo: Quân bị ghim không thể rời vị trí: hãy tấn công chúng!",
            "Mẹo: Đòn đôi (fork) thường do Mã thực hiện, vì Mã đi kiểu chữ L.",
            "Mẹo: Luôn tạo 'luft' cho Vua để tránh chiếu hết ở hàng cuối.",
            "Mẹo: Đừng đưa quân vào ô mà đối thủ tấn công nhiều hơn mình bảo vệ.",
            "Mẹo: Cờ vua không phải chạy đua ăn quân. Có khi nước kín đáo mới là nước hay.",
            "Mẹo: Khi đối thủ sai lầm, đừng vội. Kiểm tra xem có đòn nào ẩn sau không.",
            "Mẹo: Tốt thông cần Vua hoặc Xe hỗ trợ mới thành công.",
            "Mẹo: Xe sau tốt thông là vị trí mạnh nhất ở tàn cuộc Xe.",
            "Mẹo: Khi bí, hãy cải thiện quân tệ nhất của mình.",
            "Mẹo: Phản xạ 'ăn lại' phải luôn kiểm tra xem có đòn nào ẩn không.",
            "Mẹo: Mỗi ván cờ đều là bài học. Xem lại sau ván để thấy lỗi.",
            "Mẹo: Đừng thay đổi kế hoạch chỉ vì sợ. Hãy thay đổi khi thế cờ thay đổi.",
            "Mẹo: Hãy luôn hỏi: nước này của mình có mở đường cho đối thủ không?",
        ),
        Say.JOKE to listOf(
            "Biết vì sao Mã đi chữ L không? Vì nó sợ bị gọi là 'thẳng tính' đấy!",
            "Tốt đi một bước mà tưởng mình thành Hậu. Mơ ước đẹp lắm.",
            "Vua mà cũng biết lo: suốt ngày chỉ đi một ô vì sợ bị chiếu.",
            "Tượng chỉ đi chéo vì nó sợ gặp mặt trực tiếp với Xe.",
            "Hậu mạnh nhất mà vẫn nghe lời Vua. Quyền lực thật sự là ở đó!",
            "Cờ vua là trò duy nhất mà hy sinh Hậu vẫn có thể thắng.",
            "Mất Hậu cũng không sao đâu. Mất bình tĩnh mới nguy hiểm!",
            "Thua một ván thì học thêm một bài. Thua mười ván thì thành thầy luôn.",
            "Nước nào cũng có lý do. Kể cả nước 'lỡ tay'.",
            "Đừng sợ chiếu: Vua mà, nó biết chạy mà!",
        ),

        // ------------------------------------------------------------ kết thúc
        Say.WIN to listOf(
            "THẮNG RỒI! {Me} tự hào về {you} lắm!",
            "Chiến thắng xứng đáng! Hãy xem lại ván để biết {you} đã chơi hay chỗ nào.",
            "Chúc mừng! {You} đã chơi rất chắc.",
            "Ván này {you} làm rất tốt. Nghỉ chút rồi ván tiếp nhé!",
        ),
        Say.LOSE to listOf(
            "Không sao đâu. Thua một ván là học thêm được một bài. Mình xem lại cùng nhau.",
            "Đừng buồn. Cao thủ nào cũng từng thua nhiều ván. Xem lại phần Review nhé.",
            "Ván này {you} chưa thắng, nhưng {you} đã cố gắng. Ván sau sẽ khác!",
            "Thua cũng là bài học. Hãy xem chỗ nào thế cờ đổi chiều.",
        ),
        Say.DRAW to listOf(
            "Hòa cờ! Không thua cũng đáng giá, nhất là với đối thủ mạnh.",
            "Hòa. Xem lại: lúc nào {you} có thể thắng?",
            "Một kết quả cân bằng. Xem lại để biết có bỏ lỡ cơ hội nào không.",
        ),
        Say.RESIGN to listOf(
            "Chịu thua cũng cần can đảm. Mình xem lại xem sai ở chỗ nào nhé.",
            "Được rồi, ván sau gỡ lại. Nhớ lại thế cờ lúc quyết định sai.",
        ),
        Say.END_STALEMATE to listOf(
            "Hòa pat! Đáng tiếc, nếu hơn quân thì cẩn thận đừng để đối thủ hết nước.",
            "Hết nước đi mà không bị chiếu là hòa. Bài học đáng nhớ!",
        ),
    )

    /** Câu mở đầu thêm vào cho "đậm tính cách". Có xác suất xuất hiện, tùy tâm trạng. */
    private val openers: Map<Persona, Map<Mood, List<String>>> = mapOf(
        Persona.GENTLE to mapOf(
            Mood.HAPPY to listOf("Ừ, tốt lắm. ", "Hay đấy con. ", "Thầy vui lắm. "),
            Mood.CHEER to listOf("Giỏi quá! ", "Tuyệt vời con! ", "Thầy tự hào! "),
            Mood.PROUD to listOf("Giỏi lắm. "),
            Mood.WORRIED to listOf("Con ơi! ", "Nhẹ nhàng nhé. ", "Thầy nhắc nhỏ nhé. "),
            Mood.ALARM to listOf("Khoan đã con! ", "Chậm lại một chút! ", "Cẩn thận nhé! "),
            Mood.SAD to listOf("Không sao đâu con. ", "Thầy hiểu mà. "),
            Mood.THINK to listOf("Hừm… ", "Để xem nào. "),
            Mood.CALM to listOf("", "", "Ừm. "),
        ),
        Persona.STRICT to mapOf(
            Mood.HAPPY to listOf("Được. ", "Tạm ổn. ", "Đúng rồi. "),
            Mood.CHEER to listOf("Tốt. Rất tốt. ", "Xuất sắc. ", "Đạt yêu cầu. "),
            Mood.PROUD to listOf("Khá lắm. "),
            Mood.WORRIED to listOf("Chú ý. ", "Chưa tốt. ", "Em phải nhớ kỹ. "),
            Mood.ALARM to listOf("Dừng lại! ", "Em nhìn kỹ lại! ", "Sai rồi! "),
            Mood.SAD to listOf("Thua là thua. ", "Chấp nhận và học. "),
            Mood.THINK to listOf("Quan sát. ", "Suy nghĩ. "),
            Mood.CALM to listOf("", "", "Tiếp tục. "),
        ),
        Persona.FUNNY to mapOf(
            Mood.HAPPY to listOf("Ồ la la! ", "Xịn! ", "Được nha! "),
            Mood.CHEER to listOf("Wow! ", "Đỉnh của chóp! ", "Chơi lớn nha! ", "Quá đã! "),
            Mood.PROUD to listOf("Tự hào ghê! "),
            Mood.WORRIED to listOf("Ơ kìa! ", "Úi! ", "Hmm bạn ơi! "),
            Mood.ALARM to listOf("Ối giời! ", "Khoan khoan khoan! ", "Alo alo! "),
            Mood.SAD to listOf("Huhu. ", "Thôi nào. "),
            Mood.THINK to listOf("Để tui nghĩ… ", "Hmmmm. "),
            Mood.CALM to listOf("", "", "À há. "),
        ),
    )

    fun lines(say: Say): List<String> = bank[say] ?: emptyList()
    fun opener(p: Persona, mood: Mood, roll: Double): String {
        if (roll > 0.55) return ""   // ~55% câu có phụ họa
        val list = openers[p]?.get(mood) ?: return ""
        if (list.isEmpty()) return ""
        return list[(roll * 1000).toInt() % list.size]
    }
    fun all(): Map<Say, List<String>> = bank
}
