package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.review.GameReview
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.ReviewDisplay
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

// =====================================================================================
// Các phần giao diện của hộp thoại "Game Review" cuối ván (giống màn chờ của chess.com):
//   · ReviewLabelCycler   : 3 nhãn đổi liên tục trong lúc Stockfish phân tích
//   · KnightLoadingBoard  : bàn 3x3 có con mã nhảy
//   · ReviewLabelResults  : khi xong, 3 nhãn trên được thay bằng các nhãn THẬT của ván (kèm số nước)
// =====================================================================================

/** Chiều cao cố định của hàng nhãn: chờ -> xong không làm hộp thoại giật. */
val ReviewLabelRowHeight = 70.dp

private val CycleOrder = listOf(
    LabelBadge.BRILLIANT, LabelBadge.MISTAKE, LabelBadge.BEST, LabelBadge.GREAT, LabelBadge.BLUNDER,
    LabelBadge.BOOK, LabelBadge.GOOD, LabelBadge.INACCURACY, LabelBadge.EXCELLENT, LabelBadge.MISS,
)

/** Thứ tự hiển thị (tốt -> xấu), giống bảng thống kê ở màn Review. */
private val DisplayOrder = listOf(
    MoveLabel.BRILLIANT, MoveLabel.GREAT, MoveLabel.BEST, MoveLabel.EXCELLENT, MoveLabel.GOOD,
    MoveLabel.BOOK, MoveLabel.INACCURACY, MoveLabel.MISTAKE, MoveLabel.MISS, MoveLabel.BLUNDER,
)

/** Thứ tự ưu tiên khi chỉ đủ chỗ cho vài nhãn: nước nổi bật và lỗi trước. */
private val PriorityOrder = listOf(
    MoveLabel.BRILLIANT, MoveLabel.GREAT, MoveLabel.BEST, MoveLabel.BLUNDER, MoveLabel.MISTAKE, MoveLabel.MISS,
    MoveLabel.INACCURACY, MoveLabel.EXCELLENT, MoveLabel.GOOD, MoveLabel.BOOK,
)

class LabelCount(val badge: LabelBadge, val count: Int)

/**
 * Các nhãn của ván để hiện khi phân tích xong. [humanWhite] = null (2 người cùng máy) thì gộp cả hai bên.
 * Chọn tối đa [max] nhãn có số nước > 0, xếp theo thứ tự tốt -> xấu.
 */
fun reviewHighlights(review: GameReview, humanWhite: Boolean?, max: Int = 6): List<LabelCount> {
    val counts: Map<MoveLabel, Int> =
        if (humanWhite != null) {
            ReviewDisplay.countsByLabel(review, humanWhite)
        } else {
            val w = ReviewDisplay.countsByLabel(review, true)
            val b = ReviewDisplay.countsByLabel(review, false)
            MoveLabel.values().associateWith { (w[it] ?: 0) + (b[it] ?: 0) }
        }
    val picked = PriorityOrder.filter { (counts[it] ?: 0) > 0 }.take(max).toSet()
    return DisplayOrder.filter { it in picked }.map { LabelCount(it.badge(), counts[it] ?: 0) }
}

/** Nhãn nảy ra (scale lò xo) mỗi khi [badge] đổi. */
@Composable
private fun PopBadge(badge: LabelBadge, size: Dp, delayMs: Long = 0L) {
    val s = remember(badge) { Animatable(0.4f) }
    LaunchedEffect(badge) {
        delay(delayMs)
        s.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium))
    }
    LabelGlyph(
        badge, size,
        Modifier.graphicsLayer {
            scaleX = s.value
            scaleY = s.value
        },
    )
}

/** 3 nhãn đổi liên tục (mỗi ~0,6 giây) trong lúc chờ phân tích. */
@Composable
fun ReviewLabelCycler(modifier: Modifier = Modifier) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(620)
            tick += 1
        }
    }
    Row(
        modifier.fillMaxWidth().height(ReviewLabelRowHeight),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (slot in 0 until 3) {
            PopBadge(CycleOrder[(tick * 3 + slot) % CycleOrder.size], 44.dp, delayMs = slot * 70L)
        }
    }
}

/** Phân tích xong: các nhãn thật của ván + số nước, hiện lần lượt. */
@Composable
fun ReviewLabelResults(items: List<LabelCount>, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().height(ReviewLabelRowHeight),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, item ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PopBadge(item.badge, 40.dp, delayMs = i * 90L)
                Text(item.count.toString(), color = item.badge.color, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

// ------------------------------------------------------------------ Bàn 3x3 + con mã nhảy

/** Vòng đi của con mã trên bàn 3x3 (8 ô ngoài, ô giữa không đi tới được): [hàng, cột]. */
private val KnightPath = arrayOf(
    intArrayOf(0, 0), intArrayOf(1, 2), intArrayOf(2, 0), intArrayOf(0, 1),
    intArrayOf(2, 2), intArrayOf(1, 0), intArrayOf(0, 2), intArrayOf(2, 1),
)

@Composable
fun KnightLoadingBoard(knight: ImageBitmap?, modifier: Modifier = Modifier) {
    var step by remember { mutableIntStateOf(0) }
    val t = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        while (true) {
            t.snapTo(0f)
            t.animateTo(1f, tween(430, easing = FastOutSlowInEasing))
            delay(170)
            step += 1
        }
    }
    Box(modifier.size(208.dp).padding(bottom = 8.dp)) {
        Box(Modifier.fillMaxSize().offset(y = 8.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF3A3936)))
        Canvas(Modifier.fillMaxSize().clip(RoundedCornerShape(26.dp))) {
            val cell = size.width / 3f
            val from = KnightPath[step % KnightPath.size]
            val to = KnightPath[(step + 1) % KnightPath.size]
            val p = t.value
            for (r in 0 until 3) for (c in 0 until 3) {
                val light = (r + c) % 2 == 0
                drawRect(
                    if (light) Color(0xFF6A6966) else Color(0xFF52514E),
                    Offset(c * cell, r * cell), Size(cell, cell),
                )
            }
            // Ô vừa rời mờ dần, ô sắp đáp sáng xanh dần.
            drawRect(Color(0x33FFFFFF).copy(alpha = 0.2f * (1f - p)), Offset(from[1] * cell, from[0] * cell), Size(cell, cell))
            drawRect(Color(0xFF6E9B45).copy(alpha = 0.35f + 0.65f * p), Offset(to[1] * cell, to[0] * cell), Size(cell, cell))

            val x = (from[1] + (to[1] - from[1]) * p) * cell
            val y = (from[0] + (to[0] - from[0]) * p) * cell - sin(PI.toFloat() * p) * cell * 0.38f
            val side = cell * 0.9f
            val pad = (cell - side) / 2f
            if (knight != null) {
                drawImage(
                    knight,
                    dstOffset = IntOffset((x + pad).roundToInt(), (y + pad).roundToInt()),
                    dstSize = IntSize(side.roundToInt(), side.roundToInt()),
                )
            } else {
                drawCircle(Color.White, side / 3f, Offset(x + cell / 2f, y + cell / 2f))
            }
        }
    }
}
