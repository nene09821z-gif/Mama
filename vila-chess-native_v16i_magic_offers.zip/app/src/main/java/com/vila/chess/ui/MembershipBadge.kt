package com.vila.chess.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vila.chess.billing.MembershipTier
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// =============================================================================
// Huy hiệu thành viên (VIP) — vẽ bằng Canvas, sắc nét ở mọi kích thước, TẤT CẢ đều có hoạt ảnh:
//   FREE     → không hiển thị
//   GOLD     → ngôi sao vàng: nảy nhẹ + lắc + vệt sáng quét + lấp lánh
//   PLATINUM → vương miện trắng-xanh: nhấp nhô + vệt sáng quét + ngọc đỉnh nhấp nháy
//   DIAMOND  → kim cương xanh lam: lấp lánh + vệt sáng quét + xoay nhẹ
//   FAMILY   → trái tim xanh lá: đập kiểu "thình-thịch" + vệt sáng + lấp lánh
// Mỗi huy hiệu chỉ có MỘT bộ đếm thời gian (0→1, lặp) và giá trị chỉ được đọc trong khối vẽ ⇒ chỉ vẽ lại, không recompose.
// =============================================================================

object BadgeColors {
    val GoldLight = Color(0xFFFFE27A)
    val GoldDark = Color(0xFFF5A800)
    val GoldEdge = Color(0xFFE08A00)
    val SilverLight = Color(0xFFFFFFFF)
    val SilverDark = Color(0xFF9AA7B5)
    val CrownWhite = Color(0xFFFFFFFF)
    val CrownBlue = Color(0xFFBBD6F2)
    val CrownBack = Color(0xFF5E86B5)
    val CrownBand = Color(0xFF8FB6E3)
    val DiamondLight = Color(0xFF8FE3FF)
    val DiamondDark = Color(0xFF1E88E5)
    val HeartLeft = Color(0xFF9CD35A)
    val HeartRight = Color(0xFF5FA23A)
    val HeartEdge = Color(0xFF3F7A26)
}

/** Dạng nhận tên gói dạng chuỗi ("free" | "gold" | "platinum" | "diamond" | "family"). Chuỗi lạ → không hiện. */
@Composable
fun MembershipBadge(tier: String, modifier: Modifier = Modifier, size: Dp = 18.dp, animated: Boolean = true) {
    MembershipBadge(MembershipTier.fromId(tier.trim().lowercase()), modifier, size, animated)
}

/** [animated] = false: đứng yên (dùng khi cần tiết kiệm pin hoặc trong ảnh chụp). */
@Composable
fun MembershipBadge(tier: MembershipTier, modifier: Modifier = Modifier, size: Dp = 18.dp, animated: Boolean = true) {
    val desc = "Thành viên " + tier.displayName
    val m = modifier.size(size).semantics { contentDescription = desc }
    when (tier) {
        MembershipTier.FREE -> Unit                      // FREE: không hiển thị gì (kể cả khoảng trống)
        MembershipTier.GOLD -> StarBadge(m, animated)
        MembershipTier.PLATINUM -> CrownBadge(m, animated)
        MembershipTier.DIAMOND -> DiamondBadge(m, animated)
        MembershipTier.FAMILY -> HeartBadge(m, animated)
    }
}

/** Đồng hồ 0→1 lặp lại. animated = false → giá trị cố định (hình đẹp, không chạy). */
@Composable
private fun rememberBadgeClock(animated: Boolean, periodMs: Int, label: String): State<Float> {
    if (!animated) return remember { mutableStateOf(0.32f) }
    val transition = rememberInfiniteTransition(label = label)
    return transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(periodMs, easing = LinearEasing), RepeatMode.Restart),
        label = label,
    )
}

// ------------------------------------------------------------------ Gold: ngôi sao

@Composable
private fun StarBadge(modifier: Modifier, animated: Boolean) {
    val t by rememberBadgeClock(animated, 2800, "goldStar")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val pivot = Offset(w / 2f, h * 0.55f)
        // Nảy nhẹ + lắc ±5°
        val pulse = 1f + 0.06f * sin(t * 2f * PI.toFloat())
        val wobble = 5f * sin(t * 2f * PI.toFloat() + 0.8f)
        rotate(wobble, pivot) {
            scale(pulse, pivot) {
                val star = starPath(w, h)
                // Viền cam tròn góc (nét dày + nối tròn) rồi tô gradient lên trên
                drawPath(star, BadgeColors.GoldEdge, style = Stroke(width = w * 0.11f, join = StrokeJoin.Round))
                drawPath(star, Brush.verticalGradient(listOf(BadgeColors.GoldLight, BadgeColors.GoldDark), 0f, h))
                drawPath(star, BadgeColors.GoldDark, style = Stroke(width = w * 0.035f, join = StrokeJoin.Round))
                shine(star, t, w, h, 0.9f)
            }
        }
        sparkle(Offset(w * 0.90f, h * 0.14f), w * 0.15f, twinkle(t, 0.0f))
        sparkle(Offset(w * 0.08f, h * 0.70f), w * 0.11f, twinkle(t, 0.55f))
    }
}

private fun DrawScope.starPath(w: Float, h: Float): Path {
    val path = Path()
    val cx = w / 2f
    val cy = h * 0.55f
    val outer = minOf(w, h) * 0.42f
    val inner = outer * 0.48f
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) outer else inner
        val a = -PI / 2 + i * PI / 5
        val x = cx + (r * cos(a)).toFloat()
        val y = cy + (r * sin(a)).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

// ------------------------------------------------------------------ Platinum: vương miện

@Composable
private fun CrownBadge(modifier: Modifier, animated: Boolean) {
    val t by rememberBadgeClock(animated, 3000, "platinumCrown")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        // Nhấp nhô lên xuống nhẹ
        val bob = -h * 0.03f * sin(t * 2f * PI.toFloat())
        translate(0f, bob) {
            // Hai mũi nhọn phía sau (xanh đậm) cho cảm giác chiều sâu
            val back = Path().apply {
                moveTo(w * 0.14f, h * 0.74f); lineTo(w * 0.20f, h * 0.20f); lineTo(w * 0.40f, h * 0.50f)
                lineTo(w * 0.60f, h * 0.50f); lineTo(w * 0.80f, h * 0.20f); lineTo(w * 0.86f, h * 0.74f)
                close()
            }
            drawPath(back, BadgeColors.CrownBack)

            val crown = Path().apply {
                moveTo(w * 0.10f, h * 0.80f)
                lineTo(w * 0.10f, h * 0.38f)
                lineTo(w * 0.31f, h * 0.58f)
                lineTo(w * 0.50f, h * 0.16f)
                lineTo(w * 0.69f, h * 0.58f)
                lineTo(w * 0.90f, h * 0.38f)
                lineTo(w * 0.90f, h * 0.80f)
                close()
            }
            drawPath(crown, Brush.verticalGradient(listOf(BadgeColors.CrownWhite, BadgeColors.CrownBlue), h * 0.16f, h * 0.80f))
            drawPath(crown, BadgeColors.CrownBack, style = Stroke(width = w * 0.035f, join = StrokeJoin.Round))
            shine(crown, t, w, h, 0.85f)

            // Dải đế
            drawRoundRect(
                BadgeColors.CrownBand, Offset(w * 0.08f, h * 0.76f), Size(w * 0.84f, h * 0.13f),
                androidx.compose.ui.geometry.CornerRadius(h * 0.04f),
            )
            // Ba viên ngọc đỉnh nhấp nháy lệch pha
            val gem = Color(0xFF3F6FB0)
            fun gemAt(c: Offset, r: Float, phase: Float) {
                val k = 0.85f + 0.35f * twinkle(t, phase)
                drawCircle(gem, r * k, c)
                drawCircle(Color.White.copy(alpha = 0.75f), r * 0.38f * k, c - Offset(r * 0.25f, r * 0.25f))
            }
            gemAt(Offset(w * 0.10f, h * 0.36f), w * 0.055f, 0.0f)
            gemAt(Offset(w * 0.50f, h * 0.14f), w * 0.065f, 0.33f)
            gemAt(Offset(w * 0.90f, h * 0.36f), w * 0.055f, 0.66f)
        }
        sparkle(Offset(w * 0.92f, h * 0.10f), w * 0.14f, twinkle(t, 0.2f))
    }
}

// ------------------------------------------------------------------ Diamond: kim cương

@Composable
private fun DiamondBadge(modifier: Modifier, animated: Boolean) {
    val t by rememberBadgeClock(animated, 2400, "diamondShine")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun p(x: Float, y: Float) = Offset(w * x, h * y)

        // Lắc nhẹ + nhịp thở
        val pulse = 1f + 0.04f * sin(t * 2f * PI.toFloat())
        val tilt = 4f * sin(t * 2f * PI.toFloat() + 1.2f)
        val pivot = Offset(w / 2f, h * 0.55f)
        rotate(tilt, pivot) {
            scale(pulse, pivot) {
                val gem = Path().apply {
                    moveTo(w * 0.24f, h * 0.20f); lineTo(w * 0.76f, h * 0.20f)
                    lineTo(w * 0.94f, h * 0.42f); lineTo(w * 0.50f, h * 0.90f); lineTo(w * 0.06f, h * 0.42f)
                    close()
                }
                drawPath(gem, Brush.linearGradient(listOf(BadgeColors.DiamondLight, BadgeColors.DiamondDark), p(0.1f, 0.1f), p(0.9f, 0.95f)))

                // Mặt cắt: sáng dần theo vệt quét
                val facet = Color.White.copy(alpha = 0.55f)
                val sw = w * 0.035f
                drawLine(facet, p(0.06f, 0.42f), p(0.94f, 0.42f), strokeWidth = sw)
                drawLine(facet, p(0.24f, 0.20f), p(0.36f, 0.42f), strokeWidth = sw)
                drawLine(facet, p(0.76f, 0.20f), p(0.64f, 0.42f), strokeWidth = sw)
                drawLine(facet, p(0.36f, 0.42f), p(0.50f, 0.90f), strokeWidth = sw)
                drawLine(facet, p(0.64f, 0.42f), p(0.50f, 0.90f), strokeWidth = sw)
                drawLine(facet, p(0.36f, 0.42f), p(0.50f, 0.20f), strokeWidth = sw)
                drawLine(facet, p(0.64f, 0.42f), p(0.50f, 0.20f), strokeWidth = sw)
                drawPath(gem, Color(0xFF0D47A1).copy(alpha = 0.75f), style = Stroke(width = w * 0.045f, join = StrokeJoin.Round))
                shine(gem, t, w, h, 0.85f)
            }
        }
        sparkle(Offset(w * 0.90f, h * 0.12f), w * 0.17f, twinkle(t, 0.0f))
        sparkle(Offset(w * 0.10f, h * 0.60f), w * 0.12f, twinkle(t, 0.5f))
    }
}

// ------------------------------------------------------------------ Family: trái tim

@Composable
private fun HeartBadge(modifier: Modifier, animated: Boolean) {
    val t by rememberBadgeClock(animated, 1500, "familyHeart")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val pivot = Offset(w / 2f, h * 0.55f)
        // "Thình-thịch": hai nhịp liên tiếp rồi nghỉ
        val beat = 1f + 0.12f * max(bump(t, 0.10f, 0.11f), 0.65f * bump(t, 0.30f, 0.11f))
        scale(beat, pivot) {
            val heart = heartPath(w, h)
            drawPath(heart, BadgeColors.HeartEdge, style = Stroke(width = w * 0.10f, join = StrokeJoin.Round))
            drawPath(heart, BadgeColors.HeartLeft)
            // Nửa phải đậm hơn (đúng kiểu hai mảng của chess.com)
            clipRect(left = w * 0.5f) { drawPath(heart, BadgeColors.HeartRight) }
            // Bóng sáng bên trái trên
            drawCircle(Color.White.copy(alpha = 0.28f), w * 0.07f, Offset(w * 0.27f, h * 0.30f))
            shine(heart, t, w, h, 0.7f)
        }
        sparkle(Offset(w * 0.90f, h * 0.14f), w * 0.15f, twinkle(t, 0.15f))
    }
}

private fun heartPath(w: Float, h: Float): Path = Path().apply {
    moveTo(w * 0.50f, h * 0.90f)
    cubicTo(w * 0.08f, h * 0.62f, w * 0.04f, h * 0.30f, w * 0.24f, h * 0.17f)
    cubicTo(w * 0.37f, h * 0.09f, w * 0.48f, h * 0.15f, w * 0.50f, h * 0.29f)
    cubicTo(w * 0.52f, h * 0.15f, w * 0.63f, h * 0.09f, w * 0.76f, h * 0.17f)
    cubicTo(w * 0.96f, h * 0.30f, w * 0.92f, h * 0.62f, w * 0.50f, h * 0.90f)
    close()
}

// ------------------------------------------------------------------ Dùng chung

/** Vệt sáng quét chéo, cắt theo hình [shape]. Quét trong ~60% đầu chu kỳ rồi nghỉ để không rối mắt. */
private fun DrawScope.shine(shape: Path, t: Float, w: Float, h: Float, strength: Float) {
    val k = (t / 0.6f)
    if (k >= 1f) return
    val bandX = w * (-0.5f + 2.0f * k)
    clipPath(shape) {
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(Color.Transparent, Color.White.copy(alpha = strength), Color.Transparent),
                start = Offset(bandX, 0f),
                end = Offset(bandX + w * 0.45f, h * 0.45f),
            ),
        )
    }
}

/** 0→1→0 theo chu kỳ, lệch pha [phase]. */
private fun twinkle(t: Float, phase: Float): Float = abs(sin(((t + phase) % 1f) * PI)).toFloat()

/** Gờ tam giác quanh [center] với nửa độ rộng [halfWidth] (0..1). */
private fun bump(t: Float, center: Float, halfWidth: Float): Float = max(0f, 1f - abs(t - center) / halfWidth)

/** Ngôi sao bốn cánh, bán kính [r] nhân [scale] (0 = ẩn). */
private fun DrawScope.sparkle(c: Offset, r: Float, scale: Float) {
    if (scale <= 0.02f) return
    val rr = r * scale
    val path = Path().apply {
        moveTo(c.x, c.y - rr)
        quadraticTo(c.x, c.y, c.x + rr, c.y)
        quadraticTo(c.x, c.y, c.x, c.y + rr)
        quadraticTo(c.x, c.y, c.x - rr, c.y)
        quadraticTo(c.x, c.y, c.x, c.y - rr)
        close()
    }
    drawPath(path, Color.White.copy(alpha = 0.55f + 0.45f * scale))
}
