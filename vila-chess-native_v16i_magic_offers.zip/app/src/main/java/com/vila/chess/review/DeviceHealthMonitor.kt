package com.vila.chess.review

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.delay

class DeviceHealthMonitor(private val context: Context) {

    companion object {
        const val MAX_TEMP_C = 40f
        const val COOL_DOWN_MS = 4_000L
    }

    /** Nhiệt độ pin (°C). EXTRA_TEMPERATURE tính bằng 1/10 độ. Trả -1 nếu máy không báo. */
    fun batteryTempC(): Float {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        return if (raw <= 0) -1f else raw / 10f
    }

    fun isTooHot(): Boolean = batteryTempC() > MAX_TEMP_C

    /**
     * Nếu máy nóng: gọi onHot() (dừng/giải phóng engine) rồi nghỉ [COOL_DOWN_MS], tối đa [maxRounds] lần (~8 giây).
     * Trả true khi đã nguội; false nếu hết lượt vẫn nóng. Worker KHÔNG dừng/retry theo kết quả này: phân tích luôn chạy tiếp.
     */
    suspend fun awaitCoolDown(maxRounds: Int = 2, onHot: suspend () -> Unit = {}): Boolean {
        var rounds = 0
        while (isTooHot()) {
            if (rounds++ >= maxRounds) return false
            onHot()
            delay(COOL_DOWN_MS)
        }
        return true
    }
}
