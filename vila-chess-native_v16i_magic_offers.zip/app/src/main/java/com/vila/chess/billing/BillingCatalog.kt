package com.vila.chess.billing

/**
 * Khớp 1-1 với Google Play Console: mỗi gói = 1 subscription, mỗi subscription có 2 base plan "monthly" / "yearly".
 */
object BillingCatalog {
    private val productByTier = mapOf(
        MembershipTier.GOLD to "chessplus_gold",
        MembershipTier.PLATINUM to "chessplus_platinum",
        MembershipTier.DIAMOND to "chessplus_diamond",
        MembershipTier.FAMILY to "chessplus_family",   // Play Console: chỉ tạo base plan "yearly"
    )
    val productIds: List<String> = productByTier.values.toList()
    fun tierOf(productId: String): MembershipTier? = productByTier.entries.firstOrNull { it.value == productId }?.key

    /** Bảng giá cố định (VND) cho thanh toán chuyển khoản. SỬA GIÁ Ở ĐÂY. Khi cài từ Google Play thì giá Play được ưu tiên. */
    fun priceVnd(tier: MembershipTier, period: BillingPeriod): Long = when (tier) {
        MembershipTier.GOLD -> if (period == BillingPeriod.MONTHLY) 49_000L else 490_000L
        MembershipTier.PLATINUM -> if (period == BillingPeriod.MONTHLY) 99_000L else 990_000L
        MembershipTier.DIAMOND -> if (period == BillingPeriod.MONTHLY) 149_000L else 1_490_000L
        MembershipTier.FAMILY -> if (period == BillingPeriod.MONTHLY) 0L else 1_699_000L   // chỉ bán năm (giá tham chiếu theo ảnh chess.com — SỬA THEO Ý BẠN)
        MembershipTier.FREE -> 0L
    }

    /** Gói chỉ bán theo năm (không có base plan monthly). */
    fun yearlyOnly(tier: MembershipTier): Boolean = tier == MembershipTier.FAMILY

    /** Để trống = không xác thực server (chỉ nên dùng khi dev). Xem docs/PAYWALL_GUIDE.md mục 5. */
    const val VERIFY_ENDPOINT: String = ""
}

enum class BillingPeriod(val basePlanId: String) { MONTHLY("monthly"), YEARLY("yearly") }


/**
 * Thanh toán chuyển khoản (VietQR) + mã kích hoạt, KHÔNG cần Google Play Console.
 * ĐIỀN thông tin ngân hàng của bạn. LICENSE_SECRET phải trùng với scripts/gen_license.py (script tự đọc từ file này).
 */
object ManualPay {
    const val BANK_BIN: String = "970422"                 // mã BIN VietQR: MB=970422, VCB=970436, TCB=970407, ACB=970416, BIDV=970418, VPBank=970432
    const val BANK_NAME: String = "MB Bank"
    const val ACCOUNT_NO: String = "YOUR_ACCOUNT_NO"      // số tài khoản nhận tiền
    const val ACCOUNT_NAME: String = "YOUR NAME"          // tên chủ tài khoản (viết hoa không dấu)
    const val CONTACT: String = "YOUR_ZALO_OR_TELEGRAM"   // nơi người dùng gửi biên lai để nhận mã
    /** URL Cloudflare Worker, ví dụ "https://vila-license.ten-ban.workers.dev". Để trống = chỉ dùng mã kích hoạt nhập tay. */
    const val SERVER_URL: String = "https://bitter-sun-751a.nene09821z.workers.dev"
    const val ADMIN_PIN_SHA256: String = "390fe5dbba0ab35b3c96d5166e492d3e4b8d0ee45ab54930a659930389b13ac1"   // SHA-256 của mã PIN admin (không lưu PIN thật trong app)
    const val LICENSE_SECRET: String = "fb9aef07a41424ff89db89048ecc84c8"
}
