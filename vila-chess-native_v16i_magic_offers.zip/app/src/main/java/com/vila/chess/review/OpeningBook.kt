package com.vila.chess.review

import android.content.Context
import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.findMoveBySan

/** Tên khai cuộc + mã ECO của một thế cờ trong sổ khai cuộc. */
data class OpeningInfo(val eco: String, val name: String)

/**
 * Sổ khai cuộc: mọi THẾ CỜ nằm trên một dòng khai cuộc đã đặt tên (kể cả thế trung gian) -> OpeningInfo.
 *
 * Dữ liệu: assets/openings.tsv (cột eco \t name \t pgn) = bộ lichess-org/chess-openings (CC0, ~3.600 dòng),
 * do workflow GitHub Actions tải về lúc build. Thiếu file thì dùng [BUILT_IN] (bộ rút gọn) để Book vẫn chạy.
 * Index dựng lúc chạy bằng luật cờ của app (SAN -> nước đi), không cần thư viện ngoài.
 *
 * Khóa thế cờ = 3 trường đầu của FEN (quân + lượt + quyền nhập thành), bỏ ô en passant và bộ đếm nước.
 */
class OpeningBook private constructor(private val index: Map<String, OpeningInfo>, val lineCount: Int) {

    val size: Int get() = index.size

    /** null = thế không thuộc khai cuộc nào. [fen] có thể là FEN đầy đủ. */
    fun lookup(fen: String): OpeningInfo? = index[positionKey(fen)]

    companion object {
        const val ASSET_NAME = "openings.tsv"

        fun positionKey(fen: String): String {
            val p = fen.trim().split(' ')
            return if (p.size >= 3) p[0] + " " + p[1] + " " + p[2] else fen.trim()
        }

        /** Khóa của thế cờ chuẩn ban đầu: chỉ ván bắt đầu từ thế này mới có Book. */
        val START_KEY: String = positionKey(START_FEN)

        @Volatile private var cached: OpeningBook? = null

        /** Nạp (và nhớ) sổ khai cuộc. Gọi từ luồng nền: dựng index mất vài trăm ms. */
        fun load(context: Context): OpeningBook {
            cached?.let { return it }
            synchronized(this) {
                cached?.let { return it }
                val fromAsset = runCatching {
                    context.applicationContext.assets.open(ASSET_NAME).bufferedReader().useLines { fromTsv(it) }
                }.getOrNull()
                val book = fromAsset?.takeIf { it.lineCount >= 200 } ?: fromBuiltIn()
                cached = book
                return book
            }
        }

        fun fromBuiltIn(): OpeningBook =
            build(BUILT_IN.map { Triple(it.first, it.second, it.third) })

        /** TSV lichess: dòng đầu là tiêu đề (eco name pgn); các cột thừa (uci, epd) bị bỏ qua. */
        fun fromTsv(lines: Sequence<String>): OpeningBook {
            val rows = ArrayList<Triple<String, String, String>>(4096)
            for (raw in lines) {
                val line = raw.trimEnd('\r', '\n')
                if (line.isBlank()) continue
                val c = line.split('\t')
                if (c.size < 3) continue
                if (c[0].equals("eco", ignoreCase = true)) continue
                rows += Triple(c[0].trim(), c[1].trim(), c[2].trim())
            }
            return build(rows)
        }

        private fun build(rows: List<Triple<String, String, String>>): OpeningBook {
            val exact = HashMap<String, OpeningInfo>(rows.size * 2)
            val prefix = HashMap<String, OpeningInfo>(rows.size * 4)
            val prefixLen = HashMap<String, Int>(rows.size * 4)
            var ok = 0
            for ((eco, name, pgn) in rows) {
                val info = OpeningInfo(eco, name)
                val pos = Position.start()
                var plies = 0
                var valid = true
                val keys = ArrayList<String>(16)
                for (tok in pgn.split(' ', '\t')) {
                    val san = tok.replace(MOVE_NUMBER, "")
                    if (san.isEmpty() || san == "*" || san == "1-0" || san == "0-1" || san == "1/2-1/2") continue
                    val mv = findMoveBySan(pos, san)
                    if (mv == null) { valid = false; break }
                    pos.make(mv)
                    plies++
                    keys += positionKey(pos.fen())
                }
                if (!valid || plies == 0) continue
                ok++
                // Thế trung gian: tên của dòng NGẮN NHẤT chứa nó (tên chung hơn, an toàn hơn).
                for (k in keys) {
                    val old = prefixLen[k]
                    if (old == null || plies < old) { prefix[k] = info; prefixLen[k] = plies }
                }
                exact[keys.last()] = info   // thế đúng bằng một khai cuộc có tên: ưu tiên tuyệt đối
            }
            val all = HashMap<String, OpeningInfo>(prefix.size + exact.size)
            all.putAll(prefix)
            all.putAll(exact)
            return OpeningBook(all, ok)
        }

        private val MOVE_NUMBER = Regex("^\\d+\\.+")

        /** Bộ rút gọn dùng khi chưa có openings.tsv. (eco, tên, các nước SAN). */
        val BUILT_IN: List<Triple<String, String, String>> = listOf(
            Triple("A00", "Polish Opening", "1. b4"),
            Triple("A02", "Bird Opening", "1. f4"),
            Triple("A04", "Zukertort Opening", "1. Nf3"),
            Triple("A10", "English Opening", "1. c4"),
            Triple("A20", "English Opening: King's English Variation", "1. c4 e5"),
            Triple("A40", "Queen's Pawn Game", "1. d4"),
            Triple("A45", "Indian Defense", "1. d4 Nf6"),
            Triple("A80", "Dutch Defense", "1. d4 f5"),
            Triple("B00", "King's Pawn Game", "1. e4"),
            Triple("B01", "Scandinavian Defense", "1. e4 d5"),
            Triple("B02", "Alekhine Defense", "1. e4 Nf6"),
            Triple("B06", "Modern Defense", "1. e4 g6"),
            Triple("B07", "Pirc Defense", "1. e4 d6 2. d4 Nf6 3. Nc3"),
            Triple("B10", "Caro-Kann Defense", "1. e4 c6"),
            Triple("B12", "Caro-Kann Defense: Advance Variation", "1. e4 c6 2. d4 d5 3. e5"),
            Triple("B18", "Caro-Kann Defense: Classical Variation", "1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5"),
            Triple("B20", "Sicilian Defense", "1. e4 c5"),
            Triple("B23", "Sicilian Defense: Closed", "1. e4 c5 2. Nc3"),
            Triple("B30", "Sicilian Defense: Old Sicilian", "1. e4 c5 2. Nf3 Nc6"),
            Triple("B40", "Sicilian Defense: French Variation", "1. e4 c5 2. Nf3 e6"),
            Triple("B50", "Sicilian Defense: Modern Variations", "1. e4 c5 2. Nf3 d6"),
            Triple("B90", "Sicilian Defense: Najdorf Variation", "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6"),
            Triple("B33", "Sicilian Defense: Sveshnikov Variation", "1. e4 c5 2. Nf3 Nc6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 e5"),
            Triple("C00", "French Defense", "1. e4 e6"),
            Triple("C02", "French Defense: Advance Variation", "1. e4 e6 2. d4 d5 3. e5"),
            Triple("C10", "French Defense: Rubinstein Variation", "1. e4 e6 2. d4 d5 3. Nc3 dxe4"),
            Triple("C20", "King's Pawn Game", "1. e4 e5"),
            Triple("C23", "Bishop's Opening", "1. e4 e5 2. Bc4"),
            Triple("C25", "Vienna Game", "1. e4 e5 2. Nc3"),
            Triple("C30", "King's Gambit", "1. e4 e5 2. f4"),
            Triple("C40", "King's Knight Opening", "1. e4 e5 2. Nf3"),
            Triple("C41", "Philidor Defense", "1. e4 e5 2. Nf3 d6"),
            Triple("C42", "Russian Game", "1. e4 e5 2. Nf3 Nf6"),
            Triple("C44", "Scotch Game", "1. e4 e5 2. Nf3 Nc6 3. d4"),
            Triple("C46", "Four Knights Game", "1. e4 e5 2. Nf3 Nc6 3. Nc3 Nf6"),
            Triple("C50", "Italian Game", "1. e4 e5 2. Nf3 Nc6 3. Bc4"),
            Triple("C51", "Italian Game: Evans Gambit", "1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. b4"),
            Triple("C55", "Italian Game: Two Knights Defense", "1. e4 e5 2. Nf3 Nc6 3. Bc4 Nf6"),
            Triple("C60", "Ruy Lopez", "1. e4 e5 2. Nf3 Nc6 3. Bb5"),
            Triple("C65", "Ruy Lopez: Berlin Defense", "1. e4 e5 2. Nf3 Nc6 3. Bb5 Nf6"),
            Triple("C78", "Ruy Lopez: Morphy Defense", "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O"),
            Triple("D00", "Queen's Pawn Game", "1. d4 d5"),
            Triple("D02", "London System", "1. d4 d5 2. Nf3 Nf6 3. Bf4"),
            Triple("D06", "Queen's Gambit", "1. d4 d5 2. c4"),
            Triple("D10", "Slav Defense", "1. d4 d5 2. c4 c6"),
            Triple("D20", "Queen's Gambit Accepted", "1. d4 d5 2. c4 dxc4"),
            Triple("D30", "Queen's Gambit Declined", "1. d4 d5 2. c4 e6"),
            Triple("D70", "Neo-Grünfeld Defense", "1. d4 Nf6 2. c4 g6 3. f3 d5"),
            Triple("D80", "Grünfeld Defense", "1. d4 Nf6 2. c4 g6 3. Nc3 d5"),
            Triple("E00", "Catalan Opening", "1. d4 Nf6 2. c4 e6 3. g3"),
            Triple("E12", "Queen's Indian Defense", "1. d4 Nf6 2. c4 e6 3. Nf3 b6"),
            Triple("E20", "Nimzo-Indian Defense", "1. d4 Nf6 2. c4 e6 3. Nc3 Bb4"),
            Triple("E60", "King's Indian Defense", "1. d4 Nf6 2. c4 g6"),
            Triple("A60", "Benoni Defense", "1. d4 Nf6 2. c4 c5 3. d5 e6"),
        )
    }
}
