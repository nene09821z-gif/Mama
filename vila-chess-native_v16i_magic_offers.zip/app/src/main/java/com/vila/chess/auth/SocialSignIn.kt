package com.vila.chess.auth

import androidx.activity.ComponentActivity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.vila.chess.cloud.SupabaseCloud
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** Kết quả đăng nhập Google. `email` có thể null => UI cho nhập tay. */
data class SocialResult(val email: String?, val name: String)

object SocialSignIn {
    /** Đọc email/tên từ id_token (JWT) do Google trả về sau luồng trình duyệt. */
    fun parseGoogleIdToken(idToken: String?): SocialResult? = runCatching {
        val payload = idToken!!.split('.')[1]
        val json = org.json.JSONObject(String(android.util.Base64.decode(payload, android.util.Base64.URL_SAFE or android.util.Base64.NO_PADDING or android.util.Base64.NO_WRAP)))
        SocialResult(json.optString("email").takeIf { it.isNotBlank() }, json.optString("name"))
    }.getOrNull()

    /** Google: Credential Manager. serverClientId = Web client ID trong Google Cloud Console. */
    suspend fun google(activity: ComponentActivity, serverClientId: String): SocialResult {
        val req = GetCredentialRequest.Builder()
            .addCredentialOption(GetSignInWithGoogleOption.Builder(serverClientId).build())
            .build()
        val cred = CredentialManager.create(activity).getCredential(activity, req).credential
        require(cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            "Không nhận được tài khoản Google"
        }
        val g = GoogleIdTokenCredential.createFrom(cred.data)
        runCatching { SupabaseCloud.signInWithGoogle(activity.applicationContext, g.idToken) }
        return SocialResult(g.id, g.displayName ?: "")
    }
}
