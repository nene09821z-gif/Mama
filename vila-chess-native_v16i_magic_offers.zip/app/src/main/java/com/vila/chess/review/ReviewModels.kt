package com.vila.chess.review

/**
 * Bộ 10 nhãn. Thứ tự ưu tiên khi gán (xem [MoveClassifier]): BOOK > MISS > BRILLIANT > GREAT > BEST > theo EP loss
 * (EXCELLENT ≤ 2% · GOOD ≤ 5% · INACCURACY ≤ 10% · MISTAKE ≤ 20% · BLUNDER > 20%).
 * Thêm giá trị mới KHÔNG phá file cũ: ReviewJson đọc theo tên.
 */
enum class MoveLabel { BOOK, BRILLIANT, GREAT, BEST, EXCELLENT, GOOD, INACCURACY, MISTAKE, BLUNDER, MISS }

/**
 * Một nước đi đã được phân tích. ply 1 = nước đầu tiên của ván. winLoss = % xác suất thắng mất đi (0–100).
 *
 * QUY ƯỚC ĐIỂM (mọi trường *White đều theo góc nhìn TRẮNG, dương = Trắng hơn):
 *  - cp: centipawn. Khi có mate, cp = ±(10000 - 10*soNuocMate) để vẽ/so sánh; ĐỪNG hiển thị cp lúc có mate.
 *  - mate: số nước chiếu hết. Dương = Trắng chiếu hết sau n nước, âm = Đen chiếu hết sau n nước.
 *    mate == 0: thế cờ đã bị chiếu hết trên bàn; bên thắng là bên có cp dương (Trắng) hoặc âm (Đen).
 *  - null = không có mate.
 *
 * Các trường từ phiên bản 2 trở đi có giá trị mặc định ("không biết") để đọc được file phiên bản 1.
 */
data class MoveReview(
    val ply: Int,
    val whiteMoved: Boolean,
    val label: MoveLabel,
    val winLoss: Double,
    /** Điểm SAU nước đi (cp, góc nhìn Trắng). Khóa JSON cũ "eval". */
    val evalAfterCpWhite: Int,
    /** Nước tốt nhất của engine ở thế TRƯỚC nước đi (UCI). Khóa JSON cũ "best". */
    val bestMoveBefore: String?,
    // ---- phiên bản 2 ----
    val uci: String? = null,
    val san: String? = null,
    val fenBefore: String? = null,
    val fenAfter: String? = null,
    val evalBeforeCpWhite: Int? = null,
    val mateBeforeWhite: Int? = null,
    val mateAfterWhite: Int? = null,
    /** PV đầu tiên của thế TRƯỚC nước đi (danh sách UCI, bắt đầu bằng nước tốt nhất). */
    val pv: List<String> = emptyList(),
    /** Độ sâu engine đạt được khi phân tích thế trước / thế sau. 0 = không có (thế kết thúc ván hoặc file cũ). */
    val depthBefore: Int = 0,
    val depthAfter: Int = 0,
    /** Nước tốt nhì ở thế trước + điểm của nó (góc nhìn Trắng). Chỉ có khi engine chạy MultiPV >= 2. */
    val secondBestMove: String? = null,
    val secondBestCpWhite: Int? = null,
    val secondBestMateWhite: Int? = null,
    /** "native", "wasm", "rules" (thế kết thúc ván, tính bằng luật cờ) hoặc "unknown" (file cũ). */
    val engine: String = ENGINE_UNKNOWN,
    /** MultiPV thực tế đã dùng. wasm = 1 => không có secondBest* và không được gán Great/Miss. */
    val multiPv: Int = 1,
    // ---- phiên bản 3 ----
    /** Mã ECO + tên khai cuộc của thế SAU nước đi (giữ tên cuối cùng tìm được kể cả khi đã rời sổ khai cuộc). null = chưa vào khai cuộc nào. */
    val ecoCode: String? = null,
    val openingName: String? = null,
    // ---- phiên bản 7 ----
    /** Expected Points (0.0–1.0) của BÊN VỪA ĐI trước / sau nước đi. null = file cũ. */
    val epBefore: Double? = null,
    val epAfter: Double? = null,
) {
    companion object {
        const val ENGINE_UNKNOWN = "unknown"
        const val ENGINE_RULES = "rules"
    }
}

data class GameReview(
    val gameId: String,
    val moves: List<MoveReview>,
    val accuracyWhite: Double,
    val accuracyBlack: Double,
    val tier: String,
    val createdAt: Long,
    // ---- phiên bản 2 ----
    val version: Int = ReviewJson.CURRENT_VERSION,
    val startFen: String? = null,
    /** Engine chính của ván: "native" | "wasm" | "none" | "unknown". */
    val engine: String = MoveReview.ENGINE_UNKNOWN,
    val multiPv: Int = 1,
)

/** Kết quả dùng được (không phải rác do engine hỏng: mọi thế depth 0, điểm 0) — rác thì phải phân tích lại. */
fun GameReview.isUsable(): Boolean =
    moves.isEmpty() || moves.any { it.depthBefore > 0 || it.depthAfter > 0 || it.mateBeforeWhite != null }
