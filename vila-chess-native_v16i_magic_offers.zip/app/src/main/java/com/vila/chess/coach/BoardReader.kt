package com.vila.chess.coach

import com.vila.chess.core.BISHOP
import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_CASTLE
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.KING
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.makePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.core.pieceType
import com.vila.chess.core.sqFile
import com.vila.chess.core.sqRank

/**
 * "Đôi mắt" của thầy: đọc một thế cờ và trả về những điều đáng nói. Hàm thuần (không Android) => test được trên JVM.
 *
 * Mọi thứ đều nhìn từ phía NGƯỜI CHƠI ("yours" = của người chơi, "theirs" = của đối thủ).
 * Cố ý KHÔNG dùng engine: đọc thế cờ tức thì, không tốn pin, không làm giật ván.
 */

/** Điều thầy nhìn thấy. */
enum class Topic {
    // ---- chiến thuật tức thời ----
    HANGING_YOURS, HANGING_THEIRS,
    ATTACKED_BY_LESSER_YOURS, ATTACKED_BY_LESSER_THEIRS,
    FORK_AVAILABLE, MATE_IN_ONE_AVAILABLE,
    PIN_YOURS, PIN_THEIRS,
    BACK_RANK_YOURS, BACK_RANK_THEIRS,
    // ---- chiến lược ----
    OPEN_FILE_ROOK_YOURS, OPEN_FILE_ROOK_THEIRS, OPEN_FILE_EMPTY, ROOK_SEVENTH_YOURS, ROOK_SEVENTH_THEIRS,
    PASSED_PAWN_YOURS, PASSED_PAWN_THEIRS,
    DOUBLED_PAWNS_YOURS, DOUBLED_PAWNS_THEIRS, ISOLATED_PAWN_YOURS, ISOLATED_PAWN_THEIRS,
    BISHOP_PAIR_YOURS, BISHOP_PAIR_THEIRS,
    CENTER_YOURS, CENTER_THEIRS, CENTER_EMPTY,
    KING_EXPOSED_YOURS, KING_EXPOSED_THEIRS,
    KING_STUCK_YOURS, KING_STUCK_THEIRS,
    UNDEVELOPED_YOURS, UNDEVELOPED_THEIRS,
    ENDGAME_KING,
    OPPONENT_CRAMPED,
    MATERIAL_UP, MATERIAL_DOWN, MATERIAL_EVEN,
}

/** Một quan sát. [weight] 0..100: càng cao càng đáng nói. [squares]: các ô thầy muốn chỉ trên bàn. */
data class Seen(val topic: Topic, val weight: Int, val squares: List<Int> = emptyList(), val arg: Int = 0)

object BoardReader {

    // ------------------------------------------------------------------ tiện ích cơ bản

    fun value(type: Int): Int = if (type == KING) 10_000 else com.vila.chess.core.pieceValue(type)

    private val ORTHO = arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))
    private val DIAG = arrayOf(intArrayOf(1, 1), intArrayOf(1, -1), intArrayOf(-1, 1), intArrayOf(-1, -1))
    private val KN = arrayOf(
        intArrayOf(1, 2), intArrayOf(2, 1), intArrayOf(-1, 2), intArrayOf(-2, 1),
        intArrayOf(1, -2), intArrayOf(2, -1), intArrayOf(-1, -2), intArrayOf(-2, -1),
    )

    private fun inside(f: Int, r: Int) = f in 0..7 && r in 0..7

    /** Loại quân (PAWN..KING) của mọi quân của bên [byWhite] đang tấn công ô [sq]. */
    fun attackers(board: IntArray, sq: Int, byWhite: Boolean): List<Int> {
        val out = ArrayList<Int>(4)
        val f = sqFile(sq)
        val r = sqRank(sq)
        // tốt: tốt trắng ăn chéo lên => nằm dưới ô bị tấn công 1 hàng
        val pr = if (byWhite) r - 1 else r + 1
        if (pr in 0..7) {
            for (df in intArrayOf(-1, 1)) {
                val pf = f + df
                if (pf in 0..7 && board[pr * 8 + pf] == makePiece(PAWN, byWhite)) out.add(PAWN)
            }
        }
        for (d in KN) {
            val nf = f + d[0]; val nr = r + d[1]
            if (inside(nf, nr) && board[nr * 8 + nf] == makePiece(KNIGHT, byWhite)) out.add(KNIGHT)
        }
        for (df in -1..1) for (dr in -1..1) {
            if (df == 0 && dr == 0) continue
            val nf = f + df; val nr = r + dr
            if (inside(nf, nr) && board[nr * 8 + nf] == makePiece(KING, byWhite)) out.add(KING)
        }
        for (d in ORTHO) {
            val hit = firstPieceAlong(board, f, r, d[0], d[1])
            if (hit >= 0) {
                val p = board[hit]
                if (isWhitePiece(p) == byWhite && (pieceType(p) == ROOK || pieceType(p) == QUEEN)) out.add(pieceType(p))
            }
        }
        for (d in DIAG) {
            val hit = firstPieceAlong(board, f, r, d[0], d[1])
            if (hit >= 0) {
                val p = board[hit]
                if (isWhitePiece(p) == byWhite && (pieceType(p) == BISHOP || pieceType(p) == QUEEN)) out.add(pieceType(p))
            }
        }
        return out
    }

    /** Ô của quân đầu tiên gặp khi đi từ (f,r) theo hướng (df,dr); -1 nếu không có. */
    private fun firstPieceAlong(board: IntArray, f: Int, r: Int, df: Int, dr: Int): Int {
        var nf = f + df
        var nr = r + dr
        while (inside(nf, nr)) {
            val s = nr * 8 + nf
            if (board[s] != EMPTY) return s
            nf += df; nr += dr
        }
        return -1
    }

    /** Các ô mà quân đứng ở [sq] đang tấn công (giả-hợp lệ, không xét ghim). */
    fun attackSquares(board: IntArray, sq: Int): List<Int> {
        val p = board[sq]
        if (p == EMPTY) return emptyList()
        val white = isWhitePiece(p)
        val f = sqFile(sq); val r = sqRank(sq)
        val out = ArrayList<Int>(12)
        when (pieceType(p)) {
            PAWN -> {
                val nr = if (white) r + 1 else r - 1
                for (df in intArrayOf(-1, 1)) if (inside(f + df, nr)) out.add(nr * 8 + f + df)
            }
            KNIGHT -> for (d in KN) if (inside(f + d[0], r + d[1])) out.add((r + d[1]) * 8 + f + d[0])
            KING -> for (df in -1..1) for (dr in -1..1) {
                if ((df != 0 || dr != 0) && inside(f + df, r + dr)) out.add((r + dr) * 8 + f + df)
            }
            else -> {
                val t = pieceType(p)
                val dirs = ArrayList<IntArray>(8)
                if (t == ROOK || t == QUEEN) dirs.addAll(ORTHO)
                if (t == BISHOP || t == QUEEN) dirs.addAll(DIAG)
                for (d in dirs) {
                    var nf = f + d[0]; var nr = r + d[1]
                    while (inside(nf, nr)) {
                        val s = nr * 8 + nf
                        out.add(s)
                        if (board[s] != EMPTY) break
                        nf += d[0]; nr += d[1]
                    }
                }
            }
        }
        return out
    }

    /**
     * Quân ở [sq] có đang "ăn không" hoặc bị đổi lời không? (đơn giản hơn SEE đầy đủ nhưng đủ cho lời nhận xét)
     * - bị tấn công mà không ai bảo vệ, hoặc
     * - bị quân GIÁ TRỊ THẤP HƠN tấn công.
     */
    fun isEnPrise(board: IntArray, sq: Int): Boolean {
        val p = board[sq]
        if (p == EMPTY || pieceType(p) == KING) return false
        val white = isWhitePiece(p)
        val enemy = attackers(board, sq, !white)
        if (enemy.isEmpty()) return false
        val minEnemy = enemy.minOf { value(it) }
        val defended = attackers(board, sq, white).isNotEmpty()
        return !defended || minEnemy < value(pieceType(p))
    }

    /** Mọi quân (không phải vua) của một bên đang bị treo. */
    fun enPrise(board: IntArray, white: Boolean): List<Int> {
        val out = ArrayList<Int>()
        for (sq in 0 until 64) {
            val p = board[sq]
            if (p != EMPTY && isWhitePiece(p) == white && isEnPrise(board, sq)) out.add(sq)
        }
        return out
    }

    fun material(board: IntArray, white: Boolean): Int {
        var m = 0
        for (p in board) if (p != EMPTY && isWhitePiece(p) == white) m += com.vila.chess.core.pieceValue(pieceType(p))
        return m
    }

    /** Giá trị lực lượng KHÔNG tính tốt (để đo giai đoạn ván). */
    fun pieceMaterial(board: IntArray, white: Boolean): Int {
        var m = 0
        for (p in board) if (p != EMPTY && isWhitePiece(p) == white && pieceType(p) != PAWN) m += com.vila.chess.core.pieceValue(pieceType(p))
        return m
    }

    fun count(board: IntArray, white: Boolean, type: Int): Int = board.count { it == makePiece(type, white) }

    fun isEndgame(board: IntArray): Boolean {
        val q = count(board, true, QUEEN) + count(board, false, QUEEN)
        val total = pieceMaterial(board, true) + pieceMaterial(board, false)
        return q == 0 && total <= 3400 || total <= 2400
    }

    // ------------------------------------------------------------------ chiến thuật theo thế cờ

    /** Một quân bị ghim vào vua: (ô quân bị ghim, ô quân ghim). */
    fun pins(board: IntArray, white: Boolean): List<Pair<Int, Int>> {
        val ks = board.indexOf(makePiece(KING, white))
        if (ks < 0) return emptyList()
        val out = ArrayList<Pair<Int, Int>>()
        val f = sqFile(ks); val r = sqRank(ks)
        fun scan(d: IntArray, ortho: Boolean) {
            val first = firstPieceAlong(board, f, r, d[0], d[1])
            if (first < 0) return
            val p = board[first]
            if (p == EMPTY || isWhitePiece(p) != white || pieceType(p) == KING) return
            val second = firstPieceAlong(board, sqFile(first), sqRank(first), d[0], d[1])
            if (second < 0) return
            val q = board[second]
            if (isWhitePiece(q) == white) return
            val t = pieceType(q)
            val ok = if (ortho) (t == ROOK || t == QUEEN) else (t == BISHOP || t == QUEEN)
            if (ok) out.add(first to second)
        }
        for (d in ORTHO) scan(d, true)
        for (d in DIAG) scan(d, false)
        return out
    }

    /** Vua ở hàng cuối, bị chính quân mình chắn hết đường thoát, mà đối thủ còn Xe/Hậu. */
    fun backRankWeak(board: IntArray, white: Boolean): Boolean {
        val ks = board.indexOf(makePiece(KING, white))
        if (ks < 0) return false
        val homeRank = if (white) 0 else 7
        if (sqRank(ks) != homeRank) return false
        val fr = if (white) 1 else 6
        for (df in -1..1) {
            val f = sqFile(ks) + df
            if (f !in 0..7) continue
            val p = board[fr * 8 + f]
            if (p == EMPTY || isWhitePiece(p) != white) return false   // có ô thoát
        }
        return count(board, !white, ROOK) + count(board, !white, QUEEN) > 0
    }

    /** Nước của bên đang đi mà chiếu hết ngay? Trả về nước đi (int) hoặc -1. */
    fun mateInOne(pos: Position): Int {
        val moves = pos.legalMoves()
        for (m in moves) {
            val c = pos.copy()
            c.make(m)
            if (c.inCheck() && c.legalMoves().isEmpty()) return m
        }
        return -1
    }

    /** Đòn đôi: nước của bên đang đi mà quân vừa đến an toàn và đồng thời dọa >= 2 mục tiêu đáng giá. -1 nếu không có. */
    fun forkMove(pos: Position): Int {
        val moves = pos.legalMoves()
        val side = pos.whiteToMove
        var best = -1
        var bestScore = 0
        for (m in moves) {
            if (movePromo(m) != 0) continue
            val c = pos.copy()
            c.make(m)
            val to = moveTo(m)
            val moved = c.board[to]
            if (moved == EMPTY) continue
            val mv = value(pieceType(moved))
            // quân vừa đến phải an toàn (hoặc đang chiếu)
            val safe = !isEnPrise(c.board, to)
            if (!safe) continue
            var targets = 0
            var score = 0
            for (t in attackSquares(c.board, to)) {
                val tp = c.board[t]
                if (tp == EMPTY || isWhitePiece(tp) == side) continue
                val tv = value(pieceType(tp))
                if (pieceType(tp) == KING) { targets++; score += 300; continue }
                val defended = attackers(c.board, t, !side).isNotEmpty()
                if (!defended || tv > mv) { targets++; score += tv }
            }
            if (targets >= 2 && score > bestScore) { best = m; bestScore = score }
        }
        return best
    }

    /** Số nước đi hợp lệ của bên đang đi. */
    fun mobility(pos: Position): Int = pos.legalMoves().size

    // ------------------------------------------------------------------ chiến lược

    private fun pawnFiles(board: IntArray, white: Boolean): IntArray {
        val c = IntArray(8)
        for (sq in 0 until 64) if (board[sq] == makePiece(PAWN, white)) c[sqFile(sq)]++
        return c
    }

    private fun relRank(sq: Int, white: Boolean) = if (white) sqRank(sq) else 7 - sqRank(sq)

    private fun isPassed(board: IntArray, sq: Int, white: Boolean): Boolean {
        val f = sqFile(sq); val r = sqRank(sq)
        for (df in -1..1) {
            val ff = f + df
            if (ff !in 0..7) continue
            var rr = if (white) r + 1 else r - 1
            while (rr in 0..7) {
                if (board[rr * 8 + ff] == makePiece(PAWN, !white)) return false
                rr += if (white) 1 else -1
            }
        }
        return true
    }

    /**
     * Đọc cả bàn cờ, trả về các quan sát sắp theo mức đáng nói giảm dần.
     * [humanWhite]: người chơi cầm quân nào. [fullmove]: số nước (để biết đang khai cuộc hay không).
     */
    fun read(pos: Position, humanWhite: Boolean): List<Seen> {
        val b = pos.board
        val out = ArrayList<Seen>()
        val me = humanWhite
        val full = pos.fullmove

        // ---- quân bị treo / bị dọa bằng quân yếu hơn ----
        for (sq in enPrise(b, me)) {
            val t = pieceType(b[sq])
            val enemy = attackers(b, sq, !me)
            val lesser = enemy.isNotEmpty() && enemy.minOf { value(it) } < value(t) && attackers(b, sq, me).isNotEmpty()
            val w = (value(t) / 10).coerceIn(20, 92)
            out += if (lesser) Seen(Topic.ATTACKED_BY_LESSER_YOURS, w, listOf(sq), t) else Seen(Topic.HANGING_YOURS, w + 4, listOf(sq), t)
        }
        for (sq in enPrise(b, !me)) {
            val t = pieceType(b[sq])
            val enemy = attackers(b, sq, me)
            val lesser = enemy.isNotEmpty() && enemy.minOf { value(it) } < value(t) && attackers(b, sq, !me).isNotEmpty()
            val w = (value(t) / 10).coerceIn(15, 85)
            out += if (lesser) Seen(Topic.ATTACKED_BY_LESSER_THEIRS, w, listOf(sq), t) else Seen(Topic.HANGING_THEIRS, w, listOf(sq), t)
        }

        // ---- ghim ----
        for ((p, q) in pins(b, me)) out += Seen(Topic.PIN_YOURS, 50 + value(pieceType(b[p])) / 30, listOf(p, q), pieceType(b[p]))
        for ((p, q) in pins(b, !me)) out += Seen(Topic.PIN_THEIRS, 42 + value(pieceType(b[p])) / 30, listOf(p, q), pieceType(b[p]))

        // ---- hàng cuối ----
        if (backRankWeak(b, me)) out += Seen(Topic.BACK_RANK_YOURS, 55, listOf(b.indexOf(makePiece(KING, me))))
        if (backRankWeak(b, !me)) out += Seen(Topic.BACK_RANK_THEIRS, 50, listOf(b.indexOf(makePiece(KING, !me))))

        // ---- chiến thuật cho BÊN ĐANG ĐI nếu đó là người chơi ----
        if (pos.whiteToMove == me) {
            val mate = mateInOne(pos)
            if (mate >= 0) out += Seen(Topic.MATE_IN_ONE_AVAILABLE, 99, listOf(moveFrom(mate), moveTo(mate)))
            else {
                val fork = forkMove(pos)
                if (fork >= 0) out += Seen(Topic.FORK_AVAILABLE, 80, listOf(moveFrom(fork), moveTo(fork)))
            }
        }

        // ---- xe & cột mở ----
        val myPawns = pawnFiles(b, me)
        val theirPawns = pawnFiles(b, !me)
        for (sq in 0 until 64) {
            val p = b[sq]
            if (p == EMPTY || pieceType(p) != ROOK) continue
            val white = isWhitePiece(p)
            val f = sqFile(sq)
            val open = myPawns[f] == 0 && theirPawns[f] == 0
            val semi = !open && (if (white == me) myPawns[f] == 0 else theirPawns[f] == 0)
            if (open || semi) out += Seen(if (white == me) Topic.OPEN_FILE_ROOK_YOURS else Topic.OPEN_FILE_ROOK_THEIRS, if (open) 38 else 28, listOf(sq), f)
            val seventh = relRank(sq, white) == 6
            if (seventh) out += Seen(if (white == me) Topic.ROOK_SEVENTH_YOURS else Topic.ROOK_SEVENTH_THEIRS, 46, listOf(sq))
        }
        for (f in 0..7) if (myPawns[f] == 0 && theirPawns[f] == 0) {
            val rooksOn = (0 until 8).any { r -> val p = b[r * 8 + f]; p != EMPTY && pieceType(p) == ROOK }
            if (!rooksOn && full >= 8 && (count(b, me, ROOK) > 0)) out += Seen(Topic.OPEN_FILE_EMPTY, 24, emptyList(), f)
        }

        // ---- tốt thông / tốt chồng / tốt cô lập ----
        for (white in booleanArrayOf(me, !me)) {
            val yours = white == me
            var bestPassed = -1
            for (sq in 0 until 64) if (b[sq] == makePiece(PAWN, white) && isPassed(b, sq, white) && relRank(sq, white) >= 3) {
                if (bestPassed < 0 || relRank(sq, white) > relRank(bestPassed, white)) bestPassed = sq
            }
            if (bestPassed >= 0) {
                val rr = relRank(bestPassed, white)
                out += Seen(if (yours) Topic.PASSED_PAWN_YOURS else Topic.PASSED_PAWN_THEIRS, 30 + rr * 8, listOf(bestPassed), rr)
            }
            val pf = if (yours) myPawns else theirPawns
            val dbl = (0..7).firstOrNull { pf[it] >= 2 }
            if (dbl != null && full >= 6) {
                val sqs = (0 until 64).filter { b[it] == makePiece(PAWN, white) && sqFile(it) == dbl }
                out += Seen(if (yours) Topic.DOUBLED_PAWNS_YOURS else Topic.DOUBLED_PAWNS_THEIRS, 22, sqs, dbl)
            }
            val iso = (0 until 64).firstOrNull { sq ->
                b[sq] == makePiece(PAWN, white) &&
                    (sqFile(sq) == 0 || pf[sqFile(sq) - 1] == 0) && (sqFile(sq) == 7 || pf[sqFile(sq) + 1] == 0)
            }
            if (iso != null && full >= 8) out += Seen(if (yours) Topic.ISOLATED_PAWN_YOURS else Topic.ISOLATED_PAWN_THEIRS, 20, listOf(iso))
        }

        // ---- cặp tượng ----
        val myB = count(b, me, BISHOP); val thB = count(b, !me, BISHOP)
        if (myB >= 2 && thB < 2 && full >= 6) out += Seen(Topic.BISHOP_PAIR_YOURS, 26)
        if (thB >= 2 && myB < 2 && full >= 6) out += Seen(Topic.BISHOP_PAIR_THEIRS, 24)

        // ---- trung tâm (khai cuộc) ----
        if (full <= 10) {
            val center = intArrayOf(27, 28, 35, 36) // d4 e4 d5 e5
            val mine = center.count { b[it] == makePiece(PAWN, me) }
            val theirs = center.count { b[it] == makePiece(PAWN, !me) }
            when {
                mine >= 2 -> out += Seen(Topic.CENTER_YOURS, 34, center.filter { b[it] == makePiece(PAWN, me) })
                theirs >= 2 -> out += Seen(Topic.CENTER_THEIRS, 34, center.filter { b[it] == makePiece(PAWN, !me) })
                mine == 0 && theirs == 0 && full >= 4 -> out += Seen(Topic.CENTER_EMPTY, 30, center.toList())
            }
        }

        // ---- an toàn của vua & phát triển quân ----
        for (white in booleanArrayOf(me, !me)) {
            val yours = white == me
            val ks = b.indexOf(makePiece(KING, white))
            if (ks >= 0) {
                val enemyQ = count(b, !white, QUEEN) > 0
                val home = if (white) 0 else 7
                val kf = sqFile(ks)
                val uncastled = sqRank(ks) == home && kf in 3..4
                if (uncastled && full >= 10 && enemyQ) out += Seen(if (yours) Topic.KING_STUCK_YOURS else Topic.KING_STUCK_THEIRS, 44, listOf(ks))
                if (enemyQ && !isEndgame(b)) {
                    val rankStep = if (white) 1 else -1
                    var shield = 0
                    for (df in -1..1) {
                        val f = kf + df
                        if (f !in 0..7) continue
                        val r1 = sqRank(ks) + rankStep; val r2 = r1 + rankStep
                        if (r1 in 0..7 && b[r1 * 8 + f] == makePiece(PAWN, white)) shield++
                        else if (r2 in 0..7 && b[r2 * 8 + f] == makePiece(PAWN, white)) shield++
                    }
                    if (shield <= 1 && !uncastled && full >= 8) out += Seen(if (yours) Topic.KING_EXPOSED_YOURS else Topic.KING_EXPOSED_THEIRS, 48, listOf(ks))
                }
            }
            if (full in 5..12) {
                val homeSqs = if (white) intArrayOf(1, 2, 5, 6) else intArrayOf(57, 58, 61, 62)
                val undev = homeSqs.filter { val p = b[it]; p != EMPTY && isWhitePiece(p) == white && (pieceType(p) == KNIGHT || pieceType(p) == BISHOP) }
                if (undev.size >= 2) out += Seen(if (yours) Topic.UNDEVELOPED_YOURS else Topic.UNDEVELOPED_THEIRS, 36, undev, undev.size)
            }
        }

        // ---- tàn cuộc ----
        if (isEndgame(b) && full >= 15) {
            val ks = b.indexOf(makePiece(KING, me))
            out += Seen(Topic.ENDGAME_KING, 32, if (ks >= 0) listOf(ks) else emptyList())
        }

        // ---- đối thủ bí nước ----
        if (pos.whiteToMove != me && !pos.inCheck()) {
            // đối thủ đang đi: ít nước hợp lệ
            val mob = mobility(pos)
            if (mob in 1..4 && full >= 12) out += Seen(Topic.OPPONENT_CRAMPED, 52, emptyList(), mob)
        }

        // ---- vật chất ----
        val diff = (material(b, me) - material(b, !me))
        when {
            diff >= 300 -> out += Seen(Topic.MATERIAL_UP, 30, emptyList(), diff)
            diff <= -300 -> out += Seen(Topic.MATERIAL_DOWN, 32, emptyList(), -diff)
            full >= 12 && diff in -50..50 -> out += Seen(Topic.MATERIAL_EVEN, 14)
        }

        out.sortByDescending { it.weight }
        return out
    }
}

// =====================================================================================
// Phân tích RIÊNG nước đi vừa đánh
// =====================================================================================

/** Sự thật về nước vừa đi. */
data class MoveFacts(
    val ply: Int,
    val byHuman: Boolean,
    val san: String,
    val from: Int,
    val to: Int,
    val moved: Int,              // loại quân (PAWN..KING)
    val captured: Int,           // loại quân bị ăn (0 = không)
    val isEp: Boolean,
    val castle: Int,             // 0 không, 1 nhập thành ngắn, 2 nhập thành dài
    val promo: Int,
    val check: Boolean,
    val mate: Boolean,
    val stalemate: Boolean,
    val movedIntoDanger: Boolean,       // quân vừa đi đứng ở ô bị ăn mà không đủ đền
    val hangingLeft: List<Int>,         // quân khác của mình bị treo SAU nước đi (và chưa bị treo trước đó, hoặc vẫn bị treo)
    val missedWin: Int,                 // ô mục tiêu bị bỏ lỡ (ăn không được) hoặc -1
    val missedValue: Int,
    val createdThreats: List<Int>,      // quân đối phương mới bị dọa sau nước đi
    val escapedCheck: Boolean,
    val recapture: Boolean,             // ăn lại ngay ô vừa bị ăn
    val repeatedPiece: Boolean,         // trong khai cuộc lại đi con vừa đi
    val earlyQueen: Boolean,
    val rimKnight: Boolean,
    val developing: Boolean,            // đưa Mã/Tượng ra khỏi vị trí gốc
    val centerPawn: Boolean,
    val freeCapture: Boolean,           // ăn quân mà quân đó không có ai bảo vệ / đổi lời
)

object MoveReader {
    private fun homeSquaresMinor(white: Boolean) = if (white) intArrayOf(1, 2, 5, 6) else intArrayOf(57, 58, 61, 62)

    /**
     * [before] thế trước nước đi, [move] nước đi, [after] thế sau nước đi (đã áp nước).
     * [moves]: toàn bộ danh sách nước đi của ván tính đến và bao gồm nước vừa đi (để phát hiện lặp quân, ăn lại).
     */
    fun read(before: Position, move: Int, after: Position, san: String, byHuman: Boolean, moves: List<Int>, capturedType: Int): MoveFacts {
        val from = moveFrom(move)
        val to = moveTo(move)
        val moverWhite = before.whiteToMove
        val moved = pieceType(before.board[from])
        val ep = moveFlag(move) == FLAG_EP
        val castle = if (moveFlag(move) == FLAG_CASTLE) (if (sqFile(to) > sqFile(from)) 1 else 2) else 0
        val inCheckAfter = after.inCheck()
        val noMoves = after.legalMoves().isEmpty()
        val mate = inCheckAfter && noMoves
        val stalemate = !inCheckAfter && noMoves

        val capV = if (capturedType != 0) BoardReader.value(capturedType) else 0
        val movedV = BoardReader.value(moved)
        val landed = after.board[to]
        val landedPrise = landed != EMPTY && BoardReader.isEnPrise(after.board, to)
        val movedIntoDanger = landedPrise && moved != KING && capV < movedV - 60 && !mate

        // quân khác của mình bị treo sau nước đi
        val hangingNow = BoardReader.enPrise(after.board, moverWhite).filter { it != to }
        val hangingLeft = hangingNow.filter { sq -> BoardReader.value(pieceType(after.board[sq])) >= 300 }

        // bỏ lỡ miếng ăn không
        var missedSq = -1
        var missedV = 0
        for (sq in 0 until 64) {
            val p = before.board[sq]
            if (p == EMPTY || isWhitePiece(p) == moverWhite || pieceType(p) == KING) continue
            val atk = BoardReader.attackers(before.board, sq, moverWhite)
            if (atk.isEmpty()) continue
            val defended = BoardReader.attackers(before.board, sq, !moverWhite).isNotEmpty()
            val tv = BoardReader.value(pieceType(p))
            val gain = if (!defended) tv else tv - atk.minOf { BoardReader.value(it) }
            if (gain >= 250 && gain > missedV) { missedV = gain; missedSq = sq }
        }
        // đã ăn đủ giá trị hoặc đã chiếu hết thì không tính là bỏ lỡ
        if (missedSq >= 0 && (capV >= missedV - 50 || mate || to == missedSq)) { missedSq = -1; missedV = 0 }

        // thế cờ dọa gì mới
        val enemyHangBefore = BoardReader.enPrise(before.board, !moverWhite).toSet()
        val enemyHangAfter = BoardReader.enPrise(after.board, !moverWhite)
        val newThreats = enemyHangAfter.filter { it !in enemyHangBefore && BoardReader.value(pieceType(after.board[it])) >= 300 }

        val prevOpp = if (moves.size >= 2) moves[moves.size - 2] else -1
        val recapture = capturedType != 0 && prevOpp >= 0 && moveTo(prevOpp) == to
        val ownPrev = if (moves.size >= 3) moves[moves.size - 3] else -1
        val ply = moves.size
        val repeated = ply <= 20 && ownPrev >= 0 && moveTo(ownPrev) == from && moved != PAWN && moved != KING && capturedType == 0 && castle == 0

        val homeRankQueen = if (moverWhite) 3 else 59
        val earlyQ = moved == QUEEN && from == homeRankQueen && ply <= 12 &&
            homeSquaresMinor(moverWhite).count { val p = before.board[it]; p != EMPTY && isWhitePiece(p) == moverWhite } >= 2
        val rim = moved == KNIGHT && (sqFile(to) == 0 || sqFile(to) == 7) && sqFile(from) !in intArrayOf(0, 7)
        val developing = (moved == KNIGHT || moved == BISHOP) && from in homeSquaresMinor(moverWhite) && ply <= 24
        val centerPawn = moved == PAWN && to in intArrayOf(27, 28, 35, 36) && ply <= 14
        val freeCap = capturedType != 0 && capV > 0 && (capV >= movedV + 150 || !landedPrise) && !recapture

        return MoveFacts(
            ply = ply, byHuman = byHuman, san = san, from = from, to = to, moved = moved,
            captured = capturedType, isEp = ep, castle = castle, promo = movePromo(move),
            check = inCheckAfter && !mate, mate = mate, stalemate = stalemate,
            movedIntoDanger = movedIntoDanger, hangingLeft = hangingLeft,
            missedWin = missedSq, missedValue = missedV, createdThreats = newThreats,
            escapedCheck = before.inCheck(), recapture = recapture, repeatedPiece = repeated,
            earlyQueen = earlyQ, rimKnight = rim, developing = developing, centerPawn = centerPawn,
            freeCapture = freeCap,
        )
    }
}
