package com.vila.chess.core

/**
 * Tìm nước đi hợp lệ trong [pos] từ ký hiệu SAN (vd "Nf3", "exd5", "O-O", "e8=Q+", "R1e2").
 * Ngược lại với [moveToSan] nhưng KHÔNG sinh SAN cho mọi nước đi (nhanh hơn ~30 lần): chỉ lọc các nước hợp lệ
 * theo loại quân + ô đích + gợi ý phân biệt. Trả null nếu SAN sai / không hợp lệ / mơ hồ.
 */
fun findMoveBySan(pos: Position, san: String): Int? {
    var s = san.trim().trimEnd('+', '#', '!', '?')
    if (s.isEmpty()) return null
    val legal = pos.legalMoves()

    // Nhập thành (chấp nhận cả số 0).
    val castle = s.replace('0', 'O')
    if (castle == "O-O" || castle == "O-O-O") {
        val toFile = if (castle == "O-O") 6 else 2
        return legal.firstOrNull { moveFlag(it) == FLAG_CASTLE && sqFile(moveTo(it)) == toFile }
    }

    var promo = 0
    val eq = s.indexOf('=')
    if (eq >= 0) {
        promo = pieceTypeOfLetter(s.getOrNull(eq + 1) ?: return null)
        if (promo == 0 || promo == PAWN || promo == KING) return null
        s = s.substring(0, eq)
    } else if (s.length >= 3 && s.last() in "QRBN" && s[s.length - 2] in '1'..'8') {
        // Dạng "e8Q" không có dấu '='.
        promo = pieceTypeOfLetter(s.last())
        s = s.dropLast(1)
    }

    var type = PAWN
    if (s[0] in "NBRQK") {
        type = pieceTypeOfLetter(s[0])
        s = s.substring(1)
    }
    s = s.replace("x", "").replace("-", "")
    if (s.length < 2) return null
    val file = s[s.length - 2]
    val rank = s[s.length - 1]
    if (file !in 'a'..'h' || rank !in '1'..'8') return null
    val dest = (rank - '1') * 8 + (file - 'a')
    val hint = s.substring(0, s.length - 2)
    if (hint.length > 2) return null

    val found = legal.filter { m ->
        if (moveTo(m) != dest) return@filter false
        if (pieceType(pos.board[moveFrom(m)]) != type) return@filter false
        if (movePromo(m) != promo) return@filter false
        hint.all { h ->
            when (h) {
                in 'a'..'h' -> sqFile(moveFrom(m)) == h - 'a'
                in '1'..'8' -> sqRank(moveFrom(m)) == h - '1'
                else -> false
            }
        }
    }
    return if (found.size == 1) found[0] else null
}

private fun pieceTypeOfLetter(c: Char): Int = when (c) {
    'N' -> KNIGHT
    'B' -> BISHOP
    'R' -> ROOK
    'Q' -> QUEEN
    'K' -> KING
    else -> 0
}
