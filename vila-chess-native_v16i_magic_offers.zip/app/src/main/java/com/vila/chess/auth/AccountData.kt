package com.vila.chess.auth

import android.content.Context
import android.content.SharedPreferences
import java.io.File
import java.security.MessageDigest

/**
 * Tách dữ liệu trong máy theo từng tài khoản.
 *
 * Trước đây Elo, thống kê, lịch sử ván, tiến độ puzzle, hồ sơ và file review nằm chung một chỗ cho cả máy,
 * nên đăng xuất rồi đăng nhập tài khoản khác vẫn thấy dữ liệu của tài khoản cũ.
 *
 * Cách làm: dữ liệu "đang dùng" (live) luôn thuộc về tài khoản [OWNER]. Khi đăng xuất hoặc đổi tài khoản,
 * dữ liệu live được cất vào bản sao riêng của tài khoản đó rồi xoá sạch; khi đăng nhập thì nạp lại bản sao của
 * tài khoản vừa vào (chưa có thì bắt đầu mới tinh). Không mất dữ liệu: đăng nhập lại tài khoản cũ là có lại.
 *
 * Gói thành viên (vila_membership / vila_usage) KHÔNG nằm trong danh sách vì gắn với Google Play / mã kích hoạt của thiết bị.
 */
object AccountData {
    private const val META = "vila_account_meta"
    private const val OWNER = "owner"        // vắng = dữ liệu cũ chưa biết chủ; "" = live đang trống; còn lại = khoá của chủ sở hữu
    private const val REVIEWS = "reviews"

    private val SWAPPED = listOf("vila_native", "vila_elo_history", "vila_game_history", "vila_puzzle_map", "vila_profile")

    /** Cài đặt thuộc về thiết bị (âm thanh, bộ quân...) nên đổi tài khoản vẫn giữ nguyên. */
    private val DEVICE_KEYS = mapOf("vila_native" to setOf("sound", "haptic", "pieceSet2", "premoveMode", "soundPack", "boardTheme", "wallpaper"))

    private fun app(ctx: Context) = ctx.applicationContext
    private fun meta(ctx: Context) = app(ctx).getSharedPreferences(META, Context.MODE_PRIVATE)
    private fun live(ctx: Context, base: String) = app(ctx).getSharedPreferences(base, Context.MODE_PRIVATE)
    private fun backup(ctx: Context, k: String, base: String) = app(ctx).getSharedPreferences("vila_acct_${k}_$base", Context.MODE_PRIVATE)
    private fun keep(base: String): Set<String> = DEVICE_KEYS[base] ?: emptySet()

    private fun keyOf(email: String): String {
        val d = MessageDigest.getInstance("SHA-1").digest(email.trim().lowercase().toByteArray())
        return d.joinToString("") { "%02x".format(it) }.take(16)
    }

    /** Gọi TRƯỚC khi đặt AccountStore.current = [email]. */
    @Synchronized
    fun onSignIn(ctx: Context, email: String) {
        val k = keyOf(email)
        val m = meta(ctx)
        val owner = m.getString(OWNER, null)
        if (owner == k) return
        if (owner == null) {                       // dữ liệu từ bản cũ chưa có chủ: tài khoản đầu tiên nhận lấy
            m.edit().putString(OWNER, k).commit()
            return
        }
        if (owner.isNotEmpty()) stash(ctx, owner)  // đang là của tài khoản khác: cất đi, live thành trống
        restore(ctx, k)
        m.edit().putString(OWNER, k).commit()
    }

    /** Gọi khi đăng xuất, trước khi xoá AccountStore.current. [currentEmail] là tài khoản đang đăng nhập. */
    @Synchronized
    fun onSignOut(ctx: Context, currentEmail: String?) {
        val m = meta(ctx)
        val owner = m.getString(OWNER, null) ?: currentEmail?.let { keyOf(it) }
        if (owner == null) return                  // không biết dữ liệu của ai: để nguyên, tài khoản đầu tiên sẽ nhận
        if (owner.isNotEmpty()) stash(ctx, owner)
        m.edit().putString(OWNER, "").commit()
    }

    // ------------------------------------------------------------------

    private fun stash(ctx: Context, k: String) {
        for (base in SWAPPED) {
            val l = live(ctx, base)
            copy(l, backup(ctx, k, base), skip = emptySet())
            wipe(l, keep(base))
        }
        val dir = File(app(ctx).filesDir, REVIEWS)
        val bak = File(app(ctx).filesDir, "${REVIEWS}_acct_$k")
        bak.deleteRecursively()
        if (dir.exists() && !dir.renameTo(bak)) {
            runCatching { dir.copyRecursively(bak, overwrite = true) }
            dir.deleteRecursively()
        }
        dir.mkdirs()
    }

    private fun restore(ctx: Context, k: String) {
        for (base in SWAPPED) {
            val b = backup(ctx, k, base)
            if (b.all.isNotEmpty()) {
                copy(b, live(ctx, base), skip = keep(base))
                b.edit().clear().commit()
            }
        }
        val dir = File(app(ctx).filesDir, REVIEWS)
        val bak = File(app(ctx).filesDir, "${REVIEWS}_acct_$k")
        if (bak.exists()) {
            dir.deleteRecursively()
            if (!bak.renameTo(dir)) {
                runCatching { bak.copyRecursively(dir, overwrite = true) }
                bak.deleteRecursively()
            }
        }
        dir.mkdirs()
    }

    /** Chép [from] sang [to]; trong [to] xoá mọi khoá (trừ [skip]) trước khi ghi. */
    private fun copy(from: SharedPreferences, to: SharedPreferences, skip: Set<String>) {
        val e = to.edit()
        for (key in to.all.keys) if (key !in skip) e.remove(key)
        for ((key, v) in from.all) {
            if (key in skip) continue
            when (v) {
                is Boolean -> e.putBoolean(key, v)
                is Int -> e.putInt(key, v)
                is Long -> e.putLong(key, v)
                is Float -> e.putFloat(key, v)
                is String -> e.putString(key, v)
                is Set<*> -> e.putStringSet(key, v.filterIsInstance<String>().toSet())
            }
        }
        e.commit()
    }

    private fun wipe(p: SharedPreferences, keep: Set<String>) {
        val e = p.edit()
        for (key in p.all.keys) if (key !in keep) e.remove(key)
        e.commit()
    }
}
