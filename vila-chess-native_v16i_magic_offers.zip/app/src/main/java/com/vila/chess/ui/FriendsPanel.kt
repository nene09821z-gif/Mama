package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.FriendsViewModel
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.UserProfile

/**
 * Danh sách bạn bè (kèm huy hiệu VIP cạnh tên) + thêm bạn theo ID.
 * Dùng ở tab "Bạn bè" của màn Hồ sơ và ở tab Bạn bè ngoài trang chủ. Chạm một người bạn → [OpponentProfileSheet].
 * Có đủ 4 trạng thái: đang tải · lỗi (có Thử lại) · trống · có dữ liệu.
 */
@Composable
fun FriendsPanel(
    onViewProfile: (String) -> Unit,
    modifier: Modifier = Modifier,
    fvm: FriendsViewModel = viewModel(),
) {
    val ctx = LocalContext.current
    val state by fvm.state.collectAsState()
    val message by fvm.message.collectAsState()
    val busy by fvm.busy.collectAsState()
    var sheetFor by remember { mutableStateOf<UserProfile?>(null) }
    var removeFor by remember { mutableStateOf<UserProfile?>(null) }
    var newId by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val myId = SupabaseCloud.userId(ctx)

    LaunchedEffect(message) {
        message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); fvm.consumeMessage() }
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // --- ID của mình để gửi cho bạn
        if (myId != null) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(VilaColors.Glass).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text("ID của bạn (gửi cho bạn bè để họ thêm bạn)", color = VilaColors.TextDim, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(myId, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(myId))
                        Toast.makeText(ctx, "Đã sao chép ID", Toast.LENGTH_SHORT).show()
                    }) { Text("Sao chép", color = VilaColors.Green, fontWeight = FontWeight.Bold) }
                }
            }
        }

        // --- Thêm bạn theo ID
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newId,
                onValueChange = { newId = it },
                singleLine = true,
                placeholder = { Text("Dán ID bạn bè") },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            TextButton(
                enabled = !busy && newId.isNotBlank(),
                onClick = { fvm.add(newId); newId = "" },
            ) { Text(if (busy) "…" else "Thêm", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
        }

        // --- Danh sách
        when (val s = state) {
            is LoadState.Loading -> LoadingBlock(text = "Đang tải danh sách bạn bè…")
            is LoadState.Error -> ErrorBlock(s.kind, onRetry = { fvm.refresh() })
            is LoadState.Success -> if (s.data.isEmpty()) {
                Text(
                    "Chưa có bạn bè nào. Dán ID của bạn bè vào ô phía trên để thêm.",
                    color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp),
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (f in s.data) FriendRow(f, onClick = { sheetFor = f }, onRemove = { removeFor = f })
                }
            }
        }
    }

    sheetFor?.let { f ->
        OpponentProfileSheet(
            userId = f.userId,
            fallbackName = f.displayName,
            fallbackTier = f.tier,
            onDismiss = { sheetFor = null },
            onViewFull = { id -> sheetFor = null; onViewProfile(id) },
        )
    }
    removeFor?.let { f ->
        AlertDialog(
            onDismissRequest = { removeFor = null },
            title = { Text("Xóa bạn bè?") },
            text = { Text("Xóa ${f.displayName} khỏi danh sách bạn bè của bạn?") },
            confirmButton = { TextButton(onClick = { fvm.remove(f.userId); removeFor = null }) { Text("Xóa", color = LossColor) } },
            dismissButton = { TextButton(onClick = { removeFor = null }) { Text("Hủy") } },
        )
    }
}

/** Một dòng bạn bè: avatar · tên + huy hiệu VIP · quốc gia · Elo Blitz. */
@Composable
private fun FriendRow(f: UserProfile, onClick: () -> Unit, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(VilaColors.Glass)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProfileAvatar(name = f.displayName, avatarKey = f.avatarKey, size = 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            NameWithBadge(name = f.displayName, tier = f.tier, fontSize = 16f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                CountryLine(f.countryCode)
                if (com.vila.chess.profile.Countries.byCode(f.countryCode) != null) Text("  ·  ", color = VilaColors.TextDim, fontSize = 13.sp)
                Text("Blitz ${f.elo(EloMode.BLITZ)}", color = VilaColors.TextDim, fontSize = 13.sp)
            }
        }
        IconButton(onClick = onRemove) { Icon(Icons.Filled.Close, contentDescription = "Xóa bạn", tint = VilaColors.TextDim) }
    }
}
