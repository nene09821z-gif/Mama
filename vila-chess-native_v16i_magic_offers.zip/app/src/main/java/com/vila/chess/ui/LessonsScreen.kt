package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.vila.chess.billing.rememberTier
import com.vila.chess.game.Course
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Lesson
import com.vila.chess.game.LessonCatalog
import com.vila.chess.game.LessonKind
import com.vila.chess.game.LessonProgress
import com.vila.chess.game.LessonQuota
import com.vila.chess.game.LessonStore
import kotlinx.coroutines.delay
import kotlin.math.ceil
import kotlin.math.roundToInt

// ════════════════════════════════════════════════════════════════════════════════════════════
//  TRANG BÀI HỌC (kiểu chess.com)
//
//  • Đầu trang: tiến độ + lượt miễn phí còn lại trong ngày (Free: 5 bài mới/ngày, sang ngày mới là được làm mới).
//  • "Tiếp tục học": bài kế tiếp chưa xong. • Danh sách khóa → bài, mỗi bài có bàn cờ xem trước nhỏ.
//  • Khóa nâng cao chỉ dành cho thành viên (có ổ khóa); thành viên học không giới hạn.
//
//  Tiết kiệm bộ nhớ / giữ mượt:
//    - Không giải mã ảnh mới: bàn cờ nhỏ vẽ bằng Canvas, dùng LẠI bộ ảnh quân cờ đã nạp của bàn chơi.
//    - LazyColumn có key + contentType; bàn cờ xem trước (IntArray 64) dựng một lần mỗi bài rồi nhớ lại.
//    - Chỉ MỘT đồng hồ đếm ngược (mỗi giây) và chỉ khi hết lượt; không có animation chạy nền liên tục.
//    - Tiến độ lưu vài trăm byte (SharedPreferences), không dùng cơ sở dữ liệu.
// ════════════════════════════════════════════════════════════════════════════════════════════

private val MiniLight = Color(0xFFEBECD0)
private val MiniDark = Color(0xFF739552)
private val DetailBg = Color(0xFF16233B)
private val LockedDim = Color(0xFF7C879C)
private val WarnRed = Color(0xFFE5675A)
private val GoldBrush = Brush.horizontalGradient(listOf(Color(0xFFF7D26A), Color(0xFFE5A83B)))
private val GoldText = Color(0xFF3A2A06)

@Composable
fun LessonsTab(
    vm: GameViewModel,
    bottomPad: Dp,
    onPlayingChange: (Boolean) -> Unit,
    onUpgrade: () -> Unit,
) {
    val ctx = LocalContext.current
    val store = remember { LessonStore.get(ctx) }
    val progress by store.state.collectAsState()
    val tier = rememberTier()
    val limit = remember(tier) { LessonQuota.limit(tier) }
    var detail by remember { mutableStateOf<Lesson?>(null) }
    var playing by remember { mutableStateOf<Lesson?>(null) }

    // Mở tab / qua 0h: làm mới lượt trong ngày. Ngủ thẳng đến nửa đêm nên không tốn pin.
    LaunchedEffect(Unit) {
        while (true) {
            store.refreshDay()
            val now = System.currentTimeMillis()
            delay((LessonQuota.nextMidnightMs(now) - now + 1000L).coerceAtLeast(1000L))
        }
    }
    // Đang giải bài chiến thuật ⇒ Trang chủ ẩn thanh điều hướng để tập trung.
    LaunchedEffect(playing) { onPlayingChange(playing != null) }
    DisposableEffect(Unit) { onDispose { onPlayingChange(false) } }
    BackHandler(enabled = playing != null) { playing = null }

    fun start(l: Lesson) {
        val c = LessonCatalog.courseOf(l.id)
        if (c != null && !LessonQuota.canOpenCourse(c, tier)) {
            detail = null
            onUpgrade()
            return
        }
        // Hết lượt: không làm gì, hộp thoại đang mở sẽ hiện trạng thái "đã hết lượt hôm nay".
        if (!store.tryStart(l.id, limit)) return
        detail = null
        if (l.kind == LessonKind.TACTIC) playing = l else vm.startLesson(l)
    }

    val cur = playing
    if (cur != null) {
        val puzzle = remember(cur.id) { cur.toPuzzle() }
        LessonPuzzleScreen(
            puzzle = puzzle,
            title = cur.title,
            idea = cur.idea,
            images = vm.pieceImages,
            onBack = { playing = null },
            onSolved = {
                store.complete(cur.id)
                playing = null
                detail = LessonCatalog.nextInCourse(cur.id)   // gợi ý ngay bài kế tiếp
            },
        )
    } else {
        LessonsList(
            progress = progress,
            tier = tier,
            limit = limit,
            images = vm.pieceImages,
            bottomPad = bottomPad,
            onOpen = { detail = it },
            onUpgrade = onUpgrade,
        )
    }

    val d = detail
    if (d != null) {
        val course = LessonCatalog.courseOf(d.id)
        LessonDetailDialog(
            lesson = d,
            course = course,
            locked = course != null && !LessonQuota.canOpenCourse(course, tier),
            alreadyOpenedToday = d.id in progress.startedToday,
            canStart = LessonQuota.canStart(limit, progress.startedToday, d.id),
            remaining = LessonQuota.remaining(limit, progress.startedToday.size),
            images = vm.pieceImages,
            onStart = { start(d) },
            onUpgrade = {
                detail = null
                onUpgrade()
            },
            onDismiss = { detail = null },
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────── Danh sách

@Composable
private fun LessonsList(
    progress: LessonProgress,
    tier: com.vila.chess.billing.MembershipTier,
    limit: Int?,
    images: Array<ImageBitmap?>,
    bottomPad: Dp,
    onOpen: (Lesson) -> Unit,
    onUpgrade: () -> Unit,
) {
    val total = LessonCatalog.all.size
    val doneCount = remember(progress.done) { LessonCatalog.all.count { it.id in progress.done } }
    val next = remember(progress.done, tier) {
        LessonCatalog.nextUp(progress.done) { LessonQuota.canOpenCourse(it, tier) }
    }
    val remaining = LessonQuota.remaining(limit, progress.startedToday.size)
    val seen = remember { mutableSetOf<Int>() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = bottomPad + 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item(key = "head", contentType = "head") {
            LessonsHeader(done = doneCount, total = total, limit = limit, remaining = remaining)
        }
        item(key = "hero", contentType = "hero") {
            Box(Modifier.staggerIn(0, seen).padding(top = 4.dp)) {
                if (next != null) {
                    val c = LessonCatalog.courseOf(next.id)
                    HeroCard(
                        lesson = next,
                        courseTitle = c?.title ?: "",
                        accent = Color(c?.accent ?: 0xFF81B64C),
                        images = images,
                        onClick = { onOpen(next) },
                    )
                } else {
                    AllDoneCard(premiumLeft = tier.rank == 0)
                }
            }
        }
        if (limit != null) {
            item(key = "quota", contentType = "quota") {
                Box(Modifier.staggerIn(1, seen)) {
                    QuotaCard(limit = limit, remaining = remaining ?: 0, onUpgrade = onUpgrade)
                }
            }
        }
        for (course in LessonCatalog.courses) {
            val locked = !LessonQuota.canOpenCourse(course, tier)
            item(key = "c_" + course.id, contentType = "course") {
                CourseHeader(
                    course = course,
                    done = course.lessons.count { it.id in progress.done },
                    locked = locked,
                )
            }
            items(course.lessons, key = { it.id }, contentType = { "lesson" }) { l ->
                LessonRow(
                    lesson = l,
                    accent = Color(course.accent),
                    done = l.id in progress.done,
                    locked = locked,
                    images = images,
                    onClick = { onOpen(l) },
                )
            }
        }
        if (limit != null) {
            item(key = "promo", contentType = "promo") { UpgradePromo(onUpgrade = onUpgrade) }
        }
    }
}

@Composable
private fun LessonsHeader(done: Int, total: Int, limit: Int?, remaining: Int?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Bài học", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text("Đã hoàn thành $done/$total bài", color = VilaColors.TextDim, fontSize = 13.sp)
        }
        if (limit == null) {
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(GoldBrush).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Star, contentDescription = null, tint = GoldText, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("Không giới hạn", color = GoldText, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        } else {
            val left = remaining ?: 0
            val col = if (left > 0) VilaColors.Green else WarnRed
            Box(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(col.copy(alpha = 0.18f))
                    .border(1.dp, col.copy(alpha = 0.55f), RoundedCornerShape(50))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text("Còn $left/$limit hôm nay", color = col, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun HeroCard(lesson: Lesson, courseTitle: String, accent: Color, images: Array<ImageBitmap?>, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .pressable(onClickLabel = "Học " + lesson.title, pressedScale = 0.98f, onClick = onClick)
            .glass(shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MiniBoard(lesson.preview, lesson.previewFlipped, images, 104.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("TIẾP TỤC HỌC", color = accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Text(
                lesson.title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 23.sp,
            )
            Text(
                courseTitle + " · " + lesson.minutes + " phút",
                color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(6.dp))
            ChunkyButton(text = "Học ngay", onClick = onClick, modifier = Modifier.fillMaxWidth(), height = 42.dp, fontSize = 17.sp)
        }
    }
}

@Composable
private fun AllDoneCard(premiumLeft: Boolean) {
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text("Tuyệt vời!", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            if (premiumLeft) "Bạn đã học hết các khóa miễn phí. Nâng cấp để mở các khóa nâng cao."
            else "Bạn đã hoàn thành toàn bộ bài học hiện có. Hãy luyện lại bất cứ lúc nào!",
            color = VilaColors.TextDim, fontSize = 14.sp,
        )
    }
}

@Composable
private fun QuotaCard(limit: Int, remaining: Int, onUpgrade: () -> Unit) {
    val used = limit - remaining
    Column(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            for (i in 0 until limit) {
                Box(
                    Modifier
                        .weight(1f)
                        .height(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (i >= used) VilaColors.Green else Color(0x33FFFFFF)),
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                if (remaining > 0) {
                    Text(
                        "Hôm nay còn $remaining/$limit bài miễn phí",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    )
                    Text("Lượt được làm mới vào ngày mới (0 giờ)", color = VilaColors.TextDim, fontSize = 12.sp)
                } else {
                    Text("Bạn đã dùng hết $limit bài hôm nay", color = WarnRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Countdown(prefix = "Bài mới mở lại sau ")
                }
            }
            TextButton(onClick = onUpgrade) {
                Text("Nâng cấp", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
            }
        }
    }
}

/** Đồng hồ đếm ngược đến 0h. Tách riêng để mỗi giây chỉ vẽ lại đúng một dòng chữ. */
@Composable
private fun Countdown(prefix: String, color: Color = VilaColors.TextDim, size: Int = 12) {
    val text by produceState(initialValue = LessonQuota.countdownText(System.currentTimeMillis())) {
        while (true) {
            delay(1000L)
            value = LessonQuota.countdownText(System.currentTimeMillis())
        }
    }
    Text(prefix + text, color = color, fontSize = size.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun CourseHeader(course: Course, done: Int, locked: Boolean) {
    val accent = Color(course.accent)
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(4.dp).height(38.dp).clip(RoundedCornerShape(2.dp)).background(accent))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    course.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false),
                )
                if (course.premium) {
                    Spacer(Modifier.width(8.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(GoldBrush).padding(horizontal = 7.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (locked) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = GoldText, modifier = Modifier.size(10.dp))
                            Spacer(Modifier.width(2.dp))
                        }
                        Text("PRO", color = GoldText, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
            Text(
                course.level + " · " + course.subtitle,
                color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            "$done/${course.lessons.size}",
            color = if (done == course.lessons.size) VilaColors.Green else VilaColors.TextDim,
            fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
        )
    }
}

@Composable
private fun LessonRow(lesson: Lesson, accent: Color, done: Boolean, locked: Boolean, images: Array<ImageBitmap?>, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (locked) 0.62f else 1f)
            .pressable(onClickLabel = lesson.title, pressedScale = 0.98f, onClick = onClick)
            .glass(shape)
            .padding(horizontal = 10.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MiniBoard(lesson.preview, lesson.previewFlipped, images, 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                lesson.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                lesson.goal + " · " + lesson.minutes + " phút",
                color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        StatusDot(done = done, locked = locked, accent = accent)
    }
}

@Composable
private fun StatusDot(done: Boolean, locked: Boolean, accent: Color) {
    val bg = when {
        done -> VilaColors.Green
        locked -> Color(0x33FFFFFF)
        else -> accent.copy(alpha = 0.22f)
    }
    Box(Modifier.size(30.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        when {
            done -> Icon(Icons.Filled.Check, contentDescription = "Đã xong", tint = Color.White, modifier = Modifier.size(18.dp))
            locked -> Icon(Icons.Filled.Lock, contentDescription = "Dành cho thành viên", tint = LockedDim, modifier = Modifier.size(16.dp))
            else -> Icon(Icons.Filled.PlayArrow, contentDescription = "Bắt đầu", tint = accent, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun UpgradePromo(onUpgrade: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .pressable(onClickLabel = "Nâng cấp", pressedScale = 0.98f, onClick = onUpgrade)
            .clip(shape)
            .background(GoldBrush)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Star, contentDescription = null, tint = GoldText, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Học không giới hạn", color = GoldText, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Text("Mở mọi khóa nâng cao, không bị giới hạn bài mỗi ngày", color = GoldText.copy(alpha = 0.8f), fontSize = 12.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── Chi tiết bài

@Composable
private fun LessonDetailDialog(
    lesson: Lesson,
    course: Course?,
    locked: Boolean,
    alreadyOpenedToday: Boolean,
    canStart: Boolean,
    remaining: Int?,
    images: Array<ImageBitmap?>,
    onStart: () -> Unit,
    onUpgrade: () -> Unit,
    onDismiss: () -> Unit,
) {
    val accent = Color(course?.accent ?: 0xFF81B64C)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 18.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DetailBg)
                .border(1.dp, VilaBrushes.GlassStroke, RoundedCornerShape(20.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            MiniBoard(lesson.preview, lesson.previewFlipped, images, 188.dp, corner = 10.dp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip(course?.title ?: "Bài học", accent)
                Chip(if (lesson.kind == LessonKind.PRACTICE) "Thực hành với Bot" else "Tìm nước đi", Color(0xFF9AA6BA))
                Chip(lesson.minutes.toString() + " phút", Color(0xFF9AA6BA))
            }
            Text(
                lesson.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
            )
            Text(
                lesson.idea, color = Color(0xFFC9D2E3), fontSize = 15.sp, lineHeight = 21.sp,
                textAlign = TextAlign.Center,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Flag, contentDescription = null, tint = VilaColors.Green, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Mục tiêu: " + lesson.goal, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            when {
                locked -> {
                    Notice("Khóa nâng cao dành cho thành viên", GoldText, GoldBrush)
                    ChunkyButton(text = "Mở khóa với gói thành viên", onClick = onUpgrade, modifier = Modifier.fillMaxWidth(), height = 48.dp, fontSize = 17.sp)
                }
                !canStart -> {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(WarnRed.copy(alpha = 0.16f)).padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("Bạn đã dùng hết lượt học miễn phí hôm nay", color = WarnRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Countdown(prefix = "Làm mới sau ", color = Color(0xFFE9B3AC), size = 13)
                    }
                    ChunkyButton(text = "Nâng cấp để học tiếp", onClick = onUpgrade, modifier = Modifier.fillMaxWidth(), height = 48.dp, fontSize = 17.sp)
                }
                else -> {
                    if (remaining != null) {
                        val msg = if (alreadyOpenedToday) "Bài đã mở hôm nay, học lại không tốn thêm lượt"
                        else "Bài này dùng 1 trong $remaining lượt còn lại hôm nay"
                        Text(msg, color = VilaColors.TextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    ChunkyButton(text = "Bắt đầu bài học", onClick = onStart, modifier = Modifier.fillMaxWidth(), height = 50.dp, fontSize = 18.sp)
                }
            }
            TextButton(onClick = onDismiss) {
                Text("Để sau", color = VilaColors.TextDim, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 9.dp, vertical = 3.dp),
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun Notice(text: String, textColor: Color, brush: Brush) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(brush).padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
    }
}

// ─────────────────────────────────────────────────────────────────────────── Bàn cờ nhỏ

/**
 * Bàn cờ xem trước, vẽ bằng một Canvas. [board]: mã quân 0..14 như UiState.board (index = hàng*8 + cột, a1 = 0).
 * Dùng lại [images] (bộ ảnh quân cờ đã nạp) nên không tốn thêm bộ nhớ ảnh.
 */
@Composable
private fun MiniBoard(
    board: IntArray,
    flipped: Boolean,
    images: Array<ImageBitmap?>,
    size: Dp,
    modifier: Modifier = Modifier,
    corner: Dp = 7.dp,
) {
    Canvas(modifier.size(size).clip(RoundedCornerShape(corner))) {
        val s = this.size.width / 8f
        drawRect(MiniLight)
        for (sq in 0 until 64) {
            val rank = sq shr 3
            val file = sq and 7
            if ((rank + file) % 2 != 0) continue          // ô tối (a1 là ô tối)
            val col = if (flipped) 7 - file else file
            val row = if (flipped) rank else 7 - rank
            drawRect(MiniDark, topLeft = Offset(col * s, row * s), size = Size(s, s))
        }
        val px = ceil(s).toInt()
        for (sq in 0 until 64) {
            val pc = board[sq]
            if (pc <= 0 || pc >= images.size) continue
            val img = images[pc] ?: continue
            val rank = sq shr 3
            val file = sq and 7
            val col = if (flipped) 7 - file else file
            val row = if (flipped) rank else 7 - rank
            drawImage(
                image = img,
                dstOffset = IntOffset((col * s).roundToInt(), (row * s).roundToInt()),
                dstSize = IntSize(px, px),
                filterQuality = FilterQuality.Medium,
            )
        }
    }
}
