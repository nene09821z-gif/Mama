package com.vila.chess.magic

import com.vila.chess.billing.MembershipTier
import com.vila.chess.core.BISHOP
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import java.util.Random

enum class Rarity(val label: String, val weight: Int) {
    COMMON("Thường", 50),
    UNCOMMON("Khá hiếm", 28),
    RARE("Hiếm", 14),
    EPIC("Sử thi", 6),
    LEGENDARY("Huyền thoại", 2);

    companion object {
        fun forCost(cost: Int) = when {
            cost <= 1 -> COMMON
            cost == 2 -> UNCOMMON
            cost <= 4 -> RARE
            cost <= 6 -> EPIC
            else -> LEGENDARY
        }
    }
}

/** Phần thưởng/điều kiện đi kèm, nhân đôi mỗi hiệu ứng gốc thành nhiều lá khác nhau. */
enum class Modifier(val prefix: String, val costDelta: Int, val free: Boolean, val text: String) {
    NONE("", 0, false, ""),
    ECHO("Vang Vọng", 1, false, "Rút thêm 1 bài."),
    HEX("Lời Nguyền", 1, false, "Đối thủ mất 1 mana."),
    HASTE("Thần Tốc", 2, true, "Không tốn lượt dùng bài (có thể dùng thêm 1 lá)."),
    LOCK("Phong Ấn", 2, false, "Đối thủ không thể dùng bài ở lượt tới."),
    UNDERDOG("Kẻ Yếu Thế", 0, false, "Giảm 1 mana nếu quân của bạn đang ít hơn đối thủ."),
    BURN("Thiêu Đốt", 2, false, "Đối thủ mất 2 mana."),
    FOCUS("Tập Trung", 1, false, "Lượt sau nhận thêm 1 mana."),
    PURGE("Thanh Tẩy", 1, false, "Xoá khiên và bẫy của đối thủ."),
    BLESS("Ban Phước", 1, false, "Giải băng mọi quân của bạn."),
    GREED("Tham Lam", 2, false, "Rút thêm 2 bài."),
    FRUGAL("Tiết Kiệm", 0, false, "Giảm 1 mana nếu bạn đang cầm từ 4 bài trở lên."),
}

class MagicCard(
    val id: Int,
    val effect: MagicEffect,
    val modifier: Modifier,
    val baseCost: Int,
    /** FREE = bài thường; khác FREE = bài đặc quyền của gói đó (và các gói cao hơn). */
    val tier: MembershipTier = MembershipTier.FREE,
) {
    val rarity: Rarity = Rarity.forCost(baseCost)
    val name: String = if (modifier == Modifier.NONE) effect.title else "${modifier.prefix} · ${effect.title}"
    val description: String = if (modifier == Modifier.NONE) effect.description else "${effect.description} ${modifier.text}"
    val icon: String get() = effect.icon

    /** Bài giải trí: có yếu tố may rủi/vui nhộn (xúc xắc, đồng xu, mũ ảo thuật…), kể cả khi nằm trong một Tuyệt kỹ. */
    val isFun: Boolean
        get() = effect is FunEffect || ((effect as? Combo)?.partsForTest()?.any { it is FunEffect } == true)

    /** Tuyệt kỹ VIP: bài đặc quyền được thiết kế mạnh hơn mua rời. */
    val isSignature: Boolean get() = (effect as? Combo)?.signature == true
}

/** Danh mục bài: ~190 hiệu ứng gốc × 12 phần thưởng = hơn 2.000 lá (có cả bài giải trí), mỗi lá đều có luật thật. */
object MagicCatalog {
    private val pieces = intArrayOf(PAWN, KNIGHT, BISHOP, ROOK, QUEEN)
    private fun pieceCost(t: Int) = when (t) { PAWN -> 1; KNIGHT, BISHOP -> 2; ROOK -> 3; QUEEN -> 5; else -> 3 }

    private fun baseEffects(): List<Pair<MagicEffect, Int>> {
        val out = ArrayList<Pair<MagicEffect, Int>>()
        for (t in pieces) for ((r, c) in listOf(Region.HOME2 to 0, Region.HALF to 1, Region.ANY to 2)) out += Spawn(t, r) to pieceCost(t) + c
        for (t in intArrayOf(0) + pieces) for (r in listOf(Region.ANY, Region.FILES_AD, Region.FILES_EH, Region.RANKS_LOW, Region.RANKS_HIGH)) {
            val base = if (t == 0) 5 else pieceCost(t) + 1 + (if (t == QUEEN) 1 else 0)
            out += Smite(t, r) to maxOf(1, base - (if (r == Region.ANY) 0 else 1))
        }
        for ((to, c) in listOf(KNIGHT to 2, BISHOP to 2, ROOK to 3, QUEEN to 5)) out += Promote(to) to c
        for ((f, t, c) in listOf(
            Triple(QUEEN, ROOK, 4), Triple(QUEEN, BISHOP, 4), Triple(QUEEN, KNIGHT, 4), Triple(ROOK, BISHOP, 3),
            Triple(ROOK, KNIGHT, 3), Triple(BISHOP, PAWN, 2), Triple(KNIGHT, PAWN, 2), Triple(ROOK, PAWN, 4), Triple(QUEEN, PAWN, 6),
        )) out += Demote(f, t) to c
        for ((m, c) in listOf(PAWN to 2, KNIGHT to 4, BISHOP to 4, ROOK to 6, QUEEN to 9)) out += Charm(m) to c
        out += Swap(false) to 2
        out += Swap(true) to 3
        for (t in pieces) for ((d, c) in listOf(2 to 0, 3 to 1, 0 to 2)) out += Teleport(t, d) to (if (t >= ROOK) 2 else 1) + c
        for (dir in PushDir.values()) for (d in 1..3) out += Push(dir, d) to d
        for (t in intArrayOf(0) + pieces) for (n in 1..3) out += Freeze(t, n) to (if (t == 0) 3 else maxOf(1, pieceCost(t))) + n - 1
        for (t in intArrayOf(0) + pieces) for (n in 1..3) out += Shield(t, n) to (if (t == 0) 2 else if (t == QUEEN) 3 else if (t == ROOK) 2 else 1) + n - 1
        for ((t, c) in listOf(0 to 5, PAWN to 3, KNIGHT to 3, BISHOP to 3, ROOK to 4, QUEEN to 4)) out += ExtraMove(t) to c
        for (n in 1..3) out += SpellLock(n) to 2 * n
        for (k in 1..4) out += ManaDrain(k) to k
        for ((g, c) in listOf(1 to 0, 2 to 0, 3 to 1, 4 to 1, 5 to 2, 6 to 2)) out += ManaGain(g) to c
        for (k in 1..3) out += DrawCards(k) to k
        for (k in 1..2) out += Discard(k) to 2 * k
        for (t in intArrayOf(0) + pieces) for ((r, c) in listOf(Region.HOME2 to 0, Region.HALF to 1)) out += Resurrect(t, r) to (if (t == 0) 3 else pieceCost(t)) + c
        for ((d, c) in listOf(2 to 2, 3 to 3, 0 to 5)) out += KingBlink(d) to c
        for ((n, c) in listOf(3 to 2, 5 to 3, 8 to 4)) out += Trap(n) to c
        for ((m, c) in listOf(PAWN to 3, KNIGHT to 5, BISHOP to 6)) out += Lightning(m) to c
        for ((t, c) in listOf(PAWN to 2, KNIGHT to 3, BISHOP to 3, ROOK to 5, QUEEN to 8)) out += Clone(t) to c
        for ((r, c) in listOf(Region.ANY to 3, Region.FILES_AD to 2, Region.FILES_EH to 2)) out += PawnStorm(r) to c
        // Bài giải trí (may rủi / vui nhộn)
        out += DiceRoll() to 2
        out += CoinFlip() to 3
        for (t in pieces) out += Mirror(t) to pieceCost(t) + 1
        out += LuckyWheel() to 3
        out += MagicHat() to 2
        out += Meteor() to 4
        return out
    }

    val cards: List<MagicCard> = run {
        val list = ArrayList<MagicCard>()
        for (m in Modifier.values()) for ((e, c) in baseEffects()) {
            list += MagicCard(list.size, e, m, minOf(9, c + m.costDelta))
        }
        list
    }

    val size: Int get() = cards.size

    /**
     * Bài đặc quyền theo gói. CÔNG BẰNG theo cấu trúc: mỗi lá chỉ gộp các phép thường độc lập, giá = tổng giá các phần + 1 (phí gộp),
     * nên không mạnh hơn bài thường cùng mana, chỉ thêm lựa chọn. Cả hai người chơi rút từ cùng một bộ bài.
     */
    const val EXCLUSIVE_DRAW_PERCENT = 12

    /** Giá gốc của một phần = đúng giá lá thường cùng hiệu ứng (tra theo tên), nên không thể rẻ hơn bài thường. */
    private val baseCostByTitle: Map<String, Int> by lazy { baseEffects().associate { it.first.title to it.second } }

    private fun combo(title: String, icon: String, vararg parts: MagicEffect): Pair<MagicEffect, Int> =
        Combo(parts.toList(), title, icon) to parts.sumOf { baseCostByTitle[it.title] ?: error("Không có bài gốc: ${it.title}") } + 1

    /** Tuyệt kỹ VIP: giá thiết kế riêng (rẻ hơn tổng giá mua rời) nên thực sự mạnh. */
    private fun signature(title: String, icon: String, cost: Int, vararg parts: MagicEffect): Pair<MagicEffect, Int> =
        Combo(parts.toList(), title, icon, signature = true) to cost

    private fun exclusiveBase(tier: MembershipTier): List<Pair<MagicEffect, Int>> = when (tier) {
        MembershipTier.GOLD -> listOf(
            combo("Song Khiên", "🛡️", Shield(0, 1), Shield(0, 1)),
            combo("Hai Tốt Tiếp Viện", "🌱", Spawn(PAWN, Region.HOME2), Spawn(PAWN, Region.HOME2)),
            combo("Băng Giá & Lửa Nhỏ", "🧊", Freeze(0, 1), Smite(PAWN, Region.ANY)),
            combo("Nghi Lễ Kép", "🔮", ManaGain(2), DrawCards(1)),
            combo("Trọng Lực Nhẹ", "🪨", Push(PushDir.TOWARD, 1), Shield(PAWN, 1)),
            // Tuyệt kỹ Gold
            signature("Rồng Lửa", "🐲", 5, Smite(0, Region.ANY), Shield(0, 1)),
            signature("Thần Tài", "💰", 2, ManaGain(4), DrawCards(1)),
            signature("Bão Tuyết", "🌨️", 5, Freeze(0, 2), Freeze(0, 1)),
            signature("Sòng Bạc", "🎰", 4, DiceRoll(), CoinFlip()),
        )
        MembershipTier.PLATINUM -> listOf(
            combo("Phục Kích", "🪤", Trap(3), Shield(0, 1)),
            combo("Hai Xe Dịch Chuyển", "🚀", Teleport(ROOK, 3), Teleport(ROOK, 3)),
            combo("Đại Hồi Sinh", "🕊️", Resurrect(0, Region.HOME2), Resurrect(0, Region.HOME2)),
            combo("Phong Ấn Thần Tốc", "⏳", SpellLock(1), ExtraMove(0)),
            combo("Lưỡng Nghi", "☯️", Swap(false), Shield(0, 1)),
            combo("Gieo Mầm", "🌾", Clone(PAWN), Clone(PAWN)),
            // Tuyệt kỹ Platinum
            signature("Hoán Đổi Hộ Mệnh", "⚖️", 5, Swap(true), Shield(0, 2)),
            signature("Hoàng Hôn Đỏ", "🌇", 8, Smite(0, Region.ANY), Smite(0, Region.ANY)),
            signature("Quân Đoàn Bóng Tối", "🦇", 5, Spawn(BISHOP, Region.HALF), Spawn(KNIGHT, Region.HALF)),
            signature("Tiệc Pháo Hoa", "🎆", 4, LuckyWheel(), MagicHat()),
        )
        MembershipTier.DIAMOND -> listOf(
            combo("Vương Quyền", "👑", KingBlink(2), Shield(0, 2)),
            combo("Thiên Phạt", "☄️", Smite(0, Region.FILES_AD), Freeze(0, 1)),
            combo("Triều Cường", "🌊", PawnStorm(Region.ANY), Shield(PAWN, 1)),
            combo("Mê Hoặc Kép", "💎", Charm(PAWN), Charm(PAWN)),
            combo("Nghi Thức Tối Thượng", "🌟", ManaGain(6), DrawCards(2)),
            combo("Kho Báu Rồng", "🐉", DrawCards(3), ManaGain(2)),
            // Tuyệt kỹ Diamond
            signature("Ngày Tận Thế", "🌋", 7, Lightning(BISHOP), Shield(0, 2)),
            signature("Hoàng Đế Giáng Thế", "🤴", 7, Spawn(QUEEN, Region.HOME2), Shield(QUEEN, 2)),
            signature("Đại Phát Tài", "🎇", 3, ManaGain(6), DrawCards(3)),
            signature("Sao Băng Hoàng Gia", "☄️", 5, Meteor(), DiceRoll()),
        )
        else -> emptyList()
    }

    private val exclusiveMods = listOf(Modifier.NONE, Modifier.ECHO, Modifier.HEX, Modifier.FRUGAL)

    /** Mọi bài đặc quyền (id nối tiếp sau bài thường). */
    val exclusive: List<MagicCard> = run {
        val list = ArrayList<MagicCard>()
        for (tier in listOf(MembershipTier.GOLD, MembershipTier.PLATINUM, MembershipTier.DIAMOND)) {
            for (m in exclusiveMods) for ((e, c) in exclusiveBase(tier)) {
                list += MagicCard(cards.size + list.size, e, m, minOf(9, c + m.costDelta), tier)
            }
        }
        list
    }

    fun get(id: Int): MagicCard = if (id < cards.size) cards[id] else exclusive[id - cards.size]

    /** Bài đặc quyền mà [tier] được rút (gói cao hơn gồm gói thấp hơn). */
    fun exclusiveFor(tier: MembershipTier): List<MagicCard> = exclusive.filter { it.tier.rank <= tier.rank }

    private val byRarity: Map<Rarity, List<MagicCard>> = cards.groupBy { it.rarity }

    /** Lá bài giải trí (xúc xắc, đồng xu, mũ ảo thuật…) — xuất hiện thêm cho mọi gói. */
    private val funIds: List<Int> by lazy { cards.filter { it.isFun }.map { it.id } }
    const val FUN_DRAW_PERCENT = 15

    /** Số lá bài mở ra đầu mỗi lượt để người chơi chọn 1. */
    const val OFFER_SIZE = 3

    /** Xác suất mỗi ô trong 3 lá là bài đặc quyền (ô đầu tiên của gói VIP luôn là bài đặc quyền). */
    fun vipSlotPercent(tier: MembershipTier): Int = when {
        tier.rank >= MembershipTier.DIAMOND.rank -> 45
        tier.rank >= MembershipTier.PLATINUM.rank -> 35
        tier.rank >= MembershipTier.GOLD.rank -> 25
        else -> 0
    }

    /** Rút ngẫu nhiên một bài thường (có trọng số theo độ hiếm; một phần nhỏ là bài giải trí). */
    fun randomNormalId(rng: Random): Int {
        if (funIds.isNotEmpty() && rng.nextInt(100) < FUN_DRAW_PERCENT) return funIds[rng.nextInt(funIds.size)]
        val pools = Rarity.values().filter { byRarity[it]?.isNotEmpty() == true }
        var roll = rng.nextInt(pools.sumOf { it.weight })
        for (r in pools) {
            roll -= r.weight
            if (roll < 0) return byRarity.getValue(r).let { it[rng.nextInt(it.size)].id }
        }
        return cards[rng.nextInt(cards.size)].id
    }

    /** Rút ngẫu nhiên có trọng số theo độ hiếm. */
    fun randomId(rng: Random, tier: MembershipTier = MembershipTier.FREE): Int {
        val ex = exclusiveFor(tier)
        if (ex.isNotEmpty() && rng.nextInt(100) < EXCLUSIVE_DRAW_PERCENT) return ex[rng.nextInt(ex.size)].id
        return randomNormalId(rng)
    }

    /**
     * [n] lá bài KHÁC NHAU hiện ra đầu lượt để chọn 1. Gói Free: toàn bài thường (có thể có bài giải trí).
     * Gói VIP (Gold trở lên): luôn có ít nhất 1 lá đặc quyền, các ô còn lại có thêm cơ hội ra bài đặc quyền
     * (Gold 25% · Platinum 35% · Diamond/Family 45%) — gói càng cao càng mạnh.
     */
    fun offerIds(rng: Random, tier: MembershipTier = MembershipTier.FREE, n: Int = OFFER_SIZE): List<Int> {
        val ex = exclusiveFor(tier)
        val chance = vipSlotPercent(tier)
        val out = ArrayList<Int>()
        if (ex.isNotEmpty()) out += ex[rng.nextInt(ex.size)].id
        var guard = 0
        while (out.size < n && guard++ < 500) {
            val id = if (ex.isNotEmpty() && rng.nextInt(100) < chance) ex[rng.nextInt(ex.size)].id else randomNormalId(rng)
            if (id !in out) out += id
        }
        java.util.Collections.shuffle(out, rng)
        return out
    }
}
