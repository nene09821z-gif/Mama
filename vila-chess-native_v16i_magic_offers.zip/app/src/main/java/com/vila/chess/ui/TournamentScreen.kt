package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Levels
import com.vila.chess.game.TimeControls
import com.vila.chess.game.Tournament
import com.vila.chess.game.levelRating

private val ROW_SHAPE = RoundedCornerShape(10.dp)

/** Bot tournament: 8 rounds against bot levels 1..8, colours alternate, results are saved. */
@Composable
fun TournamentScreen(vm: GameViewModel, onBack: () -> Unit) {
    val results = vm.tournament
    val next = Tournament.nextRound(results)
    val points = Tournament.points(results)
    val timeControl = TimeControls.get(vm.timeIndex)
    var confirmReset by remember { mutableStateOf(false) }
    val anyPlayed = results.any { it != null }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = Color(0xFFB9C1CE),
                )
            }
            MedalIcon(Modifier.size(28.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Giải đấu Bot ViLa",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item(key = "summary") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .glass(ROW_SHAPE)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Text(
                        text = Tournament.pointsText(points) + " / " + Tournament.ROUNDS + " điểm",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold,
                    )
                    Text(
                        text = if (next < 0) {
                            "Đã kết thúc · " + Tournament.title(points)
                        } else {
                            "Sắp tới: vòng " + (next + 1) + "/" + Tournament.ROUNDS
                        },
                        color = if (next < 0) VilaColors.Green else VilaColors.TextDim,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        text = "Thời gian mỗi ván: " + timeControl.label + " (đổi ở màn Ván cờ mới)",
                        color = VilaColors.TextDim,
                        fontSize = 12.sp,
                    )
                }
            }
            items(Tournament.ROUNDS, key = { it }) { round ->
                RoundRow(round = round, result = results[round], current = round == next)
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            ChunkyButton(
                text = if (next < 0) "Chơi lại giải" else if (next == 0) "Bắt đầu giải đấu" else "Chơi vòng " + (next + 1),
                onClick = {
                    if (next < 0) vm.resetTournament()
                    vm.startTournamentRound()
                },
                modifier = Modifier.fillMaxWidth(),
                height = 50.dp,
                fontSize = 20.sp,
            )
            if (anyPlayed && next >= 0) {
                TextButton(onClick = { confirmReset = true }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Đặt lại giải", color = VilaColors.TextDim)
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = Color(0xFF16233B),
            titleContentColor = Color.White,
            textContentColor = VilaColors.TextDim,
            shape = RoundedCornerShape(16.dp),
            title = { Text("Đặt lại giải đấu?", fontWeight = FontWeight.ExtraBold) },
            text = { Text("Toàn bộ kết quả các vòng đã chơi sẽ bị xóa.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    vm.resetTournament()
                }) { Text("Đặt lại", color = VilaColors.Danger, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Hủy", color = VilaColors.TextDim) }
            },
        )
    }
}

@Composable
private fun RoundRow(round: Int, result: Double?, current: Boolean) {
    val level = Levels.get(Tournament.levelFor(round))
    val borderColor = if (current) VilaColors.Green else VilaColors.GlassBorder
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(ROW_SHAPE)
            .background(VilaColors.Glass)
            .border(if (current) 1.5.dp else 1.dp, borderColor, ROW_SHAPE)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .background(Color(0x33FFFFFF), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text((round + 1).toString(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Cấp " + level.id + " · " + level.name,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            Text(
                text = "Bạn cầm " + (if (Tournament.humanWhite(round)) "Trắng" else "Đen") + " · ~" + levelRating(level.id),
                color = VilaColors.TextDim,
                fontSize = 12.sp,
            )
        }
        val label: String
        val chipColor: Color
        val textColor: Color
        when {
            result == null -> {
                label = "—"
                chipColor = Color(0x22FFFFFF)
                textColor = VilaColors.TextDim
            }
            result >= 1.0 -> {
                label = "1"
                chipColor = VilaColors.Green
                textColor = Color.White
            }
            result >= 0.5 -> {
                label = "½"
                chipColor = Color(0xFF7C7A76)
                textColor = Color.White
            }
            else -> {
                label = "0"
                chipColor = VilaColors.Danger
                textColor = Color.White
            }
        }
        Box(
            modifier = Modifier
                .size(width = 40.dp, height = 30.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(chipColor),
            contentAlignment = Alignment.Center,
        ) {
            Text(label, color = textColor, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
