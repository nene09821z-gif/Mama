package com.vila.chess.ui

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.R
import com.vila.chess.auth.Account
import com.vila.chess.auth.AccountStore
import com.vila.chess.auth.AuthProvider
import com.vila.chess.auth.SocialSignIn
import com.vila.chess.profile.NameRules
import com.vila.chess.profile.UserSessionManager
import kotlinx.coroutines.launch

/**
 * Tài khoản: khi chưa đăng nhập = Google + nhập email; khi đã đăng nhập = các cài đặt tài khoản
 * (đổi tên hiển thị, xem email, đăng xuất). Ứng dụng đăng nhập bằng Google/email nên KHÔNG có mật khẩu để đổi.
 * Giao diện bàn cờ/quân cờ/hình nền/âm thanh nằm ở trang Chủ đề riêng, không lặp lại ở đây.
 */
@Composable
fun AccountScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? ComponentActivity
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { AccountStore.load(ctx) }
    val acc = AccountStore.current
    var email by remember { mutableStateOf("") }
    var pendingName by remember { mutableStateOf("") }
    var pendingProvider by remember { mutableStateOf(AuthProvider.EMAIL) }
    var error by remember { mutableStateOf<String?>(null) }
    var showRename by remember { mutableStateOf(false) }
    var showSignOut by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    fun finish(e: String?, name: String, p: AuthProvider) {
        if (e != null && AccountStore.isValidEmail(e)) {
            AccountStore.save(ctx, Account(e.trim(), name, p)); error = null
        } else {                       // Google không trả email -> giữ tên, bắt nhập email
            pendingName = name; pendingProvider = p
            error = "Tài khoản không cung cấp email. Hãy nhập email để xem Game Review."
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE))
            }
            Text(
                "Tài khoản", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                maxLines = 1, modifier = Modifier.align(Alignment.Center),
            )
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (acc != null) {
                val name = UserSessionManager.displayName
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ProfileAvatar(name = name, avatarKey = UserSessionManager.avatarKey, size = 64.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(acc.email, color = Color(0xFFB9C1CE), fontSize = 14.sp, maxLines = 1)
                    }
                }
                GlassSection("CÀI ĐẶT TÀI KHOẢN") {
                    AccountRow("Đổi tên", name) { showRename = true }
                    AccountRow("Email", acc.email, onClick = null)
                    AccountRow("Đăng nhập bằng", if (acc.provider == AuthProvider.GOOGLE) "Google" else "Email", onClick = null)
                }
                Text(
                    "Game Review phân tích sẽ gắn với email này.",
                    color = Color(0xFF81B64C), fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp),
                )
                Spacer(Modifier.height(8.dp))
                AuthButton("Đăng xuất", Color(0xFF3C3A37)) { showSignOut = true }
            } else {
                AuthButton("Tiếp tục với Google", Color.White, Color.Black) {
                    if (activity == null) return@AuthButton
                    scope.launch {
                        runCatching { SocialSignIn.google(activity, ctx.getString(R.string.google_web_client_id)) }
                            .onSuccess { finish(it.email, it.name, AuthProvider.GOOGLE) }
                            .onFailure { error = "Đăng nhập Google lỗi: ${it.message}" }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Hoặc nhập email", color = Color(0xFFB9C1CE), fontSize = 14.sp)
                OutlinedTextField(
                    value = email, onValueChange = { email = it },
                    singleLine = true, placeholder = { Text("email@vidu.com") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth(),
                )
                AuthButton("Lưu email", Color(0xFF81B64C)) {
                    if (AccountStore.isValidEmail(email)) finish(email, pendingName, pendingProvider)
                    else Toast.makeText(ctx, "Email không hợp lệ", Toast.LENGTH_SHORT).show()
                }
            }
            error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        }
    }

    if (showRename) {
        RenameDialog(
            current = UserSessionManager.displayName,
            onDismiss = { showRename = false },
            onSave = { newName ->
                // Giữ nguyên quốc gia + ảnh đại diện, chỉ đổi tên; tên hiện ở hồ sơ, bạn bè và bảng xếp hạng.
                val err = UserSessionManager.updateProfile(ctx, newName, UserSessionManager.countryCode, UserSessionManager.avatarKey)
                if (err == null) Toast.makeText(ctx, "Đã đổi tên", Toast.LENGTH_SHORT).show()
                err
            },
        )
    }
    if (showSignOut) {
        AlertDialog(
            onDismissRequest = { showSignOut = false },
            containerColor = VilaColors.Panel,
            title = { Text("Đăng xuất?", color = Color.White, fontWeight = FontWeight.ExtraBold) },
            text = { Text("Dữ liệu của tài khoản này được cất lại, đăng nhập lại là có lại.", color = VilaColors.TextDim) },
            confirmButton = {
                TextButton(onClick = { showSignOut = false; AccountStore.signOut(ctx) }) {
                    Text("Đăng xuất", color = VilaColors.Danger, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { showSignOut = false }) { Text("Hủy", color = VilaColors.TextDim) } },
        )
    }
}

/** Một dòng cài đặt: nhãn trái, giá trị phải; có [onClick] thì hiện mũi tên và bấm được. */
@Composable
private fun AccountRow(label: String, value: String, onClick: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(
            value, color = VilaColors.TextDim, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 190.dp),
        )
        if (onClick != null) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = VilaColors.TextDim)
    }
}

@Composable
private fun RenameDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> String?) {
    var name by remember { mutableStateOf(current) }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = VilaColors.Panel,
        title = { Text("Đổi tên", color = Color.White, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(NameRules.MAX); err = null },
                    singleLine = true,
                    isError = err != null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = VilaColors.Green, cursorColor = VilaColors.Green,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    err ?: ("Từ " + NameRules.MIN + " đến " + NameRules.MAX + " ký tự"),
                    color = if (err != null) Color(0xFFFF8A80) else VilaColors.TextDim,
                    fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { val e = onSave(name); if (e == null) onDismiss() else err = e }) {
                Text("Lưu", color = VilaColors.Green, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Hủy", color = VilaColors.TextDim) } },
    )
}

@Composable
private fun AuthButton(text: String, bg: Color, fg: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(12.dp)).background(bg)
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}
