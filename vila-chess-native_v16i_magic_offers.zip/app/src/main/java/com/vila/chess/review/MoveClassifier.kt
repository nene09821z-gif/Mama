package com.vila.chess.review

import kotlin.math.exp
import kotlin.math.max

/**
 * Chấm nước đi theo Expected Points (EP = xác suất thắng của BÊN VỪA ĐI, 0.0–1.0) — công thức Lichess + nhãn kiểu Chess.com.
 * Hàm thuần (không Android, không engine) nên test được trên JVM.
 *
 * Quy ước: cp và mate đưa vào [calculateWinProbability] theo góc nhìn TRẮNG (dương = Trắng hơn / Trắng chiếu hết).
 * Mọi "loss" và "ep" là phân số 0.0–1.0 (0.20 = 20 điểm %).
 *
 * Thứ tự gán nhãn: BOOK > MISS > BRILLIANT > GREAT > BEST > theo loss (EXCELLENT ≤ 2% · GOOD ≤ 5% · INACCURACY ≤ 10% · MISTAKE ≤ 20% · BLUNDER > 20%).
 *
 * MISS: đối thủ vừa sai (Mistake/Blunder) VÀ nước vừa đi KHÔNG phải nước tốt nhất VÀ làm EP sụt > 10% (thế sau vẫn ≥ 40%).
 *   Đi đúng nước tốt nhất sau lỗi của đối thủ = đã trừng phạt => không bao giờ là Miss (xuống Brilliant / Great / Best).
 * BRILLIANT: nước tốt nhất + hy sinh quân, và một trong hai:
 *   (a) dẫn tới chiếu hết cho mình, hoặc thế sau áp đảo (EP ≥ 95%) — bất kể epBefore / nước thay thế (vd. smothered mate);
 *   (b) nước thay thế tốt nhất còn < 90% và thế sau ≥ 40% ("chưa thắng đậm nếu không tìm ra nước này").
 */
object MoveClassifier {

    private const val WP_SLOPE = 0.00368208
    private const val ACC_A = 103.1668
    private const val ACC_K = 0.04354
    private const val ACC_B = 3.1669
    private const val EPS = 1e-9

    // ---- ngưỡng loss ----
    const val EXCELLENT_MAX = 0.02
    const val GOOD_MAX = 0.05
    const val INACCURACY_MAX = 0.10
    const val MISTAKE_MAX = 0.20

    // ---- thế đã ngã ngũ: sai thêm cũng ít ý nghĩa nên giảm nhẹ mức phạt ----
    const val DEAD_LOW = 0.05
    const val DEAD_HIGH = 0.95
    const val DEAD_FACTOR = 0.5

    // ---- nhãn đặc biệt ----
    /**
     * Brilliant (nhánh thường): phương án thay thế tốt nhất phải còn dưới mức này ("chưa thắng đậm nếu không tìm ra nước này").
     * Hy sinh dẫn tới chiếu hết hoặc thế áp đảo ([BRILLIANT_OVERWHELMING_EP]) KHÔNG bị giới hạn này.
     */
    const val BRILLIANT_MAX_ALT_EP = 0.90
    /** Brilliant (nhánh thường): hy sinh xong thế không được xấu. */
    const val BRILLIANT_MIN_EP_AFTER = 0.40
    /**
     * Brilliant (nhánh áp đảo): hy sinh xong mà EP ≥ mức này (≈ hơn +8 tốt) thì là Brilliant bất kể epBefore hay nước thay thế.
     * Muốn khắt khe hơn (ít Brilliant hơn trong ván đang thắng sẵn) thì nâng số này lên.
     */
    const val BRILLIANT_OVERWHELMING_EP = 0.95
    const val GREAT_MIN_GAP = 0.15
    const val GREAT_MIN_EP = 0.30
    /** Nước tốt nhì kém nước tốt nhất không quá mức này thì coi như ngang (vẫn là Best). */
    const val TIE_EPS = 0.0025
    /** Miss: nước đi phải làm EP sụt NHIỀU HƠN mức này (> 10%, cỡ Mistake) sau lỗi của đối thủ. */
    const val MISS_MIN_LOSS = 0.10
    /** Miss: thế sau nước đi phải còn ≥ mức này; thấp hơn là thế đã xấu thật => Mistake/Blunder chứ không phải Miss. */
    const val MISS_MIN_EP_AFTER = 0.40

    // ---- luật chiếu hết của Lichess (Advice.scala): cp của BÊN ĐI ----
    const val MATE_BIG_ADVANTAGE_CP = 700
    const val MATE_HUGE_ADVANTAGE_CP = 999
    /** "Sàn" loss ứng với từng nhãn (vừa vượt biên dưới của nhãn đó). */
    const val FLOOR_INACCURACY = GOOD_MAX + EPS
    const val FLOOR_MISTAKE = INACCURACY_MAX + EPS
    const val FLOOR_BLUNDER = MISTAKE_MAX + EPS

    // ------------------------------------------------------------------ Win probability

    /** Xác suất thắng (0–1) của bên mà [cp]/[mate] đang nói tới. mate == 0: đã bị chiếu hết, bên thắng suy từ dấu cp. */
    fun winProbability(cp: Int, mate: Int?): Double = when {
        mate == null -> 0.5 + 0.5 * (2.0 / (1.0 + exp(-WP_SLOPE * cp)) - 1.0)
        mate > 0 -> 1.0
        mate < 0 -> 0.0
        else -> if (cp >= 0) 1.0 else 0.0
    }

    /**
     * Win probability (0.0–1.0) của BÊN ĐANG ĐI. [cp]/[mate] theo góc nhìn Trắng; lượt Đen thì đảo: 1 − WP_White.
     */
    fun calculateWinProbability(cp: Int, mate: Int?, isWhiteTurn: Boolean): Double {
        val white = winProbability(cp, mate)
        return if (isWhiteTurn) white else 1.0 - white
    }

    // ------------------------------------------------------------------ Loss

    /** Nước đi là nước tốt nhất, hoặc nước tốt nhì ngang điểm (chênh ≤ [TIE_EPS]). */
    fun isBestMove(movePlayed: String, bestMove: String?, secondBestMove: String?, epBefore: Double, epSecondBest: Double?): Boolean =
        (bestMove != null && movePlayed == bestMove) ||
            (secondBestMove != null && movePlayed == secondBestMove && epSecondBest != null &&
                epBefore - epSecondBest <= TIE_EPS)

    /**
     * EP loss của nước đã đi (không có sàn mate). Nước tốt nhất = 0.
     * Đi đúng nước tốt nhì: có hai ước lượng độc lập (cùng lượt tìm kiếm và lượt tìm ở thế sau) nên lấy trung bình cho bớt nhiễu.
     * Thế đã ngã ngũ (epBefore < 5% hoặc > 95%): loss × 0.5.
     */
    fun moveLoss(
        epBefore: Double,
        epAfter: Double,
        movePlayed: String,
        bestMove: String?,
        secondBestMove: String?,
        epSecondBest: Double? = null,
    ): Double {
        if (isBestMove(movePlayed, bestMove, secondBestMove, epBefore, epSecondBest)) return 0.0
        var loss = max(0.0, epBefore - epAfter)
        if (secondBestMove != null && movePlayed == secondBestMove && epSecondBest != null) {
            loss = (max(0.0, epBefore - epSecondBest) + loss) / 2.0
        }
        if (epBefore < DEAD_LOW || epBefore > DEAD_HIGH) loss *= DEAD_FACTOR
        return loss
    }

    // ------------------------------------------------------------------ Phân loại

    /**
     * Gán nhãn một nước đi.
     *
     * @param epBefore EP của bên đi TRƯỚC nước đi (= EP của nước tốt nhất).
     * @param epAfter EP của bên đi SAU nước đi.
     * @param isSacrifice nước đi cho đi quân (xem [SacrificeDetector]).
     * @param isOpponentJustBlundered nước ngay trước của đối thủ là Mistake/Blunder.
     * @param epSecondBest EP của nước tốt nhì (MultiPV 2); null = không có.
     * @param lossFloor sàn loss theo luật mate của Lichess ([mateRuleFloor]); chỉ ảnh hưởng nhãn, không ảnh hưởng accuracy.
     * @param mateAfter mate của thế SAU nước đi theo góc nhìn BÊN VỪA ĐI: dương = mình sắp chiếu hết, 0 = vừa chiếu hết,
     *   âm = mình sắp bị chiếu hết, null = không có mate. Chỉ dùng cho nhánh Brilliant "hy sinh dẫn tới chiếu hết" ([leadsToMate]).
     */
    fun classifyMove(
        epBefore: Double,
        epAfter: Double,
        movePlayed: String,
        bestMove: String?,
        secondBestMove: String?,
        isSacrifice: Boolean,
        isOpponentJustBlundered: Boolean,
        epSecondBest: Double? = null,
        isRecapture: Boolean = false,
        inBook: Boolean = false,
        lossFloor: Double = 0.0,
        mateAfter: Int? = null,
    ): MoveLabel {
        if (inBook) return MoveLabel.BOOK

        val best = isBestMove(movePlayed, bestMove, secondBestMove, epBefore, epSecondBest)
        val loss = max(moveLoss(epBefore, epAfter, movePlayed, bestMove, secondBestMove, epSecondBest), if (best) 0.0 else lossFloor)

        // MISS: đối thủ vừa sai mà mình KHÔNG tận dụng — nước đi không phải nước tốt nhất và làm EP sụt > 10%,
        // nhưng thế sau vẫn chưa xấu (xấu thật thì là Mistake/Blunder).
        // Đi đúng nước tốt nhất sau lỗi của đối thủ = đã trừng phạt được => KHÔNG BAO GIỜ là Miss: rơi xuống nhánh Brilliant / Great / Best.
        if (isOpponentJustBlundered && !best && loss > MISS_MIN_LOSS && epAfter >= MISS_MIN_EP_AFTER) return MoveLabel.MISS

        if (best) {
            val playedBest = bestMove != null && movePlayed == bestMove
            // Phương án thay thế tốt nhất nếu KHÔNG đi nước này: nước tốt nhì (khi đã đi nước tốt nhất), không biết thì dùng epBefore.
            val alt = (if (playedBest) epSecondBest else epBefore) ?: epBefore
            if (isSacrifice) {
                // (a) hy sinh dẫn tới chiếu hết / thế áp đảo: Brilliant bất kể epBefore và nước thay thế (vd. smothered mate).
                val decisive = leadsToMate(mateAfter) || epAfter >= BRILLIANT_OVERWHELMING_EP
                // (b) hy sinh thường: chỉ khi "chưa thắng đậm nếu không tìm ra nước này" và hy sinh xong thế không xấu.
                val keyMove = alt < BRILLIANT_MAX_ALT_EP && epAfter >= BRILLIANT_MIN_EP_AFTER
                if (decisive || keyMove) return MoveLabel.BRILLIANT
            }
            if (playedBest && epSecondBest != null && epBefore - epSecondBest >= GREAT_MIN_GAP &&
                epBefore >= GREAT_MIN_EP && !isRecapture
            ) return MoveLabel.GREAT
            return MoveLabel.BEST
        }

        return labelByLoss(loss)
    }

    /**
     * Nước vừa đi đã chiếu hết (0) hoặc dẫn tới chiếu hết cưỡng bức cho chính mình (> 0). [mateAfter] theo góc nhìn BÊN VỪA ĐI.
     * Mate ÂM (mình sắp bị chiếu hết) và null (không có mate) không tính — chỉ kiểm "!= null" sẽ nhận nhầm cả nước tự dẫn vào thế bị mate.
     */
    fun leadsToMate(mateAfter: Int?): Boolean = mateAfter != null && mateAfter >= 0

    /** Nhãn chỉ theo loss (không ngữ cảnh). */
    fun labelByLoss(loss: Double): MoveLabel = when {
        loss <= EXCELLENT_MAX -> MoveLabel.EXCELLENT
        loss <= GOOD_MAX -> MoveLabel.GOOD
        loss <= INACCURACY_MAX -> MoveLabel.INACCURACY
        loss <= MISTAKE_MAX -> MoveLabel.MISTAKE
        else -> MoveLabel.BLUNDER
    }

    // ------------------------------------------------------------------ Luật mate (Lichess)

    /** Đi vào thế bị chiếu hết (trước đó chưa bị mate). [prevCp] = cp của bên đi trước nước đi. */
    fun mateCreatedFloor(prevCp: Int): Double = when {
        prevCp < -MATE_HUGE_ADVANTAGE_CP -> FLOOR_INACCURACY
        prevCp < -MATE_BIG_ADVANTAGE_CP -> FLOOR_MISTAKE
        else -> FLOOR_BLUNDER
    }

    /** Bỏ lỡ chiếu hết (đang có mate, thế sau không còn). [nextCp] = cp của bên đi sau nước đi. */
    fun mateLostFloor(nextCp: Int): Double = when {
        nextCp > MATE_HUGE_ADVANTAGE_CP -> FLOOR_INACCURACY
        nextCp > MATE_BIG_ADVANTAGE_CP -> FLOOR_MISTAKE
        else -> FLOOR_BLUNDER
    }

    /**
     * Sàn loss theo luật mate cho nước KHÔNG phải nước tốt nhất; 0 nếu không liên quan mate. Mọi tham số theo góc nhìn BÊN ĐI:
     * [mateBefore] (dương = sắp chiếu hết, âm = sắp bị chiếu hết), [mateAfter] (0 = vừa chiếu hết).
     */
    fun mateRuleFloor(mateBefore: Int?, cpBefore: Int, mateAfter: Int?, cpAfter: Int): Double = when {
        mateBefore != null && mateBefore > 0 && mateAfter != null && mateAfter < 0 -> FLOOR_BLUNDER
        mateBefore != null && mateBefore > 0 && mateAfter == null -> mateLostFloor(cpAfter)
        mateBefore == null && mateAfter != null && mateAfter < 0 -> mateCreatedFloor(cpBefore)
        else -> 0.0
    }

    // ------------------------------------------------------------------ Accuracy

    /** Độ chính xác (0–100) của một nước từ [epLoss] (phân số 0–1; công thức Lichess dùng điểm %, nên nhân 100 bên trong). */
    fun calculateAccuracy(epLoss: Double): Double =
        (ACC_A * exp(-ACC_K * max(0.0, epLoss) * 100.0) - ACC_B).coerceIn(0.0, 100.0)

    /** Độ chính xác cả ván của một bên = trung bình cộng accuracy các nước của bên đó. Không có nước nào = 100. */
    fun calculateGameAccuracy(epLosses: List<Double>): Double =
        if (epLosses.isEmpty()) 100.0 else epLosses.sumOf { calculateAccuracy(it) } / epLosses.size
}
