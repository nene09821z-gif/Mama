package com.vila.chess.auth

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

enum class AuthProvider { EMAIL, GOOGLE }

data class Account(val email: String, val name: String, val provider: AuthProvider)

/** Lưu tài khoản đang đăng nhập (SharedPreferences). `current` là state của Compose nên UI tự cập nhật. */
object AccountStore {
    private const val PREFS = "vila_account"
    var current: Account? by mutableStateOf(null)
        private set
    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val email = p.getString("email", null) ?: return
        current = Account(
            email = email,
            name = p.getString("name", "") ?: "",
            provider = runCatching { AuthProvider.valueOf(p.getString("provider", "EMAIL")!!) }.getOrDefault(AuthProvider.EMAIL),
        )
    }

    fun save(ctx: Context, a: Account) {
        // Đổi sang tài khoản khác: cất dữ liệu của tài khoản trước, nạp dữ liệu của tài khoản này (hoặc bắt đầu mới).
        runCatching { AccountData.onSignIn(ctx, a.email) }
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("email", a.email).putString("name", a.name).putString("provider", a.provider.name).commit()
        runCatching { com.vila.chess.profile.UserSessionManager.reload(ctx) }
        current = a
    }

    private val authScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun signOut(ctx: Context) {
        val app = ctx.applicationContext
        runCatching { AccountData.onSignOut(app, current?.email) }
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
        runCatching { com.vila.chess.cloud.SupabaseCloud.signOut(app) }
        runCatching { com.vila.chess.profile.UserSessionManager.clear(app) }
        // Quên phiên Google để lần sau không tự vào lại tài khoản cũ.
        authScope.launch {
            runCatching { CredentialManager.create(app).clearCredentialState(ClearCredentialStateRequest()) }
        }
        current = null
    }

    fun isValidEmail(s: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(s.trim()).matches()
}
