package com.vila.chess.review

/**
 * scoreCp/mate/secondCp/secondMate luôn tính theo góc nhìn BÊN ĐANG ĐI của FEN được phân tích.
 * pv = PV đầu tiên (UCI). second* chỉ có khi engine chạy MultiPV >= 2 và thế có từ 2 nước hợp lệ trở lên.
 * engine = "native" | "wasm" | "rules" (thế kết thúc ván, không cần engine).
 */
data class EngineResult(
    val bestMove: String?,
    val scoreCp: Int,
    val mate: Int?,
    val depthReached: Int,
    val timedOut: Boolean,
    val pv: List<String> = emptyList(),
    val secondMove: String? = null,
    val secondCp: Int? = null,
    val secondMate: Int? = null,
    val engine: String = "unknown",
    val multiPv: Int = 1,
)
