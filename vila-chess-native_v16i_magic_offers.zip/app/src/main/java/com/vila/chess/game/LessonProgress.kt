package com.vila.chess.game

// Thuần Kotlin (không Android) để test bằng JVM.

/** Trạng thái học: bài đã xong (mãi mãi) + bài đã bắt đầu TRONG NGÀY [day]. Bất biến, rất nhỏ. */
data class LessonProgress(
    val done: Set<String> = emptySet(),
    val day: String = "",
    val startedToday: Set<String> = emptySet(),
) {
    /** Sang ngày mới thì xóa danh sách bài đã bắt đầu (làm mới lượt); không đổi ngày thì giữ nguyên. */
    fun rolled(today: String): LessonProgress =
        if (day == today) this else copy(day = today, startedToday = emptySet())

    fun withStarted(id: String): LessonProgress = copy(startedToday = startedToday + id)
    fun withDone(id: String): LessonProgress = copy(done = done + id)
}

/** Mã hóa/giải mã tiến độ thành chuỗi ngắn để lưu SharedPreferences (id chỉ gồm a-z, 0-9, _). */
object LessonProgressCodec {
    fun encode(ids: Set<String>): String = ids.joinToString(",")
    fun decode(raw: String?): Set<String> =
        if (raw.isNullOrEmpty()) emptySet() else raw.split(',').filter { it.isNotEmpty() }.toSet()
}
