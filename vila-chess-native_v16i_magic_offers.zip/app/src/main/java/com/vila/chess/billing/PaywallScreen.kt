package com.vila.chess.billing

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.ui.Benefit25D
import com.vila.chess.ui.BenefitKind
import com.vila.chess.ui.CheckMark
import com.vila.chess.ui.MembershipBadge
import com.vila.chess.ui.TierGem
import com.vila.chess.ui.VilaColors
import java.text.NumberFormat
import java.util.Currency

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ---- Bảng màu theo ảnh chess.com: viền thẻ + màu nhấn từng gói ----
private val CardPanel = Color(0xFF3B3836)
private val PageBg = Color(0xFF262421)

private fun accent(t: MembershipTier): Color = when (t) {
    MembershipTier.GOLD -> Color(0xFFE5A823)
    MembershipTier.PLATINUM -> Color(0xFF7FA6D1)
    MembershipTier.DIAMOND -> Color(0xFF1AA0E6)
    MembershipTier.FAMILY -> Color(0xFF7CB342)
    MembershipTier.FREE -> VilaColors.Green
}

@Composable
fun PaywallScreen(onBack: () -> Unit, vm: PaywallViewModel = viewModel()) {
    val state by vm.ui.collectAsState()
    val ctx = LocalContext.current
    // null = đóng; Pair(gói, null-gói = chỉ nhập mã)
    var manual by remember { mutableStateOf<Pair<MembershipTier?, Boolean>?>(null) }
    var adminTaps by remember { mutableStateOf(0) }
    var showAdmin by remember { mutableStateOf(false) }
    if (showAdmin) AdminDialog(onDismiss = { showAdmin = false })
    manual?.let { (t, _) ->
        val period = if (t != null && BillingCatalog.yearlyOnly(t)) BillingPeriod.YEARLY else state.period
        ManualPayDialog(tier = t, period = period, onDismiss = { manual = null }, onRedeem = vm::redeem)
    }
    state.unlocked?.let { UnlockedDialog(it, onDismiss = vm::dismissUnlocked) }

    // Thứ tự giống ảnh mẫu: Gold, Platinum, Diamond, Family
    val tiers = remember(state.tiers) { state.tiers.sortedBy { tierOrder(it.tier) } }
    val pager = rememberPagerState(initialPage = 0) { tiers.size.coerceAtLeast(1) }
    val scope = rememberCoroutineScope()
    // Mở đúng trang gói đang dùng (nếu có) một lần khi danh sách gói đã sẵn sàng.
    LaunchedEffect(tiers.size) {
        val cur = tiers.indexOfFirst { it.tier == state.currentTier }
        val idx = if (cur >= 0) cur else tiers.indexOfFirst { it.tier == MembershipTier.DIAMOND }
        if (idx > 0) pager.scrollToPage(idx)
    }
    LaunchedEffect(pager.currentPage, tiers.size) {
        tiers.getOrNull(pager.currentPage)?.let { vm.selectTier(it.tier) }
    }

    Column(modifier = Modifier.fillMaxSize().background(PageBg).statusBarsPadding().navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().height(40.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color(0xFFBDBDBD))
            }
        }
        Text(
            "Chọn gói thành viên", color = Color.White, fontSize = 24.sp, lineHeight = 28.sp,
            fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                .clickable { adminTaps++; if (adminTaps >= 7) { adminTaps = 0; showAdmin = true } },   // bấm 7 lần → admin
        )
        Spacer(Modifier.height(8.dp))

        state.error?.let { Banner(it.message(), isError = true, onClose = vm::dismissMessage) }
        state.notice?.let { Banner(it, isError = false, onClose = vm::dismissMessage) }

        when {
            state.isLoading -> Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) {
                CircularProgressIndicator(color = VilaColors.Green)
            }
            tiers.isEmpty() -> Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp), Alignment.Center) {
                Button(onClick = vm::reload) { Text("Thử lại") }
            }
            else -> {
                TierTabs(
                    tiers = tiers.map { it.tier },
                    selected = pager.currentPage.coerceIn(0, tiers.lastIndex),
                    onSelect = { i -> scope.launch { pager.animateScrollToPage(i) } },
                )
                Spacer(Modifier.height(10.dp))
                // Thẻ gói chiếm toàn bộ phần còn lại của màn hình: giá + nút mua luôn nằm ngay trong tầm nhìn.
                HorizontalPager(
                    state = pager,
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    pageSpacing = 10.dp,
                    verticalAlignment = Alignment.Top,
                ) { page ->
                    val plans = tiers[page]
                    TierPage(
                        plans = plans,
                        period = if (BillingCatalog.yearlyOnly(plans.tier)) BillingPeriod.YEARLY else state.period,
                        isCurrent = plans.tier == state.currentTier,
                        busy = state.isPurchasing,
                        onPeriod = vm::setPeriod,
                        onBuy = { ctx.findActivity()?.let { vm.purchase(it, plans.tier) } },
                        onManual = { manual = plans.tier to true },
                    )
                }
            }
        }

        // Hàng liên kết phụ gọn một dòng + ghi chú thanh toán
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = { manual = null to false }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(32.dp)) {
                Text("Nhập mã kích hoạt", color = VilaColors.Green, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
            if (tiers.isNotEmpty() && !state.isLoading) {
                val cur = tiers[pager.currentPage.coerceIn(0, tiers.lastIndex)]
                if (cur.tier != state.currentTier) {
                    TextButton(onClick = { manual = cur.tier to true }, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(32.dp)) {
                        Text("Thanh toán chuyển khoản", color = Color(0xFFE3ECFA), fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
            TextButton(onClick = vm::restore, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp), modifier = Modifier.height(32.dp)) {
                Text("Khôi phục", color = Color(0xFFE3ECFA), fontSize = 12.sp, maxLines = 1)
            }
        }
        Text(
            "Google Play tự gia hạn đến khi bạn hủy (Google Play › Thanh toán & gói đăng ký). Chuyển khoản: có thời hạn, không tự gia hạn.",
            color = VilaColors.TextDim, fontSize = 10.sp, lineHeight = 13.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 0.dp, bottom = 6.dp),
        )
    }
}

private fun tierOrder(t: MembershipTier): Int = when (t) {
    MembershipTier.GOLD -> 0
    MembershipTier.PLATINUM -> 1
    MembershipTier.DIAMOND -> 2
    MembershipTier.FAMILY -> 3
    MembershipTier.FREE -> 4
}

// ------------------------------------------------------------------ Một trang gói (huy hiệu động nằm đè lên mép thẻ)

@Composable
private fun TierPage(
    plans: TierPlans,
    period: BillingPeriod,
    isCurrent: Boolean,
    busy: Boolean,
    onPeriod: (BillingPeriod) -> Unit,
    onBuy: () -> Unit,
    onManual: () -> Unit,
) {
    val tier = plans.tier
    val color = accent(tier)
    val option = plans.option(period)
    val badgeSize = 58.dp

    Box(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = badgeSize / 2)
                .clip(RoundedCornerShape(24.dp))
                .background(CardPanel)
                .border3(color)
                .padding(start = 16.dp, end = 16.dp, top = badgeSize / 2 + 2.dp, bottom = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(tier.displayName, color = Color.White, fontSize = 25.sp, lineHeight = 28.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            if (isCurrent) Chip("GÓI HIỆN TẠI", VilaColors.Green)
            else if (tier == MembershipTier.DIAMOND) Chip("PHỔ BIẾN NHẤT", color)
            else if (tier == MembershipTier.FAMILY) Chip("TIẾT KIỆM ĐẾN ${familySavePct()}%", color)

            if (tier == MembershipTier.FAMILY) {
                Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Benefit25D(BenefitKind.FAMILY, Modifier.size(24.dp))
                    Text("2–6 thành viên", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                saveAmount(plans)?.let { amount ->
                    Text(
                        buildAnnotatedString {
                            append("Tiết kiệm ")
                            withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold)) { append(amount) }
                            append(" với Gói Hàng Năm")
                        },
                        color = Color(0xFFE6E4E1), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 3.dp),
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            val lines = TierInfo.featureLines(tier)
            val common = TierInfo.featureLines(MembershipTier.GOLD)
            val exclusive = lines.filterNot { it in common }
            val included = lines.filter { it in common }
            // Danh sách quyền lợi cuộn được (phòng khi màn hình thấp); giá + nút mua ghim cố định bên dưới.
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
            ) {
                if (exclusive.isNotEmpty()) {
                    SectionLabel("ĐỘC QUYỀN " + tier.displayName.uppercase(), color)
                    exclusive.forEach { line -> FeatureRow(line, color) }
                    SectionLabel("BAO GỒM TRONG MỌI GÓI", Color(0xFF9A9691))
                }
                included.forEach { line -> FeatureRow(line, color) }
            }

            Spacer(Modifier.height(8.dp))
            PriceBlock(plans, period, color)

            if (BillingCatalog.yearlyOnly(tier)) {
                Box(Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF4A4745)).padding(horizontal = 14.dp, vertical = 5.dp)) {
                    Text("CHỈ BÁN GÓI NĂM", color = Color(0xFFD0D0D0), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
            } else {
                PeriodSwitch(period, onPeriod)
            }

            Spacer(Modifier.height(10.dp))
            BuyButton(
                label = if (isCurrent) "Đang sử dụng" else "Chọn gói " + tier.displayName,
                enabled = !busy && !isCurrent,
                onClick = { if (option != null) onBuy() else onManual() },
            )
        }
        // Huy hiệu động đè lên mép trên của thẻ
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
            MembershipBadge(tier, size = badgeSize)
        }
    }
}

private fun Modifier.border3(color: Color): Modifier = this.border(BorderStroke(2.5.dp, color), RoundedCornerShape(24.dp))

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier.padding(top = 4.dp).clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.22f))
            .padding(horizontal = 11.dp, vertical = 3.dp),
    ) {
        Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun FeatureRow(text: String, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Benefit25D(featureKind(text), Modifier.size(30.dp))
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, lineHeight = 17.sp, modifier = Modifier.weight(1f))
        CheckMark(tint, Modifier.size(15.dp))
    }
}

@Composable
private fun SectionLabel(text: String, color: Color) {
    Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp, modifier = Modifier.padding(top = 2.dp))
}

private fun featureKind(text: String): BenefitKind = when {
    text.contains("Xem lại") -> BenefitKind.REVIEW
    text.contains("Giải thích") -> BenefitKind.EXPLAIN
    text.contains("Thống kê") -> BenefitKind.STATS
    text.contains("câu đố") -> BenefitKind.PUZZLE
    text.contains("bài học") -> BenefitKind.LEARN
    text.contains("huấn luyện") -> BenefitKind.COACH
    text.contains("bot") -> BenefitKind.BOT
    text.contains("quảng cáo", ignoreCase = true) -> BenefitKind.NOADS
    else -> BenefitKind.REVIEW
}

/** Thanh tab gói thành viên: bấm để lướt tới trang gói, đồng bộ với vuốt ngang. */
@Composable
private fun TierTabs(tiers: List<MembershipTier>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF2F2D2A)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        tiers.forEachIndexed { i, t ->
            val on = i == selected
            Row(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(14.dp))
                    .background(if (on) Color(0xFF3B3836) else Color.Transparent)
                    .then(if (on) Modifier.border(BorderStroke(2.dp, accent(t)), RoundedCornerShape(14.dp)) else Modifier)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TierGem(accent(t), Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    t.displayName, color = if (on) Color.White else Color(0xFF9A9691),
                    fontSize = 12.5.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false,
                )
            }
        }
    }
}

@Composable
private fun PriceBlock(plans: TierPlans, period: BillingPeriod, color: Color) {
    val tier = plans.tier
    val yearly = period == BillingPeriod.YEARLY
    val perMonth = if (yearly) perMonthFromYearly(plans) else (plans.monthly?.formattedPrice ?: formatVnd(BillingCatalog.priceVnd(tier, BillingPeriod.MONTHLY)))
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            buildAnnotatedString {
                append(perMonth)
                withStyle(SpanStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFFBDBAB6))) { append(" / tháng") }
            },
            color = if (tier == MembershipTier.FAMILY) Color(0xFF4FC3F7) else Color.White,
            fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
        )
        if (yearly) {
            val total = plans.yearly?.formattedPrice ?: formatVnd(BillingCatalog.priceVnd(tier, BillingPeriod.YEARLY))
            Text("12 tháng · $total", color = Color(0xFFBDBAB6), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun PeriodSwitch(period: BillingPeriod, onChange: (BillingPeriod) -> Unit) {
    Row(
        modifier = Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF2B2927)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        listOf(BillingPeriod.YEARLY to "Hàng năm", BillingPeriod.MONTHLY to "Hàng tháng").forEach { (p, label) ->
            val on = p == period
            Box(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (on) Color(0xFF45423F) else Color.Transparent)
                    .clickable { onChange(p) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (on) Color.White else Color(0xFF8E8A86), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun BuyButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    val top = if (enabled) Color(0xFF2AAEF3) else Color(0xFF55616B)
    val bottom = if (enabled) Color(0xFF0A86D6) else Color(0xFF47515A)
    Box(
        modifier = Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.verticalGradient(listOf(top, bottom)))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun Banner(text: String, isError: Boolean, onClose: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp))
            .background(if (isError) Color(0x33E05A47) else Color(0x3381B64C))
            .clickable(onClick = onClose).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
    }
}

// ------------------------------------------------------------------ Hộp chúc mừng: huy hiệu bật ra khi vừa mua / kích hoạt xong

@Composable
private fun UnlockedDialog(tier: MembershipTier, onDismiss: () -> Unit) {
    val pop = remember { Animatable(0.2f) }
    LaunchedEffect(tier) { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(CardPanel)
                .border3(accent(tier)).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(Modifier.scale(pop.value)) { MembershipBadge(tier, size = 128.dp) }
            Spacer(Modifier.height(10.dp))
            Text("Chúc mừng!", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Bạn đã mở khóa huy hiệu " + tier.displayName + ". Huy hiệu sẽ hiện cạnh tên của bạn trong hồ sơ, ván đấu và bảng xếp hạng.",
                color = Color(0xFFE3ECFA), fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
            )
            BuyButton(label = "Tuyệt vời!", enabled = true, onClick = onDismiss)
        }
    }
}

// ------------------------------------------------------------------ Giá

private fun familySavePct(): Int {
    val fam = BillingCatalog.priceVnd(MembershipTier.FAMILY, BillingPeriod.YEARLY).toDouble()
    val six = 6.0 * BillingCatalog.priceVnd(MembershipTier.DIAMOND, BillingPeriod.YEARLY)
    return if (six <= 0.0) 0 else (100.0 - fam * 100.0 / six).toInt().coerceIn(0, 99)
}

private fun perMonthFromYearly(plans: TierPlans): String {
    val y = plans.yearly
    if (y != null) {
        try {
            val fmt = NumberFormat.getCurrencyInstance().apply { currency = Currency.getInstance(y.currencyCode) }
            return fmt.format(y.priceMicros / 12_000_000.0)
        } catch (_: Exception) {
        }
    }
    return formatVnd(BillingCatalog.priceVnd(plans.tier, BillingPeriod.YEARLY) / 12)
}

/** Số tiền tiết kiệm khi chọn gói năm (đã định dạng); null nếu không có số liệu. */
private fun saveAmount(plans: TierPlans): String? {
    val m = plans.monthly
    val y = plans.yearly
    if (m != null && y != null && m.currencyCode == y.currencyCode) {
        val diff = m.priceMicros * 12 - y.priceMicros
        if (diff > 0) {
            try {
                val fmt = NumberFormat.getCurrencyInstance().apply { currency = Currency.getInstance(y.currencyCode) }
                return fmt.format(diff / 1_000_000.0)
            } catch (_: Exception) {
            }
        }
    }
    val mv = BillingCatalog.priceVnd(plans.tier, BillingPeriod.MONTHLY)
    val yv = BillingCatalog.priceVnd(plans.tier, BillingPeriod.YEARLY)
    val diff = mv * 12 - yv
    return if (mv > 0 && diff > 0) formatVnd(diff) else null
}
