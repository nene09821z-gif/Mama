package com.vila.chess.profile

import android.content.Context
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import org.json.JSONArray
import org.json.JSONObject

/**
 * Đọc/ghi hồ sơ + bạn bè trên Supabase (bảng `users`, `friendships` — xem supabase/schema.sql).
 * Mọi hàm trả [Result] với [ProfileException] đã phân loại để UI hiện đúng thông báo; KHÔNG ném lỗi ra ngoài.
 */
object ProfileRepository {
    private val UUID_RE = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")

    private const val COLS =
        "id,display_name,avatar_key,country_code,tier,bullet_elo,blitz_elo,rapid_elo," +
            "games_played,wins,draws,losses,result_streak,elo_history"

    /** Số mốc Elo tối đa của mỗi thể loại gửi lên cloud (giữ dòng `users` nhỏ). */
    private const val CLOUD_HISTORY_CAP = 120

    fun isValidUserId(id: String): Boolean = UUID_RE.matches(id.trim())

    // ------------------------------------------------------------------ Hồ sơ người chơi khác

    /** Lấy hồ sơ công khai theo userId (dùng cho OpponentProfileSheet và hồ sơ đầy đủ của đối thủ). */
    suspend fun fetchProfile(ctx: Context, userId: String): Result<UserProfile> {
        val id = userId.trim()
        if (!isValidUserId(id)) return Result.failure(ProfileException(ProfileError.INVALID_ID))
        return SupabaseCloud.restCall(ctx, "GET", "/rest/v1/users?id=eq.$id&select=$COLS&limit=1").mapCatching { text ->
            val arr = JSONArray(text)
            if (arr.length() == 0) throw ProfileException(ProfileError.NOT_FOUND)
            parseProfile(arr.getJSONObject(0))
        }.recoverParse()
    }

    // ------------------------------------------------------------------ Hồ sơ của mình

    /**
     * Đẩy hồ sơ của mình lên cloud (upsert theo id). Gọi sau mỗi ván, khi đổi hồ sơ và khi [UserProfile.tier] đổi (mua gói).
     * Chưa đăng nhập Supabase (chưa đăng nhập) → trả lỗi NOT_SIGNED_IN, KHÔNG phải sự cố: hồ sơ vẫn đầy đủ trong máy.
     */
    suspend fun pushMyProfile(ctx: Context, p: UserProfile): Result<Unit> {
        val uid = SupabaseCloud.userId(ctx) ?: return Result.failure(ProfileException(ProfileError.NOT_SIGNED_IN))
        val body = JSONObject()
            .put("id", uid)
            .put("display_name", p.displayName)
            .put("avatar_key", p.avatarKey)
            .put("country_code", p.countryCode)
            .put("tier", p.tier.id)
            .put("bullet_elo", p.bullet)
            .put("blitz_elo", p.blitz)
            .put("rapid_elo", p.rapid)
            .put("games_played", p.played)
            .put("wins", p.won)
            .put("draws", p.drawn)
            .put("losses", p.lost)
            .put("result_streak", p.resultStreak)
            .put("elo_history", historyToJson(p.eloHistory))
            .toString()
        return SupabaseCloud.restCall(
            ctx, "POST", "/rest/v1/users?on_conflict=id", body, prefer = "resolution=merge-duplicates,return=minimal",
        ).map { }
    }

    // ------------------------------------------------------------------ Bạn bè

    suspend fun fetchFriends(ctx: Context): Result<List<UserProfile>> =
        SupabaseCloud.restCall(
            ctx, "GET", "/rest/v1/friendships?select=friend:users!friend_id($COLS)&order=created_at.desc&limit=200",
        ).mapCatching { text ->
            val arr = JSONArray(text)
            (0 until arr.length()).mapNotNull { i -> arr.getJSONObject(i).optJSONObject("friend")?.let(::parseProfile) }
        }.recoverParse()

    /** Thêm bạn theo ID. ID không tồn tại (vi phạm khóa ngoại → HTTP 409) được đổi thành NOT_FOUND. */
    suspend fun addFriend(ctx: Context, friendId: String): Result<Unit> {
        val id = friendId.trim()
        if (!isValidUserId(id)) return Result.failure(ProfileException(ProfileError.INVALID_ID))
        if (id.equals(SupabaseCloud.userId(ctx), ignoreCase = true)) return Result.failure(ProfileException(ProfileError.INVALID_ID, "self"))
        val r = SupabaseCloud.restCall(
            ctx, "POST", "/rest/v1/friendships?on_conflict=user_id,friend_id",
            JSONObject().put("friend_id", id).toString(), prefer = "resolution=ignore-duplicates,return=minimal",
        ).map { }
        val ex = r.exceptionOrNull() as? ProfileException
        return if (ex != null && ex.kind == ProfileError.SERVER && ex.message == "HTTP 409") {
            Result.failure(ProfileException(ProfileError.NOT_FOUND))
        } else r
    }

    suspend fun removeFriend(ctx: Context, friendId: String): Result<Unit> {
        val id = friendId.trim()
        if (!isValidUserId(id)) return Result.failure(ProfileException(ProfileError.INVALID_ID))
        return SupabaseCloud.restCall(ctx, "DELETE", "/rest/v1/friendships?friend_id=eq.$id").map { }
    }

    // ------------------------------------------------------------------ JSON

    private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key, "")

    internal fun parseProfile(o: JSONObject): UserProfile = UserProfile(
        userId = o.getString("id"),
        displayName = o.str("display_name").ifBlank { "Người chơi" },
        avatarKey = o.str("avatar_key"),
        countryCode = o.str("country_code"),
        tier = MembershipTier.fromId(o.str("tier")),
        bullet = o.optInt("bullet_elo", DEFAULT_ELO),
        blitz = o.optInt("blitz_elo", DEFAULT_ELO),
        rapid = o.optInt("rapid_elo", DEFAULT_ELO),
        played = o.optInt("games_played", 0),
        won = o.optInt("wins", 0),
        drawn = o.optInt("draws", 0),
        lost = o.optInt("losses", 0),
        resultStreak = o.optInt("result_streak", 0),
        eloHistory = parseHistory(o.optJSONObject("elo_history")),
    )

    private fun parseHistory(o: JSONObject?): Map<EloMode, List<EloPoint>> {
        if (o == null) return emptyMap()
        val out = HashMap<EloMode, List<EloPoint>>()
        for (mode in EloMode.values()) {
            val arr = o.optJSONArray(mode.key) ?: continue
            val pts = ArrayList<EloPoint>(arr.length())
            for (i in 0 until arr.length()) {
                val pair = arr.optJSONArray(i) ?: continue
                if (pair.length() >= 2) pts.add(EloPoint(pair.optLong(0), pair.optInt(1)))
            }
            out[mode] = pts
        }
        return out
    }

    private fun historyToJson(h: Map<EloMode, List<EloPoint>>): JSONObject {
        val o = JSONObject()
        for (mode in EloMode.values()) {
            val arr = JSONArray()
            for (p in (h[mode] ?: emptyList()).takeLast(CLOUD_HISTORY_CAP)) arr.put(JSONArray().put(p.ts).put(p.rating))
            o.put(mode.key, arr)
        }
        return o
    }

    /** Lỗi parse JSON (dữ liệu server lạ) → SERVER thay vì để lọt JSONException ra UI. */
    private fun <T> Result<T>.recoverParse(): Result<T> {
        val ex = exceptionOrNull() ?: return this
        return if (ex is ProfileException) this else Result.failure(ProfileException(ProfileError.SERVER, ex.message))
    }
}
