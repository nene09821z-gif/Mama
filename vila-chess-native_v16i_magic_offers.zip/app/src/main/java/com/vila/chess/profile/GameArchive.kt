package com.vila.chess.profile

import android.content.Context
import com.vila.chess.core.START_FEN
import com.vila.chess.review.GameReviewStore
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Một ván đã chơi, lưu đủ nước đi để xem lại / phân tích bất cứ lúc nào.
 * [score]: 1.0 thắng, 0.5 hòa, 0.0 thua theo góc nhìn của bạn; -1.0 = ván 2 người (không có "bạn").
 * [outcome]: WHITE_WINS | BLACK_WINS | DRAW.
 */
data class ArchivedGame(
    val id: String,
    val ts: Long,
    val opponent: String,
    val score: Double,
    val modeName: String,
    val timeLabel: String,
    val delta: Int,
    val moves: Int,
    val humanWhite: Boolean?,
    val startFen: String,
    val ucis: List<String>,
    val reason: String,
    val outcome: String,
)

/** Ảnh chụp để vẽ màn danh sách: toàn bộ ván (mới nhất trước) + tập id đã có kết quả phân tích. */
class ArchiveSnapshot(val games: List<ArchivedGame>, val reviewed: Set<String>)

/**
 * Kho ván đấu: lưu được hàng nghìn ván (tối đa [MAX_GAMES]).
 *
 * Thiết kế cho nhiều dữ liệu:
 *  - Một file JSON-lines (mỗi ván một dòng): thêm ván mới = GHI NỐI một dòng, không đọc/ghi lại cả kho
 *    (khác SharedPreferences phải nạp và ghi lại toàn bộ chuỗi mỗi lần).
 *  - Mọi thao tác file chạy ngoài luồng chính (ghi trên một luồng riêng, đọc ở Dispatchers.IO).
 *  - Quá [MAX_GAMES] thì tự dọn các ván cũ nhất (kèm file phân tích của chúng).
 */
object GameArchive {
    const val MAX_GAMES = 5000
    private const val SLACK = 100
    private const val FILE = "game_archive.jsonl"
    private const val PAID_PREFS = "vila_archive_paid"

    private val lock = Any()
    private var count = -1
    private val writer = Executors.newSingleThreadExecutor { r -> Thread(r, "vila-archive").apply { isDaemon = true } }

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, FILE)

    // ------------------------------------------------------------------ ghi

    /** Thêm một ván (không chặn luồng gọi). */
    fun add(ctx: Context, g: ArchivedGame) {
        val app = ctx.applicationContext
        val line = encode(g)
        writer.execute {
            runCatching {
                synchronized(lock) {
                    val f = file(app)
                    if (count < 0) count = if (f.exists()) f.useLines { seq -> seq.count { it.isNotBlank() } } else 0
                    f.appendText(line + "\n")
                    count++
                    if (count > MAX_GAMES + SLACK) compact(app, f)
                }
            }
        }
    }

    /** Xóa một ván khỏi kho (và file phân tích của nó). Gọi từ luồng nền. */
    fun delete(ctx: Context, id: String) {
        val app = ctx.applicationContext
        synchronized(lock) {
            val f = file(app)
            if (f.exists()) {
                val keep = ArrayList<String>()
                f.forEachLine { l ->
                    if (l.isNotBlank() && runCatching { JSONObject(l).optString("id") }.getOrNull() != id) keep.add(l)
                }
                rewrite(f, keep)
                count = keep.size
            }
            unpay(app, id)
        }
        GameReviewStore(app).delete(id)
    }

    private fun compact(app: Context, f: File) {
        val lines = f.readLines().filter { it.isNotBlank() }
        val dropped = lines.size - MAX_GAMES
        if (dropped <= 0) { count = lines.size; return }
        val store = GameReviewStore(app)
        for (l in lines.take(dropped)) {
            runCatching { JSONObject(l).optString("id") }.getOrNull()?.takeIf { it.isNotEmpty() }?.let {
                store.delete(it)
                unpay(app, it)
            }
        }
        val keep = lines.drop(dropped)
        rewrite(f, keep)
        count = keep.size
    }

    private fun rewrite(f: File, lines: List<String>) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.bufferedWriter().use { w -> for (l in lines) { w.write(l); w.write("\n") } }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    // ------------------------------------------------------------------ đọc

    /** Gọi từ Dispatchers.IO. Mới nhất trước. Dòng hỏng bị bỏ qua, không làm hỏng cả kho. */
    fun snapshot(ctx: Context): ArchiveSnapshot {
        val app = ctx.applicationContext
        val games = ArrayList<ArchivedGame>()
        synchronized(lock) {
            val f = file(app)
            if (f.exists()) f.forEachLine { l -> if (l.isNotBlank()) decode(l)?.let { games.add(it) } }
        }
        games.reverse()
        return ArchiveSnapshot(games, GameReviewStore(app).ids())
    }

    // ------------------------------------------------------------------ lượt Game Review đã trả

    fun isPaid(ctx: Context, id: String): Boolean =
        ctx.applicationContext.getSharedPreferences(PAID_PREFS, Context.MODE_PRIVATE).getStringSet("ids", emptySet())?.contains(id) == true

    fun markPaid(ctx: Context, id: String) {
        val p = ctx.applicationContext.getSharedPreferences(PAID_PREFS, Context.MODE_PRIVATE)
        synchronized(lock) {
            val set = HashSet(p.getStringSet("ids", emptySet()) ?: emptySet())
            if (set.add(id)) p.edit().putStringSet("ids", set).apply()
        }
    }

    private fun unpay(ctx: Context, id: String) {
        val p = ctx.applicationContext.getSharedPreferences(PAID_PREFS, Context.MODE_PRIVATE)
        val set = HashSet(p.getStringSet("ids", emptySet()) ?: emptySet())
        if (set.remove(id)) p.edit().putStringSet("ids", set).apply()
    }

    // ------------------------------------------------------------------ JSON

    internal fun encode(g: ArchivedGame): String {
        val o = JSONObject()
        o.put("id", g.id).put("ts", g.ts).put("opp", g.opponent).put("score", g.score)
            .put("mode", g.modeName).put("tc", g.timeLabel).put("delta", g.delta).put("n", g.moves)
            .put("w", when (g.humanWhite) { true -> 1; false -> 0; null -> -1 })
            .put("u", g.ucis.joinToString(" ")).put("r", g.reason).put("o", g.outcome)
        if (g.startFen != START_FEN) o.put("fen", g.startFen)
        return o.toString()
    }

    internal fun decode(line: String): ArchivedGame? = try {
        val o = JSONObject(line)
        val u = o.optString("u", "")
        val ucis = if (u.isBlank()) emptyList() else u.split(' ')
        ArchivedGame(
            id = o.getString("id"),
            ts = o.optLong("ts"),
            opponent = o.optString("opp", "?"),
            score = o.optDouble("score", -1.0),
            modeName = o.optString("mode", ""),
            timeLabel = o.optString("tc", ""),
            delta = o.optInt("delta", 0),
            moves = o.optInt("n", ucis.size),
            humanWhite = when (o.optInt("w", -1)) { 1 -> true; 0 -> false; else -> null },
            startFen = o.optString("fen", START_FEN),
            ucis = ucis,
            reason = o.optString("r", ""),
            outcome = o.optString("o", ""),
        )
    } catch (_: Exception) {
        null
    }
}
