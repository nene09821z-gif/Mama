package com.vila.chess.game

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Lưu tiến độ bài học (SharedPreferences, vài trăm byte) và phát StateFlow cho UI.
 * Không tạo đối tượng nặng; mỗi thay đổi chỉ ghi 3 chuỗi nhỏ bằng apply() (bất đồng bộ).
 */
class LessonStore private constructor(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_lessons", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        LessonProgress(
            done = LessonProgressCodec.decode(prefs.getString("done", null)),
            day = prefs.getString("day", "") ?: "",
            startedToday = LessonProgressCodec.decode(prefs.getString("started", null)),
        ).rolled(LessonQuota.dayKey(System.currentTimeMillis()))
    )
    val state: StateFlow<LessonProgress> = _state.asStateFlow()

    private fun commit(next: LessonProgress) {
        _state.value = next
        prefs.edit()
            .putString("done", LessonProgressCodec.encode(next.done))
            .putString("day", next.day)
            .putString("started", LessonProgressCodec.encode(next.startedToday))
            .apply()
    }

    /** Gọi khi mở màn / khi đồng hồ qua 0h để lượt trong ngày tự làm mới. */
    @Synchronized
    fun refreshDay() {
        val cur = _state.value
        val next = cur.rolled(LessonQuota.dayKey(System.currentTimeMillis()))
        if (next !== cur) commit(next)
    }

    /**
     * Đăng ký bắt đầu một bài. Trả về false (không ghi gì) nếu hôm nay đã hết lượt.
     * [limit] = null nghĩa là không giới hạn.
     */
    @Synchronized
    fun tryStart(lessonId: String, limit: Int?): Boolean {
        val cur = _state.value.rolled(LessonQuota.dayKey(System.currentTimeMillis()))
        if (!LessonQuota.canStart(limit, cur.startedToday, lessonId)) {
            if (cur !== _state.value) commit(cur)
            return false
        }
        commit(if (lessonId in cur.startedToday) cur else cur.withStarted(lessonId))
        return true
    }

    @Synchronized
    fun complete(lessonId: String) {
        val cur = _state.value.rolled(LessonQuota.dayKey(System.currentTimeMillis()))
        if (lessonId in cur.done) {
            if (cur !== _state.value) commit(cur)
        } else {
            commit(cur.withDone(lessonId))
        }
    }

    companion object {
        @Volatile private var instance: LessonStore? = null
        fun get(context: Context): LessonStore =
            instance ?: synchronized(this) { instance ?: LessonStore(context).also { instance = it } }
    }
}
