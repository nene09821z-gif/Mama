package com.vila.chess.game

import android.content.Context

data class SoundPackInfo(val id: String, val label: String, val desc: String)

/**
 * Các bộ âm thanh. "classic" = move/capture/castle/check/promote/gameend có sẵn; các bộ khác = res/raw/<id>_<tiếng>.wav
 * (tạo bằng scripts/gen_sounds.py). Tìm file bằng tên (getIdentifier) nên thêm bộ mới chỉ cần thêm file + 1 dòng ở [all].
 */
object SoundPacks {
    const val DEFAULT = "classic"

    val all: List<SoundPackInfo> = listOf(
        SoundPackInfo("classic", "Cổ điển", "Tiếng cờ gỗ quen thuộc"),
        SoundPackInfo("wood", "Gỗ", "Cộc cộc ấm, như quân cờ thật trên bàn gỗ"),
        SoundPackInfo("glass", "Pha lê", "Chuông thủy tinh trong trẻo"),
        SoundPackInfo("piano", "Piano mềm", "Nốt piano nhẹ nhàng, dễ chịu"),
        SoundPackInfo("arcade", "Arcade 8-bit", "Bíp bíp máy chơi game đời đầu"),
        SoundPackInfo("drum", "Trống", "Trống, snare và tom mạnh mẽ"),
        SoundPackInfo("water", "Giọt nước", "Tiếng bong bóng nước vui tai"),
    )

    fun exists(id: String): Boolean = all.any { it.id == id }

    /** Tên file (không đuôi) trong res/raw. */
    fun rawName(pack: String, sfx: Sfx): String {
        if (pack == DEFAULT) {
            return when (sfx) {
                Sfx.MOVE -> "move"
                Sfx.CAPTURE -> "capture"
                Sfx.CASTLE -> "castle"
                Sfx.CHECK -> "check"
                Sfx.PROMOTE -> "promote"
                Sfx.END -> "gameend"
            }
        }
        return pack + "_" + sfx.name.lowercase()
    }

    /** id tài nguyên raw của tiếng [sfx] trong bộ [pack]; thiếu file thì rơi về bộ Cổ điển. 0 nếu cả hai đều thiếu. */
    fun rawRes(context: Context, pack: String, sfx: Sfx): Int {
        val res = context.resources
        val id = res.getIdentifier(rawName(pack, sfx), "raw", context.packageName)
        if (id != 0 || pack == DEFAULT) return id
        return res.getIdentifier(rawName(DEFAULT, sfx), "raw", context.packageName)
    }
}
