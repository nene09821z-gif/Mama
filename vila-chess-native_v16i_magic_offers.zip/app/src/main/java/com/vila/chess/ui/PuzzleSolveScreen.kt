package com.vila.chess.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.core.moveFrom
import com.vila.chess.core.moveTo
import com.vila.chess.game.Puzzle
import com.vila.chess.game.PuzzleRepository
import com.vila.chess.game.PuzzleSession
import com.vila.chess.game.PuzzleStep
import com.vila.chess.game.puzzleGoalText
import com.vila.chess.game.puzzleSideName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ════════════════════════════════════════════════════════════════════════════════════════════
//  MÀN HÌNH GIẢI ĐỐ
//
//  Dòng chảy dữ liệu:  puzzles.db (hoặc BuiltInPuzzles) → Puzzle(fen, moves) → PuzzleSession → Position.fromFen
//                       → IntArray(64) board → Canvas vẽ quân. Bàn cờ luôn có quân vì dữ liệu đi qua đúng 1 đường này.
//
//  Quy ước Lichess: moves[0] là nước của ĐỐI THỦ (chạy animation lúc mở màn), người chơi đi từ moves[1].
//  Thả quân đúng nước (hoặc bất kỳ nước chiếu hết) ⇒ đối thủ tự đáp; sai ⇒ quân lắc + rung nhẹ.
//
//  Hiệu năng: vị trí quân đang kéo / animation trượt / lắc đều là Animatable hoặc State chỉ được đọc trong
//  draw / graphicsLayer ⇒ không recomposition trong lúc kéo.
// ════════════════════════════════════════════════════════════════════════════════════════════

private val ScreenBg = Color(0xFF262421)
private val CardBg = Color(0xFF302E2B)
private val OkGreen = Color(0xFF81B64C)
private val BadRed = Color(0xFFE05A47)
private val HintBlue = Color(0x663E9BEA)
private const val LIFT_FRAC = 0.45f      // quân đang kéo nằm cao hơn ngón tay chừng này ô
private const val SHAKE_FRAC = 0.12f     // biên độ lắc = 12% cạnh ô

private enum class PuzzleStatus { YourTurn, Correct, Wrong, Solved, Broken }

@Composable
fun PuzzleSolveScreen(
    level: Int,
    images: Array<ImageBitmap?>,
    onBack: () -> Unit,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val ctx = LocalContext.current
    val puzzle by produceState<Puzzle?>(initialValue = null, key1 = level) {
        value = withContext(Dispatchers.IO) { PuzzleRepository.load(ctx, level) }
    }
    Column(modifier.fillMaxSize().background(ScreenBg).navigationBarsPadding()) {
        TopBar(level = level, rating = puzzle?.rating, onBack = onBack)
        val p = puzzle
        if (p == null) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = OkGreen)
            }
        } else {
            key(p.level, p.puzzleId) {
                PuzzleContent(puzzle = p, images = images, onSolved = onSolved, modifier = Modifier.weight(1f).fillMaxWidth())
            }
        }
    }
}

/**
 * Màn bài học chiến thuật: dùng lại đúng bàn cờ + luật chấm của màn giải đố, chỉ thêm thanh tiêu đề riêng
 * và thẻ "Ý tưởng" phía trên (tối đa 3 dòng để chừa chỗ cho bàn cờ). Không tải gì từ đĩa/DB: [puzzle] dựng sẵn.
 */
@Composable
fun LessonPuzzleScreen(
    puzzle: Puzzle,
    title: String,
    idea: String,
    images: Array<ImageBitmap?>,
    onBack: () -> Unit,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().background(ScreenBg).navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            }
            Text(
                title,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                modifier = Modifier.weight(1f),
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(CardBg)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color(0xFFF5C84C), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(idea, color = Color(0xFFD8D8D8), fontSize = 14.sp, lineHeight = 19.sp, maxLines = 3)
        }
        Spacer(Modifier.height(8.dp))
        key(puzzle.puzzleId) {
            PuzzleContent(puzzle = puzzle, images = images, onSolved = onSolved, modifier = Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun TopBar(level: Int, rating: Int?, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
        }
        Text("Câu đố $level", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.weight(1f))
        if (rating != null) {
            Text("Độ khó $rating", color = Color(0xFFBABABA), fontSize = 14.sp, modifier = Modifier.padding(end = 14.dp))
        }
    }
}

@Composable
private fun PuzzleContent(
    puzzle: Puzzle,
    images: Array<ImageBitmap?>,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val session = remember(puzzle) { PuzzleSession(puzzle) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    // Thế cờ khởi đầu = TRƯỚC nước của đối thủ; sau ~0.5s đối thủ đi và người chơi bắt đầu.
    var board by remember(session) { mutableStateOf(session.boardBefore.copyOf()) }
    var lastFrom by remember(session) { mutableIntStateOf(-1) }
    var lastTo by remember(session) { mutableIntStateOf(-1) }
    var selected by remember(session) { mutableIntStateOf(-1) }
    var targets by remember(session) { mutableStateOf(emptyList<Int>()) }
    var hint by remember(session) { mutableStateOf<Pair<Int, Int>?>(null) }
    var wrongSq by remember(session) { mutableIntStateOf(-1) }
    var status by remember(session) { mutableStateOf(PuzzleStatus.YourTurn) }
    var busy by remember(session) { mutableStateOf(true) }
    var finished by remember(session) { mutableStateOf(false) }
    var slideFrom by remember(session) { mutableIntStateOf(-1) }
    var slideTo by remember(session) { mutableIntStateOf(-1) }
    val slide = remember(session) { Animatable(1f) }
    val shake = remember(session) { Animatable(0f) }

    LaunchedEffect(session) {
        if (!session.valid) {
            board = session.board()
            status = PuzzleStatus.Broken
            finished = true
            busy = false
            return@LaunchedEffect
        }
        delay(500)
        val sm = session.setupMove
        slide.snapTo(0f)
        slideFrom = moveFrom(sm)
        slideTo = moveTo(sm)
        lastFrom = slideFrom
        lastTo = slideTo
        board = session.board()
        slide.animateTo(1f, tween(240))
        status = PuzzleStatus.YourTurn
        busy = false
    }

    fun select(sq: Int) {
        hint = null
        if (sq < 0) {
            selected = -1
            targets = emptyList()
        } else {
            selected = sq
            targets = session.legalTargets(sq)
        }
    }

    fun attempt(from: Int, to: Int, dragged: Boolean) {
        if (busy || finished) return
        when (val r = session.submit(from, to)) {
            is PuzzleStep.Illegal -> select(-1)
            is PuzzleStep.Wrong -> {
                select(-1)
                wrongSq = from
                status = PuzzleStatus.Wrong
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                scope.launch {
                    shake.snapTo(0f)
                    for (a in floatArrayOf(-1f, 1f, -0.7f, 0.7f, -0.35f, 0.35f, 0f)) shake.animateTo(a, tween(45))
                    wrongSq = -1
                }
            }
            is PuzzleStep.Correct -> {
                select(-1)
                busy = true
                scope.launch {
                    if (!dragged) {               // chạm-để-đi: trượt quân; kéo-thả: quân đã nằm sẵn trên ô đích
                        slide.snapTo(0f)
                        slideFrom = moveFrom(r.playerMove)
                        slideTo = moveTo(r.playerMove)
                    } else {
                        slideFrom = -1
                        slideTo = -1
                    }
                    lastFrom = moveFrom(r.playerMove)
                    lastTo = moveTo(r.playerMove)
                    board = r.boardAfterPlayer
                    status = if (r.solved) PuzzleStatus.Solved else PuzzleStatus.Correct
                    if (!dragged) slide.animateTo(1f, tween(160))
                    val reply = r.reply
                    if (reply != null) {
                        delay(320)
                        slide.snapTo(0f)
                        slideFrom = moveFrom(reply)
                        slideTo = moveTo(reply)
                        lastFrom = slideFrom
                        lastTo = slideTo
                        board = session.board()
                        slide.animateTo(1f, tween(220))
                    }
                    if (r.solved) {
                        finished = true
                    } else {
                        status = PuzzleStatus.YourTurn
                        busy = false
                    }
                }
            }
        }
    }

    Box(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // Đọc maxWidth/maxHeight ở đây (BoxWithConstraintsScope): bên trong Column (ColumnScope) không gọi được trực tiếp.
            val contentW = maxWidth - 16.dp
            val side = minOf(contentW, maxHeight - 150.dp).coerceAtLeast(160.dp)
            Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                InfoCard(
                    playerWhite = session.playerWhite,
                    goal = puzzleGoalText(puzzle),
                    modifier = Modifier.width(contentW),
                )
                Spacer(Modifier.height(10.dp))
                PuzzleBoard(
                    images = images,
                    board = board,
                    flipped = !session.playerWhite,
                    lastFrom = lastFrom,
                    lastTo = lastTo,
                    selected = selected,
                    targets = targets,
                    hint = hint,
                    wrongSq = wrongSq,
                    shake = shake,
                    slideFrom = slideFrom,
                    slideTo = slideTo,
                    slide = slide,
                    enabled = !busy && !finished,
                    isPlayerPiece = { session.isPlayerPiece(it) },
                    onSelect = { select(it) },
                    onMove = { from, to, dragged -> attempt(from, to, dragged) },
                    modifier = Modifier.size(side),
                )
                StatusLine(status = status, side = puzzleSideName(session.playerWhite))
            }
        }

        // Nút nổi nhỏ ở góc dưới phải: Gợi ý (khi đang giải) · Hoàn thành (chỉ hiện khi đã giải xong).
        Row(
            Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedVisibility(visible = !finished, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(CardBg)
                        .border(1.dp, Color(0x33FFFFFF), CircleShape)
                        .clickable(enabled = !busy) {
                            select(-1)
                            hint = session.hint()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Lightbulb, contentDescription = "Gợi ý", tint = Color(0xFFF5C84C), modifier = Modifier.size(22.dp))
                }
            }
            AnimatedVisibility(visible = finished, enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
                Row(
                    Modifier
                        .height(44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(OkGreen)
                        .clickable(onClick = onSolved)
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Text(
                        if (status == PuzzleStatus.Broken) "Bỏ qua" else "Hoàn thành",
                        color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
                    )
                }
            }
        }
    }
}

/** Thanh thông tin phía trên bàn cờ: bên đi + mục tiêu (lấy từ cột `themes`). */
@Composable
private fun InfoCard(playerWhite: Boolean, goal: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(if (playerWhite) Color.White else Color(0xFF1B1B1B))
                    .border(1.dp, Color(0x88FFFFFF), CircleShape)
            )
            Spacer(Modifier.width(8.dp))
            Text("Lượt đi: " + puzzleSideName(playerWhite), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Flag, contentDescription = null, tint = OkGreen, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
            Text("Mục tiêu: $goal", color = Color(0xFFD8D8D8), fontSize = 15.sp)
        }
    }
}

@Composable
private fun StatusLine(status: PuzzleStatus, side: String) {
    val (text, color) = when (status) {
        PuzzleStatus.YourTurn -> "Tìm nước đi tốt nhất cho quân $side" to Color(0xFFBABABA)
        PuzzleStatus.Correct -> "Chính xác! Đối thủ đang đáp lại…" to OkGreen
        PuzzleStatus.Wrong -> "Chưa đúng, hãy thử nước khác" to BadRed
        PuzzleStatus.Solved -> "Tuyệt vời! Bạn đã giải xong câu đố" to OkGreen
        PuzzleStatus.Broken -> "Dữ liệu câu đố bị lỗi — bấm Bỏ qua để tiếp tục" to BadRed
    }
    Row(
        Modifier.fillMaxWidth().height(40.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        when (status) {
            PuzzleStatus.Correct, PuzzleStatus.Solved ->
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            PuzzleStatus.Wrong, PuzzleStatus.Broken ->
                Icon(Icons.Filled.Cancel, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            else -> {}
        }
        if (status != PuzzleStatus.YourTurn) Spacer(Modifier.width(6.dp))
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

// ─────────────────────────────────────────────────────────── Bàn cờ

@Composable
private fun PuzzleBoard(
    images: Array<ImageBitmap?>,
    board: IntArray,
    flipped: Boolean,
    lastFrom: Int,
    lastTo: Int,
    selected: Int,
    targets: List<Int>,
    hint: Pair<Int, Int>?,
    wrongSq: Int,
    shake: Animatable<Float, AnimationVector1D>,
    slideFrom: Int,
    slideTo: Int,
    slide: Animatable<Float, AnimationVector1D>,
    enabled: Boolean,
    isPlayerPiece: (Int) -> Boolean,
    onSelect: (Int) -> Unit,
    onMove: (from: Int, to: Int, dragged: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    var dragSq by remember { mutableIntStateOf(-1) }
    var finger by remember { mutableStateOf(Offset.Zero) }
    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    // Gesture chạy trong 1 coroutine sống lâu ⇒ luôn đọc giá trị MỚI NHẤT qua rememberUpdatedState.
    val enabledNow by rememberUpdatedState(enabled)
    val flippedNow by rememberUpdatedState(flipped)
    val selectedNow by rememberUpdatedState(selected)
    val targetsNow by rememberUpdatedState(targets)
    val isPlayerPieceNow by rememberUpdatedState(isPlayerPiece)
    val onSelectNow by rememberUpdatedState(onSelect)
    val onMoveNow by rememberUpdatedState(onMove)

    BoxWithConstraints(modifier) {
        val boardPx = constraints.maxWidth.toFloat()
        val s = boardPx / 8f
        val sDp = with(density) { s.toDp() }

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    val slop = viewConfiguration.touchSlop
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (!enabledNow) return@awaitEachGesture
                        val bp = size.width.toFloat()
                        val sq = bp / 8f
                        val flip = flippedNow
                        val startSq = squareAt(down.position, bp, flip)
                        val sel = selectedNow
                        // Đang chọn 1 quân và chạm vào ô đích hợp lệ ⇒ "chạm để đi", thực hiện lúc nhả tay.
                        val tapMoveFrom = if (sel >= 0 && startSq != sel && targetsNow.contains(startSq)) sel else -1
                        var canDrag = false
                        var wasSelected = false
                        if (tapMoveFrom < 0) {
                            if (isPlayerPieceNow(startSq)) {
                                wasSelected = sel == startSq
                                if (!wasSelected) onSelectNow(startSq)
                                canDrag = true
                            } else {
                                onSelectNow(-1)
                            }
                        }
                        var dragging = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            val center = Offset(change.position.x, change.position.y - sq * LIFT_FRAC)
                            if (!change.pressed) {
                                if (dragging) {
                                    val drop = squareAt(center, bp, flip)
                                    dragSq = -1
                                    if (drop != startSq) onMoveNow(startSq, drop, true)
                                } else if (tapMoveFrom >= 0) {
                                    onMoveNow(tapMoveFrom, startSq, false)
                                } else if (canDrag && wasSelected) {
                                    onSelectNow(-1)   // chạm lại quân đang chọn ⇒ bỏ chọn
                                }
                                break
                            }
                            if (canDrag) {
                                if (!dragging && (change.position - down.position).getDistance() > slop) {
                                    dragging = true
                                    dragSq = startSq
                                }
                                if (dragging) {
                                    finger = center
                                    change.consume()
                                }
                            }
                        }
                        dragSq = -1   // cử chỉ bị huỷ giữa chừng ⇒ quân về chỗ cũ
                    }
                },
        ) {
            drawPuzzleBoard(
                images = images,
                board = board,
                flipped = flipped,
                lastFrom = lastFrom,
                lastTo = lastTo,
                selected = selected,
                targets = targets,
                hint = hint,
                wrongSq = wrongSq,
                shakeValue = shake.value,
                slideFrom = slideFrom,
                slideTo = slideTo,
                slideValue = slide.value,
                hiddenSq = dragSq,
                hoverCenter = if (dragSq >= 0) finger else null,
                labelPaint = labelPaint,
            )
        }

        // Quân đang kéo: dính ngón tay bằng graphicsLayer (GPU), nhấc lên 1.15× + bóng đổ.
        val dragImg = if (dragSq >= 0) images.getOrNull(board[dragSq]) else null
        if (dragImg != null) {
            Image(
                bitmap = dragImg,
                contentDescription = null,
                filterQuality = FilterQuality.High,
                modifier = Modifier
                    .size(sDp)
                    .graphicsLayer {
                        translationX = finger.x - s / 2f
                        translationY = finger.y - s / 2f
                        scaleX = 1.15f
                        scaleY = 1.15f
                        shadowElevation = 12.dp.toPx()
                        shape = CircleShape
                        clip = false
                        ambientShadowColor = Color.Black
                        spotShadowColor = Color.Black
                    },
            )
        }
    }
}

private fun DrawScope.drawPuzzleBoard(
    images: Array<ImageBitmap?>,
    board: IntArray,
    flipped: Boolean,
    lastFrom: Int,
    lastTo: Int,
    selected: Int,
    targets: List<Int>,
    hint: Pair<Int, Int>?,
    wrongSq: Int,
    shakeValue: Float,
    slideFrom: Int,
    slideTo: Int,
    slideValue: Float,
    hiddenSq: Int,
    hoverCenter: Offset?,
    labelPaint: Paint,
) {
    val s = size.width / 8f

    fun topLeft(sq: Int): Offset = squareTopLeft(sq, s, flipped)
    fun center(sq: Int): Offset {
        val o = topLeft(sq)
        return Offset(o.x + s / 2f, o.y + s / 2f)
    }
    fun tint(sq: Int, color: Color) = drawRect(color = color, topLeft = topLeft(sq), size = Size(s, s))
    fun piece(code: Int, x: Float, y: Float) {
        val img = images.getOrNull(code) ?: return
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = IntOffset(x.roundToInt(), y.roundToInt()),
            dstSize = IntSize(s.roundToInt(), s.roundToInt()),
            filterQuality = FilterQuality.High,
        )
    }

    // 64 ô
    for (sq in 0 until 64) {
        val light = ((sq shr 3) + (sq and 7)) % 2 == 1
        tint(sq, if (light) VilaColors.BoardLight else VilaColors.BoardDark)
    }
    // tô sáng
    if (lastFrom >= 0 && lastTo >= 0) {
        tint(lastFrom, VilaColors.Highlight)
        tint(lastTo, VilaColors.Highlight)
    }
    if (selected >= 0) tint(selected, VilaColors.Highlight)
    if (hint != null) {
        tint(hint.first, HintBlue)
        tint(hint.second, HintBlue)
    }
    if (wrongSq >= 0) tint(wrongSq, VilaColors.PremoveRed)

    // toạ độ a–h / 1–8
    drawIntoCanvas { canvas ->
        labelPaint.textSize = s * 0.2f
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val col = if (flipped) 7 - f else f
            val row = if (flipped) r else 7 - r
            val light = (r + f) % 2 == 1
            labelPaint.color = (if (light) VilaColors.BoardDark else VilaColors.BoardLight).toArgb()
            if (col == 0) {
                labelPaint.textAlign = Paint.Align.LEFT
                canvas.nativeCanvas.drawText(('1' + r).toString(), col * s + s * 0.06f, row * s + s * 0.24f, labelPaint)
            }
            if (row == 7) {
                labelPaint.textAlign = Paint.Align.RIGHT
                canvas.nativeCanvas.drawText(('a' + f).toString(), col * s + s - s * 0.06f, row * s + s - s * 0.08f, labelPaint)
            }
        }
    }

    // chấm gợi ý nước đi
    for (sq in targets) {
        val c = center(sq)
        if (board[sq] != 0) {
            drawCircle(Color(0x2E000000), radius = s * 0.43f, center = c, style = Stroke(width = s * 0.09f))
        } else {
            drawCircle(Color(0x2E000000), radius = s * 0.17f, center = c)
        }
    }

    // QUÂN CỜ – đọc thẳng từ board (đã parse từ FEN)
    val sliding = slideTo >= 0 && slideValue < 1f
    for (sq in 0 until 64) {
        val pc = board[sq]
        if (pc == 0 || sq == hiddenSq) continue
        if (sliding && sq == slideTo) continue
        val o = topLeft(sq)
        val dx = if (sq == wrongSq) shakeValue * s * SHAKE_FRAC else 0f
        piece(pc, o.x + dx, o.y)
    }
    if (sliding && slideFrom >= 0) {
        val a = topLeft(slideFrom)
        val b = topLeft(slideTo)
        piece(board[slideTo], a.x + (b.x - a.x) * slideValue, a.y + (b.y - a.y) * slideValue)
    }

    // viền ô đang rê qua khi kéo
    if (hoverCenter != null) {
        val hover = squareAt(hoverCenter, size.width, flipped)
        if (targets.contains(hover)) {
            val o = topLeft(hover)
            drawRect(
                color = Color(0xB3FFFFFF),
                topLeft = Offset(o.x + s * 0.03f, o.y + s * 0.03f),
                size = Size(s * 0.94f, s * 0.94f),
                style = Stroke(width = s * 0.06f),
            )
        }
    }
}
