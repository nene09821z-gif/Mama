package com.vila.chess.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Grid of selectable chips (single choice). [selected] = -1 means nothing highlighted. */
@Composable
fun ChipGrid(
    labels: List<String>,
    selected: Int,
    columns: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    chipHeight: Dp = 42.dp,
    fontSize: TextUnit = 14.sp,
) {
    val rows = (labels.size + columns - 1) / columns
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (row in 0 until rows) {
            val start = row * columns
            val end = minOf(start + columns, labels.size)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                for (i in start until end) {
                    val isSel = i == selected
                    val shape = RoundedCornerShape(8.dp)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(chipHeight)
                            .pressable(pressedScale = 0.94f, onClick = { onSelect(i) })
                            .clip(shape)
                            .background(if (isSel) VilaColors.Green.copy(alpha = 0.18f) else Color(0x66101C33))
                            .border(
                                width = if (isSel) 1.5.dp else 1.dp,
                                color = if (isSel) VilaColors.Green else Color(0x26FFFFFF),
                                shape = shape,
                            )
                            .padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = labels[i],
                            color = if (isSel) VilaColors.Green else VilaColors.TextDim,
                            fontSize = fontSize,
                            fontWeight = if (isSel) FontWeight.ExtraBold else FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                for (k in end until start + columns) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = VilaColors.TextDim,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier,
    )
}

@Composable
fun SwitchRow(title: String, checked: Boolean, modifier: Modifier = Modifier, onChange: (Boolean) -> Unit) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            color = VilaColors.Text,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f),
        )
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = VilaColors.Green,
            ),
        )
    }
}

/** One card of the piece-set picker: white + black knight preview and the set name. */
@Composable
fun PieceSetCard(info: PieceSetInfo, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val pair = remember(info.id) { loadPiecePair(ctx, info.id) }
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(VilaColors.Panel)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) VilaColors.Green else VilaColors.ClockIdle,
                shape = shape,
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
            val w = pair.first
            val b = pair.second
            Box(Modifier.size(44.dp).background(VilaColors.BoardLight), contentAlignment = Alignment.Center) {
                if (w != null) Image(bitmap = w, contentDescription = null, modifier = Modifier.size(44.dp))
            }
            Box(Modifier.size(44.dp).background(VilaColors.BoardDark), contentAlignment = Alignment.Center) {
                if (b != null) Image(bitmap = b, contentDescription = null, modifier = Modifier.size(44.dp))
            }
        }
        Text(
            text = info.label,
            color = if (selected) VilaColors.Green else VilaColors.TextDim,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
