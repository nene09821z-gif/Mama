package com.vila.chess.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.streakLabel

/**
 * Bottom sheet hồ sơ nhanh của ĐỐI THỦ. Mở khi người chơi chạm tên/avatar đối thủ (PlayerBar.onProfileClick).
 *
 *   var showOpp by remember { mutableStateOf(false) }
 *   PlayerBar(vm, ui, images, white, name = opp.name, tier = opp.tier, onProfileClick = { showOpp = true })
 *   if (showOpp) OpponentProfileSheet(
 *       userId = opp.userId, fallbackName = opp.name, fallbackTier = opp.tier, mode = EloMode.BLITZ,
 *       onDismiss = { showOpp = false }, onViewFull = { id -> showOpp = false; vm.openProfile(id) },
 *   )
 *
 * Dữ liệu lấy từ bảng `users` (Supabase). Trong lúc tải / khi lỗi vẫn hiện tên + huy hiệu đã biết sẵn từ ván đấu.
 *
 * @param mode thể loại của ván đang chơi → Elo "hiện tại" hiển thị to; ba thể loại còn lại hiện nhỏ bên dưới.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpponentProfileSheet(
    userId: String,
    fallbackName: String,
    onDismiss: () -> Unit,
    onViewFull: (String) -> Unit,
    modifier: Modifier = Modifier,
    fallbackTier: MembershipTier = MembershipTier.FREE,
    mode: EloMode = EloMode.BLITZ,
) {
    val (state, retry) = rememberRemoteProfile(userId)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color(0xFF16233B),
        contentColor = Color.White,
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 280.dp)
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            when (val s = state) {
                is LoadState.Loading -> {
                    // Có sẵn tên/huy hiệu từ ván đấu → hiện ngay, chỉ phần số liệu đang tải
                    SheetHeader(UserProfile(userId = userId, displayName = fallbackName, tier = fallbackTier))
                    LoadingBlock(text = "Đang tải hồ sơ…")
                }
                is LoadState.Error -> {
                    SheetHeader(UserProfile(userId = userId, displayName = fallbackName, tier = fallbackTier))
                    ErrorBlock(s.kind, onRetry = retry)
                }
                is LoadState.Success -> {
                    val p = s.data
                    SheetHeader(p)
                    Spacer(Modifier.height(16.dp))
                    EloHero(p, mode)
                    Spacer(Modifier.height(16.dp))
                    QuickStats(p)
                    Spacer(Modifier.height(20.dp))
                    ChunkyButton(
                        text = "Xem hồ sơ đầy đủ",
                        onClick = { onViewFull(p.userId) },
                        modifier = Modifier.fillMaxWidth(),
                        height = 48.dp,
                        fontSize = 18.sp,
                    )
                }
            }
        }
    }
}

/** Avatar + tên + huy hiệu VIP + quốc gia. */
@Composable
private fun SheetHeader(p: UserProfile) {
    ProfileAvatar(name = p.displayName, avatarKey = p.avatarKey, size = 76.dp)
    Spacer(Modifier.height(10.dp))
    NameWithBadge(name = p.displayName, tier = p.tier, fontSize = 22f, badgeSize = 22.dp)
    CountryLine(p.countryCode, Modifier.padding(top = 4.dp))
}

/** Elo hiện tại của thể loại đang chơi (to) + hai thể loại còn lại (nhỏ). */
@Composable
private fun EloHero(p: UserProfile, mode: EloMode) {
    Text("Elo ${mode.title}", color = VilaColors.TextDim, fontSize = 13.sp)
    Text(p.elo(mode).toString(), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        for (m in EloMode.values()) {
            EloCard(m.title, m.subtitle, p.elo(m), selected = m == mode, modifier = Modifier.weight(1f))
        }
    }
}

/** Thắng/Hòa/Thua + chuỗi thắng/thua hiện tại. */
@Composable
private fun QuickStats(p: UserProfile) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        WdlRow(p)
        WdlBar(p.won, p.drawn, p.lost)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Chuỗi hiện tại", color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(
                streakLabel(p.resultStreak),
                color = when {
                    p.resultStreak > 0 -> WinColor
                    p.resultStreak < 0 -> LossColor
                    else -> VilaColors.TextDim
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
