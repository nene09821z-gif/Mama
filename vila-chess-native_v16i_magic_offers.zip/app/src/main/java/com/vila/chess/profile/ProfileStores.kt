package com.vila.chess.profile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Lịch sử Elo theo thời gian của từng thể loại (SharedPreferences "vila_elo_history"), dùng vẽ biểu đồ ở màn Hồ sơ.
 * Mỗi lần kết thúc ván tính điểm, GameViewModel gọi [UserSessionManager.onGameFinished] → [record].
 */
class EloHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_elo_history", Context.MODE_PRIVATE)

    fun load(mode: EloMode): List<EloPoint> = EloHistoryCodec.decode(prefs.getString(mode.key, null))

    fun loadAll(): Map<EloMode, List<EloPoint>> = EloMode.values().associateWith { load(it) }

    @Synchronized
    fun record(mode: EloMode, before: Int, after: Int, ts: Long) {
        val next = EloSeries.append(load(mode), before, after, ts)
        prefs.edit().putString(mode.key, EloHistoryCodec.encode(next)).apply()
    }
}

/** 50 ván gần nhất của chính người chơi (tab "Ván đấu"). Lưu JSON trong SharedPreferences "vila_game_history". */
class GameHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("vila_game_history", Context.MODE_PRIVATE)

    /** Mới nhất trước. File hỏng → danh sách rỗng (không làm crash màn Hồ sơ). */
    fun load(): List<GameRecord> = try {
        val arr = JSONArray(prefs.getString("games", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            GameRecord(
                ts = o.optLong("ts"),
                opponent = o.optString("opp", "?"),
                score = o.optDouble("score", 0.0),
                modeKey = o.optString("mode", ""),
                delta = o.optInt("delta", 0),
                moves = o.optInt("moves", 0),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    @Synchronized
    fun add(r: GameRecord) {
        val arr = JSONArray()
        arr.put(JSONObject().put("ts", r.ts).put("opp", r.opponent).put("score", r.score)
            .put("mode", r.modeKey).put("delta", r.delta).put("moves", r.moves))
        val old = load()
        for (g in old.take(MAX - 1)) {
            arr.put(JSONObject().put("ts", g.ts).put("opp", g.opponent).put("score", g.score)
                .put("mode", g.modeKey).put("delta", g.delta).put("moves", g.moves))
        }
        prefs.edit().putString("games", arr.toString()).apply()
    }

    private companion object { const val MAX = 50 }
}
