package com.vila.chess.billing

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.ui.VilaColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.NumberFormat
import java.util.Locale

fun formatVnd(amount: Long): String = NumberFormat.getInstance(Locale("vi", "VN")).format(amount) + " ₫"

/**
 * Thanh toán chuyển khoản: hiện mã VietQR + thông tin tài khoản + nội dung chuyển khoản (có mã thiết bị),
 * rồi ô nhập mã kích hoạt. [tier] = null → chỉ hiện ô nhập mã (nút "Nhập mã kích hoạt").
 */
@Composable
fun ManualPayDialog(
    tier: MembershipTier?,
    period: BillingPeriod,
    onDismiss: () -> Unit,
    onRedeem: (String) -> Result<String>,
) {
    val ctx = LocalContext.current
    val deviceId = remember { LicenseManager.deviceCode(ctx) }
    val amount = tier?.let { BillingCatalog.priceVnd(it, period) }
    val memo = tier?.let { "VILA " + deviceId + " " + it.id.uppercase() + if (period == BillingPeriod.YEARLY) "Y" else "M" }
    val configured = !ManualPay.ACCOUNT_NO.startsWith("YOUR_")

    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val hasServer = ManualPay.SERVER_URL.isNotBlank()

    val qr by produceState<ImageBitmap?>(null, tier, period) {
        value = null
        if (tier != null && configured && amount != null && memo != null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val url = "https://img.vietqr.io/image/" + ManualPay.BANK_BIN + "-" + ManualPay.ACCOUNT_NO + "-compact2.png" +
                        "?amount=" + amount +
                        "&addInfo=" + URLEncoder.encode(memo, "UTF-8") +
                        "&accountName=" + URLEncoder.encode(ManualPay.ACCOUNT_NAME, "UTF-8")
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    conn.inputStream.use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                }.getOrNull()
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF262522),
        title = {
            Text(
                if (tier != null) "Thanh toán " + tier.displayName + (if (period == BillingPeriod.YEARLY) " · 1 năm" else " · 1 tháng") else "Nhập mã kích hoạt",
                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (tier != null && amount != null && memo != null) {
                    Step("1. Chuyển khoản đúng số tiền và nội dung:")
                    if (!configured) {
                        Text("Chủ app chưa điền số tài khoản (ManualPay.ACCOUNT_NO trong BillingCatalog.kt).", color = Color(0xFFFF8A80), fontSize = 13.sp)
                    } else {
                        Box(Modifier.fillMaxWidth().height(260.dp), Alignment.Center) {
                            val img = qr
                            if (img != null) Image(img, "Mã VietQR", Modifier.size(250.dp))
                            else CircularProgressIndicator(color = VilaColors.Green)
                        }
                        CopyRow(ctx, "Ngân hàng", ManualPay.BANK_NAME)
                        CopyRow(ctx, "Số tài khoản", ManualPay.ACCOUNT_NO)
                        CopyRow(ctx, "Chủ tài khoản", ManualPay.ACCOUNT_NAME)
                        CopyRow(ctx, "Số tiền", formatVnd(amount), copyValue = amount.toString())
                        CopyRow(ctx, "Nội dung", memo)
                    }
                    if (hasServer) {
                        Step("2. Sau 1–2 phút, bấm nút kiểm tra: gói tự kích hoạt.")
                    } else {
                        Step("2. Gửi ảnh biên lai + mã thiết bị cho " + ManualPay.CONTACT + " để nhận mã kích hoạt.")
                        Step("3. Nhập mã vào ô bên dưới:")
                    }
                } else {
                    Step("Nhập mã kích hoạt bạn nhận được sau khi chuyển khoản.")
                }
                CopyRow(ctx, "Mã thiết bị", deviceId)
                if (hasServer) {
                    TextButton(onClick = {
                        if (checking) return@TextButton
                        checking = true; message = null
                        scope.launch {
                            val r = LicenseManager.syncFromServer(ctx)
                            checking = false
                            r.fold(
                                onSuccess = { rd ->
                                    if (rd != null) { message = "Đã kích hoạt gói " + rd.tier.displayName + " đến " + LicenseManager.formatDate(rd.expiresAt); success = true }
                                    else { message = "Chưa thấy giao dịch. Chờ 1–2 phút rồi thử lại."; success = false }
                                },
                                onFailure = { message = "Không kết nối được máy chủ. Kiểm tra mạng rồi thử lại."; success = false },
                            )
                        }
                    }) { Text(if (checking) "Đang kiểm tra…" else "Tôi đã chuyển khoản — kiểm tra", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
                    Text("Hoặc nhập mã kích hoạt nếu bạn có:", color = VilaColors.TextDim, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it; message = null },
                    singleLine = true,
                    placeholder = { Text("XXXXXX-XXXXXX-XXXXXX-XXXXXX", color = VilaColors.TextDim, fontSize = 13.sp) },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    modifier = Modifier.fillMaxWidth(),
                )
                message?.let {
                    Text(it, color = if (success) VilaColors.Green else Color(0xFFFF8A80), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(2.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (success) { onDismiss(); return@TextButton }
                onRedeem(code).fold(
                    onSuccess = { message = it; success = true },
                    onFailure = { message = it.message ?: "Mã không hợp lệ"; success = false },
                )
            }) { Text(if (success) "Xong" else "Kích hoạt", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng", color = Color(0xFFBABABA)) } },
    )
}

@Composable
private fun Step(text: String) = Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)

@Composable
private fun CopyRow(ctx: Context, label: String, value: String, copyValue: String = value) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = VilaColors.TextDim, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText(label, copyValue))
            Toast.makeText(ctx, "Đã sao chép " + label.lowercase(), Toast.LENGTH_SHORT).show()
        }) { Text("Sao chép", color = VilaColors.Green, fontSize = 13.sp) }
    }
}
