package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.vila.chess.R
import com.vila.chess.game.PuzzleLevel
import kotlin.math.roundToInt
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ════════════════════════════════════════════════════════════════════════════════════════════
//  PUZZLE MAP 2.5D
//
//  Drawable cần có trong res/drawable-nodpi/ :  bg_map · wood_node · coach · tree · house · pond · bench · bush · rocks · pine · flowers_white · flowers_color
//  + 44 sprite Kenney (CC0) render 2.5D từ GLB:  kf_*  (Mini Forest, 22)  ·  ka_*  (Mini Arena, 22)  – xem PropKind.
//
//  Thứ tự lớp (dưới → trên), tất cả nằm trong MỘT BoxWithConstraints:
//    1. bg_map        Image fillMaxSize (Crop)
//    2. TrailCanvas   Canvas CỐ ĐỊNH phủ toàn màn hình – vẽ đường mòn 2 lớp theo toạ độ THỰC của nút
//    3. SceneryLayer  cây / nhà / ao / ghế / đá / bụi / hoa + 44 vật Kenney: x, w = % bề rộng ĐƯỜNG ĐI (= chiều rộng màn trên điện thoại), y = % chiều cao "khối 16 level"; cuộn cùng thế giới.
//                     8 biến thể bố cục dày (PuzzleSceneryData.kt) luân phiên theo khối ⇒ 50.000 level không lặp liền nhau; KHÔNG vật nào đè nút / đường mòn / vật khác.
//    4. LazyColumn    50.000 nút gỗ (key = { it.id } + contentType). Trong nút chỉ có số Level; nút đã xong hiện quân Mã
//    5. HUD           tiêu đề, HLV + bong bóng chat (đặt theo % maxWidth), tiến độ, nút "Giải các câu đố"
//
//  Vừa qua màn (justCompletedLevel ≠ null): quân Mã nhảy từ dưới lên tâm nút (spring), scale 0 → 1.2 → 1, vầng sáng + vòng sóng
//  lan quanh nút. Animatable nằm ở cấp màn hình (NodeCelebration) nên cuộn đi/lại không làm animation chạy lại.
//
//  Hiệu năng – quy tắc duy nhất: mọi thứ phụ thuộc vị trí cuộn chỉ được ĐỌC trong draw / graphicsLayer
//  lambda ⇒ cuộn chỉ gây redraw của vài layer GPU, KHÔNG gây recomposition. Toạ độ (xs), Path, Stroke,
//  số đo (MapMetrics) đều tạo 1 lần bằng remember; animation chỉ đụng scale/alpha/translation.
// ════════════════════════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────── Data

/** Dữ liệu giả lập (xếp GIẢM dần như PuzzleMapViewModel.levels): [total] level, level [current] đang chơi. */
fun demoPuzzleLevels(total: Int = 15): List<PuzzleLevel> = List(total) { PuzzleLevel(total - it) }

private val DefaultLevels = demoPuzzleLevels()

/** Done: id < currentLevel · Current: id == currentLevel · Locked: id > currentLevel. */
enum class NodeState { Done, Current, Locked }

/** Cỡ chữ số Level theo số chữ số – "50000" vẫn nằm gọn trên mặt nút. Hệ số nhân với chiều rộng nút. */
private fun numberFactor(level: Int): Float = when {
    level < 100 -> 0.34f
    level < 1_000 -> 0.30f
    level < 10_000 -> 0.25f
    else -> 0.21f
}

/** Kích thước nút "chuẩn" ở màn 360dp. PuzzleTransitionWrapper dùng 2 hằng số này; trong map nút co giãn theo màn hình. */
val NodeW = 74.dp
val NodeH = 68.dp

// ─────────────────────────────────────────────────────────── Hình học (nguồn sự thật duy nhất)

private const val AMPLITUDE = 0.22f          // nút chạy từ 20% → 80% bề rộng đường đi
private const val NODE_ASPECT = 329f / 360f  // tỉ lệ ảnh wood_node
private const val FACE_SHIFT = 0.08f         // tâm MẶT TRÊN nút lệch lên 8% chiều cao (đường & số cùng dùng)
private const val ITEM_RATIO = 0.72f         // bước dọc giữa 2 level = 80% chiều rộng nút (đủ chỗ để lộ đường mòn)
private const val SCENE_LEVELS = 16          // cảnh vật lặp mỗi 16 level (= 2 chu kỳ zig-zag)
private val MaxTrackWidth = 520.dp           // máy tính bảng: đường đi không giãn quá 520dp, cảnh vật lấp 2 bên
private val TitleH = 52.dp
private val PanelHeight = 176.dp

/**
 * Sóng tam giác chu kỳ 8 (đường chéo isometric): 0.5 → 0.65 → 0.8 → 0.65 → 0.5 → 0.35 → 0.2 → 0.35 …
 * Neo theo ID level (level 7 ⇒ 0.5) chứ không theo vị trí trong list ⇒ thêm/bớt level không làm lệch hình dạng.
 * Muốn zig-zag "lẻ phải – chẵn trái": đổi thân hàm thành  if (level % 2 == 1) 0.5f + AMPLITUDE else 0.5f - AMPLITUDE.
 */
/**
 * S-curve so le trái/phải chu kỳ 4 level: giữa → PHẢI → giữa → TRÁI → … (sin). Neo theo ID level nên thêm/bớt level
 * không làm lệch hình. Nút và đường nối đều gọi hàm này ⇒ luôn trùng nhau.
 */
internal fun levelXFrac(level: Int): Float =
    0.5f + AMPLITUDE * kotlin.math.sin((level - 1) * (Math.PI / 2.0)).toFloat()

/** Mọi số đo phụ thuộc kích thước màn hình – tính 1 lần cho mỗi (maxWidth, density). */
@Immutable
private class MapMetrics(screenW: Dp, density: Density) {
    val trackW: Dp = minOf(screenW, MaxTrackWidth)
    val nodeW: Dp = (trackW * 0.205f).coerceIn(60.dp, 112.dp)
    val nodeH: Dp = nodeW * NODE_ASPECT

    /** Làm tròn về pixel nguyên: stride của LazyColumn và chiều cao khối cảnh vật khớp nhau tuyệt đối. */
    val itemH: Dp = with(density) { (nodeW.toPx() * ITEM_RATIO).roundToInt().toDp() }
}

/** Vị trí cuộn ban đầu (px): level hiện tại ~60% chiều cao; nếu cả cụm level thấp vừa khít thì dán đáy để không nút nào chui dưới panel. */
private fun initialScrollPx(curCenter: Float, viewport: Float, maxScroll: Float): Float {
    val wanted = (curCenter - viewport * 0.60f).coerceIn(0f, maxScroll)
    val yIfBottom = curCenter - maxScroll
    return if (yIfBottom in viewport * 0.35f..viewport * 0.70f) maxScroll else wanted
}

// ─────────────────────────────────────────────────────────── Ảnh (decode 1 lần)

@Immutable
private class MapArt(val bg: Painter, val node: Painter, val knight: Painter, val coach: Painter, val props: Map<PropKind, Painter>)

@Composable
private fun rememberMapArt(): MapArt {
    val bg = painterResource(R.drawable.bg_map)
    val node = painterResource(R.drawable.wood_node)
    val knight = painterResource(R.drawable.piece_wn)
    val coach = painterResource(R.drawable.coach)
    // Mọi vật cảnh (9 cái gốc + 44 sprite Kenney) nạp qua PropKind.res: số lượng cố định ⇒ thứ tự gọi painterResource ổn định;
    // painterResource tự cache theo id ⇒ decode đúng 1 lần.
    val kinds = PropKind.values()
    val painters = kinds.map { painterResource(it.res) }
    return remember(bg, node, knight, coach, painters) {
        MapArt(bg, node, knight, coach, kinds.zip(painters).toMap())
    }
}

// ─────────────────────────────────────────────────────────── Màn hình chính

@Composable
fun PuzzleMapScreen(
    modifier: Modifier = Modifier,
    levels: List<PuzzleLevel> = DefaultLevels,   // xếp GIẢM dần theo id (level cao ở trên, level 1 ở đáy) và ỔN ĐỊNH: lấy từ PuzzleMapViewModel.levels
    currentLevel: Int = 6,                        // id < currentLevel: đã xong · id == currentLevel: đang chơi · id > currentLevel: khoá
    score: Int = 554,
    streak: Int = 9,
    progress: Float = 0.28f,
    hiddenLevel: State<Int?>? = null,
    justCompletedLevel: Int? = null,              // ≠ null ⇒ phát animation quân cờ nhảy trên nút này
    onCelebrationFinished: () -> Unit = {},       // gọi 1 lần khi animation xong (ViewModel đặt justCompletedLevel = null)
    topPad: Dp = 0.dp,
    bottomPad: Dp = 0.dp,
    onNodeClick: (level: Int, center: Offset) -> Unit = { _, _ -> },
    onSolveClick: (() -> Unit)? = null,           // null ⇒ nút "Giải các câu đố" mở thẳng level đang chơi (onNodeClick)
) {
    val art = rememberMapArt()
    val shown = levels
    // Hàng của level hiện tại (list giảm dần ⇒ phần tử đầu tiên có id ≤ currentLevel). Chỉ tính lại khi tiến độ đổi.
    val currentIndex = remember(shown, currentLevel) {
        shown.indexOfFirst { it.id <= currentLevel }.takeIf { it >= 0 } ?: (shown.size - 1).coerceAtLeast(0)
    }
    val topId = remember(shown) { shown.firstOrNull()?.id ?: 1 }

    val rootCoords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    BoxWithConstraints(modifier.fillMaxSize().onGloballyPositioned { rootCoords[0] = it }) {   // chỉ chạy khi root đổi vị trí/kích thước
        val density = LocalDensity.current
        val m = remember(maxWidth, density) { MapMetrics(maxWidth, density) }
        val coachH = maxWidth * 0.19f                         // HLV: 19% chiều rộng màn
        val headerH = topPad + TitleH + coachH + 8.dp         // vùng HUD trên = phần đệm đầu của LazyColumn
        val panelH = PanelHeight + bottomPad
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()

        val itemPx = remember(m, density) { with(density) { m.itemH.toPx() } }
        val initialScroll = remember(shown.size, currentIndex, m, density, heightPx, headerH, panelH) {
            with(density) {
                val curCenter = headerH.toPx() + (currentIndex + 0.5f) * itemPx
                val maxScroll = (headerH.toPx() + shown.size * itemPx + panelH.toPx() - heightPx).coerceAtLeast(0f)
                initialScrollPx(curCenter, heightPx, maxScroll)
            }
        }
        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = (initialScroll / itemPx).toInt().coerceIn(0, (shown.size - 1).coerceAtLeast(0)),
            initialFirstVisibleItemScrollOffset = (initialScroll % itemPx).roundToInt(),
        )

        // Tâm nút (toạ độ root) tính LÚC CHẠM từ xs + layoutInfo – không tốn gì khi cuộn. Tìm hàng theo key (= id level).
        // LƯU Ý: LazyListItemInfo.offset KHÔNG gồm contentPadding ⇒ phải cộng beforeContentPadding (đây là gốc lỗi đường mòn lệch lên).
        val centerInRoot: (Int) -> Offset = remember(listState, m, widthPx, heightPx, density) {
            { id ->
                val info = listState.layoutInfo
                val row = info.visibleItemsInfo.firstOrNull { it.key == id }
                val local = if (row != null) {
                    Offset(widthPx / 2f + with(density) { (m.trackW * (levelXFrac(id) - 0.5f)).toPx() }, info.beforeContentPadding + row.offset + row.size / 2f)
                } else Offset(widthPx / 2f, heightPx / 2f)
                rootCoords[0]?.takeIf { it.isAttached }?.localToRoot(local) ?: local
            }
        }

        // Animation "vừa qua màn": mỗi lần kích hoạt dùng bộ Animatable MỚI (key = level) ⇒ không sót giá trị cũ;
        // Animatable ở cấp màn hình nên item bị LazyColumn tái chế khi cuộn cũng không làm animation chạy lại.
        val celebration = remember(justCompletedLevel) { NodeCelebration() }
        val currentOnFinished by rememberUpdatedState(onCelebrationFinished)
        LaunchedEffect(celebration) {
            if (justCompletedLevel != null) {
                celebration.play()
                currentOnFinished()
            }
        }

        // 1) Nền
        GrassBackground(art)

        // 2) Đường mòn: vẽ NGAY TRONG từng hàng (drawBehind) ⇒ luôn nằm dưới nút gỗ và không phụ thuộc toạ độ layoutInfo.

        // 3) Cảnh vật
        SceneryLayer(art = art, listState = listState, topId = topId, m = m, screenW = maxWidth)

        // 4) Danh sách nút
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = headerH, bottom = panelH),
        ) {
            items(
                items = shown,
                key = { it.id },
                contentType = { "puzzle_node" },
            ) { level ->
                // Độ lệch so với tâm: cùng hàm levelXFrac với Canvas ⇒ nút và đường luôn trùng nhau.
                val dx = remember(level.id, m) { m.trackW * (levelXFrac(level.id) - 0.5f) }
                val state = when {
                    level.id < currentLevel -> NodeState.Done
                    level.id == currentLevel -> NodeState.Current
                    else -> NodeState.Locked
                }
                PuzzleMapItem(
                    level = level.id, state = state, dx = dx, m = m, art = art, hiddenLevel = hiddenLevel,
                    celebration = if (level.id == justCompletedLevel) celebration else null,
                    onClick = { onNodeClick(level.id, centerInRoot(level.id)) },
                )
            }
        }

        // 5) HUD
        TopHud(
            level = shown.getOrNull(currentIndex)?.id ?: 1,
            art = art, screenW = maxWidth, topPad = topPad, coachH = coachH, headerH = headerH,
            modifier = Modifier.align(Alignment.TopStart),
        )
        BottomPanel(
            score = score, streak = streak, progress = progress,
            onSolveClick = { onSolveClick?.invoke() ?: onNodeClick(currentLevel, centerInRoot(currentLevel)) },
            bottomPad = bottomPad, modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

@Composable
private fun PuzzleMapItem(
    level: Int,
    state: NodeState,
    dx: Dp,
    m: MapMetrics,
    art: MapArt,
    hiddenLevel: State<Int?>?,
    celebration: NodeCelebration?,
    onClick: () -> Unit,
) {
    // Hàng đang ăn mừng vẽ ĐÈ lên hàng kế dưới: quân cờ bay lên từ phía dưới nút nên không bị nút bên dưới che.
    val trailPath = remember { Path() }
    Box(
        Modifier
            .fillMaxWidth()
            .height(m.itemH)
            .zIndex(if (celebration != null) 1f else 0f)
            .drawBehind { drawTrail(trailPath, level, state != NodeState.Locked, m) },   // dưới nút gỗ (vẽ trước nội dung)
        contentAlignment = Alignment.Center,
    ) {
        WoodenNode(
            level = level,
            state = state,
            modifier = Modifier.offset(x = dx),
            painter = art.node,
            piece = art.knight,
            nodeW = m.nodeW,
            onClick = onClick,
            celebration = celebration,
            isHidden = { hiddenLevel?.value == level },   // đọc State trong graphicsLayer ⇒ không recomposition
        )
    }
}

/** Nền cỏ: ảnh gradient + ô bàn cờ rất mờ (hợp chủ đề cờ vua) + vignette tối ở rìa. Vẽ 1 lần, không phụ thuộc cuộn. */
@Composable
private fun GrassBackground(art: MapArt) {
    Image(art.bg, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    Canvas(Modifier.fillMaxSize()) {
        val sq = 64.dp.toPx()
        val cols = (size.width / sq).toInt() + 1
        val rows = (size.height / sq).toInt() + 1
        for (r in 0 until rows) for (c in 0 until cols) {
            if ((r + c) % 2 == 0) drawRect(Color(0x12FFFFFF), Offset(c * sq, r * sq), Size(sq, sq))
        }
        drawRect(
            Brush.radialGradient(
                listOf(Color.Transparent, Color(0x66000000)),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = size.maxDimension * 0.8f,
            ),
        )
    }
}

// ─────────────────────────────────────────────────────────── Đường mòn uốn lượn

private val TrailShadow = Color(0x664A2E16)     // viền nâu mờ
private val TrailTop = Color(0xFFEBD59A)        // mặt đường be nhạt
private val LockedDotShadow = Color(0x59241A10)
private val LockedDot = Color(0xD9F0E6BE)
private val DotT = floatArrayOf(0.4f, 0.5f, 0.6f)

/**
 * Đoạn nối từ nút [level] xuống nút [level]−1, vẽ trong toạ độ CỤC BỘ của hàng (hàng cao itemH, rộng cả màn).
 * Catmull-Rom → cubicTo: C1 = P1 + (P2−P0)/6, C2 = P2 − (P3−P1)/6 ⇒ đường uốn mềm, tiếp tuyến liên tục.
 * Đã mở ([solid]): nét 8dp (+ viền mờ). Chưa mở: 3 chấm tròn trên đường cong.
 */
private fun DrawScope.drawTrail(path: Path, level: Int, solid: Boolean, m: MapMetrics) {
    if (level <= 1) return
    val trackW = m.trackW.toPx()
    val h = size.height
    val shift = m.nodeH.toPx() * FACE_SHIFT
    fun px(l: Int) = size.width / 2f + trackW * (levelXFrac(l) - 0.5f)
    fun py(k: Int) = h * (k + 0.5f) - shift
    val x0 = px(level + 1); val y0 = py(-1)
    val x1 = px(level);     val y1 = py(0)
    val x2 = px(level - 1); val y2 = py(1)
    val x3 = px(level - 2); val y3 = py(2)
    val c1x = x1 + (x2 - x0) / 6f; val c1y = y1 + (y2 - y0) / 6f
    val c2x = x2 - (x3 - x1) / 6f; val c2y = y2 - (y3 - y1) / 6f
    if (solid) {
        path.rewind()
        path.moveTo(x1, y1)
        path.cubicTo(c1x, c1y, c2x, c2y, x2, y2)
        translate(0f, 2.dp.toPx()) {
            drawPath(path, TrailShadow, style = Stroke(11.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        drawPath(path, TrailTop, style = Stroke(8.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    } else {
        val r = m.nodeW.toPx() * 0.045f
        for (t in DotT) {
            val u = 1f - t
            val bx = u * u * u * x1 + 3f * u * u * t * c1x + 3f * u * t * t * c2x + t * t * t * x2
            val by = u * u * u * y1 + 3f * u * u * t * c1y + 3f * u * t * t * c2y + t * t * t * y2
            drawCircle(LockedDotShadow, r, Offset(bx, by + 2.dp.toPx()))
            drawCircle(LockedDot, r, Offset(bx, by))
        }
    }
}

// ─────────────────────────────────────────────────────────── Cảnh vật (cuộn cùng thế giới bằng GPU)

/** [res] = drawable · [ratio] = rộng/cao của ảnh gốc. 9 vật đầu là bộ gốc; kf_* = Kenney Mini Forest, ka_* = Kenney Mini Arena (CC0, render 2.5D). */
internal enum class PropKind(val res: Int, val ratio: Float) {
    Tree(R.drawable.tree, 319f / 357f), House(R.drawable.house, 337f / 316f), Pond(R.drawable.pond, 456f / 334f),
    Bench(R.drawable.bench, 156f / 118f), Bush(R.drawable.bush, 146f / 131f), Rocks(R.drawable.rocks, 143f / 88f),
    Pine(R.drawable.pine, 169f / 242f), FlowersWhite(R.drawable.flowers_white, 164f / 116f), FlowersColor(R.drawable.flowers_color, 135f / 92f),

    // ── Kenney Mini Forest ──
    KfBridge(R.drawable.kf_bridge, 195f / 152f),
    KfBuildingPlatform(R.drawable.kf_building_platform, 250f / 206f),
    KfBuildingRoof(R.drawable.kf_building_roof, 272f / 249f),
    KfBuildingStructure(R.drawable.kf_building_structure, 224f / 264f),
    KfCharacterArcher(R.drawable.kf_character_archer, 106f / 141f),
    KfFence(R.drawable.kf_fence, 159f / 115f),
    KfFlag(R.drawable.kf_flag, 65f / 107f),
    KfLadder(R.drawable.kf_ladder, 72f / 156f),
    KfPatchDirt(R.drawable.kf_patch_dirt, 201f / 125f),
    KfPatchGrass(R.drawable.kf_patch_grass, 184f / 116f),
    KfPlant(R.drawable.kf_plant, 70f / 50f),
    KfPlatform(R.drawable.kf_platform, 191f / 117f),
    KfRocksHigh(R.drawable.kf_rocks_high, 201f / 250f),
    KfRocksLow(R.drawable.kf_rocks_low, 201f / 181f),
    KfRocksRamp(R.drawable.kf_rocks_ramp, 176f / 162f),
    KfStones(R.drawable.kf_stones, 161f / 115f),
    KfTarget(R.drawable.kf_target, 81f / 101f),
    KfTent(R.drawable.kf_tent, 259f / 243f),
    KfTree(R.drawable.kf_tree, 142f / 236f),
    KfTreeHigh(R.drawable.kf_tree_high, 130f / 282f),
    KfWeaponArrow(R.drawable.kf_weapon_arrow, 48f / 45f),
    KfWeaponBow(R.drawable.kf_weapon_bow, 30f / 68f),

    // ── Kenney Mini Arena (Starter Kit) ──
    KaBanner(R.drawable.ka_banner, 84f / 147f),
    KaBlock(R.drawable.ka_block, 224f / 201f),
    KaBorderCorner(R.drawable.ka_border_corner, 123f / 161f),
    KaBorderStraight(R.drawable.ka_border_straight, 187f / 156f),
    KaBricks(R.drawable.ka_bricks, 151f / 123f),
    KaCharacterSoldier(R.drawable.ka_character_soldier, 106f / 140f),
    KaColumn(R.drawable.ka_column, 125f / 204f),
    KaColumnDamaged(R.drawable.ka_column_damaged, 125f / 137f),
    KaFloor(R.drawable.ka_floor, 224f / 138f),
    KaFloorDetail(R.drawable.ka_floor_detail, 224f / 138f),
    KaStairs(R.drawable.ka_stairs, 224f / 201f),
    KaStairsCorner(R.drawable.ka_stairs_corner, 219f / 163f),
    KaStairsCornerInner(R.drawable.ka_stairs_corner_inner, 224f / 201f),
    KaStatue(R.drawable.ka_statue, 148f / 232f),
    KaTree(R.drawable.ka_tree, 106f / 259f),
    KaTrophy(R.drawable.ka_trophy, 81f / 102f),
    KaWall(R.drawable.ka_wall, 187f / 232f),
    KaWallCorner(R.drawable.ka_wall_corner, 138f / 237f),
    KaWallGate(R.drawable.ka_wall_gate, 187f / 232f),
    KaWeaponRack(R.drawable.ka_weapon_rack, 110f / 111f),
    KaWeaponSpear(R.drawable.ka_weapon_spear, 26f / 95f),
    KaWeaponSword(R.drawable.ka_weapon_sword, 28f / 65f),
}

/**
 * x, w: tỉ lệ so với [trackW] (bề rộng đường đi; trên điện thoại = chiều rộng màn), x tính từ mép trái đường đi · y: tỉ lệ so với chiều cao khối 16 level.
 * Mọi số đo ∝ trackW ⇒ bố cục giống hệt ở 360–520dp và không đè nhau ở mọi cỡ màn. Xếp từ trên xuống: vật thấp hơn vẽ đè lên.
 */
@Immutable
internal class Prop(val kind: PropKind, val x: Float, val y: Float, val w: Float, val mirror: Boolean = false) {
    /** Nằm hẳn ngoài đường đi (x < 0 hoặc x > 1) ⇒ chỉ dựng trên máy tính bảng, điện thoại bỏ qua cho nhẹ. */
    val isWing: Boolean = x + w < -0.02f || x > 1.02f
}

/**
 * BỐ CỤC GỐC (11 vật, thưa) – GIỮ LẠI, dùng khi USE_DENSE_SCENERY = false.
 * Đặt vào VÙNG TRỐNG của đường chữ S: đường lệch phải (level 9–11, 1–3) ⇒ trái là cây/ghế/đá/hoa;
 * đường lệch trái (level 13, 5) ⇒ phải là ao/nhà/hoa. Đã kiểm bằng mockup 360–800dp.
 */
/** true = bố cục dày 8 biến thể (SceneVariants); false = bố cục gốc [SceneProps]. */
private const val USE_DENSE_SCENERY = true

/**
 * Khối k dùng biến thể (3k + k/7) mod N. Hiệu hai khối kề nhau là 3 hoặc 4 (mod 8) ≠ 0 ⇒ KHÔNG BAO GIỜ hai khối liền kề giống nhau,
 * chu kỳ lặp dài; cuộn tới level 50.000 vẫn thấy cảnh luôn đổi.
 */
internal fun sceneVariantIndex(k: Int): Int = (k * 3 + k / 7) % SceneVariants.size

private val SceneProps = listOf(
    Prop(PropKind.Tree, x = -0.07f, y = 0.03f, w = 0.26f),
    Prop(PropKind.Bush, x = 0.87f, y = 0.11f, w = 0.16f),
    Prop(PropKind.FlowersWhite, x = 0.01f, y = 0.22f, w = 0.11f),
    Prop(PropKind.Pine, x = 0.88f, y = 0.27f, w = 0.12f),
    Prop(PropKind.Rocks, x = 0.0f, y = 0.40f, w = 0.12f),
    Prop(PropKind.Tree, x = 0.83f, y = 0.45f, w = 0.22f),
    Prop(PropKind.Bench, x = 0.0f, y = 0.58f, w = 0.16f),
    Prop(PropKind.Bush, x = 0.88f, y = 0.66f, w = 0.14f),
    Prop(PropKind.Pine, x = 0.0f, y = 0.72f, w = 0.12f),
    Prop(PropKind.FlowersColor, x = 0.88f, y = 0.80f, w = 0.11f),
    Prop(PropKind.Tree, x = -0.05f, y = 0.88f, w = 0.20f),
)

/**
 * Chỉ dựng tối đa 3 khối quanh vị trí cuộn; mỗi khối dịch bằng graphicsLayer.translationY lấy từ layoutInfo
 * (hàng đầu của khối = level k·16+16, index = topId − (k+1)·16 — có thể âm, vẫn hợp lệ).
 */
@Composable
private fun SceneryLayer(art: MapArt, listState: LazyListState, topId: Int, m: MapMetrics, screenW: Dp) {
    val blockH = m.itemH * SCENE_LEVELS
    val lastBlock = ((topId - 1) / SCENE_LEVELS).coerceAtLeast(0)
    val firstBlock by remember(listState, topId) {
        derivedStateOf { ((topId - listState.firstVisibleItemIndex - 1) / SCENE_LEVELS).coerceIn(0, lastBlock) }
    }
    for (k in (firstBlock - 1).coerceAtLeast(0)..(firstBlock + 1).coerceAtMost(lastBlock)) {
        key(k) { SceneryBlock(art, listState, k, topId, screenW, m.trackW, blockH) }
    }
}

@Composable
private fun SceneryBlock(art: MapArt, listState: LazyListState, k: Int, topId: Int, screenW: Dp, trackW: Dp, blockH: Dp) {
    val props = if (USE_DENSE_SCENERY) SceneVariants[sceneVariantIndex(k)] else SceneProps
    val wide = screenW > trackW + 1.dp          // chỉ máy tính bảng (màn > đường đi) mới có chỗ cho 2 cánh
    val left0 = (screenW - trackW) / 2          // mép trái đường đi
    Box(
        Modifier
            .wrapContentSize(Alignment.TopStart, unbounded = true)   // khối cao hơn màn hình vẫn neo đúng mép trên-trái
            .requiredSize(screenW, blockH)
            .graphicsLayer {
                val base = listState.layoutInfo.visibleItemsInfo.firstOrNull()
                if (base == null) {
                    alpha = 0f
                } else {
                    alpha = 1f
                    val topIndex = topId - (k + 1) * SCENE_LEVELS
                    translationY = listState.layoutInfo.beforeContentPadding + base.offset + (topIndex - base.index) * base.size.toFloat()
                }
            }
    ) {
        for (p in props) {
            if (p.isWing && !wide) continue
            val painter = art.props[p.kind] ?: continue
            Image(
                painter = painter,
                contentDescription = null,
                modifier = Modifier
                    .offset(x = left0 + trackW * p.x, y = blockH * p.y)
                    .width(trackW * p.w)
                    .aspectRatio(p.kind.ratio)
                    .then(if (p.mirror) Modifier.graphicsLayer { scaleX = -1f } else Modifier),
                contentScale = ContentScale.Fit,
            )
        }
    }
}

// ─────────────────────────────────────────────────────────── Nút gỗ

@Composable
private fun rememberPulse(): State<Float> =
    rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue",
    )

/**
 * Hoạt cảnh "vừa qua màn" của MỘT nút. Mọi giá trị là Animatable và chỉ được ĐỌC trong graphicsLayer / draw
 * ⇒ animation không gây recomposition. [play] suspend cho tới khi mọi hiệu ứng chạy xong.
 *  • hop   : độ lệch dọc của quân cờ, đơn vị = chiều cao nút (1 = nằm dưới nút, 0 = tâm nút, < 0 = bay cao hơn tâm)
 *  • scale : kích thước quân cờ, 0 → 1.2 → 1
 *  • glow  : cường độ vầng sáng quanh nút · ring: vòng sóng sáng lan ra
 */
@Stable
class NodeCelebration {
    val hop = Animatable(1f)
    val scale = Animatable(0f)
    val glow = Animatable(0f)
    val ring = Animatable(0f)
    val fade = Animatable(1f)   // độ hiện của quân Mã: giữ rồi mờ dần để trả lại số Level

    suspend fun play() {
        coroutineScope {
            // Nhảy: bật lên cao hơn tâm rồi rơi xuống; lò xo nảy vài nhịp mới lắng ⇒ chuyển động tự nhiên.
            launch {
                hop.animateTo(-0.45f, tween(260, easing = FastOutSlowInEasing))
                hop.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
            }
            // Hiện ra rực rỡ: 0 → 1.2 rồi về 1.
            launch {
                scale.animateTo(1.2f, tween(280, easing = FastOutSlowInEasing))
                scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
            }
            // Glow: bật nhanh – giữ – tắt dần.
            launch {
                glow.animateTo(1f, tween(240))
                delay(550)
                glow.animateTo(0f, tween(700))
            }
            // Vòng sóng sáng lan quanh nút.
            launch { ring.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
            launch { delay(900); fade.animateTo(0f, tween(300)) }
        }
    }
}

/** Vầng sáng vàng + vòng sóng lan quanh nút (nằm DƯỚI ảnh gỗ, tràn ra ngoài viền). Chỉ đọc Animatable trong draw. */
@Composable
private fun CelebrationGlow(c: NodeCelebration, nodeW: Dp, nodeH: Dp) {
    Canvas(Modifier.requiredSize(nodeW * 2.3f, nodeH * 2.3f)) {
        val g = c.glow.value
        if (g > 0.001f) {
            val r = size.minDimension / 2f
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xF2FFF1A8), Color(0xAAFFC933), Color(0x00FFC933)),
                    center = center,
                    radius = r,
                ),
                radius = r,
                center = center,
                alpha = g,
            )
        }
        val t = c.ring.value
        if (t > 0.001f && t < 0.999f) {
            val w = nodeW.toPx() * (1.1f + 0.9f * t)
            val h = w * NODE_ASPECT
            drawOval(
                color = Color(0xFFFFF3B0),
                topLeft = Offset(center.x - w / 2f, center.y - h / 2f),
                size = Size(w, h),
                alpha = 1f - t,
                style = Stroke(width = nodeW.toPx() * 0.05f),
            )
        }
    }
}

/** Số Level: chữ TO, ĐẬM, TRẮNG (có bóng nâu cho dễ đọc trên gỗ). Cỡ chữ theo cỡ nút và số chữ số, không theo fontScale hệ thống. */
@Composable
private fun LevelNumber(level: Int, nodeW: Dp, nodeH: Dp, modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val style = remember(level, nodeW, density) {
        TextStyle(
            fontSize = with(density) { (nodeW * numberFactor(level)).toSp() },
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            shadow = Shadow(Color(0xB33A1E08), Offset(0f, 4f), 6f),
        )
    }
    Text(
        level.toString(),
        style = style,
        maxLines = 1,
        softWrap = false,
        modifier = modifier.offset(y = -(nodeH * FACE_SHIFT)),
    )
}

/**
 * Quân Mã trên mặt nút. [celebration] ≠ null ⇒ nhảy + scale theo Animatable; null ⇒ đứng yên đúng vị trí/cỡ của khung cuối
 * animation ⇒ lúc ViewModel xoá justCompletedLevel, hình không giật.
 */
@Composable
private fun ChessPiece(painter: Painter, nodeW: Dp, nodeH: Dp, celebration: NodeCelebration?) {
    Image(
        painter = painter,
        contentDescription = null,
        modifier = Modifier
            .offset(y = -(nodeH * 0.13f))
            .requiredSize(nodeW * 0.56f)
            .graphicsLayer {
                if (celebration != null) {
                    translationY = celebration.hop.value * nodeH.toPx()
                    val s = celebration.scale.value
                    scaleX = s
                    scaleY = s
                    alpha = celebration.fade.value
                }
            },
        contentScale = ContentScale.Fit,
    )
}

/**
 * Nút gỗ: Box xếp chồng [glow] + ảnh wood_node + mặt nút + [CurrentPin].
 *  • Mặt nút: CHỈ số Level (Current / Locked). Nút đã xong (Done) thay số bằng quân Mã. Không còn ổ khoá, dấu tick hay chữ phụ.
 *  • Nhấn: pointerInput(detectTapGestures) → Animatable scale 0.9 → đọc trong graphicsLayer.
 *    Không có state "pressed" ⇒ không recomposition; width/height của layout KHÔNG đổi (chỉ scale ở tầng render).
 *  • Current: vòng sáng nhịp thở + ghim nhún (chỉ đổi alpha/scale/translation).
 *  • Locked: ảnh gỗ xám mờ, bỏ qua chạm.
 *  • [celebration] ≠ null: quân Mã nhảy lên từ dưới nút, scale 0 → 1.2 → 1, đè lên (làm mờ) số Level, kèm vầng sáng quanh nút.
 * Không có onGloballyPositioned trên từng nút (sẽ chạy lại mỗi frame cuộn): tâm nút trong root do màn hình tính lúc chạm.
 */
@Composable
fun WoodenNode(
    level: Int,
    state: NodeState,
    modifier: Modifier = Modifier,
    painter: Painter = painterResource(R.drawable.wood_node),
    piece: Painter = painterResource(R.drawable.piece_wn),
    nodeW: Dp = NodeW,
    celebration: NodeCelebration? = null,
    onClick: (() -> Unit)? = null,
    isHidden: () -> Boolean = { false },
) {
    val nodeH = nodeW * NODE_ASPECT
    val scope = rememberCoroutineScope()
    val press = remember { Animatable(1f) }
    val locked = state == NodeState.Locked
    val currentOnClick by rememberUpdatedState(onClick)
    val description = "Câu đố $level"
    val stateText = when (state) { NodeState.Done -> "Đã hoàn thành"; NodeState.Current -> "Hiện tại"; NodeState.Locked -> "Đã khoá" }

    fun fireClick() { currentOnClick?.invoke() }

    Box(
        modifier = modifier
            .requiredSize(nodeW, nodeH)   // nút cao hơn bước dọc ⇒ tràn ra ngoài hàng, xếp chồng kiểu isometric
            .graphicsLayer {
                val s = press.value
                scaleX = s
                scaleY = s
                alpha = if (isHidden()) 0f else 1f
            }
            .pointerInput(locked) {
                detectTapGestures(
                    onPress = {
                        scope.launch { press.animateTo(0.9f, spring(dampingRatio = 0.55f, stiffness = 800f)) }
                        tryAwaitRelease()
                        scope.launch { press.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 800f)) }
                    },
                    onTap = { if (!locked) fireClick() },
                )
            }
            .semantics(mergeDescendants = true) {
                role = Role.Button
                contentDescription = description
                stateDescription = stateText
                if (locked) disabled() else onClick { fireClick(); true }
            },
        contentAlignment = Alignment.Center,
    ) {
        val pulse = if (state == NodeState.Current) rememberPulse() else null

        if (pulse != null) {
            Box(
                Modifier
                    .requiredSize(nodeW * 1.9f, nodeH * 1.9f)
                    .graphicsLayer {
                        val p = pulse.value
                        alpha = 0.6f + 0.4f * p
                        scaleX = 1f + 0.08f * p
                        scaleY = 1f + 0.08f * p
                    }
                    .background(Brush.radialGradient(listOf(Color(0xCCFFE55C), Color(0x88A8E64A), Color(0x00A8E64A))))
            )
        }

        if (celebration != null) CelebrationGlow(celebration, nodeW, nodeH)

        Image(
            painter = painter,
            contentDescription = null,
            modifier = Modifier.matchParentSize().then(if (locked) Modifier.alpha(0.75f) else Modifier),
            contentScale = ContentScale.Fit,
            colorFilter = when (state) {
                NodeState.Locked -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0.1f) })   // khoá: xám
                NodeState.Done -> ColorFilter.tint(Color(0x557BC043), BlendMode.SrcAtop)                      // xong: ngả xanh
                NodeState.Current -> null
            },
        )

        when {
            celebration != null -> {
                // Quân cờ đáp xuống đè lên số: số mờ dần theo kích thước quân cờ.
                LevelNumber(level, nodeW, nodeH, Modifier.graphicsLayer { alpha = 1f - celebration.scale.value.coerceIn(0f, 1f) * celebration.fade.value })
                ChessPiece(piece, nodeW, nodeH, celebration)
            }
            else -> LevelNumber(level, nodeW, nodeH)
        }

        if (pulse != null) {
            CurrentPin(width = nodeW * 0.44f, pulse = pulse, modifier = Modifier.offset(y = -(nodeH * 0.62f)))
        }
    }
}

private val PinOrange = Color(0xFFF58A1F)

/** Ghim "bạn ở đây" vẽ bằng Canvas trên hệ toạ độ 40×48 rồi scale – không cần thêm asset; nhún bằng graphicsLayer. */
@Composable
private fun CurrentPin(width: Dp, pulse: State<Float>, modifier: Modifier = Modifier) {
    val tail = remember { Path().apply { moveTo(20f, 47f); lineTo(11f, 33f); lineTo(29f, 33f); close() } }
    val pawn = remember {
        Path().apply {
            moveTo(16.2f, 27.5f)
            cubicTo(16.6f, 23f, 18f, 20.5f, 20f, 19.6f)
            cubicTo(22f, 20.5f, 23.4f, 23f, 23.8f, 27.5f)
            close()
        }
    }
    Canvas(
        modifier
            .size(width, width * 1.2f)
            .graphicsLayer { translationY = -4.dp.toPx() * pulse.value }
    ) {
        scale(size.width / 40f, pivot = Offset.Zero) {
            drawPath(tail, Color.White)
            drawRoundRect(Color.White, Offset(2f, 2f), Size(36f, 36f), CornerRadius(9f))
            drawRoundRect(PinOrange, Offset(6f, 6f), Size(28f, 28f), CornerRadius(6f))
            drawCircle(Color.White, 4.6f, Offset(20f, 14f))
            drawPath(pawn, Color.White)
            drawRoundRect(Color.White, Offset(13.5f, 27.5f), Size(13f, 3.4f), CornerRadius(1.7f))
        }
    }
}

// ─────────────────────────────────────────────────────────── HUD trên

/**
 * HLV nằm góc trái, đặt theo % maxWidth: x = 2%, cao = 19% (headerH/coachH tính từ BoxWithConstraints).
 * Bong bóng chat chiếm phần còn lại của hàng.
 */
@Composable
private fun TopHud(level: Int, art: MapArt, screenW: Dp, topPad: Dp, coachH: Dp, headerH: Dp, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(headerH + 24.dp)) {
        val coachW = coachH * (349f / 290f)
        val bubbleX = screenW * 0.02f + coachW + 2.dp
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xE60E2616), Color(0x000E2616))))
        )
        Row(
            Modifier.fillMaxWidth().padding(top = topPad).height(TitleH),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Icon(Icons.Filled.Extension, null, tint = Color(0xFFD9A55B), modifier = Modifier.size(38.dp))
                Box(
                    Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF6B3F1D)),
                    contentAlignment = Alignment.Center,
                ) { Text(level.toString(), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
            }
            Spacer(Modifier.width(10.dp))
            Text("Câu đố", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Image(
            art.coach, contentDescription = "Huấn luyện viên",
            modifier = Modifier.offset(x = screenW * 0.02f, y = topPad + TitleH).height(coachH).aspectRatio(349f / 290f),
            contentScale = ContentScale.Fit,
        )
        SpeechBubble(
            text = "Đã đến lúc phải giải quyết!",
            modifier = Modifier
                .offset(x = bubbleX, y = topPad + TitleH + coachH * 0.28f)
                .width(screenW - bubbleX - screenW * 0.04f),
        )
    }
}

/** Bong bóng chat: Canvas vẽ hình chữ nhật bo góc + mũi nhọn bên trái chỉ vào HLV; Text nằm chồng lên. */
@Composable
private fun SpeechBubble(text: String, modifier: Modifier = Modifier) {
    val path = remember { Path() }
    Box(modifier.heightIn(min = 46.dp), contentAlignment = Alignment.CenterStart) {
        Canvas(Modifier.matchParentSize()) {
            val tail = 12.dp.toPx()
            val r = 16.dp.toPx()
            path.rewind()
            path.addRoundRect(RoundRect(tail, 0f, size.width, size.height, CornerRadius(r)))
            path.moveTo(tail + 2f, size.height * 0.30f)
            path.lineTo(0f, size.height * 0.50f)
            path.lineTo(tail + 2f, size.height * 0.70f)
            path.close()
            translate(0f, 3.dp.toPx()) { drawPath(path, Color(0x40000000)) }
            drawPath(path, Color.White)
        }
        Text(
            text,
            color = Color(0xFF222222),
            fontSize = 17.sp,
            modifier = Modifier.padding(start = 28.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
        )
    }
}

// ─────────────────────────────────────────────────────────── HUD dưới

@Composable
private fun BottomPanel(
    score: Int,
    streak: Int,
    progress: Float,
    onSolveClick: () -> Unit,
    bottomPad: Dp,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = bottomPad)
            .background(Brush.verticalGradient(listOf(Color(0x00102A18), Color(0xF0182E1E)), 0f, 120f))
            .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(score.toString(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.LocalFireDepartment, null, tint = Color(0xFFFF8A1F), modifier = Modifier.size(26.dp))
            Text(streak.toString(), color = Color(0xFFFF8A1F), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        ProgressBar(progress)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.FormatListBulleted, "Danh sách", tint = Color.White) }
            GameButton("Giải các câu đố", onSolveClick, Modifier.weight(1f))
        }
    }
}

/** ProgressBar: giá trị animate chỉ được đọc trong drawBehind ⇒ chạy mượt, không recomposition. */
@Composable
private fun ProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val anim = animateFloatAsState(progress.coerceIn(0.04f, 1f), tween(600), label = "progress")
    Box(
        modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                val w = size.width * anim.value
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFFFFA43A), Color(0xFFFF6A00)), 0f, w),
                    size = Size(w, size.height),
                    cornerRadius = CornerRadius(size.height / 2f),
                )
                drawRoundRect(
                    Color(0x66FFFFFF),
                    topLeft = Offset(5.dp.toPx(), 2.dp.toPx()),
                    size = Size((w - 10.dp.toPx()).coerceAtLeast(0f), 3.dp.toPx()),
                    cornerRadius = CornerRadius(1.5.dp.toPx()),
                )
            }
    )
}

/** Nút xanh lá 3D: lớp đáy tối + lớp mặt gradient; khi nhấn mặt trượt xuống bằng graphicsLayer. */
@Composable
private fun GameButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val dy = animateFloatAsState(if (pressed) 4f else 0f, label = "btnPress")
    val shape = RoundedCornerShape(18.dp)
    Box(modifier.height(62.dp)) {
        Box(Modifier.fillMaxWidth().height(56.dp).align(Alignment.BottomCenter).background(Color(0xFF4A7A1E), shape))
        Box(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .align(Alignment.TopCenter)
                .graphicsLayer { translationY = dy.value * density }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFFA5D955), Color(0xFF79B22E))))
                .clickable(interactionSource = interaction, indication = ripple(color = Color.White), onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
