package com.vila.chess.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.vila.chess.R

enum class Sfx { MOVE, CAPTURE, CASTLE, CHECK, PROMOTE, END }

class SoundPlayer(private val context: Context, pack: String = SoundPacks.DEFAULT) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private var ids = HashMap<Sfx, Int>()

    var enabled: Boolean = true

    var pack: String = SoundPacks.DEFAULT
        private set

    init {
        loadPack(if (SoundPacks.exists(pack)) pack else SoundPacks.DEFAULT)
    }

    private fun loadPack(id: String) {
        val fresh = HashMap<Sfx, Int>()
        for (sfx in Sfx.values()) {
            val res = SoundPacks.rawRes(context, id, sfx)
            if (res != 0) fresh[sfx] = pool.load(context, res, 1)
        }
        ids = fresh
        pack = id
    }

    /** Đổi bộ âm thanh (nạp bộ mới, bỏ bộ cũ). Tiếng nạp bất đồng bộ nên phát thử nên chờ ~100ms. */
    fun setPack(id: String) {
        if (id == pack || !SoundPacks.exists(id)) return
        val old = ids
        loadPack(id)
        for (v in old.values) pool.unload(v)
    }

    fun play(sfx: Sfx) {
        if (!enabled) return
        val id = ids[sfx] ?: return
        pool.play(id, 1f, 1f, 1, 0, 1f)
    }

    fun release() {
        pool.release()
    }
}

class Haptics(context: Context) {
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    var enabled: Boolean = true

    fun tick(strong: Boolean) {
        if (!enabled) return
        val v = vibrator ?: return
        try {
            val ms = if (strong) 22L else 10L
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, if (strong) 160 else 80))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) {
            // vibration is best-effort only
        }
    }
}
