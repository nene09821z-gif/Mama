package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.TimeControls
import com.vila.chess.game.timeGroups
import com.vila.chess.online.OnlinePhase
import kotlinx.coroutines.delay

private val LOBBY_SHAPE = RoundedCornerShape(12.dp)

/**
 * "Chơi online": màn RIÊNG để ghép trận với người chơi thật (không dính tới bàn cờ Bot).
 * Chọn thể loại giờ -> "Tìm đối thủ" -> khi có người ghép, ViewModel mở thẳng màn OnlineGameScreen.
 */
@Composable
fun OnlineLobbyScreen(vm: GameViewModel, onBack: () -> Unit) {
    val online = vm.online
    val searching = online.phase == OnlinePhase.SEARCHING
    val tc = TimeControls.get(vm.onlineTimeIndex)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    // Rời màn (hoặc màn bị đóng) thì ngừng tìm. Hàm tự bỏ qua khi không còn đang tìm (vd. đã có ván).
    DisposableEffect(Unit) { onDispose { vm.cancelOnlineSearch() } }
    LaunchedEffect(searching) {
        while (searching) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = Color(0xFFB9C1CE),
                )
            }
            Row(modifier = Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Public,
                    contentDescription = null,
                    tint = VilaColors.Green,
                    modifier = Modifier.size(28.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("Chơi online", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
        }

        Text(
            text = "Ghép trận với người chơi thật. Đồng hồ do máy chủ tính nên hai bên luôn khớp giờ. Cần đăng nhập Google.",
            color = VilaColors.TextDim,
            fontSize = 14.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp),
        )

        if (searching) {
            val elapsed = ((now - online.searchStartedAt) / 1000L).coerceAtLeast(0L)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .glass(LOBBY_SHAPE)
                    .padding(vertical = 28.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CircularProgressIndicator(color = VilaColors.Green, modifier = Modifier.size(44.dp), strokeWidth = 4.dp)
                Text("Đang tìm đối thủ…", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    text = tc.label + "  ·  " + (elapsed / 60) + ":" + (if (elapsed % 60 < 10) "0" else "") + (elapsed % 60),
                    color = VilaColors.TextDim,
                    fontSize = 15.sp,
                )
            }
            Spacer(Modifier.height(12.dp))
            LobbyButton("Hủy tìm trận", onClick = { vm.cancelOnlineSearch() })
        } else {
            // Thể loại giờ (không có "Không giới hạn": ván online luôn có đồng hồ)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
                    .glass(LOBBY_SHAPE)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                for (group in timeGroups()) {
                    val mode = group.first
                    val indices = group.second.filter { TimeControls.all[it].baseSec > 0 }
                    if (indices.isEmpty()) continue
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ModeIcon(mode, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(mode.label, color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        ChipGrid(
                            labels = indices.map { TimeControls.all[it].label },
                            selected = indices.indexOf(vm.onlineTimeIndex),
                            columns = 3,
                            onSelect = { vm.updateOnlineTimeIndex(indices[it]) },
                        )
                    }
                }
            }

            val error = online.error
            if (online.phase == OnlinePhase.ERROR && error != null) {
                Text(
                    text = error,
                    color = VilaColors.Danger,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp),
                )
            }

            ChunkyButton(
                text = if (online.phase == OnlinePhase.ERROR) "Thử lại" else "Tìm đối thủ · " + tc.label,
                onClick = { vm.startOnlineSearch() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 16.dp),
                height = 52.dp,
                edge = 4.dp,
                radius = 10.dp,
                fontSize = 20.sp,
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun LobbyButton(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .height(47.dp)
            .glass(LOBBY_SHAPE)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}
