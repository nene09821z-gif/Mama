package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.profile.EloPoint
import com.vila.chess.profile.EloRange
import com.vila.chess.profile.EloSeries
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Biểu đồ biến động Elo theo thời gian, vẽ hoàn toàn bằng Canvas (không thư viện ngoài).
 *  - Trục X tỉ lệ theo thời gian thật của khoảng [range] (7 ngày / 30 ngày / 1 năm), điểm cuối là hiện tại.
 *  - Chạm hoặc kéo ngang để xem Elo + thời điểm của từng mốc.
 *  - Chưa có dữ liệu → hiện trạng thái trống thay vì khung rỗng.
 */
@Composable
fun EloChart(
    history: List<EloPoint>,
    currentRating: Int,
    range: EloRange,
    modifier: Modifier = Modifier,
) {
    val now = remember(history, range) { System.currentTimeMillis() }
    val series = remember(history, range, currentRating, now) { EloSeries.window(history, range, now, currentRating) }
    if (series.isEmpty()) {
        EmptyEloChart(modifier)
        return
    }

    val start = now - range.days * EloSeries.DAY_MS
    val bounds = remember(series) { niceBounds(series) }
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    var selected by remember(series) { mutableStateOf<Int?>(null) }
    var widthPx by remember { mutableIntStateOf(0) }

    val leftPad = with(density) { 40.dp.toPx() }
    val rightPad = with(density) { 14.dp.toPx() }
    val topPad = with(density) { 14.dp.toPx() }
    val bottomPad = with(density) { 24.dp.toPx() }

    val dateFmt = remember { SimpleDateFormat(if (range == EloRange.YEAR) "MM/yyyy" else "dd/MM", Locale.getDefault()) }
    val tipFmt = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }
    val labelStyle = TextStyle(color = VilaColors.TextDim, fontSize = 10.sp)
    val tipStyle = TextStyle(color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)

    fun xOf(ts: Long, plotW: Float): Float = leftPad + ((ts - start).toFloat() / (now - start).toFloat()).coerceIn(0f, 1f) * plotW
    fun nearest(x: Float): Int {
        val plotW = widthPx - leftPad - rightPad
        var best = 0
        var bestD = Float.MAX_VALUE
        for (i in series.indices) {
            val d = abs(xOf(series[i].ts, plotW) - x)
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    val summary = "Biểu đồ Elo ${range.label}: từ ${series.first().rating} đến ${series.last().rating}"

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(190.dp)
            .semantics { contentDescription = summary }
            .onSizeChanged { widthPx = it.width }
            .pointerInput(series, widthPx) {
                detectTapGestures { off -> val i = nearest(off.x); selected = if (selected == i) null else i }
            }
            .pointerInput(series, widthPx) {
                detectHorizontalDragGestures(
                    onDragStart = { selected = nearest(it.x) },
                    onDragEnd = {},
                    onDragCancel = {},
                ) { change, _ ->
                    change.consume()
                    selected = nearest(change.position.x)
                }
            },
    ) {
        val plotW = size.width - leftPad - rightPad
        val plotH = size.height - topPad - bottomPad
        val (yMin, yMax) = bounds
        fun yOf(r: Int): Float = topPad + (1f - (r - yMin).toFloat() / (yMax - yMin).toFloat()) * plotH

        // --- Lưới ngang + nhãn trục Y (max / giữa / min)
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
        val ticks = listOf(yMax, (yMin + yMax) / 2, yMin)
        for (v in ticks) {
            val y = yOf(v)
            drawLine(Color(0x22FFFFFF), Offset(leftPad, y), Offset(size.width - rightPad, y), strokeWidth = 1.dp.toPx(), pathEffect = dash)
            val label = measurer.measure(v.toString(), labelStyle)
            drawText(label, topLeft = Offset(leftPad - label.size.width - 6.dp.toPx(), y - label.size.height / 2f))
        }

        // --- Nhãn trục X: đầu khoảng và "Hôm nay"
        val startLabel = measurer.measure(dateFmt.format(Date(start)), labelStyle)
        drawText(startLabel, topLeft = Offset(leftPad, size.height - bottomPad + 6.dp.toPx()))
        val endLabel = measurer.measure("Hôm nay", labelStyle)
        drawText(endLabel, topLeft = Offset(size.width - rightPad - endLabel.size.width, size.height - bottomPad + 6.dp.toPx()))

        // --- Đường + vùng tô gradient
        val pts = series.map { Offset(xOf(it.ts, plotW), yOf(it.rating)) }
        val line = Path().apply {
            moveTo(pts.first().x, pts.first().y)
            for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
        }
        val area = Path().apply {
            addPath(line)
            lineTo(pts.last().x, topPad + plotH)
            lineTo(pts.first().x, topPad + plotH)
            close()
        }
        drawPath(area, Brush.verticalGradient(listOf(VilaColors.Green.copy(alpha = 0.35f), Color.Transparent), startY = topPad, endY = topPad + plotH))
        drawPath(line, VilaColors.Green, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

        // --- Chấm cho từng mốc (ít điểm thì chấm rõ, nhiều điểm thì chỉ chấm cuối cho đỡ rối)
        if (pts.size <= 40) for (p in pts) drawCircle(VilaColors.Green, 3.dp.toPx(), p)
        drawCircle(Color.White, 5.dp.toPx(), pts.last())
        drawCircle(VilaColors.Green, 3.dp.toPx(), pts.last())

        // --- Điểm đang chọn + tooltip
        selected?.let { i ->
            val p = pts[i]
            val pt = series[i]
            drawLine(Color(0x66FFFFFF), Offset(p.x, topPad), Offset(p.x, topPad + plotH), strokeWidth = 1.dp.toPx())
            drawCircle(Color.White, 6.dp.toPx(), p)
            drawCircle(VilaColors.Green, 4.dp.toPx(), p)
            val tip = measurer.measure("${pt.rating} · ${tipFmt.format(Date(pt.ts))}", tipStyle)
            val padX = 8.dp.toPx()
            val padY = 5.dp.toPx()
            val bw = tip.size.width + padX * 2
            val bh = tip.size.height + padY * 2
            val bx = (p.x - bw / 2f).coerceIn(leftPad, size.width - rightPad - bw)
            val by = (p.y - bh - 10.dp.toPx()).let { if (it < 0f) p.y + 10.dp.toPx() else it }
            drawRoundRect(Color(0xE6101A2C), Offset(bx, by), Size(bw, bh), CornerRadius(8.dp.toPx()))
            drawText(tip, topLeft = Offset(bx + padX, by + padY))
        }
    }
}

/** Làm tròn khoảng Y ra số nguyên có đệm; khoảng quá hẹp (≈ phẳng) được nới ±10 để đường không dính trần. */
private fun niceBounds(series: List<EloPoint>): Pair<Int, Int> {
    val lo = series.minOf { it.rating }
    val hi = series.maxOf { it.rating }
    if (hi - lo < 20) {
        val mid = (hi + lo) / 2
        return (mid - 10) to (mid + 10)
    }
    val pad = (hi - lo) * 0.12
    return floor(lo - pad).toInt() to ceil(hi + pad).toInt()
}

@Composable
private fun EmptyEloChart(modifier: Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x14FFFFFF)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "Chưa đủ dữ liệu.\nChơi thêm vài ván để thấy biểu đồ Elo.",
            color = VilaColors.TextDim,
            fontSize = 14.sp,
            modifier = Modifier.padding(16.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
