package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Nhãn nước đi 2.5D (Brilliant … Blunder) vẽ hoàn toàn bằng vector trên Canvas:
 * đế nổi (vòng tròn tối lệch xuống) + mặt gradient + viền sáng + ký hiệu trắng có bóng đổ + vệt bóng ở trên.
 * KHÔNG dùng emoji / ký tự hệ thống nên giống nhau trên mọi máy Android và nét luôn mượt ở mọi kích thước.
 * Lưới thiết kế 48 x 52 (phần 52 gồm cả độ dày của đế).
 */

private val WhiteGlyph = Color.White

/** Dấu hỏi: nét cong dày bo tròn (dấu chấm vẽ riêng). */
private val QuesPath = Path().apply {
    moveTo(17.2f, 19.2f)
    cubicTo(17.2f, 14.8f, 20.2f, 12.2f, 24f, 12.2f)
    cubicTo(27.9f, 12.2f, 30.8f, 14.6f, 30.8f, 18.2f)
    cubicTo(30.8f, 21.2f, 28.9f, 22.6f, 27f, 24.1f)
    cubicTo(25.4f, 25.4f, 24.3f, 26.4f, 24.3f, 28.6f)
}

private val StarPath = Path().apply {
    for (i in 0 until 10) {
        val r = if (i % 2 == 0) 12.8f else 5.6f
        val a = (-90.0 + i * 36.0) * PI / 180.0
        val x = 24f + r * cos(a).toFloat()
        val y = 25f + r * sin(a).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

private val ThumbPath = Path().apply {
    moveTo(21.5f, 23f)
    lineTo(26.2f, 14f)
    cubicTo(27f, 12.5f, 29.3f, 12.7f, 29.7f, 14.4f)
    cubicTo(30.1f, 16.2f, 29.6f, 18.6f, 28.8f, 21.2f)
    lineTo(35.2f, 21.2f)
    cubicTo(37.6f, 21.2f, 39.2f, 23.4f, 38.6f, 25.6f)
    lineTo(36.6f, 33.6f)
    cubicTo(36f, 35.8f, 34.2f, 37.2f, 32f, 37.2f)
    lineTo(23.4f, 37.2f)
    cubicTo(22.3f, 37.2f, 21.5f, 36.4f, 21.5f, 35.3f)
    close()
}

private val BookLeft = Path().apply {
    moveTo(23f, 19f)
    cubicTo(19.5f, 16.4f, 15.4f, 15.8f, 11.8f, 16.6f)
    lineTo(11.8f, 32.4f)
    cubicTo(15.4f, 31.6f, 19.5f, 32.2f, 23f, 34.8f)
    close()
}

private val BookRight = Path().apply {
    moveTo(25f, 19f)
    cubicTo(28.5f, 16.4f, 32.6f, 15.8f, 36.2f, 16.6f)
    lineTo(36.2f, 32.4f)
    cubicTo(32.6f, 31.6f, 28.5f, 32.2f, 25f, 34.8f)
    close()
}

private val CheckPath = Path().apply {
    moveTo(14.5f, 25f)
    lineTo(21f, 31.5f)
    lineTo(33.5f, 17f)
}

private val CrossPath = Path().apply {
    moveTo(16.5f, 16.5f); lineTo(31.5f, 31.5f)
    moveTo(31.5f, 16.5f); lineTo(16.5f, 31.5f)
}

private fun DrawScope.excl(cx: Float, s: Float, col: Color) {
    withTransform({
        translate(cx, 24f)
        scale(s, s, Offset.Zero)
        translate(-24f, -24f)
    }) {
        drawRoundRect(col, Offset(21f, 10.5f), Size(6f, 15.5f), CornerRadius(3f, 3f))
        drawCircle(col, 3.5f, Offset(24f, 33f))
    }
}

private fun DrawScope.ques(cx: Float, s: Float, col: Color) {
    withTransform({
        translate(cx, 24f)
        scale(s, s, Offset.Zero)
        translate(-24.2f, -24f)
    }) {
        drawPath(QuesPath, col, style = Stroke(width = 5.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(col, 3.5f, Offset(24.3f, 35.2f))
    }
}

/** Ký hiệu của từng nhãn, một màu [col] (vẽ 2 lần: lần đầu màu tối làm bóng, lần sau màu trắng). */
private fun DrawScope.glyph(badge: LabelBadge, col: Color) {
    when (badge) {
        LabelBadge.BRILLIANT -> { excl(18.2f, 0.86f, col); excl(29.8f, 0.86f, col) }
        LabelBadge.GREAT -> excl(24f, 1f, col)
        LabelBadge.BEST -> {
            drawPath(StarPath, col)
            drawPath(StarPath, col, style = Stroke(width = 3f, join = StrokeJoin.Round))
        }
        LabelBadge.EXCELLENT -> {
            drawRoundRect(col, Offset(11.5f, 22.5f), Size(7f, 15f), CornerRadius(2.2f, 2.2f))
            drawPath(ThumbPath, col)
        }
        LabelBadge.GOOD -> drawPath(CheckPath, col, style = Stroke(width = 5.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        LabelBadge.BOOK -> { drawPath(BookLeft, col); drawPath(BookRight, col) }
        LabelBadge.INACCURACY -> { ques(18.4f, 0.8f, col); excl(31.4f, 0.8f, col) }
        LabelBadge.MISTAKE -> ques(24f, 1f, col)
        LabelBadge.BLUNDER -> { ques(17.6f, 0.74f, col); ques(30.4f, 0.74f, col) }
        LabelBadge.MISS -> drawPath(CrossPath, col, style = Stroke(width = 5.8f, cap = StrokeCap.Round))
    }
}

/**
 * Vẽ nhãn 2.5D vào ô vuông cạnh [box] px, góc trên-trái tại [topLeft]. Dùng được cả trong Canvas của bàn cờ
 * (không cần Composable con). [shadow] = bóng mờ dưới đế, tự tắt khi nhãn quá nhỏ.
 */
fun DrawScope.drawLabelBadge(badge: LabelBadge, topLeft: Offset, box: Float, shadow: Boolean = true) {
    val s = box / 52f
    val left = topLeft.x + (box - 48f * s) / 2f
    val c = badge.color
    val light = lerp(c, Color.White, 0.34f)
    val base = lerp(c, Color.Black, 0.16f)
    val dark = lerp(c, Color.Black, 0.42f)
    val showShadow = shadow && box >= 20.dp.toPx()
    withTransform({
        translate(left, topLeft.y)
        scale(s, s, Offset.Zero)
    }) {
        if (showShadow) drawOval(Color(0x47000000), Offset(7f, 47.3f), Size(34f, 4.4f))
        // Đế nổi
        drawCircle(dark, 22f, Offset(24f, 27.4f))
        // Mặt
        drawCircle(
            brush = Brush.verticalGradient(listOf(light, c, base), startY = 2f, endY = 46f),
            radius = 22f, center = Offset(24f, 24f),
        )
        // Viền sáng phía trên, tối nhẹ phía dưới
        drawCircle(
            brush = Brush.verticalGradient(listOf(Color(0xB3FFFFFF), Color(0x00FFFFFF), Color(0x38000000)), startY = 2f, endY = 46f),
            radius = 21.3f, center = Offset(24f, 24f), style = Stroke(width = 1.5f),
        )
        drawCircle(dark.copy(alpha = 0.22f), 17.6f, Offset(24f, 24f), style = Stroke(width = 1f))
        // Ký hiệu: bóng đổ rồi nét trắng
        withTransform({ translate(0f, 1.6f) }) { glyph(badge, dark.copy(alpha = 0.85f)) }
        glyph(badge, WhiteGlyph)
        // Vệt bóng
        drawOval(
            brush = Brush.verticalGradient(listOf(Color(0x9EFFFFFF), Color(0x00FFFFFF)), startY = 3.6f, endY = 18.8f),
            topLeft = Offset(9.5f, 3.6f), size = Size(29f, 15.2f),
        )
    }
}

/** Nhãn 2.5D hình tròn có ký hiệu (!!, ?, ??, ★…). Ô vuông [size]; phần đế nổi nằm gọn bên trong ô. */
@Composable
fun LabelGlyph(badge: LabelBadge, size: Dp = 28.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        drawLabelBadge(badge, Offset.Zero, this.size.minDimension)
    }
}
