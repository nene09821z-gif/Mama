package com.vila.chess.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.window.Dialog
import com.vila.chess.game.PremoveMode
import androidx.compose.ui.window.DialogProperties

/**
 * Gắn 2 màn lại với nhau: bottom sheet "Các tùy chọn" -> bấm "Các tùy chỉnh" -> mở màn cài đặt.
 * Dùng: đặt trong BotGameScreen, truyền visible = (đang mở menu).
 *
 *   var showOptions by remember { mutableStateOf(false) }
 *   BarItem("Tùy chọn", ...) { showOptions = true }
 *   GameOptionsHost(showOptions, onDismiss = { showOptions = false },
 *       onFlipBoard = { vm.flipBoard() }, onExplore = {}, onSaveGame = {})
 */
@Composable
fun GameOptionsHost(
    visible: Boolean,
    onDismiss: () -> Unit,
    onFlipBoard: () -> Unit,
    onExplore: () -> Unit,
    onSaveGame: () -> Unit,
    onOfferDraw: (() -> Unit)? = null,
    onNewGame: (() -> Unit)? = null,
    premoveMode: PremoveMode? = null,
    onPremoveModeChange: ((PremoveMode) -> Unit)? = null,
    moveLabelsOn: Boolean? = null,
    onMoveLabelsChange: ((Boolean) -> Unit)? = null,
) {
    var showSettings by rememberSaveable { mutableStateOf(false) }

    if (visible && !showSettings) {
        GameOptionsBottomSheet(
            onDismiss = onDismiss,
            onFlipBoard = onFlipBoard,
            onExplore = onExplore,
            onSaveGame = onSaveGame,
            onOfferDraw = onOfferDraw,
            onNewGame = onNewGame,
            onOpenSettings = { showSettings = true },
        )
    }
    if (visible && showSettings) {
        Dialog(
            onDismissRequest = { showSettings = false; onDismiss() },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
        ) {
            GameSettingsScreen(
                onClose = { showSettings = false; onDismiss() },
                premoveMode = premoveMode,
                onPremoveModeChange = onPremoveModeChange,
                moveLabelsOn = moveLabelsOn,
                onMoveLabelsChange = onMoveLabelsChange,
            )
        }
    }
}
