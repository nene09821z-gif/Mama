package com.vila.chess.ui

import android.content.Context
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import app.rive.runtime.kotlin.RiveAnimationView
import app.rive.runtime.kotlin.core.Fit
import app.rive.runtime.kotlin.core.Rive
import com.vila.chess.R
import com.vila.chess.coach.Mood
import kotlinx.coroutines.launch

/** Màu nhấn theo tâm trạng: viền avatar, viền bong bóng, tên thầy. */
fun Mood.accent(): Color = when (this) {
    Mood.CALM -> Color(0xFF9AA6BA)
    Mood.HAPPY -> Color(0xFF81B64C)
    Mood.PROUD -> Color(0xFFF2C14E)
    Mood.CHEER -> Color(0xFFFFD24D)
    Mood.WORRIED -> Color(0xFFF0A23B)
    Mood.ALARM -> Color(0xFFE05A47)
    Mood.THINK -> Color(0xFF6FA8F0)
    Mood.SAD -> Color(0xFF7A8AA8)
}

private fun Mood.glyph(): String = when (this) {
    Mood.CALM -> ""
    Mood.HAPPY -> "✓"
    Mood.PROUD, Mood.CHEER -> "★"
    Mood.WORRIED -> "?"
    Mood.ALARM -> "!"
    Mood.THINK, Mood.SAD -> "…"
}

/** Tên state machine trong file Rive (xem teacher_avatar.riv: "State Machine", listener Tap/Exit/Move). */
private const val RIVE_STATE_MACHINE = "State Machine"

private var riveReady: Boolean? = null

/** Khởi tạo Rive đúng một lần; false nếu máy/thư viện không chạy được => dùng ảnh tĩnh dự phòng. */
private fun ensureRive(context: Context): Boolean {
    riveReady?.let { return it }
    val ok = try {
        Rive.init(context.applicationContext)
        true
    } catch (t: Throwable) {
        false
    }
    riveReady = ok
    return ok
}

/**
 * Avatar thầy: ông thầy 2.5D của Rive (mắt nhìn theo con trỏ, nháy mắt, thở) cộng thêm:
 *  - viền + huy hiệu đổi theo tâm trạng,
 *  - nhún / rung / nhảy mỗi khi thầy có phản ứng mới,
 *  - mắt liếc về phía ô cờ thầy đang nói tới ([lookDx], [lookDy] trong -1..1),
 *  - chạm vào thầy => [onClick].
 */
@Composable
fun TeacherAvatar(
    mood: Mood,
    speaking: Boolean,
    reaction: Int,
    lookDx: Float,
    lookDy: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
) {
    val accent = mood.accent()
    val dx = remember { Animatable(0f) }
    val dy = remember { Animatable(0f) }
    val tilt = remember { Animatable(0f) }

    // Mỗi phản ứng mới = một điệu bộ theo tâm trạng.
    LaunchedEffect(reaction) {
        if (reaction == 0) return@LaunchedEffect
        when (mood) {
            Mood.CHEER, Mood.PROUD -> {
                launch { dy.animateTo(-10f, tween(110)); dy.animateTo(0f, tween(160)) }
                tilt.animateTo(-6f, tween(100)); tilt.animateTo(6f, tween(140)); tilt.animateTo(0f, tween(100))
            }
            Mood.ALARM -> {
                for (i in 0 until 3) { dx.animateTo(5f, tween(50)); dx.animateTo(-5f, tween(70)) }
                dx.animateTo(0f, tween(50))
            }
            Mood.WORRIED -> { tilt.animateTo(-5f, tween(180)); tilt.animateTo(0f, tween(260)) }
            Mood.SAD -> { dy.animateTo(4f, tween(260)); dy.animateTo(0f, tween(420)) }
            else -> { dy.animateTo(-3f, tween(90)); dy.animateTo(0f, tween(140)) }
        }
    }

    Box(
        modifier = modifier
            .size(size + 6.dp)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .graphicsLayer { translationX = dx.value; translationY = dy.value; rotationZ = tilt.value }
                .clip(CircleShape)
                .background(Color(0xFF1B2A44))
                .border(if (speaking) 3.dp else 2.dp, accent, CircleShape),
        ) {
            TeacherFace(lookDx, lookDy, Modifier.fillMaxSize())
        }
        val g = mood.glyph()
        if (g.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 2.dp, y = (-2).dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(accent),
                contentAlignment = Alignment.Center,
            ) {
                Text(g, color = Color(0xFF1B1B1B), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** Mặt thầy: Rive nếu chạy được, ngược lại ảnh tĩnh `R.drawable.coach`. */
@Composable
private fun TeacherFace(lookDx: Float, lookDy: Float, modifier: Modifier) {
    val ctx = LocalContext.current
    val ok = remember { ensureRive(ctx) }
    if (!ok) {
        StaticFace(modifier)
        return
    }
    var view by remember { mutableStateOf<RiveAnimationView?>(null) }
    AndroidView<View>(
        modifier = modifier,
        factory = { c ->
            try {
                RiveAnimationView(c).apply {
                    setRiveResource(
                        R.raw.teacher_avatar,
                        stateMachineName = RIVE_STATE_MACHINE,
                        fit = Fit.COVER,
                    )
                    view = this
                }
            } catch (t: Throwable) {
                View(c)
            }
        },
    )
    // "Pointer tracking" của file Rive đọc vị trí con trỏ: ta giả lập con trỏ đang chỉ về phía ô cờ thầy nhìn.
    LaunchedEffect(view, lookDx, lookDy) { view?.let { aimPointer(it, lookDx, lookDy) } }
}

@Composable
private fun StaticFace(modifier: Modifier) {
    Image(
        painter = painterResource(R.drawable.coach),
        contentDescription = "Thầy",
        contentScale = ContentScale.Crop,
        modifier = modifier.padding(0.dp),
    )
}

/** Đưa "con trỏ" của Rive tới điểm tương ứng hướng nhìn. Lỗi gì cũng nuốt: mất hiệu ứng liếc mắt chứ không sập app. */
private fun aimPointer(v: RiveAnimationView, dx: Float, dy: Float) {
    try {
        val w = v.width.toFloat()
        val h = v.height.toFloat()
        if (w <= 0f || h <= 0f) return
        val x = (w / 2f + dx.coerceIn(-1f, 1f) * w * 0.48f).coerceIn(1f, w - 1f)
        val y = (h / 2f + dy.coerceIn(-1f, 1f) * h * 0.48f).coerceIn(1f, h - 1f)
        val t = SystemClock.uptimeMillis()
        val ev = MotionEvent.obtain(t, t, MotionEvent.ACTION_MOVE, x, y, 0)
        v.dispatchTouchEvent(ev)
        ev.recycle()
    } catch (_: Throwable) {
    }
}
