package com.vila.chess.review

import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.Position
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveTo
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveUci
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue

/**
 * Nhận diện hy sinh quân bằng "vật chất sau khi đổi quân dứt điểm" (quiescence chỉ xét nước ăn quân).
 *
 *   S0 = vật chất của bên đi nếu họ "bỏ lượt" (đối thủ ăn tự do những gì ăn được)
 *   S1 = vật chất của bên đi sau khi đi nước m rồi hai bên ăn qua lại đến khi yên
 *   hy sinh = S0 − S1   (≥ ~2 tốt = đã cho đi quân)
 *
 * So với S0 (chứ không phải vật chất tĩnh) để quân đang bị treo từ trước mà bỏ mặc KHÔNG bị tính là hy sinh.
 */
object SacrificeDetector {
    /** Cho đi từ ngần này centipawn trở lên mới tính là hy sinh. */
    const val MIN_SACRIFICE_CP = 200
    private const val INF = 1_000_000
    private const val MAX_Q_PLY = 10

    /** Số centipawn bên đi cho đi bởi nước [uci] ở thế [fenBefore]. ≤ 0 = không hy sinh. */
    fun materialSacrificed(fenBefore: String, uci: String): Int {
        val pos = Position.fromFen(fenBefore)
        val mover = pos.whiteToMove
        val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci } ?: return 0

        val s0 = if (pos.inCheck()) {
            material(pos)
        } else {
            val pass = pos.copy()
            pass.whiteToMove = !mover
            pass.epSquare = -1
            -qs(pass, -INF, INF, MAX_Q_PLY)
        }
        pos.make(mv)
        val s1 = -qs(pos, -INF, INF, MAX_Q_PLY)
        return s0 - s1
    }

    fun isSacrifice(fenBefore: String, uci: String): Boolean =
        materialSacrificed(fenBefore, uci) >= MIN_SACRIFICE_CP

    /** Vật chất theo góc nhìn bên ĐANG ĐI của [pos] (tốt 100, mã 320, tượng 330, xe 500, hậu 900). */
    private fun material(pos: Position): Int {
        var white = 0
        var black = 0
        for (sq in 0 until 64) {
            val pc = pos.board[sq]
            if (pc == EMPTY) continue
            val v = pieceValue(pieceType(pc))
            if (isWhitePiece(pc)) white += v else black += v
        }
        return if (pos.whiteToMove) white - black else black - white
    }

    private fun isCapture(pos: Position, m: Int): Boolean =
        pos.board[moveTo(m)] != EMPTY || moveFlag(m) == FLAG_EP

    private fun qs(pos: Position, alpha0: Int, beta: Int, depth: Int): Int {
        var alpha = alpha0
        val stand = material(pos)
        if (depth <= 0 || stand >= beta) return stand
        if (stand > alpha) alpha = stand
        val caps = pos.legalMoves().filter { isCapture(pos, it) }
            .sortedByDescending { m ->
                val victim = if (moveFlag(m) == FLAG_EP) 100 else pieceValue(pieceType(pos.board[moveTo(m)]))
                victim * 10 + movePromo(m)
            }
        for (m in caps) {
            pos.make(m)
            val score = -qs(pos, -beta, -alpha, depth - 1)
            pos.unmake()
            if (score >= beta) return score
            if (score > alpha) alpha = score
        }
        return alpha
    }
}
