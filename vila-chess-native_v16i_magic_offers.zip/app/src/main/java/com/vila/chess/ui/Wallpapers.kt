package com.vila.chess.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Hình nền của app (tab "Hình nền" trong trang Chủ đề).
 * [top]/[mid]/[bottom] = gradient dọc; [glowA] góc dưới phải, [glowB] mép trái, [glowC] đỉnh; [stars] = có rải sao hay không.
 */
data class Wallpaper(
    val id: String,
    val label: String,
    val top: Color,
    val mid: Color,
    val bottom: Color,
    val glowA: Color,
    val glowB: Color,
    val glowC: Color,
    val stars: Boolean = true,
)

/** [current] là state của Compose: SpaceBackground đọc từ đây nên đổi hình nền là cả app đổi ngay. */
object Wallpapers {
    const val DEFAULT = "space"

    val all: List<Wallpaper> = listOf(
        Wallpaper("space", "Không gian", Color(0xFF0A1530), Color(0xFF10264A), Color(0xFF0A1226), Color(0x552F6FD0), Color(0x33A24FD0), Color(0x2238A1FF)),
        Wallpaper("aurora", "Cực quang", Color(0xFF04161C), Color(0xFF0B3A3F), Color(0xFF061A22), Color(0x5538D9A9), Color(0x3340C4FF), Color(0x2280FFC8)),
        Wallpaper("sunset", "Hoàng hôn", Color(0xFF1D0F2E), Color(0xFF4A1F4D), Color(0xFF1A0E22), Color(0x55FF7A45), Color(0x33D94F9B), Color(0x22FFB36B)),
        Wallpaper("night", "Đêm đen", Color(0xFF05060A), Color(0xFF0C0E16), Color(0xFF040509), Color(0x223A4A80), Color(0x1A5A4A8A), Color(0x112F3A5F)),
        Wallpaper("ocean", "Biển sâu", Color(0xFF031A2E), Color(0xFF06406B), Color(0xFF031524), Color(0x5531B5F0), Color(0x3320D0C0), Color(0x2260C8FF)),
        Wallpaper("forest", "Rừng đêm", Color(0xFF08160F), Color(0xFF12361F), Color(0xFF07120B), Color(0x5547B86B), Color(0x3380C060), Color(0x22A0E080)),
        Wallpaper("sakura", "Anh đào", Color(0xFF2A0F20), Color(0xFF5A1F44), Color(0xFF220C1A), Color(0x55FF7FB0), Color(0x33FFB0D0), Color(0x22FF99C0)),
        Wallpaper("nebula", "Thiên hà tím", Color(0xFF140A30), Color(0xFF2D1566), Color(0xFF0F0825), Color(0x558A5CFF), Color(0x33D04FD0), Color(0x226C7CFF)),
        Wallpaper("graphite", "Than chì", Color(0xFF1B1C1F), Color(0xFF26282C), Color(0xFF151618), Color(0x1AFFFFFF), Color(0x0FFFFFFF), Color(0x0CFFFFFF), stars = false),
        Wallpaper("ember", "Dung nham", Color(0xFF1F0A08), Color(0xFF4A140E), Color(0xFF190806), Color(0x55FF5A2A), Color(0x33FF9A2A), Color(0x22FF6A3A)),
    )

    fun exists(id: String): Boolean = all.any { it.id == id }

    fun byId(id: String): Wallpaper = all.firstOrNull { it.id == id } ?: all[0]

    var current: Wallpaper by mutableStateOf(all[0])
        private set

    fun select(id: String) {
        current = byId(id)
    }
}
