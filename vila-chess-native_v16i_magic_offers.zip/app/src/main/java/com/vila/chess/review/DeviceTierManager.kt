package com.vila.chess.review

import android.app.ActivityManager
import android.content.Context
import java.io.File

enum class DeviceTier { LOW, MEDIUM, HIGH }

/** Cấu hình engine cho một dòng máy. depth = TRẦN độ sâu; moveTimeoutMs = trần thời gian cho MỖI thế cờ. */
data class EngineConfig(
    val tier: DeviceTier,
    val depth: Int,
    val threads: Int,
    val hashMb: Int,
    val moveTimeoutMs: Long = 700L,
)

object DeviceTierManager {

    private const val GB = 1024.0 * 1024.0 * 1024.0

    /** Trần độ sâu của vòng kiểm chứng (depth + 4 không được vượt mức này). */
    const val MAX_DEPTH = 30

    /**
     * Tự nhận máy theo RAM thật + số nhân + xung nhịp nhân lớn nhất (đọc sysfs, không đọc được thì bỏ qua):
     *  - LOW    (RAM < 3GB / isLowRamDevice / CPU < 1,8GHz): depth 14–16, 1 thread, hash 16MB, 800ms/thế
     *  - MEDIUM (3–6GB):                                      depth 18–20, 2 thread, hash 64MB, 1300ms/thế
     *  - HIGH   (> 6GB):                                      depth 20–30, 4 thread, hash 128–256MB, 2000ms/thế
     * Depth chỉ là TRẦN; thời gian/thế là chốt chặn để phân tích luôn nhanh (tới mốc nào trước thì dừng).
     * Thế đơn giản/thế tàn cuộc chạm depth trần rất nhanh; thế phức tạp dừng theo thời gian.
     */
    fun getDeviceTier(context: Context): EngineConfig {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = info.totalMem / GB
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
        val mhz = maxCpuMhz()
        return configFor(ramGb, cores, mhz, am.isLowRamDevice)
    }

    /** Hàm thuần (test được trên JVM): chọn cấu hình từ thông số máy. [mhz] = 0 nếu không biết. */
    fun configFor(ramGb: Double, cores: Int, mhz: Int, lowRamFlag: Boolean = false): EngineConfig {
        val weakCpu = mhz in 1..1799
        val tier = when {
            lowRamFlag || ramGb < 3.0 || weakCpu -> DeviceTier.LOW
            ramGb <= 6.0 -> DeviceTier.MEDIUM
            else -> DeviceTier.HIGH
        }
        return when (tier) {
            DeviceTier.LOW -> EngineConfig(
                tier,
                depth = 14 + (if (cores >= 6) 1 else 0) + (if (ramGb >= 2.5) 1 else 0),   // 14–16
                threads = 1, hashMb = 16, moveTimeoutMs = 800L,
            )
            DeviceTier.MEDIUM -> EngineConfig(
                tier,
                depth = 18 + (if (cores >= 8) 1 else 0) + (if (mhz >= 2400) 1 else 0),    // 18–20
                threads = minOf(2, cores), hashMb = 64, moveTimeoutMs = 1300L,
            )
            DeviceTier.HIGH -> {
                var d = 20
                if (ramGb > 8.0) d += 2
                if (ramGb >= 12.0) d += 2
                if (cores >= 8) d += 2
                if (mhz >= 2800) d += 2
                if (mhz >= 3000) d += 2
                EngineConfig(
                    tier, depth = d.coerceIn(20, MAX_DEPTH),                                // 20–30
                    threads = minOf(4, cores), hashMb = if (ramGb > 8.0) 256 else 128, moveTimeoutMs = 2000L,
                )
            }
        }
    }

    /** Xung nhịp cao nhất của mọi nhân (MHz); 0 nếu máy không cho đọc. */
    private fun maxCpuMhz(): Int = runCatching {
        var best = 0L
        for (i in 0 until Runtime.getRuntime().availableProcessors().coerceAtMost(16)) {
            val f = File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq")
            if (f.canRead()) best = maxOf(best, f.readText().trim().toLongOrNull() ?: 0L)
        }
        (best / 1000L).toInt()   // kHz → MHz
    }.getOrDefault(0)
}
