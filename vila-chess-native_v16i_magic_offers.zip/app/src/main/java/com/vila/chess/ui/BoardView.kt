package com.vila.chess.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import com.vila.chess.coach.MarkKind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.PremoveMode
import com.vila.chess.game.UiState
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val LIFT = 0.45f        // quân đang kéo nằm cao hơn ngón tay chừng này ô (nhìn thấy quân dưới ngón)
private const val LIFT_SCALE = 0.15f  // nhấc lên: scale 1.15
private const val LIFT_SHADOW_DP = 14 // đổ bóng khi nhấc
private const val SETTLE_ACCEPT_MS = 95   // thả đúng nước: lướt vào ô cực nhanh (cảm giác hút, không nảy)
private const val SETTLE_BACK_MS = 150    // thả sai: trượt về chỗ cũ
private const val DRAG_SLOP_FACTOR = 0.3f // bắt đầu kéo gần như ngay khi ngón tay nhúc nhích

private const val DROP_GRACE_MS = 150L   // quân vừa nằm trên ô đích hợp lệ trong khoảng này trước khi nhấc tay => vẫn tính là thả vào đó
private const val DROP_SNAP = 0.62f       // thả sát mép ô đích hợp lệ (trong 0,62 ô tính từ tâm ô) => hút vào ô đó

/**
 * Chọn ô thả của quân đang kéo. Trả về ô đích hợp lệ nếu có, ngược lại trả ô dưới điểm nhấc tay (để báo thả sai).
 * Thứ tự: (1) ô dưới quân đang hiển thị, (2) ô dưới điểm nhấc tay, (3) ô đích hợp lệ vừa lướt qua ≤ [DROP_GRACE_MS],
 * (4) ô đích hợp lệ gần nhất trong bán kính [DROP_SNAP] ô.
 */
internal fun resolveDrop(
    shown: Offset,
    up: Offset,
    startSq: Int,
    targets: Set<Int>,
    boardPx: Float,
    flipped: Boolean,
    hoverTarget: Int,
    hoverAgeMs: Long,
): Int {
    fun ok(sq: Int) = sq != startSq && targets.contains(sq)
    val atShown = squareAt(shown, boardPx, flipped)
    if (ok(atShown)) return atShown
    val atUp = squareAt(up, boardPx, flipped)
    if (ok(atUp)) return atUp
    if (hoverTarget >= 0 && ok(hoverTarget) && hoverAgeMs in 0..DROP_GRACE_MS) return hoverTarget
    val s = boardPx / 8f
    var best = -1
    var bestD = DROP_SNAP * s
    for (t in targets) {
        if (t == startSq) continue
        val o = squareTopLeft(t, s, flipped)
        val d = (Offset(o.x + s / 2f, o.y + s / 2f) - shown).getDistance()
        if (d < bestD) { bestD = d; best = t }
    }
    return if (best >= 0) best else atUp
}

fun squareAt(p: Offset, boardPx: Float, flipped: Boolean): Int {
    val s = boardPx / 8f
    val col = (p.x / s).toInt().coerceIn(0, 7)
    val row = (p.y / s).toInt().coerceIn(0, 7)
    val file = if (flipped) 7 - col else col
    val rank = if (flipped) row else 7 - row
    return rank * 8 + file
}

/** Góc trên-trái của ô [sq] (px) trong bàn cờ cạnh [s]*8. Hàm thuần: dùng được trong graphicsLayer lẫn Canvas. */
internal fun squareTopLeft(sq: Int, s: Float, flipped: Boolean): Offset {
    val f = sq and 7
    val r = sq shr 3
    val col = if (flipped) 7 - f else f
    val row = if (flipped) r else 7 - r
    return Offset(col * s, row * s)
}

/** Bộ đệm vẽ mũi tên: tạo một lần, dùng lại mỗi frame (không cấp phát trong draw). */
private class ArrowScratch {
    val shaft = Path()
    val visible = Path()
    val measure = PathMeasure()
}

@Composable
fun BoardView(
    vm: GameViewModel,
    ui: UiState,
    images: Array<ImageBitmap?>,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    // ---- trượt quân (không kéo): Animatable tạo mới theo animToken nên frame đầu đã ở vị trí xuất phát, không nháy ----
    val slide = remember(ui.animToken) { Animatable(if (ui.slides.isNotEmpty()) 0f else 1f) }
    LaunchedEffect(slide) {
        if (slide.value < 1f) slide.animateTo(1f, tween(durationMillis = 150, easing = FastOutSlowInEasing))
    }

    // ---- mũi tên gợi ý vẽ dần ----
    val arrowP = remember { Animatable(0f) }
    LaunchedEffect(ui.hintFrom, ui.hintTo) {
        arrowP.snapTo(0f)
        if (ui.hintFrom >= 0 && ui.hintTo >= 0) arrowP.animateTo(1f, tween(durationMillis = 320, easing = FastOutSlowInEasing))
    }
    val scratch = remember { ArrowScratch() }

    // ---- trạng thái kéo / thả ----
    var dragSq by remember { mutableIntStateOf(-1) }          // ô gốc của quân đang kéo (-1 = không kéo)
    var hiddenSq by remember { mutableIntStateOf(-1) }        // ô mà Canvas không vẽ quân (lớp overlay vẽ thay)
    var overlayPiece by remember { mutableIntStateOf(0) }     // mã quân overlay (0 = không có)
    var fingerRaw by remember { mutableStateOf(Offset.Zero) }    // vị trí ngón tay thật; chỉ đọc trong graphicsLayer/draw (không recomposition)
    var liftPxState by remember { mutableFloatStateOf(0f) }      // độ nâng quân so với ngón tay (px) của lần kéo hiện tại
    var settling by remember { mutableStateOf(false) }
    var settleJob by remember { mutableStateOf<Job?>(null) }
    val settle = remember { Animatable(Offset.Zero, Offset.VectorConverter) }

    // Nhấc quân: scale 1.15 + bóng đổ, lò xo hơi nảy. Quay về 0 ngay khi thả (đang bay về ô thì quân hạ xuống).
    val lift by animateFloatAsState(
        targetValue = if (dragSq >= 0) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 650f),
        label = "pieceLift",
    )

    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    /**
     * Thả quân: bay [spring] hút vào tâm ô đích (đúng nước) hoặc [tween] 200ms trượt về chỗ cũ (sai / premove).
     * Mọi chuyển động là graphicsLayer.translation (GPU), không có Modifier.offset.
     */
    fun beginSettle(target: Offset, accepted: Boolean, hide: Int) {
        settleJob?.cancel()
        // Điểm bắt đầu = đúng vị trí quân đang hiển thị (đã tính độ nâng) => không giật khi thả.
        val from = Offset(fingerRaw.x, fingerRaw.y - liftPxState * lift.coerceIn(0f, 1f))
        hiddenSq = hide
        settling = true
        dragSq = -1
        // UNDISPATCHED: snapTo chạy ngay trong frame hiện tại, không để lọt 1 frame vẽ quân sai chỗ.
        settleJob = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            settle.snapTo(from)
            if (accepted) {
                settle.animateTo(target, tween(durationMillis = SETTLE_ACCEPT_MS, easing = FastOutSlowInEasing))
            } else {
                settle.animateTo(target, tween(durationMillis = SETTLE_BACK_MS, easing = FastOutSlowInEasing))
            }
            // Phong cấp: giữ quân trên ô đích tới khi người chơi chọn xong.
            if (vm.ui.promotion != null) snapshotFlow { vm.ui.promotion }.first { it == null }
            settling = false
            hiddenSq = -1
            overlayPiece = 0
        }
    }

    BoxWithConstraints(modifier = modifier.aspectRatio(1f)) {
        val boardPx = constraints.maxWidth.toFloat()
        val s = boardPx / 8f
        val sDp = with(density) { s.toDp() }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    val slop = viewConfiguration.touchSlop * DRAG_SLOP_FACTOR
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        // Chạm mới: kết thúc ngay hiệu ứng thả còn dang dở.
                        settleJob?.cancel()
                        settling = false
                        hiddenSq = -1
                        overlayPiece = 0

                        val bp = size.width.toFloat()
                        val sq = bp / 8f
                        val flipped = vm.ui.flipped
                        val liftPx = sq * LIFT
                        liftPxState = liftPx
                        val startSq = squareAt(down.position, bp, flipped)
                        val wasSelected = vm.ui.selected == startSq
                        val startPiece = vm.ui.board[startSq]
                        val picked = vm.pressSquare(startSq)
                        var dragging = false
                        var released = false
                        // Vị trí quân hiển thị ở lần di chuyển cuối + ô đích hợp lệ gần nhất mà quân vừa đi qua (để thả "dính").
                        var lastCenter = Offset(down.position.x, down.position.y - liftPx)
                        var hoverTarget = -1
                        var hoverAt = 0L
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            val center = Offset(change.position.x, change.position.y - liftPx)
                            if (!change.pressed) {
                                if (dragging) {
                                    released = true
                                    // Ô đích tính LẠI theo lượt hiện tại: đối thủ có thể vừa đi giữa lúc ngón tay đang kéo
                                    // (ui.targets cũ đã bị xóa => trước đây thả tay là quân nhảy về chỗ cũ).
                                    val tg = vm.dragTargets(startSq)
                                    // Chốt ô thả: ưu tiên chỗ quân đang HIỂN THỊ (người chơi thấy quân nằm đúng quân địch thì phải ăn được),
                                    // rồi tới điểm nhấc tay, rồi ô đích vừa lướt qua trong vòng DROP_GRACE_MS (ngón tay hay trượt khi nhấc).
                                    val drop = resolveDrop(
                                        shown = lastCenter, up = center, startSq = startSq,
                                        targets = tg, boardPx = bp, flipped = flipped,
                                        hoverTarget = hoverTarget, hoverAgeMs = change.uptimeMillis - hoverAt,
                                    )
                                    fingerRaw = change.position
                                    // true = nước đi / premove được nhận. Đi trước (Nhiều lẫn Đơn): premove hợp lệ "dính" ở ô đích
                                    // (bàn cờ ảo đã đặt quân ở đó) – quân không nhảy về chỗ cũ.
                                    // HAPTIC/SOUND (thả thành công): vm.releaseDrag -> announce() đã gọi đúng lúc nước đi được commit.
                                    val accepted = vm.releaseDrag(startSq, drop)
                                    if (accepted) {
                                        val hide = if (vm.ui.promotion != null) startSq else drop
                                        val o = squareTopLeft(drop, sq, flipped)
                                        beginSettle(Offset(o.x + sq / 2f, o.y + sq / 2f), accepted = true, hide = hide)
                                    } else if (vm.ui.board[startSq] != startPiece) {
                                        // Quân đang kéo vừa bị đối thủ ăn: không vẽ quân "ma" bay về ô cũ.
                                        overlayPiece = 0
                                        hiddenSq = -1
                                    } else {
                                        val o = squareTopLeft(startSq, sq, flipped)
                                        beginSettle(Offset(o.x + sq / 2f, o.y + sq / 2f), accepted = false, hide = startSq)
                                    }
                                } else if (picked && wasSelected) {
                                    vm.deselect()
                                }
                                break
                            }
                            if (picked) {
                                if (!dragging && (change.position - down.position).getDistance() > slop) {
                                    dragging = true
                                    overlayPiece = startPiece
                                    hiddenSq = startSq
                                    fingerRaw = change.position
                                    dragSq = startSq
                                    // HAPTIC (bắt đầu kéo): Light Impact. TextHandleMove là rung nhẹ nhất có sẵn trong Compose;
                                    // muốn "impact" thật dùng View.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                                    // hoặc VibrationEffect.EFFECT_TICK (API 29+).
                                    if (vm.hapticOn) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                }
                                if (dragging) {
                                    fingerRaw = change.position   // chỉ ghi state; graphicsLayer đọc ở pha draw => không recomposition
                                    lastCenter = center
                                    val over = squareAt(center, bp, flipped)
                                    if (over != startSq && vm.ui.targets.contains(over)) {
                                        hoverTarget = over
                                        hoverAt = change.uptimeMillis
                                    }
                                    change.consume()
                                }
                            }
                        }
                        // Cử chỉ bị hệ thống huỷ khi đang kéo: đưa quân về chỗ cũ.
                        if (dragging && !released) {
                            val o = squareTopLeft(startSq, sq, flipped)
                            beginSettle(Offset(o.x + sq / 2f, o.y + sq / 2f), accepted = false, hide = startSq)
                        }
                    }
                }
        ) {
            drawBoard(
                ui = ui,
                images = images,
                slideValue = slide.value,
                hiddenSq = hiddenSq,
                hoverCenter = null,
                labelPaint = labelPaint,
                arrowProgress = arrowP.value,
                scratch = scratch,
            )
        }

        // ================= LỚP OVERLAY (graphicsLayer / GPU) =================

        // Quân đang trượt (đi bằng chạm hoặc nước của máy): vị trí nội suy trong graphicsLayer.
        for (sl in ui.slides) {
            key(sl.to, sl.from) {
                val code = ui.board[sl.to]
                val img = images.getOrNull(code)
                if (code != 0 && img != null) {
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        filterQuality = FilterQuality.High,
                        modifier = Modifier
                            .size(sDp)
                            .graphicsLayer {
                                val t = slide.value
                                val a = squareTopLeft(sl.from, s, ui.flipped)
                                val b = squareTopLeft(sl.to, s, ui.flipped)
                                translationX = a.x + (b.x - a.x) * t
                                translationY = a.y + (b.y - a.y) * t
                                alpha = if (t < 1f) 1f else 0f   // t = 1: Canvas đã vẽ quân ở ô đích
                            },
                    )
                }
            }
        }

        // Quân bị ăn: mờ dần + thu nhỏ về 0 trong 150ms rồi mới biến mất.
        if (ui.captureSq >= 0 && ui.captureToken > 0) {
            key(ui.captureToken) {
                CaptureGhost(
                    image = images.getOrNull(ui.capturePiece),
                    topLeft = squareTopLeft(ui.captureSq, s, ui.flipped),
                    sizeDp = sDp,
                )
            }
        }

        // Nhãn chất lượng nước vừa đi (!!, ?, ??…) ở góc trên-phải ô đích, kiểu chess.com. Chỉ hiện khi nước MỚI NHẤT đã có nhãn.
        val moveLabel = if (ui.lastTo >= 0 && ui.sans.isNotEmpty()) ui.moveLabels.getOrNull(ui.sans.size - 1) else null
        if (moveLabel != null) {
            val d = sDp * 0.5f
            val dPx = s * 0.5f
            val o = squareTopLeft(ui.lastTo, s, ui.flipped)
            val bx = (o.x + s - dPx * 0.9f).coerceIn(0f, boardPx - dPx)
            val by = (o.y - dPx * 0.1f).coerceIn(0f, boardPx - dPx)
            // Nảy lên bằng lò xo mỗi khi có nước mới (key theo số nước + nhãn), không làm vẽ lại cả bàn cờ.
            val pop = remember(ui.sans.size, moveLabel) { Animatable(0.25f) }
            LaunchedEffect(ui.sans.size, moveLabel) {
                pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 420f))
            }
            LabelGlyph(
                badge = moveLabel.badge(),
                size = d,
                modifier = Modifier
                    .offset { IntOffset(bx.roundToInt(), by.roundToInt()) }
                    .graphicsLayer {
                        scaleX = pop.value
                        scaleY = pop.value
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.3f, 0.7f)
                    },
            )
        }

        // Vòng sáng ô đang rê qua + quầng tròn mờ dưới quân đang kéo (giống chess.com). Vẽ ở Canvas riêng nên
        // mỗi cú rê ngón tay KHÔNG làm vẽ lại cả bàn cờ.
        if (dragSq >= 0) {
            Canvas(Modifier.fillMaxSize()) {
                val liftNow = lift.coerceIn(0f, 1f)
                val c = Offset(fingerRaw.x, fingerRaw.y - liftPxState * liftNow)
                val hover = squareAt(c, size.width, ui.flipped)
                if (hover >= 0 && ui.targets.contains(hover)) {
                    val o = squareTopLeft(hover, s, ui.flipped)
                    drawRect(
                        color = Color(0xB3FFFFFF),
                        topLeft = Offset(o.x + s * 0.03f, o.y + s * 0.03f),
                        size = Size(s * 0.94f, s * 0.94f),
                        style = Stroke(width = s * 0.06f),
                    )
                }
                drawCircle(color = Color(0x33000000), radius = s * 0.95f * liftNow, center = c)
            }
        }

        // Quân đang kéo / đang bay về ô: dính ngón tay bằng translation, nhấc lên scale 1.15 + bóng đổ.
        val dragImg = if (overlayPiece != 0) images.getOrNull(overlayPiece) else null
        if (dragImg != null) {
            Image(
                bitmap = dragImg,
                contentDescription = null,
                filterQuality = FilterQuality.High,
                modifier = Modifier
                    .size(sDp)
                    .graphicsLayer {
                        val p = if (settling) settle.value
                        else Offset(fingerRaw.x, fingerRaw.y - liftPxState * lift.coerceIn(0f, 1f))
                        translationX = p.x - s / 2f
                        translationY = p.y - s / 2f
                        val k = 1f + LIFT_SCALE * lift
                        scaleX = k
                        scaleY = k
                        // Không dùng shadowElevation: bóng GPU dựng lại mỗi frame làm khựng máy yếu; quầng tròn mờ ở Canvas bên trên đã thay thế.
                    },
            )
        }
    }
}

/** Quân bị ăn: Animatable alpha/scale 1 -> 0 trong 150ms, tất cả qua graphicsLayer. */
@Composable
private fun CaptureGhost(image: ImageBitmap?, topLeft: Offset, sizeDp: androidx.compose.ui.unit.Dp) {
    if (image == null) return
    val p = remember { Animatable(1f) }
    var gone by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        p.animateTo(0f, tween(durationMillis = 150, easing = FastOutSlowInEasing))
        gone = true
    }
    if (gone) return
    Image(
        bitmap = image,
        contentDescription = null,
        filterQuality = FilterQuality.High,
        modifier = Modifier
            .size(sizeDp)
            .graphicsLayer {
                translationX = topLeft.x
                translationY = topLeft.y
                scaleX = p.value
                scaleY = p.value
                alpha = p.value
            },
    )
}

private fun DrawScope.drawBoard(
    ui: UiState,
    images: Array<ImageBitmap?>,
    slideValue: Float,
    hiddenSq: Int,
    hoverCenter: Offset?,
    labelPaint: Paint,
    arrowProgress: Float,
    scratch: ArrowScratch,
) {
    val s = size.width / 8f
    val flipped = ui.flipped

    fun topLeft(sq: Int): Offset = squareTopLeft(sq, s, flipped)

    fun center(sq: Int): Offset {
        val o = topLeft(sq)
        return Offset(o.x + s / 2f, o.y + s / 2f)
    }

    fun tint(sq: Int, color: Color) {
        drawRect(color = color, topLeft = topLeft(sq), size = Size(s, s))
    }

    fun piece(code: Int, o: Offset, sz: Float) {
        val img = images[code] ?: return
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = IntOffset(o.x.roundToInt(), o.y.roundToInt()),
            dstSize = IntSize(sz.roundToInt(), sz.roundToInt()),
            filterQuality = FilterQuality.High
        )
    }

    // squares
    for (sq in 0 until 64) {
        val light = ((sq shr 3) + (sq and 7)) % 2 == 1
        tint(sq, if (light) VilaColors.BoardLight else VilaColors.BoardDark)
    }

    // highlights
    if (ui.lastFrom >= 0) {
        tint(ui.lastFrom, VilaColors.Highlight)
        tint(ui.lastTo, VilaColors.Highlight)
    }
    if (ui.selected >= 0) tint(ui.selected, VilaColors.Highlight)
    if (ui.hintFrom >= 0 && ui.hintTo >= 0) {
        tint(ui.hintFrom, Color(0x663E9BEA))
        tint(ui.hintTo, Color(0x663E9BEA))
    }
    // Premove kiểu chess.com: tô đỏ cả đường đi (ô đi → ô đến), càng gần ô đến càng đậm.
    for (pm in ui.premoves) {
        val path = premovePath(pm.from, pm.to)
        for ((k, sq) in path.withIndex()) {
            val t = (k + 1f) / path.size
            tint(sq, VilaColors.PremoveRed.copy(alpha = 0.35f + 0.40f * t))
        }
    }
    if (ui.checkSquare >= 0) {
        val c = center(ui.checkSquare)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xE6FF2A2A), Color(0x00E70000)),
                center = c,
                radius = s * 0.75f
            ),
            radius = s * 0.75f,
            center = c
        )
    }

    // coordinates
    drawIntoCanvas { canvas ->
        labelPaint.textSize = s * 0.2f
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val col = if (flipped) 7 - f else f
            val row = if (flipped) r else 7 - r
            val light = (r + f) % 2 == 1
            val textColor = if (light) VilaColors.BoardDark else VilaColors.BoardLight
            labelPaint.color = textColor.toArgb()
            if (col == 0) {
                labelPaint.textAlign = Paint.Align.LEFT
                canvas.nativeCanvas.drawText(('1' + r).toString(), col * s + s * 0.06f, row * s + s * 0.24f, labelPaint)
            }
            if (row == 7) {
                labelPaint.textAlign = Paint.Align.RIGHT
                canvas.nativeCanvas.drawText(('a' + f).toString(), col * s + s - s * 0.06f, row * s + s - s * 0.08f, labelPaint)
            }
        }
    }

    // move hints
    for (sq in ui.targets) {
        val c = center(sq)
        if (ui.board[sq] != 0) {
            drawCircle(
                color = Color(0x2E000000),
                radius = s * 0.43f,
                center = c,
                style = Stroke(width = s * 0.09f)
            )
        } else {
            drawCircle(color = Color(0x2E000000), radius = s * 0.17f, center = c)
        }
    }

    // pieces (quân đang trượt / đang kéo do lớp overlay vẽ)
    val sliding = ui.slides.isNotEmpty() && slideValue < 1f
    for (sq in 0 until 64) {
        val pc = ui.board[sq]
        if (pc == 0 || sq == hiddenSq) continue
        if (sliding && ui.slides.any { it.to == sq }) continue
        piece(pc, topLeft(sq), s)
    }

    // coach arrow: vẽ dần bằng PathMeasure từ ô xuất phát tới ô đích
    if (ui.hintFrom >= 0 && ui.hintTo >= 0 && arrowProgress > 0.01f) {
        val a = center(ui.hintFrom)
        val b = center(ui.hintTo)
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len = sqrt(dx * dx + dy * dy)
        if (len > 0f) {
            val ux = dx / len
            val uy = dy / len
            val head = s * 0.34f
            val start = Offset(a.x + ux * s * 0.2f, a.y + uy * s * 0.2f)
            val base = Offset(b.x - ux * head, b.y - uy * head)
            val arrow = Color(0xCC2D8CFF)
            val p = arrowProgress.coerceIn(0f, 1f)

            scratch.shaft.reset()
            scratch.shaft.moveTo(start.x, start.y)
            scratch.shaft.lineTo(base.x, base.y)
            scratch.measure.setPath(scratch.shaft, false)
            scratch.visible.reset()
            val shaftLen = scratch.measure.length
            scratch.measure.getSegment(0f, shaftLen * p, scratch.visible, true)
            drawPath(
                path = scratch.visible,
                color = arrow,
                style = Stroke(width = s * 0.16f, cap = StrokeCap.Round)
            )

            // đầu mũi tên bám theo đầu nét vẽ, to dần tới kích thước đầy đủ
            val hs = min(1f, p * 3f)
            val tipBase = Offset(start.x + ux * shaftLen * p, start.y + uy * shaftLen * p)
            val h = head * hs
            val tip = Path()
            tip.moveTo(tipBase.x + ux * h, tipBase.y + uy * h)
            tip.lineTo(tipBase.x - uy * h * 0.75f, tipBase.y + ux * h * 0.75f)
            tip.lineTo(tipBase.x + uy * h * 0.75f, tipBase.y - ux * h * 0.75f)
            tip.close()
            drawPath(tip, arrow)
        }
    }

    // dấu của thầy: vòng tròn quanh ô cần chú ý, mũi tên chỉ hướng dọa
    for (m in ui.teacherMarks) {
        when (m.kind) {
            MarkKind.CIRCLE -> {
                val c = center(m.from)
                drawCircle(color = Color(0x33FFC93C), radius = s * 0.46f, center = c)
                drawCircle(color = Color(0xE6FFC93C), radius = s * 0.44f, center = c, style = Stroke(width = s * 0.07f))
            }
            MarkKind.ARROW -> if (m.to >= 0) {
                val a = center(m.from)
                val b = center(m.to)
                val dx = b.x - a.x
                val dy = b.y - a.y
                val len = sqrt(dx * dx + dy * dy)
                if (len > 0f) {
                    val ux = dx / len
                    val uy = dy / len
                    val head = s * 0.30f
                    val col = Color(0xCCFFB020)
                    val start = Offset(a.x + ux * s * 0.28f, a.y + uy * s * 0.28f)
                    val base = Offset(b.x - ux * head, b.y - uy * head)
                    drawLine(col, start, base, strokeWidth = s * 0.12f, cap = StrokeCap.Round)
                    val tip = Path()
                    tip.moveTo(b.x - ux * s * 0.08f, b.y - uy * s * 0.08f)
                    tip.lineTo(base.x - uy * head * 0.7f, base.y + ux * head * 0.7f)
                    tip.lineTo(base.x + uy * head * 0.7f, base.y - ux * head * 0.7f)
                    tip.close()
                    drawPath(tip, col)
                }
            }
        }
    }

    // vòng sáng ô đang rê qua khi kéo
    if (hoverCenter != null) {
        val hover = squareAt(hoverCenter, size.width, flipped)
        if (ui.targets.contains(hover)) {
            val o = topLeft(hover)
            drawRect(
                color = Color(0xB3FFFFFF),
                topLeft = Offset(o.x + s * 0.03f, o.y + s * 0.03f),
                size = Size(s * 0.94f, s * 0.94f),
                style = Stroke(width = s * 0.06f)
            )
        }
    }
}

/** Các ô trên đường đi của một nước premove (gồm ô đi và ô đến) nếu đi thẳng/chéo; nước Mã chỉ gồm 2 ô. */
internal fun premovePath(from: Int, to: Int): List<Int> {
    val df = (to and 7) - (from and 7)
    val dr = (to shr 3) - (from shr 3)
    val adf = if (df < 0) -df else df
    val adr = if (dr < 0) -dr else dr
    if (!(df == 0 || dr == 0 || adf == adr)) return listOf(from, to)
    val sf = if (df > 0) 1 else if (df < 0) -1 else 0
    val sr = if (dr > 0) 1 else if (dr < 0) -1 else 0
    val out = ArrayList<Int>()
    var f = from and 7
    var r = from shr 3
    while (true) {
        val sq = r * 8 + f
        out.add(sq)
        if (sq == to) break
        f += sf
        r += sr
    }
    return out
}
