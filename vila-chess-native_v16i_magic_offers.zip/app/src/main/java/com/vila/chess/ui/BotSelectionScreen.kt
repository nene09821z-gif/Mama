package com.vila.chess.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.bots.BotProfile
import com.vila.chess.bots.BotRepository
import com.vila.chess.game.GameViewModel

/** Chọn đối thủ: lưới 2 cột các Bot. Chạm một Bot -> vào BotGameScreen với engine cấu hình theo Elo của Bot đó. */
@Composable
fun BotSelectionScreen(vm: GameViewModel, onBack: () -> Unit) {
    // Mục nào đã chạy hiệu ứng xuất hiện thì cuộn ra/vào không chạy lại (mượt, đỡ tốn GPU).
    val seen = remember { mutableSetOf<Int>() }
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        VilaTopBar(title = "Chọn đối thủ", onBack = onBack)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(BotRepository.bots, key = { _, b -> b.id }, contentType = { _, _ -> "bot" }) { index, bot ->
                BotCard(bot = bot, index = index, seen = seen, onClick = { vm.startBotGame(bot.id) })
            }
        }
    }
}

private val BOT_SHAPE = RoundedCornerShape(16.dp)

@Composable
private fun BotCard(bot: BotProfile, index: Int, seen: MutableSet<Int>, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .staggerIn(index, seen)
            .pressable(onClickLabel = bot.name, pressedScale = 0.95f, onClick = onClick)
            .glass(BOT_SHAPE)
            .padding(horizontal = 10.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(bot.avatarResId),
            contentDescription = bot.name,
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .border(2.dp, Color(0x33FFFFFF), CircleShape),
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = bot.name,
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.1).sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(5.dp))
        Text(
            text = bot.elo.toString() + " Elo",
            color = Color(0xFFD6F0B8),
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(VilaColors.GreenDeep)
                .border(1.dp, Color(0x3381B64C), RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 3.dp),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = bot.description,
            color = Color(0xFFAEB9CB),
            fontSize = 13.sp,
            lineHeight = 17.sp,
            textAlign = TextAlign.Center,
            maxLines = 2,
            minLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
