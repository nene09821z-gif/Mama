package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.game.PremoveMode

private val DialogBg = Color(0xFF302E2B)
private val DescColor = Color(0xFFBABABA)
private val BadgeBg = Color(0xFF1B1A18)

private fun PremoveMode.description(): String = when (this) {
    PremoveMode.MULTI ->
        "Thực hiện nhiều nước đi hợp pháp trong lượt của đối thủ và chúng sẽ tự động được chơi theo thứ tự. " +
            "Hủy bỏ lượt di chuyển trước bằng cách nhấn vào bất kỳ ô trống/đối thủ nào hoặc bằng cách nhấn vào mũi tên quay lại trong lịch sử di chuyển."
    PremoveMode.SINGLE ->
        "Thực hiện một nước đi hợp pháp trong lượt của đối thủ và nước đi tiếp theo của bạn sẽ được thực hiện tự động. " +
            "Hủy bỏ lượt di chuyển trước bằng cách nhấn vào bất kỳ ô trống/đối thủ nào hoặc bằng cách nhấn vào mũi tên quay lại trong lịch sử di chuyển."
    PremoveMode.OFF -> ""
}

/**
 * Hộp thoại chọn "Đi trước" (premove) giống chess.com: Nhiều (Đề nghị) / Đơn / Đã vô hiệu hóa.
 * Chọn xong là áp dụng và đóng ngay.
 */
@Composable
fun PremoveModeDialog(current: PremoveMode, onSelect: (PremoveMode) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(DialogBg)
                .padding(vertical = 12.dp),
        ) {
            for (mode in PremoveMode.values()) {
                PremoveOption(mode, selected = mode == current) {
                    onSelect(mode)
                    onDismiss()
                }
            }
        }
    }
}

@Composable
private fun PremoveOption(mode: PremoveMode, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(mode.label, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
                if (mode == PremoveMode.MULTI) {
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Đề nghị",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(BadgeBg).padding(horizontal = 8.dp, vertical = 5.dp),
                    )
                }
            }
            val desc = mode.description()
            if (desc.isNotEmpty()) {
                Spacer(Modifier.size(10.dp))
                Text(desc, color = DescColor, fontSize = 17.sp, lineHeight = 24.sp)
            }
        }
        Spacer(Modifier.width(12.dp))
        RadioButton(
            selected = selected,
            onClick = null,
            colors = RadioButtonDefaults.colors(
                selectedColor = VilaColors.Green,
                unselectedColor = VilaColors.Green.copy(alpha = 0.9f),
            ),
            modifier = Modifier.padding(top = 4.dp).size(32.dp),
        )
    }
}

/** Hàng "Đi trước  <Giá trị> >" – bấm để mở [PremoveModeDialog]. Dùng được ở mọi màn Tùy chỉnh. */
@Composable
fun PremoveSettingRow(
    current: PremoveMode,
    onChange: (PremoveMode) -> Unit,
    modifier: Modifier = Modifier,
    titleColor: Color = VilaColors.Text,
    titleSize: TextUnit = 16.sp,
    titleWeight: FontWeight = FontWeight.Normal,
) {
    var open by remember { mutableStateOf(false) }
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(role = Role.Button) { open = true }
            .heightIn(min = 48.dp)
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Đi trước", color = titleColor, fontSize = titleSize, fontWeight = titleWeight, modifier = Modifier.weight(1f))
        Text(current.label, color = titleColor, fontSize = titleSize, fontWeight = FontWeight.Bold)
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = titleColor)
    }
    Text(
        when (current) {
            PremoveMode.MULTI -> "Đặt nhiều nước đi trước trong lượt đối thủ, tự chơi lần lượt."
            PremoveMode.SINGLE -> "Chỉ đặt một nước đi trước."
            PremoveMode.OFF -> "Không cho phép đi trước."
        },
        color = titleColor.copy(alpha = 0.55f),
        fontSize = 13.sp,
    )
    if (open) PremoveModeDialog(current, onChange) { open = false }
}
