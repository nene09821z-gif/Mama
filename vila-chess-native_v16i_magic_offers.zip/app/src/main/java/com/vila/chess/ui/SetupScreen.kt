package com.vila.chess.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Levels
import com.vila.chess.game.TimeControls
import com.vila.chess.game.levelRating
import com.vila.chess.game.modeFor

/** "Ván mới": opponent level, colour and time control, then a big green start button. */
@Composable
fun SetupScreen(vm: GameViewModel, onBack: () -> Unit, title: String = "Ván mới") {
    val images = vm.pieceImages
    val mode = modeFor(TimeControls.get(vm.timeIndex))
    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = Color.White,
                )
            }
            Text(
                text = title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "level") {
                GlassSection("ĐỐI THỦ") {
                    LevelStepper(level = vm.level, onLevel = { vm.updateLevel(it) }, images = images)
                }
            }
            item(key = "color") {
                GlassSection("MÀU QUÂN") {
                    ColorPicker(colorChoice = vm.colorChoice, onColor = { vm.updateColorChoice(it) }, images = images)
                }
            }
            item(key = "time") {
                GlassSection("THỜI GIAN") {
                    ChipGrid(
                        labels = TimeControls.all.map { it.label },
                        selected = vm.timeIndex,
                        columns = 3,
                        onSelect = { vm.updateTimeIndex(it) },
                    )
                    Text(
                        text = "Hệ số " + mode.label + " của bạn: " + vm.stats.rating(mode),
                        color = VilaColors.TextDim,
                        fontSize = 13.sp,
                    )
                }
            }
        }
        ChunkyButton(
            text = "Bắt đầu",
            onClick = { vm.startGame() },
            modifier = Modifier
                .navigationBarsPadding()
                .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp)
                .fillMaxWidth(),
            height = 51.dp,
            fontSize = 22.sp,
        )
    }
}

/** Translucent rounded card with a small caps title, shared by the setup and settings pages. */
@Composable
fun GlassSection(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .glass(shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        SectionTitle(title)
        content()
    }
}

@Composable
private fun StepButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (enabled) VilaColors.Text else VilaColors.ClockIdle,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun PieceIcon(img: ImageBitmap?, size: Dp) {
    if (img != null) {
        Image(bitmap = img, contentDescription = null, modifier = Modifier.size(size))
    } else {
        Spacer(Modifier.size(size))
    }
}

/** "‹  [knight] Cấp 3 · Nghiệp dư  ›" */
@Composable
private fun LevelStepper(level: Int, onLevel: (Int) -> Unit, images: Array<ImageBitmap?>) {
    val last = Levels.all.size
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(VilaColors.PanelDark)
            .padding(horizontal = 6.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StepButton(label = "‹", enabled = level > 1) { onLevel(level - 1) }
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF4A4743)),
                contentAlignment = Alignment.Center,
            ) {
                PieceIcon(images[10], 40.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = "Máy · Cấp " + level,
                    color = VilaColors.Text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = Levels.get(level).name + " · ~" + levelRating(level),
                    color = VilaColors.TextDim,
                    fontSize = 13.sp,
                )
            }
        }
        StepButton(label = "›", enabled = level < last) { onLevel(level + 1) }
    }
}

/** Three tiles: white king, two kings (random), black king. */
@Composable
private fun ColorPicker(colorChoice: Int, onColor: (Int) -> Unit, images: Array<ImageBitmap?>) {
    val labels = listOf("Trắng", "Ngẫu nhiên", "Đen")
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (idx in 0 until 3) {
            val sel = idx == colorChoice
            val shape = RoundedCornerShape(10.dp)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(if (sel) VilaColors.Green.copy(alpha = 0.16f) else VilaColors.PanelDark)
                    .border(
                        width = if (sel) 1.5.dp else 1.dp,
                        color = if (sel) VilaColors.Green else VilaColors.ClockIdle,
                        shape = shape,
                    )
                    .clickable { onColor(idx) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    if (idx == 0) {
                        PieceIcon(images[6], 40.dp)
                    } else if (idx == 2) {
                        PieceIcon(images[14], 40.dp)
                    } else {
                        PieceIcon(images[6], 28.dp)
                        PieceIcon(images[14], 28.dp)
                    }
                }
                Text(
                    text = labels[idx],
                    color = if (sel) VilaColors.Green else VilaColors.TextDim,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
        }
    }
}
