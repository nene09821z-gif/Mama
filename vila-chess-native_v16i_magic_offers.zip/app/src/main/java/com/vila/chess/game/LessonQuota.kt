package com.vila.chess.game

import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.Quota
import com.vila.chess.billing.dailyLimit
import com.vila.chess.billing.hasAccess
import com.vila.chess.billing.Feature
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Luật giới hạn bài học theo ngày (thuần Kotlin, test được bằng JVM).
 *
 *  • Gói Free: tối đa [Quota.LESSONS] bài MỚI mỗi ngày (giờ máy). Sang ngày mới (0h) là được học lại từ đầu.
 *  • Mở lại một bài đã bắt đầu trong ngày KHÔNG tốn thêm lượt.
 *  • Gói có UNLIMITED_LESSONS (Gold trở lên): không giới hạn và mở mọi khóa nâng cao.
 */
object LessonQuota {

    /** null = không giới hạn. */
    fun limit(tier: MembershipTier): Int? = dailyLimit(Quota.LESSONS, tier)

    /** Số lượt còn lại hôm nay (null = không giới hạn). */
    fun remaining(limit: Int?, startedToday: Int): Int? = limit?.let { (it - startedToday).coerceAtLeast(0) }

    /** Được bắt đầu [lessonId] không? Bài đã bắt đầu hôm nay luôn được mở lại. */
    fun canStart(limit: Int?, startedToday: Set<String>, lessonId: String): Boolean =
        limit == null || lessonId in startedToday || startedToday.size < limit

    /** Khóa này có mở được cho [tier] không (khóa nâng cao chỉ dành cho thành viên). */
    fun canOpenCourse(course: Course, tier: MembershipTier): Boolean =
        !course.premium || hasAccess(Feature.UNLIMITED_LESSONS, tier)

    /** Khóa ngày theo giờ máy, ví dụ "2026-11-10". Đổi ngày ⇒ khóa đổi ⇒ lượt tự làm mới. */
    fun dayKey(nowMs: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(nowMs))

    /** Mốc 0h của ngày kế tiếp (giờ máy), tính từ [nowMs]. */
    fun nextMidnightMs(nowMs: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = nowMs
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    /** "03:25:10" – thời gian còn lại đến khi sang ngày mới. */
    fun countdownText(nowMs: Long): String {
        val total = ((nextMidnightMs(nowMs) - nowMs) / 1000L).coerceAtLeast(0L)
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return two(h) + ":" + two(m) + ":" + two(s)
    }

    private fun two(v: Long): String = if (v < 10) "0$v" else v.toString()
}
