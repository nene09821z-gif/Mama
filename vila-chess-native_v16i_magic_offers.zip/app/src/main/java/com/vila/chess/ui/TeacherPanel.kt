package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.coach.Mood
import com.vila.chess.coach.Persona
import com.vila.chess.coach.TeacherController
import kotlinx.coroutines.delay

/**
 * Khung "Thầy": avatar + bong bóng thoại (chữ hiện dần như đang nói) + 4 nút: Hỏi thầy · Gợi ý · Sổ tay · Cài đặt.
 *
 *  - Thầy tự nói sau mỗi nước đi (xem coach/TeacherBrain).
 *  - Một lượt có thể có 2–4 câu: chạm bong bóng để nghe tiếp (hoặc tự chuyển sau vài giây).
 *  - Người chơi nghĩ lâu => thầy nhắc nhẹ ở 28 s, 58 s, 98 s.
 *  - Dấu vẽ trên bàn cờ tự tắt sau 9 giây.
 */
@Composable
fun TeacherPanel(
    teacher: TeacherController,
    flipped: Boolean,
    canAsk: Boolean,
    hintBusy: Boolean,
    over: Boolean,
    onHint: () -> Unit,
    onAsk: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val line = teacher.current
    val mood = line?.mood ?: Mood.CALM
    val accent = mood.accent()
    var showHistory by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // ---- chữ hiện dần ----
    val full = line?.text.orEmpty()
    var shown by remember(line?.id) { mutableIntStateOf(0) }
    LaunchedEffect(line?.id) {
        shown = 0
        for (i in 1..full.length) { shown = i; delay(16L) }
        if (teacher.hasMore) {
            delay((1800L + full.length * 22L).coerceAtMost(5200L))
            teacher.next()
        }
    }
    val speaking = shown < full.length

    // ---- dấu trên bàn cờ tự tắt ----
    LaunchedEffect(line?.id) {
        if (line != null && line.marks.isNotEmpty()) {
            delay(9_000L)
            teacher.clearMarks()
        }
    }

    // ---- nhắc khi nghĩ lâu ----
    LaunchedEffect(teacher.ply, canAsk, over) {
        if (!canAsk || over) return@LaunchedEffect
        delay(28_000L); teacher.nudge(1)
        delay(30_000L); teacher.nudge(2)
        delay(40_000L); teacher.nudge(3)
    }

    // ---- hướng nhìn: ô cờ thầy vừa nói tới, quy ra -1..1 so với avatar (bàn cờ nằm phía trên) ----
    val sq = teacher.lookSquare
    val look = remember(sq, flipped) {
        if (sq < 0) 0f to 0f
        else {
            val file = sq and 7
            val rank = sq shr 3
            val col = if (flipped) 7 - file else file
            val row = if (flipped) rank else 7 - rank           // 0 = hàng trên cùng của màn hình
            ((col - 3.5f) / 3.5f) to (-1f + row / 7f * 0.55f)   // luôn nhìn lên: -1 (hàng trên) … -0.45 (hàng dưới)
        }
    }

    Row(
        modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp),
        verticalAlignment = Alignment.Top,
    ) {
        TeacherAvatar(
            mood = mood,
            speaking = speaking,
            reaction = teacher.reaction,
            lookDx = look.first,
            lookDy = look.second,
            onClick = { teacher.poke() },
        )
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            // ---- bong bóng thoại ----
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(VilaColors.PanelDark)
                    .border(1.5.dp, accent.copy(alpha = 0.85f), RoundedCornerShape(10.dp))
                    .clickable(enabled = teacher.hasMore) { teacher.next() }
                    .padding(horizontal = 9.dp, vertical = 5.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = teacher.persona.label,
                        color = accent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.weight(1f),
                    )
                    if (teacher.hasMore) {
                        Text("chạm để nghe tiếp ▸", color = VilaColors.TextDim, fontSize = 10.sp)
                    }
                }
                Text(
                    text = if (full.isEmpty()) "Thầy đang xem bàn cờ cùng ${teacher.persona.you}…" else full.substring(0, shown.coerceAtMost(full.length)),
                    color = VilaColors.Text,
                    fontSize = 13.sp,
                    lineHeight = 17.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(5.dp))
            // ---- nút ----
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                TeacherChip("Hỏi thầy", canAsk && !over, Modifier.weight(1.15f)) { onAsk() }
                TeacherChip("Gợi ý", canAsk && !over && !hintBusy, Modifier.weight(1f)) { onHint() }
                TeacherChip("Sổ tay", true, Modifier.weight(1f)) { showHistory = true }
                TeacherChip(null, true, Modifier.width(34.dp)) { showSettings = true }
            }
        }
    }

    if (showHistory) TeacherHistorySheet(teacher) { showHistory = false }
    if (showSettings) TeacherSettingsSheet(teacher) { showSettings = false }
}

@Composable
private fun TeacherChip(text: String?, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .height(28.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(8.dp))
            .background(VilaColors.PanelRaised)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (text != null) {
            Text(text, color = VilaColors.Text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        } else {
            Icon(Icons.Filled.Settings, "Cài đặt thầy", tint = VilaColors.TextDim, modifier = Modifier.size(16.dp))
        }
    }
}

// =============================================================================
// Sổ tay: toàn bộ lời thầy đã nói trong ván
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeacherHistorySheet(teacher: TeacherController, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = OptionsColors.Sheet,
        contentColor = OptionsColors.Text,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp)) {
            Text("Sổ tay của thầy", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(
                "Mọi điều thầy đã nhắc trong ván này — xem lại để nhớ lỗi.",
                fontSize = 12.sp, color = VilaColors.TextDim, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp),
            )
            val entries = teacher.history.asReversed()
            if (entries.isEmpty()) {
                Text("Chưa có lời nào.", color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.padding(vertical = 24.dp))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false).height(420.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(entries, key = { it.id }) { l ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(VilaColors.PanelDark).padding(10.dp),
                        ) {
                            Box(Modifier.width(4.dp).height(36.dp).clip(RoundedCornerShape(2.dp)).background(l.mood.accent()))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    if (l.ply > 0) "Sau nước " + l.ply else "Trước / sau ván",
                                    color = l.mood.accent(), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                )
                                Text(l.text, color = VilaColors.Text, fontSize = 14.sp, lineHeight = 19.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// =============================================================================
// Cài đặt thầy: tính cách · độ nói nhiều · giọng đọc  (dùng cả trong ván lẫn ở "Các tùy chỉnh")
// =============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeacherSettingsSheet(teacher: TeacherController, onDismiss: () -> Unit) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = OptionsColors.Sheet,
        contentColor = OptionsColors.Text,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 4.dp)) {
            Text("Thầy của bạn", fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(Modifier.height(10.dp))
            TeacherSettingsContent(teacher)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun TeacherSettingsContent(teacher: TeacherController) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Tính cách", color = VilaColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        for (p in Persona.entries) {
            val on = p == teacher.persona
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (on) VilaColors.GreenDeep else VilaColors.PanelRaised)
                    .border(if (on) 1.5.dp else 0.dp, if (on) VilaColors.Green else Color.Transparent, RoundedCornerShape(10.dp))
                    .clickable { teacher.setPersona(p) }
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(p.label, color = VilaColors.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(p.blurb, color = VilaColors.TextDim, fontSize = 12.sp)
                }
                if (on) Text("✓", color = VilaColors.Green, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(2.dp))
        Text("Thầy nói nhiều không?", color = VilaColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val labels = listOf("Ít", "Vừa", "Nhiều")
            for (i in labels.indices) {
                val on = teacher.talkiness == i
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (on) VilaColors.Green else VilaColors.PanelRaised)
                        .clickable { teacher.setTalkiness(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(labels[i], color = if (on) Color(0xFF14210E) else VilaColors.Text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
        Text(
            when (teacher.talkiness) {
                0 -> "Thầy chỉ lên tiếng khi có chuyện quan trọng: quân bị treo, bỏ lỡ miếng ngon, chiếu hết."
                1 -> "Thầy nhận xét các nước đáng chú ý và thỉnh thoảng nhắc chiến lược."
                else -> "Thầy nói gần như mỗi nước: khen, nhắc, chỉ thế cờ, kèm mẹo và chuyện vui."
            },
            color = VilaColors.TextDim, fontSize = 12.sp,
        )
        SwitchRow("Thầy đọc thành tiếng", teacher.voiceOn) { teacher.setVoice(it) }
    }
}
