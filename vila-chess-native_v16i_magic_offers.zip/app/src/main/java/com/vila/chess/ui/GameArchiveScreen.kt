package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.RatingMode
import com.vila.chess.profile.ArchiveSnapshot
import com.vila.chess.profile.ArchivedGame
import com.vila.chess.profile.GameArchive
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// =============================================================================
// "Ván đã chơi": kho ván đấu (hàng nghìn ván) - lọc, nhóm theo ngày, chạm để xem lại + phân tích.
// Danh sách là LazyColumn có key + contentType: chỉ dựng các dòng đang nhìn thấy nên 5.000 ván vẫn mượt.
// =============================================================================

private const val R_NONE = 0
private const val R_WIN = 1
private const val R_DRAW = 2
private const val R_LOSS = 3

private val WIN_COLOR = Color(0xFF81B64C)
private val DRAW_COLOR = Color(0xFF8A93A3)
private val LOSS_COLOR = Color(0xFFE05A47)
private val NEUTRAL_COLOR = Color(0xFF5E86BD)
private val ROW_SHAPE = RoundedCornerShape(14.dp)
private val TIME_FMT = SimpleDateFormat("HH:mm", Locale.getDefault())

private sealed interface ArchiveItem {
    data class Header(val key: String, val label: String) : ArchiveItem
    data class Game(val g: ArchivedGame) : ArchiveItem
}

private fun resultOf(g: ArchivedGame): Int = when {
    g.score < 0.0 -> R_NONE
    g.score > 0.75 -> R_WIN
    g.score > 0.25 -> R_DRAW
    else -> R_LOSS
}

private fun reasonText(r: String): String = when (r) {
    "CHECKMATE" -> "Chiếu hết"
    "STALEMATE" -> "Hết nước đi"
    "INSUFFICIENT" -> "Thiếu lực lượng"
    "FIFTY" -> "Luật 50 nước"
    "REPETITION" -> "Lặp thế cờ"
    "TIMEOUT" -> "Hết giờ"
    "RESIGN" -> "Đầu hàng"
    "AGREEMENT" -> "Hòa thuận"
    else -> ""
}

private fun dayIndex(ts: Long, tz: TimeZone): Long = (ts + tz.getOffset(ts)) / 86_400_000L

private fun buildItems(games: List<ArchivedGame>, resultFilter: Int, modeFilter: Int): List<ArchiveItem> {
    val modes = RatingMode.values()
    val tz = TimeZone.getDefault()
    val today = dayIndex(System.currentTimeMillis(), tz)
    val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val out = ArrayList<ArchiveItem>(games.size + 64)
    var lastDay = Long.MIN_VALUE
    for (g in games) {
        if (resultFilter != 0 && resultOf(g) != resultFilter) continue
        if (modeFilter != 0 && g.modeName != modes[modeFilter - 1].name) continue
        val d = dayIndex(g.ts, tz)
        if (d != lastDay) {
            lastDay = d
            val label = when (today - d) {
                0L -> "Hôm nay"
                1L -> "Hôm qua"
                else -> dateFmt.format(Date(g.ts))
            }
            out.add(ArchiveItem.Header("h$d", label))
        }
        out.add(ArchiveItem.Game(g))
    }
    return out
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GameArchiveScreen(vm: GameViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var snapshot by remember { mutableStateOf<ArchiveSnapshot?>(null) }
    var resultFilter by remember { mutableIntStateOf(0) }
    var modeFilter by remember { mutableIntStateOf(0) }
    var pendingDelete by remember { mutableStateOf<ArchivedGame?>(null) }

    // Đọc kho ở luồng nền: màn hình hiện ngay, danh sách hiện khi đọc xong.
    LaunchedEffect(Unit) { snapshot = withContext(Dispatchers.IO) { GameArchive.snapshot(ctx) } }

    val listState = rememberLazyListState(vm.archiveScrollIndex, vm.archiveScrollOffset)
    DisposableEffect(Unit) {
        onDispose {
            vm.archiveScrollIndex = listState.firstVisibleItemIndex
            vm.archiveScrollOffset = listState.firstVisibleItemScrollOffset
        }
    }

    val snap = snapshot
    val items = remember(snap, resultFilter, modeFilter) {
        if (snap == null) emptyList() else buildItems(snap.games, resultFilter, modeFilter)
    }
    val totals = remember(snap) { snap?.let { ArchiveTotals.of(it.games) } }
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        VilaTopBar(
            title = "Ván đã chơi",
            onBack = onBack,
            leading = { Icon(Icons.Filled.History, null, tint = Color(0xFF9CC0F0), modifier = Modifier.size(26.dp)) },
        )
        if (snap == null || totals == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = VilaColors.Green, strokeWidth = 3.dp, modifier = Modifier.size(36.dp))
            }
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 4.dp, bottom = 24.dp + bottomInset),
            ) {
                item(key = "summary", contentType = "summary") { SummaryCard(totals) }
                item(key = "filters", contentType = "filters") {
                    Column(modifier = Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ChipRow(
                            labels = listOf("Tất cả", "Thắng", "Hòa", "Thua"),
                            selected = resultFilter,
                            onSelect = { resultFilter = it },
                        )
                        ChipRow(
                            labels = listOf("Mọi thể loại") + RatingMode.values().map { it.label },
                            selected = modeFilter,
                            onSelect = { modeFilter = it },
                        )
                    }
                }
                if (items.isEmpty()) {
                    item(key = "empty", contentType = "empty") {
                        EmptyArchive(hasGames = snap.games.isNotEmpty())
                    }
                } else {
                    for (entry in items) {
                        when (entry) {
                            is ArchiveItem.Header -> stickyHeader(key = entry.key, contentType = "header") { DayHeader(entry.label) }
                            is ArchiveItem.Game -> item(key = entry.g.id, contentType = "game") {
                                val g = entry.g
                                GameRow(
                                    g = g,
                                    reviewed = g.id in snap.reviewed,
                                    onOpen = {
                                        val msg = vm.openArchivedReview(g)
                                        if (msg != null) Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                                    },
                                    onDelete = { pendingDelete = g },
                                )
                            }
                        }
                    }
                    item(key = "footer", contentType = "footer") {
                        Text(
                            text = "Lưu tối đa " + fmtInt(GameArchive.MAX_GAMES) + " ván gần nhất.",
                            color = VilaColors.TextDim,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                        )
                    }
                }
            }
        }
    }

    val del = pendingDelete
    if (del != null && snap != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = Color(0xFF16233B),
            titleContentColor = Color.White,
            textContentColor = VilaColors.TextDim,
            shape = RoundedCornerShape(20.dp),
            title = { Text("Xóa ván này?", fontWeight = FontWeight.ExtraBold) },
            text = { Text("Ván đấu với " + del.opponent + " và kết quả phân tích của nó sẽ bị xóa vĩnh viễn.") },
            confirmButton = {
                TextButton(onClick = {
                    pendingDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) { GameArchive.delete(ctx, del.id) }
                        val cur = snapshot
                        if (cur != null) snapshot = ArchiveSnapshot(cur.games.filter { it.id != del.id }, cur.reviewed - del.id)
                    }
                }) { Text("Xóa", color = VilaColors.Danger, fontWeight = FontWeight.ExtraBold) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Hủy", color = VilaColors.TextDim) } },
        )
    }
}

// ------------------------------------------------------------------ tổng quan

private class ArchiveTotals(val total: Int, val win: Int, val draw: Int, val loss: Int) {
    val decided: Int get() = win + draw + loss
    val winPct: Int get() = if (decided <= 0) 0 else Math.round(win * 100f / decided)

    companion object {
        fun of(games: List<ArchivedGame>): ArchiveTotals {
            var w = 0; var d = 0; var l = 0
            for (g in games) {
                when (resultOf(g)) {
                    R_WIN -> w++
                    R_DRAW -> d++
                    R_LOSS -> l++
                    else -> {}
                }
            }
            return ArchiveTotals(games.size, w, d, l)
        }
    }
}

private fun fmtInt(n: Int): String = NumberFormat.getIntegerInstance(Locale("vi", "VN")).format(n)

@Composable
private fun SummaryCard(t: ArchiveTotals) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .glass(RoundedCornerShape(16.dp))
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Column(modifier = Modifier.weight(1f)) {
                Text(fmtInt(t.total), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text("ván đã chơi", color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            if (t.decided > 0) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(t.winPct.toString() + "%", color = WIN_COLOR, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("tỉ lệ thắng", color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (t.decided > 0) {
            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50))) {
                if (t.win > 0) Box(Modifier.weight(t.win.toFloat()).fillMaxSize().background(WIN_COLOR))
                if (t.draw > 0) Box(Modifier.weight(t.draw.toFloat()).fillMaxSize().background(DRAW_COLOR))
                if (t.loss > 0) Box(Modifier.weight(t.loss.toFloat()).fillMaxSize().background(LOSS_COLOR))
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                LegendItem("Thắng", t.win, WIN_COLOR, Modifier.weight(1f))
                LegendItem("Hòa", t.draw, DRAW_COLOR, Modifier.weight(1f))
                LegendItem("Thua", t.loss, LOSS_COLOR, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun LegendItem(label: String, n: Int, color: Color, modifier: Modifier = Modifier) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(color))
        Spacer(Modifier.width(6.dp))
        Text(label + " " + fmtInt(n), color = Color(0xFFD5DCE8), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ------------------------------------------------------------------ bộ lọc

@Composable
private fun ChipRow(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (i in labels.indices) {
            val sel = i == selected
            val shape = RoundedCornerShape(50)
            Box(
                modifier = Modifier
                    .height(36.dp)
                    .pressable(pressedScale = 0.94f, onClick = { onSelect(i) })
                    .clip(shape)
                    .background(if (sel) VilaColors.Green.copy(alpha = 0.2f) else Color(0x66101C33))
                    .border(if (sel) 1.5.dp else 1.dp, if (sel) VilaColors.Green else Color(0x26FFFFFF), shape)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = labels[i],
                    color = if (sel) VilaColors.Green else Color(0xFFB7C3D6),
                    fontSize = 14.sp,
                    fontWeight = if (sel) FontWeight.ExtraBold else FontWeight.Bold,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
private fun DayHeader(label: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xF20D1B38))
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(label, color = Color(0xFF9CC0F0), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun EmptyArchive(hasGames: Boolean) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.History, null, tint = Color(0x669CC0F0), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            text = if (hasGames) "Không có ván nào khớp bộ lọc" else "Chưa có ván nào được lưu",
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = if (hasGames) "Thử chọn bộ lọc khác." else "Chơi xong một ván, ván đó sẽ tự lưu ở đây để bạn xem lại và phân tích.",
            color = VilaColors.TextDim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
    }
}

// ------------------------------------------------------------------ một dòng ván đấu

@Composable
private fun GameRow(g: ArchivedGame, reviewed: Boolean, onOpen: () -> Unit, onDelete: () -> Unit) {
    val result = resultOf(g)
    val time = remember(g.ts) { TIME_FMT.format(Date(g.ts)) }
    val reason = remember(g.reason) { reasonText(g.reason) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .height(76.dp)
            .pressable(onClickLabel = "Xem lại ván với " + g.opponent, pressedScale = 0.98f, onClick = onOpen)
            .glass(ROW_SHAPE),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.width(12.dp))
        ResultBadge(result, g.outcome)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = g.opponent,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = time + " · " + g.timeLabel + " · " + g.moves + " nước",
                color = Color(0xFFAEB9CB),
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (reason.isNotEmpty()) {
                    Text(reason, color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1)
                }
                if (reviewed) {
                    if (reason.isNotEmpty()) Text("  ·  ", color = VilaColors.TextDim, fontSize = 12.sp)
                    Text("Đã phân tích", color = WIN_COLOR, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                } else if (reason.isEmpty()) {
                    Text("Chạm để phân tích", color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
        Column(
            modifier = Modifier.width(56.dp).fillMaxHeight().padding(vertical = 8.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            val deltaText = when {
                result == R_NONE -> ""
                g.delta > 0 -> "+" + g.delta
                g.delta < 0 -> g.delta.toString()
                else -> "–"
            }
            Text(
                text = deltaText,
                color = if (g.delta > 0) WIN_COLOR else if (g.delta < 0) LOSS_COLOR else VilaColors.TextDim,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                modifier = Modifier.padding(end = 12.dp),
            )
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .pressable(onClickLabel = "Xóa ván", pressedScale = 0.85f, haptic = false, onClick = onDelete)
                    .clip(RoundedCornerShape(50)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Delete, contentDescription = "Xóa ván", tint = Color(0xFF7D8AA0), modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun ResultBadge(result: Int, outcome: String) {
    val color = when (result) {
        R_WIN -> WIN_COLOR
        R_DRAW -> DRAW_COLOR
        R_LOSS -> LOSS_COLOR
        else -> NEUTRAL_COLOR
    }
    val label = when (result) {
        R_WIN -> "+"
        R_DRAW -> "="
        R_LOSS -> "−"
        else -> when (outcome) {
            "WHITE_WINS" -> "1-0"
            "BLACK_WINS" -> "0-1"
            else -> "="
        }
    }
    Box(
        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)).background(color),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = Color.White,
            fontSize = if (label.length > 1) 13.sp else 24.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
        )
    }
}
