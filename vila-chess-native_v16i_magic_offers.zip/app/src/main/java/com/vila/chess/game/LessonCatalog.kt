package com.vila.chess.game

import com.vila.chess.core.Position

// ════════════════════════════════════════════════════════════════════════════════════════════
//  KHO BÀI HỌC (thuần Kotlin, không phụ thuộc Android/Compose ⇒ test được bằng JVM)
//
//  Hai loại bài:
//    • PRACTICE – bắt đầu từ một thế cờ, bạn cầm bên thắng thế và đấu với Bot (dùng lại GameKind.ENDGAME).
//    • TACTIC   – tìm nước đi đúng trên bàn cờ giải đố (dùng lại PuzzleSession, định dạng Lichess:
//                 moves[0] = nước của đối thủ, moves[1] = nước bạn phải tìm, …).
//
//  Thêm bài mới = thêm MỘT dòng practice(...) / tactic(...) vào một khóa bên dưới. Mọi thế cờ nên được kiểm
//  bằng LessonCatalogTest (FEN hợp lệ, lời giải chạy được qua PuzzleSession) trước khi phát hành.
//
//  Bộ nhớ: dữ liệu chỉ là vài chục chuỗi nhỏ; bàn cờ xem trước (IntArray 64) chỉ dựng khi cần và được nhớ lại.
// ════════════════════════════════════════════════════════════════════════════════════════════

enum class LessonKind { PRACTICE, TACTIC }

class Lesson(
    val id: String,
    val title: String,
    /** Ý tưởng chính (1–2 câu) hiện trước khi bắt đầu. */
    val idea: String,
    /** Mục tiêu ngắn gọn hiện trên thẻ, vd "Chiếu hết trong 1 nước". */
    val goal: String,
    val kind: LessonKind,
    /** PRACTICE: thế bắt đầu. TACTIC: FEN kiểu Lichess (TRƯỚC nước đi đầu của đối thủ). */
    val fen: String,
    /** PRACTICE: người học cầm Trắng? (TACTIC: bên đi sau nước moves[0], tự suy ra). */
    val humanWhite: Boolean = true,
    /** TACTIC: chuỗi UCI xen kẽ đối thủ / bạn. */
    val moves: List<String> = emptyList(),
    /** TACTIC: nhãn chủ đề (để hiện mục tiêu đúng ở màn giải). */
    val themes: List<String> = emptyList(),
    /** PRACTICE: hòa cũng tính là hoàn thành (bài "giữ hòa"). */
    val drawCounts: Boolean = false,
    val minutes: Int = 3,
) {
    /** Dựng câu đố tương ứng (chỉ dùng cho TACTIC). */
    fun toPuzzle(): Puzzle = Puzzle(
        level = 0,
        puzzleId = "lesson-$id",
        fen = fen,
        moves = moves,
        rating = 0,
        themes = themes,
    )

    /** Bàn cờ xem trước (sau nước mở màn của đối thủ nếu là TACTIC), dựng một lần rồi nhớ lại. */
    val preview: IntArray by lazy(LazyThreadSafetyMode.NONE) { buildPreview(this) }

    /** Xem trước nên lật bàn (người học cầm Đen)? */
    val previewFlipped: Boolean by lazy(LazyThreadSafetyMode.NONE) {
        when (kind) {
            LessonKind.PRACTICE -> !humanWhite
            LessonKind.TACTIC -> runCatching { !PuzzleSession(toPuzzle()).playerWhite }.getOrDefault(false)
        }
    }
}

private fun buildPreview(l: Lesson): IntArray = try {
    when (l.kind) {
        LessonKind.PRACTICE -> Position.fromFen(l.fen).board.copyOf()
        LessonKind.TACTIC -> PuzzleSession(l.toPuzzle()).board()
    }
} catch (e: Exception) {
    IntArray(64)
}

class Course(
    val id: String,
    val title: String,
    val subtitle: String,
    val level: String,
    /** Màu nhấn 0xAARRGGBB của khóa. */
    val accent: Long,
    /** true = chỉ thành viên (gói có UNLIMITED_LESSONS) mới học được. */
    val premium: Boolean,
    val lessons: List<Lesson>,
)

object LessonCatalog {

    private fun practice(
        id: String, title: String, idea: String, goal: String, fen: String,
        humanWhite: Boolean = true, minutes: Int = 4, drawCounts: Boolean = false,
    ) = Lesson(id, title, idea, goal, LessonKind.PRACTICE, fen, humanWhite, drawCounts = drawCounts, minutes = minutes)

    private fun tactic(
        id: String, title: String, idea: String, goal: String, fen: String, moves: String,
        themes: String, minutes: Int = 2,
    ) = Lesson(
        id, title, idea, goal, LessonKind.TACTIC, fen,
        moves = moves.split(' '), themes = themes.split(' '), minutes = minutes,
    )

    val courses: List<Course> = listOf(
        Course(
            id = "mate_basic",
            title = "Chiếu hết cơ bản",
            subtitle = "Dồn vua đối phương vào mép bàn và kết thúc ván đấu",
            level = "Người mới",
            accent = 0xFF81B64C,
            premium = false,
            lessons = listOf(
                practice(
                    "kq", "Vua + Hậu chiếu hết",
                    "Hậu cắt vua đối phương thành từng vùng nhỏ rồi vua của bạn tiến lên hỗ trợ. Cẩn thận kẻo hòa pat!",
                    "Chiếu hết Bot", "4k3/8/8/8/8/8/8/3QK3 w - - 0 1",
                ),
                practice(
                    "kq_center", "Hậu: vua ở giữa bàn",
                    "Giữ Hậu cách vua một nước đi của mã để không bị ăn, rồi thu hẹp dần vùng vua có thể đi.",
                    "Chiếu hết Bot", "8/8/3k4/8/8/8/8/Q3K3 w - - 0 1",
                ),
                practice(
                    "kr", "Vua + Xe chiếu hết",
                    "Dùng vua và xe ép vua đen vào mép bàn, chiếu hết bằng thế đối vua.",
                    "Chiếu hết Bot", "4k3/8/8/8/8/8/8/R3K3 w - - 0 1",
                ),
                practice(
                    "kr_center", "Xe: vua ở giữa bàn",
                    "Xe cắt vua theo từng hàng. Giữ vua của bạn gần để xe luôn được bảo vệ.",
                    "Chiếu hết Bot", "8/8/8/3k4/8/8/8/R3K3 w - - 0 1",
                ),
                practice(
                    "krr", "Hai Xe chiếu hết",
                    "Hai xe luân phiên ép vua xuống hàng cuối (thang xe).",
                    "Chiếu hết Bot", "8/8/8/4k3/8/8/8/R3K2R w - - 0 1",
                ),
            ),
        ),
        Course(
            id = "mate_in_1",
            title = "Chiếu hết trong 1 nước",
            subtitle = "Nhận ra thế chiếu hết quen thuộc chỉ trong một nước đi",
            level = "Người mới",
            accent = 0xFFE5A83B,
            premium = false,
            lessons = listOf(
                tactic(
                    "m1_backrank", "Chiếu hết hàng cuối",
                    "Vua bị chính tốt của mình chặn kín ở hàng cuối. Xe hoặc Hậu ăn hàng cuối là chiếu hết.",
                    "Chiếu hết trong 1 nước", "6k1/p4ppp/8/8/8/8/5PPP/3R2K1 b - - 0 1", "a7a6 d1d8", "mate mateIn1 backRankMate",
                ),
                tactic(
                    "m1_scholar", "Chiếu hết ở f7",
                    "Ô f7 chỉ có vua bảo vệ. Hậu có Tượng hỗ trợ sẽ chiếu hết ngay.",
                    "Chiếu hết trong 1 nước", "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR b KQkq - 5 3", "g8f6 h5f7", "mate mateIn1",
                ),
                tactic(
                    "m1_fool", "Nước chiếu hết nhanh nhất",
                    "Đen bị thủng đường chéo e1–h4 sau khi Trắng đi f3 và g4. Hậu đen chiếu hết ngay.",
                    "Chiếu hết trong 1 nước", "rnbqkbnr/pppp1ppp/8/4p3/8/5P2/PPPPP1PP/RNBQKBNR w KQkq - 0 2", "g2g4 d8h4", "mate mateIn1 opening",
                ),
                tactic(
                    "m1_smothered", "Chiếu hết ngạt",
                    "Vua bị chính quân mình bao quanh. Quân Mã là quân duy nhất chiếu được mà không bị chặn.",
                    "Chiếu hết trong 1 nước", "6rk/p5pp/8/4N3/8/8/8/6K1 b - - 0 1", "a7a6 e5f7", "mate mateIn1 smotheredMate",
                ),
                tactic(
                    "m1_queen_bishop", "Hậu và Tượng phối hợp",
                    "Tượng bảo vệ ô chiếu của Hậu nên vua không thể ăn Hậu.",
                    "Chiếu hết trong 1 nước", "5rk1/p4ppp/8/7Q/8/3B4/5PPP/6K1 b - - 0 1", "a7a6 h5h7", "mate mateIn1",
                ),
                tactic(
                    "m1_rook_roller", "Hai Xe ăn hàng",
                    "Một xe đã chiếm hàng 7, xe còn lại ăn hàng cuối: vua không còn chỗ trốn.",
                    "Chiếu hết trong 1 nước", "6k1/R7/7p/8/8/8/8/1R4K1 b - - 0 1", "h6h5 b1b8", "mate mateIn1",
                ),
            ),
        ),
        Course(
            id = "tactics",
            title = "Đòn chiến thuật",
            subtitle = "Đòn đôi, ghim, tấn công bằng nước đi lộ: giành quân của đối thủ",
            level = "Trung cấp",
            accent = 0xFF4A9BE8,
            premium = false,
            lessons = listOf(
                tactic(
                    "t_fork", "Đòn đôi của Mã",
                    "Mã nhảy tới ô đánh cùng lúc vua và xe. Vua phải tránh chiếu, bạn ăn quân còn lại.",
                    "Giành quân", "r3k3/p7/8/3N4/8/8/5PPP/6K1 b - - 0 1", "a7a6 d5c7 e8d8 c7a8", "fork advantage short",
                ),
                tactic(
                    "t_pin", "Ghim và tấn công",
                    "Mã đen bị Tượng ghim vào vua nên không thể rời chỗ. Dùng tốt tấn công nó để giành quân.",
                    "Giành quân", "4k3/1p5p/2n5/1B6/3P4/8/8/6K1 b - - 0 1", "h7h6 d4d5 e8d8 d5c6", "pin advantage short",
                ),
                tactic(
                    "t_discovered", "Chiếu lộ (nước đi lộ)",
                    "Khi quân chắn đường đi, xe sau lưng nó tấn công vua. Mã ăn Hậu kèm chiếu lộ: đối thủ không kịp cứu Hậu.",
                    "Giành quân", "4k3/p2q4/8/4N3/8/8/8/4R1K1 b - - 0 1", "a7a6 e5d7 e8d7", "discoveredAttack advantage short",
                ),
            ),
        ),
        Course(
            id = "pawns",
            title = "Tốt & phong cấp",
            subtitle = "Đưa tốt tới hàng cuối và biến nó thành Hậu",
            level = "Người mới",
            accent = 0xFFB07CE8,
            premium = false,
            lessons = listOf(
                practice(
                    "kp", "Vua + Tốt thắng",
                    "Vua ở trước tốt trên hàng 6: đẩy tốt phong Hậu rồi chiếu hết.",
                    "Phong Hậu và thắng", "4k3/8/4K3/4P3/8/8/8/8 w - - 0 1",
                ),
                practice(
                    "p_square", "Tốt tự do chạy thoát",
                    "Vua đối phương quá xa để đuổi kịp tốt. Cứ đẩy tốt đi, rồi dùng Hậu mới chiếu hết.",
                    "Phong Hậu và thắng", "7k/8/8/1P6/8/8/8/K7 w - - 0 1",
                ),
                practice(
                    "p_promote", "Phong cấp thành Hậu",
                    "Tốt đã ở hàng 7. Phong Hậu, nhưng hãy chắc chắn không làm vua đối phương bị hòa pat.",
                    "Phong Hậu và thắng", "7k/4P3/8/8/8/8/8/K7 w - - 0 1",
                ),
                practice(
                    "p_connected", "Hai tốt liên kết",
                    "Hai tốt cạnh nhau bảo vệ lẫn nhau và đi cùng nhau rất mạnh. Đẩy chúng lên và phong cấp.",
                    "Phong Hậu và thắng", "7k/8/8/8/2PP4/8/8/K7 w - - 0 1",
                ),
            ),
        ),
        Course(
            id = "mate_in_2",
            title = "Chiếu hết trong 2 nước",
            subtitle = "Hy sinh quân để ép vua vào thế chiếu hết",
            level = "Nâng cao",
            accent = 0xFFE0674A,
            premium = true,
            lessons = listOf(
                tactic(
                    "m2_smothered", "Hy sinh Hậu rồi chiếu ngạt",
                    "Hậu chiếu và bị ăn, nhưng vua đen tự chặn đường thoát của mình: Mã chiếu hết ngạt.",
                    "Chiếu hết trong 2 nước", "5r1k/p5pp/4Q3/4N3/2B5/8/8/6K1 b - - 0 1", "a7a6 e6g8 f8g8 e5f7", "mate mateIn2 smotheredMate",
                    minutes = 3,
                ),
                tactic(
                    "m2_backrank", "Hy sinh Hậu ở hàng cuối",
                    "Hậu lên hàng cuối buộc xe đen ăn Hậu, xe của bạn ăn lại và chiếu hết.",
                    "Chiếu hết trong 2 nước", "3r2k1/p4ppp/8/8/4Q3/8/5PPP/4R1K1 b - - 0 1", "a7a6 e4e8 d8e8 e1e8", "mate mateIn2 backRankMate",
                    minutes = 3,
                ),
                tactic(
                    "m2_black_queen", "Hậu đen hy sinh ở e1",
                    "Bạn cầm Đen: Hậu chiếu ở e1 buộc xe trắng ăn, rồi xe đen chiếu hết hàng cuối.",
                    "Chiếu hết trong 2 nước", "4r1k1/5ppp/8/4q3/8/8/P4PPP/3R2K1 w - - 0 1", "a2a3 e5e1 d1e1 e8e1", "mate mateIn2 backRankMate",
                    minutes = 3,
                ),
                tactic(
                    "m2_bishop_f7", "Tượng ăn f7 chiếu",
                    "Ăn tốt f7 buộc vua đen đi ra, rồi Mã nhảy vào chiếu hết.",
                    "Chiếu hết trong 2 nước", "rn1qkbnr/ppp2p1p/3p2p1/4N3/2B1P1b1/2N5/PPPP1PPP/R1BQK2R b KQkq - 0 5", "g4d1 c4f7 e8e7 c3d5", "mate mateIn2 opening",
                    minutes = 3,
                ),
            ),
        ),
        Course(
            id = "endgame_pro",
            title = "Tàn cuộc nâng cao",
            subtitle = "Các thế tàn cuộc kinh điển mà kỳ thủ mạnh phải thuộc",
            level = "Nâng cao",
            accent = 0xFFF0C040,
            premium = true,
            lessons = listOf(
                practice(
                    "kbb", "Hai Tượng chiếu hết",
                    "Hai Tượng khác màu ô cùng vua dồn vua đối phương vào góc. Cần kiên nhẫn và đi đúng thứ tự.",
                    "Chiếu hết Bot", "8/8/8/4k3/8/8/8/2B1KB2 w - - 0 1", minutes = 6,
                ),
                practice(
                    "lucena", "Thế Lucena",
                    "Thế thắng kinh điển Xe + Tốt: dựng \"cây cầu\" bằng xe để vua của bạn thoát khỏi bị chiếu liên tục.",
                    "Phong Hậu và thắng", "1K1k4/1P6/8/8/8/8/r7/2R5 w - - 0 1", minutes = 6,
                ),
            ),
        ),
    ) + LessonLichessData.courses   // khóa chiến thuật theo chủ đề, tự sinh từ Lichess (scripts/generate_puzzles.py)

    /** Mọi bài theo đúng thứ tự hiển thị. */
    val all: List<Lesson> by lazy(LazyThreadSafetyMode.NONE) { courses.flatMap { it.lessons } }

    private val byId: Map<String, Lesson> by lazy(LazyThreadSafetyMode.NONE) { all.associateBy { it.id } }
    private val courseByLesson: Map<String, Course> by lazy(LazyThreadSafetyMode.NONE) {
        courses.flatMap { c -> c.lessons.map { it.id to c } }.toMap()
    }

    fun find(id: String): Lesson? = byId[id]
    fun courseOf(lessonId: String): Course? = courseByLesson[lessonId]

    /**
     * Bài nên học tiếp: bài đầu tiên chưa xong trong các khóa [canOpen] cho phép (khóa nào mở được thì mới xét).
     * Trả về null khi đã học hết.
     */
    fun nextUp(done: Set<String>, canOpen: (Course) -> Boolean): Lesson? {
        for (c in courses) {
            if (!canOpen(c)) continue
            for (l in c.lessons) if (l.id !in done) return l
        }
        return null
    }

    /** Bài kế tiếp ngay sau [lessonId] trong cùng khóa (null nếu là bài cuối khóa). */
    fun nextInCourse(lessonId: String): Lesson? {
        val c = courseByLesson[lessonId] ?: return null
        val i = c.lessons.indexOfFirst { it.id == lessonId }
        return c.lessons.getOrNull(i + 1)
    }
}
