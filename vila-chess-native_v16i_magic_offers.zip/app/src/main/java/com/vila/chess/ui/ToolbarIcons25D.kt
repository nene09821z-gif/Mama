package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Icon thanh công cụ 2.5D (thay icon Material mặc định): mỗi icon là một "vật thể" có đế dày, mặt gradient và vệt sáng.
 * Lưới 40 x 44. Khi nút bị khóa icon chuyển xám; icon Gợi ý phát sáng khi đang bật.
 * ToolbarButton cung cấp 2 CompositionLocal bên dưới cho icon đọc.
 */
enum class ToolIcon { OPTIONS, FLAG, BULB, BARS, UNDO, REFRESH }

internal val LocalToolbarEnabled = compositionLocalOf { true }
internal val LocalToolbarActive = compositionLocalOf { false }

private class ToolPal(private val on: Boolean) {
    fun c(v: Long): Color {
        val col = Color(v)
        if (on) return col
        val g = col.red * 0.3f + col.green * 0.59f + col.blue * 0.11f
        return lerp(col, Color(g, g, g, 1f), 0.9f)
    }
    fun v(a: Long, b: Long, y0: Float, y1: Float): Brush =
        Brush.verticalGradient(listOf(c(a), c(b)), startY = y0, endY = y1)
}

@Composable
internal fun ToolbarIcon(kind: ToolIcon, modifier: Modifier = Modifier) {
    val enabled = LocalToolbarEnabled.current
    val active = LocalToolbarActive.current
    Canvas(modifier.size(30.dp)) {
        val s = size.height / 44f
        val left = (size.width - 40f * s) / 2f
        withTransform({
            translate(left, 0f)
            scale(s, s, Offset.Zero)
        }) { drawTool(kind, ToolPal(enabled), active && enabled) }
    }
}

private fun DrawScope.groundShadow(x: Float, y: Float, w: Float) {
    drawOval(Color(0x42000000), Offset(x, y), Size(w, 4f))
}

private fun DrawScope.drawTool(kind: ToolIcon, p: ToolPal, active: Boolean) {
    when (kind) {
        ToolIcon.OPTIONS -> {
            groundShadow(6f, 39.5f, 28f)
            drawRoundRect(p.c(0xFF7F8A98), Offset(5f, 9f), Size(30f, 28f), CornerRadius(8.5f, 8.5f))
            drawRoundRect(brush = p.v(0xFFF6F9FC, 0xFFB5BFCB, 6f, 34f), topLeft = Offset(5f, 6f), size = Size(30f, 28f), cornerRadius = CornerRadius(8.5f, 8.5f))
            drawRoundRect(Color(0xCCFFFFFF), Offset(5.7f, 6.7f), Size(28.6f, 26.6f), CornerRadius(7.8f, 7.8f), style = Stroke(width = 1f))
            for (y in floatArrayOf(13.5f, 20f, 26.5f)) {
                drawCircle(brush = p.v(0xFFB5E57C, 0xFF5C9A2F, y - 2.5f, y + 2.5f), radius = 2.5f, center = Offset(12.5f, y))
                drawRoundRect(p.c(0xFF6A7684), Offset(18f, y - 1.8f), Size(12f, 3.6f), CornerRadius(1.8f, 1.8f))
            }
        }
        ToolIcon.FLAG -> {
            groundShadow(5f, 39.5f, 18f)
            drawRoundRect(p.c(0xFF7F8A98), Offset(10.5f, 7f), Size(4.4f, 33f), CornerRadius(2.2f, 2.2f))
            drawRoundRect(brush = p.v(0xFFEEF2F6, 0xFF9BA6B4, 5f, 38f), topLeft = Offset(9.2f, 5f), size = Size(4.4f, 33f), cornerRadius = CornerRadius(2.2f, 2.2f))
            withTransform({ translate(0f, 3.4f) }) { drawPath(FlagPath, p.c(0xFF86241B)) }
            drawPath(FlagPath, p.v(0xFFFF8472, 0xFFD3382B, 6f, 26f))
            drawPath(FlagShine, Color(0x8CFFFFFF), style = Stroke(width = 1.3f, cap = StrokeCap.Round))
            drawCircle(p.c(0xFFE9EEF3), 2.7f, Offset(11.4f, 5.2f))
        }
        ToolIcon.BULB -> {
            if (active) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0x66FFC83A), Color(0x00FFC83A)), center = Offset(20f, 17f), radius = 23f),
                    radius = 23f, center = Offset(20f, 17f),
                )
            }
            drawOval(Color(0x42000000), Offset(11f, 40.2f), Size(18f, 3.6f))
            val side = SolidColor(p.c(0xFFB67600))
            val face = Brush.radialGradient(
                listOf(p.c(0xFFFFF6B0), p.c(0xFFFFCB3D), p.c(0xFFF29E00)),
                center = Offset(15.6f, 12f), radius = 19f,
            )
            withTransform({ translate(0f, 2.6f) }) { bulbBody(side) }
            bulbBody(face)
            drawPath(BulbFilament, p.c(0xFFC47F00), style = Stroke(width = 1.7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            withTransform({ rotate(28f, Offset(15.6f, 11f)) }) { drawOval(Color(0x8CFFFFFF), Offset(12.2f, 6f), Size(6.8f, 10f)) }
            drawRoundRect(brush = p.v(0xFFD9DFE6, 0xFF8D98A6, 31.5f, 35.1f), topLeft = Offset(13.5f, 31.5f), size = Size(13f, 3.6f), cornerRadius = CornerRadius(1.8f, 1.8f))
            drawRoundRect(p.c(0xFF7F8A98), Offset(15.2f, 36f), Size(9.6f, 3.4f), CornerRadius(1.7f, 1.7f))
        }
        ToolIcon.BARS -> {
            groundShadow(4f, 40.8f, 32f)
            bar(p, 4.5f, 21f, 15f, 0xFFFFC56A, 0xFFF08A1E, 0xFFB2600C)
            bar(p, 15.7f, 12f, 24f, 0xFFA2D86A, 0xFF5FA032, 0xFF3C6E1E)
            bar(p, 26.9f, 5f, 31f, 0xFF7CCBFF, 0xFF2E84E0, 0xFF1B5CA8)
        }
        ToolIcon.UNDO -> {
            groundShadow(6f, 39f, 28f)
            val sideCol = p.c(0xFF1B5CA8)
            val face = p.v(0xFF7CCBFF, 0xFF2E84E0, 7f, 35f)
            withTransform({ translate(0f, 3f) }) {
                drawPath(UndoArrow, sideCol, style = Stroke(width = 6.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(UndoHead, sideCol)
                drawPath(UndoHead, sideCol, style = Stroke(width = 4.4f, join = StrokeJoin.Round))
            }
            drawPath(UndoArrow, face, style = Stroke(width = 6.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(UndoHead, face)
            drawPath(UndoHead, face, style = Stroke(width = 4.4f, join = StrokeJoin.Round))
            drawPath(UndoShine, Color(0x8CFFFFFF), style = Stroke(width = 1.3f, cap = StrokeCap.Round))
        }
        ToolIcon.REFRESH -> {
            groundShadow(6f, 39f, 28f)
            val tl = Offset(9f, 11f)
            val sz = Size(22f, 22f)
            val start = -50f
            val sweep = 275f
            val end = (start + sweep) * PI.toFloat() / 180f
            val cx = 20f; val cy = 22f; val r = 11f
            val ex = cx + r * cos(end); val ey = cy + r * sin(end)
            val tx = -sin(end); val ty = cos(end)          // tiếp tuyến (chiều kim đồng hồ)
            val nx = cos(end); val ny = sin(end)            // pháp tuyến (hướng ra ngoài)
            val head = Path().apply {
                moveTo(ex + tx * 8f, ey + ty * 8f)
                lineTo(ex + nx * 6f, ey + ny * 6f)
                lineTo(ex - nx * 6f, ey - ny * 6f)
                close()
            }
            val face = p.v(0xFFB4E37A, 0xFF4F9A2A, 8f, 36f)
            withTransform({ translate(0f, 3f) }) {
                drawArc(p.c(0xFF3C6E1E), start, sweep, false, tl, sz, style = Stroke(width = 6.2f, cap = StrokeCap.Round))
                drawPath(head, p.c(0xFF3C6E1E))
            }
            drawArc(brush = face, startAngle = start, sweepAngle = sweep, useCenter = false, topLeft = tl, size = sz, style = Stroke(width = 6.2f, cap = StrokeCap.Round))
            drawPath(head, face)
        }
    }
}

private fun DrawScope.bulbBody(b: Brush) {
    drawCircle(brush = b, radius = 11.8f, center = Offset(20f, 16.3f))
    drawPath(BulbNeck, b)
}

private fun DrawScope.bar(p: ToolPal, x: Float, y: Float, h: Float, top: Long, bottom: Long, sideC: Long) {
    drawRoundRect(p.c(sideC), Offset(x, y + 2.6f), Size(8.6f, h), CornerRadius(3f, 3f))
    drawRoundRect(brush = p.v(top, bottom, y, y + h), topLeft = Offset(x, y), size = Size(8.6f, h), cornerRadius = CornerRadius(3f, 3f))
    drawRoundRect(Color(0x80FFFFFF), Offset(x + 1.4f, y + 1.4f), Size(2f, h - 5f), CornerRadius(1f, 1f))
}

private val FlagPath = Path().apply {
    moveTo(13f, 8f)
    cubicTo(18f, 5.5f, 22f, 11f, 28f, 8.5f)
    cubicTo(30f, 7.7f, 32f, 7f, 34.5f, 6.5f)
    lineTo(34.5f, 22f)
    cubicTo(32f, 22.6f, 30f, 23.3f, 28f, 24f)
    cubicTo(22f, 26.5f, 18f, 21f, 13f, 23.5f)
    close()
}

private val FlagShine = Path().apply {
    moveTo(13.5f, 8.8f)
    cubicTo(18f, 7f, 22f, 12.2f, 28f, 9.8f)
    cubicTo(30f, 9f, 32f, 8.4f, 34f, 8f)
}

private val BulbNeck = Path().apply {
    moveTo(11.1f, 24.2f)
    cubicTo(12.5f, 25.7f, 13.2f, 27f, 13.2f, 29f)
    lineTo(26.8f, 29f)
    cubicTo(26.8f, 27f, 27.5f, 25.7f, 28.9f, 24.2f)
    close()
}

private val BulbFilament = Path().apply {
    moveTo(16f, 15.5f); lineTo(20f, 21f); lineTo(24f, 15.5f)
    moveTo(20f, 21f); lineTo(20f, 28f)
}

private val UndoArrow = Path().apply {
    moveTo(14f, 15.5f)
    lineTo(23.5f, 15.5f)
    cubicTo(28.33f, 15.5f, 32.25f, 19.42f, 32.25f, 24.25f)
    cubicTo(32.25f, 29.08f, 28.33f, 33f, 23.5f, 33f)
    lineTo(15f, 33f)
}

private val UndoHead = Path().apply {
    moveTo(14.5f, 7.5f); lineTo(5.5f, 15.5f); lineTo(14.5f, 23.5f); close()
}

private val UndoShine = Path().apply {
    moveTo(15f, 12.6f)
    lineTo(23.5f, 12.6f)
    cubicTo(25.9f, 12.6f, 27.6f, 13.5f, 28.4f, 15f)
}
