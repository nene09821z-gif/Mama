package com.vila.chess.profile

import com.vila.chess.billing.MembershipTier
import kotlin.math.roundToInt

// =============================================================================
// Mô hình dữ liệu + logic THUẦN của hệ thống Hồ sơ (không phụ thuộc Android → test được bằng JUnit thường).
// =============================================================================

const val DEFAULT_ELO = 800

/** Ba thể loại hiện trên hồ sơ (khớp RatingMode.BULLET/BLITZ/RAPID của Stats.kt; "Tự do" không hiện). */
enum class EloMode(val key: String, val title: String, val subtitle: String) {
    BULLET("bullet", "Bullet", "Siêu chớp"),
    BLITZ("blitz", "Blitz", "Chớp"),
    RAPID("rapid", "Rapid", "Nhanh");

    companion object {
        fun fromKey(k: String?): EloMode? = values().firstOrNull { it.key == k }
    }
}

/** Khoảng thời gian của biểu đồ Elo. */
enum class EloRange(val label: String, val days: Int) {
    WEEK("7 ngày", 7),
    MONTH("30 ngày", 30),
    YEAR("1 năm", 365),
}

/** Một mốc Elo: [ts] = epoch ms. */
data class EloPoint(val ts: Long, val rating: Int)

/** Hồ sơ công khai của một người chơi (khớp bảng `users` trên Supabase). */
data class UserProfile(
    val userId: String,
    val displayName: String,
    val avatarKey: String = "",
    val countryCode: String = "",
    val tier: MembershipTier = MembershipTier.FREE,
    val bullet: Int = DEFAULT_ELO,
    val blitz: Int = DEFAULT_ELO,
    val rapid: Int = DEFAULT_ELO,
    val played: Int = 0,
    val won: Int = 0,
    val drawn: Int = 0,
    val lost: Int = 0,
    /** Chuỗi kết quả hiện tại: +n = n ván thắng liên tiếp, -n = n ván thua liên tiếp, 0 = không có chuỗi. */
    val resultStreak: Int = 0,
    val eloHistory: Map<EloMode, List<EloPoint>> = emptyMap(),
) {
    fun elo(mode: EloMode): Int = when (mode) {
        EloMode.BULLET -> bullet
        EloMode.BLITZ -> blitz
        EloMode.RAPID -> rapid
    }

    val winRatePct: Int get() = if (played <= 0) 0 else (won * 100.0 / played).roundToInt()
}

fun streakLabel(streak: Int): String = when {
    streak > 0 -> "$streak thắng liên tiếp"
    streak < 0 -> "${-streak} thua liên tiếp"
    else -> "Chưa có chuỗi"
}

/** Một dòng trong tab "Ván đấu". [score]: 1.0 thắng, 0.5 hòa, 0.0 thua. */
data class GameRecord(
    val ts: Long,
    val opponent: String,
    val score: Double,
    val modeKey: String,
    /** Thay đổi Elo sau ván (0 nếu không tính điểm). */
    val delta: Int,
    val moves: Int,
)

// -----------------------------------------------------------------------------
// Trạng thái tải + lỗi
// -----------------------------------------------------------------------------

enum class ProfileError { NOT_CONFIGURED, NOT_SIGNED_IN, NETWORK, NOT_FOUND, INVALID_ID, SERVER }

class ProfileException(val kind: ProfileError, message: String? = null) : Exception(message ?: kind.name)

sealed interface LoadState<out T> {
    object Loading : LoadState<Nothing>
    data class Success<T>(val data: T) : LoadState<T>
    data class Error(val kind: ProfileError) : LoadState<Nothing>
}

fun ProfileError.message(): String = when (this) {
    ProfileError.NOT_CONFIGURED -> "Máy chủ hồ sơ chưa được cấu hình."
    ProfileError.NOT_SIGNED_IN -> "Hãy đăng nhập bằng Google để dùng tính năng này."
    ProfileError.NETWORK -> "Không có kết nối mạng. Kiểm tra Internet rồi thử lại."
    ProfileError.NOT_FOUND -> "Không tìm thấy người chơi này."
    ProfileError.INVALID_ID -> "ID người chơi không hợp lệ."
    ProfileError.SERVER -> "Máy chủ đang bận. Vui lòng thử lại sau."
}

// -----------------------------------------------------------------------------
// Chuỗi thắng/thua
// -----------------------------------------------------------------------------

object ResultStreak {
    /** Chuỗi mới sau một ván: thắng cộng dồn chuỗi thắng, thua cộng dồn chuỗi thua, hòa làm đứt chuỗi. */
    fun next(old: Int, score: Double): Int = when {
        score >= 1.0 -> if (old > 0) old + 1 else 1
        score <= 0.0 -> if (old < 0) old - 1 else -1
        else -> 0
    }
}

// -----------------------------------------------------------------------------
// Lịch sử Elo → chuỗi điểm để vẽ biểu đồ
// -----------------------------------------------------------------------------

object EloSeries {
    const val DAY_MS = 86_400_000L
    const val MAX_POINTS = 400

    /**
     * Chuỗi điểm vẽ cho [range] tại thời điểm [now].
     *  - Điểm cuối luôn là (now, [current]) để đường kéo tới hiện tại.
     *  - Nếu có điểm cũ hơn cửa sổ, Elo của nó được "mang" tới đầu cửa sổ để đường bắt đầu đúng mức.
     *  - Trả rỗng khi chưa đủ dữ liệu (không có lịch sử nào) → UI hiện trạng thái trống.
     */
    fun window(history: List<EloPoint>, range: EloRange, now: Long, current: Int): List<EloPoint> {
        if (history.isEmpty()) return emptyList()
        val start = now - range.days * DAY_MS
        val sorted = history.filter { it.ts <= now }.sortedBy { it.ts }
        if (sorted.isEmpty()) return emptyList()
        val inside = sorted.filter { it.ts >= start }
        val baseline = sorted.lastOrNull { it.ts < start }
        val out = ArrayList<EloPoint>(inside.size + 2)
        if (baseline != null) out.add(EloPoint(start, baseline.rating))
        out.addAll(inside)
        if (out.isEmpty() || out.last().ts < now) out.add(EloPoint(now, current))
        else out[out.lastIndex] = EloPoint(now, current)
        return if (out.size >= 2) out else emptyList()
    }

    /**
     * Thêm kết quả một ván. Lần đầu của thể loại này ghi thêm mốc "trước ván" (ts - 1) để đường biểu đồ có điểm xuất phát.
     * Giữ tối đa [cap] điểm mới nhất.
     */
    fun append(history: List<EloPoint>, before: Int, after: Int, ts: Long, cap: Int = MAX_POINTS): List<EloPoint> {
        val out = ArrayList<EloPoint>(history.size + 2)
        out.addAll(history)
        if (out.isEmpty()) out.add(EloPoint(ts - 1, before))
        out.add(EloPoint(ts, after))
        return if (out.size > cap) out.subList(out.size - cap, out.size).toList() else out
    }
}

/** Mã hóa lịch sử thành chuỗi "ts:rating,ts:rating" để lưu SharedPreferences. Dòng hỏng bị bỏ qua. */
object EloHistoryCodec {
    fun encode(points: List<EloPoint>): String = points.joinToString(",") { "${it.ts}:${it.rating}" }

    fun decode(s: String?): List<EloPoint> {
        if (s.isNullOrBlank()) return emptyList()
        val out = ArrayList<EloPoint>()
        for (part in s.split(',')) {
            val i = part.indexOf(':')
            if (i <= 0) continue
            val ts = part.substring(0, i).toLongOrNull() ?: continue
            val r = part.substring(i + 1).toIntOrNull() ?: continue
            out.add(EloPoint(ts, r))
        }
        return out
    }
}

// -----------------------------------------------------------------------------
// Quốc gia / avatar
// -----------------------------------------------------------------------------

data class Country(val code: String, val name: String)

object Countries {
    val all: List<Country> = listOf(
        Country("VN", "Việt Nam"), Country("US", "Hoa Kỳ"), Country("GB", "Vương quốc Anh"), Country("FR", "Pháp"),
        Country("DE", "Đức"), Country("RU", "Nga"), Country("CN", "Trung Quốc"), Country("JP", "Nhật Bản"),
        Country("KR", "Hàn Quốc"), Country("IN", "Ấn Độ"), Country("BR", "Brazil"), Country("CA", "Canada"),
        Country("AU", "Úc"), Country("ES", "Tây Ban Nha"), Country("IT", "Ý"), Country("NL", "Hà Lan"),
        Country("PL", "Ba Lan"), Country("UA", "Ukraine"), Country("TR", "Thổ Nhĩ Kỳ"), Country("MX", "Mexico"),
        Country("AR", "Argentina"), Country("TH", "Thái Lan"), Country("ID", "Indonesia"), Country("MY", "Malaysia"),
        Country("SG", "Singapore"), Country("PH", "Philippines"), Country("LA", "Lào"), Country("KH", "Campuchia"),
        Country("MM", "Myanmar"), Country("TW", "Đài Loan"), Country("HK", "Hồng Kông"), Country("NO", "Na Uy"),
        Country("SE", "Thụy Điển"), Country("FI", "Phần Lan"), Country("DK", "Đan Mạch"), Country("CH", "Thụy Sĩ"),
        Country("AT", "Áo"), Country("BE", "Bỉ"), Country("PT", "Bồ Đào Nha"), Country("CZ", "Séc"),
        Country("HU", "Hungary"), Country("RO", "Romania"), Country("GR", "Hy Lạp"), Country("IL", "Israel"),
        Country("EG", "Ai Cập"), Country("ZA", "Nam Phi"), Country("NZ", "New Zealand"), Country("CU", "Cuba"),
        Country("AM", "Armenia"), Country("AZ", "Azerbaijan"), Country("KZ", "Kazakhstan"), Country("UZ", "Uzbekistan"),
        Country("IR", "Iran"),
    )

    fun byCode(code: String?): Country? = all.firstOrNull { it.code.equals(code, ignoreCase = true) }

    /** Mã ISO 2 chữ cái → emoji cờ (hai ký tự "regional indicator"). Mã sai → chuỗi rỗng. */
    fun flag(code: String?): String {
        val c = code?.trim()?.uppercase().orEmpty()
        if (c.length != 2 || c.any { it !in 'A'..'Z' }) return ""
        val base = 0x1F1E6 - 'A'.code
        return String(Character.toChars(base + c[0].code)) + String(Character.toChars(base + c[1].code))
    }
}

/** Avatar dựng sẵn (ký tự quân cờ + màu nền ARGB). Chưa chọn thì dùng chữ cái đầu của tên. */
data class AvatarPreset(val key: String, val glyph: String, val argb: Long)

object Avatars {
    val presets: List<AvatarPreset> = listOf(
        AvatarPreset("king", "♚", 0xFFE5A100),
        AvatarPreset("queen", "♛", 0xFFB04FD6),
        AvatarPreset("rook", "♜", 0xFF4F8FD6),
        AvatarPreset("bishop", "♝", 0xFF3AA27F),
        AvatarPreset("knight", "♞", 0xFF81B64C),
        AvatarPreset("pawn", "♟", 0xFFD66A4F),
    )

    fun byKey(key: String?): AvatarPreset? = presets.firstOrNull { it.key == key }

    /** Tối đa 2 chữ cái đầu của các từ trong tên (in hoa). Tên rỗng → "?". */
    fun initials(name: String): String {
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return "?"
        val letters = if (parts.size == 1) parts[0].take(1) else parts[0].take(1) + parts.last().take(1)
        return letters.uppercase()
    }

    /** Màu nền ổn định theo tên khi chưa chọn avatar. */
    fun colorFor(seed: String): Long {
        val i = (seed.hashCode() and 0x7FFFFFFF) % presets.size
        return presets[i].argb
    }
}

object NameRules {
    const val MIN = 2
    const val MAX = 20

    /** null = hợp lệ, ngược lại là thông báo lỗi tiếng Việt. */
    fun validate(raw: String): String? {
        val s = raw.trim()
        return when {
            s.length < MIN -> "Tên cần ít nhất $MIN ký tự"
            s.length > MAX -> "Tên tối đa $MAX ký tự"
            s.any { it.isISOControl() } -> "Tên chứa ký tự không hợp lệ"
            else -> null
        }
    }
}
