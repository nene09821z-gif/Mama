package com.vila.chess.profile

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Danh sách bạn bè (Supabase). Dùng chung cho tab "Bạn bè" của màn Hồ sơ và tab Bạn bè ngoài trang chủ
 * (cùng một instance vì cùng Activity) nên hai nơi luôn khớp nhau.
 */
class FriendsViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow<LoadState<List<UserProfile>>>(LoadState.Loading)
    val state: StateFlow<LoadState<List<UserProfile>>> = _state.asStateFlow()

    /** Thông báo ngắn sau khi thêm/xóa bạn (UI hiện rồi gọi [consumeMessage]). */
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    init { refresh() }

    fun consumeMessage() { _message.value = null }

    /** Tải lại. Đang có danh sách thì giữ nguyên trên màn hình trong lúc tải (không nháy spinner). */
    fun refresh() {
        if (_state.value !is LoadState.Success) _state.value = LoadState.Loading
        viewModelScope.launch {
            _state.value = ProfileRepository.fetchFriends(getApplication()).fold(
                onSuccess = { LoadState.Success(it) },
                onFailure = { LoadState.Error(kindOf(it)) },
            )
        }
    }

    fun add(friendId: String) {
        if (_busy.value) return
        _busy.value = true
        viewModelScope.launch {
            ProfileRepository.addFriend(getApplication(), friendId).fold(
                onSuccess = { _message.value = "Đã thêm bạn"; refresh() },
                onFailure = {
                    val k = kindOf(it)
                    _message.value = if (k == ProfileError.INVALID_ID && it.message == "self") "Đó là ID của chính bạn" else k.message()
                },
            )
            _busy.value = false
        }
    }

    fun remove(friendId: String) {
        viewModelScope.launch {
            ProfileRepository.removeFriend(getApplication(), friendId).fold(
                onSuccess = {
                    // Cập nhật ngay trên màn hình, không chờ tải lại
                    (_state.value as? LoadState.Success)?.let { s ->
                        _state.value = LoadState.Success(s.data.filterNot { it.userId == friendId })
                    }
                    _message.value = "Đã xóa khỏi danh sách bạn"
                },
                onFailure = { _message.value = kindOf(it).message() },
            )
        }
    }

    private fun kindOf(t: Throwable): ProfileError = (t as? ProfileException)?.kind ?: ProfileError.SERVER
}
