package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.Achievement as GameAchievement

// =============================================================================
// Hai tab của màn Hồ sơ: "Thành tựu" (lưới huy hiệu) và "Bạn bè" (tìm kiếm + danh sách).
// Dữ liệu huy hiệu: 6 thành tích THẬT của app (trạng thái đạt/chưa lấy từ PlayerStats) + 4 huy hiệu giả lập.
// Dữ liệu bạn bè: giả lập (chưa có backend trạng thái online/Elo bạn bè).
// =============================================================================

/**
 * Huy hiệu hiển thị trong lưới. [icon] là ImageVector của Material (dự án chưa có drawable huy hiệu,
 * và vector tự dựng bằng tay dễ sai đường vẽ -> crash khi inflate).
 */
data class Achievement(
    val id: Int,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val isUnlocked: Boolean,
)

data class Friend(val id: String, val name: String, val elo: Int, val isOnline: Boolean)

private val GoldGlow = Color(0xFFFFC83D)
private val AquaGlow = Color(0xFF4FD1C5)
private val OfflineGray = Color(0xFF7D8696)

/** 6 thành tích thật (theo thứ tự trong game/Stats.kt) + 4 huy hiệu giả lập = 10 huy hiệu. */
fun profileAchievements(real: List<GameAchievement>): List<Achievement> {
    val realIcons = listOf(
        Icons.Filled.Flag, Icons.Filled.EmojiEvents, Icons.Filled.FitnessCenter,
        Icons.Filled.LocalFireDepartment, Icons.Filled.Star, Icons.Filled.MilitaryTech,
    )
    val fromGame = real.mapIndexed { i, a ->
        Achievement(
            id = i + 1, title = a.title, description = a.desc,
            icon = realIcons.getOrElse(i) { Icons.Filled.Star }, isUnlocked = a.done,
        )
    }
    val base = fromGame.size
    val mock = listOf(
        Achievement(base + 1, "Chuỗi 10 trận thắng", "Thắng liên tiếp 10 ván", Icons.Filled.Bolt, false),
        Achievement(base + 2, "Khai cuộc Sicilian", "Chơi 20 ván với Phòng thủ Sicilian", Icons.Filled.Shield, true),
        Achievement(base + 3, "Vua cờ tàn", "Thắng 10 ván ở tàn cuộc", Icons.Filled.WorkspacePremium, false),
        Achievement(base + 4, "Thiên tài chiến thuật", "Giải đúng 100 câu đố", Icons.Filled.Psychology, false),
    )
    return fromGame + mock
}

val MockFriends: List<Friend> = listOf(
    Friend("f1", "Minh Khoa", 1432, true),
    Friend("f2", "Lan Anh", 1187, false),
    Friend("f3", "Hoàng Long", 1650, true),
    Friend("f4", "Thu Trang", 905, false),
    Friend("f5", "Quốc Bảo", 1320, true),
    Friend("f6", "Gia Hân", 1010, false),
    Friend("f7", "Đức Anh", 1544, true),
)

// ------------------------------------------------------------------ Tab: Thành tựu

@Composable
fun AchievementsTab(items: List<Achievement>, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = modifier.fillMaxSize(),
        // Đáy 32dp: hàng cuối không dính mép màn hình.
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(items, key = { it.id }, contentType = { "badge" }) { a ->
            AchievementCell(a, onClick = {
                Toast.makeText(ctx, (if (a.isUnlocked) "Đã đạt: " else "Chưa đạt: ") + a.description, Toast.LENGTH_SHORT).show()
            })
        }
    }
}

@Composable
private fun AchievementCell(a: Achievement, onClick: () -> Unit) {
    val glow = if (a.id % 2 == 0) GoldGlow else AquaGlow
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (a.isUnlocked) {
            // Đã đạt: nền gradient sáng + viền & bóng phát sáng.
            Box(
                Modifier
                    .size(72.dp)
                    .shadow(14.dp, CircleShape, ambientColor = glow, spotColor = glow)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(glow.copy(alpha = 0.55f), Color(0xFF1B2D4A))))
                    .border(2.dp, glow, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(a.icon, contentDescription = a.title, tint = Color.White, modifier = Modifier.size(36.dp))
            }
        } else {
            // Chưa đạt: huy hiệu mờ (alpha 0.3) + ổ khóa ở giữa (ổ khóa KHÔNG bị mờ).
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(72.dp).alpha(0.3f).clip(CircleShape).background(Color(0xFF2B3F63)).border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(a.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Icon(Icons.Filled.Lock, contentDescription = "Chưa đạt", tint = Color.White, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            a.title, color = if (a.isUnlocked) Color.White else VilaColors.TextDim,
            fontSize = 12.sp, fontWeight = if (a.isUnlocked) FontWeight.Bold else FontWeight.Medium,
            textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp,
        )
    }
}

// ------------------------------------------------------------------ Tab: Bạn bè

@Composable
fun FriendsTab(friends: List<Friend>, onChallenge: (Friend) -> Unit, modifier: Modifier = Modifier) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(friends, query) {
        val q = query.trim()
        if (q.isEmpty()) friends else friends.filter { it.name.contains(q, ignoreCase = true) }
    }
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it.take(30) },
            singleLine = true,
            placeholder = { Text("Tìm bạn bè", color = VilaColors.TextDim) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = VilaColors.TextDim) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Clear, contentDescription = "Xóa", tint = VilaColors.TextDim) }
                }
            },
            shape = RoundedCornerShape(50),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = VilaColors.Green, unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = VilaColors.Green,
                focusedContainerColor = Color(0x14FFFFFF), unfocusedContainerColor = Color(0x14FFFFFF),
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        )
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (shown.isEmpty()) {
                item(key = "empty", contentType = "empty") {
                    Text(
                        "Không tìm thấy bạn bè phù hợp.", color = VilaColors.TextDim, fontSize = 14.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp),
                    )
                }
            } else {
                items(shown, key = { it.id }, contentType = { "friend" }) { f -> FriendRow(f, onChallenge = { onChallenge(f) }) }
            }
        }
    }
}

@Composable
private fun FriendRow(f: Friend, onChallenge: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(VilaColors.Glass).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Avatar + viền (xanh = online, xám = offline) + chấm xanh ở góc khi online.
        Box(Modifier.size(52.dp)) {
            ProfileAvatar(
                name = f.name, avatarKey = "", size = 48.dp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .border(2.dp, if (f.isOnline) VilaColors.Green else OfflineGray, CircleShape),
            )
            if (f.isOnline) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(14.dp)
                        .clip(CircleShape).background(VilaColors.Green)
                        .border(2.dp, Color(0xFF16233B), CircleShape),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Elo ${f.elo}", color = VilaColors.TextDim, fontSize = 13.sp)
        }
        if (f.isOnline) {
            Button(
                onClick = onChallenge,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = VilaColors.Green, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                modifier = Modifier.height(36.dp),
            ) { Text("Thách đấu", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
        } else {
            Text("Offline", color = OfflineGray, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
