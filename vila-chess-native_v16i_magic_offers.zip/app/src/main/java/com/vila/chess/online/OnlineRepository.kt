package com.vila.chess.online

import android.content.Context
import androidx.compose.runtime.Immutable
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import org.json.JSONObject

/** Một ván online theo góc nhìn của máy chủ (supabase/online.sql). Giờ còn lại đã do máy chủ trừ thời gian đang chạy. */
class OnlineGame(
    val id: String,
    val whiteId: String,
    val blackId: String,
    val whiteName: String,
    val blackName: String,
    val whiteTier: MembershipTier,
    val blackTier: MembershipTier,
    val baseSec: Int,
    val incSec: Int,
    /** Các nước UCI đã đi ("e2e4", "e7e8q"...). */
    val moves: List<String>,
    val whiteMs: Long,
    val blackMs: Long,
    /** "active" | "finished" | "aborted". */
    val status: String,
    /** "1-0" | "0-1" | "1/2-1/2" | null. */
    val result: String?,
    val reason: String?,
    /** "w" | "b" | null: bên đang cầu hòa. */
    val drawOfferBy: String?,
) {
    val active: Boolean get() = status == "active"
    val aborted: Boolean get() = status == "aborted"
}

sealed interface MatchResult {
    object Waiting : MatchResult
    class Matched(val game: OnlineGame) : MatchResult
    object Cancelled : MatchResult
}

enum class OnlinePhase { IDLE, SEARCHING, ERROR }

/** Trạng thái phần online mà UI cần (màn tìm trận + màn chơi). */
@Immutable
data class OnlineUi(
    val phase: OnlinePhase = OnlinePhase.IDLE,
    val error: String? = null,
    /** Mốc bắt đầu tìm (System.currentTimeMillis) để màn hình tự đếm giờ chờ. */
    val searchStartedAt: Long = 0L,
    val opponentId: String? = null,
    val opponentName: String = "",
    val opponentTier: MembershipTier = MembershipTier.FREE,
    val drawOfferedByOpponent: Boolean = false,
    val drawOfferedByMe: Boolean = false,
    /** Nhiều lần gọi máy chủ liên tiếp thất bại: hiện dải "đang thử kết nối lại". */
    val connectionLost: Boolean = false,
)

/**
 * Gọi các hàm RPC trong supabase/online.sql qua [SupabaseCloud.restCall] (đã có sẵn đăng nhập + làm mới token).
 * Không ném lỗi: mọi hàm trả [Result]; lỗi mất mạng / chưa đăng nhập mang theo [com.vila.chess.profile.ProfileException].
 */
object OnlineRepository {
    private suspend fun rpc(ctx: Context, fn: String, args: JSONObject): Result<JSONObject> =
        SupabaseCloud.restCall(ctx, "POST", "/rest/v1/rpc/$fn", args.toString())
            .mapCatching { JSONObject(it) }

    suspend fun findMatch(ctx: Context, baseSec: Int, incSec: Int): Result<MatchResult> =
        rpc(ctx, "online_find_match", JSONObject().put("p_base", baseSec).put("p_inc", incSec)).mapCatching { parseMatch(it) }

    suspend fun cancelSearch(ctx: Context): Result<MatchResult> =
        rpc(ctx, "online_cancel_search", JSONObject()).mapCatching { parseMatch(it) }

    suspend fun getGame(ctx: Context, id: String): Result<OnlineGame> =
        rpc(ctx, "online_get_game", JSONObject().put("p_id", id)).mapCatching { parseGame(it) }

    /** [ply] = số nước đã có trên bàn TRƯỚC nước này. [result]/[reason] chỉ điền khi nước này kết thúc ván theo luật. */
    suspend fun sendMove(ctx: Context, id: String, ply: Int, uci: String, result: String?, reason: String?): Result<OnlineGame> {
        val args = JSONObject().put("p_id", id).put("p_ply", ply).put("p_uci", uci)
        if (result != null) args.put("p_result", result).put("p_reason", reason ?: "")
        return rpc(ctx, "online_move", args).mapCatching { parseGame(it) }
    }

    suspend fun resign(ctx: Context, id: String): Result<OnlineGame> =
        rpc(ctx, "online_resign", JSONObject().put("p_id", id)).mapCatching { parseGame(it) }

    /** [action] = "offer" (đối thủ đã cầu hòa trước thì là chấp nhận) | "decline". */
    suspend fun draw(ctx: Context, id: String, action: String): Result<OnlineGame> =
        rpc(ctx, "online_draw", JSONObject().put("p_id", id).put("p_action", action)).mapCatching { parseGame(it) }

    // ------------------------------------------------------------------ JSON

    private fun parseMatch(j: JSONObject): MatchResult = when (j.optString("status")) {
        "matched" -> MatchResult.Matched(parseGame(j.getJSONObject("game")))
        "cancelled" -> MatchResult.Cancelled
        else -> MatchResult.Waiting
    }

    private fun JSONObject.strOrNull(key: String): String? = if (isNull(key)) null else optString(key).takeIf { it.isNotEmpty() }

    private fun parseGame(j: JSONObject): OnlineGame = OnlineGame(
        id = j.getString("id"),
        whiteId = j.getString("white_id"),
        blackId = j.getString("black_id"),
        whiteName = j.optString("white_name", "Người chơi"),
        blackName = j.optString("black_name", "Người chơi"),
        whiteTier = MembershipTier.fromId(j.optString("white_tier", "free")),
        blackTier = MembershipTier.fromId(j.optString("black_tier", "free")),
        baseSec = j.getInt("base_sec"),
        incSec = j.getInt("inc_sec"),
        moves = j.optString("moves", "").trim().split(' ').filter { it.isNotEmpty() },
        whiteMs = j.getLong("white_ms"),
        blackMs = j.getLong("black_ms"),
        status = j.optString("status", "active"),
        result = j.strOrNull("result"),
        reason = j.strOrNull("reason"),
        drawOfferBy = j.strOrNull("draw_offer_by"),
    )
}
