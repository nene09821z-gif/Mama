package com.vila.chess.profile

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.vila.chess.auth.AccountStore
import com.vila.chess.billing.MembershipStore
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.game.PlayerStats
import com.vila.chess.game.RatingMode
import com.vila.chess.game.StatsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/** RatingMode (Stats.kt) → thể loại hiện trên hồ sơ. "Tự do" không có Elo công khai → null. */
fun RatingMode.toEloMode(): EloMode? = when (this) {
    RatingMode.BULLET -> EloMode.BULLET
    RatingMode.BLITZ -> EloMode.BLITZ
    RatingMode.RAPID -> EloMode.RAPID
    RatingMode.DAILY -> null
}

/**
 * Phiên người dùng cho hệ thống Hồ sơ: gom `userId`, `elo`, `tier` từ các nguồn đã có trong app
 * (AccountStore = tài khoản, StatsStore = Elo, MembershipStore = gói) thành một [UserProfile].
 *
 * Gói (tier) KHÔNG lưu riêng ở đây — luôn đọc từ [MembershipStore] (nguồn sự thật chung của Google Play, mã kích hoạt, server).
 * Nhờ vậy mua gói / đổi gói / hết hạn đều tự cập nhật huy hiệu; [init] chỉ đăng ký lắng nghe để đồng bộ lên cloud.
 */
object UserSessionManager {
    private const val PREFS = "vila_profile"
    private const val NATIVE_PREFS = "vila_native"   // nơi GameViewModel lưu PlayerStats

    // Compose state: sửa hồ sơ là mọi màn đang hiện tên/avatar tự vẽ lại.
    private var customName by mutableStateOf("")
    var countryCode by mutableStateOf("")
        private set
    var avatarKey by mutableStateOf("")
        private set

    /** Tên hiển thị: tên người dùng tự đặt → tên tài khoản → phần trước @ của email → "Người chơi". */
    val displayName: String
        get() = customName.ifBlank {
            val acc = AccountStore.current
            acc?.name?.takeIf { it.isNotBlank() } ?: acc?.email?.substringBefore('@')?.takeIf { it.isNotBlank() } ?: "Người chơi"
        }

    private var loaded = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var syncJob: Job? = null

    /** Gọi một lần lúc mở app (AppRoot). An toàn khi gọi lại. */
    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        val app = ctx.applicationContext
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        customName = p.getString("name", "") ?: ""
        avatarKey = p.getString("avatar", "") ?: ""
        countryCode = p.getString("country", null) ?: Countries.byCode(Locale.getDefault().country)?.code.orEmpty()
        // Gói đổi (mua thành công / khôi phục / mã kích hoạt / hết hạn) → đẩy tier mới lên cloud để người khác thấy huy hiệu mới.
        scope.launch { MembershipStore.get(app).tier.collect { requestSync(app) } }
    }

    /** Nạp lại tên/quốc gia/avatar từ máy (sau khi đổi tài khoản, dữ liệu trong vila_profile đã được thay). */
    fun reload(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        customName = p.getString("name", "") ?: ""
        avatarKey = p.getString("avatar", "") ?: ""
        countryCode = p.getString("country", null) ?: Countries.byCode(Locale.getDefault().country)?.code.orEmpty()
    }

    // ------------------------------------------------------------------ Đọc dữ liệu

    /** id dùng trên cloud (Supabase uid); chưa đăng nhập Supabase thì dùng id cục bộ ổn định "local-…". */
    fun userId(ctx: Context): String =
        SupabaseCloud.userId(ctx) ?: ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).let { p ->
            p.getString("localId", null) ?: ("local-" + UUID.randomUUID()).also { p.edit().putString("localId", it).apply() }
        }

    /** Gói hiện tại dạng flow (huy hiệu tự đổi màu theo). */
    fun tier(ctx: Context): StateFlow<MembershipTier> = MembershipStore.get(ctx).tier

    fun elo(stats: PlayerStats, mode: EloMode): Int = stats.ratings.getOrNull(mode.ordinal) ?: DEFAULT_ELO

    fun loadStats(ctx: Context): PlayerStats =
        StatsStore.load(ctx.applicationContext.getSharedPreferences(NATIVE_PREFS, Context.MODE_PRIVATE))

    /** Hồ sơ đầy đủ của chính mình từ dữ liệu trong máy. [stats] truyền từ GameViewModel để UI cập nhật ngay sau ván. */
    fun profile(ctx: Context, stats: PlayerStats, withHistory: Boolean = true): UserProfile = UserProfile(
        userId = userId(ctx),
        displayName = displayName,
        avatarKey = avatarKey,
        countryCode = countryCode,
        tier = MembershipStore.get(ctx).tier.value,
        bullet = elo(stats, EloMode.BULLET),
        blitz = elo(stats, EloMode.BLITZ),
        rapid = elo(stats, EloMode.RAPID),
        played = stats.played,
        won = stats.won,
        drawn = stats.drawn,
        lost = stats.lost,
        resultStreak = stats.resultStreak,
        eloHistory = if (withHistory) EloHistoryStore(ctx).loadAll() else emptyMap(),
    )

    // ------------------------------------------------------------------ Ghi dữ liệu

    /** Lưu hồ sơ đã chỉnh. Trả null nếu OK, ngược lại là thông báo lỗi để hiện ngay trong form. */
    fun updateProfile(ctx: Context, name: String, country: String, avatar: String): String? {
        NameRules.validate(name)?.let { return it }
        val app = ctx.applicationContext
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("name", name.trim()).putString("country", country).putString("avatar", avatar).apply()
        customName = name.trim()
        countryCode = country
        avatarKey = avatar
        requestSync(app, delayMs = 0)
        return null
    }

    /** Gọi từ GameViewModel khi một ván TÍNH ĐIỂM kết thúc: ghi lịch sử Elo + lịch sử ván, rồi đồng bộ cloud. */
    fun onGameFinished(ctx: Context, mode: RatingMode, before: Int, after: Int, score: Double, opponent: String, moves: Int) {
        val app = ctx.applicationContext
        val now = System.currentTimeMillis()
        val em = mode.toEloMode()
        if (em != null) EloHistoryStore(app).record(em, before, after, now)
        GameHistoryStore(app).add(GameRecord(now, opponent, score, em?.key ?: "free", after - before, moves))
        requestSync(app)
    }

    /** Đăng xuất: bỏ tên/quốc gia/avatar tự đặt để tài khoản sau không thừa hưởng. (Elo, gói vẫn của thiết bị.) */
    fun clear(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("name").remove("country").remove("avatar").apply()
        customName = ""
        avatarKey = ""
        countryCode = Countries.byCode(Locale.getDefault().country)?.code.orEmpty()
    }

    // ------------------------------------------------------------------ Đồng bộ cloud (best-effort, gộp nhiều lần gọi)

    /**
     * Đẩy hồ sơ lên Supabase sau [delayMs]. Gọi dồn dập (nhiều ván liền, gói đổi...) chỉ gửi một lần.
     * Thất bại/mất mạng/chưa đăng nhập Supabase đều im lặng: hồ sơ trong máy không bị ảnh hưởng, lần sau gửi lại.
     */
    fun requestSync(ctx: Context, delayMs: Long = 1500) {
        val app = ctx.applicationContext
        syncJob?.cancel()
        syncJob = scope.launch {
            delay(delayMs)
            runCatching { ProfileRepository.pushMyProfile(app, profile(app, loadStats(app))) }
        }
    }
}
