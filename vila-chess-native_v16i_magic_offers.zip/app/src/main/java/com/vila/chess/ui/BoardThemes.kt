package com.vila.chess.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

data class BoardTheme(val id: String, val label: String, val light: Color, val dark: Color)

/**
 * Màu bàn cờ. [current] là state của Compose: VilaColors.BoardLight/BoardDark đọc từ đây nên MỌI bàn cờ
 * (ván đấu, câu đố, xem lại, xem trước) đổi màu ngay, không cần sửa từng chỗ.
 */
object BoardThemes {
    const val DEFAULT = "green"

    val all: List<BoardTheme> = listOf(
        BoardTheme("green", "Xanh lá", Color(0xFFEBECD0), Color(0xFF739552)),
        BoardTheme("brown", "Gỗ cổ điển", Color(0xFFF0D9B5), Color(0xFFB58863)),
        BoardTheme("blue", "Xanh biển", Color(0xFFDEE3E6), Color(0xFF8CA2AD)),
        BoardTheme("walnut", "Óc chó", Color(0xFFEAD8B8), Color(0xFF8B5E3C)),
        BoardTheme("purple", "Tím mộng mơ", Color(0xFFE6DDF0), Color(0xFF8E6BBF)),
        BoardTheme("rose", "Hồng pastel", Color(0xFFFCE4EC), Color(0xFFE58FB0)),
        BoardTheme("slate", "Xám đá", Color(0xFFDDDDDD), Color(0xFF7A8691)),
        BoardTheme("midnight", "Đêm xanh", Color(0xFF9FB4D1), Color(0xFF2F4A75)),
        BoardTheme("emerald", "Ngọc bích", Color(0xFFD9F2E6), Color(0xFF2E8B6E)),
        BoardTheme("sunset", "Hoàng hôn", Color(0xFFFFE3C2), Color(0xFFE07B39)),
        BoardTheme("coffee", "Cà phê", Color(0xFFE9DCC9), Color(0xFF6F4E37)),
        BoardTheme("wine", "Đỏ rượu", Color(0xFFF2DADA), Color(0xFFA33B4A)),
        BoardTheme("ice", "Băng tuyết", Color(0xFFF2F8FC), Color(0xFF7FB2D9)),
        BoardTheme("desert", "Cát sa mạc", Color(0xFFF3E5C0), Color(0xFFC9A66B)),
        BoardTheme("mono", "Đen trắng", Color(0xFFEEEEEE), Color(0xFF3A3A3A)),
        BoardTheme("forest", "Rừng sâu", Color(0xFFCFE0C3), Color(0xFF3E6B48)),
        BoardTheme("teal", "Xanh ngọc", Color(0xFFD5ECEC), Color(0xFF3B8C94)),
        BoardTheme("gold", "Vàng kim", Color(0xFFFBF0C9), Color(0xFFD4A72C)),
        BoardTheme("bubblegum", "Kẹo cao su", Color(0xFFFFFFFF), Color(0xFFFBD5DC)),
        BoardTheme("charcoal", "Than đen", Color(0xFF5E6B80), Color(0xFF252B38)),
    )

    fun exists(id: String): Boolean = all.any { it.id == id }

    fun byId(id: String): BoardTheme = all.firstOrNull { it.id == id } ?: all[0]

    var current: BoardTheme by mutableStateOf(all[0])
        private set

    fun select(id: String) {
        current = byId(id)
    }
}
