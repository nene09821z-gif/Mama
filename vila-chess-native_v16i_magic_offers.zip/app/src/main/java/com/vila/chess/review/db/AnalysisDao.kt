package com.vila.chess.review.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AnalysisDao {

    // REPLACE trên summary xóa dòng cũ => CASCADE xóa luôn các result cũ của ván đó trước khi ghi lại.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSummary(summary: AnalysisSummary)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResults(rows: List<AnalysisResult>)

    /** Phát lại mỗi khi Worker ghi xong (hoặc xóa) kết quả của ván. null = chưa có. */
    @Query("SELECT * FROM analysis_summary WHERE gameId = :gameId LIMIT 1")
    fun observeSummary(gameId: String): Flow<AnalysisSummary?>

    @Query("SELECT * FROM analysis_summary WHERE gameId = :gameId LIMIT 1")
    suspend fun summary(gameId: String): AnalysisSummary?

    @Query("SELECT * FROM analysis_result WHERE gameId = :gameId ORDER BY ply ASC")
    suspend fun results(gameId: String): List<AnalysisResult>

    @Query("DELETE FROM analysis_summary WHERE gameId = :gameId")
    suspend fun deleteGame(gameId: String): Int

    /** Bản chặn luồng cho nơi gọi không phải coroutine (GameReviewStore.delete). CHỈ gọi từ luồng nền. */
    @Query("DELETE FROM analysis_summary WHERE gameId = :gameId")
    fun deleteGameBlocking(gameId: String): Int

    @Query("SELECT gameId FROM analysis_summary")
    suspend fun completedIds(): List<String>
}
