package com.vila.chess.review.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Một dòng cho MỖI ván đã phân tích XONG. Có dòng này = kết quả đã sẵn sàng (Worker ghi nó CUỐI CÙNG,
 * cùng giao dịch với các [AnalysisResult]) nên màn Review không bao giờ thấy kết quả dở dang.
 */
@Entity(tableName = "analysis_summary")
data class AnalysisSummary(
    @PrimaryKey val gameId: String,
    val accuracyWhite: Double,
    val accuracyBlack: Double,
    val tier: String,
    val createdAt: Long,
    val startFen: String?,
    val engine: String,
    val multiPv: Int,
    val moveCount: Int,
    /** Phiên bản thuật toán phân loại. Nhỏ hơn bản hiện tại => coi như chưa phân tích. */
    val version: Int,
)

/**
 * Kết quả của TỪNG NƯỚC ĐI (ply 1 = nước đầu tiên). Xóa [AnalysisSummary] => các dòng này tự xóa (CASCADE).
 * Điểm theo góc nhìn TRẮNG (dương = Trắng hơn), xem quy ước ở MoveReview.
 */
@Entity(
    tableName = "analysis_result",
    primaryKeys = ["gameId", "ply"],
    foreignKeys = [
        ForeignKey(
            entity = AnalysisSummary::class,
            parentColumns = ["gameId"],
            childColumns = ["gameId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("gameId")],
)
data class AnalysisResult(
    val gameId: String,
    val ply: Int,
    val whiteMoved: Boolean,
    /** Tên MoveLabel (BOOK, BRILLIANT, GREAT, BEST, EXCELLENT, GOOD, INACCURACY, MISTAKE, BLUNDER, MISS). */
    val label: String,
    /** EP loss (% xác suất thắng mất đi). */
    val winLoss: Double,
    /** FEN thế TRƯỚC nước đi / SAU nước đi. */
    val fen: String?,
    val fenAfter: String?,
    /** Nước tốt nhất của engine ở thế trước (UCI). */
    val bestMove: String?,
    /** Điểm cp SAU nước đi (Trắng). */
    val scoreCp: Int,
    val evalBeforeCp: Int?,
    val mateBefore: Int?,
    val mateAfter: Int?,
    val uci: String?,
    val san: String?,
    /** PV của thế trước, các nước UCI cách nhau bằng dấu cách. */
    val pv: String,
    val depthBefore: Int,
    val depthAfter: Int,
    val secondBestMove: String?,
    val secondBestCp: Int?,
    val secondBestMate: Int?,
    val engine: String,
    val multiPv: Int,
    val ecoCode: String?,
    val openingName: String?,
    /** Expected Points (0.0–1.0) của bên vừa đi trước / sau nước đi. */
    val epBefore: Double? = null,
    val epAfter: Double? = null,
)
