package com.vila.chess.game

// Bản RỖNG dự phòng để dự án luôn biên dịch được.
// scripts/generate_puzzles.py (chạy trong GitHub Actions) ghi đè file này bằng các khóa chiến thuật từ Lichess.
object LessonLichessData {
    val courses: List<Course> = emptyList()
}
