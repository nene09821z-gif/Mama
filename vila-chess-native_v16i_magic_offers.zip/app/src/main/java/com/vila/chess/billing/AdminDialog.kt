package com.vila.chess.billing

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.ui.VilaColors

/**
 * Trang admin ẩn: bấm 7 lần vào tiêu đề "Nâng cấp ChessPlus" → nhập PIN → tạo mã kích hoạt cho khách
 * (không cần chạy script), hoặc tự cấp gói cho máy này để thử.
 */
@Composable
fun AdminDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    var device by remember { mutableStateOf("") }
    var tier by remember { mutableStateOf(MembershipTier.GOLD) }
    var period by remember { mutableStateOf(BillingPeriod.MONTHLY) }
    var code by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF262522),
        title = { Text(if (unlocked) "Admin · Tạo mã kích hoạt" else "Admin", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp) },
        text = {
            if (!unlocked) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = pin, onValueChange = { pin = it; pinError = false }, singleLine = true,
                        placeholder = { Text("Nhập PIN admin", color = VilaColors.TextDim) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        isError = pinError, modifier = Modifier.fillMaxWidth(),
                    )
                    if (pinError) Text("PIN không đúng", color = Color(0xFFFF8A80), fontSize = 13.sp)
                }
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = device, onValueChange = { device = it.take(12); code = null },
                        singleLine = true, label = { Text("Mã thiết bị của khách (8 ký tự)", color = VilaColors.TextDim) },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Chips(listOf(MembershipTier.GOLD, MembershipTier.PLATINUM, MembershipTier.DIAMOND, MembershipTier.FAMILY), tier, { it.displayName }) { tier = it; code = null }
                    Chips(listOf(BillingPeriod.MONTHLY, BillingPeriod.YEARLY), period, { if (it == BillingPeriod.MONTHLY) "1 tháng" else "1 năm" }) { period = it; code = null }
                    TextButton(onClick = {
                        LicenseManager.generate(device, tier, period).fold(
                            onSuccess = { code = it; info = null },
                            onFailure = { code = null; info = it.message },
                        )
                    }) { Text("Tạo mã", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
                    code?.let { c ->
                        Text(c, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = {
                                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", c))
                                Toast.makeText(ctx, "Đã sao chép mã", Toast.LENGTH_SHORT).show()
                            }) { Text("Sao chép", color = VilaColors.Green) }
                            TextButton(onClick = {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, "Mã kích hoạt ChessPlus " + tier.displayName + ": " + c)
                                }
                                ctx.startActivity(Intent.createChooser(send, "Gửi mã").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }) { Text("Gửi", color = VilaColors.Green) }
                        }
                    }
                    info?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp) }

                    Text("Trên máy này", color = VilaColors.TextDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    TextButton(onClick = {
                        val exp = LicenseManager.grantSelf(ctx, tier, 365)
                        info = "Đã cấp " + tier.displayName + " đến " + LicenseManager.formatDate(exp)
                    }) { Text("Tự cấp gói đang chọn (365 ngày)", color = Color(0xFFE3ECFA)) }
                    TextButton(onClick = {
                        LicenseManager.revokeSelf(ctx)
                        info = "Đã gỡ gói cấp bằng mã/admin trên máy này"
                    }) { Text("Gỡ gói cấp bằng mã", color = Color(0xFFE3ECFA)) }
                    Text("Mã thiết bị máy này: " + LicenseManager.deviceCode(ctx), color = VilaColors.TextDim, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            if (!unlocked) {
                TextButton(onClick = { if (LicenseManager.checkAdminPin(pin)) unlocked = true else pinError = true }) {
                    Text("Mở", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold)
                }
            } else TextButton(onClick = onDismiss) { Text("Xong", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
        },
        dismissButton = { if (!unlocked) TextButton(onClick = onDismiss) { Text("Đóng", color = Color(0xFFBABABA)) } },
    )
}

@Composable
private fun <T> Chips(items: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { item ->
            val on = item == selected
            Text(
                label(item), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .background(if (on) VilaColors.Green else Color(0xFF3C3A37))
                    .clickable { onPick(item) }.padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
    }
}
