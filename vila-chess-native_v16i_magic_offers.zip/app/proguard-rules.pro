# R8 đang bật cho cả release và debug. App không dùng reflection/JNI (Room, WorkManager, Billing,
# Credentials, AppAuth tự mang theo consumer rules), nên chỉ cần vài dòng dưới đây.

# Giữ số dòng để stack trace đọc được.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# Room: lớp DB/DAO/entity do KSP sinh ra, tham chiếu bằng ReviewDatabase::class.java.
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao interface *

# Cảnh báo thiếu lớp tuỳ chọn của thư viện bên thứ ba (không ảnh hưởng chạy) — tránh R8 làm hỏng build.
-dontwarn javax.annotation.**
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
-dontwarn com.google.errorprone.annotations.**

# Rive (avatar thầy): thư viện gọi JNI/native nên giữ nguyên tên lớp.
-keep class app.rive.** { *; }
-dontwarn app.rive.**
