plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose")
  id("com.google.devtools.ksp")
}

android {
  namespace = "com.vila.chess"
  compileSdk = 35

  defaultConfig {
    applicationId = "com.vila.chessnative"
    minSdk = 24
    targetSdk = 35
    versionCode = 1
    versionName = "0.1.0"
    // AppAuth: scheme redirect của luồng đăng nhập Google toàn trang (= package name)
    manifestPlaceholders["appAuthRedirectScheme"] = "com.vila.chessnative"
  }

  // Keystore cố định => SHA-1 không đổi giữa các lần build CI (cần cho Google).
  // Chỉ áp dụng khi file app/vila.keystore tồn tại; thiếu file thì build debug như cũ.
  signingConfigs {
    getByName("debug") {
      val ks = file("vila.keystore")
      if (ks.exists()) {
        storeFile = ks
        storePassword = "vila123"
        keyAlias = "vila"
        keyPassword = "vila123"
      }
    }
  }

  // HIỆU NĂNG: Compose ở bản không-R8 + debuggable chậm hơn rõ rệt (giật khi kéo quân, lag khi mở màn).
  // => bật R8 (thu nhỏ + tối ưu code) và Baseline Profile (app/src/main/baseline-prof.txt) cho cả release lẫn debug.
  // Cả hai cùng ký bằng keystore cố định (vila.keystore) nên SHA-1 không đổi (đăng nhập Google vẫn chạy)
  // và cài đè lên nhau được.
  // Muốn quay lại bản debug thường để gỡ lỗi bằng debugger: đặt isMinifyEnabled=false và isDebuggable=true cho "debug".
  buildTypes {
    release {
      isMinifyEnabled = true
      isShrinkResources = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("debug")
    }
    debug {
      isMinifyEnabled = true
      isDebuggable = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  kotlinOptions {
    jvmTarget = "17"
  }

  buildFeatures {
    compose = true
  }

  // Giải nén libstockfish.so ra đĩa để chạy được bằng ProcessBuilder.
  packaging {
    jniLibs {
      useLegacyPackaging = true
    }
  }

  testOptions {
    unitTests.isReturnDefaultValues = true
  }
}

dependencies {
  val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
  implementation(composeBom)
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.activity:activity-compose:1.9.3")
  implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
  implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.compose.ui:ui-graphics")
  implementation("androidx.compose.foundation:foundation")
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.material:material-icons-extended")
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
  implementation("androidx.work:work-runtime-ktx:2.9.1")
  // Cài Baseline Profile (biên dịch sẵn code nóng) ngay khi mở app lần đầu => bớt giật lúc đầu.
  implementation("androidx.profileinstaller:profileinstaller:1.4.1")
  // Room: lưu kết quả Game Review (bảng analysis_summary / analysis_result), UI quan sát bằng Flow.
  implementation("androidx.room:room-runtime:2.6.1")
  implementation("androidx.room:room-ktx:2.6.1")
  ksp("androidx.room:room-compiler:2.6.1")
  // Google Play Billing 7.x (+ bản ktx cho suspend API)
  implementation("com.android.billingclient:billing-ktx:7.1.1")

  // Đăng nhập: Google (Credential Manager) + email/mật khẩu (Supabase)
  implementation("androidx.credentials:credentials:1.3.0")
  implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
  implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
  implementation("net.openid:appauth:0.11.1")

  // Thầy giáo: avatar Rive 2.5D (res/raw/teacher_avatar.riv). "9.+" = bản 9.x mới nhất; nên ghim số cụ thể sau khi build thành công.
  implementation("app.rive:rive-android:9.+")
  implementation("androidx.startup:startup-runtime:1.1.1")

  testImplementation("junit:junit:4.13.2")
  // android.jar trong unit test chỉ có stub org.json (trả về rỗng): cần bản thật để test ReviewJson.
  testImplementation("org.json:json:20240303")
}
