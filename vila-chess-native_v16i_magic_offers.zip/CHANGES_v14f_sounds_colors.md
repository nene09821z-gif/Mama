# v14f — Nhiều bộ âm thanh, 18 màu bàn cờ, sửa đi-trước/phong cấp

## Âm thanh (Các tùy chỉnh > Bộ âm thanh)
7 bộ: Cổ điển (có sẵn) · Gỗ · Pha lê · Piano mềm · Arcade 8-bit · Trống · Giọt nước. Mỗi bộ 6 tiếng: đi quân, ăn quân, nhập thành, chiếu, phong cấp, hết ván.
Chạm để chọn + nghe thử. File tự tổng hợp (scripts/gen_sounds.py, không bản quyền, ~690 KB tổng).
game/SoundPacks.kt (danh sách + tìm file theo tên), game/Feedback.kt (SoundPlayer.setPack).

## Màu bàn cờ (Các tùy chỉnh > Màu bàn cờ)
18 màu (Xanh lá, Gỗ cổ điển, Xanh biển, Óc chó, Tím, Hồng, Xám đá, Đêm xanh, Ngọc bích, Hoàng hôn, Cà phê, Đỏ rượu, Băng tuyết, Cát sa mạc, Đen trắng, Rừng sâu, Xanh ngọc, Vàng kim).
ui/BoardThemes.kt; VilaColors.BoardLight/BoardDark đọc từ chủ đề đang chọn ⇒ ván đấu, câu đố, xem lại ván đều đổi màu cùng lúc.

## Sửa lỗi quân nhảy về chỗ cũ
- Đi trước (premove) chế độ ĐƠN: trước đây thả quân xong nó bị trả về ô cũ (chỉ chế độ Nhiều mới nằm lại ô đích). Giờ cả Nhiều lẫn Đơn đều
  hiện quân ở ô đích trên bàn cờ ảo, kể cả khi ăn quân / phong cấp (như chess.com).
- Hộp "Phong cấp thành": chạm ra ngoài hộp không còn hủy nước đi (trước đây chạm nhầm là quân bị trả về ô cũ). Nút Back vẫn hủy.
- Chưa tái hiện được lỗi "phong cấp không ăn được quân" ở ván thường: luật đi (Position.generatePseudo/make/unmake) và PuzzleSession
  xử lý ăn quân + phong cấp đúng khi đọc code. Nếu còn lỗi, cần biết: chơi với bot hay câu đố, chạm hay kéo, chế độ đi trước nào.
