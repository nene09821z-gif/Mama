# v16d — Nhãn phân tích theo đúng luật Chess.com + Lichess

Chỉ đổi logic gán nhãn (hàm thuần, không đụng giao diện / engine). Win% và Accuracy% vẫn là công thức Lichess; ngưỡng
Excellent/Good/Inaccuracy/Mistake/Blunder vẫn là bảng Expected Points công bố của Chess.com (2 / 5 / 10 / 20%).

## 1. Đi vào thế bị chiếu hết / bỏ lỡ chiếu hết — luật mate của Lichess
Win% bão hòa ở 0 và 100 nên "đi vào thế bị mate" chỉ bị tính bằng win% trước nước đi (vd. thế -5,0 => mất 13,6% => chỉ Mistake)
dù Lichess gọi đó là Blunder. Nay áp thêm **sàn EP loss** theo lila `Advice.scala` (cp của BÊN ĐI):
- Đi vào thế bị mate (trước đó chưa bị mate): cp trước ≥ -700 => **Blunder**; -700…-999 => Mistake; < -999 (đã thua nặng) => Inaccuracy.
- Bỏ lỡ mate (đang có mate, thế sau không còn mate): cp sau ≤ 700 => **Blunder**; 700…999 => Mistake; > 999 => Inaccuracy.
- Đang có mate mà đi thành bị mate ngược: luôn Blunder.
- Nước tốt nhất của engine không bao giờ bị phạt. Thay cho hằng cũ `MISSED_MATE_LOSS = 12`.
- Vòng kiểm chứng sâu (`ReviewVerify`) cũng chọn các nước dính luật mate để tìm lại sâu hơn trước khi chốt nhãn.

## 2. Brilliant — đúng định nghĩa Chess.com
Chess.com: "bạn không được thắng đậm **ngay cả khi không tìm ra nước này**". Bản cũ kiểm tra win% *của chính nước tốt nhất*
(≤ 85) nên một cú hy sinh thắng cưỡng bức (win% 100) KHÔNG BAO GIỜ được Brilliant — ngược hẳn ý nghĩa của nhãn.
Nay kiểm tra **nước thay thế tốt nhất** (`winIfNotPlayed`): đã đi nước tốt nhất thì nhìn nước tốt nhì (MultiPV 2); nước tốt nhì
vẫn ≤ 85% win thì hy sinh đó mới là chìa khóa => Brilliant. Không có nước tốt nhì (engine 1 PV / chỉ 1 nước hợp lệ) thì giữ cách cũ (thận trọng).
Ví dụ ván smothered mate `10.Re1? Nf2+ 11.Kg1 Nh3+ 12.Kh1 Qg1+!! 13.Rxg1 Nf2#`: 10.Re1 => Blunder, 12...Qg1+ => Brilliant (khi các nước khác không thắng đậm).

## 3. ReviewJson.CURRENT_VERSION 5 → 6
Ván đã phân tích bằng cách chấm cũ tự phân tích lại (ngầm) khi mở.

## Test
`ReviewAnalyzerTest.kt` thêm lớp `ReviewMateRulesTest` (9 test): ngưỡng ±700/±999, các trường hợp `mateRuleFloor`,
ván smothered mate đủ 8 nước, Brilliant theo nước thay thế, nước tốt nhất không bị phạt. Đã chạy cùng ReviewVerifyTest,
LichessAccuracyTest, GameReviewLogicTest: 39 test đều qua (biên dịch bằng Kotlin 2.0.21 + JUnit 4.13 trên JVM).
