# v18i — Phân tích ngầm TRƯỚC khi hết ván ("gần xong" là bắt đầu), vẫn mượt

## Vấn đề
Game Review chỉ bắt đầu sau khi ván kết thúc nên người chơi phải chờ cả vòng phân tích.

## Cách làm
Khi ván "gần xong" thì tranh thủ phân tích các thế cờ đã đi, lúc đang chơi, bằng một engine nền cực nhẹ.
Hết ván GameAnalysisWorker dùng lại những thế đã có, chỉ tính nốt phần còn thiếu => review hiện gần như ngay.

### 1. Khi nào là "gần xong" (review/NearEnd.kt, hàm thuần, chỉ đếm quân/đồng hồ, không hỏi engine)
Điều kiện chung: đã đi >= 16 nửa nước. Chỉ cần MỘT trong:
- Tàn cuộc: tổng số quân (kể cả 2 vua) <= 8
- Chênh quân >= 1 Hậu (900) và đã qua 24 nửa nước
- Sắp hết giờ: bên ít giờ hơn còn <= max(15s, 12% giờ gốc)
- Sắp hòa: đồng hồ 50 nước >= 40 nửa nước
Đã gần xong thì giữ nguyên cả ván (không dao động). Không phân tích trước nếu hôm nay hết lượt Game Review (cuối ván cũng không chạy review).

### 2. Mượt như thế nào (review/PreAnalyzer.kt)
- Engine RIÊNG, chỉ native (không bao giờ dùng wasm/WebView vì chạy trên luồng chính), 1 luồng, Hash <= 16MB, nice 19 (thấp nhất).
  Không có libstockfish.so thì âm thầm tắt phân tích trước, cuối ván Worker vẫn làm đủ như cũ.
- Chỉ chạy khi KHÔNG: máy đang nghĩ nước đi, rời màn bàn cờ, ván đã xong, đang chọn quân phong cấp. Kiểm tra mỗi 80ms và gửi `stop`
  ngay khi cần nhường; kết quả bị ngắt (nông) bị bỏ, tính lại sau.
- Nghỉ 350ms sau mỗi lần tiếp tục để animation đi quân chạy xong rồi mới tính. Máy nóng > 40°C thì nghỉ như Worker.
- Máy yếu (RAM < 3GB / CPU yếu): còn tạm dừng khi người chơi đang chạm/kéo quân.
- Tính thế MỚI NHẤT trước rồi lùi dần về đầu ván. Bắt kịp hết thì chờ; rảnh > 20s thì tắt tiến trình engine trả RAM.
- Mọi lỗi chỉ tắt tính năng cho ván đó, không bao giờ làm hỏng ván.

### 3. Dùng lại ở cuối ván (review/PreAnalysisCache.kt, GameAnalysisWorker.kt)
- Cache theo từng thế (khóa = FEN), ghi nối từng dòng vào files/review_queue/<id>.pre ngay khi xong mỗi thế.
  Vì khóa là FEN nên đi lại / hoàn tác nước vẫn dùng đúng.
- Chỉ nhận kết quả của engine native, MultiPV 2, depth >= max(12, depth máy - 4) (nền chạy 1 luồng nên cho thấp hơn tối đa 4 bậc).
  Không đạt thì Worker tính lại thế đó như cũ nên chất lượng nhãn không giảm.
- Hết ván: GameViewModel.enqueueSilentReview gọi preAnalyzer.handOff() (dừng engine nền trước khi Worker chạy) và dùng lại id ván.
  Worker bỏ qua thế đã có, vẫn chạy vòng kiểm chứng sâu cho nước nghi sai. Xong thì xóa file .pre.
- Ván bị bỏ dở / ván mới: cache bị xóa. File .pre bỏ sót > 2 ngày tự dọn.

## File
- Mới: review/NearEnd.kt, review/PreAnalysisCache.kt, review/PreAnalyzer.kt, test/PreAnalysisTest.kt
- Sửa: review/SilentStockfishEngine.kt (thêm allowWasm, niceLevel; mặc định giữ nguyên hành vi cũ),
  review/GameAnalysisWorker.kt (dùng lại cache), game/GameViewModel.kt (preAnalysisTick sau mỗi nước, handOff cuối ván, discard khi ván mới / onCleared)

## Lưu ý
- Chưa build được trong môi trường này (không tải được plugin Android Gradle) nên chưa chạy test. Hãy chạy ./gradlew testDebugUnitTest (PreAnalysisTest) hoặc đẩy lên GitHub Actions.
- Chỉ có ý nghĩa khi libstockfish.so có trong APK (workflow Build APK tải về). Xem Logcat tag "GameAnalysis": "dùng lại x/y thế từ phân tích trước".
