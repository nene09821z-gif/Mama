# v18l — Màn "Các tùy chỉnh" trong ván: các công tắc dùng được thật

## Vấn đề
GameSettingsScreen chỉ lưu vào SettingsViewModel tạm (không nối vào ván, không lưu): Thanh đánh giá, Bộ máy, Gợi ý,
Mũi tên gợi ý, Các mối đe doạ, Takeback và thanh trượt đều không làm gì. "Phản hồi nước đi" ở ván Bot cũng không được truyền vào.

## Nay (BotGameScreen truyền InGameSettings vào GameOptionsHost -> GameSettingsScreen)
- Thanh đánh giá   -> vm.setEvalBar (dùng chung với nút "Đánh giá" ở thanh công cụ).
- Phản Hồi nước đi -> vm.setMoveLabels; nay được NHỚ lần sau (trước đó luôn khởi động ở trạng thái tắt).
- Gợi ý            -> vm.setCoach (cùng công tắc "Nút Gợi ý trong ván cờ" ở tab Thêm: nút Gợi ý + Thầy giáo).
- Bộ máy           -> vm.engineOn: gợi ý kèm đánh giá của engine ("· bạn hơn 0.3 tốt"); tắt thì chỉ nói nước tốt nhất.
- Mũi tên gợi ý    -> vm.hintArrowsOn: tắt thì không vẽ mũi tên xanh (vẫn tô 2 ô của nước gợi ý).
- Các mối đe doạ   -> vm.threatArrowsOn: mũi tên + vòng đỏ từ quân đối thủ tới quân của bạn có thể bị ăn (quân không được bảo vệ,
  hoặc bị quân rẻ hơn ăn). Chỉ ở ván Bot / Tàn cuộc. UiState.threats, tính trong refreshUi.
- Takeback         -> vm.takebackOn: tắt thì nút Hoàn tác bị khoá (vm.undo() cũng từ chối).
- Thanh trượt      -> vm.hintStrengthElo, đổi tên "Độ mạnh gợi ý tối đa" (Elo 400..3200 -> độ sâu gợi ý 2..8; 3200 = như cũ).
  Kéo thì giữ giá trị cục bộ, ghi prefs khi thả tay / bấm Lưu.
- Nút "Tiết kiệm" (dịch nhầm từ "Save") đổi thành "Lưu".
- Tất cả lưu SharedPreferences (opt_engine, opt_hintArrows, opt_threats, opt_takeback, opt_hintElo, moveLabels).

## File
- ui/GameSettingsScreen.kt (InGameSettings), ui/GameOptionsHost.kt, ui/BotGameScreen.kt, ui/BoardView.kt (vẽ mối đe doạ, ẩn mũi tên gợi ý)
- game/GameViewModel.kt, game/UiState.kt, game/Modes.kt (Coach.hint(maxDepth), Coach.depthForElo)
- Mới: test/CoachStrengthTest.kt

## Lưu ý
- Chưa build được trong môi trường này (không có Android SDK) - chạy ./gradlew assembleDebug / testDebugUnitTest hoặc đẩy lên GitHub Actions.
- Chỉ ván Bot / Tàn cuộc có màn tùy chỉnh này (GameOptionsHost chỉ gắn trong BotGameScreen).
