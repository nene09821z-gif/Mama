#!/usr/bin/env python3
"""
Tải mẫu nhạc cụ thật từ VCSL (Versilian Community Sample Library, giấy phép CC0 = phạm vi công cộng,
dùng thương mại được, không cần ghi nguồn) và dựng 5 bộ âm thanh "chill" cho mục Chủ đề > Âm thanh.

  github.com/michaelwillis/VCSL   (CC0 1.0)

5 bộ x 6 tiếng = 30 file res/raw/<bộ>_<tiếng>.wav (44,1 kHz, 16-bit, mono, ~3 MB):
  vibes   Vibraphone  - nốt rung mềm, vang mơ màng
  harp    Đàn hạc     - nốt gảy ấm, dịu
  glock   Glockenspiel - chuông nhỏ lấp lánh như sao đêm
  marimba Marimba     - gỗ ấm, tròn
  ocarina Ocarina     - tiếng sáo đất nung nhẹ như hơi thở

Cách làm: lấy mẫu gần nhất, đổi cao độ tối đa vài bán cung, ghép thành giai điệu ngũ cung (C-D-E-G-A) để
nghe luôn dễ chịu, cắt bỏ khoảng lặng đầu (đi quân là nghe ngay), thêm vang nhẹ, chuẩn hoá.

Dùng:  python3 scripts/get_sounds_vcsl.py [--out app/src/main/res/raw] [--cache DIR] [--force] [--only vibes,harp]
Cần: python3 + numpy + mạng tới raw.githubusercontent.com. Bộ nào đã đủ 6 file thì bỏ qua (trừ khi --force).
Thất bại ở bộ nào thì bộ đó KHÔNG được ghi (app tự ẩn bộ thiếu file, xem SoundPacks.installed). Mã thoát 0 nếu
ít nhất 1 bộ xong, 1 nếu không bộ nào xong.
"""
import argparse
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import wave
from pathlib import Path

import numpy as np

SR = 44100
BASE = "https://raw.githubusercontent.com/michaelwillis/VCSL/master/"
DEFAULT_OUT = Path(__file__).resolve().parent.parent / "app" / "src" / "main" / "res" / "raw"
SFX = ["move", "capture", "castle", "check", "promote", "end"]  # khớp enum Sfx (viết thường) trong Feedback.kt

STRUCK = "Idiophones/Struck Idiophones/"
# bộ -> (thư mục trong repo, {tên nốt: tên file}). Tên file/thư mục lấy đúng từ cây repo VCSL.
INSTRUMENTS = {
    "vibes": (STRUCK + "Vibraphone/Soft Mallets/",
              {n: f"Vibes_soft_{n}_v2_rr1_Main.wav" for n in ["F2", "A2", "C3", "E3", "G3", "B3", "D4", "F4", "A4", "C5", "E5"]}),
    "harp": ("Chordophones/Composite Chordophones/Concert Harp/",
             {**{n: f"KSHarp_{n}_mf1.wav" for n in ["A2", "E3", "B3", "D4", "F4", "A4", "C5", "E5", "B5", "D6", "F6"]},
              "C3": "KSHarp_C3_mf3.wav"}),
    "glock": (STRUCK + "Glockenspiel/",
              {"G4": "glock_soft_G4_01.wav", "C5": "glock_soft_C5_02.wav", "G5": "glock_soft_G5_01.wav",
               "C6": "glock_soft_C6_01.wav", "G6": "glock_soft_G6_01.wav", "C7": "glock_soft_C7_03.wav"}),
    "marimba": (STRUCK + "Marimba/",
                {n: f"Marimba_hit_Outrigger_{n}_med_01.wav" for n in ["F1", "C2", "G2", "B2", "F3", "C4", "G4", "B4", "F5", "C6"]}),
    "ocarina": ("Aerophones/Edge-blown Aerophones/Ocarina, Small/Staccato/",
                {n: f"ocarina_{n}_staccato0.wav" for n in ["A#4", "C5", "D5", "D#5", "E5", "F5", "F#5", "G5", "G#5", "A5", "A#5", "B5", "C6"]}),
}
# dịch giai điệu (bán cung) cho từng nhạc cụ để rơi vào dải nghe hay nhất của nó
# (không hạ quãng tám: loa điện thoại phát yếu dưới ~300 Hz nên giữ mọi nốt ở dải trung)
SHIFT = {"vibes": 0, "harp": 0, "glock": 12, "marimba": 0, "ocarina": 0}

# Giai điệu chung (ngũ cung C): (giây, nốt, âm lượng). Nốt nằm ngoài dải mẫu sẽ tự gập lên/xuống 1 quãng tám.
MELODY = {
    "move":    [(0.00, "G4", 1.00)],
    "capture": [(0.00, "C4", 1.00), (0.00, "G4", 0.45)],
    "castle":  [(0.00, "G4", 0.85), (0.12, "C5", 1.00)],
    "check":   [(0.00, "D5", 1.00), (0.17, "D5", 0.75)],
    "promote": [(0.00, "C5", 0.70), (0.10, "E5", 0.80), (0.20, "G5", 0.90), (0.30, "A5", 1.00)],
    "end":     [(0.00, "C4", 1.00), (0.20, "G4", 0.85), (0.40, "E5", 0.75), (0.62, "C5", 0.70)],
}
LENGTH = {"move": 0.55, "capture": 0.70, "castle": 0.85, "check": 0.90, "promote": 1.35, "end": 2.60}
PEAK = 0.80      # trần đỉnh
TARGET_RMS = 0.12  # độ to cảm nhận chung cho cả 30 file (bộ cũ: 0,05-0,21)

_SEMI = {"C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11}


def midi(name):
    """'C#4' -> 61 (C4 = 60)."""
    n = _SEMI[name[0]]
    rest = name[1:]
    if rest.startswith("#"):
        n += 1
        rest = rest[1:]
    return 12 * (int(rest) + 1) + n


# ───────────────────────────────────────────── tải + đọc wav
def fetch(rel, cache):
    """Tải 1 file VCSL (có lưu tạm để chạy lại không phải tải)."""
    dst = cache / rel.replace("/", "__")
    if dst.is_file() and dst.stat().st_size > 1000:
        return dst.read_bytes()
    url = BASE + urllib.parse.quote(rel)
    last = None
    for i in range(4):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "vila-sounds"}), timeout=60) as r:
                data = r.read()
            if data[:4] != b"RIFF":
                raise ValueError("không phải file WAV (có thể là con trỏ LFS hoặc trang lỗi)")
            dst.write_bytes(data)
            return data
        except (urllib.error.URLError, OSError, ValueError) as e:
            last = e
            time.sleep(2 * (i + 1))
    raise RuntimeError(f"không tải được {rel}: {last}")


def parse_wav(b):
    """Đọc WAV PCM 16/24/32-bit hoặc float32 (kể cả WAVE_FORMAT_EXTENSIBLE) -> (mono float64, sample rate)."""
    pos, fmt, data = 12, None, None
    while pos + 8 <= len(b):
        cid, size = b[pos:pos + 4], int.from_bytes(b[pos + 4:pos + 8], "little")
        body = b[pos + 8:pos + 8 + size]
        if cid == b"fmt ":
            tag = int.from_bytes(body[0:2], "little")
            ch = int.from_bytes(body[2:4], "little")
            sr = int.from_bytes(body[4:8], "little")
            bits = int.from_bytes(body[14:16], "little")
            if tag == 0xFFFE and len(body) >= 26:
                tag = int.from_bytes(body[24:26], "little")
            fmt = (tag, ch, sr, bits)
        elif cid == b"data":
            data = b[pos + 8:pos + 8 + size] if size < len(b) else b[pos + 8:]
            break
        pos += 8 + size + (size & 1)
    if fmt is None or data is None:
        raise ValueError("WAV thiếu fmt/data")
    tag, ch, sr, bits = fmt
    if tag == 3 and bits == 32:
        x = np.frombuffer(data[:len(data) // 4 * 4], dtype="<f4").astype(np.float64)
    elif tag == 1 and bits == 16:
        x = np.frombuffer(data[:len(data) // 2 * 2], dtype="<i2").astype(np.float64) / 32768.0
    elif tag == 1 and bits == 24:
        a = np.frombuffer(data[:len(data) // 3 * 3], dtype=np.uint8).reshape(-1, 3).astype(np.int32)
        v = a[:, 0] | (a[:, 1] << 8) | (a[:, 2] << 16)
        v = np.where(v & 0x800000, v - 0x1000000, v)
        x = v.astype(np.float64) / 8388608.0
    elif tag == 1 and bits == 32:
        x = np.frombuffer(data[:len(data) // 4 * 4], dtype="<i4").astype(np.float64) / 2147483648.0
    else:
        raise ValueError(f"định dạng WAV chưa hỗ trợ: tag={tag} bits={bits}")
    if ch > 1:
        x = x[:len(x) // ch * ch].reshape(-1, ch).mean(axis=1)
    return x, sr


# ───────────────────────────────────────────── xử lý
def trim_head(x, thr=0.02):
    """Bỏ khoảng lặng đầu để tiếng nổ ngay khi đi quân (giữ lại 3 ms)."""
    p = float(np.max(np.abs(x))) or 1.0
    idx = np.flatnonzero(np.abs(x) > thr * p)
    s = max(0, (int(idx[0]) if len(idx) else 0) - int(0.003 * SR))
    return x[s:]


def pitch_shift(x, sr, semitones):
    """Đổi cao độ bằng nội suy tuyến tính (đổi cả tốc độ - như hạ/nâng băng cassette); đồng thời đưa về 44,1 kHz."""
    step = (2.0 ** (semitones / 12.0)) * sr / SR
    pos = np.arange(0, len(x) - 1, step)
    return np.interp(pos, np.arange(len(x)), x)


def pick_sample(roots, target):
    """Gập target vào dải [min-3, max+5] bằng quãng tám rồi chọn nốt mẫu gần nhất -> (tên nốt mẫu, số bán cung cần đổi)."""
    lo, hi = min(roots.values()), max(roots.values())
    t = target
    while t > hi + 5:
        t -= 12
    while t < lo - 3:
        t += 12
    name = min(roots, key=lambda n: abs(roots[n] - t))
    return name, t - roots[name]


def reverb(x, wet=0.20, rt=0.45, seed=7):
    """Vang phòng nhỏ: đáp ứng xung là nhiễu suy giảm mũ, tích chập bằng FFT."""
    rng = np.random.default_rng(seed)
    n = int(rt * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal(n) * np.exp(-t / (rt / 4.5))
    ir[: int(0.004 * SR)] *= np.linspace(0, 1, int(0.004 * SR))
    ir /= np.sqrt((ir ** 2).sum())
    size = 1 << int(np.ceil(np.log2(len(x) + n)))
    y = np.fft.irfft(np.fft.rfft(x, size) * np.fft.rfft(ir, size), size)[: len(x) + n]
    out = np.zeros(len(y))
    out[: len(x)] += x
    return out + wet * y


def highpass(x, fc=70.0):
    """Cắt tiếng ục dưới ~70 Hz (loa điện thoại không phát được, chỉ ăn biên độ): đáp ứng Butterworth bậc 2 trên phổ."""
    f = np.fft.rfftfreq(len(x), 1 / SR)
    r = (f / fc) ** 4
    return np.fft.irfft(np.fft.rfft(x) * (r / (1 + r)), len(x))


def render(pack, sfx, samples):
    """Dựng 1 tiếng: ghép các nốt của giai điệu rồi thêm vang, cắt đuôi mượt, chuẩn hoá."""
    length = LENGTH[sfx]
    tail = 0.30
    total = int((length + tail) * SR)
    mix = np.zeros(total)
    roots = {n: midi(n) for n in samples}
    for when, note, gain in MELODY[sfx]:
        target = midi(note) + SHIFT[pack]
        root_name, semis = pick_sample(roots, target)
        if abs(semis) > 5:
            print(f"  ! {pack}_{sfx}: {note} phải đổi {semis:+d} bán cung từ {root_name}", file=sys.stderr)
        x = pitch_shift(samples[root_name][0], samples[root_name][1], semis)
        x = x[: total + SR]
        x = x / (float(np.max(np.abs(x))) or 1.0) * gain
        a = int(when * SR)
        seg = x[: total - a]
        mix[a:a + len(seg)] += seg
    mix = reverb(mix[: int((length + tail) * SR)])[: int((length + tail) * SR)]
    mix = highpass(mix)   # lọc TRƯỚC khi làm mờ đầu/đuôi (lọc FFT quấn vòng, làm sau sẽ tràn biên)
    # vào nhẹ 2 ms (chống click), ra mượt (cosine) ở phần đuôi
    fi = int(0.002 * SR)
    mix[:fi] *= np.linspace(0, 1, fi)
    fo = int(min(0.45, length * 0.5 + tail) * SR)
    mix[-fo:] *= 0.5 * (1 + np.cos(np.linspace(0, np.pi, fo)))
    mix *= TARGET_RMS / (float(np.sqrt((mix ** 2).mean())) or 1.0)   # cùng độ to cảm nhận
    peak = float(np.max(np.abs(mix)))
    return mix * (PEAK / peak) if peak > PEAK else mix                # ...nhưng không vượt trần đỉnh


def write_wav(path, x):
    pcm = np.clip(np.round(x * 32767), -32768, 32767).astype("<i2")
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def build_pack(pack, out, cache, force):
    files = [out / f"{pack}_{s}.wav" for s in SFX]
    if not force and all(f.is_file() and f.stat().st_size > 1000 for f in files):
        print(f"= {pack}: đã đủ 6 file, bỏ qua")
        return True
    folder, notes = INSTRUMENTS[pack]
    samples = {}
    for name, fn in notes.items():
        x, sr = parse_wav(fetch(folder + fn, cache))
        samples[name] = (trim_head(x), sr)
    rendered = {s: render(pack, s, samples) for s in SFX}   # dựng đủ 6 rồi mới ghi => không bao giờ ghi dở dang
    out.mkdir(parents=True, exist_ok=True)
    for s, f in zip(SFX, files):
        write_wav(f, rendered[s])
    kb = sum(f.stat().st_size for f in files) // 1024
    print(f"+ {pack}: 6 file, {kb} KB ({len(samples)} mẫu CC0 từ VCSL)")
    return True


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--cache", type=Path, default=None)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    packs = [p for p in (a.only.split(",") if a.only else INSTRUMENTS) if p]
    bad = [p for p in packs if p not in INSTRUMENTS]
    if bad:
        sys.exit(f"bộ không có: {bad}; có: {list(INSTRUMENTS)}")
    cache = a.cache or Path(tempfile.mkdtemp(prefix="vcsl_"))
    cache.mkdir(parents=True, exist_ok=True)
    ok = 0
    for p in packs:
        try:
            ok += bool(build_pack(p, a.out, cache, a.force))
        except Exception as e:  # noqa: BLE001 - 1 bộ lỗi không làm hỏng các bộ khác
            print(f"x {p}: {e}", file=sys.stderr)
    print(f"Xong {ok}/{len(packs)} bộ")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
