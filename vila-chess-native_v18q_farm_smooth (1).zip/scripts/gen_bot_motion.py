#!/usr/bin/env python3
"""
Sinh BotMotionData.kt: thông số chuyển động avatar RIÊNG cho từng bot (chạy trong GitHub Actions, main.yml).

Đọc danh sách bot từ BotRepository.kt nên thêm bot mới là tự có chuyển động, không cần sửa tay.
Tính cách theo Elo: bot yếu = lanh lẹ, nhún nhảy, phản ứng mạnh; bot mạnh = điềm tĩnh, chuyển động nhẹ, chậm.
Mỗi bot lệch ngẫu nhiên CỐ ĐỊNH (crc32 của id) để không bot nào giống hệt bot nào, mỗi lần build ra cùng kết quả.

    python3 scripts/gen_bot_motion.py [--repo app/src/main/java/com/vila/chess/bots/BotRepository.kt] [--out .../BotMotionData.kt]
"""
from __future__ import annotations
import argparse, colorsys, re, sys, zlib
from pathlib import Path

BOT_RE = re.compile(r'BotProfile\(\s*"(\w+)"\s*,\s*"[^"]*"\s*,\s*(\d+)\s*,')
ELO_LO, ELO_HI = 250, 3200


def jitter(bot_id: str, salt: str) -> float:
    """-1..1 cố định theo (id, salt)."""
    return (zlib.crc32(f"{bot_id}:{salt}".encode()) % 2001) / 1000.0 - 1.0


def f(x: float) -> str:
    return f"{x:.3f}f"


def motion(bot_id: str, elo: int) -> dict:
    t = min(max((elo - ELO_LO) / (ELO_HI - ELO_LO), 0.0), 1.0)   # 0 = yếu/lanh lẹ, 1 = mạnh/điềm tĩnh
    j = lambda s, k: 1.0 + k * jitter(bot_id, s)
    hue = (zlib.crc32(bot_id.encode()) % 360) / 360.0
    r, g, b = colorsys.hsv_to_rgb(hue, 0.55, 0.88)
    return {
        "breathMs": round((1900 + 1400 * t) * j("b", 0.10)),
        "breathScale": round((0.040 - 0.020 * t) * j("bs", 0.12), 4),
        "bobDp": round((1.6 - 0.8 * t) * j("bd", 0.12), 3),
        "swayDeg": round((4.5 - 2.5 * t) * j("sw", 0.12), 3),
        "swayMs": round((800 + 700 * t) * j("sm", 0.10)),
        "glowMs": round((700 + 500 * t) * j("g", 0.10)),
        "hopDp": round((9.0 - 4.0 * t) * j("h", 0.10), 3),
        "hopScale": round((0.15 - 0.07 * t) * j("hs", 0.10), 4),
        "shakeDp": round((4.5 - 1.5 * t) * j("sk", 0.10), 3),
        "ring": 0xFF000000 | int(r * 255) << 16 | int(g * 255) << 8 | int(b * 255),
        # ── v18j: animation chi tiết theo lớp (mắt / mày / miệng). Bot yếu = hồi hộp: chớp nhiều, mắt đảo nhanh, mày nhướn mạnh, nói nhanh.
        "blinkEveryMs": round((2300 + 2900 * t) * j("be", 0.12)),   # khoảng cách trung bình giữa hai lần chớp
        "blinkMs": round((150 - 35 * t) * j("bm", 0.08)),           # một lần chớp (nhắm + mở)
        "lookDp": round((1.6 - 0.7 * t) * j("lk", 0.12), 3),        # biên độ liếc mắt (dp, avatar 48dp)
        "lookEveryMs": round((1700 + 2300 * t) * j("le", 0.10)),
        "browLiftDp": round((1.5 - 0.6 * t) * j("br", 0.12), 3),    # nhướn mày khi nghĩ
        "talkMs": round((150 + 70 * t) * j("tk", 0.10)),            # nửa chu kỳ há/ngậm miệng khi nói
        "mouthOpen": round((1.55 - 0.30 * t) * j("mo", 0.08), 3),   # scaleY miệng lúc há tối đa
    }


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=str(root / "app/src/main/java/com/vila/chess/bots/BotRepository.kt"))
    ap.add_argument("--out", default=str(root / "app/src/main/java/com/vila/chess/bots/BotMotionData.kt"))
    a = ap.parse_args()

    bots = BOT_RE.findall(Path(a.repo).read_text(encoding="utf-8"))
    if not bots:
        print("❌ Không đọc được bot nào từ BotRepository.kt", file=sys.stderr)
        return 1

    rows = []
    for bot_id, elo in bots:
        m = motion(bot_id, int(elo))
        rows.append(
            f'        "{bot_id}" to BotMotion({m["breathMs"]}, {f(m["breathScale"])}, {f(m["bobDp"])}, {f(m["swayDeg"])}, '
            f'{m["swayMs"]}, {m["glowMs"]}, {f(m["hopDp"])}, {f(m["hopScale"])}, {f(m["shakeDp"])}, Color(0x{m["ring"]:08X}), '
            f'{m["blinkEveryMs"]}, {m["blinkMs"]}, {f(m["lookDp"])}, {m["lookEveryMs"]}, {f(m["browLiftDp"])}, {m["talkMs"]}, {f(m["mouthOpen"])}),'
        )
    out = (
        "package com.vila.chess.bots\n\n"
        "import androidx.compose.ui.graphics.Color\n\n"
        "// FILE SINH TỰ ĐỘNG bởi scripts/gen_bot_motion.py (GitHub Actions) — đừng sửa tay.\n"
        f"// {len(bots)} bot, thông số chuyển động theo Elo + độ lệch cố định theo id.\n"
        "object BotMotionData {\n"
        "    val byId: Map<String, BotMotion> = mapOf(\n" + "\n".join(rows) + "\n    )\n}\n"
    )
    p = Path(a.out)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(out, encoding="utf-8")
    print(f"✅ Bot motion: {len(bots)} bot → {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
