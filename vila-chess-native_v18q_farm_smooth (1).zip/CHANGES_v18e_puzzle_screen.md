# v18e — Màn giải câu đố kiểu chess.com (có thanh công cụ, một trang đầy đủ)

Trước đây bấm một nút trên bản đồ câu đố chỉ mở màn xám phẳng: thanh trên đơn giản, ô "mục tiêu", bàn cờ, ô phản hồi và đúng MỘT nút Gợi ý.
Giờ là một trang giống ảnh chess.com:

| Khối (từ trên xuống) | Nội dung |
|---|---|
| Thanh trên | mũi tên về · huy hiệu mảnh ghép gỗ có số cấp + "Câu đố" · nút cài đặt |
| Bong bóng thầy | avatar thầy (đổi tâm trạng, nhún/rung theo kết quả) + bong bóng trắng: ô tick "Đến lượt quân trắng di chuyển" (tick xanh khi giải xong) + lời nhắc theo chủ đề câu đố |
| Bàn cờ | như cũ (kéo-thả, chạm-để-đi, gợi ý), to hết bề ngang |
| HUD | điểm câu đố · ngọn lửa chuỗi · đồng hồ · thanh tiến độ cam (số nước đã đi đúng) · huy hiệu cấp kế tiếp |
| Thanh nút đáy | **Gợi ý** · **Quay lại** (câu trước) · **Tiếp** (câu kế, sáng xanh khi vừa giải xong) |

## Hành vi
- **Tiếp** sang câu kế NGAY trong màn này (không về bản đồ); chỉ bấm được khi đã giải câu hiện tại hoặc level kế đã mở khoá từ trước.
- Giải xong là mở khoá level kế ngay (`PuzzleMapViewModel.unlockAfter`), không cần quay về bản đồ. Mũi tên trên cùng về bản đồ; nếu đã giải câu nào trong lượt thì bản đồ vẫn phát animation ăn mừng.
- **Cài đặt** (bánh răng): xem độ khó + điểm, "Làm lại câu này".
- Nền: `StaticSpaceBackground` (sao tĩnh theo hình nền đang chọn) — nền đặc che bản đồ phía sau, không thêm vòng lặp animation thứ hai nên không tốn GPU.

## Điểm + chuỗi là THẬT (trước đây bản đồ hiện số mẫu 554 / 9 viết cứng)
- `game/PuzzleStats.kt`: điểm Elo câu đố (khởi đầu 600) + chuỗi giải sạch, lưu SharedPreferences, là Compose state nên bản đồ và màn giải cùng cập nhật.
- Sai nước đầu tiên của một câu ⇒ chuỗi về 0. Giải sạch: ít nhất +1; giải sau khi sai: không bao giờ hơn +12.
- Chỉ câu có level ≥ level đang chơi mới tính điểm (chơi lại câu cũ không "cày" điểm).
- Bản đồ câu đố (`PuzzleTab`) giờ truyền điểm/chuỗi thật vào `PuzzleMapScreen`.

## File
Mới: `game/PuzzleStats.kt`, `app/src/test/.../PuzzleStatsTest.kt`.
Sửa: `ui/PuzzleSolveScreen.kt` (bố cục mới + `PuzzleBadge`; bố cục gọn của `LessonPuzzleScreen` giữ nguyên), `ui/PuzzleTransitionWrapper.kt`, `ui/SpaceBackground.kt`, `game/PuzzleSession.kt` (lời nhắc thầy `puzzleCoachTip`, `puzzlePlayerMoveCount`), `game/PuzzleMapViewModel.kt`.
Chưa build được trong môi trường tạo (không có Android SDK); đã rà cú pháp/import bằng tay.
