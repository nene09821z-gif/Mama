# v18c — Trang chủ gọn, thoáng như chess.com

Thu nhỏ khoảng 20–25% các khối đang quá to (so với ảnh chess.com), giữ nguyên bố cục và chức năng. Không đổi logic.

| Phần | Trước | Sau |
|---|---|---|
| Header | cao 52, avatar 44, nút 42, chip chuỗi 36 (chữ 17) | cao 44, avatar 34, nút 34, chip 28 (chữ 14) |
| Banner sự kiện / Học | cao 172, chữ tiêu đề 28 (Học 38), icon 96 | cao 140, tiêu đề 22 (Học 28), icon 72 |
| Nút trong banner | 112 x 36, chữ 16 | 92–96 x 30, chữ 14 |
| Tiêu đề mục | cao 30, chữ 22 | cao 26, chữ 18 |
| Trận đấu đề nghị | cao 96, avatar 64, "Cấp N" 20 | cao 72, avatar 52, "Cấp N" 17 |
| Thẻ Hệ số | 128 x 132, số 28 | 104 x 104, số 22 |
| Thẻ Bạn bè | cao 72, icon 46, chữ 16/13 | cao 58, icon 36, chữ 14/11.5 |
| Nút Chơi | cao 56, chữ 26 | cao 44, chữ 22 |
| Thanh điều hướng | cao 62, icon 32 | cao 52, icon 26 |

- Khoảng cách giữa các mục: 22/18/25 → 16/14/16 (mục nhỏ hơn nên vẫn thoáng).
- Vùng bị dock (Chơi + thanh dưới) che giảm 144 → 118 dp (cộng inset), thấy được nhiều nội dung hơn.
- File sửa: `HomeParts.kt`, `HomeScreen.kt`. Chưa build được trong môi trường tạo; đã rà cú pháp bằng tay.
