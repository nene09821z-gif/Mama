# v18b — Ngựa 3D nhảy từ ô sang ô khi xong bài học / câu đố

## Mới
- ui/HorseMotion.kt  : chuyển động thuần Kotlin (HorseFrame): gom lực → bay parabol (co chân ở đỉnh, duỗi chân trước đón mặt ô) → tiếp đất dẹt người + bụi.
  Mọi giá trị liền mạch (có unit test).
- ui/HorseMascot.kt  : vẽ ngựa bằng Canvas (không asset) + `HorseOverlay` (lớp phủ trên danh sách, nhảy được qua nhiều hàng) + `HorseHop`.
  Chi tiết 3D: gradient sáng/tối từ trên-trái, rim light, bóng dưới bụng/hàm, 2 cung cơ vai–đùi, chân xa tối hơn chân gần, tất trắng,
  móng có điểm sáng, mắt bóng 2 điểm sáng + chớp mắt, má hồng, đốm trắng trên mặt, dây cương + khoá vàng, yên + chăn đổi màu theo chủ đề vùng,
  bờm/đuôi bay theo gió, thở nhẹ khi đứng; bóng đổ thật trên mặt ô nhỏ + nhạt dần khi bay cao; quay mặt theo hướng nhảy.
- test/HorseMotionTest.kt

## Sửa
- ui/LessonsScreen.kt : ngựa đứng trên ô "Bài tiếp theo"; học xong → ô vừa xong bật nảy, 0,3 s sau ngựa nhảy sang ô kế (kể cả qua tấm biển khóa sang khóa sau);
  hộp thoại bài kế chờ 1,9 s (ngựa đáp xong mới hiện). Bỏ linh vật Mascot trên ô Current (Mascot vẫn dùng ở biển khóa và hộp thoại).
- ui/PuzzleMapScreen.kt: ngựa thay linh vật + quân Mã phẳng. Thắng câu đố mới → ngựa nhảy từ ô trước sang ô vừa thắng; đáp xuống rồi ô mới
  chuyển Done: số mờ → dấu tích hiện + vầng sáng + vòng sóng. Level 1: nhảy tại chỗ. Giải lại câu cũ: ngựa đứng yên.
  WoodenNode bỏ tham số `piece`/`mascot`; NodeCelebration bỏ hop/fade, thêm `landed`; MapArt bỏ `knight`.

## Chưa build thử (không có Android SDK). Cần: ./gradlew :app:testDebugUnitTest :app:compileDebugKotlin rồi xem trên máy thật:
- Ngựa bám ô khi cuộn giữa lúc đang nhảy; kích thước ngựa so với ô (Lessons: 0,78·nodeW, Puzzle: 0,8·nodeW – chỉnh ở HorseOverlay(width=…)).
- Cường độ nhảy: chiều cao cung = 0,42 × khoảng cách (kẹp 0,55–1,5 chiều rộng ngựa) – hằng số trong horsePlace().
