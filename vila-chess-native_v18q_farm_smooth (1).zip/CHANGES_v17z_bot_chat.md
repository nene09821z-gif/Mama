# v17z - Bot cá tính + chat (kiểu chess.com)
- bots/BotPersonality.kt: 7 phong cách (SHY, CHEERFUL, CLEVER, FIERY, CALM, PROUD, CAT), câu chào riêng 15 bot, câu thoại theo sự kiện, BotChatter (giãn cách 5 nước, xác suất, không lặp câu).
- ui/BotSpeechBubble.kt: bong bóng thoại dưới thanh bot.
- GameViewModel: botBubble, botReact (ăn Hậu/quân, bỏ quân, chiếu, nhập thành, phong cấp), nói câu thắng/thua/hòa cuối ván.
- BotGameScreen: hiện bong bóng trên bàn cờ. Chưa build thử (không có Android SDK ở đây).
- Giọng nói bot: bots/BotVoice.kt (TextToSpeech vi-VN), BotPersonality.voiceOf (pitch/rate riêng 15 bot), công tắc "Giọng bot" trong Các tùy chọn (mặc định tắt). Cần máy có giọng tiếng Việt.
- Sửa lỗi quầng tròn xám kẹt trên bàn cờ: quân đang kéo bị đối thủ ăn giữa lúc kéo thì dragSq không được reset (BoardView.kt). Thêm điều kiện overlayPiece != 0 khi vẽ quầng.
