# v18d — Sửa banner trang chủ: bị méo/kẹt lệch, không tự lướt, lag

## Nguyên nhân gốc
`LaunchedEffect(heroPager.currentPage)` chạy `animateScrollToPage(...)` bên trong. Nhưng `currentPage` đổi ở GIỮA lúc lướt
(qua nửa trang) => Compose huỷ effect => huỷ luôn animation => banner **đứng kẹt lệch** vài chục dp (ảnh chụp: thẻ bị đẩy sang phải,
lộ thẻ trước bên trái, icon bị cắt mép phải). Sau đó phải đợi 5 giây mới nhúc nhích nên trông như "không tự lướt".

## Đã sửa (HomeScreen.kt)
- Vòng tự lướt độc lập, không phụ thuộc `currentPage`, không còn tự huỷ giữa chừng. Kiểm tra mỗi 250 ms; đang vuốt/lướt thì đếm lại, đủ 5 giây yên mới lướt (tween 450 ms).
- Pager vòng lặp vô hạn (100.000 trang ảo, trang thật = `page % 6`): trang cuối lướt tiếp sang trang đầu cùng chiều, không còn tua ngược qua 5 trang.
- `beyondViewportPageCount = 1`: dựng sẵn slide kế, bớt khựng lúc bắt đầu lướt.
- `HeroDots` nhận lambda `current: () -> Int`: chỉ chấm phân trang recompose khi đổi trang (trước đó cả pager + HomeTab recompose mỗi lần đổi trang).
- Nền động tạm đứng yên khi banner đang lướt (`BackgroundMotion.paused`) — nền thiên hà/cảnh vũ trụ vẽ điểm lớn chồng lớp (overdraw nặng) cùng lúc là nguyên nhân tụt khung hình trên máy yếu.

## Đã sửa (HomeParts.kt)
- `LearnCard`: bàn cờ phối cảnh trước đây dựng 60 `Path` MỖI lần vẽ; nay dựng 1 lần trong `drawWithCache` thành 2 Path (ô tối/ô sáng) => 5 lệnh vẽ.
- `EventCard`: vòng sáng, bóng, gradient chuyển sang `drawWithCache` (không tạo Brush mỗi frame).
- `EventCard` trên màn hình hẹp (~290 dp): tiêu đề 22 → 20 sp, icon 72 → 68 dp, chừa đúng chỗ cho icon => chữ "Cờ Phép Thuật" không còn đè lên icon. Bóng tiếp đất tính theo cỡ icon.

## File sửa
`HomeScreen.kt`, `HomeParts.kt`, `SpaceBackground.kt`, `SpaceScenes.kt`.
Chưa build được trong môi trường tạo (không có Android SDK); đã rà cú pháp/import bằng tay.
