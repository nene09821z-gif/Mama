# v18j — Animation chi tiết cho 15 bot (chớp mắt, liếc nhìn, nhướn mày, miệng nói)

## Trước đó
- AnimatedAvatarFrame chỉ chuyển động CẢ avatar (thở, nghiêng, nhảy, rung, vòng sáng). Mặt bot là ảnh phẳng, chưa có chớp mắt / đổi miệng.

## Thêm
- tools/botfaces_layers.py: tách 15 khuôn mặt (botfaces.py) thành lớp bg · rear · body · head · brows · eyes · mouth · front, giữ thứ tự chồng.
  `python3 tools/botfaces_layers.py --android app/src/main` → res/drawable/botl_<id>_<n>.xml + bots/BotLayerData.kt (đặt .kt vào java/com/vila/chess/bots/).
- ui/LayeredBotFace.kt: chớp mắt (có chớp đôi), liếc quanh, nhìn lên-trái + nhướn mày khi nghĩ, miệng há/ngậm khi nói, híp mắt/cười toe khi vui, trố mắt khi giật mình; đầu đi theo ánh mắt.
- BotMotion: thêm blinkEveryMs, blinkMs, lookDp, lookEveryMs, browLiftDp, talkMs, mouthOpen (có mặc định); scripts/gen_bot_motion.py sinh theo Elo: bot yếu = hồi hộp (chớp nhiều, liếc nhanh, nói nhanh), bot mạnh = điềm tĩnh.
- Test: BotLayerDataTest.

## Đổi
- ui/GameCommon.kt PlayerBar: bot có dữ liệu lớp → LayeredBotFace (thinking = đến lượt bot, speaking = đang có bong bóng thoại); còn lại giữ ảnh tĩnh.

## Lưu ý
- Hiro (mắt nhắm) không chớp được rõ; Nova/Mittens không có lớp mày.
- Chưa build/chạy trên máy (không có Android SDK): hãy build và thử một ván.
- Bản xem trước chuyển động: file Figma "Vila Chess - Bot Motion Lab" + video MP4.
