# v18g — Ghép ngựa 3D nhảy (v18b_horse_hop) vào v18f_online_elo

Hai bản tách từ cùng v18: nhánh ngựa (v18b_horse_hop) và nhánh khoá vùng → trang chủ gọn → sửa banner → màn giải câu đố → Elo online (v18f).
Bản này = TOÀN BỘ v18f + ngựa. Không mất gì của v18f (khoá vùng + mây, điểm/chuỗi thật, màn giải kiểu chess.com, Elo online, nút Thoát, mã ANBO...).

## File lấy nguyên từ bản ngựa
- `ui/HorseMotion.kt`, `ui/HorseMascot.kt`, `test/HorseMotionTest.kt` (file mới, không trùng tên với bất kỳ khai báo nào của v18f)
- `ui/LessonsScreen.kt` — v18f chưa sửa file này nên lấy nguyên bản ngựa (khác biệt duy nhất giữa hai bản chính là code ngựa)

## File phải ghép tay: `ui/PuzzleMapScreen.kt` (cả hai nhánh cùng sửa)
Giữ của v18f: `currentRegion`, `FogLayer`, `FrostGround`, `LockedHint`, `JumpToCurrentButton`, `frozen` của ô, `TopHud(currentRegion)`, vật cảnh theo vùng khoá.
Lấy của ngựa: `HorseOverlay`, `HorseHop`, `NodeCelebration(landed)` (ô chờ ngựa đáp rồi mới hiện dấu tích), bỏ quân Mã phẳng + linh vật trên ô (`MapArt.knight`, `ChessPiece`, tham số `piece`/`mascot`).
Thứ tự lớp: ... ô → mây khoá vùng → **ngựa** → hạt môi trường → HUD (ngựa không bị mây che).

## Điều chỉnh cho khớp luồng v18e (quan trọng)
v18e mở khoá level kế NGAY khi giải xong, lúc màn giải còn che bản đồ ⇒ `currentLevel` đã tăng trước khi bản đồ hiện lại.
Nếu bám nguyên logic cũ (ngựa luôn ở `currentLevel − 1`), ngựa sẽ "nhảy trước" sau màn che rồi nhảy lần nữa, và ô vừa xong nháy dấu tích → vàng → dấu tích.
Cách xử lý:
- `horseDone` = ô ngựa đang đứng; chỉ tăng khi ngựa đáp xuống. `hopping` = đang trong cú nhảy (from → to mới có hiệu lực).
- Ô vừa xong mà ngựa chưa tới được vẽ như ô hiện tại (`holdCurrent`), đáp xong mới thành dấu tích.
- Giải liền nhiều câu bằng nút "Tiếp" rồi về bản đồ: ngựa nhảy 1 bước cuối tới câu mới nhất, hoạt cảnh phát ở ô đó.
- Giải lại câu cũ: ngựa đứng yên, ô chỉ phát lại dấu tích như bản ngựa.
- Dự phòng: thoát màn giải bằng nút Back của máy sau khi đã giải (không có hoạt cảnh) ⇒ chờ bản đồ hiện, đặt ngựa sang ô mới không nhảy.

## Chưa build thử (không có Android SDK). Đã làm: rà cú pháp bằng parser Kotlin (sạch), soát trùng tên/khai báo, đối chiếu chữ ký hàm mọi chỗ gọi.
Cần: ./gradlew :app:testDebugUnitTest :app:compileDebugKotlin rồi xem trên máy thật (xem thêm CHANGES_v18b_horse_hop.md).
