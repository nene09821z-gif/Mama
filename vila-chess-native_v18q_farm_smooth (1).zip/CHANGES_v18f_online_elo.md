# v18f — Elo chỉ tính ván online, công thức công bằng, hội viên x2 điểm cộng, nút Thoát

## Elo
- **Chỉ ván online** (người thật) mới cộng/trừ Elo, theo hệ số của đối thủ (hồ sơ cloud lúc vào ván; chưa lấy được thì coi như ngang mình).
- **Ván với bot / giải đấu bot không còn đổi Elo.** Vẫn ghi số ván thắng/hòa/thua, chuỗi ngày, lịch sử ván; biểu đồ Elo không thêm mốc phẳng.
- **Công thức** (`game/OnlineElo.kt`, logic thuần, có test):
  - Kỳ vọng theo Elo chuẩn, chênh lệch chặn ±400 (luật 400 của FIDE).
  - K theo số ván online ở thể loại đó. **Người mới (như chess.com): ván 1–5 K=160, ván 6–10 K=100, ván 11–20 K=60** → 5 ván đầu thắng hết (đối thủ ~800) tăng khoảng +265 Elo, thua hết thì rớt khoảng -265. Sau 20 ván: Elo < 1800 = 24, 1800–2399 = 16, ≥ 2400 = 10.
  - Đấu lặp cùng một đối thủ trong 24 giờ: ván 1–3 đủ điểm, 4–6 còn 1/2, từ ván 7 còn 1/4 (cả cộng lẫn trừ).
  - Thắng luôn ≥ +1. Làm tròn số nguyên. Sàn Elo 100.
- **Đặc quyền x2**: gói Gold trở lên (`ELO_BOOST_MIN_TIER` trong `billing/Membership.kt`) nhân đôi điểm CỘNG, điểm TRỪ giữ nguyên.
- Thoát giữa ván online khi đã đi >= 2 nước = xử thua, trừ Elo ngay. Ván < 2 nước (bị hủy) không tính.
- Toast cuối ván: `Hệ số Chớp: 852 (+40 · đặc quyền x2)`.

- **Ghép trận online giữ nguyên:** chỉ ghép theo thể loại giờ, không giới hạn Elo (hai người Elo chênh bao nhiêu cũng ghép được; chênh lệch đã được chặn ±400 trong công thức).

## Nút Thoát (màn Chơi online)
- Thêm nút **Thoát** (icon cửa + mũi tên `ToolIcon.EXIT`, cùng nét/màu với các icon khác) ở cuối thanh công cụ.
  - Đang chơi: Cầu hòa · Chat · Đầu hàng · Thoát. Hết ván: Tìm trận mới · Chat · Thoát.
  - Hành vi giống mũi tên ở thanh trên và nút Back của máy: đang chơi thì hỏi xác nhận, hết ván thì về menu.
- Hộp xác nhận ghi rõ số Elo sẽ bị trừ (tính đúng công thức chốt cuối ván), nút nguy hiểm màu đỏ, nút hủy là "Ở lại".

## Khác
- Dòng giải thích ở màn Chơi online và màn thiết lập ván với máy.
- Test mới: `OnlineEloTest`.

Lưu ý: Elo đang tính trên máy rồi đẩy lên cloud (như trước). Muốn chống gian lận thật sự thì cần tính trong hàm RPC của Supabase.

## Mã ANBO
- Mã `ANBO` giờ đổi lấy gói **Platinum** (trước là Diamond), `billing/LicenseManager.kt`. Vẫn mỗi máy 1 lần, không hạ gói đang có, thời hạn `TRIAL_DAYS` (7 ngày).
