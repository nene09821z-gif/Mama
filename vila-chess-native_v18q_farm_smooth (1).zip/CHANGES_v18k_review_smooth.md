# v18k — Bảng "Bạn thua / Game Review": nhãn nhỏ + con mã chạy trơn tru

## Vấn đề
Trong lúc Stockfish phân tích, hàng 4 nhãn nhỏ (??, sách, ✓, ?!) đổi nhãn bị khựng / nhảy cỡ, con mã nhảy có nhịp giật,
và lúc chờ -> xong thì hàng nhãn đổi cảnh đột ngột.

## Cách sửa (ui/ReviewLoadingParts.kt)
- ReviewLabelCycler viết lại: cả hàng là MỘT Canvas + MỘT đồng hồ vô hạn, mọi giá trị đọc ở pha vẽ
  => không recomposition mỗi 0,62s, không Animatable / coroutine cho từng nhãn.
- Nhãn 2.5D (nhiều gradient / nét) dựng SẴN 1 lần ra bitmap trên luồng nền (BadgeBitmapCache), lúc chạy chỉ dán bitmap
  + scale/xoay/alpha => không cấp phát, không hitch lúc đổi nhãn.
- Đổi nhãn kiểu chồng mờ: nhãn cũ thu nhỏ + mờ dần trong khi nhãn mới nảy lên (overshoot) => không còn khung hình
  nhãn mới xuất hiện nhỏ 0,4x rồi mới nảy. Ô đổi lần lượt từ trái sang phải, thêm nhấp nhô nhẹ để hàng luôn có chuyển động.
- Vòng lặp khép kín (5 nhịp x 4 ô, 10 nhãn) nên quay về đầu không giật.
- KnightLoadingBoard: bỏ snapTo / delay / state "step" (từng gây khung hình mã nhảy sớm 1 ô và khựng ở chỗ nối);
  nay một đồng hồ 0..8 tính hết ở pha vẽ. Con mã dịch bằng ma trận (không làm tròn toạ độ => hết rung),
  thêm bóng đổ dưới đất và cú nhún nhẹ lúc đáp; ô xanh mờ dần liền mạch giữa hai bước.
- ResultBadge: số đếm chỉ recomposition khi số nguyên đổi (derivedStateOf), không phải mỗi khung hình.

## ui/PostGameSummaryScreen.kt
- Hàng nhãn chuyển chờ -> xong / lỗi bằng Crossfade 240ms (chiều cao cố định nên không nhảy bố cục).

## review/GameAnalysisWorker.kt
- Engine native của Worker cuối ván nice 10 -> 15 để nhường thêm CPU cho luồng giao diện khi hộp thoại đang chạy animation.
  (Phân tích có thể chậm hơn chút trên máy đang bận; PreAnalyzer vẫn nice 19.)

## Lưu ý
- Chưa build được trong môi trường này (không có Android SDK) - hãy chạy ./gradlew assembleDebug hoặc đẩy lên GitHub Actions.
- Nếu máy không có libstockfish.so thì engine rơi về wasm trong WebView (chạy trên luồng chính) và vẫn có thể gây giật: cần đảm bảo workflow Build APK tải libstockfish.so.
