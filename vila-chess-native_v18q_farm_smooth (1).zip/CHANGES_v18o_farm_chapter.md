# v18o — Chủ đề NÔNG TRẠI: vùng đầu tiên của bản đồ Câu đố

## Thứ tự vùng (chỉ bản đồ Câu đố)
Nông trại → Rừng xanh → Làng Giáng sinh → Sa mạc & Núi lửa → Không gian → Biển sâu → (lặp vòng, 6 vùng).
Bài học vẫn dùng 5 chủ đề như cũ (`mapChapterFor`), không đổi.

## Mới
- tools/farm/render_farm.py : bộ dựng 3D nhỏ (Pillow + numpy, không cần mạng) → 19 sprite 2.5D low-poly góc nhìn isometric,
  ánh sáng từ trên-trái, bóng đổ mềm: chuồng, silo, cối xay gió, đống rơm, cuộn rơm, hàng rào, bù nhìn, hoa hướng dương, lúa,
  cà rốt, bí ngô, cây táo, cây, gà, cừu, bò, giếng, máy kéo, xe rơm. Chạy lại: `python3 tools/farm/render_farm.py`.
- res/drawable-nodpi/farm_*.png (19 file, ~600 KB).
- PuzzleChapters.kt : `FarmChapter` (ô xong màu vàng lúa, nền đồng cỏ + thửa ruộng thoi có luống, hoa, cỏ; dải HUD nâu đất),
  `FarmPools` (đủ 7 nhóm vật), `puzzleChapterFor()`, mũ rơm `MascotHat.Straw`, `ChapterDeco.Fields`.
- PuzzleThemeEffects.kt : `drawFarm` (phấn hoa bay + bướm vỗ cánh, 4 lần/giây, lặp liền mạch 24 s), chuyển động nhẹ cho cây (đung đưa),
  hoa hướng dương, gà/cừu/bò (nhún). `ThemeAmbient(..., farmFirst = true)` chỉ ở bản đồ Câu đố; Bài học giữ nguyên.
- PuzzleMapScreen.kt : 19 mục `PropKind.Farm*`; các chỗ đọc chủ đề dùng `puzzleChapterFor`.
- PuzzleLockedZone.kt : màu nền vùng khoá phía dưới đọc từ `puzzleChapterFor`.
- LessonsScreen.kt : thêm nhánh `ChapterDeco.Fields -> {}` (when phải đủ nhánh; Bài học không dùng).
- Test: PuzzleRegionsTest thêm 2 ca (thứ tự vùng + đủ nhóm vật; bố cục nông trại xác định và ≥ 25 vật ở biến thể 0, cùng ngưỡng với 5 chủ đề cũ).

## Chưa build thử (không có Android SDK)
Cần: ./gradlew :app:compileDebugKotlin :app:testDebugUnitTest. Xem trên máy thật:
- Vùng 1 (level 1–496) giờ là Nông trại; người đã chơi qua vùng 1 sẽ thấy cảnh mới ở các ô cũ (tiến độ không đổi).
- Kích thước vật theo bố cục gốc (themedProps giữ chiều cao, kẹp 0,6–1,4 bề rộng) – nếu có vật quá to/nhỏ, chỉnh `FarmPools`.
