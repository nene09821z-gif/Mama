# v18h — Âm thanh cho bàn cờ Câu đố và Bài học chiến thuật

## Lỗi
Chỉ ván đấu (GameViewModel) có phát tiếng. Màn Câu đố (PuzzleSolveScreen) và Bài học chiến thuật (LessonPuzzleScreen)
dùng chung PuzzleContent nhưng không hề gọi âm thanh nên đi quân hoàn toàn im lặng.
(Bài học tàn cuộc chơi qua GameViewModel nên vốn đã có tiếng.)

## Sửa
- game/Feedback.kt : thêm `PuzzleSfx` (một SoundPlayer dùng chung toàn app). Mỗi lần phát đọc lại công tắc "Âm thanh"
  và "Bộ âm thanh" trong vila_native ⇒ tắt tiếng / đổi bộ ở Tùy chỉnh là có hiệu lực ngay. SoundPlayer thêm loadExtra/playExtra.
- game/PuzzleSession.kt : PuzzleStep.Correct có thêm playerSfx / replySfx, PuzzleSession có setupSfx.
  Phân loại như ván đấu: chiếu > phong cấp > nhập thành > ăn quân (kể cả bắt tốt qua đường) > đi thường.
- ui/PuzzleSolveScreen.kt (PuzzleContent) phát tiếng ở: nước đầu của đối thủ, nước của bạn, nước đối thủ đáp,
  đi sai (tiếng trầm mới) và giải xong (tiếng "hết ván" của bộ đang chọn).
- res/raw/puzzle_wrong.wav : tiếng sai nước (0,3 s, tự tổng hợp, không bản quyền).
- test/PuzzleSoundTest.kt : kiểm tra phân loại tiếng đi / ăn / chiếu / phong cấp / nhập thành.

## Lưu ý
- Chưa build được trong môi trường này (không tải được plugin Android Gradle), nên chưa chạy test; đã soát tay các thế cờ trong test.
