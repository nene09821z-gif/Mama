#!/usr/bin/env python3
"""Tách 15 khuôn mặt bot (tools/botfaces.py) thành LỚP riêng để làm animation chi tiết.

Không sửa botfaces.py: ta chặn (monkeypatch) các hàm vẽ bộ phận để gắn nhãn nhóm cho từng path rồi gộp các đoạn liên tiếp
cùng nhóm thành một lớp, GIỮ NGUYÊN thứ tự chồng (z-order) của bản vẽ gốc.

Nhóm (theo thứ tự chồng từ dưới lên):
  bg (nền, đứng yên) · rear (phần của ĐẦU nằm SAU thân: đuôi ngựa, tóc dài…) · body (vai/thân/cổ áo, nhịp thở)
  · head (đầu, tóc, phụ kiện, mũi, má hồng) · brows · eyes · mouth · front (phụ kiện vẽ sau miệng)
  Mọi nhóm trừ bg và body đều chuyển động theo đầu (nghiêng / nhún / nhảy).
"""
import json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import botfaces as bf

GROUP_OF = {'bg': 'bg', 'body': 'body', 'head': 'head', 'blush': 'head', 'nose': 'head', 'shine': 'head',
            'brows': 'brows', 'eyes_round': 'eyes', 'eyes_dot': 'eyes', 'eyes_calm': 'eyes', 'eyes_happy': 'eyes',
            'mouth': 'mouth'}

class Tagged(bf.Scene):
    cur = None
    def path(self, d, fill=None, op=1.0, stroke=None, sw=1.0, so=1.0):
        super().path(d, fill, op, stroke, sw, so)
        self.items[-1]['grp'] = self.cur

import inspect
META_KEY = {'brows': 'brow', 'eyes_round': 'eye', 'eyes_dot': 'eye', 'eyes_calm': 'eye', 'eyes_happy': 'eye', 'mouth': 'mouth'}
META = {}

def _wrap(name):
    orig = getattr(bf, name)
    sig = inspect.signature(orig)
    def inner(s, *a, **k):
        if name in META_KEY:
            ba = sig.bind(s, *a, **k); ba.apply_defaults()
            META[META_KEY[name]] = ba.arguments['y']
            if name == 'mouth':
                META['mouthKind'] = ba.arguments['kind']
        prev, s.cur = s.cur, GROUP_OF[name]
        try:
            return orig(s, *a, **k)
        finally:
            s.cur = prev
    return inner

# Bot vẽ mắt/miệng trực tiếp (không qua eyes_*/mouth): gắn nhóm theo dấu hiệu của path.  (bot_id -> [(nhóm, hàm kiểm tra)])
OVERRIDES = {
    'jimmy':   [('mouth', lambda i: i['d'].startswith('M25.5,29.4') or i['d'].startswith('M20,29 Q24,31.6'))],
    'antonio': [('mouth', lambda i: i['d'].startswith('M17.2,28.4') or i['d'].startswith('M21,31.6'))],
    'viktor':  [('mouth', lambda i: i['d'].startswith('M18,28 Q21') or i['d'].startswith('M21.6,31.2'))],
    'hiro':    [('eyes', lambda i: i['stroke'] and ',22.6' in i['d'])],
    'nova':    [('eyes', lambda i: ',22.6 a' in i['d']),
                ('mouth', lambda i: i['d'].startswith('M20.4,31.2') or ',31.2 a' in i['d'])],
    'mittens': [('eyes', lambda i: ',21.8 a' in i['d'] or ',20.4 a' in i['d'] or ',19.8 Q' in i['d']),
                ('mouth', lambda i: i['d'].startswith('M24,28.2 L24,29.6'))],
}

MANUAL_META = {
    'jimmy': dict(mouth=30.0), 'antonio': dict(mouth=29.5), 'viktor': dict(mouth=29.5),
    'hiro': dict(eye=22.6), 'nova': dict(eye=22.6, mouth=31.2), 'mittens': dict(eye=21.8, mouth=29.6),
}

def layers_for(bot_fn, bot_id=None):
    META.clear()
    saved = {n: getattr(bf, n) for n in GROUP_OF}
    for n in GROUP_OF:
        setattr(bf, n, _wrap(n))
    try:
        s = Tagged(); bot_fn(s)
    finally:
        for n, fn in saved.items():
            setattr(bf, n, fn)
    for grp, pred in OVERRIDES.get(bot_id, []):
        for it in s.items:
            if pred(it):
                it['grp'] = grp
    has_body = any(i.get('grp') == 'body' for i in s.items)
    seen_body = seen_mouth = False
    out = []
    for it in s.items:
        g = it.get('grp')
        m = re.match(r'M\s*(-?[\d.]+)[ ,]\s*(-?[\d.]+)', it['d'])
        y0 = float(m.group(2)) if m else None
        if g == 'body':
            seen_body = True
        if g is None:                      # path vẽ trực tiếp, không qua hàm bộ phận
            if y0 is not None and y0 >= 33 and not seen_mouth:
                g = 'body'                 # cổ áo / cà vạt / vai
            elif has_body and not seen_body:
                g = 'rear'                 # vẽ trước thân => nằm sau thân (đuôi ngựa…)
            elif seen_mouth:
                g = 'front'
            else:
                g = 'head'
        if g == 'mouth':
            seen_mouth = True
        if out and out[-1][0] == g:
            out[-1][1].append(it)
        else:
            out.append((g, [it]))
    META.update({k: v for k, v in MANUAL_META.get(bot_id, {}).items()})
    return out

def svg_of(items):
    sc = bf.Scene(); sc.items = items
    return sc.svg(96)

def compact(items):
    """[d, fill, opacity] hoặc [d, '', 1, stroke, width, strokeOpacity] — gọn hơn SVG đầy đủ khi nhúng vào mã Figma."""
    out = []
    for it in items:
        if it['stroke']:
            out.append([it['d'], '', 1, it['stroke'], it['sw'], it['so']])
        else:
            out.append([it['d'], it['fill'], round(it['op'], 3)])
    return out

def export_android(out_dir):
    """Ghi res/drawable/botl_<id>_<n>.xml (mỗi lớp một VectorDrawable) + BotLayerData.kt (thứ tự chồng + toạ độ mắt/miệng/mày)."""
    out = Path(out_dir); drw = out / 'drawable'; drw.mkdir(parents=True, exist_ok=True)
    rows = []
    for bid, name, elo, fn in bf.BOTS:
        lay = layers_for(fn, bid)
        meta = dict(META)
        refs = []
        for n, (g, its) in enumerate(lay):
            sc = bf.Scene(); sc.items = its
            (drw / f'botl_{bid}_{n}.xml').write_text(sc.android(), encoding='utf-8')
            refs.append(f'FaceLayer(R.drawable.botl_{bid}_{n}, FaceKind.{g.upper()})')
        f = lambda k: ('%.1ff' % meta[k]) if k in meta else '-1f'
        rows.append(f'        "{bid}" to BotFace({f("eye")}, {f("mouth")}, {f("brow")}, listOf(\n            ' + ',\n            '.join(refs) + ',\n        )),')
    kt = ('package com.vila.chess.bots\n\nimport androidx.annotation.DrawableRes\nimport com.vila.chess.R\n\n'
          '// FILE SINH TỰ ĐỘNG bởi tools/botfaces_layers.py --android — đừng sửa tay.\n'
          '// Mỗi bot = danh sách lớp theo thứ tự chồng (dưới → trên). eyeCy/mouthCy/browCy: tâm theo lưới 48 (−1 = không có) để đặt tâm xoay.\n'
          'enum class FaceKind { BG, REAR, BODY, HEAD, BROWS, EYES, MOUTH, FRONT }\n'
          'class FaceLayer(@DrawableRes val res: Int, val kind: FaceKind)\n'
          'class BotFace(val eyeCy: Float, val mouthCy: Float, val browCy: Float, val layers: List<FaceLayer>)\n\n'
          'object BotLayerData {\n    val byId: Map<String, BotFace> = mapOf(\n' + '\n'.join(rows) + '\n    )\n}\n')
    (out / 'BotLayerData.kt').write_text(kt, encoding='utf-8')
    print('android:', len(rows), 'bot ->', out)

if __name__ == '__main__':
    if len(sys.argv) > 2 and sys.argv[1] == '--android':
        export_android(sys.argv[2]); sys.exit(0)
    res = {}
    for bid, name, elo, fn in bf.BOTS:
        lay = layers_for(fn, bid)
        res[bid] = dict(name=name, elo=elo, meta=dict(META), layers=[dict(g=g, svg=svg_of(its), items=compact(its)) for g, its in lay])
    Path(sys.argv[1] if len(sys.argv) > 1 else 'work/layers.json').write_text(json.dumps(res, ensure_ascii=False), encoding='utf-8')
    for bid, v in res.items():
        print(bid, v['meta'], [(l['g'], len(json.dumps(l['items'], separators=(',', ':')))) for l in v['layers']])
