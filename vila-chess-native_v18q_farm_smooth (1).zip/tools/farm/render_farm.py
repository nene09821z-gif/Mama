#!/usr/bin/env python3
"""Dựng sprite 2.5D chủ đề NÔNG TRẠI (low-poly, góc nhìn isometric, ánh sáng từ trên-trái) cho bản đồ Câu đố.

Không cần mạng, chỉ cần Pillow + numpy:
    python3 tools/farm/render_farm.py [thư mục ra, mặc định app/src/main/res/drawable-nodpi]

Mỗi vật = tập đa giác 3D (hộp, trụ/nón cụt, cầu, mái chóp) → loại mặt khuất → vẽ từ xa tới gần → tô theo
hướng ánh sáng → vẽ ở độ phân giải gấp 4 rồi thu nhỏ (khử răng cưa) + bóng đổ mềm dưới chân.
In ra bảng "tên rộng/cao" để dán vào PropKind (ratio).
"""
import math, os, random, sys, zlib
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SS = 4                      # siêu lấy mẫu
PITCH = math.radians(33)
OUT = 240                   # cạnh dài nhất của sprite
S2 = math.sqrt(2)
VIEW = np.array([math.cos(PITCH) / S2, math.sin(PITCH), math.cos(PITCH) / S2])
LIGHT = np.array([-0.62, 0.95, 0.30]); LIGHT = LIGHT / np.linalg.norm(LIGHT)


def hexc(h):
    h = h.lstrip('#'); return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float)


# ── Bảng màu ────────────────────────────────────────────────────────────────────────────────────
RED, DRED, WHITE, CREAM = hexc('D9473A'), hexc('A82F2C'), hexc('F7F3EA'), hexc('EFE3C8')
BROWN, WOOD, DWOOD = hexc('9A5E40'), hexc('C98F52'), hexc('8A5A33')
HAY, HAYD = hexc('F2C14E'), hexc('D49A2A')
GRASS, LEAF, LEAFD = hexc('72C550'), hexc('4FAE3E'), hexc('2F8A34')
SOIL, SOILD = hexc('8B5E3C'), hexc('6E4529')
STONE, STONED = hexc('BDB8AA'), hexc('8F8A7E')
BLUE, SKY = hexc('2A4A63'), hexc('86C0E6')
BLACK, PINK = hexc('2E2A2A'), hexc('F2A6A0')
SUN, SUND = hexc('FFC93C'), hexc('6B3E1E')
CARROT, PUMP, PUMPD = hexc('F28A2E'), hexc('F08A24'), hexc('C96A12')
GREEN_T = hexc('4FA85A')
APPLE = hexc('E0413A')


# ── Hình học ────────────────────────────────────────────────────────────────────────────────────
def rotm(rx=0., ry=0., rz=0.):
    cx, sx, cy, sy, cz, sz = math.cos(rx), math.sin(rx), math.cos(ry), math.sin(ry), math.cos(rz), math.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Ry @ Rz @ Rx


def build(verts, faces, cols, pos, rot):
    """verts: Nx3 cục bộ (tâm gốc) · faces: danh sách chỉ số · cols: màu từng mặt (hoặc 1 màu)."""
    V = (np.array(verts, float) @ rotm(*rot).T) + np.array(pos, float)
    c = V.mean(axis=0)
    out = []
    for i, f in enumerate(faces):
        P = V[f]
        n = np.cross(P[1] - P[0], P[2] - P[0])
        ln = np.linalg.norm(n)
        if ln < 1e-9:
            continue
        n = n / ln
        if np.dot(n, P.mean(axis=0) - c) < 0:
            n = -n
        col = cols[i] if isinstance(cols, list) else cols
        out.append((P, n, col))
    return out


def box(w, h, d, col, x, y, z, rot=(0, 0, 0), anchor='bottom'):
    cy = y + h / 2 if anchor == 'bottom' else y
    v = [(sx * w / 2, sy * h / 2, sz * d / 2) for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)]
    f = [[0, 1, 3, 2], [4, 6, 7, 5], [0, 4, 5, 1], [2, 3, 7, 6], [0, 2, 6, 4], [1, 5, 7, 3]]
    return build(v, f, col, (x, cy, z), rot)


SMOOTH = 2          # v18q: nhân số cạnh của khối tròn để hết mặt tam giác to (cạnh ít ≤ 6 là hộp/cọc, giữ nguyên)


def cyl(r0, r1, h, n, col, x, y, z, rot=(0, 0, 0), anchor='bottom', top=None):
    if n >= 7:
        n = min(40, n * SMOOTH)
    cy = y + h / 2 if anchor == 'bottom' else y
    v, f, cols = [], [], []
    for i in range(n):
        a = 2 * math.pi * i / n
        v.append((r0 * math.cos(a), -h / 2, r0 * math.sin(a)))
    for i in range(n):
        a = 2 * math.pi * i / n
        v.append((r1 * math.cos(a), h / 2, r1 * math.sin(a)))
    for i in range(n):
        j = (i + 1) % n
        f.append([i, j, n + j, n + i])
    if r1 > 1e-6:
        f.append([n + i for i in range(n)])
    f.append(list(range(n)))
    colf = [col] * len(f)
    if top is not None and r1 > 1e-6:
        colf[n] = top
    return build(v, f, colf, (x, cy, z), rot)


def sphere(r, col, x, y, z, sc=(1, 1, 1), seg=(12, 8), rot=(0, 0, 0)):
    nu, nv = min(40, seg[0] * SMOOTH), min(26, seg[1] * SMOOTH)
    v, f = [], []
    for j in range(nv + 1):
        t = math.pi * j / nv
        for i in range(nu):
            a = 2 * math.pi * i / nu
            v.append((r * sc[0] * math.sin(t) * math.cos(a), r * sc[1] * math.cos(t), r * sc[2] * math.sin(t) * math.sin(a)))
    for j in range(nv):
        for i in range(nu):
            a, b = j * nu + i, j * nu + (i + 1) % nu
            f.append([a, b, b + nu, a + nu])
    return build(v, f, col, (x, y, z), rot)


def roof(w, h, d, col, x, y, z, end=None, rot=(0, 0, 0)):
    """Mái chóp, sống mái chạy dọc x. y = đáy mái."""
    v = [(-w / 2, -h / 2, -d / 2), (w / 2, -h / 2, -d / 2), (w / 2, -h / 2, d / 2), (-w / 2, -h / 2, d / 2),
         (-w / 2, h / 2, 0), (w / 2, h / 2, 0)]
    f = [[3, 2, 5, 4], [1, 0, 4, 5], [2, 1, 5], [0, 3, 4], [0, 1, 2, 3]]
    e = col if end is None else end
    return build(v, f, [col, col * 0.93, e, e, col], (x, y + h / 2, z), rot)


# ── Dựng ảnh ────────────────────────────────────────────────────────────────────────────────────
def project(P):
    x, y, z = P[..., 0], P[..., 1], P[..., 2]
    xr, zr = (x - z) / S2, (x + z) / S2
    return np.stack([xr, zr * math.sin(PITCH) - y * math.cos(PITCH)], axis=-1), zr * math.cos(PITCH) + y * math.sin(PITCH)


def shade(col, n):
    d = max(0.0, float(np.dot(n, LIGHT)))
    d = d ** 0.85
    f = 0.76 + 0.40 * d + 0.06 * max(0.0, float(n[1]))   # mặt hướng lên sáng hơn chút (trời)
    c = col * f
    if f < 0.95:   # bóng hơi ngả lạnh
        c = c * 0.94 + np.array([6, 10, 22]) * (0.95 - f) * 2.2
    return np.clip(c, 0, 255)



# ── Bụi cỏ 2D (dùng cho chân cỏ quanh vật và cho texture nền) ──────────────────────────────────
TUFT_DARK, TUFT_MID, TUFT_LIGHT = (62, 148, 52), (88, 184, 66), (136, 212, 92)


def draw_tuft(dr, x, y, s, rng, tones=(TUFT_DARK, TUFT_MID, TUFT_LIGHT)):
    """Một bụi cỏ: 5–8 lá cong toả quạt từ gốc (x, y), cao ~s. Lá ngoài tối, lá giữa sáng; vẽ lá ngoài trước."""
    n = rng.randint(5, 8)
    blades = []
    for i in range(n):
        ang = (i / (n - 1) - 0.5) * 1.9 + rng.uniform(-.16, .16)
        blades.append(ang)
    blades.sort(key=lambda a: -abs(a))
    for ang in blades:
        k = abs(ang) / 0.95
        L = s * rng.uniform(.78, 1.22) * (1.0 - 0.32 * k)
        wb = s * 0.15
        tx, ty = x + math.sin(ang) * L * 0.85, y - math.cos(ang) * L
        bend = math.sin(ang) * s * 0.16 + rng.uniform(-.06, .06) * s
        mx, my = x + (tx - x) * 0.5 + bend, y + (ty - y) * 0.5
        col = tones[0] if k > 0.62 else (tones[1] if k > 0.25 else tones[2])
        j = rng.uniform(.93, 1.07)
        col = tuple(int(min(255, c * j)) for c in col)
        dr.polygon([(x - wb, y), (mx - wb * .55, my), (tx, ty), (mx + wb * .55, my), (x + wb, y)], fill=col + (255,))


def leaf_texture(img, name):
    """Rắc cụm lá nhỏ sáng/tối lên vùng xanh lá (tán, bụi, cỏ) ⇒ tán có bề mặt lá thật thay vì nhựa láng.
    Chỉ chạm pixel có g > r, b rõ rệt nên không ảnh hưởng chuồng, hàng rào, vật nuôi."""
    a = np.asarray(img).astype(np.int16)
    r, g, b, al = a[..., 0], a[..., 1], a[..., 2], a[..., 3]
    mask = (al > 200) & (g > r + 18) & (g > b + 28)
    if mask.sum() < 400:
        return img
    rng = random.Random(zlib.crc32(name.encode()) & 0xffffff)
    W, H = img.size
    lay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    dr = ImageDraw.Draw(lay)
    ys, xs = np.nonzero(mask)
    n = int(len(xs) / (SS * SS * 62))
    for _ in range(n):
        i = rng.randrange(len(xs)); x, y = int(xs[i]), int(ys[i])
        s = SS * rng.uniform(2.6, 5.2)
        ang = rng.uniform(0, math.pi)
        dx, dy = math.cos(ang) * s, math.sin(ang) * s * 0.55
        light = rng.random() < 0.55
        col = (190, 235, 120, 88) if light else (28, 96, 40, 96)
        if not light: y += int(s * .3)
        dr.ellipse([x - s, y - s * .6, x + s, y + s * .6], fill=col)
        if light:   # nét sáng nhỏ ở mép trên-trái ⇒ cảm giác lá có khối
            dr.ellipse([x - s * .7 + dx * .2, y - s * .5, x + s * .2, y - s * .05], fill=(225, 250, 160, 90))
    lay = lay.filter(ImageFilter.GaussianBlur(SS * 0.45))
    m = Image.fromarray((mask * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(SS * 0.5))
    lay.putalpha(Image.fromarray((np.asarray(lay.getchannel('A')).astype(np.float32) * np.asarray(m).astype(np.float32) / 255).astype(np.uint8)))
    return Image.alpha_composite(img, lay)


def render(faces, name, shadow=None, out_dir='.', pad=10, skirt=0.0):
    vis = [(P, n, c) for (P, n, c) in faces if np.dot(n, VIEW) > 0.001]
    allv = np.concatenate([P for (P, _, _) in faces], axis=0)
    pts, _ = project(allv)
    if shadow:
        cx, cz, rx, rz = shadow
        sp = np.array([[cx + rx * .82 * math.cos(a), 0, cz + rz * .82 * math.sin(a)] for a in np.linspace(0, 2 * math.pi, 40)])
        sps, _ = project(sp)
        pts = np.concatenate([pts, sps], axis=0)
    ring = []
    if shadow and skirt > 0:
        rng = random.Random(zlib.crc32(name.encode()) & 0xffff)
        cx, cz, rx, rz = shadow
        n_t = int(round(14 + 16 * skirt * min(1.0, 0.45 + 0.28 * rx)))
        for i in range(n_t):
            a = 2 * math.pi * (i + rng.uniform(-.35, .35)) / n_t
            k = rng.uniform(.80, 1.08)
            ring.append(np.array([cx + rx * k * math.cos(a), 0, cz + rz * k * math.sin(a)]))
        rp, _ = project(np.array(ring))
        pts = np.concatenate([pts, rp + np.array([0, 0.0])], axis=0)
    mn, mx = pts.min(axis=0), pts.max(axis=0)
    span = max(mx - mn)
    sc = (OUT - 2 * pad) * SS / span
    W = int((mx[0] - mn[0]) * sc + 2 * pad * SS) + 2
    H = int((mx[1] - mn[1]) * sc + 2 * pad * SS) + 2

    def tp(P):
        q, _ = project(P)
        return [((a - mn[0]) * sc + pad * SS, (b - mn[1]) * sc + pad * SS) for a, b in q]

    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    if shadow:
        sh = Image.new('L', (W, H), 0)
        ImageDraw.Draw(sh).polygon(tp(sp), fill=70)
        sh = sh.filter(ImageFilter.GaussianBlur(5 * SS))
        black = Image.new('RGBA', (W, H), (20, 40, 20, 255)); black.putalpha(sh)
        img = Image.alpha_composite(img, black)
    dr = ImageDraw.Draw(img)
    tufts_back, tufts_front = [], []
    if ring:
        rng = random.Random((zlib.crc32(name.encode()) & 0xffff) + 1)
        cdepth = project(np.array([shadow[0], 0, shadow[1]]))[1]
        us = sc * min(0.30, 0.12 + 0.07 * shadow[2]) * (0.85 + 0.3 * min(skirt, 1.5))
        for P in ring:
            q, d_ = project(P)
            pt = ((q[0] - mn[0]) * sc + pad * SS, (q[1] - mn[1]) * sc + pad * SS)
            (tufts_front if d_ > cdepth else tufts_back).append((pt, us * rng.uniform(.75, 1.25)))
        tufts_back.sort(key=lambda t: t[0][1]); tufts_front.sort(key=lambda t: t[0][1])
        for (pt, u) in tufts_back:
            draw_tuft(dr, pt[0], pt[1], u, rng)
    order = sorted(vis, key=lambda t: project(t[0])[1].mean())
    for P, n, col in order:
        c = shade(col, n)
        edge = tuple(int(v) for v in np.clip(c, 0, 255)) + (255,)
        dr.polygon(tp(P), fill=tuple(int(v) for v in c) + (255,), outline=edge)
    for (pt, u) in tufts_front:
        draw_tuft(dr, pt[0], pt[1], u, rng)
    img = leaf_texture(img, name)
    bbox = img.getbbox()
    img = img.crop(bbox)
    k = OUT / max(img.size)
    img = img.resize((max(1, round(img.width * k)), max(1, round(img.height * k))), Image.LANCZOS)
    os.makedirs(out_dir, exist_ok=True)
    img.save(os.path.join(out_dir, name + '.png'), optimize=True)
    return img.size


# ── Các vật ─────────────────────────────────────────────────────────────────────────────────────
def barn():
    f = []
    f += box(3.0, 1.7, 2.3, RED, 0, 0, 0)
    f += box(3.06, .14, 2.36, WHITE, 0, 0, 0)
    f += roof(3.5, 1.2, 2.8, BROWN, 0, 1.7, 0, end=RED)
    f += box(.07, 1.25, 1.1, DRED, 1.52, 0, 0)
    f += box(.08, .1, 1.18, WHITE, 1.54, 1.2, 0) + box(.08, 1.3, .1, WHITE, 1.54, 0, .55) + box(.08, 1.3, .1, WHITE, 1.54, 0, -.55)
    for s in (1, -1):
        f += box(.09, 1.66, .09, WHITE, 1.56, .62, 0, rot=(s * 0.72, 0, 0), anchor='center')
    f += box(.08, .62, .62, WHITE, 1.77, 1.85, 0) + box(.09, .46, .46, BLUE, 1.79, 1.93, 0)
    for xo in (-.75, .75):
        f += box(.8, .62, .08, WHITE, xo, .85, 1.17) + box(.62, .44, .09, BLUE, xo, .94, 1.19)
    f += box(.5, .32, .5, STONE, 2.0, 0, .7) + box(.9, .55, .7, HAY, -.2, 0, 1.75)
    f += box(.9, .08, .7, HAYD, -.2, .55, 1.75)
    return f, (0, .3, 2.4, 1.9)


def silo():
    f = []
    body = hexc('EAE3D0')
    f += cyl(.95, .95, 3.0, 14, body, 0, 0, 0)
    for y in (.75, 1.55, 2.35):
        f += cyl(.98, .98, .1, 14, hexc('CDBF9E'), 0, y, 0)
    f += cyl(1.0, 0.0, 1.0, 14, RED, 0, 3.0, 0)
    f += cyl(.1, .1, .35, 6, STONED, 0, 3.95, 0)
    f += box(.62, .95, .08, DWOOD, .0, 0, .0 + .93, rot=(0, math.pi / 4, 0)) if False else []
    f += box(.09, .9, .6, DWOOD, .68, 0, .68, rot=(0, -math.pi / 4, 0))
    return f, (0, 0, 1.5, 1.2)


def windmill():
    f = []
    f += cyl(1.15, .75, 2.6, 8, CREAM, 0, 0, 0)
    f += cyl(1.17, 1.17, .22, 8, STONE, 0, 0, 0)
    f += cyl(.95, 0.0, .9, 8, RED, 0, 2.6, 0)
    f += box(.1, .9, .55, DWOOD, 1.0, 0, 1.0, rot=(0, -math.pi / 4, 0))
    f += box(.1, .42, .42, BLUE, .75, 1.4, .75, rot=(0, -math.pi / 4, 0))
    f += box(.07, .5, .5, WHITE, .56, 1.45, .56, rot=(0, math.pi / 4, 0)) if False else []
    hub = np.array([.8, 2.4, .8])
    f += sphere(.2, DWOOD, hub[0] + .02, hub[1], hub[2] + .02, seg=(8, 6))
    for k in range(4):
        a = k * math.pi / 2 + .42
        blade = box(.14, 1.7, .06, DWOOD, 0, .15, 0) + box(.5, 1.1, .05, hexc('FFF8E8'), .3, .5, 0)
        Rz, Ry = rotm(0, 0, a), rotm(0, math.pi / 4, 0)
        for (P, n, c) in blade:
            f.append((((P @ Rz.T) @ Ry.T) + hub + np.array([.14, 0, .14]), (n @ Rz.T) @ Ry.T, c))
    return f, (0, 0, 1.8, 1.8)


def haystack():
    f = []
    f += cyl(1.0, 0.7, .6, 12, HAYD, 0, 0, 0)
    f += cyl(.7, 0.0, 1.05, 12, HAY, 0, .6, 0)
    f += cyl(.72, .72, .06, 12, HAYD, 0, .72, 0)
    f += box(.5, .14, .08, DWOOD, .2, 0, 1.0, rot=(0, .3, 0))
    return f, (0, 0, 1.25, 1.1)


def bale():
    f = []
    f += cyl(.75, .75, 1.3, 14, HAY, 0, .75, 0, rot=(0, 0, math.pi / 2), anchor='center', top=HAYD)
    for xo in (-.35, 0, .35):
        f += cyl(.77, .77, .07, 14, HAYD, xo, .75, 0, rot=(0, 0, math.pi / 2), anchor='center')
    f += cyl(.45, .45, .02, 14, HAYD, .66, .75, 0, rot=(0, 0, math.pi / 2), anchor='center')
    return f, (0, 0, 1.4, 1.0)


def fence():
    f = []
    for xo in (-1.4, 0, 1.4):
        f += box(.22, 1.0, .22, WOOD, xo, 0, 0) + box(.26, .08, .26, DWOOD, xo, 1.0, 0)
    for y in (.3, .65):
        f += box(3.1, .12, .08, WOOD, 0, y, .12) + box(3.1, .12, .08, DWOOD, 0, y, -.12)
    return f, (0, 0, 1.9, .5)


def scarecrow():
    f = []
    f += box(.16, 2.0, .16, WOOD, 0, 0, 0)
    f += box(1.7, .13, .13, WOOD, 0, 1.25, 0)
    f += box(.5, .8, .4, BLUE, 0, .75, 0) + box(.52, .22, .42, RED, 0, .98, 0)
    f += sphere(.31, PUMP, 0, 1.78, 0, sc=(1, 1.05, 1)) + box(.05, .1, .05, DWOOD, 0, 2.08, 0)
    f += cyl(.5, .5, .06, 14, HAYD, 0, 2.0, 0) + cyl(.3, .26, .28, 14, HAY, 0, 2.04, 0) + cyl(.31, .31, .06, 14, RED, 0, 2.08, 0)
    for s in (-1, 1):
        f += box(.3, .1, .1, HAY, s * .95, 1.25, 0)
    f += box(.07, .07, .05, BLACK, -.1, 1.76, .3, rot=(0, math.pi / 4, 0)) + box(.07, .07, .05, BLACK, .1, 1.76, .3, rot=(0, math.pi / 4, 0))
    return f, (0, 0, .9, .8)


def sunflowers():
    f = []
    for (x, z, h, r) in ((-.5, -.2, 1.6, .38), (.45, -.1, 2.0, .44), (0, .45, 1.3, .34)):
        f += cyl(.05, .05, h, 6, LEAFD, x, .1, z)
        f += box(.34, .05, .2, LEAF, x + .18, .1 + h * .45, z, rot=(0, 0, .5)) + box(.34, .05, .2, LEAF, x - .18, .1 + h * .35, z, rot=(0, 0, -.5))
        f += cyl(r + .06, r + .06, .11, 12, SUND, x, .1 + h, z, rot=(math.pi / 2.6, math.pi / 4, 0), anchor='center') if False else []
        f += cyl(r * 1.35, r * 1.35, .1, 14, SUN, x, .1 + h, z, rot=(.95, math.pi / 4, 0), anchor='center')
        f += cyl(r * .72, r * .72, .13, 12, SUND, x, .1 + h, z, rot=(.95, math.pi / 4, 0), anchor='center')
    return f, (0, 0, 1.3, 1.2)


def wheat():
    f = []
    f += box(3.0, .22, 2.2, SOIL, 0, 0, 0) + box(3.0, .05, 2.2, SOILD, 0, .22, 0)
    for zi in range(4):
        z = -.8 + zi * .52
        for xi in range(9):
            x = -1.3 + xi * .32
            f += cyl(.025, .025, .75, 4, HAYD, x, .25, z) + cyl(.1, 0.0, .3, 5, HAY, x, .98, z)
    return f, (0, 0, 1.9, 1.5)


def carrots():
    f = []
    f += box(3.0, .22, 2.2, SOIL, 0, 0, 0) + box(3.0, .05, 2.2, SOILD, 0, .22, 0)
    for zi in range(4):
        z = -.8 + zi * .52
        for xi in range(6):
            x = -1.15 + xi * .46
            f += cyl(.12, 0.0, .26, 6, CARROT, x, .24, z)
            f += box(.05, .34, .05, LEAF, x, .28, z, rot=(0, 0, .45)) + box(.05, .4, .05, LEAFD, x, .28, z, rot=(0, 0, -.35)) + box(.05, .36, .05, LEAF, x, .28, z, rot=(.4, 0, 0))
    return f, (0, 0, 1.9, 1.5)


def pumpkins():
    f = []
    for (x, z, r) in ((-.5, 0, .5), (.45, .15, .4), (.05, -.55, .33)):
        f += sphere(r, PUMP, x, .1 + r * .78, z, sc=(1, .78, 1), seg=(12, 8))
        f += sphere(r * .55, PUMPD, x, .1 + r * .78, z, sc=(1.12, .7, 1.12), seg=(8, 6)) if False else []
        f += box(.1, .22, .1, LEAFD, x, .1 + r * 1.52, z)
        f += box(.3, .04, .18, LEAF, x + .12, .1 + r * 1.35, z, rot=(0, .3, .3))
    return f, (0, 0, 1.4, 1.1)


def tree(apple=True):
    f = []
    f += cyl(.2, .27, 1.1, 8, DWOOD, 0, 0, 0)
    f += sphere(.95, LEAF, 0, 1.6, 0, sc=(1.15, 1.0, 1.15), seg=(10, 7))
    f += sphere(.7, LEAFD, -.55, 1.35, .45, seg=(9, 6)) + sphere(.72, LEAF * 1.05, .55, 1.5, -.35, seg=(9, 6))
    f += sphere(.6, LEAF * 1.08, .1, 2.15, .1, seg=(9, 6))
    if apple:
        for (x, y, z) in ((.95, 1.5, .55), (.3, 1.2, 1.05), (1.05, 1.25, -.1), (.5, 2.0, .78), (-.1, 1.62, 1.02), (.82, 1.9, .1), (-.6, 1.3, .85)):
            f += sphere(.13, APPLE, x, y, z, seg=(7, 5))
    return f, (0, 0, 1.4, 1.3)


def chicken():
    f = []
    f += sphere(.62, WHITE, 0, .78, 0, sc=(1.12, .92, .86), seg=(10, 7))
    f += sphere(.33, WHITE, .56, 1.2, 0, seg=(9, 7))
    f += box(.16, .2, .1, RED, .56, 1.5, 0) + box(.12, .16, .09, RED, .66, 1.45, 0)
    f += cyl(.1, 0.0, .28, 5, CARROT, .92, 1.17, 0, rot=(0, 0, -math.pi / 2), anchor='center')
    f += box(.1, .2, .07, RED, .8, 1.0, 0)
    f += sphere(.3, hexc('F4EFE3'), -.58, 1.08, 0, sc=(.8, 1.05, .55), seg=(8, 6)) + sphere(.22, WHITE, -.72, 1.3, 0, sc=(.7, 1.1, .5), seg=(8, 6))
    f += sphere(.34, hexc('F1EBDD'), -.05, .8, .5, sc=(1.1, .7, .3), seg=(8, 6)) + sphere(.34, hexc('F1EBDD'), -.05, .8, -.5, sc=(1.1, .7, .3), seg=(8, 6))
    for z in (-.16, .16):
        f += cyl(.045, .045, .38, 5, CARROT, 0, 0, z) + box(.3, .05, .14, CARROT, .08, 0, z)
    f += sphere(.05, BLACK, .72, 1.28, .26, seg=(6, 4)) + sphere(.05, BLACK, .72, 1.28, -.26, seg=(6, 4))
    return f, (0, 0, .9, .7)


def sheep():
    f = []
    wool = hexc('FBF8F0')
    f += sphere(.8, wool, 0, 1.0, 0, sc=(1.28, .95, .95), seg=(12, 8))
    for (x, y, z, r) in ((-.55, 1.32, .32, .4), (.45, 1.4, -.28, .42), (0, 1.5, .1, .46), (-.6, .98, -.4, .38), (.5, 1.2, .45, .4), (-.15, 1.2, .55, .4)):
        f += sphere(r, wool, x, y, z, seg=(10, 7))
    f += sphere(.36, hexc('3A3330'), 1.08, 1.04, 0, sc=(.95, 1.05, .85), seg=(9, 7))
    f += sphere(.42, wool, .92, 1.4, 0, sc=(.8, .55, 1.0), seg=(9, 6))
    f += box(.22, .1, .3, hexc('3A3330'), 1.0, 1.2, .4, rot=(0, 0, .4)) + box(.22, .1, .3, hexc('3A3330'), 1.0, 1.2, -.4, rot=(0, 0, .4))
    f += sphere(.05, WHITE, 1.34, 1.14, .13, seg=(6, 4)) + sphere(.05, WHITE, 1.34, 1.14, -.13, seg=(6, 4))
    for (x, z) in ((.55, .3), (.55, -.3), (-.55, .3), (-.55, -.3)):
        f += box(.17, .55, .17, hexc('3A3330'), x, 0, z)
    return f, (0, 0, 1.6, 1.0)


def cow():
    f = []
    f += box(1.9, .95, 1.0, WHITE, 0, .62, 0)
    for (x, y, w_, h_) in ((-.35, .95, .75, .5), (.55, .75, .45, .55)):
        f += box(w_, h_, .04, BLACK, x, y, .51) + box(.04, h_, .55, BLACK, 1.0 if False else x + .0, y, 0) if False else []
    f += box(.8, .5, .12, BLACK, -.35, .95, .5) + box(.5, .46, .12, BLACK, .55, .74, .5)
    f += box(.8, .04, .7, BLACK, -.35, 1.56, .0) if False else []
    f += box(.82, .85, .82, WHITE, 1.2, .95, 0) + box(.36, .42, .72, PINK, 1.62, .92, 0)
    f += box(.2, .26, .24, BLACK, 1.16, 1.7, .48) + box(.2, .26, .24, BLACK, 1.16, 1.7, -.48)
    f += box(.1, .26, .08, CREAM, 1.2, 1.74, .22, rot=(0, 0, .3)) + box(.1, .26, .08, CREAM, 1.2, 1.74, -.22, rot=(0, 0, -.3))
    f += box(.06, .08, .06, BLACK, 1.6, 1.12, .24) + box(.06, .08, .06, BLACK, 1.6, 1.12, -.24)
    f += sphere(.06, BLACK, 1.5, 1.45, .25, seg=(6, 4)) + sphere(.06, BLACK, 1.5, 1.45, -.25, seg=(6, 4))
    f += box(.08, .5, .08, BLACK, -.98, .72, 0) + box(.16, .18, .16, BLACK, -.98, .56, 0)
    f += box(.32, .12, .5, PINK, .25, .55, 0)
    for (x, z) in ((.62, .33), (.62, -.33), (-.62, .33), (-.62, -.33)):
        f += box(.24, .7, .24, WHITE, x, 0, z) + box(.26, .12, .26, BLACK, x, 0, z)
    return f, (0, 0, 1.6, 1.0)


def well():
    f = []
    f += cyl(.95, .95, .75, 12, STONE, 0, 0, 0, top=STONED)
    f += cyl(.62, .62, .02, 12, SKY * .85, 0, .74, 0)
    for s in (-1, 1):
        f += box(.14, 1.55, .14, DWOOD, s * .85, .75, 0)
    f += roof(2.1, .7, 1.5, RED, 0, 2.3, 0, end=BROWN)
    f += box(1.7, .1, .1, WOOD, 0, 1.95, 0)
    f += cyl(.08, .08, .6, 6, WOOD, 0, 1.55, 0, rot=(0, 0, math.pi / 2), anchor='center')
    f += cyl(.2, .17, .24, 8, WOOD, 0, .75, 0)
    return f, (0, 0, 1.4, 1.2)


def tractor():
    f = []
    f += box(2.1, .8, 1.0, GREEN_T, .25, .55, 0) + box(.5, .15, 1.02, WHITE, 1.1, 1.3, 0) if False else []
    f += box(1.6, .75, 1.0, GREEN_T, .5, .6, 0)
    f += box(.9, .62, .9, GREEN_T * .95, 1.25, .55, 0)
    f += box(.5, .1, .9, DWOOD, 1.45, 1.17, 0) if False else []
    f += box(1.0, .08, .95, WHITE * .95, -.35, 1.95, 0)
    for (x, z) in ((-.78, .5), (-.78, -.5)):
        f += box(.08, 1.3, .08, WHITE * .9, x, .65, z * .98)
    f += box(.95, .7, .08, SKY, -.35, 1.2, .5) + box(.95, .7, .08, SKY, -.35, 1.2, -.5)
    f += box(.9, .12, .9, BLACK, -.35, .62, 0)
    f += cyl(.1, .1, .6, 8, STONED, 1.3, 1.1, .2)
    f += cyl(.5, .5, .38, 14, BLACK, -.55, .5, .7, rot=(math.pi / 2, 0, 0), anchor='center') if False else []
    for z in (.72, -.72):
        f += cyl(.62, .62, .34, 14, BLACK, -.45, .62, z, rot=(math.pi / 2, 0, 0), anchor='center')
        f += cyl(.34, .34, .36, 14, HAY, -.45, .62, z, rot=(math.pi / 2, 0, 0), anchor='center')
        f += cyl(.32, .32, .34, 12, BLACK, 1.35, .32, z * .88, rot=(math.pi / 2, 0, 0), anchor='center')
        f += cyl(.17, .17, .36, 10, HAY, 1.35, .32, z * .88, rot=(math.pi / 2, 0, 0), anchor='center')
    return f, (.3, 0, 2.0, 1.2)


def cart():
    f = []
    f += box(2.0, .15, 1.2, DWOOD, 0, .45, 0)
    for z in (.6, -.6):
        f += box(2.0, .5, .1, WOOD, 0, .55, z)
    f += box(.1, .5, 1.2, WOOD, 1.0, .55, 0) + box(.1, .5, 1.2, WOOD, -1.0, .55, 0)
    f += box(1.8, .5, 1.0, HAY, 0, .62, 0) + box(1.6, .22, .9, HAYD, 0, 1.0, 0)
    for z in (.7, -.7):
        f += cyl(.5, .5, .14, 14, DWOOD, 0, .5, z, rot=(math.pi / 2, 0, 0), anchor='center')
        f += cyl(.15, .15, .16, 8, WOOD, 0, .5, z, rot=(math.pi / 2, 0, 0), anchor='center')
    f += box(1.3, .1, .1, WOOD, 1.9, .5, 0)
    return f, (.3, 0, 1.8, 1.1)


# ── Thực vật & cảnh quan (v18p) ─────────────────────────────────────────────────────────────────
LEAFL, LEAFLL = hexc('6FCB4C'), hexc('8FDB5A')
PINE_D, PINE_M = hexc('2C7A4B'), hexc('3F9A5C')
DAISY, TULIP_R, TULIP_P, LAV = hexc('FFFDF4'), hexc('E8453C'), hexc('F06292'), hexc('8E6CD8')
BIRCH = hexc('EFE9DD')


def oak(apples=False, big=1.0):
    """Cây sồi: thân + 6–7 khối tán lệch tầng, đỉnh sáng, đáy tối ⇒ tán dày như ảnh cây chess.com."""
    f = []
    f += cyl(.26, .36, 1.35, 8, DWOOD, 0, 0, 0)
    f += box(.16, .8, .16, DWOOD, .3, .95, .05, rot=(0, 0, -.75), anchor='bottom') + box(.16, .7, .16, DWOOD, -.28, 1.0, -.05, rot=(0, 0, .75), anchor='bottom')
    f += sphere(1.2, LEAF, 0, 1.95, 0, sc=(1.18, .9, 1.18), seg=(14, 9))
    f += sphere(.85, LEAFD, -.95, 1.6, .35, seg=(11, 7)) + sphere(.88, LEAF * 1.02, .95, 1.7, -.3, seg=(11, 7))
    f += sphere(.78, LEAFD * 1.1, -.25, 1.55, 1.0, seg=(11, 7)) + sphere(.8, LEAF * 1.05, .3, 1.6, -1.0, seg=(11, 7))
    f += sphere(.85, LEAFL, .05, 2.6, .05, sc=(1.1, .9, 1.1), seg=(12, 8))
    f += sphere(.55, LEAFLL, -.55, 2.5, -.35, seg=(10, 7)) + sphere(.5, LEAFL, .6, 2.45, .4, seg=(10, 7))
    if apples:
        for (x, y, z) in ((1.25, 1.7, .55), (.4, 1.35, 1.35), (1.4, 1.5, -.2), (.75, 2.3, 1.0), (-.2, 1.9, 1.3), (1.1, 2.2, .1), (-.9, 1.55, 1.05), (-1.3, 1.8, -.1)):
            f += sphere(.15, APPLE, x, y, z, seg=(7, 5))
    f = [(P * big, n, c) for (P, n, c) in f]
    return f, (0, 0, 1.55 * big, 1.45 * big)


def pine():
    f = []
    f += cyl(.2, .26, 1.0, 7, DWOOD, 0, 0, 0)
    for i, (r, h, y) in enumerate(((1.35, 1.25, .8), (1.1, 1.15, 1.55), (.85, 1.05, 2.25), (.6, .95, 2.9))):
        f += cyl(r, 0.0, h, 10, PINE_D if i % 2 == 0 else PINE_M, 0, y, 0)
    return f, (0, 0, 1.45, 1.3)


def poplar():
    f = []
    f += cyl(.17, .22, .9, 7, DWOOD, 0, 0, 0)
    for (y, r, c) in ((1.2, .78, LEAFD), (1.95, .72, LEAF), (2.65, .62, LEAFL), (3.25, .42, LEAFLL)):
        f += sphere(r, c, 0, y, 0, sc=(.95, 1.25, .95), seg=(10, 7))
    return f, (0, 0, .95, .85)


def bush(berries=False, blossom=None):
    f = []
    spec = ((.62, LEAF, 0, .5, 0), (.52, LEAFD, .62, .42, .22), (.52, LEAF * 1.04, -.58, .4, .25), (.5, LEAFL, -.1, .62, -.45), (.42, LEAFLL, .2, .76, -.05), (.44, LEAFD * 1.1, .4, .4, -.5))
    for (r, c, x, y, z) in spec:
        f += sphere(r, c, x, y, z, sc=(1.1, .88, 1.1), seg=(10, 7))
    if berries:
        for (x, y, z) in ((.5, .9, .5), (-.4, .85, .55), (.1, 1.1, .3), (.85, .62, -.05), (-.8, .6, .1), (.25, .5, .95), (-.15, .5, .9)):
            f += sphere(.1, hexc('D6336C'), x, y, z, seg=(6, 4))
    if blossom is not None:
        for (x, y, z) in ((.5, .9, .5), (-.4, .85, .55), (.1, 1.1, .3), (.85, .62, -.05), (-.8, .6, .1), (.25, .5, .95), (-.15, .5, .9), (.55, .5, -.7)):
            f += sphere(.1, blossom, x, y, z, sc=(1, .6, 1), seg=(6, 4))
    return f, (0, 0, 1.2, 1.0)


def hedge():
    f = []
    f += box(3.2, .55, .95, LEAFD, 0, 0, 0)
    for i, x in enumerate((-1.3, -.65, 0, .65, 1.3)):
        f += sphere(.52, LEAF if i % 2 == 0 else LEAFL, x, .62, 0, sc=(1.05, .78, 1.0), seg=(9, 6))
    f += box(3.0, .1, .9, LEAFD * .9, 0, .5, 0) if False else []
    return f, (0, 0, 1.75, .6)


def flower(x, z, h, col, center=SUN, r=.2):
    f = []
    f += cyl(.035, .035, h, 5, LEAFD, x, 0, z)
    f += box(.3, .04, .16, LEAF, x + .15, h * .35, z, rot=(0, 0, .55)) + box(.3, .04, .16, LEAF, x - .15, h * .22, z, rot=(0, 0, -.55))
    f += cyl(r, r * .9, .06, 9, col, x, h, z, rot=(.5, .6, 0), anchor='center')
    f += sphere(r * .42, center, x, h + .02, z, seg=(7, 5))
    return f


def tulip(x, z, h, col):
    f = []
    f += cyl(.035, .035, h, 5, LEAFD, x, 0, z)
    f += box(.34, .05, .14, LEAF, x + .17, h * .3, z, rot=(0, 0, .75)) + box(.34, .05, .14, LEAF, x - .17, h * .3, z, rot=(0, 0, -.75))
    f += sphere(.17, col, x, h + .1, z, sc=(.9, 1.35, .9), seg=(8, 6))
    return f


def lavender(x, z, h):
    f = []
    f += cyl(.03, .03, h * .6, 5, LEAFD, x, 0, z)
    f += cyl(.1, 0.0, h * .6, 6, LAV, x, h * .5, z)
    return f


def leaf_clump(x, z, r=.5):
    return sphere(r, LEAF, x, r * .3, z, sc=(1.2, .45, 1.2), seg=(8, 5))


def flowers_daisy():
    f = []
    for (x, z, r) in ((-.7, .1, .55), (.15, -.1, .65), (.85, .2, .5), (0, .6, .5)):
        f += leaf_clump(x, z, r)
    for (x, z, h, c) in ((-.75, .05, .9, DAISY), (-.35, .35, .65, SUN), (.1, -.15, 1.15, DAISY), (.55, .3, .75, DAISY), (.9, .1, .95, hexc('FFD6E7')), (.25, .65, .55, DAISY), (-.5, -.3, 1.0, SUN)):
        f += flower(x, z, h, c, center=SUN if c is not SUN else hexc('E58A2B'), r=.22)
    return f, (0, 0, 1.25, .8)


def flowers_tulip():
    f = []
    for (x, z, r) in ((-.7, .0, .5), (.1, .15, .6), (.8, -.05, .5)):
        f += leaf_clump(x, z, r)
    for (x, z, h, c) in ((-.8, .0, .85, TULIP_R), (-.45, .3, .6, TULIP_P), (-.1, -.1, .95, TULIP_R), (.3, .3, .7, hexc('FFB02E')), (.7, -.05, .9, TULIP_P), (.95, .25, .6, TULIP_R)):
        f += tulip(x, z, h, c)
    for (x, z, h) in ((.05, .55, .8), (-.25, -.5, .95), (.55, -.45, .85)):
        f += lavender(x, z, h)
    return f, (0, 0, 1.25, .8)


def draw_flower2d(dr, x, y, s, col, center=(255, 201, 60)):
    """Hoa nhỏ 2D: cuống + 5 cánh tròn + nhuỵ, cao ~s."""
    dr.line([(x, y), (x, y - s)], fill=(60, 140, 50, 255), width=max(2, int(s * .09)))
    hx, hy, pr = x, y - s, s * .2
    for k in range(5):
        a = 2 * math.pi * k / 5 - math.pi / 2
        px, py = hx + math.cos(a) * pr * .95, hy + math.sin(a) * pr * .8
        dr.ellipse([px - pr, py - pr, px + pr, py + pr], fill=col + (255,))
    dr.ellipse([hx - pr * .62, hy - pr * .62, hx + pr * .62, hy + pr * .62], fill=center + (255,))


def render_grass(name, out_dir, kind):
    rng = random.Random(zlib.crc32(name.encode()))
    W, H = 240 * SS, 200 * SS
    img = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    sh = Image.new('L', (W, H), 0)
    dr = ImageDraw.Draw(img)
    base = H * 0.78
    if kind == 'a':      # một bụi cỏ lớn + 2 bụi con
        spots = [(W * .50, base, 120 * SS), (W * .30, base + 6 * SS, 70 * SS), (W * .70, base + 4 * SS, 78 * SS)]
        flowers = []
    elif kind == 'b':    # hàng 5 bụi thấp
        spots = [(W * (.14 + .18 * i), base + (i % 2) * 8 * SS, (56 + rng.randint(0, 26)) * SS) for i in range(5)]
        flowers = []
    else:                # bụi cỏ + hoa dại
        spots = [(W * .30, base, 86 * SS), (W * .66, base + 4 * SS, 92 * SS), (W * .48, base + 10 * SS, 58 * SS)]
        flowers = [(W * .38, base - 6 * SS, 78 * SS, (255, 253, 244)), (W * .58, base - 2 * SS, 92 * SS, (255, 214, 231)),
                   (W * .76, base + 2 * SS, 70 * SS, (255, 201, 60)), (W * .22, base + 2 * SS, 66 * SS, (190, 160, 255))]
    shd = ImageDraw.Draw(sh)
    for (x, y, u) in spots:
        shd.ellipse([x - u * .55, y - u * .06, x + u * .55, y + u * .16], fill=70)
    sh = sh.filter(ImageFilter.GaussianBlur(4 * SS))
    shadow = Image.new('RGBA', (W, H), (20, 50, 20, 255)); shadow.putalpha(sh)
    img = Image.alpha_composite(img, shadow)
    dr = ImageDraw.Draw(img)
    for (x, y, u) in sorted(spots, key=lambda t: t[1]):
        draw_tuft(dr, x, y, u, rng)
    for (x, y, u, c) in flowers:
        draw_flower2d(dr, x, y, u, c, center=(255, 201, 60) if c != (255, 201, 60) else (229, 138, 43))
    for (x, y, u) in sorted(spots, key=lambda t: t[1]):
        draw_tuft(dr, x + rng.uniform(-8, 8) * SS, y + 3 * SS, u * .55, rng)
    img = img.crop(img.getbbox())
    k = OUT / max(img.size)
    img = img.resize((max(1, round(img.width * k)), max(1, round(img.height * k))), Image.LANCZOS)
    os.makedirs(out_dir, exist_ok=True)
    img.save(os.path.join(out_dir, name + '.png'), optimize=True)
    return img.size


def mushrooms():
    f = []
    for (x, z, h, r) in ((-.3, 0, .5, .38), (.35, .2, .35, .28), (.05, -.4, .28, .22)):
        f += cyl(.1, .13, h, 7, hexc('F3EAD3'), x, 0, z)
        f += sphere(r, hexc('D9473A'), x, h, z, sc=(1, .6, 1), seg=(9, 6))
        for (dx, dz) in ((.12, .05), (-.1, .12), (.02, -.14)):
            f += sphere(r * .16, WHITE, x + dx * r * 2, h + r * .5, z + dz * r * 2, seg=(5, 4))
    return f, (0, 0, .8, .6)


def stump():
    f = []
    f += cyl(.55, .62, .65, 10, DWOOD, 0, 0, 0, top=hexc('E8C48B'))
    f += cyl(.2, .2, .05, 8, hexc('C99A5B'), 0, .66, 0)
    f += cyl(.2, .2, 1.3, 8, WOOD, .95, .22, .55, rot=(0, .6, math.pi / 2), anchor='center')
    f += sphere(.2, LEAFL, .4, .12, -.5, sc=(1.2, .5, 1.2), seg=(6, 4))
    return f, (.3, .25, 1.1, .8)


def pond():
    f = []
    f += cyl(1.75, 1.75, .14, 16, STONED, 0, 0, 0)
    f += cyl(1.5, 1.5, .16, 16, hexc('4BA6D8'), 0, .02, 0, top=hexc('5FB8E8'))
    rr = random.Random(5)
    for i in range(11):
        a = 2 * math.pi * i / 11 + rr.uniform(-.1, .1)
        r = 1.68
        f += box(rr.uniform(.34, .5), rr.uniform(.2, .3), rr.uniform(.3, .42), STONE if i % 2 else STONED * 1.12, r * math.cos(a), 0, r * math.sin(a) * .98, rot=(0, -a + rr.uniform(-.3, .3), 0))
    for (x, z, r) in ((-.5, .3, .34), (.4, -.4, .3), (.55, .45, .26)):
        f += cyl(r, r, .04, 10, hexc('4FAE3E'), x, .17, z)
    f += cyl(.09, .09, .05, 8, hexc('F7B6CE'), -.5, .21, .3)
    for (x, z) in ((1.2, -.9), (1.35, -.7), (1.05, -1.05)):
        f += cyl(.04, .0, .9, 4, LEAFD, x, .1, z) + cyl(.11, .11, .24, 6, hexc('8A5A33'), x, .85, z)
    return f, (0, 0, 2.0, 1.6)


# (tên, hàm dựng, độ dày chân cỏ: 0 = không có)
MODELS = [
    ('farm_barn', barn, 1.0), ('farm_silo', silo, 1.0), ('farm_windmill', windmill, 1.0), ('farm_haystack', haystack, 1.0),
    ('farm_bale', bale, 1.0), ('farm_fence', fence, 0.9), ('farm_scarecrow', scarecrow, 1.0), ('farm_sunflowers', sunflowers, 1.2),
    ('farm_wheat', wheat, 0.8), ('farm_carrots', carrots, 0.8), ('farm_pumpkins', pumpkins, 1.2), ('farm_tree_apple', lambda: oak(True), 1.2),
    ('farm_tree', lambda: oak(False), 1.2), ('farm_chicken', chicken, 0.7), ('farm_sheep', sheep, 0.8), ('farm_cow', cow, 0.8),
    ('farm_well', well, 1.0), ('farm_tractor', tractor, 0.8), ('farm_cart', cart, 0.8),
    # v18p: cây cỏ hoa lá
    ('farm_pine', pine, 1.1), ('farm_poplar', poplar, 1.0),
    ('farm_bush', bush, 0.9), ('farm_bush_berry', lambda: bush(berries=True), 0.9),
    ('farm_bush_blossom', lambda: bush(blossom=hexc('FFB7D5')), 0.9),
    ('farm_hedge', hedge, 0.8),
    ('farm_flowers_daisy', flowers_daisy, 0.7), ('farm_flowers_tulip', flowers_tulip, 0.7),
    ('farm_grass_a', 'a', 0.0), ('farm_grass_b', 'b', 0.0), ('farm_grass_c', 'c', 0.0),
    ('farm_mushrooms', mushrooms, 0.8), ('farm_stump', stump, 0.9), ('farm_pond', pond, 0.9),
]

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'res', 'drawable-nodpi')
    only = set(sys.argv[2:])
    for name, fn, skirt in MODELS:
        if only and name not in only:
            continue
        if isinstance(fn, str):
            w, h = render_grass(name, out, fn)
        else:
            faces, sh = fn()
            w, h = render(faces, name, shadow=sh, out_dir=out, skirt=skirt)
        print(f'{name:18s} {w}x{h}  ratio={w}f / {h}f')
