#!/usr/bin/env python3
"""Dựng texture ĐỒNG CỎ lặp liền (tileable) cho chương Nông trại của bản đồ Câu đố.

    python3 tools/farm/render_ground.py [file ra, mặc định app/src/main/res/drawable-nodpi/farm_ground.jpg]

Nền = mảng sáng/tối mềm (nhiễu tuần hoàn) + bụi cỏ nhiều lá + hoa dại + cỏ ba lá + đốm đất + sỏi nhỏ.
Mọi chi tiết vẽ lặp quanh mép (9 bản) ⇒ ghép gạch theo cả hai chiều không lộ đường nối.
"""
import math, os, random, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy.ndimage import gaussian_filter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from render_farm import draw_tuft, draw_flower2d   # noqa: E402

N = 768           # cạnh gạch (px)
SS = 2            # siêu lấy mẫu
rng = np.random.default_rng(20261118)
rnd = random.Random(20261118)

# ── Nền: hai tầng nhiễu tuần hoàn ──
def periodic_noise(sigma):
    a = rng.standard_normal((N, N))
    a = gaussian_filter(a, sigma, mode='wrap')
    return (a - a.mean()) / a.std()

t = 0.62 * periodic_noise(110) + 0.38 * periodic_noise(34)
t = np.clip(t / 2.4 + 0.5, 0, 1)                       # 0..1
dark, light = np.array([104, 180, 66.]), np.array([134, 203, 88.])
base = dark[None, None, :] * (1 - t[..., None]) + light[None, None, :] * t[..., None]
img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), 'RGB').convert('RGBA')
img = img.resize((N * SS, N * SS), Image.BICUBIC)
W = N * SS

def wrapped(draw_fn, x, y, r):
    """Gọi draw_fn(x', y') cho mọi bản sao lặp mà hình (bán kính r) chạm khung."""
    for ox in (-W, 0, W):
        for oy in (-W, 0, W):
            xx, yy = x + ox, y + oy
            if -r <= xx <= W + r and -r <= yy <= W + r:
                draw_fn(xx, yy)

dr = ImageDraw.Draw(img, 'RGBA')

# ── Đốm đất + sỏi nhỏ (rất nhẹ) ──
for _ in range(22):
    x, y = rnd.uniform(0, W), rnd.uniform(0, W)
    w, h = rnd.uniform(5, 12) * SS, rnd.uniform(2.5, 5) * SS
    col = (150, 118, 70, 46)
    wrapped(lambda a, b: dr.ellipse([a - w, b - h, a + w, b + h], fill=col), x, y, w)
for _ in range(14):
    x, y = rnd.uniform(0, W), rnd.uniform(0, W)
    w, h = rnd.uniform(4, 7) * SS, rnd.uniform(3, 5) * SS
    def pebble(a, b, w=w, h=h):
        dr.ellipse([a - w, b - h + 2 * SS, a + w, b + h + 2 * SS], fill=(60, 90, 40, 90))
        dr.ellipse([a - w, b - h, a + w, b + h], fill=(206, 200, 184, 255))
        dr.ellipse([a - w * .6, b - h * .8, a + w * .3, b - h * .1], fill=(232, 228, 214, 255))
    wrapped(pebble, x, y, w * 2)

# ── Cỏ ba lá ──
for _ in range(20):
    x, y = rnd.uniform(0, W), rnd.uniform(0, W)
    r = rnd.uniform(6, 10) * SS
    def clover(a, b, r=r):
        for k in range(3):
            ang = 2 * math.pi * k / 3 - math.pi / 2
            px, py = a + math.cos(ang) * r * .7, b + math.sin(ang) * r * .5
            dr.ellipse([px - r * .6, py - r * .5, px + r * .6, py + r * .5], fill=(76, 160, 60, 235))
        dr.ellipse([a - r * .35, b - r * .25, a + r * .35, b + r * .25], fill=(120, 196, 82, 255))
    wrapped(clover, x, y, r * 2)

# ── Bụi cỏ ──
tuft_pts = []
for _ in range(58):
    x, y = rnd.uniform(0, W), rnd.uniform(0, W)
    u = rnd.uniform(24, 40) * SS
    tuft_pts.append((x, y, u))
tuft_pts.sort(key=lambda p: p[1])
for (x, y, u) in tuft_pts:
    seed = rnd.randrange(1 << 30)
    def tuft(a, b, u=u, seed=seed):
        # bóng nhỏ dưới bụi
        dr.ellipse([a - u * .5, b - u * .05, a + u * .5, b + u * .14], fill=(40, 90, 30, 34))
        draw_tuft(dr, a, b, u, random.Random(seed), tones=((70, 150, 54), (92, 172, 62), (150, 214, 98)))
    wrapped(tuft, x, y, u * 1.2)

# ── Hoa dại ──
cols = [(255, 253, 244), (255, 214, 231), (255, 201, 60), (190, 160, 255), (255, 160, 120)]
for _ in range(30):
    x, y = rnd.uniform(0, W), rnd.uniform(0, W)
    s = rnd.uniform(13, 21) * SS
    c = rnd.choice(cols)
    cen = (229, 138, 43) if c == (255, 201, 60) else (255, 201, 60)
    def fl(a, b, s=s, c=c, cen=cen):
        dr.ellipse([a - s * .3, b - s * .04, a + s * .3, b + s * .1], fill=(40, 90, 30, 60))
        draw_flower2d(dr, a, b, s, c, center=cen)
    wrapped(fl, x, y, s * 1.2)

out = img.resize((N, N), Image.LANCZOS).convert('RGB')
path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'res', 'drawable-nodpi', 'farm_ground.jpg')
out.save(path, quality=88, optimize=True)
a = np.asarray(out, float).reshape(-1, 3).mean(axis=0)
print('saved', path, os.path.getsize(path) // 1024, 'KB; mean RGB', [int(v) for v in a], '#%02X%02X%02X' % tuple(int(v) for v in a))
