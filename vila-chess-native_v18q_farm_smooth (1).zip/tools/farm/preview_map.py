#!/usr/bin/env python3
"""Mô phỏng (xấp xỉ) một đoạn bản đồ Câu đố vùng Nông trại để XEM thử không cần build Android.

Cổng Python của themedProps() + layoutAroundPath() + nền ChapterGround (texture) + ô khối.
    python3 tools/farm/preview_map.py out.png [số khối=2] [bộ pool: new|old]
"""
import math, os, re, random, sys
from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
RES = os.path.join(ROOT, 'app/src/main/res/drawable-nodpi')
UI = os.path.join(ROOT, 'app/src/main/java/com/vila/chess/ui')

# ── Đọc PropKind (res, ratio) và các biến thể cảnh ──
src = open(os.path.join(UI, 'PuzzleMapScreen.kt'), encoding='utf-8').read()
KIND = {}
for m in re.finditer(r'(\w+)\(R\.drawable\.(\w+), (\d+)f / (\d+)f\)', src):
    KIND[m.group(1)] = (m.group(2), int(m.group(3)) / int(m.group(4)))
data = open(os.path.join(UI, 'PuzzleSceneryData.kt'), encoding='utf-8').read()
VARIANTS = []
for vm in re.finditer(r'private val SceneV\d+ = listOf\((.*?)\n\)', data, re.S):
    props = []
    for pm in re.finditer(r'Prop\(PropKind\.(\w+), (-?[\d.]+)f, (-?[\d.]+)f, (-?[\d.]+)f(, mirror = true)?\)', vm.group(1)):
        props.append(dict(kind=pm.group(1), x=float(pm.group(2)), y=float(pm.group(3)), w=float(pm.group(4)), mirror=bool(pm.group(5))))
    VARIANTS.append(props)

# ── Phân loại (khớp categoryOf trong PuzzleChapters.kt) ──
CAT = {}
for k in 'Tree Pine KfTree KfTreeHigh KaTree'.split(): CAT[k] = 'TREE'
for k in 'Rocks KfStones KfRocksLow KfRocksRamp KfRocksHigh KaColumnDamaged KaBricks'.split(): CAT[k] = 'ROCK'
for k in 'FlowersWhite FlowersColor Bush KfPlant KfPatchDirt KfPatchGrass KfWeaponArrow KfWeaponBow'.split(): CAT[k] = 'SMALL'
for k in 'Bench KfFence KfLadder KfPlatform KfBridge KaBorderCorner KaBorderStraight KaFloor KaFloorDetail'.split(): CAT[k] = 'FURN'
for k in 'KfFlag KaBanner KaWeaponSpear KaWeaponSword KaColumn KfTarget KaTrophy KaStatue KaWeaponRack'.split(): CAT[k] = 'TALL'
for k in 'KfCharacterArcher KaCharacterSoldier'.split(): CAT[k] = 'CHAR'
def cat(k): return CAT.get(k, 'BIG')

def kotlin_pools():
    """Đọc FarmPools thật từ PuzzleChapters.kt để preview luôn khớp code."""
    t = open(os.path.join(UI, 'PuzzleChapters.kt'), encoding='utf-8').read()
    a = t.index('private val FarmPools')
    b = t.index('\n)\n', a)
    pools = {}
    for m in re.finditer(r'PropCat\.(\w+) to listOf\((.*?)\),?\n', t[a:b + 3]):
        pools[m.group(1)] = re.findall(r'PropKind\.(\w+)', m.group(2))
    return pools

def kotlin_const(name, default):
    t = open(os.path.join(UI, 'PuzzleChapters.kt'), encoding='utf-8').read()
    m = re.search(name + r'\s*=\s*([\d.]+)f', t)
    return float(m.group(1)) if m else default

POOLS = kotlin_pools()

def kotlin_fill():
    t = open(os.path.join(UI, 'PuzzleChapters.kt'), encoding='utf-8').read()
    a = t.index('private val FarmFillPool')
    return re.findall(r'PropKind\.(\w+)', t[a:t.index('\n)\n', a)])
FILL = kotlin_fill()
FILL_EXTRA = int(kotlin_const('fillExtra = ', 5)) if False else int(re.search(r'fillExtra = (\d+)', open(os.path.join(UI, 'PuzzleChapters.kt'), encoding='utf-8').read().split('private val FarmChapter')[1]).group(1))
TREE_BOOST = kotlin_const('FARM_TREE_BOOST', 1.0)

def ratio(k): return KIND[k][1]

def themed(base):
    out = []
    for p in base:
        pool = POOLS.get(cat(p['kind']))
        if not pool: continue
        h = (((int(p['x'] * 1000) * 31 + int(p['y'] * 10000)) & 0x7fffffff) % len(pool))
        kind = pool[h]
        w = (p['w'] / ratio(p['kind'])) * ratio(kind)
        lo, hi = p['w'] * 0.6, p['w'] * 1.4
        w = min(max(w, lo), hi)
        if cat(p['kind']) == 'TREE': w = min(w * TREE_BOOST, p['w'] * 1.4 * TREE_BOOST)
        out.append(dict(kind=kind, x=p['x'] + (p['w'] - w) / 2, y=p['y'], w=w, mirror=p['mirror']))
    return out

# ── Hình học đường đi ──
ITEM_RATIO, LEVELS, SLAB_ASPECT, AMP = 0.58, 16, 0.64, 0.28
TRACK_ITEM_H = 0.205 * ITEM_RATIO
BLOCK_H = TRACK_ITEM_H * LEVELS
def level_x(l):
    p = (l - 1) % 8
    tri = 1 - p / 2 if p <= 4 else (p - 4) / 2 - 1
    return 0.5 + AMP * tri
def nodes():
    w = 0.205 * 1.22; h = w * SLAB_ASPECT * 1.3   # v18q khớp PathNodes (Kotlin)
    out = []
    for j in range(1, LEVELS + 1):
        cx = level_x(j); cy = (LEVELS - j + 0.5) * TRACK_ITEM_H
        out.append((cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2))
    return out
NODES = nodes()
def box(kind, x, y, w):
    h = w / ratio(kind)
    return (x + w * .06, y + h * .06, x + w * .94, y + h * .94)   # khớp boxOf (Kotlin) v18q
NODE_CLEAR = 0.014


def hits(a, b, m=0.0):
    return a[0] < b[2] + m and a[2] > b[0] - m and a[1] < b[3] + m and a[3] > b[1] - m

FILL_X = [-0.03, 0.89, 0.02, 0.84]
def layout(props):
    out, boxes, bad = [], [], []
    for p in props:
        b = box(p['kind'], p['x'], p['y'] * BLOCK_H, p['w'])
        wing = p['x'] + p['w'] < -0.02 or p['x'] > 1.02
        if not wing and any(hits(n, b, NODE_CLEAR) for n in NODES): bad.append(p)
        else: out.append(p); boxes.append(b)
    shifts = sorted([(dx * .02, dy * .01) for dx in range(-20, 21) for dy in (0, 3, -3, 6, -6, 9, -9)], key=lambda t: abs(t[0]) + 2 * abs(t[1]))
    lost = 0
    for p in bad:
        h = p['w'] / ratio(p['kind'])
        placed = False
        for dx, dy in shifts:
            nx, ny = p['x'] + dx, p['y'] * BLOCK_H + dy
            if nx < -.5 * p['w'] or nx + p['w'] > 1 + .5 * p['w'] or ny < 0 or ny + h > BLOCK_H: continue
            b = box(p['kind'], nx, ny, p['w'])
            if any(hits(n, b, NODE_CLEAR) for n in NODES) or any(hits(o, b, .004) for o in boxes): continue
            out.append(dict(p, x=nx, y=ny / BLOCK_H)); boxes.append(b); placed = True; break
        if not placed: lost += 1
    pool = FILL
    want, n, row = lost + FILL_EXTRA, 0, 0
    while want > 0 and row < 40:
        ny = row * .047
        for fx in FILL_X:
            if want <= 0: break
            kind = pool[(row * 7 + n) % len(pool)]
            w = .09 * (.8 + .1 * ((row + n) % 5))
            if ny + w / ratio(kind) > BLOCK_H: continue
            b = box(kind, fx, ny, w)
            if any(hits(nd, b, NODE_CLEAR) for nd in NODES) or any(hits(o, b, .01) for o in boxes): continue
            out.append(dict(kind=kind, x=fx, y=ny / BLOCK_H, w=w, mirror=(row + n) % 2 == 0)); boxes.append(b); want -= 1; n += 1
        row += 1
    out.sort(key=lambda p: p['y'] + p['w'] / ratio(p['kind']) / BLOCK_H)
    return out

_cache = {}
def sprite(kind, wpx, mirror):
    key = (kind, wpx, mirror)
    if key not in _cache:
        im = Image.open(os.path.join(RES, KIND[kind][0] + '.png')).convert('RGBA')
        h = max(1, round(wpx / ratio(kind)))
        im = im.resize((max(1, wpx), h), Image.LANCZOS)
        if mirror: im = im.transpose(Image.FLIP_LEFT_RIGHT)
        _cache[key] = im
    return _cache[key]

def slab(dr, cx, cy, w, top, side):
    h = w * .5; th = w * .14
    dr.polygon([(cx - w / 2, cy), (cx, cy + h / 2), (cx, cy + h / 2 + th), (cx - w / 2, cy + th)], fill=side)
    dr.polygon([(cx + w / 2, cy), (cx, cy + h / 2), (cx, cy + h / 2 + th), (cx + w / 2, cy + th)], fill=tuple(int(c * .88) for c in side))
    dr.polygon([(cx, cy - h / 2), (cx + w / 2, cy), (cx, cy + h / 2), (cx - w / 2, cy)], fill=top)

def main():
    out = sys.argv[1]
    nblocks = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    TW = 540
    BH = int(BLOCK_H * TW)
    H = BH * nblocks
    gt = Image.open(os.path.join(RES, 'farm_ground.jpg')).convert('RGB')
    canvas = Image.new('RGBA', (TW, H))
    # nền: texture lặp theo toạ độ thế giới (khối 0 ở đáy)
    for y in range(-(gt.height), H + gt.height, gt.height):
        for x in range(0, TW, gt.width):
            canvas.paste(gt, (x, y + (H % gt.height)))
    for b in range(nblocks):        # b = 0 là khối DƯỚI cùng
        top = H - (b + 1) * BH
        props = layout(themed(VARIANTS[(b * 3 + b // 7) % len(VARIANTS)]))
        for p in props:
            w = max(1, round(TW * p['w']))
            im = sprite(p['kind'], w, p['mirror'])
            canvas.alpha_composite(im, (int(TW * p['x']), int(top + BH * p['y']))) if int(TW * p['x']) >= 0 and int(TW * p['x']) + im.width <= TW else _paste_clip(canvas, im, int(TW * p['x']), int(top + BH * p['y']))
        dr = ImageDraw.Draw(canvas, 'RGBA')
        for j in range(1, LEVELS + 1):
            cx = level_x(j) * TW; cy = top + (LEVELS - j + 0.5) * TRACK_ITEM_H * TW
            level = b * LEVELS + j
            cur = 11
            if level < cur: slab(dr, cx, cy, 0.205 * TW, (245, 184, 61, 255), (196, 130, 30, 255))
            elif level == cur: slab(dr, cx, cy, 0.205 * TW, (255, 200, 58, 255), (224, 149, 26, 255))
            else: slab(dr, cx, cy, 0.205 * TW, (125, 144, 166, 255), (88, 104, 124, 255))
    canvas.convert('RGB').save(out)
    print('saved', out, canvas.size)

def _paste_clip(canvas, im, x, y):
    tmp = Image.new('RGBA', canvas.size, (0, 0, 0, 0))
    tmp.paste(im, (x, y), im)
    canvas.alpha_composite(tmp)

if __name__ == '__main__':
    main()
