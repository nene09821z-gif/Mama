# v18 — Trang Bài học dạng bản đồ khóa học (cùng ngôn ngữ thiết kế với bản đồ Câu đố)

## Sửa
- ui/LessonsScreen.kt : thay toàn bộ giao diện danh sách bằng BẢN ĐỒ (`LessonMap`). `LessonsTab(vm, bottomPad, onPlayingChange, onUpgrade)`
  giữ NGUYÊN chữ ký ⇒ HomeScreen.kt không phải sửa.

## Giao diện
- Mỗi KHÓA HỌC = một chặng: tấm biển khóa (tên, cấp độ, vòng % tiến độ; khóa PRO có ổ khóa + nhãn PRO), nền/vật cảnh/hạt theo chủ đề
  (Rừng → Giáng sinh → Sa mạc → Không gian → Biển, lặp vòng 5 chặng), dùng lại `mapChapterFor`, `drawSlab`, `ThemeAmbient`, `Mascot`, `PropKind`.
- Đường đi chữ S từ trên xuống; mỗi ô có nhãn tên bài + loại bài + số phút. 4 trạng thái ô: Đã xong · Bài tiếp theo (vàng + linh vật) · Chưa học · Khóa PRO.
- Học xong một bài: ô bật nảy + vòng sóng sáng, ~1 giây sau mới hiện hộp thoại bài kế tiếp (TACTIC). Bài PRACTICE: quay lại tab Học thì ô vừa xong tự bật nảy.
- HUD trên (tên khóa đang xem, đổi màu theo khóa) + bảng dưới (số bài, lượt miễn phí còn lại/đếm ngược, chuỗi ngày, thanh tiến độ, thẻ bàn cờ + nút "HỌC TIẾP").
- Nút nổi "Bài tiếp theo" khi cuộn xa bài hiện tại.

## Không đổi
- Luật hạn mức (LessonQuota), khóa PRO, LessonStore, LessonCatalog, LessonPuzzleScreen, GameViewModel.startLesson: giữ nguyên, file mới chỉ gọi lại.
- MiniBoard / Countdown / Chip / Notice giống hệt bản cũ; UpgradePromo chỉ đổi khoảng cách trên 10dp → 6dp.

## Đã kiểm tra tĩnh trước khi ghép (chưa build thử – không có Android SDK ở đây)
- Mọi symbol dùng từ file khác đều tồn tại và không `private`: ChapterDeco, MapChapter, Mascot, PropKind (41/41 vật cảnh có trong enum), SLAB_ASPECT,
  Slab*Top/Side, drawSlab, drawCheck, mapChapterFor, ThemeAmbient, rememberSceneClock, propMotion/motionOrigin/motionPhase/motionAngle,
  pressable, lipBehind, VilaColors/VilaBrushes, MembershipTier.rank, StatsStore.today, Stats.activeStreak, LessonCatalog.nextUp/all/courses.
- Chữ ký khớp: LessonPuzzleScreen, LessonQuota.*, LessonStore.*, Lesson/Course. `ripple()` và `material-icons-extended` (LocalFireDepartment) đã có sẵn trong project.
- Ngoặc {} () [] cân bằng; không import trùng; không trùng tên khai báo với file khác trong package `ui`.
- Cần chạy: `./gradlew :app:compileDebugKotlin` rồi thử trên máy thật (cuộn mượt, bật nảy khi xong bài, khóa PRO, hết lượt).
