# v18b — Vùng Câu đố bị khoá (mây phủ) theo ảnh mẫu chess.com

## Quy tắc
- Vùng r bị khoá khi r > vùng của level đang chơi (chưa xong vùng trước thì chưa vào được vùng sau). Mỗi vùng = 496 câu.
- Ô thuộc vùng khoá không bấm được (NodeState.Locked sẵn có). Xong level cuối của vùng ⇒ `currentLevel` sang vùng kế ⇒ vùng đó hết khoá.

## Giao diện (file mới `PuzzleLockedZone.kt`)
- **Nền băng**: xám-lam + ô kim cương mờ + vệt sáng + hạt băng (`FrostGround`), thay nền chủ đề; vẫn mờ chéo ở ranh giới vùng. Không dựng vật cảnh trong vùng khoá.
- **Ô đóng băng**: xen kẽ sáng/tối theo số level như ô cờ (`frozenTop/frozenSide`), số trắng có bóng.
- **Mây** (`FogLayer`, phủ LÊN các ô, không nhận chạm): đám mây kem viền xanh ngọc vẽ bằng Canvas (3 mẫu, lật gương).
  Hai bên luôn có mây; giữa đường đi: 7 level đầu của vùng khoá còn thấy rõ, tới ~25 level thì mây kín (`fogCover`),
  kèm màn sương trắng-lam đậm dần (`fogHazeAlpha`, = 0 tại ranh giới ⇒ không có đường ranh).
- **Mở khoá**: vừa xong level cuối vùng, mây của vùng mới tan dần 1,4 s; nền + ô chuyển sang dạng mở ngay.
- **HUD**: dải tên vùng khoá hiện ổ khoá + "VÙNG n · ĐÃ KHOÁ · a-b" (giấu tên chủ đề), thanh trên/dưới đổi sang xám-lam;
  chip nổi "Xong VÙNG n (còn X câu) để mở khoá"; tắt hạt môi trường chủ đề khi đang xem vùng khoá.
- **Nút mũi tên** (góc phải, trên bảng điểm): hiện khi level hiện tại ra khỏi màn hình, mũi tên lên/xuống theo hướng; bấm ⇒ cuộn mượt về level hiện tại.

## Hiệu năng
- Mỗi khối 16 level là MỘT Canvas tĩnh, cuộn bằng graphicsLayer.translationY (như SceneryBlock); chỉ dựng ≤ 3 khối quanh vị trí cuộn.
- Mây trôi ngang ±5dp = translationX đọc từ đồng hồ chung trong graphicsLayer (không vẽ lại); TẮT trên máy yếu (DeviceTier.LOW).
- Vùng khoá không dựng vật cảnh ⇒ nhẹ hơn vùng thường.

## File đã sửa
- `PuzzleLockedZone.kt` (mới) · `PuzzleMapScreen.kt` (nối khoá vùng, nút mũi tên, chip, `frozen` cho WoodenNode) ·
  `PuzzleChapters.kt` (`RegionPill` có ổ khoá, `drawRegionFade` → internal).

## Test mới
- `PuzzleLockedZoneTest`: quy tắc khoá, số câu còn lại, mức mây/sương, bố cục mây xác định + hai bên luôn có mây + giữa kín dần.

## Lưu ý
- Bản này chưa build trong môi trường tạo (không có Android SDK/Maven); đã rà cú pháp bằng tay. Nếu Android Studio báo lỗi, gửi lại log để sửa.
