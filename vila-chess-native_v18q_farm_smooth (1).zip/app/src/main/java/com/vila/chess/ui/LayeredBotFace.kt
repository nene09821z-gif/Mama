package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import com.vila.chess.bots.BotLayerData
import com.vila.chess.bots.BotMotions
import com.vila.chess.bots.FaceKind
import kotlin.math.max
import kotlin.random.Random
import kotlinx.coroutines.delay

// =============================================================================
// Khuôn mặt bot NHIỀU LỚP (v18j) — chuyển động chi tiết hơn AnimatedAvatarFrame
//
// AnimatedAvatarFrame vẫn lo thở / nghiêng đầu / nhảy / rung / vòng sáng của CẢ avatar. Component này thêm chuyển động RIÊNG từng bộ phận
// (lớp vẽ sinh bởi tools/botfaces_layers.py):
//   • Mắt:  chớp (đôi khi chớp đôi), liếc quanh theo chu kỳ riêng từng bot, nhìn lên-trái khi đang nghĩ; híp mắt khi vui, trố mắt khi giật mình.
//   • Mày:  nhướn khi nghĩ; nhướn mạnh khi giật mình; hạ nhẹ khi vui.
//   • Miệng: há/ngậm theo nhịp khi bot đang nói (speaking), cười toe khi vui.
//   • Đầu:  các lớp thuộc đầu trượt nhẹ theo hướng nhìn (đầu "đi theo" ánh mắt) => có chiều sâu so với thân.
// Mọi giá trị chỉ được ĐỌC trong khối graphicsLayer nên không gây recomposition. Thông số lấy từ BotMotion (scripts/gen_bot_motion.py).
// =============================================================================

@Composable
internal fun LayeredBotFace(
    botId: String,
    size: Dp,
    modifier: Modifier = Modifier,
    /** Đang nghĩ (đến lượt bot): nhìn lên-trái + nhướn mày. */
    thinking: Boolean = false,
    /** Đang nói (có bong bóng thoại): miệng há/ngậm. */
    speaking: Boolean = false,
    reaction: AvatarReaction = AvatarReaction.NONE,
    reactionKey: Int = 0,
) {
    val face = BotLayerData.byId[botId] ?: return
    val m = BotMotions.forBot(botId)
    val density = androidx.compose.ui.platform.LocalDensity.current
    val sizePx = with(density) { size.toPx() }
    val k = sizePx / 48f                       // 1 ô lưới = k px
    val dpToPx = sizePx / 48f                  // BotMotion tính theo avatar 48dp

    val blink = remember { Animatable(0f) }    // 0 mở … 1 nhắm
    val lookX = remember { Animatable(0f) }
    val lookY = remember { Animatable(0f) }
    val think = remember { Animatable(0f) }    // 0..1
    val mouth = remember { Animatable(0f) }    // 0 ngậm … 1 há
    val emo = remember { Animatable(0f) }      // cường độ phản ứng 0..1
    val emoKind by rememberUpdatedState(reaction)
    val thinkingNow by rememberUpdatedState(thinking)

    // Chớp mắt: khoảng cách ngẫu nhiên ±25 %, 25 % lần chớp đôi
    LaunchedEffect(botId) {
        val rnd = Random(botId.hashCode())
        delay((400 + rnd.nextInt(900)).toLong())
        while (true) {
            val one: suspend () -> Unit = {
                blink.animateTo(1f, tween((m.blinkMs * 0.4f).toInt(), easing = LinearEasing))
                blink.animateTo(0f, tween((m.blinkMs * 0.6f).toInt(), easing = LinearEasing))
            }
            one()
            if (rnd.nextFloat() < 0.25f) { delay(90); one() }
            delay((m.blinkEveryMs * (0.75f + 0.5f * rnd.nextFloat())).toLong())
        }
    }
    // Liếc quanh (không liếc khi đang nghĩ: lúc đó nhìn lên-trái)
    LaunchedEffect(botId) {
        val rnd = Random(botId.hashCode() * 31 + 7)
        val dirs = arrayOf(1f to 0f, -1f to 0f, -0.8f to -0.6f, 0.7f to 0.5f, 1f to -0.4f, -1f to 0.3f)
        delay((500 + rnd.nextInt(800)).toLong())
        while (true) {
            if (!thinkingNow) {
                val (dx, dy) = dirs[rnd.nextInt(dirs.size)]
                lookX.animateTo(dx, tween(180, easing = FastOutSlowInEasing))
                lookY.animateTo(dy, tween(180, easing = FastOutSlowInEasing))
                delay(550)
                lookX.animateTo(0f, tween(280, easing = FastOutSlowInEasing))
                lookY.animateTo(0f, tween(280, easing = FastOutSlowInEasing))
            }
            delay((m.lookEveryMs * (0.8f + 0.4f * rnd.nextFloat())).toLong())
        }
    }
    LaunchedEffect(thinking) {
        if (thinking) {
            think.animateTo(1f, tween(250))
            lookX.animateTo(-0.7f, tween(200)); lookY.animateTo(-0.8f, tween(200))
        } else {
            think.animateTo(0f, tween(300))
            lookX.animateTo(0f, tween(280)); lookY.animateTo(0f, tween(280))
        }
    }
    // Nói: mỗi âm tiết biên độ khác nhau
    LaunchedEffect(speaking) {
        if (speaking) {
            val rnd = Random(System.nanoTime())
            while (true) {
                mouth.animateTo(0.6f + 0.4f * rnd.nextFloat(), tween(m.talkMs, easing = FastOutSlowInEasing))
                mouth.animateTo(0f, tween(m.talkMs, easing = FastOutSlowInEasing))
            }
        } else mouth.animateTo(0f, tween(120))
    }
    // Phản ứng (cùng reactionKey với AnimatedAvatarFrame)
    LaunchedEffect(reactionKey) {
        if (reactionKey > 0 && emoKind != AvatarReaction.NONE) {
            emo.snapTo(0f)
            emo.animateTo(1f, tween(120))
            delay(if (emoKind == AvatarReaction.HAPPY) 380 else 300)
            emo.animateTo(0f, tween(180))
        }
    }

    Box(modifier.size(size)) {
        for (layer in face.layers) {
            val kind = layer.kind
            Image(
                painter = painterResource(layer.res),
                contentDescription = null,
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    val e = emo.value
                    val happy = emoKind == AvatarReaction.HAPPY
                    val shock = emoKind == AvatarReaction.SHAKE
                    when (kind) {
                        FaceKind.EYES -> {
                            val sy = (1f - 0.92f * blink.value) * (1f - (if (happy) 0.6f else 0f) * e) * (1f + (if (shock) 0.12f else 0f) * e)
                            transformOrigin = TransformOrigin(0.5f, face.eyeCy / 48f)
                            scaleY = max(sy, 0.04f)
                            translationX = lookX.value * m.lookDp * dpToPx
                            translationY = lookY.value * m.lookDp * dpToPx * 0.7f
                        }
                        FaceKind.BROWS -> {
                            val lift = m.browLiftDp * dpToPx
                            translationY = -lift * think.value - lift * 0.5f * (if (happy) e else 0f) - lift * 1.3f * (if (shock) e else 0f)
                            translationX = lookX.value * m.lookDp * dpToPx * 0.35f
                        }
                        FaceKind.MOUTH -> {
                            val sy = 1f + (m.mouthOpen - 1f) * mouth.value + 0.25f * (if (happy) e else 0f) + 0.2f * (if (shock) e else 0f)
                            transformOrigin = TransformOrigin(0.5f, face.mouthCy / 48f)
                            scaleY = sy
                            scaleX = 1f + 0.18f * (if (happy) e else 0f) - 0.12f * (if (shock) e else 0f)
                            translationX = lookX.value * m.lookDp * dpToPx * 0.35f
                        }
                        FaceKind.REAR, FaceKind.HEAD, FaceKind.FRONT -> {
                            translationX = lookX.value * m.lookDp * dpToPx * 0.35f   // đầu đi theo ánh mắt
                            translationY = lookY.value * m.lookDp * dpToPx * 0.2f
                        }
                        else -> Unit                                                  // BG, BODY: đứng yên (AnimatedAvatarFrame lo phần thở)
                    }
                },
            )
        }
    }
}
