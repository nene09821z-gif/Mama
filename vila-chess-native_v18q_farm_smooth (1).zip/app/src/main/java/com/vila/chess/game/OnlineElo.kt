package com.vila.chess.game

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Công thức Elo cho ván ONLINE (người với người). Logic THUẦN, không phụ thuộc Android nên test được bằng JUnit thường.
 *
 * Nguyên tắc công bằng:
 *  1. Xác suất thắng kỳ vọng theo Elo chuẩn, chênh lệch bị chặn ở ±[DIFF_CAP] (luật 400 của FIDE): đánh với người quá yếu
 *     không "cày" được nhiều điểm, thua người quá mạnh không bị trừ vô lý.
 *  2. Hệ số K theo SỐ VÁN ONLINE đã chơi ở thể loại đó và theo Elo. Người mới (< [PROVISIONAL_GAMES] ván) có K rất cao
 *     rồi giảm dần, giống chess.com: vài ván đầu thắng liên tiếp có thể tăng vài trăm Elo (thua cũng giảm nhanh) để hạng
 *     chạm đúng trình độ thật sau ít ván. Người đã ổn định K thấp để hạng không dao động; Elo càng cao K càng thấp.
 *  3. Đấu lặp lại cùng một đối thủ trong 24 giờ bị giảm điểm (cả cộng lẫn trừ, nên hai bên vẫn đối xứng) để chống
 *     "cày điểm" hoặc đổi điểm qua lại giữa hai tài khoản.
 *  4. Thắng luôn được ít nhất +1 trước khi nhân đặc quyền. Hòa/thua tính theo kỳ vọng.
 *  5. Đặc quyền (x2) chỉ nhân điểm CỘNG, không nhân điểm TRỪ.
 */
object OnlineElo {
    const val DIFF_CAP = 400
    const val PROVISIONAL_GAMES = 20
    const val MIN_RATING = 100
    const val REPEAT_WINDOW_MS = 24L * 3600L * 1000L
    private const val HISTORY_MAX = 60

    /**
     * Hệ số K. Giai đoạn người mới (theo số ván online ở thể loại đó): ván 1–5 = 160, ván 6–10 = 100, ván 11–20 = 60.
     * Sau đó Elo < 1800: 24; 1800–2399: 16; từ 2400: 10.
     * (Ví dụ: 5 ván đầu thắng hết với đối thủ ~800 → khoảng +265 Elo.)
     */
    fun kFactor(rating: Int, onlineGames: Int): Int = when {
        onlineGames < 5 -> 160
        onlineGames < 10 -> 100
        onlineGames < PROVISIONAL_GAMES -> 60
        rating < 1800 -> 24
        rating < 2400 -> 16
        else -> 10
    }

    /** Xác suất kỳ vọng (0..1) của mình trước đối thủ, chênh lệch chặn ±[DIFF_CAP]. */
    fun expected(rating: Int, oppRating: Int): Double {
        val diff = (oppRating - rating).coerceIn(-DIFF_CAP, DIFF_CAP)
        return 1.0 / (1.0 + 10.0.pow(diff / 400.0))
    }

    /**
     * Hệ số giảm điểm theo số ván ĐÃ đấu với cùng đối thủ trong 24 giờ qua ([previousGames], chưa tính ván này):
     * ván 1–3 đủ điểm, 4–6 còn một nửa, từ ván 7 còn 1/4.
     */
    fun repeatFactor(previousGames: Int): Double = when {
        previousGames < 3 -> 1.0
        previousGames < 6 -> 0.5
        else -> 0.25
    }

    /**
     * Elo thay đổi sau ván. [score] = 1 / 0.5 / 0. [gainMultiplier] (x2 đặc quyền) chỉ nhân điểm cộng.
     * Kết quả đã làm tròn; việc chặn sàn [MIN_RATING] do nơi áp vào Elo xử lý.
     */
    fun delta(
        rating: Int,
        oppRating: Int,
        score: Double,
        onlineGames: Int,
        previousGamesVsOpponent: Int = 0,
        gainMultiplier: Int = 1,
    ): Int {
        val k = kFactor(rating, onlineGames)
        val raw = k * (score - expected(rating, oppRating)) * repeatFactor(previousGamesVsOpponent)
        var base = raw.roundToInt()
        if (score == 1.0 && base < 1) base = 1
        return if (base > 0) base * gainMultiplier.coerceAtLeast(1) else base
    }

    /** Điểm dự kiến cho từng kết quả: dùng hiện trên hộp xác nhận (thoát / đầu hàng = [loss]). */
    data class Preview(val win: Int, val draw: Int, val loss: Int)

    fun preview(
        rating: Int,
        oppRating: Int,
        onlineGames: Int,
        previousGamesVsOpponent: Int = 0,
        gainMultiplier: Int = 1,
    ): Preview = Preview(
        win = delta(rating, oppRating, 1.0, onlineGames, previousGamesVsOpponent, gainMultiplier),
        draw = delta(rating, oppRating, 0.5, onlineGames, previousGamesVsOpponent, gainMultiplier),
        loss = delta(rating, oppRating, 0.0, onlineGames, previousGamesVsOpponent, gainMultiplier),
    )

    // ------------------------------------------------------------------ Lịch sử đối thủ gần đây (để tính repeatFactor)

    data class Entry(val oppId: String, val ts: Long)

    /** Chuỗi lưu "id|ts;id|ts". Bỏ dòng hỏng và dòng quá 24 giờ. */
    fun parseHistory(raw: String?, now: Long): List<Entry> {
        if (raw.isNullOrBlank()) return emptyList()
        val out = ArrayList<Entry>()
        for (part in raw.split(';')) {
            val i = part.lastIndexOf('|')
            if (i <= 0) continue
            val ts = part.substring(i + 1).toLongOrNull() ?: continue
            if (abs(now - ts) <= REPEAT_WINDOW_MS) out.add(Entry(part.substring(0, i), ts))
        }
        return out
    }

    fun serializeHistory(list: List<Entry>): String = list.takeLast(HISTORY_MAX).joinToString(";") { it.oppId + "|" + it.ts }

    fun previousGames(history: List<Entry>, oppId: String): Int =
        if (oppId.isBlank()) 0 else history.count { it.oppId.equals(oppId, ignoreCase = true) }

    fun withGame(history: List<Entry>, oppId: String, now: Long): List<Entry> =
        if (oppId.isBlank()) history else history + Entry(oppId, now)
}
