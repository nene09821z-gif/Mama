package com.vila.chess.game

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import com.vila.chess.R

enum class Sfx { MOVE, CAPTURE, CASTLE, CHECK, PROMOTE, END }

class SoundPlayer(private val context: Context, pack: String = SoundPacks.DEFAULT) {
    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()
    private var ids = HashMap<Sfx, Int>()

    var enabled: Boolean = true

    var pack: String = SoundPacks.DEFAULT
        private set

    init {
        loadPack(if (SoundPacks.exists(pack)) pack else SoundPacks.DEFAULT)
    }

    private fun loadPack(id: String) {
        val fresh = HashMap<Sfx, Int>()
        for (sfx in Sfx.values()) {
            val res = SoundPacks.rawRes(context, id, sfx)
            if (res != 0) fresh[sfx] = pool.load(context, res, 1)
        }
        ids = fresh
        pack = id
    }

    /** Đổi bộ âm thanh (nạp bộ mới, bỏ bộ cũ). Tiếng nạp bất đồng bộ nên phát thử nên chờ ~100ms. */
    fun setPack(id: String) {
        if (id == pack || !SoundPacks.exists(id)) return
        val old = ids
        loadPack(id)
        for (v in old.values) pool.unload(v)
    }

    fun play(sfx: Sfx) {
        if (!enabled) return
        val id = ids[sfx] ?: return
        pool.play(id, 1f, 1f, 1, 0, 1f)
    }

    /** Nạp thêm 1 file ngoài 6 tiếng của bộ (vd tiếng sai nước của câu đố); trả về id để [playExtra]. */
    fun loadExtra(resId: Int): Int = pool.load(context, resId, 1)

    fun playExtra(id: Int, volume: Float = 1f) {
        if (!enabled || id == 0) return
        pool.play(id, volume, volume, 1, 0, 1f)
    }

    fun release() {
        pool.release()
    }
}

/**
 * Âm thanh cho bàn cờ NGOÀI ván đấu (Câu đố, Bài học chiến thuật): dùng chung một SoundPlayer toàn app,
 * mỗi lần phát đều đọc lại công tắc "Âm thanh" và "Bộ âm thanh" trong vila_native nên đổi ở Chủ đề/Tùy chỉnh là có hiệu lực ngay.
 */
object PuzzleSfx {
    private var player: SoundPlayer? = null
    private var wrongId = 0

    @Synchronized
    private fun ready(context: Context): SoundPlayer {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences("vila_native", Context.MODE_PRIVATE)
        val pack = prefs.getString("soundPack", SoundPacks.DEFAULT)?.takeIf { SoundPacks.exists(it) } ?: SoundPacks.DEFAULT
        val p = player ?: SoundPlayer(app, pack).also {
            player = it
            wrongId = it.loadExtra(R.raw.puzzle_wrong)
        }
        p.setPack(pack)
        p.enabled = prefs.getBoolean("sound", true)
        return p
    }

    /** Tiếng đi quân / ăn / nhập thành / chiếu / phong cấp / hết (giống ván đấu). */
    fun play(context: Context, sfx: Sfx) {
        try { ready(context).play(sfx) } catch (_: Throwable) { /* âm thanh chỉ là phần thêm, không được làm sập màn chơi */ }
    }

    /** Tiếng "bùm bùm" trầm khi đi sai nước. */
    fun playWrong(context: Context) {
        try {
            val p = ready(context)
            p.playExtra(wrongId, 0.8f)
        } catch (_: Throwable) { }
    }
}

class Haptics(context: Context) {
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    var enabled: Boolean = true

    fun tick(strong: Boolean) {
        if (!enabled) return
        val v = vibrator ?: return
        try {
            val ms = if (strong) 22L else 10L
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms, if (strong) 160 else 80))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (e: Exception) {
            // vibration is best-effort only
        }
    }
}
