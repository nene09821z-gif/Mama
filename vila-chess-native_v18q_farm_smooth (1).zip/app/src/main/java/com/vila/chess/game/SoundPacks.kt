package com.vila.chess.game

import android.content.Context

data class SoundPackInfo(val id: String, val label: String, val desc: String)

/**
 * Các bộ âm thanh. "classic" = move/capture/castle/check/promote/gameend có sẵn; các bộ khác = res/raw/<id>_<tiếng>.wav
 * (tạo bằng scripts/gen_sounds.py và scripts/gen_sounds_chill.py). Tìm file bằng tên (getIdentifier) nên thêm bộ mới chỉ cần thêm file + 1 dòng ở [all].
 */
object SoundPacks {
    const val DEFAULT = "classic"

    val all: List<SoundPackInfo> = listOf(
        SoundPackInfo("classic", "Cổ điển", "Tiếng cờ gỗ quen thuộc"),
        SoundPackInfo("wood", "Gỗ", "Cộc cộc ấm, như quân cờ thật trên bàn gỗ"),
        SoundPackInfo("glass", "Pha lê", "Chuông thủy tinh trong trẻo"),
        SoundPackInfo("piano", "Piano mềm", "Nốt piano nhẹ nhàng, dễ chịu"),
        SoundPackInfo("arcade", "Arcade 8-bit", "Bíp bíp máy chơi game đời đầu"),
        SoundPackInfo("drum", "Trống", "Trống, snare và tom mạnh mẽ"),
        SoundPackInfo("water", "Giọt nước", "Tiếng bong bóng nước vui tai"),
        SoundPackInfo("marble", "Cẩm thạch", "Đá lạnh trong trẻo, rõ mà không chói"),
        SoundPackInfo("nature", "Thiên nhiên", "Gõ gỗ, lá xào xạc, chim hót, gió nhẹ"),
        SoundPackInfo("space", "Vũ trụ", "Ping mềm vang vọng giữa các vì sao"),
        SoundPackInfo("musicbox", "Hộp nhạc", "Nốt lanh canh, bài ru khi hết ván"),
        SoundPackInfo("zen", "Tre & chuông gió", "Gõ tre khẽ, chuông gió ngân dài"),
        // 5 bộ nhạc cụ thật (mẫu CC0 của VCSL) — file wav được dựng lúc build bằng scripts/get_sounds_vcsl.py (xem main.yml)
        SoundPackInfo("vibes", "Vibraphone", "Nốt rung mềm, ngân mơ màng"),
        SoundPackInfo("harp", "Đàn hạc", "Nốt gảy ấm, dịu như bài ru"),
        SoundPackInfo("glock", "Sao đêm", "Chuông glockenspiel lấp lánh"),
        SoundPackInfo("marimba", "Marimba", "Gỗ ấm, tròn, êm như mưa nhẹ"),
        SoundPackInfo("ocarina", "Sáo ocarina", "Hơi thở nhẹ, mộc mạc, thư thái"),
    )

    /**
     * Các bộ KHÔNG nằm sẵn trong zip: file res/raw/<bộ>_<tiếng>.wav do bước "Tải mẫu nhạc cụ CC0" trong main.yml tạo ra.
     * Nếu bước đó lỗi (mất mạng...) thì bộ thiếu file bị ẩn khỏi tab Âm thanh thay vì chọn xong lại nghe tiếng Cổ điển.
     */
    val downloaded: Set<String> = setOf("vibes", "harp", "glock", "marimba", "ocarina")

    fun exists(id: String): Boolean = all.any { it.id == id }

    /** Bộ có đủ 6 file trong APK? Bộ có sẵn trong zip luôn true; bộ trong [downloaded] cần đủ cả 6 tiếng. */
    fun isInstalled(context: Context, id: String): Boolean =
        id !in downloaded || Sfx.values().all {
            context.resources.getIdentifier(rawName(id, it), "raw", context.packageName) != 0
        }

    /** Danh sách hiện trong Chủ đề > Âm thanh. */
    fun installed(context: Context): List<SoundPackInfo> = all.filter { isInstalled(context, it.id) }

    /** Tên file (không đuôi) trong res/raw. */
    fun rawName(pack: String, sfx: Sfx): String {
        if (pack == DEFAULT) {
            return when (sfx) {
                Sfx.MOVE -> "move"
                Sfx.CAPTURE -> "capture"
                Sfx.CASTLE -> "castle"
                Sfx.CHECK -> "check"
                Sfx.PROMOTE -> "promote"
                Sfx.END -> "gameend"
            }
        }
        return pack + "_" + sfx.name.lowercase()
    }

    /** id tài nguyên raw của tiếng [sfx] trong bộ [pack]; thiếu file thì rơi về bộ Cổ điển. 0 nếu cả hai đều thiếu. */
    fun rawRes(context: Context, pack: String, sfx: Sfx): Int {
        val res = context.resources
        val id = res.getIdentifier(rawName(pack, sfx), "raw", context.packageName)
        if (id != 0 || pack == DEFAULT) return id
        return res.getIdentifier(rawName(DEFAULT, sfx), "raw", context.packageName)
    }
}
