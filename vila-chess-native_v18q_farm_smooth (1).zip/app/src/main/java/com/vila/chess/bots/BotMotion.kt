package com.vila.chess.bots

import androidx.compose.ui.graphics.Color

/**
 * Thông số chuyển động của avatar một bot. Giá trị cụ thể của từng bot nằm trong [BotMotionData]
 * (file này được SINH TỰ ĐỘNG bởi scripts/gen_bot_motion.py trong GitHub Actions — đừng sửa tay).
 */
data class BotMotion(
    val breathMs: Int,        // chu kỳ thở
    val breathScale: Float,   // độ phồng khi thở (0.03 = 3%)
    val bobDp: Float,         // độ nhấp nhô khi thở
    val swayDeg: Float,       // góc nghiêng đầu khi đến lượt
    val swayMs: Int,          // chu kỳ nghiêng
    val glowMs: Int,          // chu kỳ nhấp nháy vòng sáng
    val hopDp: Float,         // độ nhảy khi vui (ăn quân / thắng)
    val hopScale: Float,      // độ phồng khi vui
    val shakeDp: Float,       // biên độ rung khi bị chiếu / thua
    val ringColor: Color,     // màu vòng sáng
    // ── v18j: animation chi tiết theo lớp (xem ui/LayeredBotFace.kt) ──
    val blinkEveryMs: Int = 3200,   // khoảng cách trung bình giữa hai lần chớp
    val blinkMs: Int = 140,         // một lần chớp (nhắm + mở)
    val lookDp: Float = 1.2f,       // biên độ liếc mắt (dp, avatar 48dp)
    val lookEveryMs: Int = 2800,    // khoảng cách giữa hai lần liếc
    val browLiftDp: Float = 1.2f,   // nhướn mày khi nghĩ
    val talkMs: Int = 190,          // nửa chu kỳ há/ngậm miệng khi nói
    val mouthOpen: Float = 1.4f,    // scaleY miệng lúc há tối đa
) {
    companion object {
        /** Bằng đúng giá trị cũ của AnimatedAvatarFrame: dùng cho người chơi và bot chưa có số liệu. */
        val DEFAULT = BotMotion(2300, 0.03f, 1.2f, 3f, 1100, 900, 7f, 0.12f, 3.5f, Color(0xFF81B64C))
    }
}

object BotMotions {
    fun forBot(id: String?): BotMotion = id?.let { BotMotionData.byId[it] } ?: BotMotion.DEFAULT

    /** Tìm theo avatar (ảnh bot) vì các màn hình chỉ giữ avatarRes. */
    fun forAvatarRes(res: Int?): BotMotion =
        if (res == null) BotMotion.DEFAULT
        else forBot(BotRepository.bots.firstOrNull { it.avatarResId == res }?.id)
}
