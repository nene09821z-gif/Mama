package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.rememberTier
import com.vila.chess.game.Course
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Lesson
import com.vila.chess.game.LessonCatalog
import com.vila.chess.game.LessonKind
import com.vila.chess.game.LessonProgress
import com.vila.chess.game.LessonQuota
import com.vila.chess.game.LessonStore
import com.vila.chess.game.StatsStore
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ════════════════════════════════════════════════════════════════════════════════════════════
//  TRANG BÀI HỌC – BẢN ĐỒ KHÓA HỌC (cùng ngôn ngữ thiết kế với bản đồ Câu đố)
//
//  Giống trang Câu đố:  ô khối isometric (drawSlab) · nền + hạt môi trường theo chủ đề · linh vật đội mũ theo chủ đề ·
//                       vật cảnh 2.5D hai bên đường · HUD trên/dưới chuyển sắc theo chủ đề đang xem · nút 3D xanh.
//  Khác (đúng chất bài học):
//    • Mỗi KHÓA HỌC là một chặng riêng: tấm biển khóa (tên, cấp độ, vòng % tiến độ, ổ khóa + PRO nếu là khóa nâng cao),
//      nền/vật cảnh/hạt đổi theo chặng (Rừng → Giáng sinh → Sa mạc → Không gian → Biển, lặp vòng).
//    • Đường đi chữ S TỪ TRÊN XUỐNG (bài đầu ở trên) và mỗi ô có NHÃN tên bài + loại bài + số phút.
//    • 4 trạng thái ô: Đã xong (màu chặng + dấu tích) · Bài tiếp theo (vàng + linh vật nhún) · Chưa học (màu khóa) · Khóa PRO (xám + ổ khóa).
//    • Học xong một bài: ô bật nảy + vòng sóng sáng, rồi hộp thoại bài kế tiếp mới hiện ra.
//    • Bảng dưới: số bài đã học, lượt miễn phí còn lại (đếm ngược khi hết), chuỗi ngày, thanh tiến độ,
//      thẻ bàn cờ của bài tiếp theo + nút "Học tiếp"; nút nổi "Bài tiếp theo" khi đã cuộn đi xa.
//
//  Hiệu năng (cùng quy tắc với bản đồ Câu đố):
//    - Mọi hàng cao CỐ ĐỊNH (px nguyên) và là một graphicsLayer riêng ⇒ cuộn là GPU dịch lớp, không vẽ lại.
//    - Nền kim cương vẽ theo TOẠ ĐỘ TUYỆT ĐỐI trong danh sách ⇒ các hàng liền nhau khớp mép, không có đường ranh.
//    - Vật cảnh tạo ở từng hàng (chỉ hàng đang hiện); chuyển động nhẹ đọc đồng hồ chung trong graphicsLayer.
//    - Không có animation chạy nền ngoài: nhịp thở ô hiện tại + đồng hồ cảnh (dùng chung với bản đồ Câu đố).
//    - Tiến độ lưu vài trăm byte (SharedPreferences), không dùng cơ sở dữ liệu.
// ════════════════════════════════════════════════════════════════════════════════════════════

private val MiniLight = Color(0xFFEBECD0)
private val MiniDark = Color(0xFF739552)
private val DetailBg = Color(0xFF16233B)
private val WarnRed = Color(0xFFE5675A)
private val GoldBrush = Brush.horizontalGradient(listOf(Color(0xFFF7D26A), Color(0xFFE5A83B)))
private val GoldText = Color(0xFF3A2A06)

private val LsMaxTrack = 520.dp          // máy tính bảng: đường đi không giãn quá 520dp
private val LsTitleH = 52.dp
private val LsPillH = 26.dp
private val LsPanelH = 168.dp            // chiều cao nội dung bảng dưới (chưa tính thanh điều hướng)
private val LsGapTop = 22.dp             // khoảng trên ô: chừa chỗ cho linh vật đứng trên ô và nét nối
private val LsLabelGap = 4.dp
private val LsLabelH = 54.dp
private val LsGapBottom = 10.dp
private const val LsFaceShift = 0.11f    // tâm MẶT TRÊN ô lệch lên 11% chiều cao (giống bản đồ Câu đố)

private enum class LsState { Done, Current, Open, Locked }

/** Đường chữ S: giữa → phải → giữa → trái. Mỗi khóa bắt đầu ở giữa, ngay dưới tấm biển khóa. */
private fun lsXFrac(i: Int): Float = when (Math.floorMod(i, 4)) {
    0 -> 0.5f
    1 -> 0.74f
    2 -> 0.5f
    else -> 0.26f
}

// ─────────────────────────────────────────────────────────────────────────── Dữ liệu hàng

private sealed class LsRow(val key: String, val kind: String, val courseIdx: Int) {
    class Header(courseIdx: Int, val course: Course) : LsRow("h_" + course.id, "header", courseIdx)
    class Item(courseIdx: Int, val course: Course, val lesson: Lesson, val idx: Int, val global: Int) :
        LsRow("l_" + lesson.id, "lesson", courseIdx)
    class Footer(courseIdx: Int) : LsRow("footer", "footer", courseIdx)
}

/** Toàn bộ hàng của bản đồ theo thứ tự hiển thị: [biển khóa, bài, bài, …] × số khóa, rồi chân trang. Dựng một lần. */
private val LsRows: List<LsRow> by lazy(LazyThreadSafetyMode.NONE) {
    val out = ArrayList<LsRow>()
    var g = 0
    LessonCatalog.courses.forEachIndexed { ci, c ->
        out.add(LsRow.Header(ci, c))
        c.lessons.forEachIndexed { i, l ->
            out.add(LsRow.Item(ci, c, l, i, g))
            g++
        }
    }
    out.add(LsRow.Footer((LessonCatalog.courses.size - 1).coerceAtLeast(0)))
    out
}

/** id bài → chỉ số hàng trong [LsRows]: ngựa tìm ô theo id mà không phải duyệt danh sách mỗi khung hình. */
private val LsItemIndex: Map<String, Int> by lazy(LazyThreadSafetyMode.NONE) {
    val out = HashMap<String, Int>()
    LsRows.forEachIndexed { i, r -> if (r is LsRow.Item) out[r.lesson.id] = i }
    out
}

/** Mọi số đo phụ thuộc kích thước màn hình – tính một lần cho mỗi (maxWidth, density). Chiều cao hàng làm tròn px nguyên. */
@Immutable
private class LsMetrics(screenW: Dp, density: Density) {
    val trackW: Dp = minOf(screenW, LsMaxTrack)
    val nodeW: Dp = (trackW * 0.235f).coerceIn(68.dp, 118.dp)
    val nodeH: Dp = nodeW * SLAB_ASPECT
    val rowPx: Int = with(density) { (nodeH + LsGapTop + LsLabelGap + LsLabelH + LsGapBottom).toPx().roundToInt() }
    val headPx: Int = with(density) { 184.dp.toPx().roundToInt() }
    val footPx: Int = with(density) { 214.dp.toPx().roundToInt() }
    val rowH: Dp = with(density) { rowPx.toDp() }
    val headH: Dp = with(density) { headPx.toDp() }
    val footH: Dp = with(density) { footPx.toDp() }
}

// ─────────────────────────────────────────────────────────────────────────── Nền theo chặng

@Immutable
private class LsGround(val base: Color, val diamond: Color, val deco: ChapterDeco?)

private val LsGrounds: List<LsGround> = List(5) { i ->
    val g = mapChapterFor(i).ground
    if (g == null) LsGround(Color(0xFF2F7344), Color(0x1CFFFFFF), null)
    else LsGround(lerp(g.top, g.bottom, 0.5f), g.checker, g.deco)
}

private fun lsGround(ci: Int): LsGround = LsGrounds[Math.floorMod(ci, 5)]

/**
 * Vẽ nền của MỘT hàng. [topPx] = vị trí đỉnh hàng trong danh sách (px, tuyệt đối) nên hoa văn kim cương
 * liền mạch giữa các hàng; hạt trang trí lấy theo [seed] của hàng ⇒ ổn định, không nhấp nháy.
 */
private fun DrawScope.drawLsGround(g: LsGround, topPx: Int, seed: Int) {
    drawRect(g.base)
    val w = 95.dp.toPx()
    val h = 48.dp.toPx()
    val path = Path()
    val r0 = kotlin.math.floor(topPx / h).toInt() - 1
    val r1 = ceil((topPx + size.height) / h).toInt() + 1
    for (r in r0..r1) {
        val y = r * h - topPx
        var x = if (Math.floorMod(r, 2) == 0) 0f else w
        while (x < size.width + w) {
            path.reset()
            path.moveTo(x, y - h)
            path.lineTo(x + w, y)
            path.lineTo(x, y + h)
            path.lineTo(x - w, y)
            path.close()
            drawPath(path, g.diamond)
            x += 2 * w
        }
    }

    val rnd = Random(seed)
    val ww = size.width
    val hh = size.height
    fun glow(color: Color, maxR: Float) {
        val rad = minOf(maxR, hh * 0.46f)
        val cx = rnd.nextFloat() * ww
        val cy = rad + rnd.nextFloat() * (hh - 2 * rad).coerceAtLeast(0f)
        drawCircle(Brush.radialGradient(listOf(color, Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
    }
    when (g.deco) {
        null -> {
            glow(Color(0x22C8FF9E), 80.dp.toPx())
            repeat(7) {
                val rad = (1.5f + rnd.nextFloat() * 2.5f).dp.toPx()
                drawCircle(Color(0x2A0A2E14), rad, Offset(rnd.nextFloat() * ww, rnd.nextFloat() * hh))
            }
        }
        ChapterDeco.Snow -> {
            glow(Color(0x40EAF6FF), 70.dp.toPx())
            repeat(8) {
                val rad = (1f + rnd.nextFloat() * 2.2f).dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.25f + rnd.nextFloat() * 0.6f), rad, Offset(rnd.nextFloat() * ww, rnd.nextFloat() * hh))
            }
        }
        ChapterDeco.Dunes -> {
            glow(if (rnd.nextBoolean()) Color(0x33FFE2A8) else Color(0x2E7A4416), 70.dp.toPx())
            repeat(2) {
                val len = (30 + rnd.nextInt(50)).dp.toPx()
                val cx = rnd.nextFloat() * ww
                val cy = rnd.nextFloat() * hh
                drawArc(Color(0x30FFF1D0), 200f, 140f, false, Offset(cx - len / 2f, cy), Size(len, len * 0.3f), style = Stroke(width = 2.dp.toPx()))
            }
            repeat(4) {
                val rad = (1f + rnd.nextFloat() * 2f).dp.toPx()
                drawCircle(Color(0x405A3010), rad, Offset(rnd.nextFloat() * ww, rnd.nextFloat() * hh))
            }
        }
        ChapterDeco.Stars -> {
            glow(if (rnd.nextBoolean()) Color(0x338A4FFF) else Color(0x2E2FA8FF), 90.dp.toPx())
            repeat(18) {
                val rad = (0.6f + rnd.nextFloat() * 1.8f).dp.toPx()
                val warm = rnd.nextInt(5) == 0
                drawCircle((if (warm) Color(0xFFFFE9A8) else Color.White).copy(alpha = 0.3f + rnd.nextFloat() * 0.7f), rad, Offset(rnd.nextFloat() * ww, rnd.nextFloat() * hh))
            }
        }
        ChapterDeco.Fields -> {}   // chỉ dùng ở bản đồ Câu đố (Nông trại)
        ChapterDeco.Bubbles -> {
            glow(Color(0x3340D8FF), 80.dp.toPx())
            repeat(6) {
                val rad = (2f + rnd.nextFloat() * 8f).dp.toPx()
                val c0 = Offset(rnd.nextFloat() * ww, rnd.nextFloat() * hh)
                drawCircle(Color.White.copy(alpha = 0.10f + rnd.nextFloat() * 0.15f), rad, c0)
                drawCircle(Color.White.copy(alpha = 0.35f), rad, c0, style = Stroke(width = 1.dp.toPx()))
            }
        }
    }
}

/** Nét chấm nối hai ô liền nhau; đoạn đã đi qua màu vàng, chưa đi màu trắng mờ. Hai nửa ở ranh hàng cùng tiếp tuyến dọc ⇒ nối mượt. */
private fun DrawScope.drawLsDots(x0: Float, y0: Float, x1: Float, y1: Float, walked: Boolean) {
    val path = Path()
    path.moveTo(x0, y0)
    val dy = (y1 - y0) * 0.5f
    path.cubicTo(x0, y0 + dy, x1, y1 - dy, x1, y1)
    val dot = (if (walked) 5.5f else 4.2f).dp.toPx()
    drawPath(
        path,
        color = if (walked) Color(0xFFFFE08A) else Color(0x55FFFFFF),
        style = Stroke(width = dot, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.1f, dot * 2.1f), 0f)),
    )
}

// ─────────────────────────────────────────────────────────────────────────── Vật cảnh theo chặng

private val LsDecorPools: List<List<PropKind>> = listOf(
    listOf(
        PropKind.KfTree, PropKind.KfTreeHigh, PropKind.KfStones, PropKind.KfPlant, PropKind.KfRocksLow,
        PropKind.KfTent, PropKind.KfFlag, PropKind.KfPatchGrass, PropKind.KaTree, PropKind.KfFence,
    ),
    listOf(
        PropKind.HolTreeA, PropKind.HolTreeB, PropKind.HolTreeC, PropKind.HolTreeDeco, PropKind.HolSnowman,
        PropKind.HolSnowmanHat, PropKind.HolPresentA, PropKind.HolPresentB, PropKind.HolLantern, PropKind.HolCandy,
        PropKind.HolSled, PropKind.HolReindeer, PropKind.HolGingerbread, PropKind.HolNutcracker, PropKind.HolSnowPile,
    ),
    listOf(PropKind.DesCactus, PropKind.DesCactus2, PropKind.DesLavarock, PropKind.DesMesa, PropKind.DesVolcano),
    listOf(PropKind.SpcPlanet, PropKind.SpcPlanet2, PropKind.SpcAsteroid, PropKind.SpcCrystal, PropKind.SpcRocket),
    listOf(PropKind.SeaCoral, PropKind.SeaCoral2, PropKind.SeaSeaweed, PropKind.SeaShell, PropKind.SeaJelly),
)

/** Lật gương + chuyển động nhẹ của vật cảnh: MỘT graphicsLayer đọc đồng hồ chung trong lambda ⇒ không recomposition. */
private fun lsPropMotion(kind: PropKind, mirror: Boolean, px: Float, py: Float, clock: State<Float>): Modifier {
    val motion = propMotion(kind)
    if (motion == null) return if (mirror) Modifier.graphicsLayer { scaleX = -1f } else Modifier
    val phase = motionPhase(px, py)
    val origin = motionOrigin(motion)
    return Modifier.graphicsLayer {
        val a = motionAngle(motion, clock.value, phase)
        transformOrigin = origin
        if (mirror) scaleX = -1f
        rotationZ = kotlin.math.sin(a) * motion.deg
        translationY = kotlin.math.cos(a) * motion.bobDp * density
    }
}

@Composable
private fun rememberLsPulse(): State<Float> =
    rememberInfiniteTransition(label = "lsPulse").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "lsPulseValue",
    )

// ─────────────────────────────────────────────────────────────────────────── Tab Học

/** Tiến độ đã thấy lần gần nhất (trong tiến trình): bài mới xong từ lần mở tab trước ⇒ phát hiệu ứng ăn mừng. */
private object LsSeen {
    var last: Set<String>? = null
}

@Composable
fun LessonsTab(
    vm: GameViewModel,
    bottomPad: Dp,
    onPlayingChange: (Boolean) -> Unit,
    onUpgrade: () -> Unit,
) {
    val ctx = LocalContext.current
    val store = remember { LessonStore.get(ctx) }
    val progress by store.state.collectAsState()
    val tier = rememberTier()
    val limit = remember(tier) { LessonQuota.limit(tier) }
    var detail by remember { mutableStateOf<Lesson?>(null) }
    var playing by remember { mutableStateOf<Lesson?>(null) }
    var pendingNext by remember { mutableStateOf<Lesson?>(null) }
    var celebrate by remember {
        val prev = LsSeen.last
        LsSeen.last = progress.done
        mutableStateOf<String?>(if (prev == null) null else (progress.done - prev).firstOrNull())
    }
    LaunchedEffect(progress.done) { LsSeen.last = progress.done }

    // Mở tab / qua 0h: làm mới lượt trong ngày. Ngủ thẳng đến nửa đêm nên không tốn pin.
    LaunchedEffect(Unit) {
        while (true) {
            store.refreshDay()
            val now = System.currentTimeMillis()
            delay((LessonQuota.nextMidnightMs(now) - now + 1000L).coerceAtLeast(1000L))
        }
    }
    // Vừa giải xong bài: ô bật nảy, ngựa nhảy sang ô kế (~1,1 giây), đáp xong mới gợi ý bài kế tiếp.
    LaunchedEffect(pendingNext) {
        val p = pendingNext
        if (p != null) {
            delay(1900L)
            detail = p
            pendingNext = null
        }
    }
    // Đang giải bài chiến thuật ⇒ Trang chủ ẩn thanh điều hướng để tập trung.
    LaunchedEffect(playing) { onPlayingChange(playing != null) }
    DisposableEffect(Unit) { onDispose { onPlayingChange(false) } }
    BackHandler(enabled = playing != null) { playing = null }

    fun start(l: Lesson) {
        val c = LessonCatalog.courseOf(l.id)
        if (c != null && !LessonQuota.canOpenCourse(c, tier)) {
            detail = null
            onUpgrade()
            return
        }
        // Hết lượt: không làm gì, hộp thoại đang mở sẽ hiện trạng thái "đã hết lượt hôm nay".
        if (!store.tryStart(l.id, limit)) return
        detail = null
        pendingNext = null
        if (l.kind == LessonKind.TACTIC) playing = l else vm.startLesson(l)
    }

    val cur = playing
    if (cur != null) {
        val puzzle = remember(cur.id) { cur.toPuzzle() }
        LessonPuzzleScreen(
            puzzle = puzzle,
            title = cur.title,
            idea = cur.idea,
            images = vm.pieceImages,
            onBack = { playing = null },
            onSolved = {
                store.complete(cur.id)
                celebrate = cur.id
                pendingNext = LessonCatalog.nextInCourse(cur.id)   // gợi ý bài kế tiếp sau khi ô nảy xong
                playing = null
            },
        )
    } else {
        LessonMap(
            progress = progress,
            tier = tier,
            limit = limit,
            images = vm.pieceImages,
            streak = vm.stats.activeStreak(StatsStore.today()),
            celebrateId = celebrate,
            onCelebrated = { celebrate = null },
            bottomPad = bottomPad,
            onOpen = { detail = it },
            onUpgrade = onUpgrade,
        )
    }

    val d = detail
    if (d != null) {
        val course = LessonCatalog.courseOf(d.id)
        LessonDetailDialog(
            lesson = d,
            course = course,
            courseIdx = LessonCatalog.courses.indexOfFirst { it.id == course?.id }.coerceAtLeast(0),
            locked = course != null && !LessonQuota.canOpenCourse(course, tier),
            alreadyOpenedToday = d.id in progress.startedToday,
            canStart = LessonQuota.canStart(limit, progress.startedToday, d.id),
            remaining = LessonQuota.remaining(limit, progress.startedToday.size),
            images = vm.pieceImages,
            onStart = { start(d) },
            onUpgrade = {
                detail = null
                onUpgrade()
            },
            onDismiss = { detail = null },
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────── Bản đồ

@Composable
private fun LessonMap(
    progress: LessonProgress,
    tier: MembershipTier,
    limit: Int?,
    images: Array<ImageBitmap?>,
    streak: Int,
    celebrateId: String?,
    onCelebrated: () -> Unit,
    bottomPad: Dp,
    onOpen: (Lesson) -> Unit,
    onUpgrade: () -> Unit,
) {
    val rows = LsRows
    val total = LessonCatalog.all.size
    val doneCount = remember(progress.done) { LessonCatalog.all.count { it.id in progress.done } }
    val next = remember(progress.done, tier) {
        LessonCatalog.nextUp(progress.done) { LessonQuota.canOpenCourse(it, tier) }
    }
    val remaining = LessonQuota.remaining(limit, progress.startedToday.size)
    val nextId = next?.id
    val curIdx = remember(nextId) { rows.indexOfFirst { it is LsRow.Item && it.lesson.id == nextId } }
    // Lần đầu dựng: đưa bài vừa xong (nếu có) hoặc bài tiếp theo vào khoảng giữa màn hình.
    val targetIdx = remember { rows.indexOfFirst { it is LsRow.Item && it.lesson.id == (celebrateId ?: nextId) }.coerceAtLeast(0) }
    val startCourse = rows[targetIdx].courseIdx
    val scope = rememberCoroutineScope()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val m = remember(maxWidth, density) { LsMetrics(maxWidth, density) }
        val headerH = LsTitleH + LsPillH + 14.dp
        val panelH = LsPanelH + bottomPad
        val tops = remember(m) {
            val t = IntArray(rows.size)
            var y = 0
            for (i in rows.indices) {
                t[i] = y
                y += when (rows[i]) {
                    is LsRow.Header -> m.headPx
                    is LsRow.Item -> m.rowPx
                    is LsRow.Footer -> m.footPx
                }
            }
            t
        }
        val listState = rememberLazyListState(initialFirstVisibleItemIndex = (targetIdx - 2).coerceAtLeast(0))

        val visibleCourse by remember(listState, startCourse) {
            derivedStateOf {
                val vis = listState.layoutInfo.visibleItemsInfo
                val mid = vis.getOrNull(vis.size / 2)?.index
                if (mid != null) (rows.getOrNull(mid)?.courseIdx ?: startCourse) else startCourse
            }
        }
        val currentVisible by remember(listState, curIdx) {
            derivedStateOf { curIdx < 0 || listState.layoutInfo.visibleItemsInfo.any { it.index == curIdx } }
        }
        val hudTint = animateColorAsState(mapChapterFor(visibleCourse).banner, tween(600), label = "lsHudTint")
        val baseColor = animateColorAsState(lsGround(visibleCourse).base, tween(600), label = "lsBase")
        val clock = rememberSceneClock()

        // Ngựa: đứng trên ô bài tiếp theo; học xong thì nhảy từ ô vừa xong sang ô kế. Vẽ ở lớp phủ riêng (bước 2b)
        // nên bay được qua nhiều hàng, không bị LazyColumn cắt/tái chế.
        val hop = remember { HorseHop() }
        val restId = remember(nextId, tier) {
            nextId ?: LessonCatalog.all.lastOrNull { l ->
                LessonCatalog.courseOf(l.id)?.let { LessonQuota.canOpenCourse(it, tier) } == true
            }?.id
        }
        val hopRow = if (celebrateId != null) (LsItemIndex[celebrateId] ?: -1) else -1
        val hopping = hopRow >= 0
        val restRow = restId?.let { LsItemIndex[it] } ?: -1
        val fromRow = if (hopping) hopRow else restRow
        val toRow = if (hopping) (nextId?.let { LsItemIndex[it] } ?: hopRow) else -1
        val headerPx = with(density) { headerH.toPx() }
        val widthPx = with(density) { maxWidth.toPx() }
        val trackPx = with(density) { m.trackW.toPx() }
        val faceY = with(density) { (LsGapTop + m.nodeH * (0.5f - LsFaceShift)).toPx() }   // tâm mặt ô so với đỉnh hàng
        // Điểm chân ngựa (px, hệ của màn hình) khi đứng trên mặt ô của hàng [ri]; đọc trạng thái cuộn ⇒ bám ô khi cuộn.
        fun feetOfRow(ri: Int): Offset {
            val item = rows.getOrNull(ri) as? LsRow.Item ?: return Offset(-1000f, -1000f)
            val first = listState.firstVisibleItemIndex.coerceIn(0, tops.size - 1)
            val scroll = tops[first] + listState.firstVisibleItemScrollOffset
            return Offset(widthPx / 2f + trackPx * (lsXFrac(item.idx) - 0.5f), headerPx + tops[ri] + faceY - scroll)
        }
        LaunchedEffect(celebrateId) {
            if (hopRow >= 0) {
                val a = (rows[hopRow] as LsRow.Item).idx
                val b = (rows.getOrNull(toRow) as? LsRow.Item)?.idx ?: a
                hop.faceLeft = lsXFrac(b) < lsXFrac(a)
                hop.t.snapTo(0f)
                delay(HORSE_WAIT_MS)   // ô vừa xong bật nảy trước, ngựa nhảy sau
                hop.play(HORSE_HOP_MS)
            }
        }

        // 1) Nền đặc theo chặng đang xem (lộ ra ở vùng đệm đầu danh sách và khi kéo quá mép)
        Box(Modifier.fillMaxSize().drawBehind { drawRect(baseColor.value) })

        // 2) Danh sách hàng
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = headerH, bottom = panelH),
        ) {
            itemsIndexed(rows, key = { _, r -> r.key }, contentType = { _, r -> r.kind }) { i, row ->
                when (row) {
                    is LsRow.Header -> LsCourseHeader(
                        row = row,
                        m = m,
                        topPx = tops[i],
                        done = row.course.lessons.count { it.id in progress.done },
                        locked = !LessonQuota.canOpenCourse(row.course, tier),
                        onUpgrade = onUpgrade,
                    )
                    is LsRow.Item -> {
                        val l = row.lesson
                        val locked = !LessonQuota.canOpenCourse(row.course, tier)
                        val st = when {
                            l.id in progress.done -> LsState.Done
                            locked -> LsState.Locked
                            l.id == nextId -> LsState.Current
                            else -> LsState.Open
                        }
                        LsLessonRow(
                            row = row,
                            m = m,
                            topPx = tops[i],
                            state = st,
                            prevDone = row.idx > 0 && row.course.lessons[row.idx - 1].id in progress.done,
                            hasNext = row.idx < row.course.lessons.size - 1,
                            clock = clock,
                            celebrate = l.id == celebrateId,
                            onCelebrated = onCelebrated,
                            onClick = { onOpen(l) },
                        )
                    }
                    is LsRow.Footer -> LsFooter(
                        m = m,
                        topPx = tops[i],
                        ci = row.courseIdx,
                        showPromo = limit != null,
                        onUpgrade = onUpgrade,
                    )
                }
            }
        }

        // 2b) Ngựa 3D (không nhận chạm) – trên danh sách, dưới HUD/bảng dưới
        HorseOverlay(
            width = m.nodeW * 0.78f,
            accent = mapChapterFor(rows.getOrNull(fromRow)?.courseIdx ?: 0).tileTop,
            hop = hop,
            clock = clock,
            from = { if (fromRow >= 0) feetOfRow(fromRow) else Offset(-1000f, -1000f) },
            to = { if (toRow >= 0) feetOfRow(toRow) else null },
        )

        // 3) Hạt môi trường theo chặng (không nhận chạm) – trên danh sách, dưới HUD
        ThemeAmbient(visibleCourse, clock, Modifier.fillMaxSize())

        // 4) HUD
        LsTopHud(
            courseIdx = visibleCourse,
            done = progress.done,
            tint = hudTint,
            maxW = m.trackW - 28.dp,
            headerH = headerH,
            modifier = Modifier.align(Alignment.TopStart),
        )
        AnimatedVisibility(
            visible = !currentVisible,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = panelH + 10.dp),
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
        ) {
            Row(
                Modifier
                    .pressable(onClickLabel = "Về bài tiếp theo", pressedScale = 0.94f) {
                        scope.launch { listState.animateScrollToItem((curIdx - 2).coerceAtLeast(0)) }
                    }
                    .clip(RoundedCornerShape(50))
                    .background(GoldBrush)
                    .padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Flag, contentDescription = null, tint = GoldText, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Bài tiếp theo", color = GoldText, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        LsBottomPanel(
            done = doneCount,
            total = total,
            streak = streak,
            limit = limit,
            remaining = remaining,
            next = next,
            canUnlockMore = tier.rank == 0,
            images = images,
            tint = hudTint,
            bottomPad = bottomPad,
            onCta = {
                if (next != null) onOpen(next) else if (tier.rank == 0) onUpgrade()
            },
            modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────── Hàng: tấm biển khóa

@Composable
private fun LsCourseHeader(row: LsRow.Header, m: LsMetrics, topPx: Int, done: Int, locked: Boolean, onUpgrade: () -> Unit) {
    val ci = row.courseIdx
    val course = row.course
    val theme = remember(ci) { mapChapterFor(ci) }
    val ground = remember(ci) { lsGround(ci) }
    val prevBase = remember(ci) { if (ci > 0) lsGround(ci - 1).base else null }
    val accent = remember(course) { Color(course.accent) }
    val deep = theme.banner.copy(alpha = 1f)
    val plaqueTop = lerp(deep, accent, 0.40f)
    val plaqueBot = lerp(deep, Color.Black, 0.12f)
    val shape = RoundedCornerShape(20.dp)
    val lip = 5.dp

    Box(
        Modifier
            .fillMaxWidth()
            .height(m.headH)
            .graphicsLayer { }
            .drawBehind {
                drawLsGround(ground, topPx, ci * 7919 + 17)
                // Khóa sau nối liền màu với chân khóa trước: không có đường ranh gắt.
                if (prevBase != null) {
                    val fade = 48.dp.toPx()
                    drawRect(
                        Brush.verticalGradient(listOf(prevBase, Color.Transparent), startY = 0f, endY = fade),
                        size = Size(size.width, fade),
                    )
                }
            },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Row(
            Modifier
                .padding(bottom = 12.dp)
                .width(m.trackW - 28.dp)
                .height(112.dp + lip)
                .then(
                    if (locked) Modifier.pressable(onClickLabel = "Mở khóa " + course.title, pressedScale = 0.98f, onClick = onUpgrade)
                    else Modifier
                )
                .lipBehind(20.dp, lip, Color(0x66000000))
                .padding(bottom = lip)
                .clip(shape)
                .background(Brush.verticalGradient(listOf(plaqueTop, plaqueBot)))
                .border(1.dp, VilaBrushes.GlassStroke, shape)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(62.dp, 84.dp), contentAlignment = Alignment.BottomCenter) {
                Canvas(Modifier.matchParentSize()) {
                    val c = Offset(size.width / 2f, size.height * 0.62f)
                    val r = size.width * 0.75f
                    drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.55f), Color.Transparent), c, r), r, c)
                }
                Mascot(hat = theme.hat, width = 48.dp)
            }
            Column(
                Modifier.weight(1f).padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(
                    "KHÓA " + (ci + 1) + " · " + course.level.uppercase(),
                    color = lerp(accent, Color.White, 0.55f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.8.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    course.title,
                    color = Color.White,
                    fontSize = 18.sp,
                    lineHeight = 21.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    course.subtitle,
                    color = Color(0xCCFFFFFF),
                    fontSize = 11.5.sp,
                    lineHeight = 14.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (locked) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Filled.Lock, contentDescription = "Dành cho thành viên", tint = Color(0xFFF7D26A), modifier = Modifier.size(24.dp))
                    Box(Modifier.clip(RoundedCornerShape(50)).background(GoldBrush).padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text("PRO", color = GoldText, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
            } else {
                LsProgressRing(done, course.lessons.size, accent)
            }
        }
    }
}

@Composable
private fun LsProgressRing(done: Int, total: Int, color: Color) {
    val p = if (total <= 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f)
    val anim = animateFloatAsState(p, tween(600), label = "lsRing")
    Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) {
            val sw = 5.dp.toPx()
            val inset = sw / 2f
            val d = Size(size.width - sw, size.height - sw)
            drawArc(Color(0x33FFFFFF), -90f, 360f, false, Offset(inset, inset), d, style = Stroke(width = sw))
            if (anim.value > 0.001f) {
                drawArc(
                    lerp(color, Color.White, 0.25f), -90f, 360f * anim.value, false, Offset(inset, inset), d,
                    style = Stroke(width = sw, cap = StrokeCap.Round),
                )
            }
        }
        if (total > 0 && done >= total) {
            Icon(Icons.Filled.Check, contentDescription = "Đã hoàn thành khóa", tint = Color.White, modifier = Modifier.size(22.dp))
        } else {
            Text((p * 100f).toInt().toString() + "%", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── Hàng: bài học

@Composable
private fun LsLessonRow(
    row: LsRow.Item,
    m: LsMetrics,
    topPx: Int,
    state: LsState,
    prevDone: Boolean,
    hasNext: Boolean,
    clock: State<Float>,
    celebrate: Boolean,
    onCelebrated: () -> Unit,
    onClick: () -> Unit,
) {
    val ci = row.courseIdx
    val theme = remember(ci) { mapChapterFor(ci) }
    val ground = remember(ci) { lsGround(ci) }
    val accent = remember(row.course) { Color(row.course.accent) }
    val xFrac = lsXFrac(row.idx)
    val dx = m.trackW * (xFrac - 0.5f)
    val done = state == LsState.Done
    val mascot = state == LsState.Current
    val g = row.global
    val seed = ci * 7919 + g * 104729

    // Vật cảnh: luôn đặt ở PHÍA TRỐNG (đối diện ô), cao không quá 80% hàng nên không tràn sang hàng khác.
    val pool = LsDecorPools[Math.floorMod(ci, 5)]
    val kind = pool[Math.floorMod(g * 7 + g / pool.size, pool.size)]
    val leftSide = when {
        xFrac > 0.6f -> true
        xFrac < 0.4f -> false
        else -> g % 2 == 0
    }
    val jx = ((g * 37) % 10) / 10f
    val jy = ((g * 53) % 10) / 10f
    var ph = m.rowH * 0.8f
    var pw = ph * kind.ratio
    val wantW = m.trackW * 0.20f
    if (pw > wantW) {
        pw = wantW
        ph = pw / kind.ratio
    }
    val margin = m.trackW * (0.012f + jx * 0.03f)
    val propX = if (leftSide) margin else m.trackW - pw - margin
    val propY = (m.rowH - ph) * (0.2f + 0.6f * jy)

    Box(
        Modifier
            .fillMaxWidth()
            .height(m.rowH)
            .zIndex(if (mascot || celebrate) 1f else 0f)
            .graphicsLayer { }
            .drawBehind {
                drawLsGround(ground, topPx, seed)
                val trackPx = m.trackW.toPx()
                val cx = size.width / 2f + trackPx * (xFrac - 0.5f)
                if (row.idx > 0) {
                    val px = size.width / 2f + trackPx * (lsXFrac(row.idx - 1) - 0.5f)
                    drawLsDots((px + cx) / 2f, 0f, cx, LsGapTop.toPx() + m.nodeH.toPx() * 0.10f, prevDone)
                }
                if (hasNext) {
                    val nx = size.width / 2f + trackPx * (lsXFrac(row.idx + 1) - 0.5f)
                    drawLsDots(cx, size.height - LsGapBottom.toPx() - 2.dp.toPx(), (nx + cx) / 2f, size.height, done)
                }
            },
        contentAlignment = Alignment.TopCenter,
    ) {
        Box(Modifier.width(m.trackW).fillMaxHeight()) {
            Image(
                painter = painterResource(kind.res),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = propX, y = propY)
                    .requiredSize(pw, ph)
                    .then(lsPropMotion(kind, (g % 2) == 1, propX.value, propY.value, clock)),
                contentScale = ContentScale.Fit,
            )
            LsNode(
                state = state,
                number = row.idx + 1,
                title = row.lesson.title,
                accent = accent,
                theme = theme,
                m = m,
                celebrate = celebrate,
                onCelebrated = onCelebrated,
                modifier = Modifier.align(Alignment.TopCenter).offset(x = dx, y = LsGapTop),
                onClick = onClick,
            )
            LsLabel(
                lesson = row.lesson,
                state = state,
                maxW = m.trackW * 0.46f,
                modifier = Modifier.align(Alignment.TopCenter).offset(x = dx, y = LsGapTop + m.nodeH + LsLabelGap),
                onClick = onClick,
            )
        }
    }
}

@Composable
private fun LsNode(
    state: LsState,
    number: Int,
    title: String,
    accent: Color,
    theme: MapChapter,
    m: LsMetrics,
    celebrate: Boolean,
    onCelebrated: () -> Unit,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val nodeW = m.nodeW
    val nodeH = m.nodeH
    val pop = remember { Animatable(1f) }
    val ring = remember { Animatable(0f) }
    val glow = remember { Animatable(0f) }
    var bursting by remember { mutableStateOf(false) }
    val currentOnCelebrated by rememberUpdatedState(onCelebrated)

    // Vừa học xong: ô bật lên rồi nảy lại, vầng sáng + vòng sóng lan quanh ô. Chỉ đụng scale/alpha ⇒ không recomposition.
    LaunchedEffect(celebrate) {
        if (celebrate) {
            bursting = true
            coroutineScope {
                launch {
                    pop.animateTo(1.28f, tween(200, easing = FastOutSlowInEasing))
                    pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
                }
                launch {
                    glow.animateTo(1f, tween(220))
                    delay(500)
                    glow.animateTo(0f, tween(700))
                }
                launch { ring.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
            }
            ring.snapTo(0f)
            bursting = false
            currentOnCelebrated()
        }
    }

    val stateText = when (state) {
        LsState.Done -> "Đã hoàn thành"
        LsState.Current -> "Bài tiếp theo"
        LsState.Open -> "Chưa học"
        LsState.Locked -> "Dành cho thành viên"
    }
    Box(
        modifier = modifier
            .requiredSize(nodeW, nodeH)
            .pressable(onClickLabel = title, pressedScale = 0.9f, onClick = onClick)
            .graphicsLayer {
                scaleX = pop.value
                scaleY = pop.value
            }
            .semantics(mergeDescendants = true) {
                contentDescription = title
                stateDescription = stateText
            },
        contentAlignment = Alignment.Center,
    ) {
        if (state == LsState.Current) {
            val pulse = rememberLsPulse()
            Box(
                Modifier
                    .requiredSize(nodeW * 1.9f, nodeH * 1.9f)
                    .graphicsLayer {
                        val p = pulse.value
                        alpha = 0.6f + 0.4f * p
                        scaleX = 1f + 0.08f * p
                        scaleY = 1f + 0.08f * p
                    }
                    .background(Brush.radialGradient(listOf(Color(0xCCFFE55C), Color(0x88A8E64A), Color(0x00A8E64A))))
            )
        }
        if (bursting) {
            Canvas(Modifier.requiredSize(nodeW * 2.3f, nodeH * 2.3f)) {
                val gl = glow.value
                if (gl > 0.001f) {
                    val r = size.minDimension / 2f
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xF2FFF1A8), Color(0xAAFFC933), Color(0x00FFC933)),
                            center = center,
                            radius = r,
                        ),
                        radius = r,
                        center = center,
                        alpha = gl,
                    )
                }
                val t = ring.value
                if (t > 0.001f && t < 0.999f) {
                    val w = nodeW.toPx() * (1.1f + 0.9f * t)
                    val h = w * SLAB_ASPECT
                    drawOval(
                        color = Color(0xFFFFF3B0),
                        topLeft = Offset(center.x - w / 2f, center.y - h / 2f),
                        size = Size(w, h),
                        alpha = 1f - t,
                        style = Stroke(width = nodeW.toPx() * 0.05f),
                    )
                }
            }
        }

        val topC = when (state) {
            LsState.Done -> theme.tileTop
            LsState.Current -> SlabGoldTop
            LsState.Open -> lerp(accent, Color.White, 0.08f)
            LsState.Locked -> SlabLockedTop
        }
        val sideC = when (state) {
            LsState.Done -> theme.tileSide
            LsState.Current -> SlabGoldSide
            LsState.Open -> lerp(accent, Color.Black, 0.38f)
            LsState.Locked -> SlabLockedSide
        }
        Canvas(Modifier.matchParentSize()) { drawSlab(topC, sideC) }

        when (state) {
            LsState.Done -> Canvas(Modifier.matchParentSize()) {
                drawCheck(size.width / 2f, size.height * (0.5f - LsFaceShift), size.width * 0.34f)
            }
            LsState.Locked -> Icon(
                Icons.Filled.Lock,
                contentDescription = null,
                tint = Color(0xCCDCE6EC),
                modifier = Modifier.offset(y = -(nodeH * LsFaceShift)).size(nodeW * 0.28f),
            )
            else -> LsNumber(number, nodeW, nodeH)
        }
        // Linh vật đứng trên ô Current giờ là ngựa 3D ở lớp phủ HorseOverlay của LessonMap.
    }
}

/** Số thứ tự bài trong khóa: chữ TO, ĐẬM, TRẮNG (có bóng); cỡ chữ theo cỡ ô, không theo fontScale hệ thống. */
@Composable
private fun LsNumber(n: Int, nodeW: Dp, nodeH: Dp) {
    val density = LocalDensity.current
    val factor = if (n < 100) 0.30f else 0.24f
    val style = remember(n, nodeW, density) {
        TextStyle(
            fontSize = with(density) { (nodeW * factor).toSp() },
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            shadow = Shadow(Color(0x66000000), Offset(0f, 3f), 5f),
        )
    }
    Text(
        n.toString(),
        style = style,
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.offset(y = -(nodeH * LsFaceShift)),
    )
}

/** Nhãn dưới ô: tên bài (tối đa 2 dòng) + loại bài · số phút. Nền tối mờ ⇒ luôn đọc được trên mọi chặng. */
@Composable
private fun LsLabel(lesson: Lesson, state: LsState, maxW: Dp, modifier: Modifier, onClick: () -> Unit) {
    val dim = state == LsState.Locked
    val shape = RoundedCornerShape(12.dp)
    val kindText = if (lesson.kind == LessonKind.PRACTICE) "Đấu với Bot" else "Tìm nước đi"
    Column(
        modifier
            .widthIn(max = maxW)
            .pressable(onClickLabel = lesson.title, pressedScale = 0.96f, onClick = onClick)
            .clip(shape)
            .background(Color(0xB30B1526))
            .border(1.dp, Color(0x22FFFFFF), shape)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            lesson.title,
            color = if (dim) Color(0xFFB4BECE) else Color.White,
            fontSize = 12.5.sp,
            lineHeight = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            kindText + " · " + lesson.minutes + " phút",
            color = Color(0xFFAFC0DA),
            fontSize = 10.5.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────── Hàng: chân trang

@Composable
private fun LsFooter(m: LsMetrics, topPx: Int, ci: Int, showPromo: Boolean, onUpgrade: () -> Unit) {
    val ground = remember(ci) { lsGround(ci) }
    Box(
        Modifier
            .fillMaxWidth()
            .height(m.footH)
            .graphicsLayer { }
            .drawBehind { drawLsGround(ground, topPx, ci * 7919 + 99) },
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            Modifier.width(m.trackW - 32.dp).padding(top = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Image(
                painter = painterResource(PropKind.KaTrophy.res),
                contentDescription = null,
                modifier = Modifier.height(64.dp).aspectRatio(PropKind.KaTrophy.ratio),
                contentScale = ContentScale.Fit,
            )
            Text(
                "Bạn đã đi tới cuối bản đồ bài học",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            if (showPromo) UpgradePromo(onUpgrade = onUpgrade)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── HUD trên

@Composable
private fun LsBookIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val left = Path().apply {
            moveTo(w * 0.5f, h * 0.22f)
            cubicTo(w * 0.38f, h * 0.12f, w * 0.18f, h * 0.12f, w * 0.04f, h * 0.20f)
            lineTo(w * 0.04f, h * 0.80f)
            cubicTo(w * 0.18f, h * 0.72f, w * 0.38f, h * 0.72f, w * 0.5f, h * 0.84f)
            close()
        }
        val right = Path().apply {
            moveTo(w * 0.5f, h * 0.22f)
            cubicTo(w * 0.62f, h * 0.12f, w * 0.82f, h * 0.12f, w * 0.96f, h * 0.20f)
            lineTo(w * 0.96f, h * 0.80f)
            cubicTo(w * 0.82f, h * 0.72f, w * 0.62f, h * 0.72f, w * 0.5f, h * 0.84f)
            close()
        }
        drawPath(left, Color(0xFFF2C777))
        drawPath(right, Color(0xFFE0A850))
        drawLine(Color(0xFF8A5A22), Offset(w * 0.5f, h * 0.22f), Offset(w * 0.5f, h * 0.84f), strokeWidth = w * 0.05f, cap = StrokeCap.Round)
        for (k in 0 until 3) {
            val y = h * (0.34f + 0.12f * k)
            drawLine(Color(0x668A5A22), Offset(w * 0.14f, y), Offset(w * 0.40f, y + h * 0.02f), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
            drawLine(Color(0x668A5A22), Offset(w * 0.60f, y + h * 0.02f), Offset(w * 0.86f, y), strokeWidth = w * 0.03f, cap = StrokeCap.Round)
        }
    }
}

/** HUD trên: biểu tượng sách + chữ "Bài học" ở giữa, dải tên khóa cố định ngay dưới. Nền chuyển sắc theo khóa đang xem. */
@Composable
private fun LsTopHud(
    courseIdx: Int,
    done: Set<String>,
    tint: State<Color>,
    maxW: Dp,
    headerH: Dp,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxWidth().height(headerH + 24.dp)) {
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind { drawRect(Brush.verticalGradient(listOf(tint.value.copy(alpha = 0.92f), tint.value.copy(alpha = 0f)))) }
        )
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.height(LsTitleH), verticalAlignment = Alignment.CenterVertically) {
                LsBookIcon(Modifier.size(38.dp))
                Spacer(Modifier.width(10.dp))
                Text("Bài học", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            Crossfade(targetState = courseIdx, modifier = Modifier.height(LsPillH), label = "lsPill") { r ->
                val c = LessonCatalog.courses.getOrNull(r)
                if (c != null) {
                    val d = c.lessons.count { it.id in done }
                    Box(
                        Modifier
                            .widthIn(max = maxW)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0x99000000))
                            .padding(horizontal = 14.dp, vertical = 5.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            "KHÓA " + (r + 1) + " · " + c.title.uppercase() + " · " + d + "/" + c.lessons.size,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.6.sp,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── HUD dưới

@Composable
private fun LsBottomPanel(
    done: Int,
    total: Int,
    streak: Int,
    limit: Int?,
    remaining: Int?,
    next: Lesson?,
    canUnlockMore: Boolean,
    images: Array<ImageBitmap?>,
    tint: State<Color>,
    bottomPad: Dp,
    onCta: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = bottomPad)
            .drawBehind { drawRect(Brush.verticalGradient(listOf(tint.value.copy(alpha = 0f), tint.value.copy(alpha = 0.94f)), 0f, 120f)) }
            .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(done.toString(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                " / $total bài",
                color = Color(0xB3FFFFFF),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 5.dp),
            )
            Spacer(Modifier.weight(1f))
            LsQuotaChip(limit, remaining, Modifier.padding(bottom = 4.dp))
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.LocalFireDepartment, null, tint = Color(0xFFFF8A1F), modifier = Modifier.size(24.dp))
            Text(streak.toString(), color = Color(0xFFFF8A1F), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        LsProgressBar(if (total <= 0) 0f else done.toFloat() / total)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            if (next != null) {
                val thumb = RoundedCornerShape(14.dp)
                Box(Modifier.size(56.dp).clip(thumb).border(2.dp, Color(0x55FFFFFF), thumb)) {
                    MiniBoard(next.preview, next.previewFlipped, images, 56.dp, corner = 12.dp)
                }
            } else {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x33FFFFFF)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Check, contentDescription = "Đã học hết", tint = Color.White) }
            }
            when {
                next != null -> LsCta("HỌC TIẾP", next.title, onCta, Modifier.weight(1f))
                canUnlockMore -> LsCta(null, "Mở khóa bài nâng cao", onCta, Modifier.weight(1f), gold = true)
                else -> LsCta(null, "Bạn đã học hết!", onCta, Modifier.weight(1f), enabled = false)
            }
        }
    }
}

@Composable
private fun LsQuotaChip(limit: Int?, remaining: Int?, modifier: Modifier = Modifier) {
    if (limit == null) {
        Row(
            modifier.clip(RoundedCornerShape(50)).background(GoldBrush).padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Star, contentDescription = null, tint = GoldText, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(4.dp))
            Text("Không giới hạn", color = GoldText, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
        }
    } else {
        val left = remaining ?: 0
        val col = if (left > 0) VilaColors.Green else WarnRed
        val shape = RoundedCornerShape(50)
        Box(
            modifier
                .clip(shape)
                .background(col.copy(alpha = 0.18f))
                .border(1.dp, col.copy(alpha = 0.55f), shape)
                .padding(horizontal = 10.dp, vertical = 4.dp),
        ) {
            if (left > 0) {
                Text("Còn $left/$limit hôm nay", color = col, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            } else {
                Countdown(prefix = "Hết lượt · ", color = col, size = 12)
            }
        }
    }
}

/** Thanh tiến độ: giá trị animate chỉ được đọc trong drawBehind ⇒ chạy mượt, không recomposition. */
@Composable
private fun LsProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val anim = animateFloatAsState(progress.coerceIn(0.04f, 1f), tween(600), label = "lsProgress")
    Box(
        modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                val w = size.width * anim.value
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFFA5D955), Color(0xFF79B22E)), 0f, w),
                    size = Size(w, size.height),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2f),
                )
                drawRoundRect(
                    Color(0x66FFFFFF),
                    topLeft = Offset(5.dp.toPx(), 2.dp.toPx()),
                    size = Size((w - 10.dp.toPx()).coerceAtLeast(0f), 3.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx()),
                )
            }
    )
}

/** Nút 3D: lớp đáy tối + lớp mặt gradient; khi nhấn mặt trượt xuống bằng graphicsLayer. [gold] = nút vàng (nâng cấp). */
@Composable
private fun LsCta(
    eyebrow: String?,
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    gold: Boolean = false,
    enabled: Boolean = true,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val dy = animateFloatAsState(if (pressed) 4f else 0f, label = "lsCtaPress")
    val shape = RoundedCornerShape(18.dp)
    val faceTop = if (gold) Color(0xFFFFDA6A) else Color(0xFFA5D955)
    val faceBot = if (gold) Color(0xFFF0A92E) else Color(0xFF79B22E)
    val lipColor = if (gold) Color(0xFFB57516) else Color(0xFF4A7A1E)
    val textColor = if (gold) GoldText else Color.White
    Box(modifier.height(62.dp).alpha(if (enabled) 1f else 0.55f)) {
        Box(Modifier.fillMaxWidth().height(56.dp).align(Alignment.BottomCenter).background(lipColor, shape))
        Box(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .align(Alignment.TopCenter)
                .graphicsLayer { translationY = dy.value * density }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(faceTop, faceBot)))
                .clickable(interactionSource = interaction, indication = ripple(color = Color.White), enabled = enabled, onClick = onClick)
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (eyebrow != null) {
                    Text(eyebrow, color = textColor.copy(alpha = 0.78f), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                }
                Text(
                    text,
                    color = textColor,
                    fontSize = if (eyebrow != null) 16.sp else 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── Dùng chung

/** Đồng hồ đếm ngược đến 0h. Tách riêng để mỗi giây chỉ vẽ lại đúng một dòng chữ. */
@Composable
private fun Countdown(prefix: String, color: Color = VilaColors.TextDim, size: Int = 12) {
    val text by produceState(initialValue = LessonQuota.countdownText(System.currentTimeMillis())) {
        while (true) {
            delay(1000L)
            value = LessonQuota.countdownText(System.currentTimeMillis())
        }
    }
    Text(prefix + text, color = color, fontSize = size.sp, fontWeight = FontWeight.Medium)
}

@Composable
private fun UpgradePromo(onUpgrade: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .pressable(onClickLabel = "Nâng cấp", pressedScale = 0.98f, onClick = onUpgrade)
            .clip(shape)
            .background(GoldBrush)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Star, contentDescription = null, tint = GoldText, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Học không giới hạn", color = GoldText, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            Text("Mở mọi khóa nâng cao, không bị giới hạn bài mỗi ngày", color = GoldText.copy(alpha = 0.8f), fontSize = 12.sp)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────── Chi tiết bài

@Composable
private fun LessonDetailDialog(
    lesson: Lesson,
    course: Course?,
    courseIdx: Int,
    locked: Boolean,
    alreadyOpenedToday: Boolean,
    canStart: Boolean,
    remaining: Int?,
    images: Array<ImageBitmap?>,
    onStart: () -> Unit,
    onUpgrade: () -> Unit,
    onDismiss: () -> Unit,
) {
    val accent = Color(course?.accent ?: 0xFF81B64C)
    val theme = remember(courseIdx) { mapChapterFor(courseIdx) }
    val ground = remember(courseIdx) { lsGround(courseIdx) }
    val shape = RoundedCornerShape(24.dp)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(horizontal = 18.dp)
                .fillMaxWidth()
                .clip(shape)
                .background(DetailBg)
                .border(1.dp, VilaBrushes.GlassStroke, shape)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Dải chủ đề của khóa: nền + linh vật đội mũ theo chặng, giống tấm biển khóa trên bản đồ.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .drawBehind {
                        drawLsGround(ground, 0, courseIdx * 131 + 5)
                        drawRect(Brush.verticalGradient(listOf(Color.Transparent, DetailBg), startY = size.height * 0.55f, endY = size.height))
                    },
            ) {
                Column(Modifier.align(Alignment.CenterStart).padding(start = 18.dp, end = 90.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        "KHÓA " + (courseIdx + 1) + (if (course != null) " · " + course.level.uppercase() else ""),
                        color = lerp(accent, Color.White, 0.55f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.8.sp,
                        maxLines = 1,
                    )
                    Text(
                        course?.title ?: "Bài học",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Mascot(hat = theme.hat, width = 46.dp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 22.dp))
            }

            Column(
                Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val frame = RoundedCornerShape(12.dp)
                val lip = 5.dp
                Box(
                    Modifier
                        .size(184.dp, 184.dp + lip)
                        .lipBehind(12.dp, lip, Color(0x66000000))
                        .padding(bottom = lip)
                        .clip(frame)
                        .border(2.dp, Color(0x40FFFFFF), frame)
                ) {
                    MiniBoard(lesson.preview, lesson.previewFlipped, images, 184.dp, corner = 10.dp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip(if (lesson.kind == LessonKind.PRACTICE) "Đấu với Bot" else "Tìm nước đi", accent)
                    Chip(lesson.minutes.toString() + " phút", Color(0xFF9AA6BA))
                    if (locked) Chip("PRO", Color(0xFFF7D26A))
                }
                Text(
                    lesson.title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center, lineHeight = 26.sp,
                )
                Text(
                    lesson.idea, color = Color(0xFFC9D2E3), fontSize = 15.sp, lineHeight = 21.sp,
                    textAlign = TextAlign.Center,
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x14FFFFFF))
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Flag, contentDescription = null, tint = VilaColors.Green, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Mục tiêu: " + lesson.goal, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }

                when {
                    locked -> {
                        Notice("Khóa nâng cao dành cho thành viên", GoldText, GoldBrush)
                        LsCta(null, "Mở khóa với gói thành viên", onUpgrade, Modifier.fillMaxWidth(), gold = true)
                    }
                    !canStart -> {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(WarnRed.copy(alpha = 0.16f)).padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text("Bạn đã dùng hết lượt học miễn phí hôm nay", color = WarnRed, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Countdown(prefix = "Làm mới sau ", color = Color(0xFFE9B3AC), size = 13)
                        }
                        LsCta(null, "Nâng cấp để học tiếp", onUpgrade, Modifier.fillMaxWidth(), gold = true)
                    }
                    else -> {
                        if (remaining != null) {
                            val msg = if (alreadyOpenedToday) "Bài đã mở hôm nay, học lại không tốn thêm lượt"
                            else "Bài này dùng 1 trong $remaining lượt còn lại hôm nay"
                            Text(msg, color = VilaColors.TextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
                        }
                        LsCta(null, "Bắt đầu bài học", onStart, Modifier.fillMaxWidth())
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Để sau", color = VilaColors.TextDim, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .padding(horizontal = 9.dp, vertical = 3.dp),
    ) {
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun Notice(text: String, textColor: Color, brush: Brush) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(brush).padding(vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = textColor, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
    }
}

// ─────────────────────────────────────────────────────────────────────────── Bàn cờ nhỏ

/**
 * Bàn cờ xem trước, vẽ bằng một Canvas. [board]: mã quân 0..14 như UiState.board (index = hàng*8 + cột, a1 = 0).
 * Dùng lại [images] (bộ ảnh quân cờ đã nạp) nên không tốn thêm bộ nhớ ảnh.
 */
@Composable
private fun MiniBoard(
    board: IntArray,
    flipped: Boolean,
    images: Array<ImageBitmap?>,
    size: Dp,
    modifier: Modifier = Modifier,
    corner: Dp = 7.dp,
) {
    Canvas(modifier.size(size).clip(RoundedCornerShape(corner))) {
        val s = this.size.width / 8f
        drawRect(MiniLight)
        for (sq in 0 until 64) {
            val rank = sq shr 3
            val file = sq and 7
            if ((rank + file) % 2 != 0) continue          // ô tối (a1 là ô tối)
            val col = if (flipped) 7 - file else file
            val row = if (flipped) rank else 7 - rank
            drawRect(MiniDark, topLeft = Offset(col * s, row * s), size = Size(s, s))
        }
        val px = ceil(s).toInt()
        for (sq in 0 until 64) {
            val pc = board[sq]
            if (pc <= 0 || pc >= images.size) continue
            val img = images[pc] ?: continue
            val rank = sq shr 3
            val file = sq and 7
            val col = if (flipped) 7 - file else file
            val row = if (flipped) rank else 7 - rank
            drawImage(
                image = img,
                dstOffset = IntOffset((col * s).roundToInt(), (row * s).roundToInt()),
                dstSize = IntSize(px, px),
                filterQuality = FilterQuality.Medium,
            )
        }
    }
}
