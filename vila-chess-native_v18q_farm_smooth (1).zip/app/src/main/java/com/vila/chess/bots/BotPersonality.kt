package com.vila.chess.bots

import kotlin.random.Random

/** Sự kiện trong ván mà bot có thể "nói" (kiểu bong bóng thoại của bot chess.com). */
enum class BotEvent {
    WIN, LOSE, DRAW,
    HUMAN_TAKES_QUEEN, HUMAN_TAKES_PIECE, HUMAN_CHECK, HUMAN_PROMOTE,
    HUMAN_HANGS_PIECE, BOT_TAKES_BIG, BOT_CHECK, BOT_CASTLE, BOT_PROMOTE,
}

/** Một câu thoại đang hiện; token đổi mỗi câu để UI chạy lại hiệu ứng. */
class BotBubble(val token: Int, val text: String)

/** Cao độ + tốc độ đọc của một bot. */
class BotVoiceProfile(val pitch: Float, val rate: Float)

/** Giọng điệu của bot. Mỗi bot thuộc đúng một phong cách. */
enum class BotStyle { SHY, CHEERFUL, CLEVER, FIERY, CALM, PROUD, CAT }

/** Tính cách từng bot: phong cách + câu chào riêng + kho câu thoại theo sự kiện. Thuần dữ liệu, không phụ thuộc Android. */
object BotPersonality {

    fun styleOf(botId: String): BotStyle = when (botId) {
        "martin" -> BotStyle.SHY
        "jimmy", "nelson" -> BotStyle.CHEERFUL
        "emir", "isabel", "nova" -> BotStyle.CLEVER
        "lena", "viktor" -> BotStyle.FIERY
        "sofia", "hiro" -> BotStyle.CALM
        "antonio", "magnus", "olga", "daniel" -> BotStyle.PROUD
        "mittens" -> BotStyle.CAT
        else -> BotStyle.CHEERFUL
    }

    /** Giọng đọc: pitch 0.5–2.0 (cao/thấp), rate là tốc độ (1.0 = bình thường). Mỗi bot một cặp riêng. */
    fun voiceOf(botId: String): BotVoiceProfile = when (botId) {
        "martin" -> BotVoiceProfile(1.45f, 0.95f)     // trẻ, ngập ngừng
        "jimmy" -> BotVoiceProfile(1.25f, 1.05f)
        "nelson" -> BotVoiceProfile(1.10f, 1.10f)
        "emir" -> BotVoiceProfile(0.95f, 1.15f)       // nói nhanh, gọn
        "lena" -> BotVoiceProfile(1.30f, 1.20f)       // nhanh, hăng
        "antonio" -> BotVoiceProfile(0.90f, 1.00f)
        "sofia" -> BotVoiceProfile(1.15f, 0.90f)      // chậm rãi, chắc
        "hiro" -> BotVoiceProfile(0.80f, 0.85f)       // trầm, chậm
        "viktor" -> BotVoiceProfile(0.70f, 1.10f)     // trầm, dồn dập
        "isabel" -> BotVoiceProfile(1.20f, 1.00f)
        "magnus" -> BotVoiceProfile(0.85f, 0.95f)
        "olga" -> BotVoiceProfile(1.00f, 0.95f)
        "daniel" -> BotVoiceProfile(0.75f, 0.90f)     // trầm, uy quyền
        "nova" -> BotVoiceProfile(0.60f, 1.00f)       // thấp, đều như máy
        "mittens" -> BotVoiceProfile(1.90f, 1.30f)    // the thé, nhanh như mèo
        else -> BotVoiceProfile(1.0f, 1.0f)
    }

    /** Câu chào đầu ván, riêng từng bot. */
    fun greeting(botId: String): String = when (botId) {
        "martin" -> "Chào bạn! Mình mới học chơi cờ thôi, nhẹ tay nhé."
        "jimmy" -> "Xin chào! Mình sẽ cố hết sức, chúc vui nhé!"
        "nelson" -> "Đi quân ra giữa bàn là phải rồi, bắt đầu nào!"
        "emir" -> "Mình đã tính sẵn vài chiêu rồi đó. Sẵn sàng chưa?"
        "lena" -> "Mình thích tấn công lắm, đừng đứng yên nhé!"
        "antonio" -> "Một ván đáng nhớ đây. Chúc may mắn!"
        "sofia" -> "Cứ thong thả. Mình sẽ phòng thủ thật chắc."
        "hiro" -> "Cờ tàn mới là nơi phân thắng bại. Cùng đi tới đó nhé."
        "viktor" -> "Ván này mình không nhường đâu."
        "isabel" -> "Rất vui được gặp bạn. Cùng chơi một ván hay nào."
        "magnus" -> "Chúc bạn một ván cờ thật chất lượng."
        "olga" -> "Hãy cho mình thấy bạn có gì nào."
        "daniel" -> "Bạn dám thách đấu mình sao? Thú vị đấy."
        "nova" -> "Đang tính trước vài chục nước. Bắt đầu thôi."
        "mittens" -> "Meo~ Đưa mình xem quân cờ nào!"
        else -> "Chúc bạn chơi vui!"
    }

    /** Câu thoại cho một sự kiện; không có thì rơi về phong cách CHEERFUL. */
    fun lines(style: BotStyle, event: BotEvent): List<String> =
        LINES[style]?.get(event) ?: LINES.getValue(BotStyle.CHEERFUL).getValue(event)

    private val LINES: Map<BotStyle, Map<BotEvent, List<String>>> = mapOf(
        BotStyle.SHY to mapOf(
            BotEvent.WIN to listOf("Mình thắng thật sao? Hên quá!", "Ôi, cảm ơn bạn đã chơi với mình!"),
            BotEvent.LOSE to listOf("Bạn giỏi quá, mình học được nhiều lắm.", "Mình thua rồi... nhưng vui lắm!"),
            BotEvent.DRAW to listOf("Hòa à? Mình thấy vậy là tốt rồi.", "Hòa cờ! Mình không dám mong hơn."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Ối, mất Hậu rồi!", "Không... Hậu của mình!"),
            BotEvent.HUMAN_TAKES_PIECE to listOf("A, mình quên giữ quân đó.", "Ôi, bị ăn mất rồi."),
            BotEvent.HUMAN_CHECK to listOf("Á, chiếu! Để mình xem...", "Chiếu rồi, mình phải làm sao đây?"),
            BotEvent.HUMAN_PROMOTE to listOf("Bạn phong cấp rồi, giỏi ghê.", "Ôi, thêm một quân mạnh nữa."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Ơ, mình ăn được quân này sao?", "Bạn có để quên quân đó không?"),
            BotEvent.BOT_TAKES_BIG to listOf("Mình ăn được quân to này, may thật!", "Ơ, ăn được rồi nè!"),
            BotEvent.BOT_CHECK to listOf("Mình chiếu bạn... xin lỗi nhé!", "Chiếu ạ."),
            BotEvent.BOT_CASTLE to listOf("Mình nhập thành cho vua yên tâm.", "Vua mình sẽ an toàn hơn."),
            BotEvent.BOT_PROMOTE to listOf("Tốt của mình lên cấp rồi!", "Mình phong Hậu được rồi!"),
        ),
        BotStyle.CHEERFUL to mapOf(
            BotEvent.WIN to listOf("Thắng rồi! Ván hay lắm, chơi lại nhé?", "Mình thắng! Cảm ơn bạn nhiều!"),
            BotEvent.LOSE to listOf("Bạn thắng đẹp lắm! Chúc mừng nhé!", "Hay quá, mình thua tâm phục khẩu phục."),
            BotEvent.DRAW to listOf("Hòa! Ván đấu cân bằng ghê.", "Hòa cờ, ai cũng giỏi cả."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Ối! Bạn ăn Hậu mình rồi!", "Mất Hậu, nhưng mình chưa bỏ cuộc đâu!"),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Nước ăn quân hay đó!", "Được lắm, bạn lấy quân của mình rồi."),
            BotEvent.HUMAN_CHECK to listOf("Chiếu! Hay đấy.", "Bạn chiếu mình rồi, để mình tránh."),
            BotEvent.HUMAN_PROMOTE to listOf("Phong cấp ngon lành!", "Thêm một quân mạnh cho bạn rồi."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Cảm ơn quân tặng nhé!", "Quân này mình xin nhận!"),
            BotEvent.BOT_TAKES_BIG to listOf("Ăn được quân lớn rồi, tuyệt!", "Mình xin cái này nhé!"),
            BotEvent.BOT_CHECK to listOf("Chiếu nè!", "Cẩn thận vua nhé!"),
            BotEvent.BOT_CASTLE to listOf("Nhập thành xong, yên tâm rồi!", "Vua vào chỗ an toàn."),
            BotEvent.BOT_PROMOTE to listOf("Phong cấp! Tốt đi tới cùng rồi!", "Mình có Hậu mới rồi nè!"),
        ),
        BotStyle.CLEVER to mapOf(
            BotEvent.WIN to listOf("Đúng như mình tính toán.", "Kết thúc gọn. Ván sau cẩn thận hơn nhé."),
            BotEvent.LOSE to listOf("Mình đã tính sót một nước. Chúc mừng bạn.", "Thú vị. Bạn thắng xứng đáng."),
            BotEvent.DRAW to listOf("Hòa. Cả hai đều không sơ hở.", "Hòa cờ, cân bằng đến cuối."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Hy sinh Hậu... hay là sai lầm của mình?", "Mất Hậu. Phải tính lại rồi."),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Một nước đổi quân khá hợp lý.", "Bạn ăn đúng lúc đấy."),
            BotEvent.HUMAN_CHECK to listOf("Chiếu, nhưng mình đã lường trước.", "Một nước chiếu đáng chú ý."),
            BotEvent.HUMAN_PROMOTE to listOf("Phong cấp. Thế cờ đổi rồi.", "Bạn có thêm quân mạnh, mình cần cẩn thận."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Bạn để hở quân này rồi.", "Một sơ suất nhỏ, mình xin nhận."),
            BotEvent.BOT_TAKES_BIG to listOf("Nước ăn này nằm trong kế hoạch.", "Đổi quân có lợi cho mình."),
            BotEvent.BOT_CHECK to listOf("Chiếu. Bạn có đường lui không?", "Một nước chiếu có chủ đích."),
            BotEvent.BOT_CASTLE to listOf("Vua đã an toàn, giờ tới lượt tấn công.", "Nhập thành đúng thời điểm."),
            BotEvent.BOT_PROMOTE to listOf("Phong cấp, đúng như tính toán.", "Quân mới vào cuộc."),
        ),
        BotStyle.FIERY to mapOf(
            BotEvent.WIN to listOf("Nghiền nát! Muốn gỡ lại thì đấu tiếp!", "Thắng rồi! Ván sau mình còn mạnh hơn."),
            BotEvent.LOSE to listOf("Hừ! Lần sau mình sẽ trả đũa!", "Bạn thắng, nhưng đừng đắc ý. Đấu lại đi!"),
            BotEvent.DRAW to listOf("Hòa? Mình chưa chịu đâu!", "Hòa cờ... chưa đã! Đấu lại nào."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Cái gì?! Hậu của mình!", "Được lắm... mình sẽ đòi lại!"),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Bạn ăn quân của mình? Trả giá đi!", "Hừ, mình chưa thua đâu!"),
            BotEvent.HUMAN_CHECK to listOf("Chiếu à? Mình phản công ngay!", "Đừng tưởng chiếu là thắng."),
            BotEvent.HUMAN_PROMOTE to listOf("Phong cấp? Mình xông lên ngay!", "Hừ, thêm một quân nữa để mình diệt."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Quân này của mình rồi!", "Sơ hở! Mình không bỏ qua đâu!"),
            BotEvent.BOT_TAKES_BIG to listOf("Ăn gọn! Xông lên nào!", "Quân to cũng không thoát!"),
            BotEvent.BOT_CHECK to listOf("Chiếu! Vua bạn đang run đấy!", "Tấn công, tấn công!"),
            BotEvent.BOT_CASTLE to listOf("Nhập thành, chuẩn bị tổng tấn công!", "Vua xong, giờ mới là lúc đánh."),
            BotEvent.BOT_PROMOTE to listOf("Hậu mới, thêm lửa!", "Phong cấp! Bạn xong rồi!"),
        ),
        BotStyle.CALM to mapOf(
            BotEvent.WIN to listOf("Một ván cờ đẹp. Cảm ơn bạn.", "Kiên nhẫn sẽ có kết quả."),
            BotEvent.LOSE to listOf("Bạn chơi rất tốt. Chúc mừng.", "Ván này bạn xứng đáng thắng."),
            BotEvent.DRAW to listOf("Hòa. Một kết quả công bằng.", "Cả hai đều đã chơi chắc tay."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Hậu đã mất. Bình tĩnh, ván cờ còn dài.", "Một mất mát lớn, nhưng chưa phải hết."),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Nước ăn hợp lý.", "Đổi quân, không sao."),
            BotEvent.HUMAN_CHECK to listOf("Chiếu. Mình sẽ giải quyết.", "Một nước chiếu, bình tĩnh đỡ thôi."),
            BotEvent.HUMAN_PROMOTE to listOf("Phong cấp rồi. Mình sẽ phòng thủ chặt hơn.", "Tốt đã đi tới cuối."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Quân này đang không được bảo vệ.", "Mình xin nhận."),
            BotEvent.BOT_TAKES_BIG to listOf("Một quân lớn. Cảm ơn bạn.", "Thế cờ nghiêng về mình rồi."),
            BotEvent.BOT_CHECK to listOf("Chiếu. Hãy cẩn thận.", "Một nước chiếu nhẹ nhàng."),
            BotEvent.BOT_CASTLE to listOf("Vua vào nơi an toàn.", "Nhập thành là nền tảng."),
            BotEvent.BOT_PROMOTE to listOf("Phong cấp. Kiên nhẫn đã được đền đáp.", "Một quân mới đã sinh ra."),
        ),
        BotStyle.PROUD to mapOf(
            BotEvent.WIN to listOf("Như dự đoán. Ván sau cố gắng hơn nhé.", "Chiến thắng thuộc về mình."),
            BotEvent.LOSE to listOf("Hiếm khi có người thắng mình. Ấn tượng đấy.", "Bạn thắng. Mình sẽ nhớ ván này."),
            BotEvent.DRAW to listOf("Hòa. Bạn làm mình hơi bất ngờ.", "Hòa cờ, nhưng ván sau mình sẽ thắng."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("Bạn ăn được Hậu của mình? Đáng nể.", "Hiếm có người làm được điều đó."),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Khá lắm, nhưng chưa đủ.", "Bạn lấy được quân. Giờ thì sao?"),
            BotEvent.HUMAN_CHECK to listOf("Chiếu? Đừng vội mừng.", "Chiếu thì chiếu, mình vẫn ổn."),
            BotEvent.HUMAN_PROMOTE to listOf("Phong cấp. Cũng đáng khen.", "Bạn đã đi xa hơn mình nghĩ."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Bạn không nên bỏ quân như vậy.", "Quân này mình lấy, cảm ơn."),
            BotEvent.BOT_TAKES_BIG to listOf("Như mong đợi.", "Một quân lớn cho mình."),
            BotEvent.BOT_CHECK to listOf("Chiếu. Bạn đang bị dồn vào thế khó.", "Mình đang kiểm soát ván này."),
            BotEvent.BOT_CASTLE to listOf("Vua mình an toàn. Còn của bạn?", "Nhập thành, đúng sách giáo khoa."),
            BotEvent.BOT_PROMOTE to listOf("Phong cấp. Kết thúc gần rồi.", "Thêm một Hậu. Bạn chống nổi không?"),
        ),
        BotStyle.CAT to mapOf(
            BotEvent.WIN to listOf("Meo meo! Mình thắng rồi!", "Grừ~ Cá khô đâu, mình thắng rồi!"),
            BotEvent.LOSE to listOf("Meo... bạn giỏi hơn mèo rồi.", "Meooo! Thua rồi, chơi lại không?"),
            BotEvent.DRAW to listOf("Meo? Hòa à?", "Hòa rồi, mình đi ngủ trưa đây."),
            BotEvent.HUMAN_TAKES_QUEEN to listOf("MEOOO! Hậu của mình!", "Hức, mèo mất Hậu rồi..."),
            BotEvent.HUMAN_TAKES_PIECE to listOf("Meo! Bạn ăn quân mình rồi!", "Grừ, trả quân đây!"),
            BotEvent.HUMAN_CHECK to listOf("Meo?! Chiếu mèo à?", "Chiếu... mình sợ quá, meo."),
            BotEvent.HUMAN_PROMOTE to listOf("Meo, quân mới kìa!", "Phong cấp rồi, mèo ghen đó."),
            BotEvent.HUMAN_HANGS_PIECE to listOf("Meo! Quân này mình vồ!", "Bạn bỏ quân nè, ngoạm luôn!"),
            BotEvent.BOT_TAKES_BIG to listOf("Meo meo! Vồ được rồi!", "Ngoạm! Quân to ngon quá."),
            BotEvent.BOT_CHECK to listOf("Meo! Chiếu nè!", "Cào cào, chiếu vua nè."),
            BotEvent.BOT_CASTLE to listOf("Meo, vua vào hang rồi.", "Nhập thành xong, mèo yên tâm."),
            BotEvent.BOT_PROMOTE to listOf("Meooo! Mèo có Hậu rồi!", "Phong cấp! Mèo thành Hậu luôn!"),
        ),
    )
}

/**
 * Chọn lúc nào bot nói để không nói liên tục: tối thiểu [MIN_GAP_PLIES] nước giữa hai câu, mỗi sự kiện có xác suất riêng,
 * không lặp lại câu vừa nói. Câu chào và kết quả ván luôn được nói (force).
 */
class BotChatter(private val rnd: Random = Random.Default) {
    private var lastPly = -100
    private var lastLine = ""

    fun reset() {
        lastPly = -100
        lastLine = ""
    }

    fun greeting(bot: BotProfile): String = BotPersonality.greeting(bot.id).also { lastLine = it }

    /** Trả về câu thoại, hoặc null nếu lần này bot im lặng. */
    fun react(bot: BotProfile, event: BotEvent, ply: Int, force: Boolean = false): String? {
        if (!force) {
            if (ply - lastPly < MIN_GAP_PLIES) return null
            if (rnd.nextFloat() > chance(event)) return null
        }
        val pool = BotPersonality.lines(BotPersonality.styleOf(bot.id), event)
        val line = pool.filter { it != lastLine }.randomOrNull(rnd) ?: pool.firstOrNull() ?: return null
        lastLine = line
        lastPly = ply
        return line
    }

    private fun chance(e: BotEvent): Float = when (e) {
        BotEvent.HUMAN_TAKES_QUEEN, BotEvent.HUMAN_HANGS_PIECE, BotEvent.BOT_PROMOTE, BotEvent.HUMAN_PROMOTE -> 0.9f
        BotEvent.BOT_TAKES_BIG -> 0.7f
        BotEvent.HUMAN_TAKES_PIECE -> 0.55f
        BotEvent.HUMAN_CHECK, BotEvent.BOT_CHECK -> 0.35f
        BotEvent.BOT_CASTLE -> 0.3f
        else -> 1f
    }

    private companion object {
        const val MIN_GAP_PLIES = 5
    }
}
