package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.animation.Crossfade
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.res.imageResource
import androidx.compose.runtime.remember
import com.vila.chess.R
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

// =============================================================================
// CHẶNG (chương) của bản đồ Câu đố
//
// 300.000 câu đố chia thành các VÙNG: mỗi vùng = BLOCKS_PER_REGION khối cảnh x 16 level = 496 câu (~500, khớp ranh giới khối).
// Vùng thứ r (đếm từ level 1 lên) dùng chủ đề r mod 5:
//   0 Rừng xanh (bộ Kenney hiện có) · 1 Làng Giáng sinh · 2 Sa mạc & Núi lửa · 3 Không gian · 4 Biển sâu
// Bố cục vị trí vật cảnh giữ nguyên (đã kiểm không đè nút/đường mòn); chỉ ĐỔI LOẠI vật theo nhóm (cây, đá, hoa cỏ, ...)
// và thêm nền riêng + dải tên chặng ở chân khối.
// =============================================================================

/** Số khối cảnh (mỗi khối 16 level) trong một vùng: 31 x 16 = 496 câu đố. */
internal const val BLOCKS_PER_REGION = 31

internal enum class PropCat { TREE, ROCK, SMALL, FURN, TALL, CHAR, BIG }

internal enum class ChapterDeco { Snow, Dunes, Stars, Bubbles, Fields }

internal enum class MascotHat { Sprout, Santa, Cowboy, Helmet, Goggles, Straw }

@Immutable
internal class ChapterGroundStyle(val top: Color, val bottom: Color, val checker: Color, val deco: ChapterDeco)

@Immutable
internal class MapChapter(
    val name: String,
    /** Màu ô khối ĐÃ XONG của vùng (mặt trên + thành bên) và kiểu mũ của linh vật. */
    val tileTop: Color,
    val tileSide: Color,
    val hat: MascotHat,
    /** null = dùng nền cỏ mặc định của màn hình (chặng Rừng). */
    val ground: ChapterGroundStyle?,
    val banner: Color,
    /** null = giữ nguyên bộ vật cảnh gốc (chỉ lọc [hidden]). */
    val pools: Map<PropCat, List<PropKind>>?,
    /** Bộ vật nhỏ bù vào chỗ trống ở hai mép (null = dùng nhóm SMALL của [pools]); [fillExtra] = số vật bù thêm cho cảnh dày. */
    val fill: List<PropKind>? = null,
    val fillExtra: Int = 5,
    /** Nhân bề rộng của vật nhóm TREE (cây lớn hơn bố cục gốc; layoutAroundPath vẫn né ô khối). */
    val treeBoost: Float = 1f,
)

internal fun categoryOf(kind: PropKind): PropCat = when (kind) {
    PropKind.Tree, PropKind.Pine, PropKind.KfTree, PropKind.KfTreeHigh, PropKind.KaTree -> PropCat.TREE
    PropKind.Rocks, PropKind.KfStones, PropKind.KfRocksLow, PropKind.KfRocksRamp, PropKind.KfRocksHigh,
    PropKind.KaColumnDamaged, PropKind.KaBricks -> PropCat.ROCK
    PropKind.FlowersWhite, PropKind.FlowersColor, PropKind.Bush, PropKind.KfPlant,
    PropKind.KfPatchDirt, PropKind.KfPatchGrass, PropKind.KfWeaponArrow, PropKind.KfWeaponBow -> PropCat.SMALL
    PropKind.Bench, PropKind.KfFence, PropKind.KfLadder, PropKind.KfPlatform, PropKind.KfBridge,
    PropKind.KaBorderCorner, PropKind.KaBorderStraight, PropKind.KaFloor, PropKind.KaFloorDetail -> PropCat.FURN
    PropKind.KfFlag, PropKind.KaBanner, PropKind.KaWeaponSpear, PropKind.KaWeaponSword, PropKind.KaColumn,
    PropKind.KfTarget, PropKind.KaTrophy, PropKind.KaStatue, PropKind.KaWeaponRack -> PropCat.TALL
    PropKind.KfCharacterArcher, PropKind.KaCharacterSoldier -> PropCat.CHAR
    else -> PropCat.BIG
}

private val ChristmasPools = mapOf(
    PropCat.TREE to listOf(PropKind.HolTreeA, PropKind.HolTreeB, PropKind.HolTreeC, PropKind.HolTreeDeco),
    PropCat.ROCK to listOf(PropKind.HolRocks, PropKind.HolSnowPile),
    PropCat.SMALL to listOf(PropKind.HolSnowPile, PropKind.HolPresentA, PropKind.HolPresentB, PropKind.HolCandy, PropKind.HolGingerbread),
    PropCat.FURN to listOf(PropKind.HolBench, PropKind.HolSled),
    PropCat.TALL to listOf(PropKind.HolLantern, PropKind.HolNutcracker, PropKind.HolCandy),
    PropCat.CHAR to listOf(PropKind.HolSnowman, PropKind.HolSnowmanHat, PropKind.HolReindeer),
    PropCat.BIG to listOf(PropKind.HolTreeDeco, PropKind.HolSnowmanHat, PropKind.HolSled),
)

private val DesertPools = mapOf(
    PropCat.TREE to listOf(PropKind.DesCactus, PropKind.DesCactus2),
    PropCat.ROCK to listOf(PropKind.DesLavarock, PropKind.DesMesa),
    PropCat.SMALL to listOf(PropKind.DesLavarock, PropKind.DesCactus2),
    PropCat.FURN to listOf(PropKind.DesMesa, PropKind.DesLavarock),
    PropCat.TALL to listOf(PropKind.DesCactus, PropKind.DesVolcano),
    PropCat.CHAR to listOf(PropKind.DesCactus),
    PropCat.BIG to listOf(PropKind.DesVolcano, PropKind.DesMesa),
)

private val SpacePools = mapOf(
    PropCat.TREE to listOf(PropKind.SpcCrystal),
    PropCat.ROCK to listOf(PropKind.SpcAsteroid),
    PropCat.SMALL to listOf(PropKind.SpcAsteroid, PropKind.SpcCrystal),
    PropCat.FURN to listOf(PropKind.SpcAsteroid),
    PropCat.TALL to listOf(PropKind.SpcRocket, PropKind.SpcCrystal),
    PropCat.CHAR to listOf(PropKind.SpcPlanet2, PropKind.SpcPlanet),
    PropCat.BIG to listOf(PropKind.SpcPlanet, PropKind.SpcPlanet2),
)

private val SeaPools = mapOf(
    PropCat.TREE to listOf(PropKind.SeaSeaweed, PropKind.SeaCoral),
    PropCat.ROCK to listOf(PropKind.SeaShell, PropKind.SeaCoral2),
    PropCat.SMALL to listOf(PropKind.SeaShell, PropKind.SeaCoral2, PropKind.SeaJelly),
    PropCat.FURN to listOf(PropKind.SeaShell),
    PropCat.TALL to listOf(PropKind.SeaSeaweed, PropKind.SeaCoral),
    PropCat.CHAR to listOf(PropKind.SeaJelly),
    PropCat.BIG to listOf(PropKind.SeaCoral, PropKind.SeaCoral2),
)

private val MapChapters: List<MapChapter> = listOf(
    MapChapter("RỪNG XANH", Color(0xFF6CC24A), Color(0xFF3E8E2A), MascotHat.Sprout, null, Color(0xCC1B3A22), null),
    MapChapter(
        "LÀNG GIÁNG SINH", Color(0xFFE5373B), Color(0xFFA81F2B), MascotHat.Santa,
        ChapterGroundStyle(Color(0xFF2F6B91), Color(0xFF1F4F73), Color(0x14FFFFFF), ChapterDeco.Snow),
        Color(0xCC12324D), ChristmasPools,
    ),
    MapChapter(
        "SA MẠC & NÚI LỬA", Color(0xFF2DB7A9), Color(0xFF1B837D), MascotHat.Cowboy,
        ChapterGroundStyle(Color(0xFFDDA864), Color(0xFFB8763B), Color(0x16FFFFFF), ChapterDeco.Dunes),
        Color(0xCC6B3A14), DesertPools,
    ),
    MapChapter(
        "KHÔNG GIAN", Color(0xFF30C6F2), Color(0xFF1790BE), MascotHat.Helmet,
        ChapterGroundStyle(Color(0xFF1B1550), Color(0xFF0A0928), Color(0x0FFFFFFF), ChapterDeco.Stars),
        Color(0xCC0A0A30), SpacePools,
    ),
    MapChapter(
        "BIỂN SÂU", Color(0xFFF0527A), Color(0xFFBE3860), MascotHat.Goggles,
        ChapterGroundStyle(Color(0xFF12709A), Color(0xFF0A3F66), Color(0x12FFFFFF), ChapterDeco.Bubbles),
        Color(0xCC07304F), SeaPools,
    ),
)

/** Cây trên bản đồ nông trại to hơn bố cục gốc ~25% cho tán dày, giống bản đồ chess.com. */
private const val FARM_TREE_BOOST = 1.25f

/**
 * NÔNG TRẠI – vùng đầu tiên của bản đồ Câu đố. Đủ 7 nhóm để themedProps() không bỏ rơi vật nào của bố cục gốc.
 * v18p: đa số là CÂY · BỤI · HOA · CỎ (trước đây toàn ruộng/vật nuôi nên bản đồ trống trải); công trình và vật nuôi là điểm nhấn.
 */
private val FarmPools = mapOf(
    PropCat.TREE to listOf(PropKind.FarmTree, PropKind.FarmTreeApple, PropKind.FarmPine, PropKind.FarmTree, PropKind.FarmPoplar, PropKind.FarmTreeApple),
    PropCat.ROCK to listOf(PropKind.FarmBale, PropKind.FarmBush, PropKind.FarmHaystack, PropKind.FarmStump, PropKind.FarmBushBerry),
    PropCat.SMALL to listOf(
        PropKind.FarmFlowersDaisy, PropKind.FarmBush, PropKind.FarmFlowersTulip, PropKind.FarmGrassC, PropKind.FarmBushBlossom,
        PropKind.FarmSunflowers, PropKind.FarmGrassA, PropKind.FarmPumpkins, PropKind.FarmMushrooms, PropKind.FarmBushBerry,
        PropKind.FarmWheat, PropKind.FarmGrassB, PropKind.FarmCarrots,
    ),
    PropCat.FURN to listOf(PropKind.FarmFence, PropKind.FarmHedge, PropKind.FarmCart, PropKind.FarmHedge),
    PropCat.TALL to listOf(PropKind.FarmScarecrow, PropKind.FarmPoplar, PropKind.FarmPine, PropKind.FarmSilo, PropKind.FarmPoplar, PropKind.FarmScarecrow),
    PropCat.CHAR to listOf(PropKind.FarmSheep, PropKind.FarmChicken, PropKind.FarmCow),
    PropCat.BIG to listOf(PropKind.FarmBarn, PropKind.FarmPond, PropKind.FarmTractor, PropKind.FarmWell, PropKind.FarmWindmill, PropKind.FarmBarn),
)

/** Vật nhỏ bù vào hai mép đường: toàn cỏ, hoa, bụi, nấm – lấp chỗ trống giữa các ô khối. */
private val FarmFillPool = listOf(
    PropKind.FarmGrassA, PropKind.FarmFlowersDaisy, PropKind.FarmBush, PropKind.FarmGrassC, PropKind.FarmFlowersTulip,
    PropKind.FarmGrassB, PropKind.FarmBushBlossom, PropKind.FarmMushrooms, PropKind.FarmBushBerry,
)

private val FarmChapter = MapChapter(
    "NÔNG TRẠI", Color(0xFFF5B83D), Color(0xFFC4821E), MascotHat.Straw,
    ChapterGroundStyle(Color(0xFF7CBF50), Color(0xFF72B848), Color(0x10FFFFFF), ChapterDeco.Fields),
    Color(0xCC5B3A12), FarmPools,
    fill = FarmFillPool, fillExtra = 16, treeBoost = FARM_TREE_BOOST,
)

/** Chủ đề của bản đồ CÂU ĐỐ: Nông trại đứng đầu, rồi 5 chủ đề cũ; lặp vòng sau 6 vùng. */
private val PuzzleChapters: List<MapChapter> = listOf(FarmChapter) + MapChapters

internal fun puzzleChapterFor(chapter: Int): MapChapter = PuzzleChapters[Math.floorMod(chapter, PuzzleChapters.size)]

/** Vùng thứ [chapter] (0 = vùng đầu, ở đáy bản đồ). Lặp vòng sau vùng cuối. */
internal fun mapChapterFor(chapter: Int): MapChapter = MapChapters[Math.floorMod(chapter, MapChapters.size)]

/** Đổi vật cảnh của một khối sang chủ đề [c], giữ nguyên vị trí (tâm ngang) và độ cao tương đối của từng vật. */
internal fun themedProps(base: List<Prop>, c: MapChapter, hidden: Set<PropKind>): List<Prop> {
    val pools = c.pools ?: return base.filter { it.kind !in hidden }
    return base.mapNotNull { p ->
        val pool = pools[categoryOf(p.kind)]
        if (pool.isNullOrEmpty()) return@mapNotNull null
        val hash = (((p.x * 1000f).toInt() * 31 + (p.y * 10000f).toInt()) and 0x7fffffff) % pool.size
        val kind = pool[hash]
        var w = ((p.w / p.kind.ratio) * kind.ratio).coerceIn(p.w * 0.6f, p.w * 1.4f)
        if (c.treeBoost != 1f && categoryOf(p.kind) == PropCat.TREE) w *= c.treeBoost
        Prop(kind, p.x + (p.w - w) / 2f, p.y, w, p.mirror)
    }
}

/** Nền riêng của chặng (cuộn cùng khối cảnh). Vẽ một lần, không phụ thuộc cuộn. */
@Composable
internal fun ChapterGround(c: MapChapter, chapter: Int, modifier: Modifier = Modifier) {
    // Khối đầu của vùng (trừ vùng 0): 14% chân khối mờ dần sang màu nền vùng bên dưới ⇒ không có đường ranh gắt giữa hai vùng.
    val prev: Color? = if (chapter > 0 && chapter % BLOCKS_PER_REGION == 0) {
        puzzleChapterFor(chapter / BLOCKS_PER_REGION - 1).ground
            ?.let { androidx.compose.ui.graphics.lerp(it.top, it.bottom, 0.5f) } ?: Color(0xFF1C4A2A)
    } else null
    val g = c.ground
    if (g == null) {
        if (prev != null) Canvas(modifier) { drawRegionFade(prev) }
        return
    }
    // Nông trại: nền là TEXTURE đồng cỏ lặp liền (cỏ, hoa dại, cỏ ba lá, mảng sáng/tối) thay cho một màu phẳng.
    val meadow: ImageBitmap? = if (g.deco == ChapterDeco.Fields) ImageBitmap.imageResource(R.drawable.farm_ground) else null
    val meadowBrush: ShaderBrush? = remember(meadow) { meadow?.let { ShaderBrush(ImageShader(it, TileMode.Repeated, TileMode.Repeated)) } }
    Canvas(modifier) {
        // Một màu liền: các khối cùng vùng nối nhau không lộ đường ranh.
        drawRect(androidx.compose.ui.graphics.lerp(g.top, g.bottom, 0.5f))
        if (meadow != null && meadowBrush != null) {
            // Pha của gạch theo vị trí thế giới của khối (chapter 0 ở đáy, cao hơn thì chapter lớn hơn) ⇒ hai khối kề nhau ghép liền, không lộ đường cắt.
            val ty = (((chapter + 1).toDouble() * size.height.toDouble()) % meadow.height.toDouble()).toFloat()
            translate(top = ty) { drawRect(meadowBrush, topLeft = Offset(0f, -ty), size = size) }
        }

        // Ô kim cương mờ (hợp chủ đề cờ vua, cùng ngôn ngữ nền cỏ)
        val w = 95.dp.toPx()
        val h = 48.dp.toPx()
        val path = Path()
        var r = 0
        var y = 0f
        while (y < size.height + h) {
            var x = if (r % 2 == 0) 0f else w
            while (x < size.width + w) {
                path.reset()
                path.moveTo(x, y - h); path.lineTo(x + w, y); path.lineTo(x, y + h); path.lineTo(x - w, y); path.close()
                drawPath(path, g.checker)
                x += 2 * w
            }
            y += h
            r++
        }

        val rnd = Random(chapter * 7919 + g.deco.ordinal)
        when (g.deco) {
            ChapterDeco.Snow -> {
                repeat(9) {
                    val rad = (60 + rnd.nextInt(80)).dp.toPx(); val cx = rnd.nextFloat() * size.width; val cy = rad + rnd.nextFloat() * (size.height - 2 * rad).coerceAtLeast(0f)
                    drawCircle(Brush.radialGradient(listOf(Color(0x66EAF6FF), Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
                }
                repeat(110) {
                    val rad = (1 + rnd.nextFloat() * 2.2f).dp.toPx()
                    drawCircle(Color.White.copy(alpha = 0.25f + rnd.nextFloat() * 0.6f), rad, Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height))
                }
            }
            ChapterDeco.Dunes -> {
                repeat(14) {
                    val rad = (50 + rnd.nextInt(90)).dp.toPx(); val cx = rnd.nextFloat() * size.width; val cy = rad + rnd.nextFloat() * (size.height - 2 * rad).coerceAtLeast(0f)
                    val light = rnd.nextBoolean()
                    val col = if (light) Color(0x33FFE2A8) else Color(0x2E7A4416)
                    drawCircle(Brush.radialGradient(listOf(col, Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
                }
                repeat(26) {
                    val cx = rnd.nextFloat() * size.width; val cy = rnd.nextFloat() * size.height; val len = (30 + rnd.nextInt(50)).dp.toPx()
                    drawArc(
                        Color(0x30FFF1D0), 200f, 140f, false, Offset(cx - len / 2, cy), androidx.compose.ui.geometry.Size(len, len * 0.3f),
                        style = Stroke(width = 2.dp.toPx()),
                    )
                }
                repeat(40) {
                    val rad = (1 + rnd.nextFloat() * 2f).dp.toPx()
                    drawCircle(Color(0x405A3010), rad, Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height))
                }
            }
            ChapterDeco.Stars -> {
                repeat(4) {
                    val rad = (120 + rnd.nextInt(120)).dp.toPx(); val cx = rnd.nextFloat() * size.width; val cy = rad + rnd.nextFloat() * (size.height - 2 * rad).coerceAtLeast(0f)
                    val col = if (it % 2 == 0) Color(0x338A4FFF) else Color(0x2E2FA8FF)
                    drawCircle(Brush.radialGradient(listOf(col, Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
                }
                repeat(170) {
                    val rad = (0.6f + rnd.nextFloat() * 1.8f).dp.toPx()
                    val warm = rnd.nextInt(5) == 0
                    drawCircle((if (warm) Color(0xFFFFE9A8) else Color.White).copy(alpha = 0.3f + rnd.nextFloat() * 0.7f), rad, Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height))
                }
            }
            ChapterDeco.Fields -> {
                // Không vẽ ruộng lên nền: nền không biết vị trí các ô khối nên ruộng sẽ chui dưới nút.
                // Ruộng (lúa, cà rốt, bí, hướng dương) là sprite trong FarmPools, được layoutAroundPath() cho né ô khối và đường mòn.
            }
            ChapterDeco.Bubbles -> {
                repeat(7) {
                    val rad = (80 + rnd.nextInt(100)).dp.toPx(); val cx = rnd.nextFloat() * size.width; val cy = rad + rnd.nextFloat() * (size.height - 2 * rad).coerceAtLeast(0f)
                    drawCircle(Brush.radialGradient(listOf(Color(0x3340D8FF), Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
                }
                repeat(55) {
                    val rad = (2 + rnd.nextFloat() * 10f).dp.toPx()
                    val c0 = Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height)
                    drawCircle(Color.White.copy(alpha = 0.10f + rnd.nextFloat() * 0.15f), rad, c0)
                    drawCircle(Color.White.copy(alpha = 0.35f), rad, c0, style = Stroke(width = 1.dp.toPx()))
                }
            }
        }
        if (prev != null) drawRegionFade(prev)
    }
}

internal fun DrawScope.drawRegionFade(color: Color) {
    val y0 = size.height * 0.86f
    drawRect(
        Brush.verticalGradient(listOf(Color.Transparent, color), startY = y0, endY = size.height),
        topLeft = Offset(0f, y0),
        size = Size(size.width, size.height - y0),
    )
}

/** Dải tên vùng ở chân khối đầu vùng (chỉ vẽ khi bước sang vùng mới). Chữ nằm góc TRÁI: nút đầu chặng ở giữa, nút thứ 2 bên phải ⇒ không che chữ. */
@Composable
internal fun ChapterBanner(chapter: Int, c: MapChapter, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .background(Brush.horizontalGradient(listOf(c.banner, c.banner, Color.Transparent))),
        contentAlignment = Alignment.CenterStart,
    ) {
        Column(Modifier.padding(start = 10.dp)) {
            Text(
                "VÙNG ${chapter + 1}",
                color = Color(0xCCFFFFFF),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
            )
            Text(
                c.name,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.6.sp,
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}


// =============================================================================
// v17v — Ô khối 2.5D theo vùng, linh vật, dải tên vùng cố định (theo ảnh mẫu 5 vùng)
// =============================================================================

/** Số level của MỘT vùng (31 khối x 16 level = 496). */
internal const val LEVELS_PER_REGION = BLOCKS_PER_REGION * SCENE_LEVELS

/** Vùng (0 = vùng đầu) chứa [level]. Khớp với `chapter / BLOCKS_PER_REGION` của khối cảnh vật. */
internal fun regionOfLevel(level: Int): Int = (level - 1).coerceAtLeast(0) / LEVELS_PER_REGION

/** "a-b": level đầu – cuối của vùng, cắt ở [maxLevel] (vùng cuối của kho câu đố có thể ngắn hơn 496). */
internal fun regionRangeText(region: Int, maxLevel: Int): String {
    val a = region * LEVELS_PER_REGION + 1
    val b = minOf((region + 1) * LEVELS_PER_REGION, maxOf(maxLevel, a))
    return "$a-$b"
}

/** Màu ô vàng của câu đố HIỆN TẠI (mọi vùng dùng chung, như ảnh mẫu) và ô khoá. */
internal val SlabGoldTop = Color(0xFFFFC83A)
internal val SlabGoldSide = Color(0xFFE0951A)
internal val SlabLockedTop = Color(0xFF7D90A6)
internal val SlabLockedSide = Color(0xFF58687C)

/** Tỉ lệ cao/rộng của ô khối: mặt trên hình thoi cao 0,50 rộng + thành dày 0,14 rộng. */
internal const val SLAB_ASPECT = 0.64f

/** Vẽ ô khối isometric vừa khít DrawScope (rộng = size.width). Góc bo nhẹ nhờ nét viền Round. */
internal fun DrawScope.drawSlab(top: Color, side: Color) {
    val w = size.width
    val i = w * 0.025f                 // lề trong = nửa bề dày nét viền
    val topH = w * 0.50f
    val thick = w * 0.14f
    val midY = topH / 2f
    val sideL = androidx.compose.ui.graphics.lerp(side, Color.Black, 0.14f)
    val round = Stroke(width = i * 2f, join = StrokeJoin.Round)

    val left = Path().apply {
        moveTo(i, midY); lineTo(w / 2f, topH - i); lineTo(w / 2f, topH + thick - i); lineTo(i, midY + thick - i); close()
    }
    val right = Path().apply {
        moveTo(w - i, midY); lineTo(w / 2f, topH - i); lineTo(w / 2f, topH + thick - i); lineTo(w - i, midY + thick - i); close()
    }
    drawPath(left, sideL); drawPath(left, sideL, style = round)
    drawPath(right, side); drawPath(right, side, style = round)

    val face = Path().apply {
        moveTo(w / 2f, i); lineTo(w - i, midY); lineTo(w / 2f, topH - i); lineTo(i, midY); close()
    }
    val lit = androidx.compose.ui.graphics.lerp(top, Color.White, 0.16f)
    drawPath(face, Brush.verticalGradient(listOf(lit, top), startY = 0f, endY = topH))
    drawPath(face, top, style = round)
    drawPath(face, Brush.verticalGradient(listOf(lit, top), startY = 0f, endY = topH))
}

/** Dấu tích trắng (có bóng) tâm (cx, cy), rộng ~[s]. */
internal fun DrawScope.drawCheck(cx: Float, cy: Float, s: Float) {
    fun check(dy: Float) = Path().apply {
        moveTo(cx - s * 0.50f, cy + dy)
        lineTo(cx - s * 0.14f, cy + s * 0.34f + dy)
        lineTo(cx + s * 0.50f, cy - s * 0.34f + dy)
    }
    val st = Stroke(width = s * 0.2f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawPath(check(s * 0.07f), Color(0x40000000), style = st)
    drawPath(check(0f), Color.White, style = st)
}

/**
 * Dải tên vùng CỐ ĐỊNH dưới tiêu đề: "VÙNG n · TÊN · a-b". Đổi mờ dần khi cuộn sang vùng khác.
 * Vùng r > [currentRegion] (chưa mở): hiện ổ khoá + "ĐÃ KHOÁ" thay cho tên chủ đề (giữ bí mật) và nền xám-lam.
 */
@Composable
internal fun RegionPill(region: Int, maxLevel: Int, modifier: Modifier = Modifier, currentRegion: Int = Int.MAX_VALUE) {
    Crossfade(targetState = region, modifier = modifier, label = "regionPill") { r ->
        val locked = isRegionLocked(r, currentRegion)
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(if (locked) Color(0xB32B3A42) else Color(0x99000000))
                .padding(horizontal = 14.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (locked) {
                Icon(Icons.Filled.Lock, null, tint = Color(0xFFCFE3EA), modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(5.dp))
            }
            Text(
                if (locked) "VÙNG ${r + 1} · ĐÃ KHOÁ · ${regionRangeText(r, maxLevel)}"
                else "VÙNG ${r + 1} · ${puzzleChapterFor(r).name} · ${regionRangeText(r, maxLevel)}",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.6.sp,
                maxLines = 1,
                softWrap = false,
            )
        }
    }
}

/** Linh vật trắng đứng trên ô vừa xong; mũ đổi theo vùng. Vẽ bằng Canvas (hệ toạ độ 40 x 52), đáy chạm y = 50. */
@Composable
internal fun Mascot(hat: MascotHat, width: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.requiredSize(width, width * 1.3f)) {
        scale(size.width / 40f, pivot = Offset.Zero) {
            val ink = Color(0xFF2B2F3A)
            drawOval(Color(0x33000000), Offset(7f, 46f), Size(26f, 6f))
            drawOval(Color.White, Offset(7f, 10f), Size(26f, 39f))
            drawOval(Color(0x14000000), Offset(7f, 34f), Size(26f, 15f))
            drawCircle(Color(0x55FF8FA0), 2.2f, Offset(12.5f, 29f))
            drawCircle(Color(0x55FF8FA0), 2.2f, Offset(27.5f, 29f))
            drawCircle(ink, 1.8f, Offset(15.5f, 24f))
            drawCircle(ink, 1.8f, Offset(24.5f, 24f))
            drawArc(ink, 20f, 140f, false, Offset(17f, 26f), Size(6f, 4f), style = Stroke(width = 1.2f, cap = StrokeCap.Round))
            when (hat) {
                MascotHat.Sprout -> {
                    drawLine(Color(0xFF4E9B35), Offset(20f, 11f), Offset(20f, 6f), strokeWidth = 1.6f, cap = StrokeCap.Round)
                    drawOval(Color(0xFF5BBE3F), Offset(11f, 2f), Size(10f, 6f))
                    drawOval(Color(0xFF6ED04F), Offset(19f, 0.5f), Size(10f, 6f))
                }
                MascotHat.Santa -> {
                    val cone = Path().apply { moveTo(9f, 15f); lineTo(31f, 15f); lineTo(29f, 3f); close() }
                    drawPath(cone, Color(0xFFE5373B))
                    drawRoundRect(Color.White, Offset(8f, 13f), Size(24f, 5f), CornerRadius(2.5f))
                    drawCircle(Color.White, 3.2f, Offset(29f, 3f))
                }
                MascotHat.Cowboy -> {
                    drawOval(Color(0xFF8E5F32), Offset(3f, 12f), Size(34f, 8f))
                    drawRoundRect(Color(0xFFB07A44), Offset(11f, 2f), Size(18f, 14f), CornerRadius(5f))
                    drawRect(Color(0xFF5C3A1C), Offset(11f, 11f), Size(18f, 3f))
                }
                MascotHat.Helmet -> {
                    drawCircle(Color(0x44BFE8FF), 15.5f, Offset(20f, 20f))
                    drawCircle(Color(0xCCDDF3FF), 15.5f, Offset(20f, 20f), style = Stroke(width = 1.8f))
                    drawArc(Color(0xAAFFFFFF), 200f, 55f, false, Offset(9f, 9f), Size(22f, 22f), style = Stroke(width = 1.6f, cap = StrokeCap.Round))
                }
                MascotHat.Goggles -> {
                    drawRect(Color(0xFF1C6E8C), Offset(7f, 21.5f), Size(26f, 3.2f))
                    drawCircle(Color(0xAA7FD6F0), 4.6f, Offset(15.5f, 23.5f))
                    drawCircle(Color(0xAA7FD6F0), 4.6f, Offset(24.5f, 23.5f))
                    drawCircle(Color(0xFF1C6E8C), 4.6f, Offset(15.5f, 23.5f), style = Stroke(width = 1.4f))
                    drawCircle(Color(0xFF1C6E8C), 4.6f, Offset(24.5f, 23.5f), style = Stroke(width = 1.4f))
                }
                MascotHat.Straw -> {
                    drawOval(Color(0xFFD9B058), Offset(2f, 12f), Size(36f, 9f))
                    drawRoundRect(Color(0xFFF2D58A), Offset(11f, 2.5f), Size(18f, 14f), CornerRadius(6f))
                    drawRect(Color(0xFFD9473A), Offset(11f, 11f), Size(18f, 3.2f))
                    drawLine(Color(0xFFC99A2E), Offset(27f, 4f), Offset(33f, -0.5f), strokeWidth = 1.4f, cap = StrokeCap.Round)
                }
            }
        }
    }
}

// ── Bố trí vật cảnh quanh đường đi zig-zag mới ───────────────────────────────────────────────

private class Box4(val x0: Float, val y0: Float, val x1: Float, val y1: Float) {
    fun hits(o: Box4, margin: Float = 0f): Boolean =
        x0 < o.x1 + margin && x1 > o.x0 - margin && y0 < o.y1 + margin && y1 > o.y0 - margin
}

private const val TRACK_ITEM_H = 0.205f * ITEM_RATIO               // bước dọc 1 level (đơn vị trackW)
private const val TRACK_BLOCK_H = TRACK_ITEM_H * SCENE_LEVELS       // chiều cao 1 khối cảnh

/** Vùng cấm quanh nút (đơn vị trackW): vật cảnh không được lấn vào đây ⇒ không đè nút, ngôi sao, số level. */
private const val NODE_CLEAR = 0.014f

/** Hộp bao 16 ô khối của một khối (đơn vị trackW). v18q: nới bề rộng 22% và cao 30% (chỗ ô khối dày + sao + nhãn), còn chừa NODE_CLEAR. */
private val PathNodes: List<Box4> by lazy {
    val w = 0.205f * 1.22f
    val h = w * SLAB_ASPECT * 1.3f
    (1..SCENE_LEVELS).map { j ->
        val cx = levelXFrac(j)
        val cy = (SCENE_LEVELS - j + 0.5f) * TRACK_ITEM_H
        Box4(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }
}

/** Các độ dời thử khi vật bị đè, gần nhất trước: ngang ±0..0,40 (bước 0,02), dọc ±0..0,09 (dọc tính nặng gấp đôi). */
private val PathShifts: List<Pair<Float, Float>> by lazy {
    val l = ArrayList<Pair<Float, Float>>()
    for (dx in -20..20) for (dy in intArrayOf(0, 3, -3, 6, -6, 9, -9)) l.add((dx * 0.02f) to (dy * 0.01f))
    l.sortedBy { kotlin.math.abs(it.first) + 2f * kotlin.math.abs(it.second) }
}

private val FillX = floatArrayOf(-0.03f, 0.89f, 0.02f, 0.84f)
private val ForestFill = listOf(PropKind.KfPlant, PropKind.KfPatchGrass, PropKind.KfStones)

private fun boxOf(kind: PropKind, x: Float, y: Float, w: Float): Box4 {
    val h = w / kind.ratio
    return Box4(x + w * 0.06f, y + h * 0.06f, x + w * 0.94f, y + h * 0.94f)   // sprite có viền trong suốt ⇒ thu 6% (v18q: trước 10% nên tán cây/mái chuồng lấn vào nút)
}

/**
 * Xếp lại vật cảnh quanh đường zig-zag chéo (bố cục PuzzleSceneryData được kiểm cho đường cong cũ):
 *  1) vật KHÔNG đè ô khối ⇒ giữ nguyên vị trí;
 *  2) vật bị đè ⇒ DỜI tới chỗ trống gần nhất (ngang trước, dọc nhẹ), không đè ô khối và không đè vật khác;
 *  3) không dời được ⇒ bỏ, rồi BÙ bằng vật nhỏ cùng chủ đề vào chỗ trống ở hai mép (+5 vật cho dày hơn) ⇒ cảnh không thưa;
 *  4) sắp theo đáy vật (xa → gần) để vật thấp che vật cao như phối cảnh isometric.
 * Mọi số đo theo đơn vị bề rộng đường đi (trackW); chạy 1 lần cho mỗi (khối, chủ đề) nhờ remember ở nơi gọi.
 */
internal fun layoutAroundPath(props: List<Prop>, c: MapChapter): List<Prop> {
    val nodes = PathNodes
    val out = ArrayList<Prop>(props.size + 8)
    val boxes = ArrayList<Box4>(props.size + 8)
    val bad = ArrayList<Prop>()
    for (p in props) {
        val b = boxOf(p.kind, p.x, p.y * TRACK_BLOCK_H, p.w)
        if (!p.isWing && nodes.any { it.hits(b, NODE_CLEAR) }) {
            bad.add(p)
        } else {
            out.add(p); boxes.add(b)
        }
    }
    var lost = 0
    for (p in bad) {
        val h = p.w / p.kind.ratio
        var placed = false
        for ((dx, dy) in PathShifts) {
            val nx = p.x + dx
            val ny = p.y * TRACK_BLOCK_H + dy
            if (nx < -0.5f * p.w || nx + p.w > 1f + 0.5f * p.w || ny < 0f || ny + h > TRACK_BLOCK_H) continue
            val b = boxOf(p.kind, nx, ny, p.w)
            if (nodes.any { it.hits(b, NODE_CLEAR) } || boxes.any { it.hits(b, 0.004f) }) continue
            out.add(Prop(p.kind, nx, ny / TRACK_BLOCK_H, p.w, p.mirror)); boxes.add(b)
            placed = true
            break
        }
        if (!placed) lost++
    }
    val pool = c.fill?.takeIf { it.isNotEmpty() } ?: c.pools?.get(PropCat.SMALL)?.takeIf { it.isNotEmpty() } ?: ForestFill
    var want = lost + c.fillExtra
    var n = 0
    var row = 0
    while (want > 0 && row < 40) {
        val ny = row * 0.047f
        for (fx in FillX) {
            if (want <= 0) break
            val kind = pool[(row * 7 + n) % pool.size]
            val w = 0.09f * (0.8f + 0.1f * ((row + n) % 5))
            if (ny + w / kind.ratio > TRACK_BLOCK_H) continue
            val b = boxOf(kind, fx, ny, w)
            if (nodes.any { it.hits(b, NODE_CLEAR) } || boxes.any { it.hits(b, 0.01f) }) continue
            out.add(Prop(kind, fx, ny / TRACK_BLOCK_H, w, (row + n) % 2 == 0)); boxes.add(b)
            want--; n++
        }
        row++
    }
    out.sortBy { it.y + it.w / it.kind.ratio / TRACK_BLOCK_H }
    return out
}
