package com.vila.chess.review

import android.content.Context
import java.io.File

/**
 * Bộ nhớ đệm kết quả phân tích TRƯỚC (khi ván còn đang chơi), lưu theo từng thế cờ (khóa = FEN).
 * Hết ván, GameAnalysisWorker đọc file này và chỉ phân tích nốt những thế còn thiếu ⇒ màn Review hiện gần như ngay.
 *
 * Định dạng: mỗi thế một dòng, các trường cách nhau bằng TAB, "-" = null:
 *   fen  bestMove  cp  mate  depth  timedOut(0/1)  pv(cách nhau bằng dấu cách)  secondMove  secondCp  secondMate  engine  multiPv
 * Ghi nối (append) từng dòng ngay khi xong một thế nên bị tắt đột ngột cũng chỉ mất tối đa thế đang tính;
 * dòng hỏng/cụt bị bỏ qua khi đọc. Hàm encode/decode/acceptable là hàm thuần (test được trên JVM).
 */
object PreAnalysisCache {

    private const val NONE = "-"
    private const val FIELDS = 12
    const val MAX_AGE_MS = 2L * 24 * 3600 * 1000

    // ---------- hàm thuần ----------

    fun encode(fen: String, r: EngineResult): String = listOf(
        fen,
        r.bestMove ?: NONE,
        r.scoreCp.toString(),
        r.mate?.toString() ?: NONE,
        r.depthReached.toString(),
        if (r.timedOut) "1" else "0",
        if (r.pv.isEmpty()) NONE else r.pv.joinToString(" "),
        r.secondMove ?: NONE,
        r.secondCp?.toString() ?: NONE,
        r.secondMate?.toString() ?: NONE,
        r.engine,
        r.multiPv.toString(),
    ).joinToString("\t")

    fun decode(line: String): Pair<String, EngineResult>? {
        val f = line.split('\t')
        if (f.size != FIELDS || f[0].isBlank()) return null
        return try {
            fun s(i: Int) = f[i].takeIf { it != NONE }
            f[0] to EngineResult(
                bestMove = s(1),
                scoreCp = f[2].toInt(),
                mate = s(3)?.toInt(),
                depthReached = f[4].toInt(),
                timedOut = f[5] == "1",
                pv = s(6)?.split(' ')?.filter { it.isNotEmpty() } ?: emptyList(),
                secondMove = s(7),
                secondCp = s(8)?.toInt(),
                secondMate = s(9)?.toInt(),
                engine = f[10],
                multiPv = f[11].toInt(),
            )
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun decodeAll(lines: List<String>): Map<String, EngineResult> {
        val out = HashMap<String, EngineResult>()
        for (l in lines) decode(l)?.let { (fen, r) -> out[fen] = r }
        return out
    }

    /**
     * Kết quả nền có dùng được cho review không? Phải là engine native (có MultiPV 2 cho nhãn Great/Brilliant) và đủ sâu:
     * engine nền chạy 1 luồng nên cho phép thấp hơn trần của máy tối đa 4 bậc (không dưới 12). Quá nông ⇒ Worker tính lại.
     */
    fun acceptable(r: EngineResult, config: EngineConfig): Boolean =
        r.engine == "native" && r.multiPv >= 2 && r.bestMove != null && r.depthReached >= maxOf(12, config.depth - 4)

    // ---------- file ----------

    private fun dir(context: Context) = File(context.applicationContext.filesDir, "review_queue").apply { mkdirs() }

    fun file(context: Context, gameId: String) = File(dir(context), "$gameId.pre")

    @Synchronized
    fun append(context: Context, gameId: String, fen: String, r: EngineResult) {
        runCatching { file(context, gameId).appendText(encode(fen, r) + "\n") }
    }

    fun load(context: Context, gameId: String): Map<String, EngineResult> {
        val f = file(context, gameId)
        if (!f.exists()) return emptyMap()
        return runCatching { decodeAll(f.readLines()) }.getOrDefault(emptyMap())
    }

    fun delete(context: Context, gameId: String) {
        runCatching { file(context, gameId).delete() }
    }

    /** Dọn file .pre bỏ sót (ván bị bỏ giữa chừng / app bị tắt) cũ hơn [MAX_AGE_MS]. */
    fun prune(context: Context, now: Long = System.currentTimeMillis()) {
        runCatching {
            dir(context).listFiles { f -> f.name.endsWith(".pre") }?.forEach { f ->
                if (now - f.lastModified() > MAX_AGE_MS) f.delete()
            }
        }
    }
}
