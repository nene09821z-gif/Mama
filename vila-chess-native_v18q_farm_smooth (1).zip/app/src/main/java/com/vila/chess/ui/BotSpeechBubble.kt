package com.vila.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.bots.BotBubble

private val BubbleBg = Color(0xFFF2F2F2)
private val BubbleText = Color(0xFF262421)

/**
 * Bong bóng thoại của bot (kiểu chess.com): hiện dưới avatar bot, đuôi nhọn chỉ lên avatar.
 * Đặt trong Box phủ bàn cờ, căn TopStart. Không chặn thao tác chạm vì không có clickable.
 */
@Composable
fun BotSpeechBubble(bubble: BotBubble?, modifier: Modifier = Modifier) {
    // Giữ chữ cũ trong lúc mờ dần để bong bóng không nháy trống.
    var last by remember { mutableStateOf("") }
    LaunchedEffect(bubble?.token) { bubble?.let { last = it.text } }
    val text = bubble?.text ?: last

    AnimatedVisibility(
        visible = bubble != null,
        modifier = modifier,
        enter = fadeIn(tween(150)) + scaleIn(tween(180), initialScale = 0.85f, transformOrigin = TransformOrigin(0.1f, 0f)),
        exit = fadeOut(tween(220)),
    ) {
        Column {
            Canvas(Modifier.padding(start = 18.dp).size(width = 14.dp, height = 8.dp)) {
                val p = Path().apply {
                    moveTo(0f, size.height)
                    lineTo(size.width / 2f, 0f)
                    lineTo(size.width, size.height)
                    close()
                }
                drawPath(p, BubbleBg)
            }
            Text(
                text = text,
                color = BubbleText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .widthIn(max = 240.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(BubbleBg)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
    }
}
