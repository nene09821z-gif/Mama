package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.review.GameReview
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.ReviewDisplay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin

// =====================================================================================
// Các phần giao diện của hộp thoại "Game Review" cuối ván (giống màn chờ của chess.com):
//   · ReviewLabelCycler   : 4 nhãn đổi liên tục trong lúc Stockfish phân tích
//   · KnightLoadingBoard  : bàn 3x3 có con mã nhảy
//   · ReviewLabelResults  : khi xong, 4 nhãn trên được thay bằng các nhãn THẬT của ván (kèm số nước, đếm tăng dần, quầng sáng nhẹ)
// =====================================================================================

/** Số nhãn hiện ở hộp thoại tổng kết (cả lúc chờ lẫn lúc xong). */
const val ReviewHighlightCount = 4

/** Chiều cao cố định của hàng nhãn: chờ -> xong không làm hộp thoại giật. */
val ReviewLabelRowHeight = 70.dp

private val CycleOrder = listOf(
    LabelBadge.BRILLIANT, LabelBadge.MISTAKE, LabelBadge.BEST, LabelBadge.GREAT, LabelBadge.BLUNDER,
    LabelBadge.BOOK, LabelBadge.GOOD, LabelBadge.INACCURACY, LabelBadge.EXCELLENT, LabelBadge.MISS,
)

/** Thứ tự hiển thị (tốt -> xấu), giống bảng thống kê ở màn Review. */
private val DisplayOrder = listOf(
    MoveLabel.BRILLIANT, MoveLabel.GREAT, MoveLabel.BEST, MoveLabel.EXCELLENT, MoveLabel.GOOD,
    MoveLabel.BOOK, MoveLabel.INACCURACY, MoveLabel.MISTAKE, MoveLabel.MISS, MoveLabel.BLUNDER,
)

/** Thứ tự ưu tiên khi chỉ đủ chỗ cho vài nhãn: nước nổi bật và lỗi trước. */
private val PriorityOrder = listOf(
    MoveLabel.BRILLIANT, MoveLabel.GREAT, MoveLabel.BEST, MoveLabel.BLUNDER, MoveLabel.MISTAKE, MoveLabel.MISS,
    MoveLabel.INACCURACY, MoveLabel.EXCELLENT, MoveLabel.GOOD, MoveLabel.BOOK,
)

class LabelCount(val badge: LabelBadge, val count: Int)

/**
 * Các nhãn của ván để hiện khi phân tích xong. [humanWhite] = null (2 người cùng máy) thì gộp cả hai bên.
 * Chọn tối đa [max] nhãn có số nước > 0, xếp theo thứ tự tốt -> xấu.
 */
fun reviewHighlights(review: GameReview, humanWhite: Boolean?, max: Int = ReviewHighlightCount): List<LabelCount> {
    val counts: Map<MoveLabel, Int> =
        if (humanWhite != null) {
            ReviewDisplay.countsByLabel(review, humanWhite)
        } else {
            val w = ReviewDisplay.countsByLabel(review, true)
            val b = ReviewDisplay.countsByLabel(review, false)
            MoveLabel.values().associateWith { (w[it] ?: 0) + (b[it] ?: 0) }
        }
    val picked = PriorityOrder.filter { (counts[it] ?: 0) > 0 }.take(max).toSet()
    return DisplayOrder.filter { it in picked }.map { LabelCount(it.badge(), counts[it] ?: 0) }
}

// ------------------------------------------------------------------ 4 nhãn đổi liên tục (mượt, không recomposition)

/** Cạnh hiển thị của mỗi nhãn trong hàng chờ. */
private val CycleBadgeSize = 40.dp

/** Bitmap dựng sẵn lớn hơn một chút để nhãn nảy quá cỡ (overshoot) vẫn nét. */
private val CycleBadgeRender = 44.dp

/** Mỗi "nhịp" đổi nhãn (ms). */
private const val CycleTickMs = 620

/** 4 ô x nhịp rồi lặp: (nhịp * 4 + ô) % 10 lặp lại sau 5 nhịp => vòng lặp khép kín, không giật khi quay về đầu. */
private const val CycleTicks = 5

/** Ô sau trễ hơn ô trước một chút (đơn vị: nhịp) để nhãn đổi lần lượt từ trái sang phải. */
private const val SlotStagger = 0.11f

private const val TwoPi = 6.2831855f

private fun cycleIndex(tick: Int, slot: Int): Int = Math.floorMod(tick * ReviewHighlightCount + slot, CycleOrder.size)

private fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val m = x - 1f
    return 1f + c3 * m * m * m + c1 * m * m
}

/**
 * Nhãn 2.5D vẽ vector rất nhiều lớp (gradient, nét, bóng). Thay vì vẽ lại mỗi lần đổi nhãn, dựng SẴN một lần ra bitmap
 * (trên luồng nền) rồi chỉ việc dán bitmap + scale/xoay/alpha mỗi khung hình => không cấp phát, không giật lúc đổi nhãn.
 */
private object BadgeBitmapCache {
    private val byPx = HashMap<Int, List<ImageBitmap>>()

    @Synchronized
    fun get(px: Int): List<ImageBitmap>? = byPx[px]

    fun getOrRender(px: Int, density: Density): List<ImageBitmap> {
        get(px)?.let { return it }
        val rendered = CycleOrder.map { badge ->
            val bmp = ImageBitmap(px, px)
            CanvasDrawScope().draw(
                density, LayoutDirection.Ltr, androidx.compose.ui.graphics.Canvas(bmp), Size(px.toFloat(), px.toFloat()),
            ) { drawLabelBadge(badge, Offset.Zero, px.toFloat()) }
            bmp
        }
        synchronized(this) { byPx[px] = rendered }
        return rendered
    }
}

/** Dán [img] (cạnh [side] px) tâm tại ([cx], [cy]) với scale / xoay / alpha. Không cấp phát bitmap. */
private fun DrawScope.drawBadgeImage(img: ImageBitmap, cx: Float, cy: Float, side: Int, scale: Float, rotation: Float, alpha: Float) {
    if (alpha <= 0.01f || scale <= 0.01f) return
    withTransform({
        translate(cx, cy)
        rotate(rotation, Offset.Zero)
        scale(scale, scale, Offset.Zero)
    }) {
        drawImage(
            img,
            dstOffset = IntOffset(-side / 2, -side / 2),
            dstSize = IntSize(side, side),
            alpha = alpha.coerceIn(0f, 1f),
            filterQuality = FilterQuality.Medium,
        )
    }
}

/**
 * 4 nhãn đổi liên tục trong lúc chờ phân tích. Cả hàng là MỘT Canvas + MỘT đồng hồ vô hạn, mọi giá trị chỉ đọc ở pha vẽ:
 * không recomposition, không coroutine / Animatable cho từng nhãn. Mỗi lần đổi: nhãn cũ thu nhỏ mờ dần trong khi nhãn mới
 * nảy lên (overshoot) và hơi xoay chính lại - hai nhãn chồng nhau nên không bao giờ có khung hình "trống" hay "nhảy cỡ".
 * Giữa các lần đổi nhãn còn nhấp nhô rất nhẹ để hàng luôn có chuyển động liên tục.
 */
@Composable
fun ReviewLabelCycler(modifier: Modifier = Modifier) {
    val density = LocalDensity.current
    val renderPx = with(density) { CycleBadgeRender.toPx() }.roundToInt()
    val bitmaps by produceState<List<ImageBitmap>?>(BadgeBitmapCache.get(renderPx), renderPx) {
        if (value == null) value = withContext(Dispatchers.Default) { BadgeBitmapCache.getOrRender(renderPx, density) }
    }
    val clock = rememberInfiniteTransition(label = "labelCycler")
    val u = clock.animateFloat(
        0f, CycleTicks.toFloat(),
        infiniteRepeatable(tween(CycleTicks * CycleTickMs, easing = LinearEasing), RepeatMode.Restart),
        label = "cycleU",
    )
    Canvas(modifier.fillMaxWidth().height(ReviewLabelRowHeight)) {
        val imgs = bitmaps ?: return@Canvas
        val t = u.value
        val base = CycleBadgeSize.toPx()
        val side = (CycleBadgeRender.toPx()).roundToInt()
        val baseScale = base / side
        val gap = (size.width - base * ReviewHighlightCount) / (ReviewHighlightCount + 1)
        val bob = 1.5.dp.toPx()
        for (slot in 0 until ReviewHighlightCount) {
            val us = t - slot * SlotStagger
            val tick = floor(us).toInt()
            val f = us - tick
            val cx = gap * (slot + 1) + base * slot + base / 2f
            val cy = size.height / 2f + sin(TwoPi * (t / CycleTicks * 2f + slot * 0.25f)) * bob

            // Nhãn cũ: thu nhỏ + mờ dần (nằm dưới).
            val o = (f / 0.30f).coerceIn(0f, 1f)
            if (o < 1f) {
                drawBadgeImage(imgs[cycleIndex(tick - 1, slot)], cx, cy, side, baseScale * (1f - 0.4f * o * o), 0f, 1f - o)
            }
            // Nhãn mới: nảy lên có overshoot, hơi xoay chính lại, hiện nhanh.
            val a = (f / 0.55f).coerceIn(0f, 1f)
            val k = 1f - a
            drawBadgeImage(
                imgs[cycleIndex(tick, slot)], cx, cy, side,
                baseScale * (0.4f + 0.6f * easeOutBack(a)), -16f * k * k, (f / 0.22f).coerceIn(0f, 1f),
            )
        }
    }
}

/**
 * Phân tích xong: các nhãn thật của ván (tối đa [ReviewHighlightCount]) hiện lần lượt từ trái sang phải:
 * nhãn nảy lên có quầng sáng cùng màu thở nhẹ phía sau, số nước đếm tăng dần từ 0.
 */
@Composable
fun ReviewLabelResults(items: List<LabelCount>, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().height(ReviewLabelRowHeight),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, item -> ResultBadge(item, i) }
    }
}

@Composable
private fun ResultBadge(item: LabelCount, index: Int) {
    val pop = remember(item.badge) { Animatable(0f) }
    val counter = remember(item.badge, item.count) { Animatable(0f) }
    LaunchedEffect(item.badge, item.count) {
        delay(index * 110L)
        launch { pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow)) }
        counter.animateTo(item.count.toFloat(), tween(480 + 50 * minOf(item.count, 8), easing = FastOutSlowInEasing))
    }
    // Đọc counter qua derivedStateOf: chỉ recomposition khi SỐ NGUYÊN đổi, không phải mỗi khung hình của animation đếm.
    val shownCount by remember(counter) { derivedStateOf { counter.value.roundToInt() } }
    val infinite = rememberInfiniteTransition(label = "labelHalo")
    val pulse by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Reverse), label = "pulse")
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(44.dp)
                .drawBehind {
                    // Quầng sáng nhẹ cùng màu nhãn, to ra khi nhãn nảy lên rồi thở chậm.
                    val a = pop.value.coerceIn(0f, 1f) * (0.16f + 0.14f * pulse)
                    drawCircle(
                        Brush.radialGradient(listOf(item.badge.color.copy(alpha = a), Color.Transparent), radius = size.minDimension * 0.85f),
                        radius = size.minDimension * 0.85f,
                    )
                },
            contentAlignment = Alignment.Center,
        ) {
            LabelGlyph(
                item.badge, 40.dp,
                Modifier.graphicsLayer {
                    scaleX = pop.value
                    scaleY = pop.value
                    rotationZ = (1f - pop.value.coerceIn(0f, 1f)) * -16f
                },
            )
        }
        Text(shownCount.toString(), color = item.badge.color, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
    }
}

// ------------------------------------------------------------------ Bàn 3x3 + con mã nhảy

/** Vòng đi của con mã trên bàn 3x3 (8 ô ngoài, ô giữa không đi tới được): [hàng, cột]. */
private val KnightPath = arrayOf(
    intArrayOf(0, 0), intArrayOf(1, 2), intArrayOf(2, 0), intArrayOf(0, 1),
    intArrayOf(2, 2), intArrayOf(1, 0), intArrayOf(0, 2), intArrayOf(2, 1),
)

/** Một bước nhảy kéo dài 600ms: 430ms bay + 170ms đứng (đáp xuống, hơi nhún). */
private const val HopMs = 600f
private const val HopFlightMs = 430f

/**
 * Bàn 3x3 + con mã nhảy. MỘT đồng hồ vô hạn chạy liên tục 0..8 (8 ô, ô cuối nối lại ô đầu => vòng khép kín); bước nhảy,
 * độ cong, ô sáng, bóng đổ và cú nhún khi đáp đều TÍNH từ đồng hồ đó ở pha vẽ. Không snapTo / delay / state bước nhảy
 * nên không còn khung hình lệch (mã nhảy sớm 1 ô) hay khựng ở chỗ nối giữa hai bước. Con mã được dịch bằng ma trận (dưới pixel)
 * thay vì làm tròn toạ độ nên chuyển động trơn, không rung.
 */
@Composable
fun KnightLoadingBoard(knight: ImageBitmap?, modifier: Modifier = Modifier) {
    val clock = rememberInfiniteTransition(label = "knightHop")
    val w = clock.animateFloat(
        0f, KnightPath.size.toFloat(),
        infiniteRepeatable(tween((KnightPath.size * HopMs).toInt(), easing = LinearEasing), RepeatMode.Restart),
        label = "hop",
    )
    Box(modifier.size(208.dp).padding(bottom = 8.dp)) {
        Box(Modifier.fillMaxSize().offset(y = 8.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF3A3936)))
        Canvas(Modifier.fillMaxSize().clip(RoundedCornerShape(26.dp))) {
            val cell = size.width / 3f
            val wv = w.value
            val stepF = floor(wv)
            val step = stepF.toInt()
            val ms = (wv - stepF) * HopMs
            val lin = (ms / HopFlightMs).coerceIn(0f, 1f)
            val p = FastOutSlowInEasing.transform(lin)                         // tiến độ bay đã làm mượt
            val land = ((ms - HopFlightMs) / (HopMs - HopFlightMs)).coerceIn(0f, 1f)   // 0..1 trong lúc đứng
            val from = KnightPath[step % KnightPath.size]
            val to = KnightPath[(step + 1) % KnightPath.size]

            for (r in 0 until 3) for (c in 0 until 3) {
                val light = (r + c) % 2 == 0
                drawRect(
                    if (light) Color(0xFF6A6966) else Color(0xFF52514E),
                    Offset(c * cell, r * cell), Size(cell, cell),
                )
            }
            // Ô vừa rời mờ dần, ô sắp đáp sáng xanh dần (liền mạch: cuối bước này = đầu bước sau).
            val green = Color(0xFF6E9B45)
            drawRect(green.copy(alpha = 0.9f * (1f - p)), Offset(from[1] * cell, from[0] * cell), Size(cell, cell))
            drawRect(green.copy(alpha = 0.9f * p), Offset(to[1] * cell, to[0] * cell), Size(cell, cell))

            val gx = (from[1] + (to[1] - from[1]) * p) * cell
            val gy = (from[0] + (to[0] - from[0]) * p) * cell
            val hop = sin(PI.toFloat() * p)                                     // 0 dưới đất .. 1 trên đỉnh
            val side = cell * 0.9f
            val sideI = side.roundToInt()
            val footY = gy + cell / 2f + side / 2f                              // chân con mã (đáy ô)

            // Bóng đổ dưới đất: nhỏ và mờ khi con mã bay cao.
            drawOval(
                Color.Black.copy(alpha = 0.26f * (1f - 0.55f * hop)),
                Offset(gx + cell / 2f - side * 0.3f * (1f - 0.25f * hop), footY - cell * 0.1f),
                Size(side * 0.6f * (1f - 0.25f * hop), cell * 0.11f),
            )

            val lift = hop * cell * 0.38f
            if (knight != null) {
                val squash = sin(PI.toFloat() * land) * 0.07f                   // nhún nhẹ lúc đáp
                withTransform({
                    translate(gx + cell / 2f, footY - lift)
                    scale(1f + squash, 1f - squash, Offset.Zero)
                }) {
                    drawImage(
                        knight,
                        dstOffset = IntOffset(-sideI / 2, -sideI),
                        dstSize = IntSize(sideI, sideI),
                        filterQuality = FilterQuality.Medium,
                    )
                }
            } else {
                drawCircle(Color.White, side / 3f, Offset(gx + cell / 2f, gy + cell / 2f - lift))
            }
        }
    }
}
