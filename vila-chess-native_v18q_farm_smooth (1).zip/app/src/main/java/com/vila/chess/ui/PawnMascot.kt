package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * QUÂN TỐT XANH 3D – linh vật trên bản đồ câu đố (thay ngựa ở PuzzleMapScreen; bài học vẫn dùng ngựa).
 *
 * Dùng lại nguyên bộ chuyển động của ngựa (HorseFrame / HorseHop trong HorseMotion.kt + HorseMascot.kt):
 * gom lực → bay parabol → tiếp đất dẹt người nảy lại. Cùng chữ ký với HorseOverlay nên thay 1 dòng là xong.
 *
 * Vẽ hoàn toàn bằng Canvas (không asset) trên hệ toạ độ đơn vị 100×124, chân chạm y = 116.
 * Cảm giác 3D: thân tiện (lathe) tô gradient ngang sáng-tối như hình trụ, đầu là hình cầu bóng
 * (gradient toả tròn + vệt phản chiếu + viền sáng phía trên-trái), đĩa cổ và chân đế có sọc theo màu chủ đề vùng,
 * viền mực mềm, bóng đổ trên mặt ô co lại khi bay cao.
 * Hiệu ứng: vòng sáng lan ra dưới chân khi đứng chờ; tia sáng 4 cánh vàng-trắng bắn ra khi tiếp đất.
 */

private const val PW_UW = 100f
private const val PW_UH = 124f
private const val PW_FOOT_X = 50f
private const val PW_FOOT_Y = 116f
private const val PW_TAU = 6.2831855f

// ── Bảng màu ─────────────────────────────────────────────────────────────────────────────────────
private val PwDark = Color(0xFF14401E)
private val PwMid = Color(0xFF2E8B45)
private val PwLight = Color(0xFF6FD28A)
private val PwGlint = Color(0xFFA6F0B8)
private val PwInk = Color(0xAA0E3416)
private val PwGold = Color(0xFFFFD45A)
private val PwCream = Color(0xFFFFF3D6)

// ── Hình khối tĩnh (dựng 1 lần) ──────────────────────────────────────────────────────────────────
/** Chân đế loe + thân tiện, đối xứng quanh x = 50. */
private val PwBase = Path().apply {
    moveTo(21f, 116f)
    lineTo(79f, 116f)
    cubicTo(83f, 116f, 84f, 107f, 78f, 105f)
    cubicTo(66f, 101f, 61f, 95f, 59.5f, 86f)
    cubicTo(58f, 76f, 58f, 66f, 59f, 58f)
    lineTo(41f, 58f)
    cubicTo(42f, 66f, 42f, 76f, 40.5f, 86f)
    cubicTo(39f, 95f, 34f, 101f, 22f, 105f)
    cubicTo(16f, 107f, 17f, 116f, 21f, 116f)
    close()
}
private val PwStar = Path()   // dùng lại cho tia sáng (đổi hình mỗi khung) – chỉ vẽ trên luồng UI

// ── Brush tĩnh (toạ độ đơn vị cố định ⇒ dùng chung mọi khung hình) ───────────────────────────────
private val PwBodyBrush = Brush.horizontalGradient(
    0f to PwDark, 0.28f to PwLight, 0.52f to PwMid, 1f to PwDark, startX = 17f, endX = 84f,
)
private val PwHeadBrush = Brush.radialGradient(
    0f to PwGlint, 0.35f to PwLight, 0.7f to PwMid, 1f to PwDark, center = Offset(42f, 25f), radius = 30f,
)
private val PwFootShade = Brush.verticalGradient(
    0f to Color(0x00000000), 1f to Color(0x66000000), startY = 104f, endY = 116f,
)

// ── Lớp phủ ──────────────────────────────────────────────────────────────────────────────────────
/**
 * Quân tốt + bóng đổ, vẽ ĐÈ lên danh sách (nhảy được qua nhiều hàng). Ý nghĩa tham số giống hệt [HorseOverlay]:
 *  • [from]: chân khi đứng yên / lúc bắt đầu nhảy · [to]: điểm đáp (null = đứng yên, trùng [from] = nhảy tại chỗ).
 *  • [hop]: dùng chung kiểu HorseHop (faceLeft không dùng vì quân tốt đối xứng).
 */
@Composable
internal fun PawnOverlay(
    width: Dp,
    accent: Color,
    hop: HorseHop,
    clock: State<Float>,
    from: () -> Offset,
    to: () -> Offset?,
    modifier: Modifier = Modifier,
) {
    val f = remember { HorseFrame() }
    val pShadow = remember { FloatArray(3) }
    val pPawn = remember { FloatArray(3) }
    val wPx = with(LocalDensity.current) { width.toPx() }
    val k = wPx / PW_UW
    val pawnH = width * (PW_UH / PW_UW)
    val shadowH = width * 0.5f
    val glow = lerp(accent, Color.White, 0.5f)

    Box(modifier.fillMaxSize()) {
        // Bóng đổ + vòng sáng chờ + tia sáng tiếp đất (nằm ở mặt ô, không bay theo quân).
        Canvas(
            Modifier
                .requiredSize(width, shadowH)
                .graphicsLayer {
                    f.set(hop.t.value, 0f)
                    pawnPlace(from(), to(), f, wPx, pShadow)
                    translationX = pShadow[0] - wPx / 2f
                    translationY = pShadow[1] - wPx * 0.25f
                },
        ) {
            f.set(hop.t.value, clock.value)
            val c = center
            val rx = size.width * 0.34f * (1f - 0.4f * f.lift)
            withTransform({ scale(1f, 0.3f, c) }) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0x99000000), Color(0x00000000)), center = c, radius = rx),
                    radius = rx, center = c, alpha = 1f - 0.5f * f.lift,
                )
            }
            val tv = hop.t.value
            if (tv <= 0f || tv >= 1f) {
                // Đứng chờ: vòng sáng lan ra mỗi 1,5 s (đồng hồ cảnh 24 s ⇒ 16 chu kỳ nguyên, lặp liền mạch).
                val q = (clock.value * 16f) % 1f
                withTransform({ scale(1f, 0.3f, c) }) {
                    drawCircle(
                        color = glow, radius = rx * (0.9f + 0.9f * q), center = c,
                        alpha = 0.55f * (1f - q), style = Stroke(width = size.width * 0.04f),
                    )
                }
            }
            if (f.dust > 0.001f) {
                val u = f.dust
                for (i in 0 until 8) {
                    val a = i * (PW_TAU / 8f) + 0.3f
                    val d = size.width * (0.22f + 0.5f * u)
                    drawSparkle(
                        Offset(c.x + cos(a) * d, c.y + sin(a) * d * 0.45f - size.width * 0.28f * u),
                        size.width * 0.075f * (1f - 0.5f * u),
                        if (i % 2 == 0) PwGold else Color.White,
                        1f - u,
                    )
                }
                for (i in 0 until 6) {   // bụi kem quanh chân
                    val a = i * (PW_TAU / 6f) + 0.4f
                    val d = size.width * (0.16f + 0.3f * u)
                    drawCircle(
                        PwCream,
                        radius = size.width * (0.04f - 0.016f * u),
                        center = Offset(c.x + cos(a) * d, c.y + sin(a) * d * 0.32f),
                        alpha = (1f - u) * 0.7f,
                    )
                }
            }
        }
        // Quân tốt.
        Canvas(
            Modifier
                .requiredSize(width, pawnH)
                .graphicsLayer {
                    f.set(hop.t.value, 0f)
                    pawnPlace(from(), to(), f, wPx, pPawn)
                    translationX = pPawn[0] - PW_FOOT_X * k
                    translationY = pPawn[1] - PW_FOOT_Y * k - pPawn[2]
                },
        ) {
            f.set(hop.t.value, clock.value)
            val feet = Offset(PW_FOOT_X * k, PW_FOOT_Y * k)
            // Dồn/giãn quanh bàn chân → nghiêng nhẹ quanh bàn chân → đổi sang px (gọi sau = áp trước).
            withTransform({
                scale(1f + (1f - f.squashY) * 0.6f, f.squashY, feet)
                rotate(f.pitch * 0.4f + f.swing * 1.5f, feet)
                scale(k, k, Offset.Zero)
            }) { drawPawn(accent) }
        }
    }
}

/** out = [chân x, chân y (mặt đất, không tính độ cao), độ cao px]. Cùng công thức cung nhảy với ngựa. */
private fun pawnPlace(a: Offset, b: Offset?, f: HorseFrame, wPx: Float, out: FloatArray) {
    if (b == null) {
        out[0] = a.x; out[1] = a.y; out[2] = 0f
        return
    }
    val dx = b.x - a.x
    val dy = b.y - a.y
    val arc = (sqrt(dx * dx + dy * dy) * 0.42f).coerceIn(wPx * 0.8f, wPx * 2.1f)   // quân tốt hẹp hơn ngựa ⇒ nâng cung theo bề rộng nhỏ hơn
    out[0] = a.x + dx * f.s
    out[1] = a.y + dy * f.s
    out[2] = f.lift * arc
}

// ── Vẽ ───────────────────────────────────────────────────────────────────────────────────────────
private fun DrawScope.drawSparkle(c: Offset, r: Float, color: Color, alpha: Float) {
    val s = r * 0.28f
    PwStar.reset()
    PwStar.moveTo(c.x, c.y - r)
    PwStar.lineTo(c.x + s, c.y - s)
    PwStar.lineTo(c.x + r, c.y)
    PwStar.lineTo(c.x + s, c.y + s)
    PwStar.lineTo(c.x, c.y + r)
    PwStar.lineTo(c.x - s, c.y + s)
    PwStar.lineTo(c.x - r, c.y)
    PwStar.lineTo(c.x - s, c.y - s)
    PwStar.close()
    drawPath(PwStar, color, alpha = alpha)
}

private fun DrawScope.drawPawn(accent: Color) {
    val accentLight = lerp(accent, Color.White, 0.35f)

    // Thân tiện + chân đế.
    drawPath(PwBase, PwBodyBrush)
    clipPath(PwBase) {
        drawRect(PwFootShade, Offset(10f, 104f), Size(80f, 12f))                                       // tối dần sát mặt ô
        drawRect(accent, Offset(10f, 107f), Size(80f, 3.2f))                                           // sọc màu chủ đề
        drawRect(accentLight, Offset(10f, 107f), Size(80f, 1.1f))
        drawRoundRect(Color(0x55FFFFFF), Offset(43.5f, 62f), Size(3.4f, 22f), CornerRadius(1.7f))      // vệt sáng dọc thân
    }
    drawPath(PwBase, PwInk, style = Stroke(1.3f, join = StrokeJoin.Round))

    // Đĩa cổ.
    drawRoundRect(PwBodyBrush, Offset(30f, 50f), Size(40f, 10f), CornerRadius(5f))
    drawRoundRect(accent, Offset(31f, 54.6f), Size(38f, 2.6f), CornerRadius(1.3f))
    drawRoundRect(Color(0x66FFFFFF), Offset(33f, 51.2f), Size(20f, 2f), CornerRadius(1f))
    drawRoundRect(PwInk, Offset(30f, 50f), Size(40f, 10f), CornerRadius(5f), style = Stroke(1.2f))

    // Đầu: hình cầu bóng.
    val head = Offset(50f, 34f)
    drawCircle(PwHeadBrush, radius = 17.5f, center = head)
    drawArc(
        Color(0x88FFFFFF), 200f, 100f, false, Offset(32.8f, 16.8f), Size(34.4f, 34.4f),
        style = Stroke(1.5f, cap = StrokeCap.Round),
    )                                                                                                  // viền sáng trên-trái
    drawCircle(PwInk, radius = 17.5f, center = head, style = Stroke(1.3f))
    drawOval(Color(0xDDFFFFFF), Offset(38f, 21f), Size(10f, 6f))                                       // vệt phản chiếu chính
    drawCircle(Color(0xCCFFFFFF), radius = 1.6f, center = Offset(51.5f, 24f))                          // điểm sáng nhỏ
    drawOval(Color(0x3376F0A0), Offset(42f, 43f), Size(16f, 6f))                                       // ánh phản chiếu từ mặt ô
}
