package com.vila.chess.review

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phân tích NGẦM TRƯỚC khi ván kết thúc (khi ván đã "gần xong", xem [NearEnd]).
 *
 * Mục tiêu: hết ván là có review gần như ngay, mà lúc đang chơi KHÔNG làm giật bàn cờ:
 *  • Engine riêng, native, 1 luồng, Hash <= 16MB, nice 19 (thấp nhất). Không bao giờ dùng wasm/WebView.
 *  • Chỉ chạy khi [shouldPause] = false (đến lượt người chơi / chờ đối thủ online, đang ở màn bàn cờ). Máy đang nghĩ nước đi,
 *    bàn cờ đóng, hộp phong cấp đang mở... ⇒ dừng NGAY (kiểm tra mỗi 80ms, gửi `stop`), kết quả nông bị bỏ.
 *  • Nghỉ ~350ms sau mỗi lần tiếp tục để animation đi quân chạy xong; máy nóng thì nghỉ như worker.
 *  • Mỗi thế xong là ghi ngay vào [PreAnalysisCache] (khóa = FEN). Hết ván [handOff] dừng engine nền rồi giao id ván cho
 *    GameAnalysisWorker; Worker dùng lại các thế đã có, chỉ tính nốt phần thiếu.
 *  • Rảnh > 20s (đã bắt kịp mọi nước) thì tắt hẳn tiến trình engine để trả RAM; nước mới tới sẽ tự bật lại.
 *  • Mọi lỗi (không có libstockfish.so, engine chết...) chỉ tắt tính năng nền cho ván này; Worker cuối ván vẫn làm đủ.
 */
class PreAnalyzer(
    context: Context,
    private val scope: CoroutineScope,
    /** true = tạm dừng/dừng ngay. Được gọi từ luồng nền nên chỉ đọc trạng thái, không ghi. */
    private val shouldPause: () -> Boolean,
) {
    private class Snapshot(val startFen: String, val ucis: List<String>)

    private val app = context.applicationContext
    private val wake = Channel<Unit>(Channel.CONFLATED)

    @Volatile private var snapshot: Snapshot? = null
    @Volatile private var disabled = false
    private var job: Job? = null

    /** Id ván đang được phân tích trước (chính là id sẽ dùng cho review), null nếu chưa bắt đầu. */
    @Volatile var gameId: String? = null
        private set

    init {
        scope.launch(Dispatchers.IO) { PreAnalysisCache.prune(app) }   // dọn file bỏ sót, không chặn luồng chính
    }

    /**
     * Gọi (luồng chính) sau mỗi nước khi ván đã gần xong. [ucis] là bản sao riêng của nơi gọi.
     * Lần đầu tạo id ván; các lần sau chỉ cập nhật danh sách nước và đánh thức vòng lặp.
     */
    fun update(startFen: String, ucis: List<String>) {
        if (disabled) return
        val id = gameId ?: UUID.randomUUID().toString().also { gameId = it }
        snapshot = Snapshot(startFen, ucis)
        wake.trySend(Unit)
        if (job?.isActive != true) job = scope.launch(Dispatchers.Default) { loop(id) }
    }

    /**
     * Hết ván: dừng engine nền (giải phóng CPU/RAM trước khi Worker khởi động) và trả id ván cùng cache để Worker dùng.
     * null nếu chưa từng phân tích trước. Sau lệnh này đối tượng sẵn sàng cho ván mới.
     */
    fun handOff(): String? {
        val id = gameId
        stopLoop()
        gameId = null
        disabled = false
        return id
    }

    /** Ván bị bỏ / bắt đầu ván mới: dừng và XÓA cache của ván đang dở. */
    fun discard() {
        val id = gameId
        stopLoop()
        gameId = null
        disabled = false
        if (id != null) PreAnalysisCache.delete(app, id)
    }

    private fun stopLoop() {
        job?.cancel()
        job = null
        snapshot = null
    }

    private suspend fun loop(id: String) {
        val full = DeviceTierManager.getDeviceTier(app)
        // Cấu hình NHẸ cho lúc đang chơi: 1 luồng, hash nhỏ. Depth/thời gian giữ như worker để kết quả dùng chung được.
        val light = full.copy(threads = 1, hashMb = minOf(full.hashMb, 16))
        val monitor = DeviceHealthMonitor(app)
        val engine = SilentStockfishEngine(app, light, allowWasm = false, niceLevel = 19)
        val done = HashSet<String>()           // thế đã có kết quả dùng được
        val attempted = HashSet<String>()      // thế đã thử mà không đạt chuẩn: để Worker tính, không thử lại vô hạn
        done.addAll(PreAnalysisCache.load(app, id).filterValues { PreAnalysisCache.acceptable(it, full) }.keys)
        var resumedAt = 0L
        try {
            while (currentCoroutineContext().isActive) {
                val snap = snapshot ?: break
                val replay = ReviewReplay.replay(snap.startFen, snap.ucis) ?: break
                val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
                // Thế MỚI NHẤT trước (người chơi sắp xem nước vừa đi), rồi lùi dần về đầu ván.
                val next = fens.asReversed().firstOrNull { it !in done && it !in attempted }
                if (next == null) {
                    // Đã bắt kịp: chờ nước mới; rảnh lâu thì tắt tiến trình engine.
                    val got = withTimeoutOrNull(20_000L) { wake.receive() }
                    if (got == null) engine.close()
                    resumedAt = 0L   // nước mới vừa tới: để animation chạy xong rồi mới tính
                    continue
                }
                if (ReviewReplay.terminalEval(next) != null) { done += next; continue }
                if (shouldPause()) { resumedAt = 0L; delay(150); continue }
                if (monitor.isTooHot()) { delay(DeviceHealthMonitor.COOL_DOWN_MS); continue }
                if (resumedAt == 0L) { resumedAt = System.currentTimeMillis(); delay(SETTLE_MS); continue }   // chờ animation xong, rồi kiểm tra lại

                val interrupted = AtomicBoolean(false)
                val watcher = scope.launch(Dispatchers.Default) {
                    while (isActive) {
                        delay(WATCH_MS)
                        if (shouldPause()) { interrupted.set(true); engine.stopSearch(); break }
                    }
                }
                val r = try {
                    engine.analyzeSilently(next, full.depth, full.moveTimeoutMs)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Phân tích trước bị tắt cho ván này: ${e.message}")
                    disabled = true
                    break
                } finally {
                    watcher.cancel()
                }
                if (interrupted.get()) continue    // bị ngắt giữa chừng: kết quả nông, bỏ; lần sau tính lại
                if (PreAnalysisCache.acceptable(r, full)) {
                    PreAnalysisCache.append(app, id, next, r)
                    done += next
                } else {
                    attempted += next
                }
            }
        } finally {
            withContext(NonCancellable) { engine.shutdown() }
        }
    }

    private companion object {
        const val TAG = "PreAnalyzer"
        const val SETTLE_MS = 350L
        const val WATCH_MS = 80L
    }
}
