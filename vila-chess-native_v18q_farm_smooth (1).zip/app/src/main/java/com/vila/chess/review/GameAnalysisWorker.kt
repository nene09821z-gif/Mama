package com.vila.chess.review

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.vila.chess.review.db.ReviewRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Phân tích ván cờ CHẠY NGẦM HOÀN TOÀN (Silent Background Analysis).
 *
 *  - Được xếp hàng khi ván kết thúc ([enqueueAnalysis]); không có thông báo hệ thống / Toast.
 *    Tiến độ (KEY_DONE / KEY_TOTAL) chỉ được đẩy qua WorkManager.setProgress để lớp phủ "Đang phân tích" trên bàn cờ
 *    vẽ vòng %; kết quả thật vẫn CHỈ lấy từ Room khi đã lưu xong.
 *  - KHÔNG có ràng buộc pin/sạc: luôn chạy ngay. Máy nóng chỉ nghỉ ngắn vài giây (xem DeviceHealthMonitor), không bao giờ bỏ dở.
 *  - Chạy trên Dispatchers.Default; engine native bị hạ độ ưu tiên CPU (nice) để nhường luồng chính.
 *  - Mỗi nước đi lưu vào bảng analysis_result (FEN, Best Move, điểm, nhãn...) trong MỘT giao dịch với analysis_summary.
 *  - BẮT BUỘC: xong (kể cả lỗi/hủy) là gửi `stop` + `quit` cho engine, giải phóng tiến trình và RAM.
 */
class GameAnalysisWorker(
    ctx: Context,
    params: WorkerParameters,
) : CoroutineWorker(ctx, params) {

    companion object {
        private const val TAG = "GameAnalysis"
        private const val KEY_GAME_ID = "gameId"
        const val KEY_DONE = "done"
        const val KEY_TOTAL = "total"

        /** Tên work duy nhất của một ván. */
        fun uniqueName(gameId: String) = "game_analysis_$gameId"

        private fun queueFile(context: Context, gameId: String) =
            File(File(context.filesDir, "review_queue").apply { mkdirs() }, "$gameId.txt")

        /** Xóa file hàng đợi của một ván. */
        fun discardQueue(context: Context, gameId: String) {
            runCatching { queueFile(context.applicationContext, gameId).delete() }
            PreAnalysisCache.delete(context.applicationContext, gameId)
        }

        /**
         * Gọi khi ván kết thúc (hoặc khi mở một ván chưa có kết quả). FEN đầu ván + các nước UCI được ghi ra file
         * thay vì nhét vào inputData vì Data của WorkManager giới hạn 10KB — ván dài sẽ crash.
         *
         * [replace] = true: hủy work cũ (đã thất bại/kẹt) và xếp lại. Mặc định KEEP: đang chờ/đang chạy thì không đụng.
         * KHÔNG gọi setExpedited(): work chạy ở mức ưu tiên thường, nhường tài nguyên cho app đang mở.
         */
        fun enqueueAnalysis(
            context: Context,
            gameId: String,
            startFen: String,
            ucis: List<String>,
            replace: Boolean = false,
        ) {
            val app = context.applicationContext
            val qf = queueFile(app, gameId)
            val tmp = File(qf.parentFile, qf.name + ".tmp")
            tmp.writeText(ReviewReplay.encodeQueue(startFen, ucis))
            if (!tmp.renameTo(qf)) { qf.delete(); tmp.renameTo(qf) }

            // KHÔNG đặt ràng buộc pin/sạc/mạng: phân tích luôn chạy ngay, pin yếu cũng chạy (người dùng yêu cầu).

            val req = OneTimeWorkRequestBuilder<GameAnalysisWorker>()
                .setInputData(workDataOf(KEY_GAME_ID to gameId))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(app).enqueueUniqueWork(
                uniqueName(gameId),
                if (replace) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                req,
            )
        }
    }

    // Dispatchers.Default: không chiếm Main/IO; engine (tiến trình riêng) được hạ ưu tiên ở SilentStockfishEngine.
    override suspend fun doWork(): Result = withContext(Dispatchers.Default) {
        val gameId = inputData.getString(KEY_GAME_ID) ?: return@withContext Result.failure()
        val repo = ReviewRepository.get(applicationContext)
        // Đã có kết quả hợp lệ trong Room => xong (file hàng đợi còn sót thì dọn).
        if (repo.exists(gameId)) { discardQueue(applicationContext, gameId); return@withContext Result.success() }

        val qf = queueFile(applicationContext, gameId)
        if (!qf.exists()) return@withContext Result.failure()
        val replay = ReviewReplay.parseQueue(qf.readLines())
        if (replay == null) { qf.delete(); return@withContext Result.failure() }
        if (replay.plies.isEmpty()) { qf.delete(); return@withContext Result.success() }
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
        // Kết quả phân tích TRƯỚC (lúc ván còn đang chơi, xem PreAnalyzer): thế nào đã có và đủ sâu thì dùng lại, không tính lại.
        val pre = PreAnalysisCache.load(applicationContext, gameId)
        var reused = 0

        // Cấu hình engine theo máy (RAM + số nhân) — DeviceTierManager.
        val config = DeviceTierManager.getDeviceTier(applicationContext)
        val monitor = DeviceHealthMonitor(applicationContext)
        // niceLevel 15 (trước 10): hộp thoại Game Review đang chạy animation (nhãn + con mã) ngay lúc Worker tính, nhường thêm CPU cho luồng giao diện.
        val engine = SilentStockfishEngine(applicationContext, config, niceLevel = 15)

        try {
            val evals = ArrayList<EngineResult>(fens.size)
            for ((idx, fen) in fens.withIndex()) {
                ensureActive()
                setProgress(workDataOf(KEY_DONE to idx, KEY_TOTAL to fens.size))
                // Thế đã hết ván (chiếu hết/hòa) tính bằng luật cờ, không cần engine.
                val terminal = ReviewReplay.terminalEval(fen)
                if (terminal != null) { evals += terminal; continue }

                val cached = pre[fen]
                if (cached != null && PreAnalysisCache.acceptable(cached, config)) { evals += cached; reused++; continue }

                // Nóng > 40°C: stop + giải phóng engine, nghỉ vài giây rồi chạy tiếp (không retry, không bỏ dở).
                monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })   // nghỉ ngắn nếu nóng, rồi chạy tiếp

                evals += engine.analyzeSilently(fen, config.depth)
            }

            setProgress(workDataOf(KEY_DONE to fens.size, KEY_TOTAL to fens.size))

            // Vòng kiểm chứng: chỉ tìm lại SÂU HƠN những thế thuộc nước nghi sai (tối đa vài nước) để kết luận
            // Mistake/Blunder/Miss không bị oan do nhiễu độ sâu. Lỗi ở vòng này KHÔNG làm mất kết quả vòng đầu.
            val suspects = ReviewVerify.suspectPositions(replay.plies, evals)
            for (k in suspects) {
                ensureActive()
                try {
                    monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })
                    val deep = engine.analyzeSilently(fens[k], minOf(config.depth + 4, DeviceTierManager.MAX_DEPTH), config.moveTimeoutMs * 3)
                    if (deep.depthReached >= evals[k].depthReached) evals[k] = deep
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Bỏ qua vòng kiểm chứng: ${e.message}")
                    break
                }
            }

            // Chẩn đoán: depth / MultiPV THỰC TẾ trên máy này (không phải cấu hình) — xem Logcat tag "GameAnalysis" khi nhãn bị lệch.
            val diag = AnalysisDiagnostics.from(config, evals)
            Log.i(TAG, "Phân tích $gameId: ${diag.summary()} · dùng lại $reused/${fens.size} thế từ phân tích trước")
            diag.warnings().forEach { Log.w(TAG, "  ⚠ $it") }

            val review = ReviewAssembler.assemble(
                gameId, replay.startFen, replay.plies, evals,
                config.tier.name, System.currentTimeMillis(),
                book = OpeningBook.load(applicationContext),
            )
            Log.i(TAG, "Nhãn ván $gameId: " + review.moves.groupingBy { it.label }.eachCount().entries.joinToString(" ") { "${it.key}=${it.value}" })
            repo.save(review)     // Room (+ bản sao JSON): đây là lúc màn Review "thấy" kết quả
            qf.delete()
            PreAnalysisCache.delete(applicationContext, gameId)
            com.vila.chess.cloud.SupabaseCloud.pushReview(applicationContext, review)   // không ném lỗi
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: IllegalStateException) {
            // Engine không khởi động / không trả kết quả: retry vô ích.
            Log.e(TAG, "Lỗi phân tích: ${e.message}", e)
            Result.failure()
        } catch (e: Throwable) {
            // Mọi lỗi khác (parse, OOM, IO...) chỉ được log, không làm văng app.
            Log.e(TAG, "Lỗi phân tích: ${e.message}", e)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        } finally {
            // BẮT BUỘC: stop -> quit -> destroy, kể cả khi bị hủy (NonCancellable) để RAM luôn được trả lại.
            withContext(NonCancellable) { engine.shutdown() }
        }
    }
}
