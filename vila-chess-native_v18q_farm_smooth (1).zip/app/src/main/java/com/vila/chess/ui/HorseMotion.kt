package com.vila.chess.ui

import kotlin.math.cos
import kotlin.math.sin

/*
 * Chuyển động của con ngựa 3D (xem HorseMascot.kt cho phần vẽ). File này CHỈ chứa toán học thuần Kotlin
 * (không đụng Compose/Android) để unit test được.
 *
 * Một cú nhảy = tiến độ t ∈ [0, 1]:
 *   0.00 – 0.20  gom lực   : hạ thấp người, đạp chân sau ra sau, ngẩng đầu
 *   0.20 – 0.84  bay       : parabol, co chân ở đỉnh rồi duỗi chân trước ra đón mặt ô
 *   0.84 – 1.00  tiếp đất  : dẹt người (squash), nảy lại, bụi bay quanh chân
 * t ≤ 0 hoặc t ≥ 1 ⇒ đứng yên (thở, chớp mắt, bờm/đuôi đung đưa theo đồng hồ cảnh).
 */

internal const val HORSE_HOP_MS = 780
internal const val HORSE_WAIT_MS = 320L   // đứng chờ một nhịp trước khi nhảy ⇒ người chơi kịp thấy ngựa ở ô cũ

private const val PI_F = 3.1415927f
private const val TAU_F = 6.2831855f
private const val CROUCH_END = 0.20f
private const val LAND_START = 0.84f

private fun smooth(x: Float): Float {
    val c = x.coerceIn(0f, 1f)
    return c * c * (3f - 2f * c)
}

private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Trạng thái tạo dáng của ngựa ở một thời điểm. Một đối tượng dùng lại mỗi khung hình (không cấp phát). */
internal class HorseFrame {
    /** Tiến độ BAY dọc theo đường nối 2 ô: 0 = ô xuất phát, 1 = ô đáp. */
    var s = 0f
    /** Độ cao so với mặt ô, chuẩn hoá: 0 = chạm đất, 1 = đỉnh cung. Nhân với chiều cao cung (px) khi vẽ. */
    var lift = 0f
    /** Co giãn dọc quanh bàn chân (<1 = dẹt xuống, >1 = kéo dài). */
    var squashY = 1f
    /** Tư thế chân: 1 = co gọn hết cỡ, 0 = đứng, −1 = duỗi (chân trước ra trước, chân sau ra sau). */
    var legs = 0f
    /** Độ nghiêng thân (độ, âm = ngẩng mũi lên). */
    var pitch = 0f
    /** Gió đẩy bờm/đuôi: +1 = bị hất xuống/ra sau (đang lên), −1 = bị hất lên (đang rơi). */
    var swing = 0f
    /** Độ nhắm mắt 0..1. */
    var blink = 0f
    /** Bụi lúc tiếp đất: 0 = không có, (0,1] = tiến độ lan ra. */
    var dust = 0f

    /** [clock] là đồng hồ cảnh 0..1 lặp mỗi 24 giây; mọi nhịp idle dùng số chu kỳ NGUYÊN trên đồng hồ này ⇒ lặp liền mạch. */
    fun set(t: Float, clock: Float) {
        val breath = 0.012f * sin(clock * 8f * TAU_F)
        val idleSwing = 0.2f * sin(clock * 6f * TAU_F + 1f)
        val bp = (clock * 6f) % 1f
        blink = if (bp < 0.06f) sin(bp / 0.06f * PI_F) else 0f
        dust = 0f
        when {
            t <= 0f || t >= 1f -> {
                s = if (t >= 1f) 1f else 0f
                lift = 0f; squashY = 1f + breath; legs = 0f; pitch = 0f; swing = idleSwing
            }
            t < CROUCH_END -> {
                val u = smooth(t / CROUCH_END)
                s = 0f; lift = 0f
                squashY = 1f - 0.16f * u
                legs = -0.8f * u
                pitch = -14f * u
                swing = u   // bờm/đuôi bị hất ra sau lúc bật lên ⇒ khớp swing = cos(0) = 1 của pha bay
            }
            t < LAND_START -> {
                val q = (t - CROUCH_END) / (LAND_START - CROUCH_END)
                s = q
                lift = 4f * q * (1f - q)
                squashY = if (q < 0.25f) mix(0.84f, 1.1f, smooth(q / 0.25f)) else mix(1.1f, 1f, (q - 0.25f) / 0.75f)
                legs = when {
                    q < 0.40f -> mix(-0.8f, 1f, smooth(q / 0.40f))
                    q < 0.68f -> 1f
                    else -> mix(1f, -0.7f, smooth((q - 0.68f) / 0.32f))
                }
                pitch = mix(-14f, 10f, q)
                swing = cos(q * PI_F)
            }
            else -> {
                val u = (t - LAND_START) / (1f - LAND_START)
                s = 1f; lift = 0f
                squashY = 1f - 0.2f * sin(u * PI_F)
                legs = mix(-0.7f, 0f, smooth(u))
                pitch = mix(10f, 0f, smooth(u))
                swing = -(1f - u)   // khớp swing = cos(π) = −1 cuối pha bay, rồi lắng về 0
                dust = u
            }
        }
    }
}
