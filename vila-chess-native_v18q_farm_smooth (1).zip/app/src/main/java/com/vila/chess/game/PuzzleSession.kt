package com.vila.chess.game

import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_CASTLE
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.Position
import com.vila.chess.core.QUEEN
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.moveFlag
import com.vila.chess.core.moveFrom
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo

// ════════════════════════════════════════════════════════════════════════════════════════════
//  LOGIC CÂU ĐỐ (thuần Kotlin, không phụ thuộc Android/Compose ⇒ test được bằng JVM)
//
//  Định dạng Lichess:
//    • FEN        = thế cờ TRƯỚC nước đi đầu tiên của đối thủ.
//    • Moves      = chuỗi UCI cách nhau bởi dấu cách:  moves[0] là nước của ĐỐI THỦ (đi tự động),
//                   moves[1] là nước người chơi phải tìm, moves[2] là đối thủ đáp lại, moves[3] … cứ thế xen kẽ.
//    • Người chơi cầm quân của bên đi sau nước moves[0].
// ════════════════════════════════════════════════════════════════════════════════════════════

/** 1 câu đố. [level] = số Level trên bản đồ (cột `id` trong puzzles.db). */
data class Puzzle(
    val level: Int,
    val puzzleId: String,
    val fen: String,
    val moves: List<String>,
    val rating: Int,
    val themes: List<String>,
)

/** Kết quả của một lần người chơi thả quân. */
sealed class PuzzleStep {
    /** Không phải nước hợp lệ (quân sai màu, đi không đúng luật…) ⇒ UI chỉ đưa quân về, không tính lỗi. */
    object Illegal : PuzzleStep()

    /** Hợp lệ nhưng không phải nước trong lời giải ⇒ UI lắc quân. Thế cờ KHÔNG đổi. */
    object Wrong : PuzzleStep()

    /**
     * Đúng. [reply] = nước đối thủ đáp lại (null nếu câu đố đã xong). [solved] = đã giải xong toàn bộ.
     * [boardAfterPlayer] = bàn cờ ngay sau nước của người chơi, TRƯỚC khi đối thủ đáp (để UI chạy animation từng nước).
     */
    class Correct(
        val playerMove: Int,
        val reply: Int?,
        val solved: Boolean,
        val boardAfterPlayer: IntArray,
        /** Loại tiếng của nước người chơi / nước đối thủ đáp (null nếu không có nước đáp). */
        val playerSfx: Sfx = Sfx.MOVE,
        val replySfx: Sfx? = null,
    ) : PuzzleStep()
}

/** "e2e4" / "e7e8q" → nước đi mã hoá của engine, hoặc null nếu không hợp lệ trong [pos]. */
fun parseUciMove(pos: Position, uci: String): Int? {
    if (uci.length < 4) return null
    val ff = uci[0] - 'a'
    val fr = uci[1] - '1'
    val tf = uci[2] - 'a'
    val tr = uci[3] - '1'
    if (ff !in 0..7 || fr !in 0..7 || tf !in 0..7 || tr !in 0..7) return null
    val from = fr * 8 + ff
    val to = tr * 8 + tf
    val promo = if (uci.length >= 5) "??nbrq".indexOf(uci[4].lowercaseChar()).coerceAtLeast(0) else 0
    for (m in pos.legalMoves()) {
        if (moveFrom(m) == from && moveTo(m) == to && movePromo(m) == promo) return m
    }
    return null
}

class PuzzleSession(val puzzle: Puzzle) {
    private val pos: Position = Position.fromFen(puzzle.fen)

    /** Bàn cờ TRƯỚC nước đầu của đối thủ (để UI chạy animation đối thủ đi). */
    val boardBefore: IntArray = pos.board.copyOf()

    /** Nước đầu tiên của đối thủ (đã mã hoá), -1 nếu dữ liệu hỏng. */
    val setupMove: Int

    /** Loại tiếng của nước đầu của đối thủ (setupMove). */
    var setupSfx: Sfx = Sfx.MOVE
        private set

    /** false ⇒ dữ liệu câu đố hỏng (FEN/Moves sai); UI báo lỗi và cho phép bỏ qua. */
    val valid: Boolean

    /** Người chơi cầm quân Trắng? (= bên đi sau nước đầu của đối thủ). */
    val playerWhite: Boolean

    private var next = 1
    var solved: Boolean = false
        private set

    init {
        val setup = if (puzzle.moves.size >= 2) parseUciMove(pos, puzzle.moves[0]) else null
        if (setup == null) {
            setupMove = -1
            valid = false
            playerWhite = pos.whiteToMove
        } else {
            setupMove = setup
            valid = true
            setupSfx = makeAndClassify(setup)
            playerWhite = pos.whiteToMove
        }
    }

    /** Đi nước [m] trên [pos] và trả về loại tiếng tương ứng (ưu tiên giống ván đấu: chiếu > phong cấp > nhập thành > ăn > đi). */
    private fun makeAndClassify(m: Int): Sfx {
        val capture = pos.board[moveTo(m)] != EMPTY || moveFlag(m) == FLAG_EP
        pos.make(m)
        return when {
            pos.inCheck() -> Sfx.CHECK
            movePromo(m) != 0 -> Sfx.PROMOTE
            moveFlag(m) == FLAG_CASTLE -> Sfx.CASTLE
            capture -> Sfx.CAPTURE
            else -> Sfx.MOVE
        }
    }

    /** Bàn cờ hiện tại (bản sao – UI được phép giữ). */
    fun board(): IntArray = pos.board.copyOf()

    /** Quân tại [sq] có phải của người chơi không. */
    fun isPlayerPiece(sq: Int): Boolean {
        val pc = pos.board[sq]
        return pc != EMPTY && isWhitePiece(pc) == playerWhite
    }

    /** Các ô đến hợp lệ của quân ở [from] (để hiện chấm gợi ý). */
    fun legalTargets(from: Int): List<Int> {
        if (!valid || solved || !isPlayerPiece(from)) return emptyList()
        val out = ArrayList<Int>()
        for (m in pos.legalMoves()) if (moveFrom(m) == from && moveTo(m) !in out) out.add(moveTo(m))
        return out
    }

    /** (ô đi, ô đến) của nước đúng kế tiếp – dùng cho nút Gợi ý. */
    fun hint(): Pair<Int, Int>? {
        if (!valid || solved || next >= puzzle.moves.size) return null
        val m = parseUciMove(pos, puzzle.moves[next]) ?: return null
        return moveFrom(m) to moveTo(m)
    }

    private fun deliversMate(m: Int): Boolean {
        val side = pos.whiteToMove
        pos.make(m)
        val mate = pos.inCheck(!side) && pos.legalMoves().isEmpty()
        pos.unmake()
        return mate
    }

    /**
     * Người chơi đi quân từ [from] sang [to].
     * Đúng ⇔ trùng nước trong lời giải, HOẶC (giống Lichess) là một nước chiếu hết bất kỳ.
     */
    fun submit(from: Int, to: Int): PuzzleStep {
        if (!valid || solved || next >= puzzle.moves.size) return PuzzleStep.Illegal
        val candidates = pos.legalMoves().filter { moveFrom(it) == from && moveTo(it) == to }
        if (candidates.isEmpty()) return PuzzleStep.Illegal

        val expected = parseUciMove(pos, puzzle.moves[next])
        // Phong cấp: nếu trúng lời giải thì lấy đúng quân phong, ngược lại mặc định Hậu.
        val m = candidates.firstOrNull { it == expected }
            ?: candidates.firstOrNull { movePromo(it) == QUEEN || movePromo(it) == 0 }
            ?: candidates[0]

        val mate = deliversMate(m)
        if (m != expected && !mate) return PuzzleStep.Wrong

        val playerSfx = makeAndClassify(m)
        val afterPlayer = pos.board.copyOf()
        next++
        if (mate || next >= puzzle.moves.size) {
            solved = true
            return PuzzleStep.Correct(m, null, true, afterPlayer, playerSfx)
        }
        val reply = parseUciMove(pos, puzzle.moves[next])
        if (reply == null) {          // dữ liệu hỏng ở giữa chuỗi: coi như đã xong để người chơi không bị kẹt
            solved = true
            return PuzzleStep.Correct(m, null, true, afterPlayer, playerSfx)
        }
        val replySfx = makeAndClassify(reply)
        next++
        if (next >= puzzle.moves.size) solved = true
        return PuzzleStep.Correct(m, reply, solved, afterPlayer, playerSfx, replySfx)
    }
}

// ───────────────────────────────────────────────────────────── Văn bản hiển thị

/** "Trắng" / "Đen" – bên người chơi cầm. */
fun puzzleSideName(playerWhite: Boolean): String = if (playerWhite) "Trắng" else "Đen"

/** Mục tiêu hiển thị, lấy từ cột `themes` (vd "mateIn2 short" ⇒ "Chiếu hết trong 2 nước"). */
fun puzzleGoalText(p: Puzzle): String {
    val t = p.themes
    val mateIn = t.firstOrNull { it.startsWith("mateIn") }?.removePrefix("mateIn")?.toIntOrNull()
    return when {
        mateIn != null -> "Chiếu hết trong $mateIn nước"
        "mate" in t -> "Chiếu hết đối thủ"
        "fork" in t || "pin" in t || "skewer" in t || "hangingPiece" in t || "trappedPiece" in t -> "Giành quân"
        "promotion" in t -> "Phong cấp"
        "equality" in t -> "Cầm hòa"
        "advantage" in t || "crushing" in t -> "Giành lợi thế"
        else -> "Tìm nước đi tốt nhất"
    }
}

/** Số nước người chơi phải đi để giải xong (moves[0] là nước của đối thủ; người chơi đi ở vị trí lẻ 1, 3, 5…). */
fun puzzlePlayerMoveCount(p: Puzzle): Int = (p.moves.size / 2).coerceAtLeast(1)

/**
 * Lời nhắc của thầy hiện trong bong bóng thoại (ngắn, ≤ ~100 ký tự để vừa 3 dòng trên màn hình hẹp).
 * Lấy theo chủ đề Lichess trong cột `themes`; không có chủ đề quen thuộc thì nhắc cách nhìn thế cờ chung.
 */
fun puzzleCoachTip(p: Puzzle): String {
    val t = p.themes
    val mateIn = t.firstOrNull { it.startsWith("mateIn") }?.removePrefix("mateIn")?.toIntOrNull()
    return when {
        mateIn == 1 -> "Có một nước chiếu hết ngay. Hãy xem mọi nước chiếu của bạn!"
        mateIn != null -> "Chiếu hết trong $mateIn nước. Hãy bắt đầu từ các nước chiếu, ép vua đối thủ vào đường cùng!"
        "backRankMate" in t -> "Vua đối thủ bị chính quân mình chặn ở hàng cuối. Hãy khai thác điều đó!"
        "mate" in t -> "Vua đối thủ đang rất nguy hiểm. Hãy tìm chuỗi nước ép chiếu hết!"
        "fork" in t -> "Một quân của bạn có thể tấn công hai quân cùng lúc. Hãy tìm đòn đôi (fork)!"
        "pin" in t -> "Hãy ghim một quân: nó không dám rời đi vì sẽ làm lộ quân quan trọng hơn phía sau."
        "skewer" in t -> "Tấn công quân lớn để nó phải chạy, rồi ăn quân nằm sau nó (đòn xiên)."
        "discoveredAttack" in t -> "Dời một quân để mở đường cho quân phía sau tấn công (đòn mở đường)."
        "hangingPiece" in t -> "Có quân đối thủ đang không được bảo vệ. Bạn thấy nó không?"
        "trappedPiece" in t -> "Có quân đối thủ gần hết đường thoát. Hãy giăng bẫy nó!"
        "promotion" in t -> "Tốt của bạn sắp phong cấp. Hãy mở đường đưa nó lên hàng cuối!"
        "sacrifice" in t -> "Hy sinh một quân đôi khi đem lại lợi thế lớn hơn. Hãy tính kỹ!"
        "defensiveMove" in t -> "Thế cờ đang khó cho bạn. Hãy tìm nước phòng thủ chính xác nhất."
        "equality" in t -> "Bạn đang kém thế. Hãy tìm nước đi để cầm hòa."
        "endgame" in t -> "Tàn cuộc: mỗi nước đi đều quan trọng. Hãy tính cẩn thận."
        "advantage" in t || "crushing" in t -> "Có một nước đi tạo lợi thế lớn. Hãy tìm nó!"
        else -> "Hãy nhìn kỹ thế cờ: quân nào đang bị đe doạ, quân nào đang bị hở?"
    }
}
