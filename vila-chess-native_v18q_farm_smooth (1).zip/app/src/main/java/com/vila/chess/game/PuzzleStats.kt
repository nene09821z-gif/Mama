package com.vila.chess.game

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Điểm câu đố (kiểu chess.com: số lớn bên trái thanh tiến độ) + chuỗi giải đúng liên tiếp (biểu tượng ngọn lửa).
 *  • [rating]: điểm Elo câu đố, tăng khi giải sạch câu khó hơn mình, giảm khi sai nhiều câu dễ. Lưu SharedPreferences.
 *  • [streak]: số câu giải liên tiếp KHÔNG sai nước nào; sai một nước là về 0.
 * Hai giá trị là Compose state ⇒ màn giải và bản đồ tự cập nhật, không cần ViewModel trung gian.
 */
object PuzzleStats {
    private const val PREFS = "vila_puzzle_stats"
    private const val KEY_RATING = "rating"
    private const val KEY_STREAK = "streak"
    const val START_RATING = 600
    const val MIN_RATING = 100

    var rating by mutableIntStateOf(START_RATING)
        private set
    var streak by mutableIntStateOf(0)
        private set
    private var loaded = false

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        rating = p.getInt(KEY_RATING, START_RATING).coerceAtLeast(MIN_RATING)
        streak = p.getInt(KEY_STREAK, 0).coerceAtLeast(0)
        loaded = true
    }

    /** Gọi ĐÚNG MỘT LẦN cho mỗi câu, ngay ở nước sai đầu tiên: chuỗi về 0. */
    fun onMistake(ctx: Context) {
        load(ctx)
        if (streak != 0) {
            streak = 0
            save(ctx)
        }
    }

    /** Gọi khi giải xong câu CÓ TÍNH ĐIỂM. Trả về số điểm đổi (âm = bị trừ) để màn hình hiện "+N". */
    fun onSolved(ctx: Context, puzzleRating: Int, mistakes: Int): Int {
        load(ctx)
        val d = puzzleRatingDelta(rating, puzzleRating, mistakes)
        rating = (rating + d).coerceAtLeast(MIN_RATING)
        streak = if (mistakes == 0) streak + 1 else 0
        save(ctx)
        return d
    }

    private fun save(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY_RATING, rating).putInt(KEY_STREAK, streak).apply()
    }
}

private const val ELO_K = 24.0   // hệ số Elo: mỗi câu dao động tối đa ~24 điểm

/**
 * Thay đổi điểm sau một câu đố (hàm thuần, test được trên JVM). [mistakes] > 0 ⇒ chỉ tính 0,3 điểm thắng thay vì 1.
 * Giải sạch luôn được ít nhất +1; giải sau khi sai không bao giờ được cộng quá +K/2.
 */
fun puzzleRatingDelta(playerRating: Int, puzzleRating: Int, mistakes: Int): Int {
    val expected = 1.0 / (1.0 + 10.0.pow((puzzleRating - playerRating) / 400.0))
    val score = if (mistakes == 0) 1.0 else 0.3
    val d = (ELO_K * (score - expected)).roundToInt()
    return if (mistakes == 0) d.coerceAtLeast(1) else d.coerceAtMost((ELO_K / 2).toInt())
}
