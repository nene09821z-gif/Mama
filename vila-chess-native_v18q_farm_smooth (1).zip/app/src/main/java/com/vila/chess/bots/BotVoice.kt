package com.vila.chess.bots

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Giọng đọc của bot: cao độ + tốc độ riêng từng bot, dùng TextToSpeech có sẵn trên máy (offline nếu máy đã tải giọng tiếng Việt). */
class BotVoice(context: Context) {
    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                val r = engine.setLanguage(Locale("vi", "VN"))
                ready = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    /** Đọc [text] bằng giọng của [bot]; câu mới cắt câu đang đọc. Máy không có giọng tiếng Việt thì im lặng. */
    fun speak(bot: BotProfile, text: String) {
        val engine = tts ?: return
        if (!ready) return
        val v = BotPersonality.voiceOf(bot.id)
        engine.setPitch(v.pitch)
        engine.setSpeechRate(v.rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bot_" + bot.id)
    }

    fun stop() {
        tts?.stop()
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
