package com.vila.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.review.DeviceTier
import com.vila.chess.review.DeviceTierManager
import kotlin.math.sin
import kotlin.random.Random

// =============================================================================
// v18 — VÙNG BỊ KHOÁ của bản đồ Câu đố (theo ảnh mẫu chess.com)
//
// Quy tắc: vùng r bị khoá khi r > vùng của level đang chơi (chưa xong vùng trước ⇒ chưa vào được vùng sau).
//   • Nền: băng xám-lam (FrostGround) thay cho nền chủ đề; KHÔNG dựng vật cảnh (nhẹ máy, và đúng ý "bí ẩn").
//   • Ô khối: màu "đóng băng" nhạt, xen kẽ sáng/tối như bàn cờ, số mờ, không bấm được (NodeState.Locked sẵn có).
//   • Mây: FogLayer phủ LÊN các ô – 2 bên luôn có mây, giữa đường đi bị mây che dày dần theo độ cao
//     (8 level đầu của vùng khoá còn thấy rõ, ~25 level sau là mây kín) + màn sương trắng-lam tăng dần.
//   • Mở khoá (xong level cuối của vùng): mây của vùng vừa mở tan dần trong 1,4 s.
//   • Nút mũi tên "về câu đố hiện tại" khi level hiện tại ra khỏi màn hình; chip gợi ý "còn X câu để mở khoá".
//
// Hiệu năng: mỗi khối 16 level là MỘT Canvas tĩnh (vẽ 1 lần, cuộn bằng graphicsLayer.translationY như SceneryBlock);
// mây trôi nhẹ chỉ là translationX đọc từ đồng hồ chung trong graphicsLayer (không recomposition, không vẽ lại).
// =============================================================================

// ─────────────────────────────────────────────────────────── Quy tắc (hàm thuần, có test)

/** Vùng [region] bị khoá khi người chơi chưa tới vùng đó. */
internal fun isRegionLocked(region: Int, currentRegion: Int): Boolean = region > currentRegion

/** Số câu còn lại của vùng chứa [currentLevel] (tính cả câu đang chơi) = số câu phải giải để mở vùng kế tiếp. */
internal fun levelsToUnlock(currentLevel: Int): Int =
    (regionOfLevel(currentLevel) + 1) * LEVELS_PER_REGION - currentLevel.coerceAtLeast(1) + 1

/** Mức mây che đường đi ở độ cao [levelsAbove] (số level tính từ ranh giới vùng khoá): 0 ≤ 7 level, 1 từ 25 level. */
internal fun fogCover(levelsAbove: Float): Float = ((levelsAbove - 7f) / 18f).coerceIn(0f, 1f)

/** Độ đậm màn sương: 0 tại ranh giới (không lộ đường ranh), tăng tới 0,44 sau 96 level. */
internal fun fogHazeAlpha(levelsAbove: Float): Float = 0.44f * (levelsAbove / 96f).coerceIn(0f, 1f)

// ─────────────────────────────────────────────────────────── Màu

private val FrostBase = Color(0xFF8FA1A9)
private val FrostDiamond = Color(0x1AFFFFFF)
private val FogHaze = Color(0xFFE3F0F2)
private val CloudOutline = Color(0xFF9CCDD4)
private val CloudShade = Color(0xFFC6E2E7)
private val CloudFill = Color(0xFFF6F7EC)
private val CloudLight = Color(0x8CFFFFFF)

/** Thanh tiêu đề / đáy khi đang xem vùng khoá (thay cho màu chủ đề). */
internal val LockedBanner = Color(0xCC3C4E57)

/** Ô khối "đóng băng": xen kẽ theo số level (như ô cờ). */
internal fun frozenTop(level: Int): Color = if (level % 2 == 0) Color(0xFF8798A8) else Color(0xFFD3E3EA)
internal fun frozenSide(level: Int): Color = if (level % 2 == 0) Color(0xFF66768B) else Color(0xFFA9BCC8)

// ─────────────────────────────────────────────────────────── Nền băng

/** Màu cuối của vùng bên dưới khối đầu vùng – để nền mờ dần sang đó, không có đường ranh gắt (cùng quy tắc ChapterGround). */
internal fun regionFadeColor(chapter: Int): Color? =
    if (chapter > 0 && chapter % BLOCKS_PER_REGION == 0) {
        puzzleChapterFor(chapter / BLOCKS_PER_REGION - 1).ground?.let { lerp(it.top, it.bottom, 0.5f) } ?: Color(0xFF1C4A2A)
    } else null

/** Nền của khối thuộc vùng khoá: xám-lam, ô kim cương mờ cùng ngôn ngữ nền chủ đề, vài vệt sáng và hạt băng. Vẽ một lần. */
@Composable
internal fun FrostGround(chapter: Int, modifier: Modifier = Modifier) {
    val prev = remember(chapter) { regionFadeColor(chapter) }
    Canvas(modifier) {
        drawRect(FrostBase)

        val w = 95.dp.toPx()
        val h = 48.dp.toPx()
        val path = Path()
        var r = 0
        var y = 0f
        while (y < size.height + h) {
            var x = if (r % 2 == 0) 0f else w
            while (x < size.width + w) {
                path.reset()
                path.moveTo(x, y - h); path.lineTo(x + w, y); path.lineTo(x, y + h); path.lineTo(x - w, y); path.close()
                drawPath(path, FrostDiamond)
                x += 2 * w
            }
            y += h
            r++
        }

        val rnd = Random(chapter * 104729 + 17)
        repeat(7) {
            val rad = (70 + rnd.nextInt(90)).dp.toPx()
            val cx = rnd.nextFloat() * size.width
            val cy = rad + rnd.nextFloat() * (size.height - 2 * rad).coerceAtLeast(0f)
            drawCircle(Brush.radialGradient(listOf(Color(0x40FFFFFF), Color.Transparent), Offset(cx, cy), rad), rad, Offset(cx, cy))
        }
        repeat(60) {
            val rad = (1f + rnd.nextFloat() * 1.8f).dp.toPx()
            drawCircle(Color.White.copy(alpha = 0.18f + rnd.nextFloat() * 0.4f), rad, Offset(rnd.nextFloat() * size.width, rnd.nextFloat() * size.height))
        }
        if (prev != null) drawRegionFade(prev)
    }
}

// ─────────────────────────────────────────────────────────── Mây

/** [cx], [cy]: tâm mây (tỉ lệ bề rộng / chiều cao khối) · [w]: bề rộng mây (tỉ lệ bề rộng khối) · [template] 0..2 · [mirror]: lật ngang. */
@Immutable
internal class CloudSpec(val cx: Float, val cy: Float, val w: Float, val template: Int, val mirror: Boolean)

/** Mỗi mây = các "cục" (x, y, bán kính) tính theo bề rộng mây; x ∈ [−0,5; 0,5]. */
private val CloudTemplates = arrayOf(
    floatArrayOf(-0.30f, 0.06f, 0.16f, -0.12f, -0.06f, 0.22f, 0.12f, -0.10f, 0.24f, 0.32f, 0.04f, 0.17f, 0.00f, 0.08f, 0.20f),
    floatArrayOf(-0.33f, 0.07f, 0.14f, -0.15f, -0.03f, 0.19f, 0.02f, -0.12f, 0.25f, 0.22f, -0.04f, 0.20f, 0.36f, 0.07f, 0.13f, 0.05f, 0.09f, 0.18f),
    floatArrayOf(-0.28f, 0.05f, 0.18f, -0.02f, -0.08f, 0.27f, 0.27f, 0.02f, 0.20f, -0.10f, 0.10f, 0.17f, 0.14f, 0.10f, 0.15f),
)

private const val FOG_ROWS = 8   // 8 hàng mây mỗi khối = mỗi hàng 2 level

/**
 * Bố cục mây của khối [chapter]; [d] = số khối kể từ ranh giới vùng khoá (0 = khối sát ranh giới).
 * Hai bên luôn có mây; giữa đường đi chỉ có mây khi [fogCover] > 0 (ngày càng dày). Thuần túy và xác định ⇒ test được.
 * Kết quả sắp theo cy tăng dần (mây thấp vẽ sau, đè lên mây cao như phối cảnh isometric).
 */
internal fun buildClouds(chapter: Int, d: Int): List<CloudSpec> {
    val rnd = Random(chapter * 7919 + 13)
    val out = ArrayList<CloudSpec>(FOG_ROWS * 4)
    for (row in 0 until FOG_ROWS) {
        val y = (row + 0.5f) / FOG_ROWS
        val cover = fogCover((d + (1f - y)) * SCENE_LEVELS)
        // Hai bên
        out.add(CloudSpec(-0.02f + rnd.nextFloat() * 0.14f, y + (rnd.nextFloat() - 0.5f) * 0.05f, 0.46f + rnd.nextFloat() * 0.16f, rnd.nextInt(3), rnd.nextBoolean()))
        out.add(CloudSpec(0.86f + rnd.nextFloat() * 0.14f, y + (rnd.nextFloat() - 0.5f) * 0.05f, 0.46f + rnd.nextFloat() * 0.16f, rnd.nextInt(3), rnd.nextBoolean()))
        // Giữa đường đi
        if (cover > 0f) {
            val jitter = (rnd.nextFloat() - 0.5f) * 0.12f
            val roll = rnd.nextFloat()
            if (cover > 0.7f) {
                // Kín: hai mây lớn cạnh nhau phủ hết đường 22%–78%.
                out.add(CloudSpec(0.32f + jitter, y + (rnd.nextFloat() - 0.5f) * 0.05f, 0.56f + rnd.nextFloat() * 0.14f, rnd.nextInt(3), rnd.nextBoolean()))
                out.add(CloudSpec(0.68f - jitter, y + (rnd.nextFloat() - 0.5f) * 0.05f, 0.56f + rnd.nextFloat() * 0.14f, rnd.nextInt(3), rnd.nextBoolean()))
            } else if (roll < cover * 1.15f) {
                out.add(CloudSpec(0.22f + rnd.nextFloat() * 0.56f, y + (rnd.nextFloat() - 0.5f) * 0.05f, 0.44f + rnd.nextFloat() * 0.18f, rnd.nextInt(3), rnd.nextBoolean()))
            }
        }
    }
    out.sortBy { it.cy }
    return out
}

/** Một đám mây: viền xanh ngọc → bóng xanh nhạt lệch xuống → thân kem → vệt sáng; viền chung của các cục nên cả đám có MỘT đường viền. */
private fun DrawScope.drawCloud(c: CloudSpec) {
    val t = CloudTemplates[c.template]
    val wpx = c.w * size.width
    val cx = c.cx * size.width
    val cy = c.cy * size.height
    val sgn = if (c.mirror) -1f else 1f
    val line = 4.dp.toPx()
    val n = t.size / 3
    for (i in 0 until n) {
        drawCircle(CloudOutline, t[3 * i + 2] * wpx + line, Offset(cx + sgn * t[3 * i] * wpx, cy + t[3 * i + 1] * wpx))
    }
    for (i in 0 until n) {
        val r = t[3 * i + 2] * wpx
        drawCircle(CloudShade, r, Offset(cx + sgn * t[3 * i] * wpx, cy + t[3 * i + 1] * wpx + r * 0.12f))
    }
    for (i in 0 until n) {
        val r = t[3 * i + 2] * wpx
        drawCircle(CloudFill, r * 0.97f, Offset(cx + sgn * t[3 * i] * wpx, cy + t[3 * i + 1] * wpx - r * 0.06f))
    }
    for (i in 0 until n) {
        val r = t[3 * i + 2] * wpx
        drawCircle(CloudLight, r * 0.42f, Offset(cx + sgn * t[3 * i] * wpx - sgn * r * 0.32f, cy + t[3 * i + 1] * wpx - r * 0.38f))
    }
}

private fun DrawScope.drawFogBlock(clouds: List<CloudSpec>, hazeTop: Float, hazeBottom: Float) {
    val ext = 24.dp.toPx()   // rộng hơn khối để mây trôi ngang không lộ mép
    drawRect(
        Brush.verticalGradient(listOf(FogHaze.copy(alpha = hazeTop), FogHaze.copy(alpha = hazeBottom))),
        topLeft = Offset(-ext, 0f),
        size = Size(size.width + 2 * ext, size.height),
    )
    for (c in clouds) drawCloud(c)
}

private const val FOG_TWO_PI = (2.0 * Math.PI).toFloat()

/** true ⇒ cho mây trôi nhẹ (tắt trên máy yếu). */
@Composable
internal fun rememberFogDrift(): Boolean {
    val ctx = LocalContext.current
    return remember { runCatching { DeviceTierManager.getDeviceTier(ctx).tier != DeviceTier.LOW }.getOrDefault(true) }
}

/**
 * Lớp mây phủ LÊN danh sách ô (đặt sau LazyColumn). Chỉ dựng tối đa 3 khối quanh vị trí cuộn, chỉ những khối thuộc vùng khoá
 * (hoặc vùng [fadingRegion] vừa mở khoá: mây mờ dần theo [fade] 1 → 0). Canvas không nhận chạm ⇒ cuộn / bấm ô bên dưới bình thường.
 */
@Composable
internal fun FogLayer(
    listState: LazyListState,
    topId: Int,
    blockH: Dp,
    screenW: Dp,
    currentRegion: Int,
    fadingRegion: Int,
    fade: State<Float>,
    clock: State<Float>,
    drift: Boolean,
) {
    val lastBlock = ((topId - 1) / SCENE_LEVELS).coerceAtLeast(0)
    val firstBlock by remember(listState, topId) {
        derivedStateOf { ((topId - listState.firstVisibleItemIndex - 1) / SCENE_LEVELS).coerceIn(0, lastBlock) }
    }
    for (k in (firstBlock - 1).coerceAtLeast(0)..(firstBlock + 1).coerceAtMost(lastBlock)) {
        val chapter = lastBlock - k
        val region = chapter / BLOCKS_PER_REGION
        val fading = region == fadingRegion
        if (!isRegionLocked(region, currentRegion) && !fading) continue
        key(k) {
            val firstLocked = if (fading) fadingRegion else currentRegion + 1
            val d = chapter - firstLocked * BLOCKS_PER_REGION
            val clouds = remember(chapter, d) { buildClouds(chapter, d) }
            val hazeBottom = fogHazeAlpha(d * SCENE_LEVELS.toFloat())
            val hazeTop = fogHazeAlpha((d + 1) * SCENE_LEVELS.toFloat())
            val phase = chapter * 1.7f
            Canvas(
                Modifier
                    .wrapContentSize(Alignment.TopStart, unbounded = true)
                    .requiredSize(screenW, blockH)
                    .graphicsLayer {
                        val base = listState.layoutInfo.visibleItemsInfo.firstOrNull()
                        if (base == null) {
                            alpha = 0f
                        } else {
                            alpha = if (fading) fade.value else 1f
                            val topIndex = topId - (k + 1) * SCENE_LEVELS
                            translationY = listState.layoutInfo.beforeContentPadding + base.offset + (topIndex - base.index) * base.size.toFloat()
                            translationX = if (drift) sin(clock.value * FOG_TWO_PI + phase) * 5f * density else 0f
                        }
                    }
            ) { drawFogBlock(clouds, hazeTop, hazeBottom) }
        }
    }
}

// ─────────────────────────────────────────────────────────── Nút "về câu đố hiện tại" + chip gợi ý

/** Nút vuông bo góc, mũi tên có thân (như ảnh mẫu). [down] = level hiện tại nằm DƯỚI màn hình. */
@Composable
internal fun JumpToCurrentButton(visible: Boolean, down: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn() + scaleIn(initialScale = 0.7f),
        exit = fadeOut() + scaleOut(targetScale = 0.7f),
    ) {
        val shape = RoundedCornerShape(14.dp)
        Box(
            Modifier
                .size(50.dp)
                .drawBehind { drawRoundRect(Color(0xFF2B3739), Offset(0f, 3.dp.toPx()), Size(size.width, size.height - 2.dp.toPx()), CornerRadius(14.dp.toPx())) }
                .clip(shape)
                .background(Color(0xF2465659))
                .semantics { role = Role.Button; contentDescription = "Về câu đố hiện tại" }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(26.dp)) {
                val s = size.width
                val sw = s * 0.16f
                val dir = if (down) 1f else -1f
                val cx = s / 2f
                drawLine(Color.White, Offset(cx, s * 0.5f - dir * s * 0.34f), Offset(cx, s * 0.5f + dir * s * 0.34f), sw, StrokeCap.Round)
                val head = Path().apply {
                    moveTo(cx - s * 0.30f, s * 0.5f + dir * s * 0.06f)
                    lineTo(cx, s * 0.5f + dir * s * 0.36f)
                    lineTo(cx + s * 0.30f, s * 0.5f + dir * s * 0.06f)
                }
                drawPath(head, Color.White, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

/** Chip nổi dưới tiêu đề khi đang xem vùng khoá: ổ khoá + lời nhắc. */
@Composable
internal fun LockedHint(visible: Boolean, text: String, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = visible, modifier = modifier, enter = fadeIn(), exit = fadeOut()) {
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(Color(0xD92B3A42))
                .padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Lock, null, tint = Color(0xFFCFE3EA), modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
        }
    }
}
