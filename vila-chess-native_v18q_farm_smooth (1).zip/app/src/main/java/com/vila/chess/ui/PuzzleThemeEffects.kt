package com.vila.chess.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import com.vila.chess.review.DeviceTier
import com.vila.chess.review.DeviceTierManager
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// =============================================================================
// v17v — Hiệu ứng riêng của từng chủ đề (vùng)
//
//  • Lớp hạt môi trường phủ toàn màn hình (Canvas, KHÔNG nhận chạm):
//      Rừng xanh → đom đóm + lá rơi · Giáng sinh → tuyết rơi 3 lớp · Sa mạc → bụi cát bay + tàn lửa núi lửa
//      Không gian → sao nhấp nháy + sao băng · Biển sâu → bong bóng nổi + tia nắng đung đưa
//  • Vật cảnh chuyển động nhẹ (cây đung đưa, sứa/hành tinh/tên lửa lơ lửng) – chỉ vài loại, xem [propMotion].
//
// Hiệu năng: MỘT đồng hồ vô hạn duy nhất (24 s/vòng, tuyến tính) đọc trong draw phase ⇒ không recomposition.
// Vị trí hạt là hàm thuần của (hạt, t) với số chu kỳ NGUYÊN trong mỗi vòng ⇒ lặp vòng không giật.
// Số hạt giảm theo cấu hình máy (DeviceTier): yếu 40% · trung bình 70% · mạnh 100%.
// =============================================================================

private const val TWO_PI = (2.0 * PI).toFloat()
private const val LOOP_MS = 24_000

/** Hạt giả ngẫu nhiên cố định: Seeds[4·i + 0..3] ∈ [0,1). Tính một lần, không đổi giữa các frame. */
private val Seeds = FloatArray(80 * 4) { idx ->
    var h = (idx / 4) * 374761393 + (idx % 4) * 668265263 + 1013904223
    h = (h xor (h ushr 13)) * 1274126177
    h = h xor (h ushr 16)
    (h and 0xFFFF) / 65536f
}

private fun seed(i: Int, k: Int): Float = Seeds[(i % 80) * 4 + k]

/** Đồng hồ chung 0 → 1 mỗi 24 giây. */
@Composable
internal fun rememberSceneClock(): State<Float> =
    rememberInfiniteTransition(label = "sceneClock").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(LOOP_MS, easing = LinearEasing)),
        label = "sceneClockValue",
    )

/** Lớp hạt của vùng [region]; đổi vùng ⇒ mờ chéo 0,7 s. Đặt TRÊN danh sách nút, DƯỚI HUD. */
@Composable
/** [farmFirst] = true: bản đồ Câu đố (6 chủ đề, Nông trại đứng đầu). false: Bài học (5 chủ đề như cũ). */
internal fun ThemeAmbient(region: Int, clock: State<Float>, modifier: Modifier = Modifier, farmFirst: Boolean = false) {
    val ctx = LocalContext.current
    val tier = remember { runCatching { DeviceTierManager.getDeviceTier(ctx).tier }.getOrDefault(DeviceTier.MEDIUM) }
    val quality = when (tier) { DeviceTier.LOW -> 0.4f; DeviceTier.MEDIUM -> 0.7f; DeviceTier.HIGH -> 1f }
    Crossfade(
        targetState = if (farmFirst) Math.floorMod(region, 6) else Math.floorMod(region, 5) + 1,   // 0 Nông trại · 1 Rừng · 2 Giáng sinh · 3 Sa mạc · 4 Không gian · 5 Biển
        modifier = modifier,
        animationSpec = tween(700),
        label = "ambientTheme",
    ) { theme ->
        Canvas(Modifier.fillMaxSize()) {
            val t = clock.value
            when (theme) {
                0 -> drawFarm(t, quality)
                1 -> drawForest(t, quality)
                2 -> drawSnow(t, quality)
                3 -> drawDesert(t, quality)
                4 -> drawSpace(t, quality)
                else -> drawSea(t, quality)
            }
        }
    }
}

private fun count(base: Int, q: Float): Int = max(1, (base * q).toInt())

/** Pha tuần hoàn [0,1) của hạt i với [cycles] chu kỳ nguyên mỗi vòng. */
private fun phase(t: Float, cycles: Int, offset: Float): Float {
    val v = t * cycles + offset
    return v - kotlin.math.floor(v)
}

// ───────────────────────────── Nông trại: phấn hoa bay lên + bướm vỗ cánh
private fun DrawScope.drawFarm(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    val pollen = Color(0xFFFFF2A8)
    for (i in 0 until count(18, q)) {
        val p = phase(t, 1 + i % 2, seed(i, 1))                          // 1–2 vòng / 24 s: bay chậm từ dưới lên
        val y = h - p * (h + 40f * d) + 20f * d
        val x = seed(i, 0) * w + sin(TWO_PI * (t * 3 + seed(i, 2))) * 18f * d
        val s = sin(TWO_PI * (t * (6 + i % 5) + seed(i, 3)))
        val tw = if (s > 0f) s * s else 0f
        drawCircle(pollen.copy(alpha = 0.10f + 0.14f * tw), 6f * d, Offset(x, y))
        drawCircle(pollen.copy(alpha = 0.30f + 0.55f * tw), 1.7f * d, Offset(x, y))
    }
    val wings = listOf(Color(0xFFFF9A3C), Color(0xFFFFFFFF), Color(0xFFFFD84D), Color(0xFFFF8FB1))
    for (i in 0 until count(4, q)) {
        val px = phase(t, 1, seed(i + 40, 0))                            // 1 vòng ngang màn mỗi 24 s
        val x = px * (w + 80f * d) - 40f * d
        val y = seed(i + 40, 1) * h + sin(TWO_PI * (t * 4 + seed(i + 40, 2))) * 30f * d
        val flap = kotlin.math.abs(sin(TWO_PI * (t * 96 + seed(i + 40, 3))))   // 96 chu kỳ nguyên / 24 s = 4 lần vỗ mỗi giây
        val c = wings[i % wings.size]
        val ww = (2f + 5f * flap) * d
        drawOval(c.copy(alpha = 0.85f), Offset(x - ww - 0.8f * d, y - 3.4f * d), Size(ww, 6.4f * d))
        drawOval(c.copy(alpha = 0.85f), Offset(x + 0.8f * d, y - 3.4f * d), Size(ww, 6.4f * d))
        drawLine(Color(0xFF4A3A2A), Offset(x, y - 3f * d), Offset(x, y + 3f * d), strokeWidth = 1.3f * d)
    }
}

// ───────────────────────────── Rừng xanh: đom đóm + lá rơi
private fun DrawScope.drawForest(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    val warm = Color(0xFFEFFF8A)
    for (i in 0 until count(16, q)) {
        val cx = seed(i, 0) * w + sin(TWO_PI * (t * (1 + i % 2) + seed(i, 2))) * 20f * d
        val cy = seed(i, 1) * h + cos(TWO_PI * (t * (2 - i % 2) + seed(i, 3))) * 14f * d
        val s = sin(TWO_PI * (t * (8 + i % 7) + seed(i, 2)))
        val blink = if (s > 0f) s * s else 0f
        val c = Offset(cx, cy)
        drawCircle(warm.copy(alpha = 0.10f + 0.16f * blink), 7f * d, c)
        drawCircle(warm.copy(alpha = 0.22f + 0.30f * blink), 3.6f * d, c)
        drawCircle(Color.White.copy(alpha = 0.30f + 0.65f * blink), 1.5f * d, c)
    }
    for (i in 0 until count(8, q)) {
        val p = phase(t, 1 + i % 2, seed(i + 20, 1))
        val y = p * (h + 60f * d) - 30f * d
        val x = seed(i + 20, 0) * w + sin(TWO_PI * (t * 3 + seed(i + 20, 2))) * 26f * d
        val ang = sin(TWO_PI * (t * 4 + seed(i + 20, 3))) * 40f + i * 37f
        val col = if (i % 2 == 0) Color(0xFF8BD34F) else Color(0xFFE0A040)
        rotate(ang, Offset(x, y)) {
            drawOval(col.copy(alpha = 0.55f), Offset(x - 4f * d, y - 2.2f * d), Size(8f * d, 4.4f * d))
        }
    }
}

// ───────────────────────────── Giáng sinh: tuyết rơi 3 lớp
private fun DrawScope.drawSnow(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    for (i in 0 until count(48, q)) {
        val layer = i % 3                        // 0 xa-nhỏ-chậm · 2 gần-to-nhanh
        val r = (1.2f + layer * 0.9f) * d
        val p = phase(t, 2 + layer * 2, seed(i, 1))
        val y = p * (h + 20f * d) - 10f * d
        val x = seed(i, 0) * w + sin(TWO_PI * (t * (2 + layer) + seed(i, 2))) * (8f + 5f * layer) * d
        drawCircle(Color.White.copy(alpha = 0.40f + 0.18f * layer + 0.10f * seed(i, 3)), r, Offset(x, y))
    }
}

// ───────────────────────────── Sa mạc: bụi cát bay + tàn lửa
private fun DrawScope.drawDesert(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    for (i in 0 until count(14, q)) {
        val p = phase(t, 2 + i % 3, seed(i, 1))
        val x = p * (w + 100f * d) - 50f * d
        val y = seed(i, 0) * h + sin(TWO_PI * (t * 2 + seed(i, 2))) * 6f * d
        val len = (22f + 28f * seed(i, 3)) * d
        drawLine(Color(0xFFFFF1D0).copy(alpha = 0.16f), Offset(x, y), Offset(x - len, y + 2f * d), 1.4f * d, StrokeCap.Round)
    }
    for (i in 0 until count(10, q)) {
        val p = phase(t, 2 + i % 3, seed(i + 30, 1))
        val y = h * (1f - p)
        val x = seed(i + 30, 0) * w + sin(TWO_PI * (t * 3 + seed(i + 30, 2))) * 10f * d
        val tw = 0.55f + 0.45f * sin(TWO_PI * (t * 12 + seed(i + 30, 3)))
        val a = (1f - p) * 0.8f * tw
        drawCircle(Color(0xFFFFA040).copy(alpha = a * 0.35f), 4f * d, Offset(x, y))
        drawCircle(Color(0xFFFFD27A).copy(alpha = a), (1.1f + 1.3f * seed(i + 30, 2)) * d, Offset(x, y))
    }
}

// ───────────────────────────── Không gian: sao nhấp nháy + sao băng
private fun DrawScope.drawSpace(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    for (i in 0 until count(44, q)) {
        val tw = 0.5f + 0.5f * sin(TWO_PI * (t * (6 + i % 11) + seed(i, 2)))
        val a = 0.18f + 0.82f * tw
        val c = Offset(seed(i, 0) * w, seed(i, 1) * h)
        val r = (0.6f + 1.3f * seed(i, 3)) * d
        val col = if (i % 6 == 0) Color(0xFFFFE9A8) else Color.White
        drawCircle(col.copy(alpha = a), r, c)
        if (r > 1.5f * d) {                      // sao to có tia chữ thập
            val l = r * 3.2f * tw
            drawLine(col.copy(alpha = a * 0.7f), Offset(c.x - l, c.y), Offset(c.x + l, c.y), 0.8f * d)
            drawLine(col.copy(alpha = a * 0.7f), Offset(c.x, c.y - l), Offset(c.x, c.y + l), 0.8f * d)
        }
    }
    // Sao băng: 3 vệt mỗi vòng, mỗi vệt chỉ hiện ~12% thời gian
    for (s in 0 until 3) {
        val u = phase(t, 3, s * 0.31f)
        if (u > 0.12f) continue
        val p = u / 0.12f
        val sx = (0.35f + 0.55f * seed(s + 60, 0)) * w
        val sy = (0.05f + 0.35f * seed(s + 60, 1)) * h
        val travel = 0.55f * w
        val head = Offset(sx - travel * p, sy + travel * 0.6f * p)
        val tail = Offset(head.x + 90f * d, head.y - 54f * d)
        val a = sin(PI.toFloat() * p)
        drawLine(Color(0xFFBFD8FF).copy(alpha = 0.35f * a), tail, head, 3.2f * d, StrokeCap.Round)
        drawLine(Color.White.copy(alpha = 0.9f * a), Offset(head.x + 34f * d, head.y - 20f * d), head, 1.6f * d, StrokeCap.Round)
    }
}

// ───────────────────────────── Biển sâu: tia nắng + bong bóng
private fun DrawScope.drawSea(t: Float, q: Float) {
    val d = density
    val w = size.width
    val h = size.height
    for (i in 0 until 4) {
        val sway = sin(TWO_PI * (t + seed(i + 50, 2))) * 0.05f * w
        val x0 = (0.08f + 0.26f * i) * w + sway
        val bw = (0.07f + 0.05f * seed(i + 50, 1)) * w
        val lean = 0.20f * w
        val path = Path().apply {
            moveTo(x0, 0f); lineTo(x0 + bw, 0f)
            lineTo(x0 + bw + lean, h * 0.75f); lineTo(x0 + lean * 0.8f, h * 0.75f)
            close()
        }
        val a = 0.035f + 0.025f * (0.5f + 0.5f * sin(TWO_PI * (t * 2 + seed(i + 50, 0))))
        drawPath(path, Color.White.copy(alpha = a))
    }
    for (i in 0 until count(22, q)) {
        val r = (1.5f + 4.5f * seed(i, 3)) * d
        val p = phase(t, 2 + i % 3, seed(i, 1))
        val y = h + r - p * (h + 2f * r)
        val x = seed(i, 0) * w + sin(TWO_PI * (t * (3 + i % 3) + seed(i, 2))) * 9f * d
        val c = Offset(x, y)
        drawCircle(Color.White.copy(alpha = 0.10f), r, c)
        drawCircle(Color.White.copy(alpha = 0.42f), r, c, style = Stroke(width = 1f * d))
        drawCircle(Color.White.copy(alpha = 0.55f), r * 0.22f, Offset(x - r * 0.35f, y - r * 0.35f))
    }
}

// ───────────────────────────── Vật cảnh chuyển động nhẹ

/** [deg]: góc lắc (độ) · [bobDp]: nhấp nhô dọc (dp) · [cycles]: số nhịp mỗi vòng 24 s · [originY]: 1 = lắc quanh gốc (cây). */
internal class PropMotion(val deg: Float, val bobDp: Float, val cycles: Int, val originY: Float)

private val Sway = PropMotion(deg = 1.6f, bobDp = 0f, cycles = 8, originY = 1f)
private val SwaySoft = PropMotion(deg = 1.1f, bobDp = 0f, cycles = 6, originY = 1f)
private val Float1 = PropMotion(deg = 2.5f, bobDp = 4f, cycles = 6, originY = 0.5f)
private val Float2 = PropMotion(deg = 1.5f, bobDp = 3f, cycles = 4, originY = 0.5f)
private val Hover = PropMotion(deg = 1.8f, bobDp = 3.5f, cycles = 8, originY = 0.5f)
private val Idle = PropMotion(deg = 1.8f, bobDp = 2.2f, cycles = 8, originY = 1f)   // gà/cừu/bò: nhún nhẹ tại chỗ

/** Chỉ vài loại có chuyển động: mỗi vật động là một graphicsLayer chạy mỗi frame, nên giữ ít để cuộn luôn mượt. */
internal fun propMotion(kind: PropKind): PropMotion? = when (kind) {
    PropKind.KfTree, PropKind.KfTreeHigh, PropKind.KaTree -> SwaySoft
    PropKind.HolTreeA, PropKind.HolTreeB, PropKind.HolTreeC, PropKind.HolLantern -> SwaySoft
    PropKind.SeaSeaweed, PropKind.SeaCoral -> Sway
    PropKind.FarmTreeApple, PropKind.FarmTree, PropKind.FarmPine, PropKind.FarmPoplar -> SwaySoft
    PropKind.FarmSunflowers -> Sway
    PropKind.FarmChicken, PropKind.FarmSheep, PropKind.FarmCow -> Idle
    PropKind.SeaJelly -> Float1
    PropKind.SpcPlanet, PropKind.SpcPlanet2, PropKind.SpcAsteroid -> Float2
    PropKind.SpcRocket, PropKind.SpcCrystal -> Hover
    else -> null
}

internal fun motionOrigin(m: PropMotion): TransformOrigin = TransformOrigin(0.5f, m.originY)

internal fun motionPhase(x: Float, y: Float): Float = (((x * 1000f).toInt() * 31 + (y * 10000f).toInt()) and 0xFF) / 255f

/** Góc (rad) của vật tại thời điểm [t] của đồng hồ chung. */
internal fun motionAngle(m: PropMotion, t: Float, phase: Float): Float = (t * m.cycles + phase) * TWO_PI
