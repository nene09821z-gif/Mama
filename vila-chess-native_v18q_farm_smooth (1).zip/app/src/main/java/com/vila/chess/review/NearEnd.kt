package com.vila.chess.review

import com.vila.chess.core.EMPTY
import com.vila.chess.core.KING
import com.vila.chess.core.isWhitePiece
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue

/**
 * Nhận biết ván "GẦN XONG" để bắt đầu phân tích ngầm sớm (hàm thuần, không Android ⇒ test được trên JVM).
 * Chỉ dùng thông tin rẻ có sẵn (số quân, chênh quân, đồng hồ, luật 50 nước), không hỏi engine.
 *
 * Trả true khi (và đã đủ [MIN_PLY] nửa nước, để ván khai cuộc vừa thế bí không bị tính):
 *  • TÀN CUỘC     : tổng số quân (cả hai vua) <= [ENDGAME_PIECES]
 *  • CHÊNH QUÂN   : lệch từ 1 Hậu trở lên (>= [DECISIVE_CP]) và đã qua [DECISIVE_MIN_PLY] nửa nước
 *  • SẮP HẾT GIỜ  : bên ít giờ hơn còn <= max([LOW_CLOCK_MS], 12% giờ gốc)
 *  • SẮP HÒA      : đồng hồ 50 nước >= [HALFMOVE_LIMIT] nửa nước
 * Nơi gọi giữ "chốt" (đã true thì giữ true cả ván) nên không cần xử lý lúc điều kiện dao động.
 */
object NearEnd {
    const val MIN_PLY = 16
    const val ENDGAME_PIECES = 8
    const val DECISIVE_CP = 900
    const val DECISIVE_MIN_PLY = 24
    const val LOW_CLOCK_MS = 15_000L
    const val HALFMOVE_LIMIT = 40

    fun isNearEnd(
        board: IntArray,
        halfmove: Int,
        ply: Int,
        clockOn: Boolean,
        lowestClockMs: Long,
        baseMs: Long,
    ): Boolean {
        if (ply < MIN_PLY) return false
        var pieces = 0
        var white = 0
        var black = 0
        for (pc in board) {
            if (pc == EMPTY) continue
            pieces++
            val t = pieceType(pc)
            if (t == KING) continue
            if (isWhitePiece(pc)) white += pieceValue(t) else black += pieceValue(t)
        }
        if (pieces <= ENDGAME_PIECES) return true
        if (ply >= DECISIVE_MIN_PLY && kotlin.math.abs(white - black) >= DECISIVE_CP) return true
        if (clockOn && baseMs > 0L && lowestClockMs <= maxOf(LOW_CLOCK_MS, baseMs * 12 / 100)) return true
        if (halfmove >= HALFMOVE_LIMIT) return true
        return false
    }
}
