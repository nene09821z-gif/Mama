package com.vila.chess.bots

import androidx.compose.ui.graphics.Color

// FILE SINH TỰ ĐỘNG bởi scripts/gen_bot_motion.py (GitHub Actions) — đừng sửa tay.
// 15 bot, thông số chuyển động theo Elo + độ lệch cố định theo id.
object BotMotionData {
    val byId: Map<String, BotMotion> = mapOf(
        "martin" to BotMotion(1745, 0.045f, 1.688f, 4.022f, 771, 739, 9.340f, 0.157f, 4.187f, Color(0xFF6496E0), 2026, 157, 1.700f, 1792, 1.464f, 150, 1.662f),
        "jimmy" to BotMotion(1876, 0.040f, 1.609f, 3.877f, 968, 807, 8.315f, 0.146f, 4.069f, Color(0xFFE064D6), 2440, 142, 1.532f, 1946, 1.502f, 152, 1.414f),
        "nelson" to BotMotion(2001, 0.035f, 1.492f, 4.482f, 845, 783, 9.005f, 0.139f, 4.449f, Color(0xFFE0DA64), 2575, 144, 1.568f, 2298, 1.444f, 151, 1.453f),
        "emir" to BotMotion(2114, 0.039f, 1.478f, 3.551f, 948, 893, 7.643f, 0.134f, 4.252f, Color(0xFFE064C7), 2899, 138, 1.435f, 2470, 1.298f, 159, 1.470f),
        "lena" to BotMotion(2546, 0.030f, 1.287f, 3.880f, 1112, 862, 7.637f, 0.139f, 3.748f, Color(0xFF64E0BD), 2986, 140, 1.308f, 2386, 1.422f, 159, 1.414f),
        "antonio" to BotMotion(2315, 0.031f, 1.204f, 3.626f, 1069, 866, 6.846f, 0.109f, 4.080f, Color(0xFF64E0BB), 3596, 142, 1.188f, 2874, 1.177f, 178, 1.312f),
        "sofia" to BotMotion(2681, 0.027f, 1.145f, 3.302f, 1230, 897, 6.938f, 0.105f, 3.720f, Color(0xFFE09064), 3356, 142, 1.128f, 2590, 1.279f, 192, 1.387f),
        "hiro" to BotMotion(2426, 0.030f, 1.231f, 3.339f, 1077, 1046, 6.092f, 0.112f, 3.373f, Color(0xFF6964E0), 3901, 127, 1.338f, 3208, 1.264f, 199, 1.387f),
        "viktor" to BotMotion(2699, 0.025f, 1.023f, 2.833f, 1162, 1024, 6.345f, 0.105f, 3.385f, Color(0xFFE064DE), 4097, 119, 1.071f, 3384, 1.236f, 181, 1.332f),
        "isabel" to BotMotion(2792, 0.026f, 1.145f, 2.567f, 1352, 954, 6.164f, 0.094f, 3.113f, Color(0xFF64C9E0), 4638, 136, 0.987f, 3525, 1.080f, 199, 1.322f),
        "magnus" to BotMotion(2678, 0.026f, 0.972f, 2.617f, 1398, 1133, 5.358f, 0.101f, 3.294f, Color(0xFF9464E0), 4171, 120, 0.995f, 3631, 1.073f, 199, 1.415f),
        "olga" to BotMotion(2979, 0.024f, 0.963f, 2.364f, 1361, 1028, 5.835f, 0.090f, 3.576f, Color(0xFF64E0AC), 5244, 122, 1.120f, 3807, 1.077f, 220, 1.296f),
        "daniel" to BotMotion(2868, 0.023f, 0.823f, 2.168f, 1292, 1109, 5.759f, 0.092f, 3.298f, Color(0xFFE07D64), 4842, 128, 0.970f, 3530, 0.870f, 226, 1.292f),
        "nova" to BotMotion(3125, 0.019f, 0.849f, 2.274f, 1338, 1187, 4.829f, 0.090f, 2.837f, Color(0xFF64E0D6), 5360, 116, 0.995f, 3713, 0.922f, 233, 1.296f),
        "mittens" to BotMotion(3161, 0.019f, 0.713f, 1.951f, 1384, 1141, 5.134f, 0.085f, 3.159f, Color(0xFF6473E0), 5717, 124, 0.883f, 4322, 0.849f, 238, 1.342f),
    )
}
