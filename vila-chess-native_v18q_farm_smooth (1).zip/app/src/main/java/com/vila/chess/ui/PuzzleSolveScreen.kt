package com.vila.chess.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import com.vila.chess.coach.Mood
import com.vila.chess.game.PuzzleMapViewModel
import com.vila.chess.game.PuzzleStats
import com.vila.chess.game.puzzleCoachTip
import com.vila.chess.game.puzzlePlayerMoveCount
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.core.moveFrom
import com.vila.chess.core.moveTo
import com.vila.chess.game.Puzzle
import com.vila.chess.game.PuzzleRepository
import com.vila.chess.game.PuzzleSession
import com.vila.chess.game.PuzzleSfx
import com.vila.chess.game.Sfx
import com.vila.chess.game.PuzzleStep
import com.vila.chess.game.puzzleGoalText
import com.vila.chess.game.puzzleSideName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// ════════════════════════════════════════════════════════════════════════════════════════════
//  MÀN HÌNH GIẢI ĐỐ
//
//  Dòng chảy dữ liệu:  puzzles.db (hoặc BuiltInPuzzles) → Puzzle(fen, moves) → PuzzleSession → Position.fromFen
//                       → IntArray(64) board → Canvas vẽ quân. Bàn cờ luôn có quân vì dữ liệu đi qua đúng 1 đường này.
//
//  Quy ước Lichess: moves[0] là nước của ĐỐI THỦ (chạy animation lúc mở màn), người chơi đi từ moves[1].
//  Thả quân đúng nước (hoặc bất kỳ nước chiếu hết) ⇒ đối thủ tự đáp; sai ⇒ quân lắc + rung nhẹ.
//
//  Hiệu năng: vị trí quân đang kéo / animation trượt / lắc đều là Animatable hoặc State chỉ được đọc trong
//  draw / graphicsLayer ⇒ không recomposition trong lúc kéo.
// ════════════════════════════════════════════════════════════════════════════════════════════

private val ScreenBg = Color(0xFF262421)
private val CardBg = Color(0xFF302E2B)
private val OkGreen = Color(0xFF81B64C)
private val BadRed = Color(0xFFE05A47)
private val HintBlue = Color(0x663E9BEA)
private const val LIFT_FRAC = 0.45f      // quân đang kéo nằm cao hơn ngón tay chừng này ô
private const val SHAKE_FRAC = 0.12f     // biên độ lắc = 12% cạnh ô

private enum class PuzzleStatus { YourTurn, Correct, Wrong, Solved, Broken }

/**
 * Màn giải câu đố kiểu chess.com: nền vũ trụ, thanh trên (huy hiệu cấp + cài đặt), bong bóng thầy, bàn cờ,
 * điểm/chuỗi/đồng hồ/thanh tiến độ và thanh nút Gợi ý · Quay lại · Tiếp.
 *
 *  • [unlockedLevel] = level đang chơi trên bản đồ: câu có level ≥ giá trị này mới TÍNH ĐIỂM; câu cũ chơi lại thì không.
 *  • [onUnlock] gọi ngay khi giải xong (hoặc bấm Tiếp ở câu lỗi) để mở khoá level kế, không cần quay về bản đồ.
 *  • Bấm Tiếp = sang câu kế NGAY TRONG màn này; Quay lại = câu trước; mũi tên trên cùng = về bản đồ
 *    (nếu đã giải câu nào trong lượt này thì gọi [onSolved] để bản đồ phát animation ăn mừng).
 */
@Composable
fun PuzzleSolveScreen(
    level: Int,
    images: Array<ImageBitmap?>,
    onBack: () -> Unit,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
    unlockedLevel: Int = level,
    onUnlock: (Int) -> Unit = {},
) {
    val ctx = LocalContext.current
    remember { PuzzleStats.load(ctx) }
    var shown by remember(level) { mutableIntStateOf(level) }
    var restart by remember(level) { mutableIntStateOf(0) }
    var solvedAny by remember(level) { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val puzzle by produceState<Puzzle?>(initialValue = null, key1 = shown) {
        value = null   // chuyển câu: hiện vòng xoay thay vì giữ câu cũ
        value = withContext(Dispatchers.IO) { PuzzleRepository.load(ctx, shown) }
    }
    val total = PuzzleMapViewModel.TOTAL_LEVELS
    val leave = { if (solvedAny) onSolved() else onBack() }

    Box(modifier.fillMaxSize()) {
        StaticSpaceBackground()
        Column(Modifier.fillMaxSize().navigationBarsPadding()) {
            CoachTopBar(level = shown, onBack = leave, onSettings = { showSettings = true })
            val p = puzzle
            if (p == null) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = OkGreen)
                }
            } else {
                key(p.level, p.puzzleId, restart) {
                    PuzzleContent(
                        puzzle = p,
                        images = images,
                        onSolved = {},
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        coach = CoachSpec(
                            level = shown,
                            rated = p.level >= unlockedLevel,
                            hasPrev = shown > 1,
                            hasNext = shown < total,
                            nextUnlocked = shown < unlockedLevel,
                            onPrev = { if (shown > 1) shown -= 1 },
                            onNext = { finished ->
                                if (finished) onUnlock(shown)
                                if (shown < total) shown += 1
                            },
                            onSolved = {
                                solvedAny = true
                                onUnlock(shown)
                            },
                        ),
                    )
                }
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                containerColor = Color(0xFF16233B),
                title = { Text("Câu đố $shown", color = Color.White, fontWeight = FontWeight.ExtraBold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val rating = puzzle?.rating
                        if (rating != null) Text("Độ khó: $rating", color = Color(0xFFB8C4D8), fontSize = 15.sp)
                        Text("Điểm câu đố của bạn: ${PuzzleStats.rating}", color = Color(0xFFB8C4D8), fontSize = 15.sp)
                        Text(
                            "Câu cũ chơi lại không được tính điểm.",
                            color = Color(0xFF8FA3C0), fontSize = 13.sp,
                        )
                    }
                },
                confirmButton = {
                    TextButton(onClick = { restart += 1; showSettings = false }) {
                        Text("Làm lại câu này", color = OkGreen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showSettings = false }) { Text("Đóng", color = Color(0xFFB8C4D8)) }
                },
            )
        }
    }
}

/**
 * Màn bài học chiến thuật: dùng lại đúng bàn cờ + luật chấm của màn giải đố, chỉ thêm thanh tiêu đề riêng
 * và thẻ "Ý tưởng" phía trên (tối đa 3 dòng để chừa chỗ cho bàn cờ). Không tải gì từ đĩa/DB: [puzzle] dựng sẵn.
 */
@Composable
fun LessonPuzzleScreen(
    puzzle: Puzzle,
    title: String,
    idea: String,
    images: Array<ImageBitmap?>,
    onBack: () -> Unit,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.fillMaxSize().background(ScreenBg).navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            }
            Text(
                title,
                color = Color.White,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                modifier = Modifier.weight(1f),
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(CardBg)
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color(0xFFF5C84C), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(idea, color = Color(0xFFD8D8D8), fontSize = 14.sp, lineHeight = 19.sp, maxLines = 3)
        }
        Spacer(Modifier.height(8.dp))
        key(puzzle.puzzleId) {
            PuzzleContent(puzzle = puzzle, images = images, onSolved = onSolved, modifier = Modifier.weight(1f).fillMaxWidth())
        }
    }
}

@Composable
private fun PuzzleContent(
    puzzle: Puzzle,
    images: Array<ImageBitmap?>,
    onSolved: () -> Unit,
    modifier: Modifier = Modifier,
    coach: CoachSpec? = null,   // ≠ null ⇒ bố cục kiểu chess.com (bong bóng thầy, điểm, thanh nút); null ⇒ bố cục gọn của bài học
) {
    val session = remember(puzzle) { PuzzleSession(puzzle) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val ctx = LocalContext.current
    val rated = remember(session) { coach?.rated == true }      // chốt LÚC MỞ câu: giải xong mở khoá cũng không đổi
    var playerDone by remember(session) { mutableIntStateOf(0) }
    var scoreDelta by remember(session) { mutableIntStateOf(0) }
    var reaction by remember(session) { mutableIntStateOf(0) }

    // Thế cờ khởi đầu = TRƯỚC nước của đối thủ; sau ~0.5s đối thủ đi và người chơi bắt đầu.
    var board by remember(session) { mutableStateOf(session.boardBefore.copyOf()) }
    var lastFrom by remember(session) { mutableIntStateOf(-1) }
    var lastTo by remember(session) { mutableIntStateOf(-1) }
    var selected by remember(session) { mutableIntStateOf(-1) }
    var targets by remember(session) { mutableStateOf(emptyList<Int>()) }
    var hint by remember(session) { mutableStateOf<Pair<Int, Int>?>(null) }
    var wrongSq by remember(session) { mutableIntStateOf(-1) }
    var status by remember(session) { mutableStateOf(PuzzleStatus.YourTurn) }
    var mistakes by remember(session) { mutableIntStateOf(0) }
    var seconds by remember(session) { mutableIntStateOf(0) }
    var busy by remember(session) { mutableStateOf(true) }
    var finished by remember(session) { mutableStateOf(false) }
    var slideFrom by remember(session) { mutableIntStateOf(-1) }
    var slideTo by remember(session) { mutableIntStateOf(-1) }
    val slide = remember(session) { Animatable(1f) }
    val shake = remember(session) { Animatable(0f) }

    LaunchedEffect(session) {
        if (!session.valid) {
            board = session.board()
            status = PuzzleStatus.Broken
            finished = true
            busy = false
            return@LaunchedEffect
        }
        delay(500)
        val sm = session.setupMove
        slide.snapTo(0f)
        slideFrom = moveFrom(sm)
        slideTo = moveTo(sm)
        lastFrom = slideFrom
        lastTo = slideTo
        board = session.board()
        PuzzleSfx.play(ctx, session.setupSfx)
        slide.animateTo(1f, tween(240))
        status = PuzzleStatus.YourTurn
        busy = false
    }

    // Đồng hồ giải đố: chạy tới khi giải xong / dữ liệu lỗi.
    LaunchedEffect(session, finished) {
        while (!finished) {
            delay(1000)
            seconds += 1
        }
    }

    fun select(sq: Int) {
        hint = null
        if (sq < 0) {
            selected = -1
            targets = emptyList()
        } else {
            if (status == PuzzleStatus.Wrong) status = PuzzleStatus.YourTurn
            selected = sq
            targets = session.legalTargets(sq)
        }
    }

    fun attempt(from: Int, to: Int, dragged: Boolean) {
        if (busy || finished) return
        when (val r = session.submit(from, to)) {
            is PuzzleStep.Illegal -> select(-1)
            is PuzzleStep.Wrong -> {
                select(-1)
                wrongSq = from
                mistakes += 1
                if (mistakes == 1 && rated) PuzzleStats.onMistake(ctx)   // sai nước đầu tiên: chuỗi về 0
                status = PuzzleStatus.Wrong
                PuzzleSfx.playWrong(ctx)
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                scope.launch {
                    shake.snapTo(0f)
                    for (a in floatArrayOf(-1f, 1f, -0.7f, 0.7f, -0.35f, 0.35f, 0f)) shake.animateTo(a, tween(45))
                    wrongSq = -1
                }
            }
            is PuzzleStep.Correct -> {
                select(-1)
                busy = true
                scope.launch {
                    if (!dragged) {               // chạm-để-đi: trượt quân; kéo-thả: quân đã nằm sẵn trên ô đích
                        slide.snapTo(0f)
                        slideFrom = moveFrom(r.playerMove)
                        slideTo = moveTo(r.playerMove)
                    } else {
                        slideFrom = -1
                        slideTo = -1
                    }
                    lastFrom = moveFrom(r.playerMove)
                    lastTo = moveTo(r.playerMove)
                    board = r.boardAfterPlayer
                    playerDone += 1
                    status = if (r.solved) PuzzleStatus.Solved else PuzzleStatus.Correct
                    PuzzleSfx.play(ctx, r.playerSfx)
                    if (!dragged) slide.animateTo(1f, tween(160))
                    val reply = r.reply
                    if (reply != null) {
                        delay(320)
                        slide.snapTo(0f)
                        slideFrom = moveFrom(reply)
                        slideTo = moveTo(reply)
                        lastFrom = slideFrom
                        lastTo = slideTo
                        board = session.board()
                        PuzzleSfx.play(ctx, r.replySfx ?: Sfx.MOVE)
                        slide.animateTo(1f, tween(220))
                    }
                    if (r.solved) {
                        finished = true
                        delay(180)
                        PuzzleSfx.play(ctx, Sfx.END)   // giải xong: tiếng "hết ván" của bộ âm thanh đang chọn
                        if (coach != null) {
                            if (rated) scoreDelta = PuzzleStats.onSolved(ctx, puzzle.rating, mistakes)
                            coach.onSolved()
                        }
                    } else {
                        status = PuzzleStatus.YourTurn
                        busy = false
                    }
                }
            }
        }
    }

    // Thầy phản ứng (nhún / rung / nhảy) mỗi khi trạng thái đổi
    LaunchedEffect(status) { reaction += 1 }

    if (coach != null) {
        val boardArea: @Composable (Modifier) -> Unit = { m ->
            PuzzleBoard(
                images = images,
                board = board,
                flipped = !session.playerWhite,
                lastFrom = lastFrom,
                lastTo = lastTo,
                selected = selected,
                targets = targets,
                hint = hint,
                wrongSq = wrongSq,
                shake = shake,
                slideFrom = slideFrom,
                slideTo = slideTo,
                slide = slide,
                enabled = !busy && !finished,
                isPlayerPiece = { session.isPlayerPiece(it) },
                onSelect = { select(it) },
                onMove = { from, to, dragged -> attempt(from, to, dragged) },
                modifier = m,
            )
        }
        CoachLayout(
            modifier = modifier,
            puzzle = puzzle,
            coach = coach,
            playerWhite = session.playerWhite,
            status = status,
            reaction = reaction,
            finished = finished,
            busy = busy,
            seconds = seconds,
            progress = playerDone / puzzlePlayerMoveCount(puzzle).toFloat(),
            scoreDelta = scoreDelta,
            rated = rated,
            mistakes = mistakes,
            onHint = { select(-1); hint = session.hint() },
            board = boardArea,
        )
        return
    }

    Box(modifier) {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            // Bố cục kiểu chess.com: thanh thông tin 56 + bàn cờ full-width + thanh phản hồi 56 + thanh nút đáy 72.
            val side = minOf(maxWidth, maxHeight - 204.dp).coerceAtLeast(160.dp)
            Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                PuzzleHeader(
                    playerWhite = session.playerWhite,
                    goal = puzzleGoalText(puzzle),
                    seconds = seconds,
                    mistakes = mistakes,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                )
                Spacer(Modifier.height(8.dp))
                PuzzleBoard(
                    images = images,
                    board = board,
                    flipped = !session.playerWhite,
                    lastFrom = lastFrom,
                    lastTo = lastTo,
                    selected = selected,
                    targets = targets,
                    hint = hint,
                    wrongSq = wrongSq,
                    shake = shake,
                    slideFrom = slideFrom,
                    slideTo = slideTo,
                    slide = slide,
                    enabled = !busy && !finished,
                    isPlayerPiece = { session.isPlayerPiece(it) },
                    onSelect = { select(it) },
                    onMove = { from, to, dragged -> attempt(from, to, dragged) },
                    modifier = Modifier.size(side),
                )
                Spacer(Modifier.height(8.dp))
                FeedbackBar(
                    status = status,
                    playerWhite = session.playerWhite,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                )
            }
        }

        // Thanh nút cố định ở đáy: Gợi ý (đang giải) → Tiếp tục (đã giải xong).
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (finished) {
                Row(
                    Modifier
                        .weight(1f)
                        .height(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(OkGreen)
                        .clickable(onClick = onSolved),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (status == PuzzleStatus.Broken) "Bỏ qua" else "Tiếp tục",
                        color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold,
                    )
                }
            } else {
                Row(
                    Modifier
                        .weight(1f)
                        .height(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CardBg)
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                        .clickable(enabled = !busy) {
                            select(-1)
                            hint = session.hint()
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = Color(0xFFF5C84C), modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Gợi ý", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Thanh thông tin phía trên bàn cờ (kiểu chess.com): mục tiêu + bên đi, bên phải là đồng hồ và số lần sai. */
@Composable
private fun PuzzleHeader(
    playerWhite: Boolean,
    goal: String,
    seconds: Int,
    mistakes: Int,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .height(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(26.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(if (playerWhite) Color.White else Color(0xFF1B1B1B))
                .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(7.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(goal, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(puzzleSideName(playerWhite) + " đi trước", color = Color(0xFFBABABA), fontSize = 13.sp, maxLines = 1)
        }
        StatChip(label = "Thời gian", value = "%d:%02d".format(seconds / 60, seconds % 60), valueColor = Color.White)
        Spacer(Modifier.width(14.dp))
        StatChip(label = "Sai", value = mistakes.toString(), valueColor = if (mistakes > 0) BadRed else Color.White)
    }
}

@Composable
private fun StatChip(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(value, color = valueColor, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Color(0xFF9A9894), fontSize = 11.sp)
    }
}

/** Thanh phản hồi dưới bàn cờ (kiểu chess.com): đổi màu xanh / đỏ theo kết quả nước vừa đi. */
@Composable
private fun FeedbackBar(status: PuzzleStatus, playerWhite: Boolean, modifier: Modifier = Modifier) {
    val bg = when (status) {
        PuzzleStatus.Correct, PuzzleStatus.Solved -> Color(0xFF3A5424)
        PuzzleStatus.Wrong, PuzzleStatus.Broken -> Color(0xFF5E2B25)
        PuzzleStatus.YourTurn -> CardBg
    }
    val accent = when (status) {
        PuzzleStatus.Correct, PuzzleStatus.Solved -> OkGreen
        PuzzleStatus.Wrong, PuzzleStatus.Broken -> BadRed
        PuzzleStatus.YourTurn -> Color.White
    }
    val title = when (status) {
        PuzzleStatus.YourTurn -> "Đến lượt " + puzzleSideName(playerWhite)
        PuzzleStatus.Correct -> "Chính xác!"
        PuzzleStatus.Wrong -> "Không phải nước đó"
        PuzzleStatus.Solved -> "Câu đố đã được giải!"
        PuzzleStatus.Broken -> "Dữ liệu câu đố bị lỗi"
    }
    val sub = when (status) {
        PuzzleStatus.YourTurn -> "Tìm nước đi tốt nhất"
        PuzzleStatus.Correct -> "Đối thủ đang đáp lại…"
        PuzzleStatus.Wrong -> "Hãy thử nước khác"
        PuzzleStatus.Solved -> "Làm tốt lắm, bấm Tiếp tục"
        PuzzleStatus.Broken -> "Bấm Bỏ qua để tiếp tục"
    }
    Row(
        modifier
            .height(56.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when (status) {
            PuzzleStatus.Correct, PuzzleStatus.Solved ->
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = accent, modifier = Modifier.size(28.dp))
            PuzzleStatus.Wrong, PuzzleStatus.Broken ->
                Icon(Icons.Filled.Cancel, contentDescription = null, tint = accent, modifier = Modifier.size(28.dp))
            PuzzleStatus.YourTurn ->
                Box(
                    Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(if (playerWhite) Color.White else Color(0xFF1B1B1B))
                        .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(7.dp))
                )
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.Center) {
            Text(title, color = accent, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(sub, color = Color(0xFFD0D0D0), fontSize = 13.sp, maxLines = 1)
        }
    }
}

// ─────────────────────────────────────────────────────────── Bàn cờ

@Composable
private fun PuzzleBoard(
    images: Array<ImageBitmap?>,
    board: IntArray,
    flipped: Boolean,
    lastFrom: Int,
    lastTo: Int,
    selected: Int,
    targets: List<Int>,
    hint: Pair<Int, Int>?,
    wrongSq: Int,
    shake: Animatable<Float, AnimationVector1D>,
    slideFrom: Int,
    slideTo: Int,
    slide: Animatable<Float, AnimationVector1D>,
    enabled: Boolean,
    isPlayerPiece: (Int) -> Boolean,
    onSelect: (Int) -> Unit,
    onMove: (from: Int, to: Int, dragged: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    var dragSq by remember { mutableIntStateOf(-1) }
    var finger by remember { mutableStateOf(Offset.Zero) }
    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    // Gesture chạy trong 1 coroutine sống lâu ⇒ luôn đọc giá trị MỚI NHẤT qua rememberUpdatedState.
    val enabledNow by rememberUpdatedState(enabled)
    val flippedNow by rememberUpdatedState(flipped)
    val selectedNow by rememberUpdatedState(selected)
    val targetsNow by rememberUpdatedState(targets)
    val isPlayerPieceNow by rememberUpdatedState(isPlayerPiece)
    val onSelectNow by rememberUpdatedState(onSelect)
    val onMoveNow by rememberUpdatedState(onMove)

    BoxWithConstraints(modifier) {
        val boardPx = constraints.maxWidth.toFloat()
        val s = boardPx / 8f
        val sDp = with(density) { s.toDp() }

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    val slop = viewConfiguration.touchSlop
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (!enabledNow) return@awaitEachGesture
                        val bp = size.width.toFloat()
                        val sq = bp / 8f
                        val flip = flippedNow
                        val startSq = squareAt(down.position, bp, flip)
                        val sel = selectedNow
                        // Đang chọn 1 quân và chạm vào ô đích hợp lệ ⇒ "chạm để đi", thực hiện lúc nhả tay.
                        val tapMoveFrom = if (sel >= 0 && startSq != sel && targetsNow.contains(startSq)) sel else -1
                        var canDrag = false
                        var wasSelected = false
                        if (tapMoveFrom < 0) {
                            if (isPlayerPieceNow(startSq)) {
                                wasSelected = sel == startSq
                                if (!wasSelected) onSelectNow(startSq)
                                canDrag = true
                            } else {
                                onSelectNow(-1)
                            }
                        }
                        var dragging = false
                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                            val center = Offset(change.position.x, change.position.y - sq * LIFT_FRAC)
                            if (!change.pressed) {
                                if (dragging) {
                                    val drop = squareAt(center, bp, flip)
                                    dragSq = -1
                                    if (drop != startSq) onMoveNow(startSq, drop, true)
                                } else if (tapMoveFrom >= 0) {
                                    onMoveNow(tapMoveFrom, startSq, false)
                                } else if (canDrag && wasSelected) {
                                    onSelectNow(-1)   // chạm lại quân đang chọn ⇒ bỏ chọn
                                }
                                break
                            }
                            if (canDrag) {
                                if (!dragging && (change.position - down.position).getDistance() > slop) {
                                    dragging = true
                                    dragSq = startSq
                                }
                                if (dragging) {
                                    finger = center
                                    change.consume()
                                }
                            }
                        }
                        dragSq = -1   // cử chỉ bị huỷ giữa chừng ⇒ quân về chỗ cũ
                    }
                },
        ) {
            drawPuzzleBoard(
                images = images,
                board = board,
                flipped = flipped,
                lastFrom = lastFrom,
                lastTo = lastTo,
                selected = selected,
                targets = targets,
                hint = hint,
                wrongSq = wrongSq,
                shakeValue = shake.value,
                slideFrom = slideFrom,
                slideTo = slideTo,
                slideValue = slide.value,
                hiddenSq = dragSq,
                hoverCenter = if (dragSq >= 0) finger else null,
                labelPaint = labelPaint,
            )
        }

        // Quân đang kéo: dính ngón tay bằng graphicsLayer (GPU), nhấc lên 1.15× + bóng đổ.
        val dragImg = if (dragSq >= 0) images.getOrNull(board[dragSq]) else null
        if (dragImg != null) {
            Image(
                bitmap = dragImg,
                contentDescription = null,
                filterQuality = FilterQuality.High,
                modifier = Modifier
                    .size(sDp)
                    .graphicsLayer {
                        translationX = finger.x - s / 2f
                        translationY = finger.y - s / 2f
                        scaleX = 1.15f
                        scaleY = 1.15f
                        shadowElevation = 12.dp.toPx()
                        shape = CircleShape
                        clip = false
                        ambientShadowColor = Color.Black
                        spotShadowColor = Color.Black
                    },
            )
        }
    }
}

private fun DrawScope.drawPuzzleBoard(
    images: Array<ImageBitmap?>,
    board: IntArray,
    flipped: Boolean,
    lastFrom: Int,
    lastTo: Int,
    selected: Int,
    targets: List<Int>,
    hint: Pair<Int, Int>?,
    wrongSq: Int,
    shakeValue: Float,
    slideFrom: Int,
    slideTo: Int,
    slideValue: Float,
    hiddenSq: Int,
    hoverCenter: Offset?,
    labelPaint: Paint,
) {
    val s = size.width / 8f

    fun topLeft(sq: Int): Offset = squareTopLeft(sq, s, flipped)
    fun center(sq: Int): Offset {
        val o = topLeft(sq)
        return Offset(o.x + s / 2f, o.y + s / 2f)
    }
    fun tint(sq: Int, color: Color) = drawRect(color = color, topLeft = topLeft(sq), size = Size(s, s))
    fun piece(code: Int, x: Float, y: Float) {
        val img = images.getOrNull(code) ?: return
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = IntOffset(x.roundToInt(), y.roundToInt()),
            dstSize = IntSize(s.roundToInt(), s.roundToInt()),
            filterQuality = FilterQuality.High,
        )
    }

    // 64 ô
    for (sq in 0 until 64) {
        val light = ((sq shr 3) + (sq and 7)) % 2 == 1
        tint(sq, if (light) VilaColors.BoardLight else VilaColors.BoardDark)
    }
    // tô sáng
    if (lastFrom >= 0 && lastTo >= 0) {
        tint(lastFrom, VilaColors.Highlight)
        tint(lastTo, VilaColors.Highlight)
    }
    if (selected >= 0) tint(selected, VilaColors.Highlight)
    if (hint != null) {
        tint(hint.first, HintBlue)
        tint(hint.second, HintBlue)
    }
    if (wrongSq >= 0) tint(wrongSq, VilaColors.PremoveRed)

    // toạ độ a–h / 1–8
    drawIntoCanvas { canvas ->
        labelPaint.textSize = s * 0.2f
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val col = if (flipped) 7 - f else f
            val row = if (flipped) r else 7 - r
            val light = (r + f) % 2 == 1
            labelPaint.color = (if (light) VilaColors.BoardDark else VilaColors.BoardLight).toArgb()
            if (col == 0) {
                labelPaint.textAlign = Paint.Align.LEFT
                canvas.nativeCanvas.drawText(('1' + r).toString(), col * s + s * 0.06f, row * s + s * 0.24f, labelPaint)
            }
            if (row == 7) {
                labelPaint.textAlign = Paint.Align.RIGHT
                canvas.nativeCanvas.drawText(('a' + f).toString(), col * s + s - s * 0.06f, row * s + s - s * 0.08f, labelPaint)
            }
        }
    }

    // chấm gợi ý nước đi
    for (sq in targets) {
        val c = center(sq)
        if (board[sq] != 0) {
            drawCircle(Color(0x2E000000), radius = s * 0.43f, center = c, style = Stroke(width = s * 0.09f))
        } else {
            drawCircle(Color(0x2E000000), radius = s * 0.17f, center = c)
        }
    }

    // QUÂN CỜ – đọc thẳng từ board (đã parse từ FEN)
    val sliding = slideTo >= 0 && slideValue < 1f
    for (sq in 0 until 64) {
        val pc = board[sq]
        if (pc == 0 || sq == hiddenSq) continue
        if (sliding && sq == slideTo) continue
        val o = topLeft(sq)
        val dx = if (sq == wrongSq) shakeValue * s * SHAKE_FRAC else 0f
        piece(pc, o.x + dx, o.y)
    }
    if (sliding && slideFrom >= 0) {
        val a = topLeft(slideFrom)
        val b = topLeft(slideTo)
        piece(board[slideTo], a.x + (b.x - a.x) * slideValue, a.y + (b.y - a.y) * slideValue)
    }

    // viền ô đang rê qua khi kéo
    if (hoverCenter != null) {
        val hover = squareAt(hoverCenter, size.width, flipped)
        if (targets.contains(hover)) {
            val o = topLeft(hover)
            drawRect(
                color = Color(0xB3FFFFFF),
                topLeft = Offset(o.x + s * 0.03f, o.y + s * 0.03f),
                size = Size(s * 0.94f, s * 0.94f),
                style = Stroke(width = s * 0.06f),
            )
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════════════════════
//  BỐ CỤC KIỂU CHESS.COM
//  Thanh trên (huy hiệu cấp + cài đặt) → bong bóng thầy → bàn cờ → điểm/chuỗi/đồng hồ + thanh tiến độ
//  → thanh nút Gợi ý · Quay lại · Tiếp. Chiều cao các khối cố định ⇒ bàn cờ KHÔNG nhảy khi lời thầy đổi dài/ngắn.
// ════════════════════════════════════════════════════════════════════════════════════════════

private val BUBBLE_H = 108.dp
private val HUD_H = 88.dp
private val TOOLBAR_H = 58.dp
private val CoachInk = Color(0xFF262421)
private val SoftBlue = Color(0xFFB8C4D8)
private val DimBlue = Color(0xFF8FA3C0)
private val FlameOrange = Color(0xFFFF8A1F)

/** Thông số + hành động của bố cục kiểu chess.com (xem [PuzzleSolveScreen]). */
private class CoachSpec(
    val level: Int,
    val rated: Boolean,                      // câu này có tính điểm không
    val hasPrev: Boolean,
    val hasNext: Boolean,
    val nextUnlocked: Boolean,               // level kế đã mở khoá từ trước (cho phép Tiếp dù chưa giải lại)
    val onPrev: () -> Unit,
    val onNext: (finished: Boolean) -> Unit,
    val onSolved: () -> Unit,
)

@Composable
private fun CoachTopBar(level: Int, onBack: () -> Unit, onSettings: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(52.dp)) {
        IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = SoftBlue, modifier = Modifier.size(28.dp))
        }
        Row(Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
            PuzzleBadge(number = level, size = 40.dp)
            Spacer(Modifier.width(8.dp))
            Text("Câu đố", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        IconButton(onClick = onSettings, modifier = Modifier.align(Alignment.CenterEnd)) {
            Icon(Icons.Filled.Settings, contentDescription = "Cài đặt câu đố", tint = DimBlue, modifier = Modifier.size(26.dp))
        }
    }
}

/**
 * Huy hiệu mảnh ghép gỗ có số cấp (như chess.com): đế tối + mặt gradient + hai núm ghép. Vẽ bằng Canvas, không dùng ảnh.
 * Cỡ chữ tự thu nhỏ theo số chữ số (level tối đa 300.000).
 */
@Composable
fun PuzzleBadge(number: Int, size: Dp, modifier: Modifier = Modifier) {
    val text = number.toString()
    val factor = when (text.length) { 1 -> 0.46f; 2 -> 0.40f; 3 -> 0.31f; 4 -> 0.25f; 5 -> 0.21f; else -> 0.18f }
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.minDimension
            val face = Brush.verticalGradient(listOf(Color(0xFFF3B76F), Color(0xFFC77B33)), startY = 0f, endY = w)
            val lip = Color(0xFF8E4F1E)
            val corner = CornerRadius(w * 0.10f)
            val bodySize = Size(w * 0.72f, w * 0.66f)
            fun layer(dy: Float, solid: Color?) {
                val tl = Offset(w * 0.10f, w * 0.20f + dy)
                val knobR = w * 0.12f
                val knob1 = Offset(w * 0.42f, w * 0.20f + dy)
                val knob2 = Offset(w * 0.84f, w * 0.54f + dy)
                if (solid != null) {
                    drawRoundRect(color = solid, topLeft = tl, size = bodySize, cornerRadius = corner)
                    drawCircle(color = solid, radius = knobR, center = knob1)
                    drawCircle(color = solid, radius = knobR, center = knob2)
                } else {
                    drawRoundRect(brush = face, topLeft = tl, size = bodySize, cornerRadius = corner)
                    drawCircle(brush = face, radius = knobR, center = knob1)
                    drawCircle(brush = face, radius = knobR, center = knob2)
                }
            }
            layer(w * 0.07f, lip)   // đế
            layer(0f, null)         // mặt
        }
        Text(
            text = text,
            color = Color.White,
            fontSize = (size.value * factor).sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            style = TextStyle(shadow = Shadow(Color(0x66000000), Offset(0f, 2f), 3f)),
            modifier = Modifier.offset(x = size * -0.04f, y = size * 0.04f),
        )
    }
}

@Composable
private fun CoachLayout(
    modifier: Modifier,
    puzzle: Puzzle,
    coach: CoachSpec,
    playerWhite: Boolean,
    status: PuzzleStatus,
    reaction: Int,
    finished: Boolean,
    busy: Boolean,
    seconds: Int,
    progress: Float,
    scoreDelta: Int,
    rated: Boolean,
    mistakes: Int,
    onHint: () -> Unit,
    board: @Composable (Modifier) -> Unit,
) {
    val title = "Đến lượt quân " + puzzleSideName(playerWhite).lowercase() + " di chuyển"
    val body = when (status) {
        PuzzleStatus.YourTurn -> puzzleCoachTip(puzzle)
        PuzzleStatus.Correct -> "Chính xác! Đối thủ đang đáp lại…"
        PuzzleStatus.Wrong -> "Chưa phải nước đó. Thử nước khác, hoặc bấm Gợi ý nếu bí."
        PuzzleStatus.Solved ->
            if (rated && scoreDelta != 0) "Làm tốt lắm, câu đố đã được giải! Điểm " + (if (scoreDelta > 0) "+" else "") + scoreDelta + "."
            else "Làm tốt lắm, câu đố đã được giải! Bấm Tiếp để sang câu kế."
        PuzzleStatus.Broken -> "Dữ liệu câu đố này bị lỗi. Bấm Tiếp để bỏ qua."
    }
    val mood = when (status) {
        PuzzleStatus.YourTurn -> Mood.CALM
        PuzzleStatus.Correct -> Mood.HAPPY
        PuzzleStatus.Wrong -> Mood.WORRIED
        PuzzleStatus.Solved -> Mood.CHEER
        PuzzleStatus.Broken -> Mood.SAD
    }
    BoxWithConstraints(modifier) {
        val boardSide = minOf(maxWidth, maxHeight - BUBBLE_H - HUD_H - TOOLBAR_H - 12.dp).coerceAtLeast(160.dp)
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            CoachBubbleRow(
                mood = mood,
                reaction = reaction,
                title = title,
                body = body,
                done = status == PuzzleStatus.Solved,
                modifier = Modifier.fillMaxWidth().height(BUBBLE_H),
            )
            board(Modifier.size(boardSide))
            CoachHud(
                score = PuzzleStats.rating,
                streak = PuzzleStats.streak,
                seconds = seconds,
                progress = progress,
                nextLevel = coach.level + 1,
                modifier = Modifier.fillMaxWidth().height(HUD_H),
            )
            Spacer(Modifier.weight(1f))
            val hintEnabled = !busy && !finished
            val nextEnabled = coach.hasNext && (finished || coach.nextUnlocked)
            Row(Modifier.fillMaxWidth().height(TOOLBAR_H).padding(horizontal = 8.dp)) {
                ToolbarButton(Icons.Filled.Lightbulb, "Gợi ý", Color(0xFFF5C84C), hintEnabled, onHint, Modifier.weight(1f))
                ToolbarButton(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Quay lại", SoftBlue, coach.hasPrev, coach.onPrev, Modifier.weight(1f))
                ToolbarButton(
                    Icons.AutoMirrored.Filled.KeyboardArrowRight, "Tiếp",
                    if (finished) OkGreen else SoftBlue, nextEnabled, { coach.onNext(finished) }, Modifier.weight(1f),
                    highlight = finished,
                )
            }
        }
    }
}

/** Thầy + bong bóng thoại trắng: dòng đầu là mục tiêu có ô tick (xanh khi đã giải), phía dưới là lời nhắc của thầy. */
@Composable
private fun CoachBubbleRow(
    mood: Mood,
    reaction: Int,
    title: String,
    body: String,
    done: Boolean,
    modifier: Modifier = Modifier,
) {
    Row(modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.Bottom) {
        TeacherAvatar(
            mood = mood,
            speaking = !done,
            reaction = reaction,
            lookDx = 0f,
            lookDy = 0f,
            onClick = {},
            modifier = Modifier.padding(bottom = 4.dp),
            size = 64.dp,
        )
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).fillMaxHeight().padding(vertical = 4.dp)) {
            Column(
                Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Box(
                        Modifier
                            .padding(top = 0.dp)
                            .size(18.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (done) OkGreen else Color.Transparent)
                            .border(2.dp, if (done) OkGreen else Color(0xFF9A9A9A), RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (done) Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        title, color = CoachInk, fontSize = 14.sp, lineHeight = 18.sp,
                        fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    body, color = Color(0xFF3A3A3A), fontSize = 12.5.sp, lineHeight = 16.sp,
                    maxLines = 3, overflow = TextOverflow.Ellipsis,
                )
            }
            // đuôi bong bóng chỉ về phía thầy (ngang tâm avatar)
            Canvas(
                Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = (-8).dp, y = (-27).dp)
                    .size(width = 9.dp, height = 16.dp),
            ) {
                val tail = Path().apply {
                    moveTo(0f, size.height / 2f)
                    lineTo(size.width, 0f)
                    lineTo(size.width, size.height)
                    close()
                }
                drawPath(tail, Color.White)
            }
        }
    }
}

/** Điểm câu đố + chuỗi (ngọn lửa) + đồng hồ, bên dưới là thanh tiến độ cam kết thúc bằng huy hiệu cấp kế. */
@Composable
private fun CoachHud(
    score: Int,
    streak: Int,
    seconds: Int,
    progress: Float,
    nextLevel: Int,
    modifier: Modifier = Modifier,
) {
    Column(modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.Center) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(score.toString(), color = Color.White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.LocalFireDepartment, contentDescription = "Chuỗi", tint = FlameOrange, modifier = Modifier.size(24.dp).padding(bottom = 3.dp))
            Text(
                streak.toString(), color = FlameOrange, fontSize = 18.sp, lineHeight = 26.sp,
                fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 2.dp),
            )
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.Schedule, contentDescription = "Thời gian", tint = DimBlue, modifier = Modifier.size(20.dp).padding(bottom = 3.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                "%d:%02d".format(seconds / 60, seconds % 60), color = DimBlue, fontSize = 17.sp,
                lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 2.dp),
            )
        }
        Box(Modifier.fillMaxWidth().height(44.dp)) {
            PuzzleProgressBar(progress, Modifier.align(Alignment.CenterStart).fillMaxWidth().padding(end = 24.dp))
            PuzzleBadge(number = nextLevel, size = 44.dp, modifier = Modifier.align(Alignment.CenterEnd))
        }
    }
}

/** Thanh tiến độ: giá trị animate chỉ được đọc trong drawBehind ⇒ chạy mượt, không recomposition. */
@Composable
private fun PuzzleProgressBar(progress: Float, modifier: Modifier = Modifier) {
    val anim = animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "puzzleProgress")
    Box(
        modifier
            .height(16.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x33FFFFFF))
            .drawBehind {
                val w = size.width * anim.value.coerceAtLeast(0.06f)
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Color(0xFFFFA43A), Color(0xFFFF6A00)), 0f, w),
                    size = Size(w, size.height),
                    cornerRadius = CornerRadius(size.height / 2f),
                )
                drawRoundRect(
                    Color(0x66FFFFFF),
                    topLeft = Offset(5.dp.toPx(), 2.dp.toPx()),
                    size = Size((w - 10.dp.toPx()).coerceAtLeast(0f), 3.dp.toPx()),
                    cornerRadius = CornerRadius(1.5.dp.toPx()),
                )
            },
    )
}

/** Một nút của thanh công cụ đáy: biểu tượng trên, nhãn dưới; mờ đi khi không dùng được. */
@Composable
private fun ToolbarButton(
    icon: ImageVector,
    label: String,
    tint: Color,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
) {
    Column(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = label, tint = if (enabled) tint else tint.copy(alpha = 0.3f), modifier = Modifier.size(30.dp))
        Text(
            label,
            color = if (!enabled) SoftBlue.copy(alpha = 0.35f) else if (highlight) OkGreen else SoftBlue,
            fontSize = 13.sp,
            fontWeight = if (highlight) FontWeight.ExtraBold else FontWeight.SemiBold,
        )
    }
}
