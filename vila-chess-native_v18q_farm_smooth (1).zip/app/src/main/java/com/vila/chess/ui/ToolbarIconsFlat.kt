package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Icon thanh công cụ dạng PHẲNG, một màu (thay bộ 2.5D nhiều màu cũ): vẽ trên lưới 24 x 24, tô bằng màu nội dung hiện tại
 * của nút (LocalContentColor) nên icon và chữ luôn cùng màu, đổi theo trạng thái bật/tắt của ToolbarButton.
 * Dùng chung cho trận Bot, Online và PvP.
 */
enum class ToolIcon { OPTIONS, FLAG, BULB, BARS, UNDO, REFRESH, DRAW, CHAT, EXIT }

internal val LocalToolbarEnabled = compositionLocalOf { true }
internal val LocalToolbarActive = compositionLocalOf { false }

@Composable
internal fun ToolbarIcon(kind: ToolIcon, modifier: Modifier = Modifier) {
    val color = LocalContentColor.current
    val active = LocalToolbarActive.current && LocalToolbarEnabled.current
    Canvas(modifier.size(28.dp)) {
        val s = size.minDimension / 24f
        withTransform({ scale(s, s, Offset.Zero) }) { drawTool(kind, color, active) }
    }
}

private fun DrawScope.drawTool(kind: ToolIcon, c: Color, active: Boolean) {
    when (kind) {
        ToolIcon.OPTIONS -> for (y in floatArrayOf(5.6f, 12f, 18.4f)) {
            drawCircle(c, 2.2f, Offset(4.6f, y))
            drawLine(c, Offset(10f, y), Offset(20.6f, y), strokeWidth = 3.2f, cap = StrokeCap.Round)
        }
        ToolIcon.FLAG -> {
            drawRoundRect(c, Offset(3.6f, 2.6f), Size(2.4f, 18.8f), CornerRadius(1.2f, 1.2f))
            drawPath(FlagPath, c)
            drawPath(FlagPath, c, style = Stroke(width = 0.8f, join = StrokeJoin.Round))
        }
        ToolIcon.BULB -> {
            if (active) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(c.copy(alpha = 0.30f), Color.Transparent), center = Offset(12f, 10.6f), radius = 12f),
                    radius = 12f, center = Offset(12f, 10.6f),
                )
            }
            for (deg in intArrayOf(205, 240, 270, 300, 335)) {      // chấm "tia sáng" quanh đỉnh bóng
                val a = deg * PI.toFloat() / 180f
                drawCircle(c, 0.85f, Offset(12f + 9.4f * cos(a), 10.6f + 9.4f * sin(a)))
            }
            drawCircle(c, 5.6f, Offset(12f, 10.6f))
            drawPath(BulbNeck, c)
            drawRoundRect(c, Offset(9.9f, 17.9f), Size(4.2f, 1.7f), CornerRadius(0.85f, 0.85f))
            drawRoundRect(c, Offset(10.6f, 20.3f), Size(2.8f, 1.6f), CornerRadius(0.8f, 0.8f))
        }
        ToolIcon.BARS -> {
            drawRoundRect(c, Offset(2.7f, 13f), Size(5f, 8f), CornerRadius(1.5f, 1.5f))
            drawRoundRect(c, Offset(9.5f, 8f), Size(5f, 13f), CornerRadius(1.5f, 1.5f))
            drawRoundRect(c, Offset(16.3f, 3f), Size(5f, 18f), CornerRadius(1.5f, 1.5f))
        }
        ToolIcon.UNDO -> {
            drawPath(UndoPath, c)
            drawPath(UndoPath, c, style = Stroke(width = 1.6f, join = StrokeJoin.Round))
        }
        ToolIcon.REFRESH -> {
            val cx = 12f; val cy = 12f; val r = 7.4f
            val start = -50f; val sweep = 275f
            val end = (start + sweep) * PI.toFloat() / 180f
            val ex = cx + r * cos(end); val ey = cy + r * sin(end)
            val tx = -sin(end); val ty = cos(end)           // tiếp tuyến (chiều kim đồng hồ)
            val nx = cos(end); val ny = sin(end)            // pháp tuyến (hướng ra ngoài)
            drawArc(c, start, sweep, false, Offset(cx - r, cy - r), Size(2 * r, 2 * r), style = Stroke(width = 2.6f, cap = StrokeCap.Round))
            val head = Path().apply {
                moveTo(ex + tx * 5.2f, ey + ty * 5.2f)
                lineTo(ex + nx * 4.2f, ey + ny * 4.2f)
                lineTo(ex - nx * 4.2f, ey - ny * 4.2f)
                close()
            }
            drawPath(head, c)
            drawPath(head, c, style = Stroke(width = 1f, join = StrokeJoin.Round))
        }
        ToolIcon.DRAW -> {                                   // "½" vẽ bằng nét, cùng độ dày với các icon khác
            drawPath(DrawOne, c, style = Stroke(width = 2.2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawLine(c, Offset(16f, 3.6f), Offset(8f, 20.4f), strokeWidth = 2f, cap = StrokeCap.Round)
            drawPath(DrawTwo, c, style = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        ToolIcon.CHAT -> drawPath(ChatPath, c)
        ToolIcon.EXIT -> {                                   // khung cửa "[" + mũi tên đi ra, cùng độ dày nét với icon khác
            val line = Stroke(width = 2.4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(ExitDoor, c, style = line)
            drawLine(c, Offset(9.6f, 12f), Offset(20.2f, 12f), strokeWidth = 2.4f, cap = StrokeCap.Round)
            drawPath(ExitArrow, c, style = line)
        }
    }
}

private val ExitDoor = Path().apply {
    moveTo(10.4f, 3.8f)
    lineTo(5.4f, 3.8f)
    lineTo(5.4f, 20.2f)
    lineTo(10.4f, 20.2f)
}

private val ExitArrow = Path().apply {
    moveTo(16.2f, 7.6f)
    lineTo(20.6f, 12f)
    lineTo(16.2f, 16.4f)
}

private val FlagPath = Path().apply {
    moveTo(5.6f, 4.4f)
    cubicTo(8.6f, 2.8f, 11f, 6f, 14f, 5f)
    cubicTo(16f, 4.4f, 18f, 3.8f, 20.4f, 4.2f)
    lineTo(20.4f, 13.6f)
    cubicTo(18f, 13.2f, 16f, 13.8f, 14f, 14.6f)
    cubicTo(11f, 15.8f, 8.6f, 12.6f, 5.6f, 14.2f)
    close()
}

private val BulbNeck = Path().apply {
    moveTo(8.6f, 14.2f)
    cubicTo(9.6f, 15.2f, 9.9f, 16f, 9.9f, 17f)
    lineTo(14.1f, 17f)
    cubicTo(14.1f, 16f, 14.4f, 15.2f, 15.4f, 14.2f)
    close()
}

private val UndoPath = Path().apply {
    moveTo(10f, 9f)
    lineTo(10f, 5f)
    lineTo(3f, 12f)
    lineTo(10f, 19f)
    lineTo(10f, 14.9f)
    cubicTo(15f, 14.9f, 18.5f, 16.5f, 21f, 20f)
    cubicTo(20f, 15f, 17f, 10f, 10f, 9f)
    close()
}

private val DrawOne = Path().apply {
    moveTo(5.2f, 6.4f); lineTo(8.2f, 4.4f); lineTo(8.2f, 12f)
}

private val DrawTwo = Path().apply {
    moveTo(13.2f, 15f)
    cubicTo(13.2f, 12.6f, 18.8f, 12.6f, 18.8f, 15.4f)
    cubicTo(18.8f, 17.4f, 14f, 18.6f, 13.2f, 20.4f)
    lineTo(19.6f, 20.4f)
}

private val ChatPath = Path().apply {
    moveTo(6.8f, 3.6f)
    lineTo(17.2f, 3.6f)
    cubicTo(19.3f, 3.6f, 21f, 5.3f, 21f, 7.4f)
    lineTo(21f, 12.6f)
    cubicTo(21f, 14.7f, 19.3f, 16.4f, 17.2f, 16.4f)
    lineTo(12.4f, 16.4f)
    lineTo(7.4f, 20.8f)
    lineTo(7.4f, 16.4f)
    lineTo(6.8f, 16.4f)
    cubicTo(4.7f, 16.4f, 3f, 14.7f, 3f, 12.6f)
    lineTo(3f, 7.4f)
    cubicTo(3f, 5.3f, 4.7f, 3.6f, 6.8f, 3.6f)
    close()
}
