package com.vila.chess

import com.vila.chess.bots.BotLayerData
import com.vila.chess.bots.BotMotionData
import com.vila.chess.bots.BotRepository
import com.vila.chess.bots.FaceKind
import org.junit.Assert.assertTrue
import org.junit.Test

class BotLayerDataTest {
    @Test fun every_bot_has_layers_with_eyes_and_body() {
        for (b in BotRepository.bots) {
            val f = BotLayerData.byId[b.id]
            assertTrue("${b.id} thiếu dữ liệu lớp (chạy tools/botfaces_layers.py --android)", f != null)
            val kinds = f!!.layers.map { it.kind }
            assertTrue("${b.id} thiếu BG", FaceKind.BG in kinds)
            assertTrue("${b.id} thiếu BODY", FaceKind.BODY in kinds)
            assertTrue("${b.id} thiếu EYES", FaceKind.EYES in kinds)
            assertTrue("${b.id} thiếu MOUTH", FaceKind.MOUTH in kinds)
            assertTrue("${b.id} eyeCy", f.eyeCy in 15f..30f)
            assertTrue("${b.id} mouthCy", f.mouthCy in 24f..36f)
        }
    }

    @Test fun layer_order_is_bottom_to_top() {
        for ((id, f) in BotLayerData.byId) {
            val k = f.layers.map { it.kind }
            assertTrue("$id: BG phải đứng đầu", k.first() == FaceKind.BG)
            assertTrue("$id: BODY dưới EYES", k.indexOf(FaceKind.BODY) < k.indexOf(FaceKind.EYES))
        }
    }

    @Test fun detail_motion_values_are_sane_and_weak_bots_are_more_nervous() {
        for ((id, m) in BotMotionData.byId) {
            assertTrue("$id blinkEveryMs", m.blinkEveryMs in 1500..7000)
            assertTrue("$id blinkMs", m.blinkMs in 80..220)
            assertTrue("$id lookDp", m.lookDp in 0.4f..2.5f)
            assertTrue("$id talkMs", m.talkMs in 100..320)
            assertTrue("$id mouthOpen", m.mouthOpen in 1.1f..1.9f)
        }
        val weak = BotMotionData.byId.getValue("martin"); val strong = BotMotionData.byId.getValue("mittens")
        assertTrue(weak.blinkEveryMs < strong.blinkEveryMs)
        assertTrue(weak.talkMs < strong.talkMs)
    }
}
