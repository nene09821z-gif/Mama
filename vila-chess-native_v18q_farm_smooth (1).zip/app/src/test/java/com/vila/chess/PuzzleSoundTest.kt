package com.vila.chess

import com.vila.chess.game.Puzzle
import com.vila.chess.game.PuzzleSession
import com.vila.chess.game.PuzzleStep
import com.vila.chess.game.Sfx
import com.vila.chess.core.moveFrom
import com.vila.chess.core.moveTo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Tiếng phát ra ở câu đố / bài học phải khớp loại nước đi (đi, ăn, chiếu, nhập thành, phong cấp). */
class PuzzleSoundTest {
    private fun puzzle(fen: String, vararg moves: String) = Puzzle(1, "t", fen, moves.toList(), 1000, emptyList())

    @Test
    fun quietSetupMoveAndCaptureReply() {
        // Đen đi a7a6 (đi thường); Trắng Qd1xd8+ vừa ăn quân vừa chiếu => ưu tiên tiếng chiếu
        val s = PuzzleSession(puzzle("3r2k1/p7/8/8/8/8/8/3QK3 b - - 0 1", "a7a6", "d1d8", "g8g7"))
        assertEquals(Sfx.MOVE, s.setupSfx)
        val r = s.submit(3, 59)   // d1 -> d8, ăn xe + chiếu
        assertTrue(r is PuzzleStep.Correct)
        assertEquals(Sfx.CHECK, (r as PuzzleStep.Correct).playerSfx)
    }

    @Test
    fun plainCaptureGivesCaptureSound() {
        val s = PuzzleSession(puzzle("7k/p7/8/3r4/8/8/8/3QK3 b - - 0 1", "a7a6", "d1d5", "h8h7"))
        val r = s.submit(3, 35) as PuzzleStep.Correct   // d1 -> d5 ăn xe, không chiếu
        assertEquals(Sfx.CAPTURE, r.playerSfx)
        assertEquals(Sfx.MOVE, r.replySfx)
        assertEquals(63, moveFrom(r.reply!!))
        assertEquals(55, moveTo(r.reply!!))
    }

    @Test
    fun promotionAndCastleSounds() {
        val promo = PuzzleSession(puzzle("8/P6k/8/8/8/8/8/K7 b - - 0 1", "h7h6", "a7a8q", "h6h5"))
        val r = promo.submit(48, 56) as PuzzleStep.Correct
        assertEquals(Sfx.PROMOTE, r.playerSfx)

        val castle = PuzzleSession(puzzle("r3k3/8/8/8/8/8/8/R3K2R b KQ - 0 1", "a8a7", "e1g1", "a7a6"))
        val c = castle.submit(4, 6) as PuzzleStep.Correct
        assertEquals(Sfx.CASTLE, c.playerSfx)
    }
}
