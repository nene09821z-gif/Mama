package com.vila.chess

import com.vila.chess.game.Sfx
import com.vila.chess.game.SoundPacks
import com.vila.chess.ui.BoardThemes
import com.vila.chess.ui.Wallpapers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class AppearanceTest {

    @Test
    fun boardThemesHaveUniqueIdsAndTwoDifferentColors() {
        val ids = BoardThemes.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(BoardThemes.exists(BoardThemes.DEFAULT))
        for (t in BoardThemes.all) assertNotEquals("${t.id}: ô sáng = ô tối", t.light, t.dark)
        assertTrue(BoardThemes.all.size >= 15)
    }

    @Test
    fun unknownThemeFallsBackToFirst() {
        assertEquals(BoardThemes.all[0], BoardThemes.byId("khong-co"))
    }

    @Test
    fun soundPacksUniqueAndDefaultExists() {
        val ids = SoundPacks.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(SoundPacks.exists(SoundPacks.DEFAULT))
        assertEquals("move", SoundPacks.rawName("classic", Sfx.MOVE))
        assertEquals("gameend", SoundPacks.rawName("classic", Sfx.END))
        assertEquals("wood_capture", SoundPacks.rawName("wood", Sfx.CAPTURE))
        assertEquals("musicbox_end", SoundPacks.rawName("musicbox", Sfx.END))
    }

    /** 5 bộ nhẹ nhàng (v17o) phải có trong danh sách; id chỉ gồm a-z/0-9/_ vì trở thành tên tài nguyên res/raw. */
    @Test
    fun chillSoundPacksRegistered() {
        for (id in listOf("marble", "nature", "space", "musicbox", "zen")) {
            assertTrue("thiếu bộ $id", SoundPacks.exists(id))
            assertTrue(Regex("[a-z0-9]+").matches(id))
        }
    }

    /** Mọi (bộ × tiếng) đều phải có file wav thật trong res/raw (thiếu file = im lặng khi chọn bộ đó). */
    @Test
    fun everySoundPackHasAllSixFiles() {
        val raw = listOf("src/main/res/raw", "app/src/main/res/raw").map { File(it) }.firstOrNull { it.isDirectory }
            ?: return   // chạy từ thư mục lạ: bỏ qua thay vì làm CI đỏ oan
        for (p in SoundPacks.all) {
            val files = Sfx.values().map { File(raw, SoundPacks.rawName(p.id, it) + ".wav") }
            // Bộ tải lúc build (main.yml) có thể vắng hẳn khi chạy test cục bộ / khi bước tải lỗi: app tự ẩn chúng.
            // Nhưng có mặt thì phải đủ cả 6, không được dở dang.
            if (p.id in SoundPacks.downloaded && files.none { it.isFile }) continue
            for (f in files) assertTrue("thiếu ${f.name}", f.isFile && f.length() > 100)
        }
    }

    /** 5 bộ nhạc cụ thật (VCSL, CC0) đã đăng ký, nằm sau 12 bộ cũ, và id hợp lệ làm tên tài nguyên raw. */
    @Test
    fun vcslSoundPacksRegisteredAfterOldOnes() {
        val ids = listOf("vibes", "harp", "glock", "marimba", "ocarina")
        assertEquals(ids.toSet(), SoundPacks.downloaded)
        for (id in ids) {
            assertTrue("thiếu bộ $id", SoundPacks.exists(id))
            assertTrue(Regex("[a-z0-9]+").matches(id))
            assertTrue(SoundPacks.all.indexOfFirst { it.id == id } >= 12)
            assertEquals(id + "_promote", SoundPacks.rawName(id, Sfx.PROMOTE))
        }
        // mô tả <= 40 ký tự để nằm gọn 1 dòng trong ô như các bộ cũ
        for (p in SoundPacks.all) assertTrue("${p.id}: mô tả quá dài", p.desc.length <= 40)
    }

    /** Lưới Chủ đề có 5 cột: số màu bàn cờ chia hết cho 5 để hàng cuối không bị lẻ. */
    @Test
    fun boardThemeCountFillsFiveColumnGrid() {
        assertEquals(0, BoardThemes.all.size % 5)
        assertTrue(BoardThemes.exists("bubblegum"))
    }

    @Test
    fun wallpapersUniqueAndDefaultFirst() {
        val ids = Wallpapers.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals(Wallpapers.DEFAULT, Wallpapers.all[0].id)
        assertTrue(Wallpapers.all.any { it.animated })   // có nền động (Ngân hà)
        assertTrue(!Wallpapers.all[0].animated)          // mặc định là nền tĩnh nhẹ
        assertEquals(Wallpapers.all.size, Wallpapers.all.map { it.label }.toSet().size)
    }

    @Test
    fun unknownWallpaperFallsBackToFirst() {
        assertEquals(Wallpapers.all[0], Wallpapers.byId("khong-co"))
        assertTrue(!Wallpapers.exists("khong-co"))
    }
}
