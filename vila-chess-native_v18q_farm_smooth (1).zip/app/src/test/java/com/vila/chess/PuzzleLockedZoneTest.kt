package com.vila.chess

import com.vila.chess.ui.buildClouds
import com.vila.chess.ui.fogCover
import com.vila.chess.ui.fogHazeAlpha
import com.vila.chess.ui.isRegionLocked
import com.vila.chess.ui.levelsToUnlock
import com.vila.chess.ui.regionOfLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Vùng bị khoá của bản đồ Câu đố: quy tắc khoá, số câu còn lại, mức mây phủ và bố cục mây. */
class PuzzleLockedZoneTest {

    @Test
    fun regionsAfterCurrentAreLocked() {
        assertFalse(isRegionLocked(0, 0))
        assertTrue(isRegionLocked(1, 0))
        assertTrue(isRegionLocked(4, 0))
        assertFalse(isRegionLocked(1, 1))
        assertFalse(isRegionLocked(0, 3))   // vùng đã qua không bao giờ khoá
    }

    @Test
    fun levelsToUnlockCountsRemainingPuzzlesOfRegion() {
        assertEquals(496, levelsToUnlock(1))      // vừa vào vùng 1: còn đủ 496 câu
        assertEquals(1, levelsToUnlock(496))      // câu cuối của vùng 1
        assertEquals(496, levelsToUnlock(497))    // sang vùng 2
        assertEquals(1, levelsToUnlock(992))
        // Giải xong câu cuối ⇒ currentLevel nhảy sang vùng kế ⇒ vùng đó hết khoá.
        assertFalse(isRegionLocked(regionOfLevel(497), regionOfLevel(497)))
    }

    @Test
    fun fogGrowsWithHeight() {
        assertEquals(0f, fogCover(0f), 0f)
        assertEquals(0f, fogCover(7f), 0f)         // 7 level đầu của vùng khoá còn thấy rõ
        assertEquals(1f, fogCover(25f), 1e-6f)     // từ 25 level: mây kín
        assertEquals(1f, fogCover(500f), 0f)
        assertTrue(fogCover(12f) in 0.01f..0.99f)
        assertEquals(0f, fogHazeAlpha(0f), 0f)     // không có đường ranh sương ở ranh giới vùng
        assertTrue(fogHazeAlpha(48f) > fogHazeAlpha(16f))
        assertEquals(0.44f, fogHazeAlpha(10_000f), 1e-6f)
    }

    @Test
    fun cloudLayoutIsDeterministic() {
        val a = buildClouds(chapter = 31, d = 0)
        val b = buildClouds(chapter = 31, d = 0)
        assertEquals(a.size, b.size)
        for (i in a.indices) {
            assertEquals(a[i].cx, b[i].cx, 0f)
            assertEquals(a[i].cy, b[i].cy, 0f)
            assertEquals(a[i].template, b[i].template)
        }
        for (i in 1 until a.size) assertTrue("mây phải sắp theo cy tăng", a[i - 1].cy <= a[i].cy)
    }

    @Test
    fun sidesAlwaysHaveCloudsAndCenterFillsUp() {
        val first = buildClouds(chapter = 31, d = 0)
        val deep = buildClouds(chapter = 31 + 5, d = 5)
        fun side(l: List<com.vila.chess.ui.CloudSpec>) = l.count { it.cx < 0.2f || it.cx > 0.8f }
        fun center(l: List<com.vila.chess.ui.CloudSpec>) = l.count { it.cx in 0.2f..0.8f }
        assertTrue("khối sát ranh giới vẫn có mây hai bên", side(first) >= 16)
        assertTrue("khối sâu có mây hai bên", side(deep) >= 16)
        assertTrue("khối sâu mây giữa đường dày hơn khối sát ranh giới", center(deep) > center(first))
        assertTrue("khối sâu: mỗi hàng ≥ 2 mây giữa", center(deep) >= 16)
        for (c in deep + first) {
            assertTrue(c.template in 0..2)
            assertTrue(c.cy in -0.05f..1.05f)
        }
    }
}
