package com.vila.chess

import com.vila.chess.core.Position
import com.vila.chess.game.Coach
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Thanh trượt "Độ mạnh gợi ý tối đa" (Elo 400..3200) -> độ sâu gợi ý. */
class CoachStrengthTest {
    @Test fun maxEloKeepsOldDefaultDepth() = assertEquals(8, Coach.depthForElo(3200))

    @Test fun lowEloIsShallowAndMonotonic() {
        assertEquals(2, Coach.depthForElo(400))
        var prev = 0
        for (elo in 400..3200 step 50) {
            val d = Coach.depthForElo(elo)
            assertTrue(d in 2..8 && d >= prev)
            prev = d
        }
    }

    @Test fun hintStillReturnsLegalMoveAtLowDepth() {
        val h = Coach.hint(Position.start(), Coach.depthForElo(400)) { false }
        assertTrue(h != null && h.move != 0)
    }
}
