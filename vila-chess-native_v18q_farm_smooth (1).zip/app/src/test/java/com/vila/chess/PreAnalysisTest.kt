package com.vila.chess

import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.review.DeviceTier
import com.vila.chess.review.EngineConfig
import com.vila.chess.review.EngineResult
import com.vila.chess.review.NearEnd
import com.vila.chess.review.PreAnalysisCache
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PreAnalysisTest {
    private fun near(fen: String, ply: Int, clockOn: Boolean = false, lowest: Long = 0, base: Long = 0): Boolean {
        val p = Position.fromFen(fen)
        return NearEnd.isNearEnd(p.board, p.halfmove, ply, clockOn, lowest, base)
    }

    @Test
    fun openingAndMiddlegameAreNotNearEnd() {
        assertFalse(near(START_FEN, 40))
        assertFalse(near("r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4", 20))
    }

    @Test
    fun tooEarlyIsNeverNearEnd() {
        // 3 quân nhưng mới 10 nửa nước (thế bài tập): không tính là gần xong
        assertFalse(near("8/8/4k3/8/8/4K3/4P3/8 w - - 0 1", 10))
    }

    @Test
    fun endgameFewPiecesIsNearEnd() {
        assertTrue(near("8/8/4k3/8/8/4K3/4P3/8 w - - 0 1", 30))
        // 8 quân vẫn tính, 9 quân thì chưa (nếu không chênh quân)
        assertTrue(near("4k3/ppp5/8/8/8/8/PPP5/4K3 w - - 0 1", 30))
        assertFalse(near("4k3/pppp4/8/8/8/8/PPP5/4K3 w - - 0 1", 30))
    }

    @Test
    fun bigMaterialGapIsNearEndOnlyAfterPly24() {
        val fen = "rnb1kbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"   // Đen mất Hậu
        assertFalse(near(fen, 20))
        assertTrue(near(fen, 26))
    }

    @Test
    fun lowClockAndFiftyMoveRule() {
        val mid = "r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 4 4"
        // 3 phút = 180s: ngưỡng = max(15s, 12% = 21,6s)
        assertTrue(near(mid, 30, clockOn = true, lowest = 20_000, base = 180_000))
        assertFalse(near(mid, 30, clockOn = true, lowest = 60_000, base = 180_000))
        assertFalse(near(mid, 30, clockOn = false, lowest = 1_000, base = 0))
        assertTrue(near("r1bqkb1r/pppp1ppp/2n2n2/4p3/4P3/2N2N2/PPPP1PPP/R1BQKB1R w KQkq - 44 30", 30))
    }

    private val cfg = EngineConfig(DeviceTier.MEDIUM, depth = 18, threads = 2, hashMb = 64, moveTimeoutMs = 1300L)

    @Test
    fun cacheLineRoundTrips() {
        val r = EngineResult("e2e4", -35, null, 17, true, listOf("e2e4", "e7e5", "g1f3"), "d2d4", 12, null, "native", 2)
        val fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        val (f, back) = PreAnalysisCache.decode(PreAnalysisCache.encode(fen, r))!!
        assertEquals(fen, f)
        assertEquals(r, back)
    }

    @Test
    fun cacheRoundTripsMateAndNulls() {
        val r = EngineResult("h5f7", 9990, 1, 20, false, emptyList(), null, null, null, "native", 2)
        val back = PreAnalysisCache.decode(PreAnalysisCache.encode("8/8/8/8/8/8/8/K6k w - - 0 1", r))!!.second
        assertEquals(r, back)
        assertEquals(1, back.mate)
        assertNull(back.secondMove)
    }

    @Test
    fun brokenLinesAreSkipped() {
        val good = PreAnalysisCache.encode("8/8/8/8/8/8/8/K6k w - - 0 1", EngineResult("a1a2", 0, null, 18, false, listOf("a1a2"), "a1b1", 0, null, "native", 2))
        val map = PreAnalysisCache.decodeAll(listOf(good, "", "garbage", good.substring(0, good.length - 6), good.replace("\t0\t", "\tx\t")))
        assertEquals(1, map.size)
    }

    @Test
    fun acceptableNeedsNativeMultiPvAndDepth() {
        val ok = EngineResult("e2e4", 10, null, 15, true, listOf("e2e4"), "d2d4", 5, null, "native", 2)
        assertTrue(PreAnalysisCache.acceptable(ok, cfg))                       // 15 >= 18 - 4
        assertFalse(PreAnalysisCache.acceptable(ok.copy(depthReached = 13), cfg))
        assertFalse(PreAnalysisCache.acceptable(ok.copy(engine = "wasm"), cfg))
        assertFalse(PreAnalysisCache.acceptable(ok.copy(multiPv = 1), cfg))
        assertFalse(PreAnalysisCache.acceptable(ok.copy(bestMove = null), cfg))
        // máy yếu depth 14: sàn 12
        assertTrue(PreAnalysisCache.acceptable(ok.copy(depthReached = 12), cfg.copy(depth = 14)))
        assertFalse(PreAnalysisCache.acceptable(ok.copy(depthReached = 11), cfg.copy(depth = 14)))
    }
}
