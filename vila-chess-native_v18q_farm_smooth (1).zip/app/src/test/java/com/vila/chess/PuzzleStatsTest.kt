package com.vila.chess

import com.vila.chess.game.Puzzle
import com.vila.chess.game.puzzleCoachTip
import com.vila.chess.game.puzzlePlayerMoveCount
import com.vila.chess.game.puzzleRatingDelta
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PuzzleStatsTest {
    private fun puzzle(moves: Int, themes: List<String> = emptyList()) =
        Puzzle(1, "x", "8/8/8/8/8/8/8/8 w - - 0 1", List(moves) { "a1a2" }, 1000, themes)

    @Test fun cleanSolveAlwaysGainsAtLeastOne() {
        assertTrue(puzzleRatingDelta(2500, 400, 0) >= 1)
        assertTrue(puzzleRatingDelta(600, 600, 0) in 1..24)
    }

    @Test fun hardPuzzleGivesMoreThanEasyOne() {
        assertTrue(puzzleRatingDelta(600, 1200, 0) > puzzleRatingDelta(600, 400, 0))
    }

    @Test fun solvingAfterMistakeNeverGainsMoreThanHalfK() {
        assertTrue(puzzleRatingDelta(600, 2000, 3) <= 12)
        assertTrue(puzzleRatingDelta(1500, 400, 1) < 0)   // sai ở câu dễ ⇒ bị trừ
    }

    @Test fun playerMoveCountMatchesLichessLayout() {
        assertEquals(1, puzzlePlayerMoveCount(puzzle(2)))
        assertEquals(1, puzzlePlayerMoveCount(puzzle(3)))
        assertEquals(2, puzzlePlayerMoveCount(puzzle(4)))
        assertEquals(3, puzzlePlayerMoveCount(puzzle(6)))
    }

    @Test fun coachTipPrefersMateThenFallsBack() {
        assertTrue(puzzleCoachTip(puzzle(2, listOf("mateIn1"))).contains("chiếu hết"))
        assertTrue(puzzleCoachTip(puzzle(2, listOf("fork"))).contains("fork"))
        assertTrue(puzzleCoachTip(puzzle(2, listOf("unknownTheme"))).isNotBlank())
    }
}
