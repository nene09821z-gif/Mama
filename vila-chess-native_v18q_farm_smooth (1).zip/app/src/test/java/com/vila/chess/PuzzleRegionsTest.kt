package com.vila.chess

import com.vila.chess.ui.PropCat
import com.vila.chess.ui.PropKind
import com.vila.chess.ui.SceneVariants
import com.vila.chess.ui.layoutAroundPath
import com.vila.chess.ui.levelXFrac
import com.vila.chess.ui.mapChapterFor
import com.vila.chess.ui.puzzleChapterFor
import com.vila.chess.ui.regionOfLevel
import com.vila.chess.ui.regionRangeText
import com.vila.chess.ui.themedProps
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Vùng của bản đồ Câu đố (496 câu/vùng), đường zig-zag chéo và bố trí vật cảnh quanh đường. */
class PuzzleRegionsTest {

    @Test
    fun regionBoundaries() {
        assertEquals(0, regionOfLevel(1))
        assertEquals(0, regionOfLevel(496))
        assertEquals(1, regionOfLevel(497))
        assertEquals(4, regionOfLevel(1985))
        assertEquals(5, regionOfLevel(2481))
    }

    @Test
    fun regionRangeTextClampsToLastLevel() {
        assertEquals("1-496", regionRangeText(0, 300000))
        assertEquals("993-1488", regionRangeText(2, 300000))
        assertEquals("2977-3000", regionRangeText(6, 3000))
    }

    @Test
    fun pathIsTriangleWaveInsideTrack() {
        for (l in 1..64) {
            val x = levelXFrac(l)
            assertTrue("level $l x=$x", x in 0.2199f..0.7801f)
        }
        assertEquals(0.78f, levelXFrac(1), 1e-4f)   // level 1: mép phải
        assertEquals(0.22f, levelXFrac(5), 1e-4f)   // sau 4 bước chéo: mép trái
        assertEquals(0.78f, levelXFrac(9), 1e-4f)   // chu kỳ 8
        assertEquals(levelXFrac(3), levelXFrac(11), 1e-6f)
    }

    @Test
    fun sceneryLayoutIsDeterministicAndKeepsDensity() {
        for (theme in 0 until 5) {
            val c = mapChapterFor(theme)
            val a = layoutAroundPath(SceneVariants[0], c)
            val b = layoutAroundPath(SceneVariants[0], c)
            assertEquals(a.size, b.size)
            assertTrue("theme $theme chỉ còn ${a.size} vật", a.size >= 25)
            for (i in a.indices) assertEquals(a[i].x, b[i].x, 0f)
        }
    }

    @Test
    fun puzzleMapStartsWithFarmThenTheFiveOriginalChapters() {
        val names = (0 until 6).map { puzzleChapterFor(it).name }
        assertEquals("NÔNG TRẠI", names[0])
        for (i in 0 until 5) assertEquals(mapChapterFor(i).name, names[i + 1])   // 5 chủ đề cũ giữ nguyên thứ tự, lùi 1 vùng
        assertEquals(names[0], puzzleChapterFor(6).name)                          // lặp vòng sau 6 vùng
        // Bài học vẫn là 5 chủ đề, vùng đầu vẫn là Rừng xanh.
        assertEquals(mapChapterFor(0).name, mapChapterFor(5).name)
        val farmPools = puzzleChapterFor(0).pools!!
        for (cat in PropCat.values()) assertTrue("Nông trại thiếu nhóm $cat", !farmPools[cat].isNullOrEmpty())
    }

    @Test
    fun farmSceneryLayoutIsDeterministicAndKeepsDensity() {
        val c = puzzleChapterFor(0)
        val a = layoutAroundPath(SceneVariants[0], c)
        val b = layoutAroundPath(SceneVariants[0], c)
        assertEquals(a.size, b.size)
        assertTrue("Nông trại chỉ còn ${a.size} vật", a.size >= 25)   // cùng ngưỡng với 5 chủ đề cũ
        for (i in a.indices) assertEquals(a[i].x, b[i].x, 0f)
    }

    /** v18p: bản đồ nông trại phải có cây · bụi · hoa · cỏ chiếm đa số (trước đó toàn ruộng/vật nuôi nên trống trải, không giống chess.com). */
    @Test
    fun farmSceneryIsMostlyTreesBushesFlowersAndGrass() {
        val plants = setOf(
            PropKind.FarmTree, PropKind.FarmTreeApple, PropKind.FarmPine, PropKind.FarmPoplar,
            PropKind.FarmBush, PropKind.FarmBushBerry, PropKind.FarmBushBlossom, PropKind.FarmHedge,
            PropKind.FarmFlowersDaisy, PropKind.FarmFlowersTulip,
            PropKind.FarmGrassA, PropKind.FarmGrassB, PropKind.FarmGrassC, PropKind.FarmMushrooms, PropKind.FarmStump,
        )
        val c = puzzleChapterFor(0)
        for (v in SceneVariants.indices) {
            val props = layoutAroundPath(themedProps(SceneVariants[v], c, emptySet()), c)
            val n = props.count { it.kind in plants }
            assertTrue("biến thể $v: chỉ $n/${props.size} vật là cây cỏ", n * 100 >= props.size * 50)
            assertTrue("biến thể $v: có ${props.size} vật, quá thưa", props.size >= 40)
        }
    }

    @Test
    fun farmTreesAreBiggerThanTheBaseLayoutAndFillPoolIsGreen() {
        val c = puzzleChapterFor(0)
        assertTrue("treeBoost phải > 1", c.treeBoost > 1f)
        assertTrue("fillExtra phải > 5 để cảnh dày", c.fillExtra > 5)
        val fill = c.fill!!
        assertTrue(fill.isNotEmpty())
        // Vật bù mép chỉ gồm cỏ / hoa / bụi / nấm, không có công trình hay vật nuôi.
        val ok = setOf(
            PropKind.FarmGrassA, PropKind.FarmGrassB, PropKind.FarmGrassC, PropKind.FarmFlowersDaisy, PropKind.FarmFlowersTulip,
            PropKind.FarmBush, PropKind.FarmBushBerry, PropKind.FarmBushBlossom, PropKind.FarmMushrooms,
        )
        for (k in fill) assertTrue("vật bù mép $k không phải cây cỏ", k in ok)
        // 5 chủ đề cũ giữ nguyên hành vi mặc định.
        for (t in 0 until 5) {
            val o = mapChapterFor(t)
            assertEquals(1f, o.treeBoost, 0f)
            assertEquals(5, o.fillExtra)
        }
    }
}
