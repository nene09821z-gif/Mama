package com.vila.chess

import com.vila.chess.ui.HorseFrame
import kotlin.math.abs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Chuyển động con ngựa 3D khi nhảy từ ô này sang ô kế (xem ui/HorseMotion.kt). */
class HorseMotionTest {

    private fun frame(t: Float, clock: Float = 0f) = HorseFrame().also { it.set(t, clock) }

    @Test
    fun idleBeforeAndAfterHop() {
        val a = frame(0f)
        assertEquals(0f, a.s, 0f)
        assertEquals(0f, a.lift, 0f)
        assertEquals(0f, a.legs, 0f)
        assertEquals(0f, a.dust, 0f)
        val b = frame(1f)
        assertEquals(1f, b.s, 0f)
        assertEquals(0f, b.lift, 0f)
        assertEquals(0f, b.legs, 0f)
        assertEquals(0f, b.dust, 0f)
    }

    @Test
    fun apexIsHalfwayAlongTheFlightWithLegsTucked() {
        val f = frame(0.52f)   // giữa pha bay (0,20 → 0,84)
        assertEquals(1f, f.lift, 1e-3f)
        assertEquals(0.5f, f.s, 1e-3f)
        assertEquals(1f, f.legs, 1e-3f)
    }

    @Test
    fun liftStaysBetweenGroundAndApexAndOnlyFlightLeavesTheGround() {
        var t = 0f
        while (t <= 1f) {
            val f = frame(t)
            assertTrue("lift=${f.lift} t=$t", f.lift in 0f..1.0001f)
            if (t < 0.2f || t > 0.84f) assertEquals("t=$t", 0f, f.lift, 0f)
            assertTrue("squashY=${f.squashY} t=$t", f.squashY in 0.75f..1.15f)
            t += 0.01f
        }
    }

    @Test
    fun poseIsContinuousThroughTheWholeHop() {
        var prev = frame(0.001f)
        var t = 0.002f
        while (t <= 0.999f) {
            val f = frame(t)
            assertTrue("legs jump at t=$t", abs(f.legs - prev.legs) < 0.05f)
            assertTrue("squash jump at t=$t", abs(f.squashY - prev.squashY) < 0.05f)
            assertTrue("lift jump at t=$t", abs(f.lift - prev.lift) < 0.05f)
            assertTrue("pitch jump at t=$t", abs(f.pitch - prev.pitch) < 0.3f)
            assertTrue("swing jump at t=$t", abs(f.swing - prev.swing) < 0.05f)
            assertTrue("s jump at t=$t", abs(f.s - prev.s) < 0.01f)
            prev = f
            t += 0.001f
        }
    }

    @Test
    fun dustOnlyAppearsOnLanding() {
        assertEquals(0f, frame(0.5f).dust, 0f)
        assertEquals(0f, frame(0.84f).dust, 1e-6f)
        assertTrue(frame(0.92f).dust > 0f)
        assertEquals(0f, frame(1f).dust, 0f)
    }

    @Test
    fun blinkHappensBrieflyAndRepeats() {
        assertEquals(0f, frame(0f, clock = 0.5f / 6f).blink, 0f)   // giữa 2 lần chớp: mở mắt
        assertTrue(frame(0f, clock = 0.03f / 6f).blink > 0.9f)     // đang chớp
        assertEquals(frame(0f, clock = 0.03f / 6f).blink, frame(0f, clock = 1.03f / 6f).blink, 1e-5f)
    }
}
