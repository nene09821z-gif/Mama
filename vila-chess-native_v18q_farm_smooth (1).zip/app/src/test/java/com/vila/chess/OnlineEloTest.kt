package com.vila.chess

import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.eloGainMultiplier
import com.vila.chess.game.OnlineElo
import com.vila.chess.game.PlayerStats
import com.vila.chess.game.RatingMode
import com.vila.chess.game.StatsStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OnlineEloTest {
    private val settled = 30   // đã qua giai đoạn người mới

    @Test
    fun kFactorByGamesAndRating() {
        assertEquals(160, OnlineElo.kFactor(1500, 0))
        assertEquals(160, OnlineElo.kFactor(1500, 4))
        assertEquals(100, OnlineElo.kFactor(1500, 5))
        assertEquals(100, OnlineElo.kFactor(1500, 9))
        assertEquals(60, OnlineElo.kFactor(1500, 10))
        assertEquals(60, OnlineElo.kFactor(1500, 19))
        assertEquals(24, OnlineElo.kFactor(1500, 20))
        assertEquals(16, OnlineElo.kFactor(1800, 20))
        assertEquals(10, OnlineElo.kFactor(2400, 20))
    }

    @Test
    fun equalRatingsAreSymmetric() {
        assertEquals(12, OnlineElo.delta(800, 800, 1.0, settled))
        assertEquals(-12, OnlineElo.delta(800, 800, 0.0, settled))
        assertEquals(0, OnlineElo.delta(800, 800, 0.5, settled))
        assertEquals(80, OnlineElo.delta(800, 800, 1.0, 0))      // người mới: K = 160
        assertEquals(-80, OnlineElo.delta(800, 800, 0.0, 0))
    }

    @Test
    fun newcomerClimbsHundredsQuickly() {
        var r = 800
        for (n in 0 until 5) r += OnlineElo.delta(r, 800, 1.0, n)   // 5 ván đầu thắng hết, đối thủ ~800
        assertTrue("sau 5 thắng: $r", r in 1040..1100)
        var s = 800
        for (n in 0 until 5) s += OnlineElo.delta(s, 800, 0.0, n)   // thua hết thì cũng rớt nhanh (đối xứng)
        assertTrue("sau 5 thua: $s", s in 500..560)
    }

    @Test
    fun diffIsCappedAt400() {
        // Chênh 1200 điểm vẫn tính như chênh 400.
        assertEquals(OnlineElo.delta(800, 1200, 1.0, settled), OnlineElo.delta(800, 2000, 1.0, settled))
        assertEquals(22, OnlineElo.delta(800, 2000, 1.0, settled))
        assertEquals(-2, OnlineElo.delta(800, 2000, 0.0, settled))
    }

    @Test
    fun farmingWeakPlayersGivesAlmostNothing() {
        assertEquals(1, OnlineElo.delta(2000, 800, 1.0, settled))              // thắng luôn được tối thiểu +1
        assertEquals(2, OnlineElo.delta(2000, 800, 1.0, settled, gainMultiplier = 2))
        assertEquals(-15, OnlineElo.delta(2000, 800, 0.0, settled))            // thua người quá yếu bị trừ nặng
    }

    @Test
    fun privilegeDoublesGainsOnly() {
        assertEquals(24, OnlineElo.delta(800, 800, 1.0, settled, gainMultiplier = 2))
        assertEquals(-12, OnlineElo.delta(800, 800, 0.0, settled, gainMultiplier = 2))
        assertTrue(OnlineElo.delta(800, 1200, 0.5, settled, gainMultiplier = 2) > 0)   // hòa với người mạnh hơn cũng được x2
    }

    @Test
    fun repeatOpponentIsDampedBothWays() {
        assertEquals(12, OnlineElo.delta(800, 800, 1.0, settled, previousGamesVsOpponent = 2))
        assertEquals(6, OnlineElo.delta(800, 800, 1.0, settled, previousGamesVsOpponent = 3))
        assertEquals(-6, OnlineElo.delta(800, 800, 0.0, settled, previousGamesVsOpponent = 5))
        assertEquals(3, OnlineElo.delta(800, 800, 1.0, settled, previousGamesVsOpponent = 6))
        assertEquals(1, OnlineElo.delta(2000, 800, 1.0, settled, previousGamesVsOpponent = 9))   // vẫn >= +1
    }

    @Test
    fun previewMatchesDelta() {
        val p = OnlineElo.preview(1000, 1100, settled, 0, 2)
        assertEquals(OnlineElo.delta(1000, 1100, 1.0, settled, 0, 2), p.win)
        assertEquals(OnlineElo.delta(1000, 1100, 0.5, settled, 0, 2), p.draw)
        assertEquals(OnlineElo.delta(1000, 1100, 0.0, settled, 0, 2), p.loss)
        assertTrue(p.loss < 0)
    }

    @Test
    fun historyRoundTripAndExpiry() {
        val now = 10_000_000_000L
        val h = OnlineElo.withGame(OnlineElo.withGame(emptyList(), "AAA", now - 1000), "bbb", now - 2000)
        val back = OnlineElo.parseHistory(OnlineElo.serializeHistory(h), now)
        assertEquals(2, back.size)
        assertEquals(1, OnlineElo.previousGames(back, "aaa"))          // không phân biệt hoa thường
        val old = OnlineElo.serializeHistory(listOf(OnlineElo.Entry("AAA", now - OnlineElo.REPEAT_WINDOW_MS - 5)))
        assertEquals(0, OnlineElo.parseHistory(old, now).size)         // quá 24 giờ thì bỏ
        assertEquals(0, OnlineElo.parseHistory("rác;|;x|y", now).size)
        assertEquals(0, OnlineElo.previousGames(back, ""))
    }

    @Test
    fun tiersWithPrivilege() {
        assertEquals(1, eloGainMultiplier(MembershipTier.FREE))
        for (t in listOf(MembershipTier.GOLD, MembershipTier.PLATINUM, MembershipTier.DIAMOND, MembershipTier.FAMILY)) {
            assertEquals(t.name, 2, eloGainMultiplier(t))
        }
    }

    @Test
    fun zeroDeltaKeepsRatingButCountsGame() {
        val old = PlayerStats()
        val next = StatsStore.applyDelta(old, RatingMode.BLITZ, 0, 1.0, today = 100L)
        assertEquals(old.rating(RatingMode.BLITZ), next.rating(RatingMode.BLITZ))
        assertEquals(1, next.played)
        assertEquals(1, next.won)
        assertEquals(0, next.onlineGames[RatingMode.BLITZ.ordinal])   // ván với máy không tính vào số ván online
    }

    @Test
    fun onlineGamesCountedPerMode() {
        val old = PlayerStats()
        val up = StatsStore.applyDelta(old, RatingMode.RAPID, OnlineElo.delta(800, 800, 1.0, 0, 0, 2), 1.0, 100L, countOnline = true)
        assertEquals(960, up.rating(RatingMode.RAPID))                  // người mới: K=160 → +80, đặc quyền x2 → +160
        assertEquals(1, up.onlineGames[RatingMode.RAPID.ordinal])
        assertEquals(0, up.onlineGames[RatingMode.BLITZ.ordinal])
        val down = StatsStore.applyDelta(old, RatingMode.RAPID, OnlineElo.delta(800, 800, 0.0, 0, 0, 2), 0.0, 100L, countOnline = true)
        assertEquals(720, down.rating(RatingMode.RAPID))                // thua -80, không nhân đôi
    }
}
