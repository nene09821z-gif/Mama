# v18p — Nông trại: có cây cỏ hoa lá, nền đồng cỏ thật, bản đồ dày như chess.com

## Vì sao trước đó xấu / trống
- Nền chỉ là MỘT màu xanh phẳng + vài hình thoi mờ.
- Cây · bụi · hoa · cỏ của bố cục gốc bị thay bằng ruộng / vật nuôi / công trình ⇒ gần như không còn thực vật.
- Sprite cũ đặt trên một "đĩa cỏ" cứng (sunflowers, pumpkins) hoặc không có chân cỏ ⇒ trông dán lên nền.

## Mới
- **Nền đồng cỏ** `res/drawable-nodpi/farm_ground.jpg` (768×768, lặp liền hai chiều, ~50 KB): mảng cỏ sáng/tối mềm, bụi cỏ nhiều lá,
  hoa dại, cỏ ba lá, sỏi nhỏ, đốm đất. Sinh bằng `python3 tools/farm/render_ground.py`.
  `ChapterGround` (PuzzleChapters.kt) lát texture bằng `ShaderBrush(ImageShader(..., Repeated))`; pha của gạch tính theo vị trí thế giới của khối
  (`(chapter+1) × chiều cao khối mod 768`) nên hai khối kề nhau ghép liền, không lộ đường cắt.
- **14 sprite thực vật / cảnh quan mới** (render_farm.py, cùng góc nhìn 2.5D low-poly):
  cây sồi (lá dày, 7 khối tán, đỉnh sáng) · sồi táo · thông (4 tầng) · dương · bụi · bụi quả · bụi hoa hồng · hàng rào cây ·
  luống cúc hoạ mi · luống tulip + oải hương · 3 mảng cỏ 2D (cỏ, hàng cỏ thấp, cỏ + hoa dại) · nấm · gốc cây + khúc gỗ · ao có đá, sen, cỏ lau.
- **Mọi vật nông trại có chân cỏ** (`render(..., skirt=)`): vòng bụi cỏ quanh chân, nửa sau vẽ trước vật, nửa trước vẽ sau ⇒ vật "đứng trong cỏ".
  Bỏ đĩa cỏ cứng của hoa hướng dương / bí ngô / bù nhìn. Toàn bộ 19 sprite cũ được dựng lại (tỉ lệ ảnh đổi nhẹ → cập nhật `PropKind`).
- **Bỏ ruộng vẽ trên nền** (bản đầu v18p vẽ 5 ô ruộng bằng Canvas nhưng nền không biết vị trí nút nên ruộng chui dưới nút). Ruộng lúa / cà rốt / bí / hướng dương là sprite trong `FarmPools`, đi qua `layoutAroundPath` nên luôn né ô khối và đường mòn. Chấm hoa / nét cỏ vẽ tay cũng bỏ (đã có trong texture).

## Bố cục dày hơn (PuzzleChapters.kt)
- `FarmPools`: nhóm TREE = sồi / sồi táo / thông / dương; SMALL = hoa, bụi, cỏ, nấm xen cây trồng; FURN = hàng rào gỗ + hàng rào cây;
  TALL = bù nhìn / dương / thông / silo; BIG = chuồng / ao / máy kéo / giếng / cối xay. Cây trồng và vật nuôi thành điểm nhấn thay vì chiếm hết.
- `MapChapter` có thêm 3 tham số mặc định (5 chủ đề cũ KHÔNG đổi): `fill` (bộ vật bù mép: toàn cỏ/hoa/bụi/nấm), `fillExtra` (nông trại 16, cũ 5), `treeBoost` (cây to hơn 25%).
- `PuzzleThemeEffects.propMotion`: thông + dương cũng đung đưa nhẹ như sồi.
- Trên mô phỏng (tools/farm/preview_map.py) 8 biến thể bố cục đều có 61–72% vật là cây cỏ (trước đó < 30%).

## Test (PuzzleRegionsTest)
- `farmSceneryIsMostlyTreesBushesFlowersAndGrass`: mọi biến thể ≥ 50% cây cỏ, ≥ 40 vật.
- `farmTreesAreBiggerThanTheBaseLayoutAndFillPoolIsGreen`: treeBoost > 1, fillExtra > 5, bộ bù mép chỉ gồm cỏ/hoa/bụi/nấm, 5 chủ đề cũ giữ mặc định.

## Công cụ
- `tools/farm/render_farm.py [thư mục ra] [tên sprite...]` — dựng sprite (mới: chân cỏ, thực vật). `tools/farm/render_ground.py` — dựng texture nền.
- `tools/farm/preview_map.py out.png [số khối]` — ghép thử bản đồ bằng Pillow (cổng Python của themedProps + layoutAroundPath, đọc pool thật từ Kotlin) để xem không cần build Android.

## Chưa build thử (không có Android SDK)
Cần: ./gradlew :app:compileDebugKotlin :app:testDebugUnitTest. Xem trên máy thật:
- Độ dày cây cỏ và kích thước cây (nếu thấy rối: giảm `fillExtra` / `FARM_TREE_BOOST` trong PuzzleChapters.kt).
- Nền không lộ vệt lặp khi cuộn nhanh (nếu thấy: tăng kích thước gạch trong render_ground.py `N`).
