# v18n — Quân tốt xanh 3D thay ngựa trên bản đồ câu đố

## Mới
- ui/PawnMascot.kt : `PawnOverlay` — cùng chữ ký với `HorseOverlay`, dùng lại `HorseFrame` / `HorseHop` (HorseMotion.kt, HorseMascot.kt)
  nên chuyển động giữ nguyên: gom lực → bay parabol → tiếp đất dẹt người nảy lại.
  Vẽ bằng Canvas (không asset), hệ toạ độ 100×124:
  - thân tiện tô gradient ngang sáng-tối như hình trụ + vệt sáng dọc, tối dần sát mặt ô;
  - đầu là hình cầu bóng: gradient toả tròn, viền sáng trên-trái, vệt phản chiếu, ánh phản chiếu từ mặt ô;
  - đĩa cổ + chân đế có sọc theo màu chủ đề vùng (`mapChapterFor(...).tileTop`, như chăn yên của ngựa);
  - đứng chờ: vòng sáng lan ra dưới chân mỗi 1,5 s (16 chu kỳ nguyên trên đồng hồ cảnh 24 s ⇒ lặp liền mạch);
  - tiếp đất: 8 tia sáng 4 cánh vàng/trắng bắn ra + bụi kem; bóng đổ co lại khi bay cao.

## Sửa
- ui/PuzzleMapScreen.kt : `HorseOverlay(width = nodeW*0.8)` → `PawnOverlay(width = nodeW*0.62)`. Không đổi logic nhảy/`horseDone`/`hopToLevel`.
  Bài học (LessonsScreen) VẪN dùng ngựa.

## Không đụng
- Bố cục cảnh vật (PuzzleSceneryData.kt là file sinh tự động, đã kiểm 0 điểm ảnh đè nhau). Hoa đã có sẵn trong cảnh
  (FlowersWhite/FlowersColor/KfPlant). Đèn lồng chỉ có ở chặng Giáng sinh (HolLantern); thêm vào chặng rừng cần chạy lại
  tools/scenery để kiểm đè nhau, nên chưa thêm.

## Chưa build thử (không có Android SDK). Cần: ./gradlew :app:compileDebugKotlin :app:testDebugUnitTest rồi xem trên máy thật:
- Kích thước quân so với ô: chỉnh `width = m.nodeW * 0.62f` ở PuzzleMapScreen.
- Chiều cao cung nhảy: hằng số trong `pawnPlace()` (0,42 × khoảng cách, kẹp 0,8–2,1 bề rộng quân).
