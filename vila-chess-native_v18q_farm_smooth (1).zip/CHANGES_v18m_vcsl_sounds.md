# v18m — 5 bộ âm thanh chill từ nhạc cụ thật (CC0), tự tải lúc build bằng main.yml

## Mới
- 5 bộ x 6 tiếng (move / capture / castle / check / promote / end), thêm vào Chủ đề > Âm thanh, sau "Tre & chuông gió":
  vibes (Vibraphone) · harp (Đàn hạc) · glock (Sao đêm - glockenspiel) · marimba (Marimba) · ocarina (Sáo ocarina).
- scripts/get_sounds_vcsl.py : tải mẫu nhạc cụ thật từ **VCSL - Versilian Community Sample Library**
  (github.com/michaelwillis/VCSL, **CC0**: dùng thương mại được, không cần ghi nguồn) rồi dựng 30 file res/raw/<bộ>_<tiếng>.wav
  (44,1 kHz, 16-bit, mono, ~3,8 MB). Giai điệu ngũ cung C nên luôn dễ nghe; đổi cao độ tối đa vài bán cung; cắt khoảng lặng đầu
  (đi quân nghe ngay, 1-9 ms); vang phòng nhỏ; lọc bỏ tiếng ục < 70 Hz (loa Oppo A17k không phát được); mọi file cùng độ to
  (RMS 0,12; đỉnh <= 0,8; đầu/cuối về 0, không tách). Tải ~56 MB mẫu, chạy ~16 s.
- .github/workflows/main.yml : thêm bước "Tải mẫu nhạc cụ CC0 (VCSL)..." (đặt sau bước sinh chuyển động bot, trước Java/Gradle/Unit test).
  continue-on-error: lỗi mạng không làm hỏng build. Ghi tóm tắt "30/30 file" vào Run summary. Bộ nào đã đủ 6 file thì bỏ qua.

## Sửa
- game/SoundPacks.kt : thêm 5 dòng vào [all]; `downloaded` (5 bộ không nằm sẵn trong zip); `isInstalled()` / `installed(context)`.
- ui/ThemeScreen.kt (SoundTab) : danh sách lấy từ SoundPacks.installed(context) -> bộ nào thiếu file (bước tải lỗi) thì ẨN,
  không để người dùng chọn xong lại nghe tiếng Cổ điển. Giao diện ô giữ nguyên.
- test/AppearanceTest.kt : everySoundPackHasAllSixFiles cho phép 5 bộ tải-lúc-build vắng hẳn (test cục bộ / tải lỗi) nhưng
  có mặt thì phải đủ 6; thêm test vcslSoundPacksRegisteredAfterOldOnes (đăng ký, thứ tự, id hợp lệ, mô tả <= 40 ký tự).

## Vì sao không dùng âm thanh cờ vua của Lichess
- piano / nes / sfx / futuristic : AGPLv3+ (đóng gói vào app có thể buộc mở mã nguồn cả app);
  lisp : CC BY-NC-SA (cấm thương mại); các bộ còn lại nằm ở mục "non-free" trong COPYING.md của lila.
  App có phần thanh toán thành viên nên không dùng.

## Lưu ý
- Chưa chạy gradle/test trong môi trường này (không có Android SDK). Đã chạy thật: script tạo đủ 30 file, đường lỗi mạng (thoát mã 1,
  không ghi dở), đúng đoạn lệnh của bước main.yml trong thư mục build giả (lần 2 tự bỏ qua).
- Nếu muốn dùng offline / không phụ thuộc mạng: chạy `python3 scripts/get_sounds_vcsl.py` rồi commit 30 file res/raw.
- Giấy phép: CC0 không bắt buộc ghi nguồn; vẫn nên cảm ơn Versilian Studios trong màn "Giới thiệu" nếu bạn muốn.
