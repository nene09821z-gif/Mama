# v18q — Nông trại: sprite mượt (hết tam giác), vật cảnh không đè nút

## Vì sao
- Sprite v18o/v18p là low-poly: tán cây, bụi, cừu hiện rõ từng mặt tam giác + viền tối quanh mỗi mặt.
- `layoutAroundPath` chỉ né ô khối theo hộp vừa khít và thu hộp vật 10% ⇒ mái chuồng, tán cây, xe rơm vẫn chạm sát/lấn vào nút (ngôi sao, số level, độ dày ô khối).

## Sprite (tools/farm/render_farm.py)
- `SMOOTH = 2`: khối tròn (cầu, trụ, nón ≥ 7 cạnh) chia nhỏ gấp đôi ⇒ tán/bụi/thân tròn hết mặt phẳng to. Cọc, hộp (≤ 6 cạnh) giữ nguyên.
- Bỏ viền tối quanh từng mặt (viền cùng màu mặt, chỉ để bịt khe khử răng cưa).
- Ánh sáng mềm hơn: `d^0.85`, thêm chút sáng trời cho mặt hướng lên.
- `leaf_texture()`: rắc cụm lá sáng/tối nhỏ CHỈ lên vùng xanh lá (g > r + 18, g > b + 28) ⇒ tán có bề mặt lá, không ảnh hưởng chuồng, hàng rào, vật nuôi.
- Dựng lại cả 33 sprite `farm_*.png`; tỉ lệ ảnh của 16 sprite đổi nhẹ → cập nhật `PropKind` trong PuzzleMapScreen.kt.

## Bố cục (PuzzleChapters.kt)
- `PathNodes`: nới bề rộng 22% (trước 10%) và chiều cao 30% (chỗ độ dày ô khối + sao + nhãn).
- `NODE_CLEAR = 0.014`: khoảng trống tối thiểu giữa vật và nút (áp cho cả 3 chỗ kiểm: vật gốc, vật dời, vật bù mép).
- `boxOf`: thu hộp vật 6% (trước 10%) ⇒ tán cây/mái chuồng được tính đúng cỡ.
- tools/farm/preview_map.py cập nhật cùng số.

## Kiểm bằng cổng Python (8 biến thể bố cục)
- 43–56 vật mỗi khối (ngưỡng test ≥ 40), 65–73% là cây cỏ (ngưỡng ≥ 50%).
- 0 vật đè lõi nút (hộp vật thu 15%, ô khối không nới).

## Chưa build thử (không có Android SDK)
Cần: ./gradlew :app:compileDebugKotlin :app:testDebugUnitTest, rồi xem trên máy thật. Nếu cảnh thấy thưa: giảm `NODE_CLEAR` hoặc tăng `fillExtra`.
Chỉ làm vùng Nông trại; 5 vùng còn lại (Rừng, Giáng sinh, Sa mạc & núi lửa, Không gian, Biển) vẫn dùng sprite cũ.
