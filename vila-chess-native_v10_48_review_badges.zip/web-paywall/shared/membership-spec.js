// Nguồn sự thật cho gói thành viên phía Web. PHẢI khớp app/.../billing/Membership.kt (Android).

export const MembershipTier = Object.freeze({
  FREE: 'free',
  GOLD: 'gold',
  PLATINUM: 'platinum',
  DIAMOND: 'diamond',
});

const RANK = { free: 0, gold: 1, platinum: 2, diamond: 3, family: 4 };
export const tierRank = (t) => RANK[t] ?? 0;
export const tierName = (t) => ({ free: 'Miễn phí', gold: 'Gold', platinum: 'Platinum', diamond: 'Diamond', family: 'Friends & Family' })[t] ?? 'Miễn phí';

/** feature -> gói tối thiểu. Gói cao hơn tự động có quyền của gói thấp hơn. */
export const Feature = Object.freeze({
  AD_FREE: 'AD_FREE',
  UNLIMITED_PUZZLES: 'UNLIMITED_PUZZLES',
  UNLIMITED_LESSONS: 'UNLIMITED_LESSONS',
  GAME_REVIEW: 'GAME_REVIEW', // không giới hạn
  COACH_EXPLANATIONS: 'COACH_EXPLANATIONS',
  INSIGHTS: 'INSIGHTS',
  ADVANCED_STATS: 'ADVANCED_STATS',
});

const MIN_TIER = {
  AD_FREE: 'gold',
  UNLIMITED_PUZZLES: 'gold',
  UNLIMITED_LESSONS: 'gold',
  GAME_REVIEW: 'platinum',
  COACH_EXPLANATIONS: 'diamond',
  INSIGHTS: 'diamond',
  ADVANCED_STATS: 'diamond',
};

export const FEATURE_LABEL = {
  AD_FREE: 'Không quảng cáo',
  UNLIMITED_PUZZLES: 'Câu đố không giới hạn',
  UNLIMITED_LESSONS: 'Bài học không giới hạn',
  GAME_REVIEW: 'Game Review không giới hạn',
  COACH_EXPLANATIONS: 'Huấn luyện viên giải thích nước đi',
  INSIGHTS: 'Insights',
  ADVANCED_STATS: 'Thống kê nâng cao',
};

/** Hạn mức/ngày khi CHƯA mở khóa tính năng tương ứng. */
export const Quota = Object.freeze({
  PUZZLES: { id: 'PUZZLES', unlockedBy: 'UNLIMITED_PUZZLES', limit: 3 },
  LESSONS: { id: 'LESSONS', unlockedBy: 'UNLIMITED_LESSONS', limit: 3 }, // giả định: đề chưa nêu
  GAME_REVIEW: { id: 'GAME_REVIEW', unlockedBy: 'GAME_REVIEW', limit: 1 }, // Free & Gold: 1 ván/ngày
});

export function hasAccess(feature, tier) {
  return tierRank(tier) >= tierRank(MIN_TIER[feature]);
}
export const requiredTier = (feature) => MIN_TIER[feature];
export const showAds = (tier) => !hasAccess(Feature.AD_FREE, tier);

/** null = không giới hạn */
export function dailyLimit(quota, tier) {
  return hasAccess(quota.unlockedBy, tier) ? null : quota.limit;
}

export const TIER_HIGHLIGHTS = {
  free: ['Game Review 1 ván/ngày', '3 câu đố/ngày', 'Có quảng cáo'],
  gold: ['Không quảng cáo', 'Câu đố & bài học không giới hạn', 'Game Review 1 ván/ngày'],
  platinum: ['Gồm tất cả quyền lợi Gold', 'Game Review không giới hạn'],
  diamond: ['Gồm tất cả quyền lợi Platinum', 'Huấn luyện viên giải thích nước đi', 'Insights', 'Thống kê nâng cao'],
  family: ['Gồm tất cả quyền lợi Diamond', '2–6 thành viên dùng chung', 'Chỉ bán gói năm'],
};

/** Khớp với RevenueCat: entitlement id = id gói; package id = `${tier}_${period}` trong offering mặc định. */
export const PAID_TIERS = ['gold', 'platinum', 'diamond', 'family'];
export const PERIODS = ['monthly', 'yearly'];
