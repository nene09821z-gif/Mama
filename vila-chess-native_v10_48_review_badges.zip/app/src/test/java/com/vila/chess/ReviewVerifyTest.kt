package com.vila.chess

import com.vila.chess.review.EngineResult
import com.vila.chess.review.ReviewClassifier
import com.vila.chess.review.ReviewReplay
import com.vila.chess.review.ReviewVerify
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ReviewVerifyTest {

    private fun ev(best: String?, cp: Int, depth: Int = 12) = EngineResult(best, cp, null, depth, false, engine = "wasm")

    @Test fun gameAccuracy_blunderPullsHarmonicMeanBelowArithmetic() {
        val clean = ReviewClassifier.gameAccuracy(List(20) { 0.0 })
        val oneBlunder = ReviewClassifier.gameAccuracy(List(19) { 0.0 } + 60.0)
        val arithOnly = (19 * 100.0 + ReviewClassifier.moveAccuracy(60.0)) / 20.0
        assertTrue(clean > 99.0)
        assertTrue(oneBlunder < arithOnly)
    }

    @Test fun suspectPositions_picksOnlyWorstNonBestMoves() {
        // 1.e4 (best, ok) 1...e5 (không phải best, tụt mạnh vì +cp lớn cho Trắng sau nước đen)
        val r = ReviewReplay.replay(com.vila.chess.core.START_FEN, listOf("e2e4", "e7e5"))!!
        val evals = listOf(
            ev("e2e4", 20),      // thế đầu (Trắng đi): best = e2e4
            ev("e7e5", -20),     // sau e4 (Đen đi): best = e7e5 -> Đen đi đúng best
            ev("g1f3", 20),
        )
        assertEquals(emptyList<Int>(), ReviewVerify.suspectPositions(r.plies, evals))

        // Đen đi nước khác best và sau đó Trắng +400 => nghi sai => tìm lại thế 1 và 2.
        val bad = listOf(ev("e2e4", 20), ev("c7c5", -20), ev("g1f3", 400))
        assertEquals(listOf(1, 2), ReviewVerify.suspectPositions(r.plies, bad))
    }
}
