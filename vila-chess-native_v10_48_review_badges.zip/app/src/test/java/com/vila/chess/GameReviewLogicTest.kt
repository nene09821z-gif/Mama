package com.vila.chess

import com.vila.chess.review.MoveLabel
import com.vila.chess.review.MoveReview
import com.vila.chess.review.MoveRow
import com.vila.chess.review.ReviewClassifier
import com.vila.chess.review.ReviewDisplay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GameReviewLogicTest {
    private fun mv(ply: Int, white: Boolean) = MoveReview(ply, white, MoveLabel.GOOD, 0.0, 0, null)

    @Test
    fun uciSquares() {
        assertEquals(Pair(12, 28), ReviewDisplay.parseUciSquares("e2e4"))
        assertEquals(Pair(6, 21), ReviewDisplay.parseUciSquares("g1f3"))
        assertNull(ReviewDisplay.parseUciSquares(null))
        assertNull(ReviewDisplay.parseUciSquares("zz"))
    }

    @Test
    fun evalTextAndFraction() {
        assertEquals("0.0", ReviewDisplay.evalText(0, null))
        assertEquals("+0.3", ReviewDisplay.evalText(30, null))
        assertEquals("-1.2", ReviewDisplay.evalText(-120, null))
        assertEquals("M3", ReviewDisplay.evalText(0, 3))
        assertEquals("-M2", ReviewDisplay.evalText(0, -2))
        assertEquals(0.5f, ReviewDisplay.evalFraction(0, null), 0.001f)
        assertEquals(1f, ReviewDisplay.evalFraction(0, 3), 0f)
        assertEquals(0f, ReviewDisplay.evalFraction(0, -1), 0f)
    }

    @Test
    fun moveRows() {
        val white = listOf(mv(1, true), mv(2, false), mv(3, true))
        assertEquals(listOf(MoveRow(1, 1, 2), MoveRow(2, 3, null)), ReviewDisplay.buildMoveRows(white))
        val black = listOf(mv(1, false), mv(2, true))
        assertEquals(listOf(MoveRow(1, null, 1), MoveRow(2, 2, null)), ReviewDisplay.buildMoveRows(black))
        assertEquals(1, ReviewDisplay.rowIndexOf(ReviewDisplay.buildMoveRows(white), 3))
    }

    @Test
    fun winPctFormulaAndMate() {
        assertEquals(50.0, ReviewClassifier.winPct(0), 1e-9)
        assertEquals(50.0 + 50.0 * (2.0 / (1.0 + Math.exp(-0.00368208 * 300)) - 1.0), ReviewClassifier.winPct(300), 1e-9)
        assertEquals(100.0, ReviewClassifier.winPct(0, 3), 0.0)
        assertEquals(0.0, ReviewClassifier.winPct(0, -2), 0.0)
        assertEquals(0.0, ReviewClassifier.winPct(-10_000, 0), 0.0)
    }

    @Test
    fun lossNeverNegativeAndBlunderIsBlunder() {
        val startFen = com.vila.chess.core.START_FEN
        val replay = com.vila.chess.review.ReviewReplay.replay(startFen, listOf("e2e4", "e7e5"))!!
        fun ev(cp: Int) = com.vila.chess.review.EngineResult("e2e4", cp, null, 12, false, engine = "native")
        // Trắng đi e4 rồi eval (góc nhìn bên đang đi) tụt từ +30 xuống -900 theo Đen => Trắng mất thế => Blunder.
        val r = com.vila.chess.review.ReviewAssembler.assemble(
            "t", replay.startFen, replay.plies, listOf(ev(30), ev(900), ev(-50)), "LOW", 0L,
        )
        assertEquals(MoveLabel.BLUNDER, r.moves[0].label)
        // Nước thứ hai "tốt hơn dự kiến" cũng không được cho loss âm.
        r.moves.forEach { org.junit.Assert.assertTrue(it.winLoss >= 0.0) }
    }
}
