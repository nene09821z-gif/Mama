package com.vila.chess.review.db

import com.vila.chess.review.GameReview
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.MoveReview

/** Chuyển qua lại giữa mô hình hiển thị (GameReview) và các dòng Room. Hàm thuần: test được trên JVM. */
object AnalysisMapper {

    fun toSummary(r: GameReview) = AnalysisSummary(
        gameId = r.gameId,
        accuracyWhite = r.accuracyWhite,
        accuracyBlack = r.accuracyBlack,
        tier = r.tier,
        createdAt = r.createdAt,
        startFen = r.startFen,
        engine = r.engine,
        multiPv = r.multiPv,
        moveCount = r.moves.size,
        version = r.version,
    )

    fun toRows(r: GameReview): List<AnalysisResult> = r.moves.map { m ->
        AnalysisResult(
            gameId = r.gameId,
            ply = m.ply,
            whiteMoved = m.whiteMoved,
            label = m.label.name,
            winLoss = m.winLoss,
            fen = m.fenBefore,
            fenAfter = m.fenAfter,
            bestMove = m.bestMoveBefore,
            scoreCp = m.evalAfterCpWhite,
            evalBeforeCp = m.evalBeforeCpWhite,
            mateBefore = m.mateBeforeWhite,
            mateAfter = m.mateAfterWhite,
            uci = m.uci,
            san = m.san,
            pv = m.pv.joinToString(" "),
            depthBefore = m.depthBefore,
            depthAfter = m.depthAfter,
            secondBestMove = m.secondBestMove,
            secondBestCp = m.secondBestCpWhite,
            secondBestMate = m.secondBestMateWhite,
            engine = m.engine,
            multiPv = m.multiPv,
            ecoCode = m.ecoCode,
            openingName = m.openingName,
        )
    }

    /** null nếu số dòng không khớp [AnalysisSummary.moveCount] (dữ liệu dở dang/hỏng). */
    fun toReview(s: AnalysisSummary, rows: List<AnalysisResult>): GameReview? {
        if (rows.size != s.moveCount) return null
        val moves = rows.sortedBy { it.ply }.map { x ->
            MoveReview(
                ply = x.ply,
                whiteMoved = x.whiteMoved,
                label = MoveLabel.values().firstOrNull { it.name == x.label } ?: MoveLabel.GOOD,
                winLoss = x.winLoss,
                evalAfterCpWhite = x.scoreCp,
                bestMoveBefore = x.bestMove,
                uci = x.uci,
                san = x.san,
                fenBefore = x.fen,
                fenAfter = x.fenAfter,
                evalBeforeCpWhite = x.evalBeforeCp,
                mateBeforeWhite = x.mateBefore,
                mateAfterWhite = x.mateAfter,
                pv = if (x.pv.isBlank()) emptyList() else x.pv.split(' ').filter { it.isNotEmpty() },
                depthBefore = x.depthBefore,
                depthAfter = x.depthAfter,
                secondBestMove = x.secondBestMove,
                secondBestCpWhite = x.secondBestCp,
                secondBestMateWhite = x.secondBestMate,
                engine = x.engine,
                multiPv = x.multiPv,
                ecoCode = x.ecoCode,
                openingName = x.openingName,
            )
        }
        return GameReview(
            gameId = s.gameId,
            moves = moves,
            accuracyWhite = s.accuracyWhite,
            accuracyBlack = s.accuracyBlack,
            tier = s.tier,
            createdAt = s.createdAt,
            version = s.version,
            startFen = s.startFen,
            engine = s.engine,
            multiPv = s.multiPv,
        )
    }
}
