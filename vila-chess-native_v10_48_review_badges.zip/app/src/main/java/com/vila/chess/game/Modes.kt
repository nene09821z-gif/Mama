package com.vila.chess.game

import com.vila.chess.core.CR_BK
import com.vila.chess.core.CR_BQ
import com.vila.chess.core.CR_WK
import com.vila.chess.core.CR_WQ
import com.vila.chess.core.Engine
import com.vila.chess.core.KING
import com.vila.chess.core.Position
import com.vila.chess.core.ROOK
import com.vila.chess.core.SearchLimits
import com.vila.chess.core.makePiece
import com.vila.chess.core.moveToSan
import kotlin.math.abs

/** What kind of game is being played. Only BOT and TOURNAMENT games change the player's ratings (ONLINE = người thật qua Supabase, chưa tính Elo). */
enum class GameKind { BOT, FRIEND, ENDGAME, TOURNAMENT, ONLINE }

/**
 * Chế độ "Đi trước" (premove) – áp dụng cho mọi ván có đối thủ (Bot, Giải đấu, Tàn cuộc, sau này là Online).
 * MULTI = xếp hàng nhiều nước, tự chơi lần lượt; SINGLE = chỉ 1 nước; OFF = tắt hẳn.
 */
enum class PremoveMode(val id: Int, val label: String) {
    MULTI(0, "Nhiều"),
    SINGLE(1, "Đơn"),
    OFF(2, "Đã vô hiệu hóa");

    companion object {
        fun fromId(id: Int): PremoveMode = values().firstOrNull { it.id == id } ?: MULTI
    }
}

/** Pages of the home flow. The ViewModel owns this so the app returns to the right page after a game. */
enum class HomeRoute { HOME, NEW_GAME, BOT_SETUP, BOT_SELECT, TOURNAMENT, ONLINE, PAYWALL, PREFERENCES, ACCOUNT, PROFILE, ARCHIVE }

// =============================================================================
// FEN validation (custom start position)
// =============================================================================

object FenCheck {
    /** Returns null when [raw] is a playable position, otherwise a short Vietnamese error message. */
    fun validate(raw: String): String? {
        val fen = raw.trim()
        if (fen.isEmpty()) return "Hãy nhập chuỗi FEN"
        val parts = fen.split(Regex("\\s+"))
        val rows = parts[0].split("/")
        if (rows.size != 8) return "FEN cần đúng 8 hàng, ngăn cách bằng dấu /"
        var whiteKings = 0
        var blackKings = 0
        for (i in rows.indices) {
            var files = 0
            for (ch in rows[i]) {
                if (ch in '1'..'8') {
                    files += ch - '0'
                } else if ("pnbrqkPNBRQK".indexOf(ch) >= 0) {
                    files++
                    if (ch == 'K') whiteKings++
                    if (ch == 'k') blackKings++
                    if ((ch == 'p' || ch == 'P') && (i == 0 || i == 7)) return "Tốt không thể nằm ở hàng 1 hoặc hàng 8"
                } else {
                    return "Ký tự không hợp lệ: " + ch
                }
            }
            if (files != 8) return "Hàng " + (8 - i) + " không đủ 8 ô"
        }
        if (whiteKings != 1 || blackKings != 1) return "Mỗi bên phải có đúng một vua"
        if (parts.size > 1 && parts[1] != "w" && parts[1] != "b") return "Lượt đi phải là w hoặc b"
        val pos: Position
        try {
            pos = Position.fromFen(fen)
        } catch (e: Exception) {
            return "FEN không hợp lệ"
        }
        val wK = makePiece(KING, true)
        val bK = makePiece(KING, false)
        val wR = makePiece(ROOK, true)
        val bR = makePiece(ROOK, false)
        val b = pos.board
        if ((pos.castling and CR_WK != 0 && (b[4] != wK || b[7] != wR)) ||
            (pos.castling and CR_WQ != 0 && (b[4] != wK || b[0] != wR)) ||
            (pos.castling and CR_BK != 0 && (b[60] != bK || b[63] != bR)) ||
            (pos.castling and CR_BQ != 0 && (b[60] != bK || b[56] != bR))
        ) {
            return "Quyền nhập thành không khớp vị trí vua và xe"
        }
        if (pos.epSquare != -1) {
            val r = pos.epSquare shr 3
            val ok = pos.epSquare in 0..63 && ((pos.whiteToMove && r == 5) || (!pos.whiteToMove && r == 2))
            if (!ok) return "Ô bắt tốt qua đường không hợp lệ"
        }
        if (pos.inCheck(!pos.whiteToMove)) return "Bên không có lượt đi đang bị chiếu"
        if (pos.legalMoves().isEmpty()) return "Thế cờ này đã kết thúc (chiếu hết hoặc hòa pat)"
        return null
    }

    /** True when white is to move in [fen] (assumes the FEN is valid). */
    fun whiteToMove(fen: String): Boolean {
        val parts = fen.trim().split(Regex("\\s+"))
        return parts.size < 2 || parts[1] == "w"
    }
}

// =============================================================================
// Endgame practice ("Học": the human plays the winning side against the bot)
// =============================================================================

class EndgamePreset(
    val id: String,
    val title: String,
    val desc: String,
    val fen: String,
    val humanWhite: Boolean,
)

object EndgamePresets {
    val all: List<EndgamePreset> = listOf(
        EndgamePreset(
            "kq",
            "Vua + Hậu chiếu hết",
            "Dồn vua đen vào mép bàn rồi chiếu hết. Cẩn thận kẻo hòa pat!",
            "4k3/8/8/8/8/8/8/3QK3 w - - 0 1",
            true,
        ),
        EndgamePreset(
            "kr",
            "Vua + Xe chiếu hết",
            "Dùng vua và xe ép vua đen vào mép bàn, chiếu hết bằng thế đối vua.",
            "4k3/8/8/8/8/8/8/R3K3 w - - 0 1",
            true,
        ),
        EndgamePreset(
            "krr",
            "Hai Xe chiếu hết",
            "Hai xe luân phiên ép vua xuống hàng cuối (thang xe).",
            "8/8/8/4k3/8/8/8/R3K2R w - - 0 1",
            true,
        ),
        EndgamePreset(
            "kp",
            "Vua + Tốt thắng",
            "Vua ở trước tốt trên hàng 6: đẩy tốt phong Hậu rồi chiếu hết.",
            "4k3/8/4K3/4P3/8/8/8/8 w - - 0 1",
            true,
        ),
    )
}

// =============================================================================
// Bot tournament: 8 rounds against bot levels 1..8
// =============================================================================

object Tournament {
    const val ROUNDS = 8

    fun parse(saved: String?): List<Double?> {
        val out = ArrayList<Double?>()
        if (saved != null && saved.isNotEmpty()) {
            for (part in saved.split(",")) out.add(part.toDoubleOrNull())
        }
        while (out.size < ROUNDS) out.add(null)
        return out.subList(0, ROUNDS).toList()
    }

    fun serialize(results: List<Double?>): String = results.joinToString(",") { if (it == null) "" else it.toString() }

    /** Index of the first round that has not been played, or -1 once the tournament is finished. */
    fun nextRound(results: List<Double?>): Int {
        for (i in results.indices) if (results[i] == null) return i
        return -1
    }

    fun points(results: List<Double?>): Double {
        var sum = 0.0
        for (r in results) if (r != null) sum += r
        return sum
    }

    fun levelFor(round: Int): Int = round + 1

    /** The player has white in even-numbered rounds (round index 0, 2, ...). */
    fun humanWhite(round: Int): Boolean = round % 2 == 0

    fun record(results: List<Double?>, round: Int, score: Double): List<Double?> {
        val next = results.toMutableList()
        if (round in next.indices) next[round] = score
        return next
    }

    fun title(points: Double): String = when {
        points >= 7.0 -> "Nhà vô địch"
        points >= 5.0 -> "Hạng nhì"
        points >= 3.0 -> "Hạng ba"
        else -> "Cố gắng thêm nhé"
    }

    fun pointsText(points: Double): String {
        val whole = points.toInt()
        return if (points - whole >= 0.25) whole.toString() + "½" else whole.toString()
    }
}

// =============================================================================
// Coach: strongest move + plain-language evaluation, from the side to move's point of view
// =============================================================================

class Hint(val move: Int, val san: String, val scoreCp: Int)

object Coach {
    private val LIMITS = SearchLimits(8, 1800L, 0)

    fun hint(position: Position, cancelled: () -> Boolean): Hint? {
        val pos = position.copy()
        val engine = Engine()
        engine.cancelled = cancelled
        val move = engine.findBestMove(pos, LIMITS)
        if (move == 0) return null
        return Hint(move, moveToSan(pos, move), engine.lastScore)
    }

    fun describe(h: Hint): String {
        val s = h.scoreCp
        val tail = if (abs(s) >= Engine.MATE - 100) {
            val moves = (Engine.MATE - abs(s) + 1) / 2
            if (s > 0) "bạn chiếu hết sau " + moves + " nước" else "bạn có thể bị chiếu hết sau " + moves + " nước"
        } else if (abs(s) < 30) {
            "thế cờ cân bằng"
        } else {
            val tenths = (abs(s) + 5) / 10
            val text = (tenths / 10).toString() + "." + (tenths % 10)
            if (s > 0) "bạn hơn " + text + " tốt" else "bạn kém " + text + " tốt"
        }
        return "Nước tốt nhất: " + h.san + " · " + tail
    }
}
