package com.vila.chess.review

import java.util.Locale

/** Thông tin để mở màn Review từ hộp thoại tổng kết: đủ để dựng lại ván mà không cần GameSession. */
data class ReviewRequest(
    val gameId: String,
    val startFen: String,
    /** Các nước đi dạng UCI, theo thứ tự. */
    val ucis: List<String>,
    /** null = chơi 2 người cùng máy (không có "phía của bạn"). */
    val humanWhite: Boolean?,
    val opponentName: String,
)

/** Kết quả phân tích + dữ liệu dựng lại từ ván, sẵn sàng để UI vẽ. Mọi danh sách theo ply (1 = nước đầu). */
data class ReviewData(
    val review: GameReview,
    /** fens[0] = thế đầu ván, fens[i] = thế sau i nước. size = moves.size + 1. */
    val fens: List<String>,
    /** SAN của từng nước. size = moves.size. */
    val sans: List<String>,
    /** SAN của nước engine cho là tốt nhất TẠI THẾ TRƯỚC nước đi thứ i+1. size = moves.size. */
    val bestSans: List<String?>,
    /** boards[i] = bàn cờ (64 ô) của thế sau i nước, dựng sẵn ở luồng nền để tua nước không phải phân tích FEN trên luồng chính. */
    val boards: List<IntArray> = emptyList(),
)

/** Một dòng của danh sách nước đi: số nước + ply của Trắng / Đen (null = ô trống). */
data class MoveRow(val number: Int, val whitePly: Int?, val blackPly: Int?)

/** Hàm thuần (không Android) cho màn Review: dễ test trên JVM. */
object ReviewDisplay {

    /** Điểm của thế SAU [ply] nước (0 = thế đầu ván), góc nhìn Trắng: Pair(cp, mate). */
    fun positionEval(review: GameReview, ply: Int): Pair<Int, Int?> {
        val moves = review.moves
        if (moves.isEmpty()) return 0 to null
        return if (ply <= 0) {
            (moves[0].evalBeforeCpWhite ?: 0) to moves[0].mateBeforeWhite
        } else {
            val m = moves[(ply - 1).coerceAtMost(moves.size - 1)]
            m.evalAfterCpWhite to m.mateAfterWhite
        }
    }

    /** Phần của thanh Eval thuộc về Trắng (0..1). Có mate thì kịch trần/sàn. */
    fun evalFraction(cp: Int, mate: Int?): Float = when {
        mate != null -> when {
            mate > 0 -> 1f
            mate < 0 -> 0f
            else -> if (cp >= 0) 1f else 0f   // mate == 0: đã bị chiếu hết, bên thắng là bên có cp cùng dấu
        }
        else -> (ReviewClassifier.winPct(cp) / 100.0).toFloat().coerceIn(0f, 1f)
    }

    /** "+0.3", "-1.2", "M4", "-M2", "1-0" (đã chiếu hết). ĐỪNG hiển thị cp khi có mate. */
    fun evalText(cp: Int, mate: Int?): String = when {
        mate == null -> if (cp == 0) "0.0" else String.format(Locale.US, "%+.1f", cp / 100.0)
        mate > 0 -> "M$mate"
        mate < 0 -> "-M${-mate}"
        else -> if (cp >= 0) "1-0" else "0-1"
    }

    /** "e2e4" -> Pair(12, 28) (from, to) theo chỉ số ô a1 = 0. Sai định dạng -> null. */
    fun parseUciSquares(uci: String?): Pair<Int, Int>? {
        if (uci == null || uci.length < 4) return null
        fun sq(file: Char, rank: Char): Int {
            val f = file - 'a'
            val r = rank - '1'
            return if (f in 0..7 && r in 0..7) r * 8 + f else -1
        }
        val src = sq(uci[0], uci[1])
        val dst = sq(uci[2], uci[3])
        return if (src < 0 || dst < 0 || src == dst) null else Pair(src, dst)
    }

    /** Nước đi tốt nhất (UCI) của THẾ đang hiển thị sau [ply] nước: chính là nước tốt nhất ở thế trước nước kế tiếp. */
    fun bestMoveAt(review: GameReview, ply: Int): String? =
        review.moves.getOrNull(ply.coerceAtLeast(0))?.bestMoveBefore

    /** Số nước theo nhãn của một phía (white = true: Trắng). */
    fun countsByLabel(review: GameReview, white: Boolean): Map<MoveLabel, Int> =
        review.moves.filter { it.whiteMoved == white }.groupingBy { it.label }.eachCount()

    /** Số fullmove ở cuối FEN (mặc định 1). */
    fun startFullmove(fen: String?): Int =
        fen?.trim()?.split(Regex("\\s+"))?.getOrNull(5)?.toIntOrNull()?.coerceAtLeast(1) ?: 1

    /** Gom các nước thành từng dòng "số | Trắng | Đen". Ván bắt đầu bằng lượt Đen thì ô Trắng của dòng đầu để trống. */
    fun buildMoveRows(moves: List<MoveReview>, startFullmove: Int = 1): List<MoveRow> {
        val rows = ArrayList<MoveRow>((moves.size + 1) / 2 + 1)
        var number = startFullmove
        var i = 0
        if (moves.isNotEmpty() && !moves[0].whiteMoved) {
            rows += MoveRow(number, null, moves[0].ply)
            number++
            i = 1
        }
        while (i < moves.size) {
            rows += MoveRow(number, moves[i].ply, moves.getOrNull(i + 1)?.ply)
            number++
            i += 2
        }
        return rows
    }

    /** Chỉ số dòng chứa [ply] trong danh sách dòng; -1 nếu không có (ply = 0). */
    fun rowIndexOf(rows: List<MoveRow>, ply: Int): Int =
        rows.indexOfFirst { it.whitePly == ply || it.blackPly == ply }

    /** Nhãn cần hiển thị gợi ý "nước tốt hơn". */
    fun isWeak(label: MoveLabel): Boolean =
        label == MoveLabel.INACCURACY || label == MoveLabel.MISTAKE || label == MoveLabel.BLUNDER ||
            label == MoveLabel.MISS

    /** "B90 · Sicilian Defense: Najdorf Variation" — null nếu thế chưa thuộc khai cuộc nào. [ply] = 0 (thế đầu ván) -> null. */
    fun openingAt(review: GameReview, ply: Int): String? {
        val m = review.moves.getOrNull(ply - 1) ?: return null
        val name = m.openingName ?: return null
        return if (m.ecoCode != null) "${m.ecoCode} · $name" else name
    }
}
