package com.vila.chess.core

private val KNIGHT_DR = intArrayOf(-2, -2, -1, -1, 1, 1, 2, 2)
private val KNIGHT_DF = intArrayOf(-1, 1, -2, 2, -2, 2, -1, 1)
private val KING_DR = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
private val KING_DF = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
private val DIAG_DR = intArrayOf(-1, -1, 1, 1)
private val DIAG_DF = intArrayOf(-1, 1, -1, 1)
private val ORTH_DR = intArrayOf(-1, 1, 0, 0)
private val ORTH_DF = intArrayOf(0, 0, -1, 1)
private val PROMO_ORDER = intArrayOf(QUEEN, ROOK, BISHOP, KNIGHT)

private val CASTLE_MASK: IntArray = IntArray(64) { 15 }.also {
    it[4] = 15 and (CR_WK or CR_WQ).inv()
    it[0] = 15 and CR_WQ.inv()
    it[7] = 15 and CR_WK.inv()
    it[60] = 15 and (CR_BK or CR_BQ).inv()
    it[56] = 15 and CR_BQ.inv()
    it[63] = 15 and CR_BK.inv()
}

const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
const val MAX_MOVES = 384

class Position {
    val board = IntArray(64)
    var whiteToMove = true
    var castling = 0
    var epSquare = -1
    var halfmove = 0
    var fullmove = 1

    private var stackMove = IntArray(512)
    private var stackCap = IntArray(512)
    private var stackCastle = IntArray(512)
    private var stackEp = IntArray(512)
    private var stackHalf = IntArray(512)

    var ply: Int = 0
        private set

    companion object {
        fun start(): Position = fromFen(START_FEN)

        fun fromFen(fen: String): Position {
            val p = Position()
            val parts = fen.trim().split(Regex("\\s+"))
            val rows = parts[0].split("/")
            for (i in rows.indices) {
                val rank = 7 - i
                var file = 0
                for (ch in rows[i]) {
                    if (ch.isDigit()) {
                        file += ch - '0'
                    } else {
                        val type = when (ch.lowercaseChar()) {
                            'p' -> PAWN
                            'n' -> KNIGHT
                            'b' -> BISHOP
                            'r' -> ROOK
                            'q' -> QUEEN
                            else -> KING
                        }
                        p.board[rank * 8 + file] = makePiece(type, ch.isUpperCase())
                        file++
                    }
                }
            }
            p.whiteToMove = parts.size < 2 || parts[1] == "w"
            if (parts.size > 2) {
                for (ch in parts[2]) {
                    when (ch) {
                        'K' -> p.castling = p.castling or CR_WK
                        'Q' -> p.castling = p.castling or CR_WQ
                        'k' -> p.castling = p.castling or CR_BK
                        'q' -> p.castling = p.castling or CR_BQ
                    }
                }
            }
            if (parts.size > 3 && parts[3] != "-") {
                p.epSquare = (parts[3][1] - '1') * 8 + (parts[3][0] - 'a')
            }
            p.halfmove = if (parts.size > 4) parts[4].toInt() else 0
            p.fullmove = if (parts.size > 5) parts[5].toInt() else 1
            return p
        }
    }

    fun copy(): Position {
        val p = Position()
        System.arraycopy(board, 0, p.board, 0, 64)
        p.whiteToMove = whiteToMove
        p.castling = castling
        p.epSquare = epSquare
        p.halfmove = halfmove
        p.fullmove = fullmove
        return p
    }

    fun fen(): String {
        val sb = StringBuilder()
        for (rank in 7 downTo 0) {
            var empty = 0
            for (file in 0..7) {
                val pc = board[rank * 8 + file]
                if (pc == EMPTY) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    sb.append(pieceChar(pc))
                }
            }
            if (empty > 0) sb.append(empty)
            if (rank > 0) sb.append('/')
        }
        sb.append(if (whiteToMove) " w " else " b ")
        if (castling == 0) {
            sb.append('-')
        } else {
            if (castling and CR_WK != 0) sb.append('K')
            if (castling and CR_WQ != 0) sb.append('Q')
            if (castling and CR_BK != 0) sb.append('k')
            if (castling and CR_BQ != 0) sb.append('q')
        }
        sb.append(' ')
        sb.append(if (epSquare >= 0) sqName(epSquare) else "-")
        sb.append(' ').append(halfmove).append(' ').append(fullmove)
        return sb.toString()
    }

    private fun pieceChar(pc: Int): Char {
        val c = when (pieceType(pc)) {
            PAWN -> 'p'
            KNIGHT -> 'n'
            BISHOP -> 'b'
            ROOK -> 'r'
            QUEEN -> 'q'
            else -> 'k'
        }
        return if (isWhitePiece(pc)) c.uppercaseChar() else c
    }

    /** Key used for repetition detection (placement, side, castling, en-passant only if capturable). */
    fun repetitionKey(): String {
        val parts = fen().split(" ")
        val ep = if (epSquare >= 0 && epCapturePossible()) sqName(epSquare) else "-"
        return parts[0] + " " + parts[1] + " " + parts[2] + " " + ep
    }

    private fun epCapturePossible(): Boolean {
        val white = whiteToMove
        val pawn = makePiece(PAWN, white)
        val r = sqRank(epSquare)
        val f = sqFile(epSquare)
        val pr = if (white) r - 1 else r + 1
        if (pr < 0 || pr > 7) return false
        for (df in intArrayOf(-1, 1)) {
            val pf = f + df
            if (pf in 0..7 && board[pr * 8 + pf] == pawn) return true
        }
        return false
    }

    fun attacked(sq: Int, byWhite: Boolean): Boolean {
        val r = sq shr 3
        val f = sq and 7
        val off = if (byWhite) 0 else BLACK_BIT
        val pr = if (byWhite) r - 1 else r + 1
        if (pr in 0..7) {
            if (f - 1 >= 0 && board[pr * 8 + f - 1] == PAWN + off) return true
            if (f + 1 <= 7 && board[pr * 8 + f + 1] == PAWN + off) return true
        }
        for (i in 0 until 8) {
            val rr = r + KNIGHT_DR[i]
            val ff = f + KNIGHT_DF[i]
            if (rr in 0..7 && ff in 0..7 && board[rr * 8 + ff] == KNIGHT + off) return true
        }
        for (i in 0 until 8) {
            val rr = r + KING_DR[i]
            val ff = f + KING_DF[i]
            if (rr in 0..7 && ff in 0..7 && board[rr * 8 + ff] == KING + off) return true
        }
        for (i in 0 until 4) {
            var rr = r + DIAG_DR[i]
            var ff = f + DIAG_DF[i]
            while (rr in 0..7 && ff in 0..7) {
                val pc = board[rr * 8 + ff]
                if (pc != EMPTY) {
                    if (pc == BISHOP + off || pc == QUEEN + off) return true
                    break
                }
                rr += DIAG_DR[i]
                ff += DIAG_DF[i]
            }
        }
        for (i in 0 until 4) {
            var rr = r + ORTH_DR[i]
            var ff = f + ORTH_DF[i]
            while (rr in 0..7 && ff in 0..7) {
                val pc = board[rr * 8 + ff]
                if (pc != EMPTY) {
                    if (pc == ROOK + off || pc == QUEEN + off) return true
                    break
                }
                rr += ORTH_DR[i]
                ff += ORTH_DF[i]
            }
        }
        return false
    }

    fun kingSquare(white: Boolean): Int {
        val target = makePiece(KING, white)
        for (i in 0 until 64) if (board[i] == target) return i
        return -1
    }

    fun inCheck(white: Boolean = whiteToMove): Boolean {
        val k = kingSquare(white)
        return k >= 0 && attacked(k, !white)
    }

    /** Pseudo-legal moves for the side to move (king safety is NOT verified). Returns the count. */
    fun generatePseudo(out: IntArray): Int {
        var n = 0
        val w = whiteToMove
        val off = if (w) 0 else BLACK_BIT
        for (sq in 0 until 64) {
            val pc = board[sq]
            if (pc == EMPTY || isBlackPiece(pc) == w) continue
            val t = pc and 7
            val r = sq shr 3
            val f = sq and 7
            if (t == PAWN) {
                val d = if (w) 1 else -1
                val start = if (w) 1 else 6
                val last = if (w) 7 else 0
                val rr1 = r + d
                if (rr1 in 0..7) {
                    val to = sq + 8 * d
                    if (board[to] == EMPTY) {
                        if (rr1 == last) {
                            for (pr in PROMO_ORDER) out[n++] = moveOf(sq, to, pr, FLAG_NONE)
                        } else {
                            out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                            if (r == start && board[sq + 16 * d] == EMPTY) {
                                out[n++] = moveOf(sq, sq + 16 * d, 0, FLAG_DOUBLE)
                            }
                        }
                    }
                    for (df in -1..1 step 2) {
                        val ff = f + df
                        if (ff in 0..7) {
                            val to2 = rr1 * 8 + ff
                            val tp = board[to2]
                            if (tp != EMPTY && isBlackPiece(tp) == w) {
                                if (rr1 == last) {
                                    for (pr in PROMO_ORDER) out[n++] = moveOf(sq, to2, pr, FLAG_NONE)
                                } else {
                                    out[n++] = moveOf(sq, to2, 0, FLAG_NONE)
                                }
                            } else if (to2 == epSquare && tp == EMPTY) {
                                out[n++] = moveOf(sq, to2, 0, FLAG_EP)
                            }
                        }
                    }
                }
            } else if (t == KNIGHT || t == KING) {
                val dr = if (t == KNIGHT) KNIGHT_DR else KING_DR
                val df = if (t == KNIGHT) KNIGHT_DF else KING_DF
                for (i in 0 until 8) {
                    val rr = r + dr[i]
                    val ff = f + df[i]
                    if (rr in 0..7 && ff in 0..7) {
                        val to = rr * 8 + ff
                        val tp = board[to]
                        if (tp == EMPTY || isBlackPiece(tp) == w) out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                    }
                }
                if (t == KING) {
                    val base = if (w) 0 else 56
                    if (sq == base + 4 && !attacked(sq, !w)) {
                        val ks = if (w) CR_WK else CR_BK
                        val qs = if (w) CR_WQ else CR_BQ
                        if (castling and ks != 0 &&
                            board[base + 5] == EMPTY && board[base + 6] == EMPTY &&
                            board[base + 7] == ROOK + off &&
                            !attacked(base + 5, !w) && !attacked(base + 6, !w)
                        ) {
                            out[n++] = moveOf(sq, base + 6, 0, FLAG_CASTLE)
                        }
                        if (castling and qs != 0 &&
                            board[base + 3] == EMPTY && board[base + 2] == EMPTY && board[base + 1] == EMPTY &&
                            board[base] == ROOK + off &&
                            !attacked(base + 3, !w) && !attacked(base + 2, !w)
                        ) {
                            out[n++] = moveOf(sq, base + 2, 0, FLAG_CASTLE)
                        }
                    }
                }
            } else {
                val diag = t == BISHOP || t == QUEEN
                val orth = t == ROOK || t == QUEEN
                if (diag) {
                    for (i in 0 until 4) {
                        var rr = r + DIAG_DR[i]
                        var ff = f + DIAG_DF[i]
                        while (rr in 0..7 && ff in 0..7) {
                            val to = rr * 8 + ff
                            val tp = board[to]
                            if (tp == EMPTY) {
                                out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                            } else {
                                if (isBlackPiece(tp) == w) out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                                break
                            }
                            rr += DIAG_DR[i]
                            ff += DIAG_DF[i]
                        }
                    }
                }
                if (orth) {
                    for (i in 0 until 4) {
                        var rr = r + ORTH_DR[i]
                        var ff = f + ORTH_DF[i]
                        while (rr in 0..7 && ff in 0..7) {
                            val to = rr * 8 + ff
                            val tp = board[to]
                            if (tp == EMPTY) {
                                out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                            } else {
                                if (isBlackPiece(tp) == w) out[n++] = moveOf(sq, to, 0, FLAG_NONE)
                                break
                            }
                            rr += ORTH_DR[i]
                            ff += ORTH_DF[i]
                        }
                    }
                }
            }
        }
        return n
    }

    fun generateLegal(out: IntArray): Int {
        val buf = IntArray(MAX_MOVES)
        val cnt = generatePseudo(buf)
        val side = whiteToMove
        var n = 0
        for (i in 0 until cnt) {
            make(buf[i])
            if (!inCheck(side)) out[n++] = buf[i]
            unmake()
        }
        return n
    }

    fun legalMoves(): IntArray {
        val buf = IntArray(MAX_MOVES)
        val n = generateLegal(buf)
        return buf.copyOf(n)
    }

    private fun ensureStack() {
        if (ply >= stackMove.size) {
            val size = stackMove.size * 2
            stackMove = stackMove.copyOf(size)
            stackCap = stackCap.copyOf(size)
            stackCastle = stackCastle.copyOf(size)
            stackEp = stackEp.copyOf(size)
            stackHalf = stackHalf.copyOf(size)
        }
    }

    fun make(m: Int) {
        ensureStack()
        val from = moveFrom(m)
        val to = moveTo(m)
        val promo = movePromo(m)
        val flag = moveFlag(m)
        val piece = board[from]
        val white = whiteToMove
        var captured = board[to]
        board[to] = piece
        board[from] = EMPTY
        if (flag == FLAG_EP) {
            val capSq = if (white) to - 8 else to + 8
            captured = board[capSq]
            board[capSq] = EMPTY
        }
        stackMove[ply] = m
        stackCap[ply] = captured
        stackCastle[ply] = castling
        stackEp[ply] = epSquare
        stackHalf[ply] = halfmove
        ply++
        if (promo != 0) board[to] = makePiece(promo, white)
        if (flag == FLAG_CASTLE) {
            val base = if (white) 0 else 56
            if (to == base + 6) {
                board[base + 5] = board[base + 7]
                board[base + 7] = EMPTY
            } else {
                board[base + 3] = board[base]
                board[base] = EMPTY
            }
        }
        castling = castling and CASTLE_MASK[from] and CASTLE_MASK[to]
        epSquare = if (flag == FLAG_DOUBLE) (from + to) / 2 else -1
        halfmove = if (pieceType(piece) == PAWN || captured != EMPTY) 0 else halfmove + 1
        if (!white) fullmove++
        whiteToMove = !white
    }

    fun unmake() {
        ply--
        val m = stackMove[ply]
        val cap = stackCap[ply]
        val from = moveFrom(m)
        val to = moveTo(m)
        val promo = movePromo(m)
        val flag = moveFlag(m)
        whiteToMove = !whiteToMove
        val white = whiteToMove
        if (!white) fullmove--
        var piece = board[to]
        if (promo != 0) piece = makePiece(PAWN, white)
        board[from] = piece
        if (flag == FLAG_EP) {
            board[to] = EMPTY
            val capSq = if (white) to - 8 else to + 8
            board[capSq] = cap
        } else {
            board[to] = cap
        }
        if (flag == FLAG_CASTLE) {
            val base = if (white) 0 else 56
            if (to == base + 6) {
                board[base + 7] = board[base + 5]
                board[base + 5] = EMPTY
            } else {
                board[base] = board[base + 3]
                board[base + 3] = EMPTY
            }
        }
        castling = stackCastle[ply]
        epSquare = stackEp[ply]
        halfmove = stackHalf[ply]
    }

    /** True when neither side can ever deliver mate (K, K+minor, or K+B vs K+B on same-colour squares). */
    fun insufficientMaterial(): Boolean {
        var minors = 0
        var knights = 0
        var lightBishops = 0
        var darkBishops = 0
        for (sq in 0 until 64) {
            val pc = board[sq]
            if (pc == EMPTY) continue
            when (pieceType(pc)) {
                PAWN, ROOK, QUEEN -> return false
                KNIGHT -> {
                    minors++
                    knights++
                }
                BISHOP -> {
                    minors++
                    if (((sq shr 3) + (sq and 7)) % 2 == 0) darkBishops++ else lightBishops++
                }
            }
        }
        if (minors <= 1) return true
        if (knights == 0 && (lightBishops == 0 || darkBishops == 0)) return true
        return false
    }

    /** Can this side still deliver mate in principle (used for time-out results). */
    fun hasMatingMaterial(white: Boolean): Boolean {
        var minors = 0
        for (sq in 0 until 64) {
            val pc = board[sq]
            if (pc == EMPTY || isWhitePiece(pc) != white) continue
            when (pieceType(pc)) {
                PAWN, ROOK, QUEEN -> return true
                KNIGHT, BISHOP -> minors++
            }
        }
        return minors >= 2
    }
}

/**
 * Pseudo-legal moves that [white] could play on the current board if it were their turn
 * (used to show premove targets). King safety is not verified; en passant is ignored.
 */
fun generatePseudoCopyForPremove(pos: Position, white: Boolean): IntArray {
    val copy = pos.copy()
    copy.whiteToMove = white
    copy.epSquare = -1
    val buf = IntArray(MAX_MOVES)
    val n = copy.generatePseudo(buf)
    return buf.copyOf(n)
}

/**
 * Áp dụng một nước "đi trước" lên bản sao [pos] (bỏ qua lượt thật, không kiểm tra an toàn vua, bỏ en passant).
 * Phong cấp thành [promo] (mặc định Hậu). Trả về false nếu không có nước giả hợp lệ from -> to.
 * Dùng để dựng "bàn cờ ảo" khi xếp hàng nhiều premove.
 */
fun applyPremoveOnCopy(pos: Position, white: Boolean, from: Int, to: Int, promo: Int = QUEEN): Boolean {
    pos.whiteToMove = white
    pos.epSquare = -1
    val buf = IntArray(MAX_MOVES)
    val n = pos.generatePseudo(buf)
    var found = -1
    for (i in 0 until n) {
        val m = buf[i]
        if (moveFrom(m) != from || moveTo(m) != to) continue
        if (found < 0 || movePromo(m) == promo) found = m
    }
    if (found < 0) return false
    pos.make(found)
    pos.whiteToMove = white
    pos.epSquare = -1
    return true
}
