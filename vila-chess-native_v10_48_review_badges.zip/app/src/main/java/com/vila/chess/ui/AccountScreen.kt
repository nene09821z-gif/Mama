package com.vila.chess.ui

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.R
import com.vila.chess.auth.Account
import com.vila.chess.auth.AccountStore
import com.vila.chess.auth.AuthProvider
import com.vila.chess.auth.SocialSignIn
import kotlinx.coroutines.launch

/** Đăng nhập Google + thanh nhập email. Email là khoá để hiện Game Review phân tích. */
@Composable
fun AccountScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? ComponentActivity
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { AccountStore.load(ctx) }
    val acc = AccountStore.current
    var email by remember { mutableStateOf("") }
    var pendingName by remember { mutableStateOf("") }
    var pendingProvider by remember { mutableStateOf(AuthProvider.EMAIL) }
    var error by remember { mutableStateOf<String?>(null) }
    BackHandler(onBack = onBack)

    fun finish(e: String?, name: String, p: AuthProvider) {
        if (e != null && AccountStore.isValidEmail(e)) {
            AccountStore.save(ctx, Account(e.trim(), name, p)); error = null
        } else {                       // Google không trả email -> giữ tên, bắt nhập email
            pendingName = name; pendingProvider = p
            error = "Tài khoản không cung cấp email. Hãy nhập email để xem Game Review."
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF262421)).statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onBack).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White)
            Text("  Tài khoản", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))

        if (acc != null) {
            Text("Đã đăng nhập", color = Color(0xFFB9C1CE), fontSize = 14.sp)
            Text(acc.email, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            if (acc.name.isNotBlank()) Text(acc.name, color = Color(0xFFB9C1CE), fontSize = 14.sp)
            Text("Game Review phân tích sẽ gắn với email này.", color = Color(0xFF81B64C), fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(24.dp))
            AuthButton("Đăng xuất", Color(0xFF3C3A37)) { AccountStore.signOut(ctx) }
        } else {
            AuthButton("Tiếp tục với Google", Color.White, Color.Black) {
                if (activity == null) return@AuthButton
                scope.launch {
                    runCatching { SocialSignIn.google(activity, ctx.getString(R.string.google_web_client_id)) }
                        .onSuccess { finish(it.email, it.name, AuthProvider.GOOGLE) }
                        .onFailure { error = "Đăng nhập Google lỗi: ${it.message}" }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Hoặc nhập email", color = Color(0xFFB9C1CE), fontSize = 14.sp)
            OutlinedTextField(
                value = email, onValueChange = { email = it },
                singleLine = true, placeholder = { Text("email@vidu.com") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
            )
            Spacer(Modifier.height(10.dp))
            AuthButton("Lưu email", Color(0xFF81B64C)) {
                if (AccountStore.isValidEmail(email)) finish(email, pendingName, pendingProvider)
                else Toast.makeText(ctx, "Email không hợp lệ", Toast.LENGTH_SHORT).show()
            }
        }
        error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp)) }
    }
}

@Composable
private fun AuthButton(text: String, bg: Color, fg: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(12.dp)).background(bg)
            .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text, color = fg, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}
