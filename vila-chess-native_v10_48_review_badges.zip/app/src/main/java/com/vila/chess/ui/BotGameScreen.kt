package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.core.makePiece
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Tournament
import com.vila.chess.game.UiState
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.runtime.getValue
import com.vila.chess.game.Levels
import com.vila.chess.game.levelRating

/** Màn chơi với máy (Bot / Tàn cuộc / Giải đấu). Dùng chung GameViewModel với màn PvP. */
@Composable
fun BotGameScreen(vm: GameViewModel) {
    val ui = vm.ui
    val images = vm.pieceImages
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showResult by remember(ui.over) { mutableStateOf(ui.over) }
    var showOptions by remember { mutableStateOf(false) }

    BackHandler { if (ui.over) vm.backToHome() else confirm = Confirm.EXIT }

    val topIsWhite = ui.flipped
    val botName = vm.opponentName()
    val bot = vm.activeBot
    val botInfo = if (bot != null) "Elo " + bot.elo else Levels.get(vm.botLevelId).name + " · Elo " + levelRating(vm.botLevelId)
    val coachAvailable = vm.coachOn && (ui.kind == GameKind.BOT || ui.kind == GameKind.ENDGAME)
    val myTurn = !ui.over && ui.whiteToMove == ui.humanWhite && ui.promotion == null

    @Composable
    fun Side(white: Boolean) {
        if (white != ui.humanWhite) {
            // Top Bar của Bot: avatar bot + cấp độ + Elo (+ đồng hồ nếu có)
            PlayerBar(vm, ui, images, white, name = botName, subtitle = botInfo, avatarIcon = Icons.Filled.SmartToy, avatarResId = bot?.avatarResId)
        } else {
            PlayerBar(vm, ui, images, white, name = "Bạn", tier = com.vila.chess.billing.rememberTier())
        }
    }

    Column(Modifier.fillMaxSize().background(VilaColors.Bg).systemBarsPadding()) {
        GameTopBar(sans = ui.sans, onBack = { if (ui.over) vm.backToHome() else confirm = Confirm.EXIT })
        Side(topIsWhite)
        ChessBoard(vm, ui, evalBar = vm.evalBarOn)
        Side(!topIsWhite)

        // Bảng gợi ý trượt ngang + mờ 250ms khi bật/tắt huấn luyện viên.
        AnimatedToolPanel(visible = coachAvailable) {
            CoachStrip(text = ui.hintText, busy = ui.hintBusy, canAsk = myTurn, onHint = { vm.requestHint() })
        }

        Spacer(Modifier.weight(1f))

        // Thanh công cụ: Các tùy chọn · Hủy · Gợi ý · Hoàn tác
        GameToolbar {
            ToolbarButton("Các tùy chọn", true, { showOptions = true }) { ToolbarVectorIcon(Icons.Filled.FormatListBulleted, "Các tùy chọn") }
            ToolbarButton("Hủy", !ui.over, { confirm = Confirm.RESIGN }) { ToolbarVectorIcon(Icons.Filled.Flag, "Hủy") }
            ToolbarButton("Gợi ý", coachAvailable && myTurn && !ui.hintBusy, { vm.requestHint() }, active = ui.hintFrom >= 0) { ToolbarVectorIcon(Icons.Filled.Lightbulb, "Gợi ý") }
            ToolbarButton("Đánh giá", ui.kind != GameKind.TOURNAMENT, { vm.setEvalBar(!vm.evalBarOn) }, active = vm.evalBarOn) { ToolbarVectorIcon(Icons.Filled.BarChart, "Đánh giá") }
            ToolbarButton("Hoàn tác", ui.canUndo, { vm.undo() }) { ToolbarVectorIcon(Icons.AutoMirrored.Filled.Undo, "Hoàn tác") }
        }
    }

    // Modal BottomSheet "Các tùy chọn"
    GameOptionsHost(
        visible = showOptions,
        onDismiss = { showOptions = false },
        onFlipBoard = { vm.flipBoard() },
        onExplore = {},
        onSaveGame = {},
        onOfferDraw = { vm.offerDraw() },
        onNewGame = { if (ui.over) vm.rematch() else confirm = Confirm.NEW_GAME },
        premoveMode = vm.premoveMode,
        onPremoveModeChange = { vm.setPremoveMode(it) },
    )

    if (ui.promotion != null) PromotionDialog(vm = vm, images = images, humanWhite = ui.humanWhite)

    ConfirmDialog(confirm, friend = false, onDismiss = { confirm = null }) { c ->
        confirm = null
        when (c) {
            Confirm.EXIT -> vm.backToHome()
            Confirm.NEW_GAME -> vm.rematch()
            Confirm.RESIGN -> vm.resign()
            Confirm.DRAW -> vm.offerDraw()
        }
    }

    if (ui.over && showResult) PostGameDialog(vm = vm, onDismiss = { showResult = false })
}

/** Coach: shows the engine's best move / evaluation and a button to ask for it. */

/** Huấn luyện viên: hiện nước đi tốt nhất / đánh giá và nút xin gợi ý. */
@Composable
private fun CoachStrip(text: String, busy: Boolean, canAsk: Boolean, onHint: () -> Unit) {
    val enabled = canAsk && !busy
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(VilaColors.PanelDark)
            .padding(start = 10.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Color(0xFF39598A)),
            contentAlignment = Alignment.Center
        ) {
            Text("HL", color = Color(0xFFDCE9FA), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = if (text.isEmpty()) "Huấn luyện viên: chạm Gợi ý để xem nước đi tốt nhất" else text,
            color = VilaColors.Text,
            fontSize = 13.sp,
            maxLines = 2,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        ChunkyButton(
            text = "Gợi ý",
            onClick = { if (enabled) onHint() },
            modifier = Modifier
                .width(72.dp)
                .alpha(if (enabled) 1f else 0.4f),
            height = 32.dp,
            edge = 3.dp,
            radius = 8.dp,
            fontSize = 14.sp
        )
    }
}
