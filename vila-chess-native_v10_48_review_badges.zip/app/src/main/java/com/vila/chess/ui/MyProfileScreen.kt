package com.vila.chess.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.Achievement
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.StatsStore
import com.vila.chess.game.achievements
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.EloRange
import com.vila.chess.profile.GameHistoryStore
import com.vila.chess.profile.GameRecord
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.UserSessionManager
import com.vila.chess.profile.streakLabel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================================================================
// Màn hình Hồ sơ kiểu Chess.com.
//   userId == null  → hồ sơ CỦA MÌNH (dữ liệu từ UserSessionManager: userId, elo, tier) — có Chỉnh sửa, Ván đấu, Thành tích, Bạn bè.
//   userId != null  → hồ sơ NGƯỜI KHÁC (đối thủ/bạn bè) tải từ Supabase — chỉ xem, có trạng thái Loading/Error.
// =============================================================================

private val TABS_SELF = listOf("Tổng quan", "Ván đấu", "Thành tích", "Bạn bè")
private val TABS_OTHER = listOf("Tổng quan")

@Composable
fun MyProfileScreen(
    vm: GameViewModel,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    userId: String? = null,
) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        ProfileTopBar(title = if (userId == null) "Hồ sơ" else "Hồ sơ người chơi", onBack = onBack)
        if (userId == null) OwnProfile(vm, onOpenProfile) else RemoteProfile(userId, onOpenProfile)
    }
}

// ------------------------------------------------------------------ Hồ sơ của mình

@Composable
private fun OwnProfile(vm: GameViewModel, onOpenProfile: (String) -> Unit) {
    val ctx = LocalContext.current
    // Gói lấy từ MembershipStore (qua UserSessionManager): mua gói xong huy hiệu đổi ngay, không cần làm gì thêm.
    val tier by UserSessionManager.tier(ctx).collectAsState()
    val name = UserSessionManager.displayName
    val country = UserSessionManager.countryCode
    val avatar = UserSessionManager.avatarKey
    val stats = vm.stats
    val profile = remember(stats, tier, name, country, avatar) { UserSessionManager.profile(ctx, stats) }
    val games = remember(stats) { GameHistoryStore(ctx).load() }
    val trophies = remember(stats, vm.tournamentsDone) { achievements(stats, vm.tournamentsDone, StatsStore.today()) }
    var editing by remember { mutableStateOf(false) }

    ProfileBody(
        profile = profile,
        isSelf = true,
        games = games,
        trophies = trophies,
        dayStreak = stats.activeStreak(StatsStore.today()),
        onEdit = { editing = true },
        onOpenProfile = onOpenProfile,
    )
    if (editing) EditProfileSheet(onDismiss = { editing = false })
}

// ------------------------------------------------------------------ Hồ sơ người khác

@Composable
private fun RemoteProfile(userId: String, onOpenProfile: (String) -> Unit) {
    val (state, retry) = rememberRemoteProfile(userId)
    when (val s = state) {
        is LoadState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { LoadingBlock(text = "Đang tải hồ sơ…") }
        is LoadState.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { ErrorBlock(s.kind, onRetry = retry) }
        is LoadState.Success -> ProfileBody(
            profile = s.data, isSelf = false, games = emptyList(), trophies = emptyList(), dayStreak = 0,
            onEdit = {}, onOpenProfile = onOpenProfile,
        )
    }
}

// ------------------------------------------------------------------ Thân trang

@Composable
private fun ProfileBody(
    profile: UserProfile,
    isSelf: Boolean,
    games: List<GameRecord>,
    trophies: List<Achievement>,
    dayStreak: Int,
    onEdit: () -> Unit,
    onOpenProfile: (String) -> Unit,
) {
    val tabs = if (isSelf) TABS_SELF else TABS_OTHER
    var modeIdx by rememberSaveable { mutableIntStateOf(EloMode.BLITZ.ordinal) }
    var rangeIdx by rememberSaveable { mutableIntStateOf(EloRange.MONTH.ordinal) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val mode = EloMode.values()[modeIdx]
    val range = EloRange.values()[rangeIdx]

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // --- Header: avatar lớn, tên đậm + huy hiệu VIP, quốc gia, nút Chỉnh sửa
        item(key = "header") {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                ProfileAvatar(name = profile.displayName, avatarKey = profile.avatarKey, size = 96.dp)
                Spacer(Modifier.height(12.dp))
                NameWithBadge(name = profile.displayName, tier = profile.tier, fontSize = 26f, badgeSize = 26.dp)
                CountryLine(profile.countryCode, Modifier.padding(top = 4.dp))
                if (isSelf) {
                    Spacer(Modifier.height(12.dp))
                    ChunkyButton(text = "Chỉnh sửa hồ sơ", onClick = onEdit, modifier = Modifier.fillMaxWidth(), height = 44.dp, fontSize = 16.sp)
                }
            }
        }

        // --- 3 thẻ Elo (chạm để đổi thể loại của biểu đồ)
        item(key = "elo") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for (m in EloMode.values()) {
                    EloCard(
                        title = m.title, subtitle = m.subtitle, rating = profile.elo(m), selected = m == mode,
                        modifier = Modifier.weight(1f), onClick = { modeIdx = m.ordinal },
                    )
                }
            }
        }

        // --- Biểu đồ Elo
        item(key = "chart") {
            GlassSection("BIẾN ĐỘNG ELO · ${mode.title.uppercase()}") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (r in EloRange.values()) RangeChip(r.label, selected = r == range) { rangeIdx = r.ordinal }
                }
                EloChart(history = profile.eloHistory[mode].orEmpty(), currentRating = profile.elo(mode), range = range)
            }
        }

        // --- Tabs
        if (tabs.size > 1) {
            item(key = "tabs") { ProfileTabs(tabs, tab.coerceIn(0, tabs.lastIndex)) { tab = it } }
        }
        val current = tab.coerceIn(0, tabs.lastIndex)
        when (tabs[current]) {
            "Tổng quan" -> item(key = "overview") { OverviewTab(profile, if (isSelf) dayStreak else null) }
            "Ván đấu" -> if (games.isEmpty()) {
                item(key = "gamesEmpty") { EmptyHint("Chưa có ván nào. Chơi với Bot hoặc tham gia giải đấu để ván xuất hiện ở đây.") }
            } else {
                items(games) { GameRow(it) }
            }
            "Thành tích" -> items(trophies) { TrophyRow(it) }
            "Bạn bè" -> item(key = "friends") { FriendsPanel(onViewProfile = onOpenProfile) }
            else -> Unit
        }
    }
}

// ------------------------------------------------------------------ Tab: Tổng quan

@Composable
private fun OverviewTab(p: UserProfile, dayStreak: Int?) {
    GlassSection("THỐNG KÊ") {
        Row(Modifier.fillMaxWidth()) {
            StatTile("Ván", p.played.toString(), Color.White, Modifier.weight(1f))
            StatTile("Thắng", p.won.toString(), WinColor, Modifier.weight(1f))
            StatTile("Hòa", p.drawn.toString(), DrawColor, Modifier.weight(1f))
            StatTile("Thua", p.lost.toString(), LossColor, Modifier.weight(1f))
        }
        WdlBar(p.won, p.drawn, p.lost)
        InfoRow("Tỉ lệ thắng", "${p.winRatePct}%")
        InfoRow(
            "Chuỗi hiện tại", streakLabel(p.resultStreak),
            valueColor = when { p.resultStreak > 0 -> WinColor; p.resultStreak < 0 -> LossColor; else -> VilaColors.TextDim },
        )
        if (dayStreak != null) InfoRow("Chuỗi ngày chơi", if (dayStreak > 0) "$dayStreak ngày" else "Chưa có")
    }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color = Color.White) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = valueColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

// ------------------------------------------------------------------ Tab: Ván đấu / Thành tích

private val DATE_FMT = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

@Composable
private fun GameRow(g: GameRecord) {
    val (label, color) = when {
        g.score >= 1.0 -> "T" to WinColor
        g.score <= 0.0 -> "B" to LossColor
        else -> "H" to DrawColor
    }
    val modeTitle = EloMode.fromKey(g.modeKey)?.title ?: "Tự do"
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(VilaColors.Glass).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(36.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("vs ${g.opponent}", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("$modeTitle · ${g.moves} nước · ${DATE_FMT.format(Date(g.ts))}", color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1)
        }
        if (g.modeKey != "free") {
            Text(
                (if (g.delta >= 0) "+" else "") + g.delta,
                color = if (g.delta >= 0) WinColor else LossColor, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
            )
        }
    }
}

@Composable
private fun TrophyRow(a: Achievement) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(VilaColors.Glass).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(if (a.done) VilaColors.Green else Color(0x22FFFFFF)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (a.done) Icons.Filled.Check else Icons.Filled.Lock,
                contentDescription = if (a.done) "Đã đạt" else "Chưa đạt",
                tint = if (a.done) Color.White else VilaColors.TextDim, modifier = Modifier.size(20.dp),
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.title, color = if (a.done) Color.White else VilaColors.TextDim, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(a.desc, color = VilaColors.TextDim, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Text(text, color = VilaColors.TextDim, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp))
}

// ------------------------------------------------------------------ Thanh trên + tab + chip

@Composable
private fun ProfileTopBar(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onBack).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color.White)
        Text("  $title", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

/** Hàng tab tự vẽ (gạch chân xanh dưới tab đang chọn). */
@Composable
private fun ProfileTabs(tabs: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        tabs.forEachIndexed { i, label ->
            val on = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    label, color = if (on) Color.White else VilaColors.TextDim, fontSize = 14.sp,
                    fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold, maxLines = 1,
                )
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(3.dp).background(if (on) VilaColors.Green else Color(0x22FFFFFF)))
            }
        }
    }
}

@Composable
private fun RangeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text = label,
        color = if (selected) Color.White else VilaColors.TextDim,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) VilaColors.Green else Color(0x22FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    )
}

// ------------------------------------------------------------------ Chỉnh sửa hồ sơ

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditProfileSheet(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(UserSessionManager.displayName) }
    var avatar by remember { mutableStateOf(UserSessionManager.avatarKey) }
    var country by remember { mutableStateOf(UserSessionManager.countryCode) }
    var error by remember { mutableStateOf<String?>(null) }
    var pickCountry by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Color(0xFF16233B),
        contentColor = Color.White,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Chỉnh sửa hồ sơ", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            ProfileAvatar(name = name, avatarKey = avatar, size = 84.dp)

            // Avatar: chữ cái đầu của tên + 6 avatar quân cờ
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                item(key = "initial") { AvatarChoice(name, "", selected = avatar.isBlank()) { avatar = "" } }
                items(Avatars.presets, key = { it.key }) { pr -> AvatarChoice(name, pr.key, selected = avatar == pr.key) { avatar = pr.key } }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(30); error = null },
                label = { Text("Tên hiển thị") },
                singleLine = true,
                isError = error != null,
                supportingText = { Text(error ?: "2–20 ký tự") },
                modifier = Modifier.fillMaxWidth(),
            )

            // Quốc gia
            val c = Countries.byCode(country)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x14FFFFFF))
                    .clickable { pickCountry = true }.padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Quốc gia", color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(if (c != null) Countries.flag(c.code) + " " + c.name else "Chưa chọn", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }

            ChunkyButton(
                text = "Lưu",
                onClick = {
                    val err = UserSessionManager.updateProfile(ctx, name, country, avatar)
                    if (err != null) error = err
                    else { Toast.makeText(ctx, "Đã lưu hồ sơ", Toast.LENGTH_SHORT).show(); onDismiss() }
                },
                modifier = Modifier.fillMaxWidth(), height = 48.dp, fontSize = 18.sp,
            )
        }
    }

    if (pickCountry) {
        AlertDialog(
            onDismissRequest = { pickCountry = false },
            title = { Text("Chọn quốc gia") },
            text = {
                LazyColumn(Modifier.height(360.dp)) {
                    items(Countries.all, key = { it.code }) { ct ->
                        Row(
                            Modifier.fillMaxWidth().clickable { country = ct.code; pickCountry = false }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(Countries.flag(ct.code), fontSize = 22.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(ct.name, fontSize = 16.sp, fontWeight = if (ct.code == country) FontWeight.ExtraBold else FontWeight.Normal)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickCountry = false }) { Text("Đóng") } },
        )
    }
}

@Composable
private fun AvatarChoice(name: String, key: String, selected: Boolean, onClick: () -> Unit) {
    ProfileAvatar(
        name = name, avatarKey = key, size = 48.dp,
        modifier = Modifier
            .border(if (selected) 3.dp else 0.dp, if (selected) VilaColors.Green else Color.Transparent, CircleShape)
            .clickable(onClick = onClick),
    )
}
