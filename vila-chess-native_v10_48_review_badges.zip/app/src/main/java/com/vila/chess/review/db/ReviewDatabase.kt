package com.vila.chess.review.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AnalysisSummary::class, AnalysisResult::class], version = 1, exportSchema = false)
abstract class ReviewDatabase : RoomDatabase() {
    abstract fun analysisDao(): AnalysisDao

    companion object {
        @Volatile private var instance: ReviewDatabase? = null

        fun get(context: Context): ReviewDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, ReviewDatabase::class.java, "game_review.db",
                )
                    // Dữ liệu ở đây chỉ là bộ nhớ đệm có thể phân tích lại, nên đổi schema thì bỏ đi làm lại.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
