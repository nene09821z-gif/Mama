package com.vila.chess.cloud

import android.content.Context
import android.util.Log
import com.vila.chess.R
import com.vila.chess.review.GameReview
import com.vila.chess.review.GameReviewStore
import com.vila.chess.review.ReviewJson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Đồng bộ kết quả Game Review lên Supabase (gói free), mỗi tài khoản một vùng dữ liệu riêng nhờ RLS.
 * Không dùng SDK: chỉ gọi REST bằng HttpURLConnection. Mọi hàm công khai KHÔNG ném lỗi (chỉ log) —
 * cloud hỏng thì app vẫn chạy bình thường với bản lưu trong máy.
 * Đăng nhập Google hoặc email + mật khẩu thì có cloud.
 */
/** Kết quả đăng ký / đăng nhập / quên mật khẩu bằng email. */
sealed class EmailAuthResult {
    data class Success(val email: String) : EmailAuthResult()
    object NeedConfirm : EmailAuthResult()      // đăng ký xong, cần bấm link xác nhận trong email
    object Sent : EmailAuthResult()             // đã gửi email đặt lại mật khẩu
    data class Error(val message: String) : EmailAuthResult()
}

object SupabaseCloud {
    private const val TAG = "GameReview"
    private const val PREFS = "vila_supabase"

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun baseUrl(ctx: Context) = ctx.getString(R.string.supabase_url).trim().trimEnd('/')
    private fun anonKey(ctx: Context) = ctx.getString(R.string.supabase_anon_key).trim()

    /** Đã điền URL + anon key trong strings.xml chưa. */
    fun configured(ctx: Context): Boolean =
        baseUrl(ctx).startsWith("https://") && anonKey(ctx).isNotBlank() && !anonKey(ctx).startsWith("YOUR_")

    fun signedIn(ctx: Context): Boolean = prefs(ctx).getString("refresh", null) != null

    /** id (uuid) của người dùng trong Supabase Auth; null = chưa đăng nhập Supabase. Khớp `users.id` của hệ thống Hồ sơ. */
    fun userId(ctx: Context): String? = prefs(ctx).getString("uid", null)?.takeIf { it.isNotBlank() }

    // ------------------------------------------------------------------ Đăng nhập

    /** Đổi Google id_token lấy phiên Supabase. Gọi ngay sau khi người dùng đăng nhập Google thành công. */
    suspend fun signInWithGoogle(ctx: Context, idToken: String?): Boolean = withContext(Dispatchers.IO) {
        if (idToken.isNullOrBlank() || !configured(ctx)) return@withContext false
        try {
            val body = JSONObject().put("provider", "google").put("id_token", idToken).toString()
            val (code, text) = http(ctx, "POST", "/auth/v1/token?grant_type=id_token", body, bearer = null)
            if (code !in 200..299) {
                Log.e(TAG, "Supabase đăng nhập lỗi $code: ${text.take(200)}")
                return@withContext false
            }
            saveSession(ctx, JSONObject(text))
            flushPending(ctx)
            runCatching { com.vila.chess.profile.UserSessionManager.requestSync(ctx) }   // đẩy hồ sơ lên cloud ngay sau khi có phiên
            true
        } catch (e: Exception) {
            Log.e(TAG, "Supabase đăng nhập lỗi: ${e.message}")
            false
        }
    }

    /** Đăng ký bằng email + mật khẩu (Supabase Auth). Nếu dự án bật "Confirm email" thì trả [EmailAuthResult.NeedConfirm]. */
    suspend fun signUpWithEmail(ctx: Context, email: String, password: String): EmailAuthResult = withContext(Dispatchers.IO) {
        if (!configured(ctx)) return@withContext EmailAuthResult.Error("Chưa cấu hình máy chủ đăng nhập.")
        try {
            val body = JSONObject().put("email", email.trim()).put("password", password).toString()
            val (code, text) = http(ctx, "POST", "/auth/v1/signup", body, bearer = null)
            if (code !in 200..299) return@withContext EmailAuthResult.Error(authError(code, text))
            val j = JSONObject(text)
            when {
                j.has("access_token") -> { saveSession(ctx, j); EmailAuthResult.Success(email.trim()) }
                j.optJSONArray("identities")?.length() == 0 -> EmailAuthResult.Error("Email này đã được đăng ký. Hãy đăng nhập.")
                else -> EmailAuthResult.NeedConfirm
            }
        } catch (e: java.io.IOException) {
            EmailAuthResult.Error("Không có kết nối mạng.")
        } catch (e: Exception) {
            Log.e(TAG, "Supabase đăng ký lỗi: ${e.message}")
            EmailAuthResult.Error(e.message ?: "Lỗi không xác định")
        }
    }

    /** Đăng nhập bằng email + mật khẩu. Sai mật khẩu / chưa xác nhận email đều trả [EmailAuthResult.Error] có thông báo tiếng Việt. */
    suspend fun signInWithEmail(ctx: Context, email: String, password: String): EmailAuthResult = withContext(Dispatchers.IO) {
        if (!configured(ctx)) return@withContext EmailAuthResult.Error("Chưa cấu hình máy chủ đăng nhập.")
        try {
            val body = JSONObject().put("email", email.trim()).put("password", password).toString()
            val (code, text) = http(ctx, "POST", "/auth/v1/token?grant_type=password", body, bearer = null)
            if (code !in 200..299) return@withContext EmailAuthResult.Error(authError(code, text))
            saveSession(ctx, JSONObject(text))
            EmailAuthResult.Success(email.trim())
        } catch (e: java.io.IOException) {
            EmailAuthResult.Error("Không có kết nối mạng.")
        } catch (e: Exception) {
            Log.e(TAG, "Supabase đăng nhập email lỗi: ${e.message}")
            EmailAuthResult.Error(e.message ?: "Lỗi không xác định")
        }
    }

    /** Gửi email đặt lại mật khẩu. Supabase luôn trả thành công kể cả khi email chưa đăng ký (để không lộ ai có tài khoản). */
    suspend fun sendPasswordReset(ctx: Context, email: String): EmailAuthResult = withContext(Dispatchers.IO) {
        if (!configured(ctx)) return@withContext EmailAuthResult.Error("Chưa cấu hình máy chủ đăng nhập.")
        try {
            val body = JSONObject().put("email", email.trim()).toString()
            val (code, text) = http(ctx, "POST", "/auth/v1/recover", body, bearer = null)
            if (code in 200..299) EmailAuthResult.Sent else EmailAuthResult.Error(authError(code, text))
        } catch (e: java.io.IOException) {
            EmailAuthResult.Error("Không có kết nối mạng.")
        } catch (e: Exception) {
            EmailAuthResult.Error(e.message ?: "Lỗi không xác định")
        }
    }

    private fun authError(code: Int, text: String): String {
        val j = runCatching { JSONObject(text) }.getOrNull()
        val ec = j?.optString("error_code").orEmpty().ifBlank { j?.optString("error").orEmpty() }
        val msg = j?.optString("msg").orEmpty()
            .ifBlank { j?.optString("error_description").orEmpty() }
            .ifBlank { j?.optString("message").orEmpty() }
        return when {
            ec == "invalid_credentials" || msg.contains("Invalid login credentials", ignoreCase = true) -> "Sai email hoặc mật khẩu."
            ec == "email_not_confirmed" || msg.contains("not confirmed", ignoreCase = true) -> "Email chưa được xác nhận. Hãy bấm link trong email xác nhận."
            ec == "user_already_exists" || ec == "email_exists" -> "Email này đã được đăng ký. Hãy đăng nhập."
            ec == "weak_password" -> "Mật khẩu quá yếu. Hãy dùng ít nhất 8 ký tự, có cả chữ và số."
            ec == "email_address_invalid" || ec == "validation_failed" -> "Email không hợp lệ."
            code == 429 || ec.contains("rate_limit") -> "Thử quá nhiều lần. Hãy đợi vài phút rồi thử lại."
            msg.isNotBlank() -> msg
            else -> "Lỗi máy chủ ($code)."
        }
    }

    fun signOut(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }

    private fun saveSession(ctx: Context, j: JSONObject) {
        val expiresIn = j.optLong("expires_in", 3600L)
        val uid = j.optJSONObject("user")?.optString("id").orEmpty()
        prefs(ctx).edit()
            .apply { if (uid.isNotBlank()) putString("uid", uid) }
            .putString("access", j.getString("access_token"))
            .putString("refresh", j.getString("refresh_token"))
            .putLong("expiresAt", System.currentTimeMillis() / 1000 + expiresIn)
            .apply()
    }

    /** Access token còn hạn (tự refresh nếu sắp hết). null = chưa đăng nhập hoặc refresh thất bại. */
    private fun accessToken(ctx: Context): String? {
        val p = prefs(ctx)
        val refresh = p.getString("refresh", null) ?: return null
        val access = p.getString("access", null)
        if (access != null && p.getLong("expiresAt", 0L) > System.currentTimeMillis() / 1000 + 60) return access
        return try {
            val body = JSONObject().put("refresh_token", refresh).toString()
            val (code, text) = http(ctx, "POST", "/auth/v1/token?grant_type=refresh_token", body, bearer = null)
            if (code !in 200..299) {
                Log.e(TAG, "Supabase refresh lỗi $code")
                if (code == 400 || code == 401) signOut(ctx)   // refresh token hết hạn/bị thu hồi: phải đăng nhập lại
                null
            } else {
                val j = JSONObject(text)
                saveSession(ctx, j)
                j.getString("access_token")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Supabase refresh lỗi: ${e.message}")
            null
        }
    }

    // ------------------------------------------------------------------ Review

    /** Đẩy một review lên cloud. Thất bại (mất mạng...) thì ghi nhớ để thử lại lần sau. */
    suspend fun pushReview(ctx: Context, review: GameReview): Boolean = withContext(Dispatchers.IO) {
        if (!configured(ctx) || !signedIn(ctx)) return@withContext false
        try {
            val token = accessToken(ctx) ?: run { markPending(ctx, review.gameId); return@withContext false }
            val body = JSONObject()
                .put("game_id", review.gameId)
                .put("review", JSONObject(ReviewJson.encode(review)))
                .toString()
            val (code, text) = http(
                ctx, "POST", "/rest/v1/game_reviews?on_conflict=user_id,game_id", body, token,
                prefer = "resolution=merge-duplicates,return=minimal",
            )
            if (code in 200..299) {
                clearPending(ctx, review.gameId)
                true
            } else {
                Log.e(TAG, "Supabase lưu review lỗi $code: ${text.take(200)}")
                markPending(ctx, review.gameId)
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Supabase lưu review lỗi: ${e.message}")
            markPending(ctx, review.gameId)
            false
        }
    }

    /** Lấy review của chính tài khoản đang đăng nhập. null = không có / chưa đăng nhập / lỗi. */
    suspend fun pullReview(ctx: Context, gameId: String): GameReview? = withContext(Dispatchers.IO) {
        if (!configured(ctx) || !signedIn(ctx)) return@withContext null
        try {
            val token = accessToken(ctx) ?: return@withContext null
            val q = "/rest/v1/game_reviews?game_id=eq.${URLEncoder.encode(gameId, "UTF-8")}&select=review&limit=1"
            val (code, text) = http(ctx, "GET", q, null, token)
            if (code !in 200..299) return@withContext null
            val arr = JSONArray(text)
            if (arr.length() == 0) null else ReviewJson.decode(arr.getJSONObject(0).getJSONObject("review").toString())
        } catch (e: Exception) {
            Log.e(TAG, "Supabase đọc review lỗi: ${e.message}")
            null
        }
    }

    /** Đẩy lại các review từng thất bại (offline...). */
    suspend fun flushPending(ctx: Context) {
        val ids = prefs(ctx).getStringSet("pending", emptySet())?.toList().orEmpty()
        if (ids.isEmpty()) return
        val store = GameReviewStore(ctx)
        for (id in ids) {
            val r = store.load(id)
            if (r == null) clearPending(ctx, id) else if (!pushReview(ctx, r)) break
        }
    }

    private fun markPending(ctx: Context, id: String) {
        val p = prefs(ctx)
        p.edit().putStringSet("pending", (p.getStringSet("pending", emptySet()) ?: emptySet()) + id).apply()
    }

    private fun clearPending(ctx: Context, id: String) {
        val p = prefs(ctx)
        p.edit().putStringSet("pending", (p.getStringSet("pending", emptySet()) ?: emptySet()) - id).apply()
    }

    // ------------------------------------------------------------------ REST dùng chung (hệ thống Hồ sơ)

    /**
     * Gọi PostgREST bằng token đăng nhập. Khác các hàm review (nuốt lỗi), hàm này trả [Result] có phân loại
     * [com.vila.chess.profile.ProfileException] để UI hiện đúng trạng thái: chưa cấu hình / chưa đăng nhập / mất mạng / lỗi máy chủ.
     */
    suspend fun restCall(
        ctx: Context, method: String, path: String, body: String? = null, prefer: String? = null,
    ): Result<String> = withContext(Dispatchers.IO) {
        if (!configured(ctx)) return@withContext Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.NOT_CONFIGURED))
        if (!signedIn(ctx)) return@withContext Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.NOT_SIGNED_IN))
        try {
            val token = accessToken(ctx)
                ?: return@withContext Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.NOT_SIGNED_IN))
            val (code, text) = http(ctx, method, path, body, token, prefer)
            if (code in 200..299) Result.success(text)
            else {
                Log.e(TAG, "Supabase $method $path lỗi $code: ${text.take(200)}")
                Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.SERVER, "HTTP $code"))
            }
        } catch (e: java.io.IOException) {
            Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.NETWORK, e.message))
        } catch (e: Exception) {
            Log.e(TAG, "Supabase $method $path lỗi: ${e.message}")
            Result.failure(com.vila.chess.profile.ProfileException(com.vila.chess.profile.ProfileError.SERVER, e.message))
        }
    }

    // ------------------------------------------------------------------ HTTP

    private fun http(
        ctx: Context, method: String, path: String, body: String?, bearer: String?, prefer: String? = null,
    ): Pair<Int, String> {
        val c = URL(baseUrl(ctx) + path).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("apikey", anonKey(ctx))
            // Khóa mới (sb_publishable_...) không phải JWT: chỉ gửi trong "apikey". Authorization chỉ dùng cho token đăng nhập của người dùng.
            if (bearer != null) c.setRequestProperty("Authorization", "Bearer $bearer")
            c.setRequestProperty("Content-Type", "application/json")
            if (prefer != null) c.setRequestProperty("Prefer", prefer)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return code to text
        } finally {
            c.disconnect()
        }
    }
}
