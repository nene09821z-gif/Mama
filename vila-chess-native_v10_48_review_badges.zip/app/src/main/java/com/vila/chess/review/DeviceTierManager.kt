package com.vila.chess.review

import android.app.ActivityManager
import android.content.Context

enum class DeviceTier { LOW, MEDIUM, HIGH }

/** Cấu hình engine cho một dòng máy. moveTimeoutMs = trần thời gian cho MỖI thế cờ. */
data class EngineConfig(
    val tier: DeviceTier,
    val depth: Int,
    val threads: Int,
    val hashMb: Int,
    val moveTimeoutMs: Long = 700L,
)

object DeviceTierManager {

    private const val GB = 1024.0 * 1024.0 * 1024.0

    /**
     * Tự chọn cấu hình theo RAM thật + số nhân CPU:
     *  - LOW    (RAM < 3GB, hoặc máy bật cờ isLowRamDevice): depth 12 (10 nếu <= 4 nhân), 1 thread, hash 16MB, 700ms/thế
     *  - MEDIUM (3–6GB): depth 18, 2 thread, hash 64MB, 1200ms/thế
     *  - HIGH   (> 6GB): depth 22, 4 thread, hash 128MB, 1800ms/thế
     * Phân tích chạy ngầm nên ưu tiên độ chuẩn: sâu hơn + nhiều thời gian hơn mỗi thế (depth/movetime tới trước thì dừng).
     * Threads luôn bị chặn trên bởi số nhân thực tế.
     * Lưu ý: máy quảng cáo "4GB" thường báo totalMem ~3.6GB nên vẫn rơi vào MEDIUM.
     */
    fun getDeviceTier(context: Context): EngineConfig {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramGb = info.totalMem / GB
        val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

        val tier = when {
            am.isLowRamDevice || ramGb < 3.0 -> DeviceTier.LOW
            ramGb <= 6.0 -> DeviceTier.MEDIUM
            else -> DeviceTier.HIGH
        }
        return when (tier) {
            DeviceTier.LOW -> EngineConfig(
                tier, depth = if (cores <= 4) 10 else 12,
                threads = 1, hashMb = 16, moveTimeoutMs = 700L,
            )
            DeviceTier.MEDIUM -> EngineConfig(
                tier, depth = 18, threads = minOf(2, cores), hashMb = 64, moveTimeoutMs = 1200L,
            )
            DeviceTier.HIGH -> EngineConfig(
                tier, depth = 22, threads = minOf(4, cores), hashMb = 128, moveTimeoutMs = 1800L,
            )
        }
    }
}
