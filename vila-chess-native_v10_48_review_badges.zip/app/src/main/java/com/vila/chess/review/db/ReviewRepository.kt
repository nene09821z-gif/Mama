package com.vila.chess.review.db

import android.content.Context
import androidx.room.withTransaction
import com.vila.chess.review.GameReview
import com.vila.chess.review.GameReviewStore
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewClassifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/**
 * Nguồn dữ liệu Game Review. Room là NGUỒN CHÍNH (màn Review quan sát bằng Flow);
 * file JSON ([GameReviewStore]) chỉ là bản sao cho kho ván + đồng bộ Supabase, ghi sau khi Room đã xong.
 */
class ReviewRepository private constructor(context: Context) {
    private val app = context.applicationContext
    private val db = ReviewDatabase.get(app)
    private val dao = db.analysisDao()
    private val mirror = GameReviewStore(app)

    /** Ghi cả ván trong MỘT giao dịch: summary + mọi dòng nước đi cùng hiện ra một lúc. */
    suspend fun save(review: GameReview) = withContext(Dispatchers.IO) {
        write(review)
        runCatching { mirror.save(review) }
    }

    private suspend fun write(review: GameReview) {
        db.withTransaction {
            dao.deleteGame(review.gameId)   // sạch kết quả cũ (nếu có) rồi mới ghi lại
            dao.upsertSummary(AnalysisMapper.toSummary(review))
            dao.insertResults(AnalysisMapper.toRows(review))
        }
    }

    /** Có kết quả hợp lệ (đúng phiên bản thuật toán) trong Room chưa. */
    suspend fun exists(gameId: String): Boolean = withContext(Dispatchers.IO) {
        dao.summary(gameId)?.let { it.version >= ReviewAssembler.ANALYSIS_VERSION } == true
    }

    /**
     * Đọc kết quả của ván. Room rỗng thì thử nhận file JSON cũ — chỉ khi nó đã ở phiên bản thuật toán hiện tại;
     * file cũ hơn dùng ngưỡng nhãn cũ nên để Worker phân tích lại.
     */
    suspend fun load(gameId: String): GameReview? = withContext(Dispatchers.IO) {
        read(gameId) ?: importLegacy(gameId)
    }

    /** Phát kết quả mỗi khi bảng thay đổi. null = chưa có (Worker chưa xong). Chạy hoàn toàn ngoài luồng chính. */
    fun observe(gameId: String): Flow<GameReview?> =
        dao.observeSummary(gameId)
            .map { s ->
                if (s == null || s.version < ReviewAssembler.ANALYSIS_VERSION) null
                else AnalysisMapper.toReview(s, dao.results(gameId))
            }
            .distinctUntilChanged()
            .flowOn(Dispatchers.IO)

    suspend fun delete(gameId: String) = withContext(Dispatchers.IO) {
        dao.deleteGame(gameId)
        mirror.delete(gameId)
    }

    private suspend fun read(gameId: String): GameReview? {
        val s = dao.summary(gameId) ?: return null
        if (s.version < ReviewAssembler.ANALYSIS_VERSION) return null
        val r = AnalysisMapper.toReview(s, dao.results(gameId))
        if (r == null) dao.deleteGame(gameId)   // dở dang/hỏng: bỏ để phân tích lại
        return r
    }

    private suspend fun importLegacy(gameId: String): GameReview? {
        val old = mirror.load(gameId) ?: return null
        if (old.version < ReviewAssembler.ANALYSIS_VERSION || !ReviewClassifier.isUsable(old)) return null
        write(old)
        return old
    }

    companion object {
        @Volatile private var instance: ReviewRepository? = null

        fun get(context: Context): ReviewRepository =
            instance ?: synchronized(this) { instance ?: ReviewRepository(context).also { instance = it } }
    }
}
