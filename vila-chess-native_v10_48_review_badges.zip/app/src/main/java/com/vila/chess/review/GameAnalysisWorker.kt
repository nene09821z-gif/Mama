package com.vila.chess.review

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.vila.chess.review.db.ReviewRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Phân tích ván cờ CHẠY NGẦM HOÀN TOÀN (Silent Background Analysis).
 *
 *  - Được xếp hàng khi ván kết thúc ([enqueueAnalysis]); không có thông báo, không có tiến độ.
 *    TUYỆT ĐỐI không setProgress / StateFlow / LiveData / Toast trong lúc chạy: UI chỉ biết khi KẾT QUẢ đã nằm trong Room.
 *  - Ràng buộc: pin không thấp (hệ thống ~15%; tự được bỏ qua khi đang sạc). Pin yếu => work chờ đến khi sạc rồi mới chạy.
 *  - Chạy trên Dispatchers.Default; engine native bị hạ độ ưu tiên CPU (nice) để nhường luồng chính.
 *  - Mỗi nước đi lưu vào bảng analysis_result (FEN, Best Move, điểm, nhãn...) trong MỘT giao dịch với analysis_summary.
 *  - BẮT BUỘC: xong (kể cả lỗi/hủy) là gửi `stop` + `quit` cho engine, giải phóng tiến trình và RAM.
 */
class GameAnalysisWorker(
    ctx: Context,
    params: WorkerParameters,
) : CoroutineWorker(ctx, params) {

    companion object {
        private const val TAG = "GameAnalysis"
        private const val KEY_GAME_ID = "gameId"

        /** Tên work duy nhất của một ván. */
        fun uniqueName(gameId: String) = "game_analysis_$gameId"

        private fun queueFile(context: Context, gameId: String) =
            File(File(context.filesDir, "review_queue").apply { mkdirs() }, "$gameId.txt")

        /** Xóa file hàng đợi của một ván. */
        fun discardQueue(context: Context, gameId: String) {
            runCatching { queueFile(context.applicationContext, gameId).delete() }
        }

        /**
         * Gọi khi ván kết thúc (hoặc khi mở một ván chưa có kết quả). FEN đầu ván + các nước UCI được ghi ra file
         * thay vì nhét vào inputData vì Data của WorkManager giới hạn 10KB — ván dài sẽ crash.
         *
         * [replace] = true: hủy work cũ (đã thất bại/kẹt) và xếp lại. Mặc định KEEP: đang chờ/đang chạy thì không đụng.
         * KHÔNG gọi setExpedited(): work chạy ở mức ưu tiên thường, nhường tài nguyên cho app đang mở.
         */
        fun enqueueAnalysis(
            context: Context,
            gameId: String,
            startFen: String,
            ucis: List<String>,
            replace: Boolean = false,
        ) {
            val app = context.applicationContext
            val qf = queueFile(app, gameId)
            val tmp = File(qf.parentFile, qf.name + ".tmp")
            tmp.writeText(ReviewReplay.encodeQueue(startFen, ucis))
            if (!tmp.renameTo(qf)) { qf.delete(); tmp.renameTo(qf) }

            // WorkManager chỉ có AND giữa các constraint. BatteryNotLow (~15%) tự thỏa khi đang sạc,
            // nên tương đương "đang sạc HOẶC pin > 15%". Pin yếu => chờ, không chạy.
            val constraints = Constraints.Builder().setRequiresBatteryNotLow(true).build()

            val req = OneTimeWorkRequestBuilder<GameAnalysisWorker>()
                .setInputData(workDataOf(KEY_GAME_ID to gameId))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(app).enqueueUniqueWork(
                uniqueName(gameId),
                if (replace) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
                req,
            )
        }
    }

    // Dispatchers.Default: không chiếm Main/IO; engine (tiến trình riêng) được hạ ưu tiên ở SilentStockfishEngine.
    override suspend fun doWork(): Result = withContext(Dispatchers.Default) {
        val gameId = inputData.getString(KEY_GAME_ID) ?: return@withContext Result.failure()
        val repo = ReviewRepository.get(applicationContext)
        // Đã có kết quả hợp lệ trong Room => xong (file hàng đợi còn sót thì dọn).
        if (repo.exists(gameId)) { discardQueue(applicationContext, gameId); return@withContext Result.success() }

        val qf = queueFile(applicationContext, gameId)
        if (!qf.exists()) return@withContext Result.failure()
        val replay = ReviewReplay.parseQueue(qf.readLines())
        if (replay == null) { qf.delete(); return@withContext Result.failure() }
        if (replay.plies.isEmpty()) { qf.delete(); return@withContext Result.success() }
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }

        // Cấu hình engine theo máy (RAM + số nhân) — DeviceTierManager.
        val config = DeviceTierManager.getDeviceTier(applicationContext)
        val monitor = DeviceHealthMonitor(applicationContext)
        val engine = SilentStockfishEngine(applicationContext, config)

        try {
            val evals = ArrayList<EngineResult>(fens.size)
            for (fen in fens) {
                ensureActive()
                // Thế đã hết ván (chiếu hết/hòa) tính bằng luật cờ, không cần engine.
                val terminal = ReviewReplay.terminalEval(fen)
                if (terminal != null) { evals += terminal; continue }

                // Nóng > 40°C: stop + giải phóng engine, chờ 1 phút/lượt. Quá 5 lượt -> retry sau.
                val cool = monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })
                if (!cool) return@withContext Result.retry()

                evals += engine.analyzeSilently(fen, config.depth)
            }

            // Vòng kiểm chứng: chỉ tìm lại SÂU HƠN những thế thuộc nước nghi sai (tối đa vài nước) để kết luận
            // Mistake/Blunder/Miss không bị oan do nhiễu độ sâu. Lỗi ở vòng này KHÔNG làm mất kết quả vòng đầu.
            val suspects = ReviewVerify.suspectPositions(replay.plies, evals)
            for (k in suspects) {
                ensureActive()
                try {
                    if (!monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })) break
                    val deep = engine.analyzeSilently(fens[k], config.depth + 4, config.moveTimeoutMs * 3)
                    if (deep.depthReached >= evals[k].depthReached) evals[k] = deep
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "Bỏ qua vòng kiểm chứng: ${e.message}")
                    break
                }
            }

            val review = ReviewAssembler.assemble(
                gameId, replay.startFen, replay.plies, evals,
                config.tier.name, System.currentTimeMillis(),
                book = OpeningBook.load(applicationContext),
            )
            repo.save(review)     // Room (+ bản sao JSON): đây là lúc màn Review "thấy" kết quả
            qf.delete()
            com.vila.chess.cloud.SupabaseCloud.pushReview(applicationContext, review)   // không ném lỗi
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: IllegalStateException) {
            // Engine không khởi động / không trả kết quả: retry vô ích.
            Log.e(TAG, "Lỗi phân tích: ${e.message}", e)
            Result.failure()
        } catch (e: Throwable) {
            // Mọi lỗi khác (parse, OOM, IO...) chỉ được log, không làm văng app.
            Log.e(TAG, "Lỗi phân tích: ${e.message}", e)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        } finally {
            // BẮT BUỘC: stop -> quit -> destroy, kể cả khi bị hủy (NonCancellable) để RAM luôn được trả lại.
            withContext(NonCancellable) { engine.shutdown() }
        }
    }
}
