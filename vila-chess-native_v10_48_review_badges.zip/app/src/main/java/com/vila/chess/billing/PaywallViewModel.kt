package com.vila.chess.billing

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TierPlans(val tier: MembershipTier, val monthly: PlanOption?, val yearly: PlanOption?) {
    fun option(period: BillingPeriod): PlanOption? = if (period == BillingPeriod.MONTHLY) monthly else yearly
}

data class PaywallUiState(
    val tiers: List<TierPlans> = emptyList(),
    val period: BillingPeriod = BillingPeriod.YEARLY,
    val selected: MembershipTier = MembershipTier.DIAMOND,
    val currentTier: MembershipTier = MembershipTier.FREE,
    val isLoading: Boolean = true,
    val isPurchasing: Boolean = false,
    val error: BillingError? = null,
    val notice: String? = null,
    /** Gói vừa mở khóa (mua xong / nhập mã xong): màn Paywall hiện hộp chúc mừng với huy hiệu động của gói đó. */
    val unlocked: MembershipTier? = null,
)

class PaywallViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = BillingRepository.get(app)
    private val store = MembershipStore.get(app)

    private val _ui = MutableStateFlow(PaywallUiState(currentTier = store.tier.value))
    val ui: StateFlow<PaywallUiState> = _ui.asStateFlow()

    init {
        viewModelScope.launch { store.tier.collect { t -> _ui.update { it.copy(currentTier = t) } } }
        viewModelScope.launch { repo.events.collect(::onEvent) }
        reload()
    }

    fun reload() {
        _ui.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            LicenseManager.syncFromServer(getApplication<Application>())   // tự nhận gói nếu đã chuyển khoản (cần SERVER_URL)
            store.refresh()
            repo.refreshEntitlements()
            // Luôn hiện đủ 4 gói (thứ tự như chess.com: Kim cương → Bạch kim → Vàng → Friends & Family):
            // có giá Google Play thì dùng, không thì dùng bảng giá chuyển khoản (BillingCatalog.priceVnd).
            val options = repo.loadPlans().getOrNull().orEmpty()
            val tiers = listOf(MembershipTier.DIAMOND, MembershipTier.PLATINUM, MembershipTier.GOLD, MembershipTier.FAMILY).map { t ->
                TierPlans(
                    tier = t,
                    monthly = options.firstOrNull { it.tier == t && it.period == BillingPeriod.MONTHLY },
                    yearly = options.firstOrNull { it.tier == t && it.period == BillingPeriod.YEARLY },
                )
            }
            _ui.update { it.copy(tiers = tiers, isLoading = false) }
        }
    }

    /** Nhập mã kích hoạt (sau khi chuyển khoản). Trả về thông báo để hiện trong hộp thoại. */
    fun redeem(code: String): Result<String> =
        LicenseManager.redeem(getApplication<Application>(), code).map { r ->
            val msg = "Đã kích hoạt gói " + r.tier.displayName + " đến " + LicenseManager.formatDate(r.expiresAt) + " 🎉"
            _ui.update { it.copy(notice = msg, error = null, unlocked = r.tier) }
            msg
        }

    fun selectTier(t: MembershipTier) = _ui.update { it.copy(selected = t) }
    fun setPeriod(p: BillingPeriod) = _ui.update { it.copy(period = p) }
    fun dismissMessage() = _ui.update { it.copy(error = null, notice = null) }
    fun dismissUnlocked() = _ui.update { it.copy(unlocked = null) }

    fun purchase(activity: Activity, tier: MembershipTier) {
        val state = _ui.value
        if (state.isPurchasing) return
        val option = state.tiers.firstOrNull { it.tier == tier }?.option(state.period) ?: return
        _ui.update { it.copy(selected = tier, isPurchasing = true, error = null, notice = null) }
        viewModelScope.launch {
            val launched = repo.launchPurchase(activity, option)
            if (!launched) _ui.update { it.copy(isPurchasing = false) }
        }
    }

    fun restore() {
        _ui.update { it.copy(isPurchasing = true, error = null, notice = null) }
        viewModelScope.launch {
            val found = repo.restore()
            _ui.update {
                it.copy(isPurchasing = false, notice = if (found) null else "Không tìm thấy gói nào để khôi phục")
            }
        }
    }

    private fun onEvent(e: BillingEvent) {
        when (e) {
            is BillingEvent.PurchaseSuccess ->
                _ui.update { it.copy(isPurchasing = false, notice = "Đã kích hoạt gói " + e.tier.displayName + " 🎉", unlocked = e.tier) }
            BillingEvent.Cancelled ->
                _ui.update { it.copy(isPurchasing = false, notice = "Bạn đã hủy giao dịch") }
            BillingEvent.Pending ->
                _ui.update { it.copy(isPurchasing = false, notice = "Giao dịch đang chờ xử lý. Gói sẽ được kích hoạt khi thanh toán hoàn tất.") }
            is BillingEvent.Failed ->
                _ui.update { it.copy(isPurchasing = false, error = e.error) }
        }
    }
}

fun BillingError.message(): String = when (this) {
    BillingError.NETWORK -> "Không có kết nối mạng. Kiểm tra Internet rồi thử lại."
    BillingError.BILLING_UNAVAILABLE -> "Thiết bị này không hỗ trợ thanh toán Google Play."
    BillingError.PRODUCT_UNAVAILABLE -> "Các gói chưa sẵn sàng. Vui lòng thử lại sau."
    BillingError.PAYMENT_FAILED -> "Thanh toán thất bại. Bạn chưa bị trừ tiền, hãy thử lại."
    BillingError.VERIFY_FAILED -> "Không xác thực được giao dịch. Hãy liên hệ hỗ trợ nếu đã bị trừ tiền."
    BillingError.UNKNOWN -> "Đã xảy ra lỗi. Vui lòng thử lại."
}
