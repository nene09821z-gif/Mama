package com.vila.chess.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import kotlin.random.Random

/** Một lớp sao cùng độ sáng/kích thước: vẽ bằng MỘT lệnh drawPoints thay vì hàng trăm drawCircle. */
private class StarLayer(val xs: FloatArray, val ys: FloatArray, val radiusDp: Float, val alpha: Float)

private fun buildStarLayers(): List<StarLayer> {
    val rnd = Random(7)
    // (số sao, bán kính dp, độ sáng): nhiều sao mờ nhỏ, ít sao sáng lớn -> có chiều sâu
    val spec = listOf(
        Triple(72, 0.6f, 0.22f),
        Triple(38, 0.95f, 0.42f),
        Triple(14, 1.4f, 0.70f),
    )
    return spec.map { (count, r, a) ->
        StarLayer(
            xs = FloatArray(count) { rnd.nextFloat() },
            ys = FloatArray(count) { rnd.nextFloat() },
            radiusDp = r,
            alpha = a,
        )
    }
}

/**
 * Nền không gian xanh thẫm phía sau màn hình chính.
 * Tối ưu: gradient + toạ độ sao được cache theo kích thước (drawWithCache), sao gom thành 3 lệnh
 * drawPoints. Không animation, không recomposition => gần như 0 chi phí mỗi frame.
 */
@Composable
fun SpaceBackground(modifier: Modifier = Modifier) {
    val layers = remember { buildStarLayers() }
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val base = Brush.verticalGradient(
                    colors = listOf(VilaColors.SpaceTop, VilaColors.SpaceMid, VilaColors.SpaceBottom),
                )
                val glowBlue = Brush.radialGradient(
                    colors = listOf(Color(0x552F6FD0), Color.Transparent),
                    center = Offset(w * 0.88f, h * 0.84f),
                    radius = w * 0.95f,
                )
                val glowPurple = Brush.radialGradient(
                    colors = listOf(Color(0x33A24FD0), Color.Transparent),
                    center = Offset(w * 0.08f, h * 0.36f),
                    radius = w * 0.7f,
                )
                val glowTop = Brush.radialGradient(
                    colors = listOf(Color(0x2238A1FF), Color.Transparent),
                    center = Offset(w * 0.5f, 0f),
                    radius = w * 0.9f,
                )
                val points = layers.map { l ->
                    List(l.xs.size) { Offset(l.xs[it] * w, l.ys[it] * h) }
                }
                onDrawBehind {
                    drawRect(base)
                    drawRect(glowTop)
                    drawRect(glowBlue)
                    drawRect(glowPurple)
                    for (i in layers.indices) {
                        drawPoints(
                            points = points[i],
                            pointMode = PointMode.Points,
                            color = Color.White.copy(alpha = layers[i].alpha),
                            strokeWidth = layers[i].radiusDp * 2f * density,
                            cap = StrokeCap.Round,
                        )
                    }
                }
            },
    )
}
