#!/usr/bin/env python3
"""Tạo mã kích hoạt ChessPlus (sau khi người dùng chuyển khoản).

Dùng:
  python3 scripts/gen_license.py --device A1B2C3D4 --tier gold --period yearly
  (mã thiết bị người dùng gửi cho bạn: hiện trong hộp thoại thanh toán và trong nội dung chuyển khoản)

Secret tự đọc từ app/src/main/java/com/vila/chess/billing/BillingCatalog.kt (ManualPay.LICENSE_SECRET).
"""
import argparse, datetime, hashlib, hmac, os, re, sys

TIERS = {"gold": 1, "platinum": 2, "diamond": 3}
PERIODS = {"monthly": 0, "yearly": 1}
BASE = datetime.date(2024, 1, 1)


def read_secret():
    here = os.path.dirname(os.path.abspath(__file__))
    f = os.path.join(here, "..", "app", "src", "main", "java", "com", "vila", "chess", "billing", "BillingCatalog.kt")
    m = re.search(r'LICENSE_SECRET:\s*String\s*=\s*"([^"]+)"', open(f, encoding="utf-8").read())
    if not m:
        sys.exit("Không tìm thấy LICENSE_SECRET trong BillingCatalog.kt")
    return m.group(1)


def make_code(secret, device_hex, tier, period, day=None):
    day = ((datetime.date.today() - BASE).days) if day is None else day
    dev = bytes.fromhex(device_hex)
    if len(dev) != 4:
        sys.exit("Mã thiết bị phải là 8 ký tự hex")
    payload = bytes([(TIERS[tier] << 4) | PERIODS[period], (day >> 8) & 0xFF, day & 0xFF]) + dev
    sig = hmac.new(secret.encode(), payload, hashlib.sha256).digest()[:5]
    h = (payload + sig).hex().upper()
    return "-".join(h[i:i + 6] for i in range(0, 24, 6))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--device", required=True, help="mã thiết bị 8 ký tự hex của người dùng")
    ap.add_argument("--tier", required=True, choices=TIERS)
    ap.add_argument("--period", required=True, choices=PERIODS)
    a = ap.parse_args()
    print(make_code(read_secret(), a.device.strip().upper(), a.tier, a.period))
