-- Chạy 1 lần trong Supabase: SQL Editor -> New query -> dán -> Run.
-- Mỗi tài khoản chỉ thấy/ghi được dòng của chính mình (RLS theo auth.uid()).

create table if not exists public.game_reviews (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  game_id    text not null,
  review     jsonb not null,
  created_at timestamptz not null default now(),
  primary key (user_id, game_id)
);

alter table public.game_reviews enable row level security;

drop policy if exists "reviews_select_own" on public.game_reviews;
drop policy if exists "reviews_insert_own" on public.game_reviews;
drop policy if exists "reviews_update_own" on public.game_reviews;
drop policy if exists "reviews_delete_own" on public.game_reviews;

create policy "reviews_select_own" on public.game_reviews for select to authenticated using (auth.uid() = user_id);
create policy "reviews_insert_own" on public.game_reviews for insert to authenticated with check (auth.uid() = user_id);
create policy "reviews_update_own" on public.game_reviews for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "reviews_delete_own" on public.game_reviews for delete to authenticated using (auth.uid() = user_id);

create index if not exists game_reviews_user_created on public.game_reviews (user_id, created_at desc);

-- =============================================================================
-- HỆ THỐNG HỒ SƠ (Profile) + BẠN BÈ — chạy thêm 1 lần trong SQL Editor
-- Lưu ý bảo mật: users.tier / Elo do CLIENT tự ghi (chưa có server xác thực ván). Chỉ dùng để HIỂN THỊ huy hiệu & số liệu;
-- quyền lợi thật (Feature/Quota) luôn lấy từ Google Play / mã kích hoạt, KHÔNG đọc từ bảng này.
-- Muốn chống giả mạo huy hiệu: thu hồi quyền cập nhật cột tier của role authenticated và cho server xác thực biên lai ghi bằng service_role.
-- =============================================================================
create table if not exists public.users (
  id            uuid primary key references auth.users(id) on delete cascade,
  display_name  text not null default 'Người chơi' check (char_length(display_name) between 1 and 30),
  avatar_key    text not null default '',
  country_code  text not null default '' check (country_code = '' or country_code ~ '^[A-Z]{2}$'),
  tier          text not null default 'free' check (tier in ('free','gold','platinum','diamond')),
  bullet_elo    int  not null default 800,
  blitz_elo     int  not null default 800,
  rapid_elo     int  not null default 800,
  games_played  int  not null default 0,
  wins          int  not null default 0,
  draws         int  not null default 0,
  losses        int  not null default 0,
  result_streak int  not null default 0,
  elo_history   jsonb,
  created_at    timestamptz not null default now()
);
alter table public.users enable row level security;
drop policy if exists "users_select_all" on public.users;
drop policy if exists "users_insert_own" on public.users;
drop policy if exists "users_update_own" on public.users;
create policy "users_select_all" on public.users for select to authenticated using (true);
create policy "users_insert_own" on public.users for insert to authenticated with check (auth.uid() = id);
create policy "users_update_own" on public.users for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create table if not exists public.friendships (
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  friend_id  uuid not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, friend_id),
  check (user_id <> friend_id)
);
alter table public.friendships enable row level security;
drop policy if exists "friends_select_own" on public.friendships;
drop policy if exists "friends_insert_own" on public.friendships;
drop policy if exists "friends_delete_own" on public.friendships;
create policy "friends_select_own" on public.friendships for select to authenticated using (auth.uid() = user_id);
create policy "friends_insert_own" on public.friendships for insert to authenticated with check (auth.uid() = user_id);
create policy "friends_delete_own" on public.friendships for delete to authenticated using (auth.uid() = user_id);
create index if not exists friendships_user on public.friendships (user_id, created_at desc);
