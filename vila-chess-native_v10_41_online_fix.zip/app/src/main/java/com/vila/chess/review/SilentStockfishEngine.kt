package com.vila.chess.review

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * scoreCp/mate/secondCp/secondMate luôn tính theo góc nhìn BÊN ĐANG ĐI của FEN được phân tích.
 * pv = PV đầu tiên (UCI). second* chỉ có khi engine chạy MultiPV >= 2 và thế có từ 2 nước hợp lệ trở lên.
 * engine = "native" | "wasm" | "rules" (thế kết thúc ván, không cần engine).
 */
data class EngineResult(
    val bestMove: String?,
    val scoreCp: Int,
    val mate: Int?,
    val depthReached: Int,
    val timedOut: Boolean,
    val pv: List<String> = emptyList(),
    val secondMove: String? = null,
    val secondCp: Int? = null,
    val secondMate: Int? = null,
    val engine: String = "unknown",
    val multiPv: Int = 1,
)

/**
 * Engine không giao diện, hai backend theo thứ tự ưu tiên:
 *  1. NATIVE: libstockfish.so (Stockfish bản đầy đủ) chạy bằng ProcessBuilder từ nativeLibraryDir.
 *  2. WASM:   Stockfish 19 lite trong WebView ẩn (dự phòng khi không có/không chạy được bản native).
 * close() giải phóng hoàn toàn (stop -> quit -> destroy); analyze sau đó tự khởi động lại.
 */
class SilentStockfishEngine(
    context: Context,
    private val config: EngineConfig,
) : AutoCloseable {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()
    private var transport: Transport? = null
    private var lines: Channel<String> = Channel(Channel.UNLIMITED)

    /** "native", "wasm" hoặc "none": để log/gỡ lỗi. */
    @Volatile var backendName: String = "none"
        private set

    /** MultiPV đang dùng: native = 2 (để có nước tốt nhì cho Great/Miss), wasm = 1 (tắt). */
    @Volatile var multiPv: Int = 1
        private set

    private companion object {
        const val HOST = "appassets.androidplatform.net"
        const val BASE = "https://$HOST/assets/stockfish/"
        const val MAX_WASM_HASH_MB = 32
        val SCORE = Regex("""\bscore (cp|mate) (-?\d+)""")
        val DEPTH = Regex("""\bdepth (\d+)""")
        val BEST = Regex("""^bestmove (\S+)""")
        val MULTIPV = Regex("""\bmultipv (\d+)""")
        val PV = Regex(""" pv (.+)$""")
        const val NATIVE_MULTIPV = 2
        const val TAG = "GameReview"
        /** Native: thoát hẳn tiến trình sau mỗi chừng này lượt để không tích RAM. */
        const val RECYCLE_NATIVE_EVERY = 8
        /** Chờ thêm ngoài movetime (khởi động search / tiến trình chậm) trước khi ép stop. */
        const val GRACE_MS = 2_000L
        const val STOP_WAIT_MS = 3_000L
    }

    /** Đã thử native nhưng không ra kết quả -> các lần sau đi thẳng wasm. */
    @Volatile private var skipNative = false
    private var searches = 0

    // ---------- Transport ----------

    private abstract class Transport(val ch: Channel<String>, val isNative: Boolean) {
        abstract fun send(cmd: String)
        abstract fun close()
    }

    private class NativeTransport(ch: Channel<String>, private val process: Process) :
        Transport(ch, true) {
        private val writer: BufferedWriter = process.outputStream.bufferedWriter()

        init {
            Thread {
                try {
                    process.inputStream.bufferedReader().forEachLine { ch.trySend(it) }
                } catch (_: IOException) {
                } finally {
                    ch.close()
                }
            }.apply { isDaemon = true }.start()
        }

        @Synchronized
        override fun send(cmd: String) {
            runCatching { writer.write(cmd); writer.newLine(); writer.flush() }
        }

        override fun close() {
            send("stop"); send("quit")
            runCatching {
                if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroy()
                process.destroy()
                if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroyForcibly()
            }
            runCatching { writer.close() }
        }
    }

    private class WebTransport(
        ch: Channel<String>,
        val view: WebView,
        private val main: Handler,
    ) : Transport(ch, false) {
        override fun send(cmd: String) {
            val js = "send(" + JSONObject.quote(cmd) + ");"
            main.post { view.evaluateJavascript(js, null) }
        }

        override fun close() {
            main.post {
                view.evaluateJavascript("try{send('stop');send('quit');}catch(e){}", null)
                main.postDelayed({
                    view.loadUrl("about:blank")
                    view.removeJavascriptInterface("Bridge")
                    view.destroy()
                }, 300)
            }
        }
    }

    private inner class Bridge(private val ch: Channel<String>) {
        @JavascriptInterface
        fun line(s: String) { ch.trySend(s) }
    }

    private suspend fun createNative(): Transport? = withContext(Dispatchers.IO) {
        val bin = File(app.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!bin.exists()) return@withContext null
        try {
            val p = ProcessBuilder(bin.absolutePath).redirectErrorStream(true).start()
            NativeTransport(Channel(Channel.UNLIMITED), p)
        } catch (_: Exception) {
            null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun createWeb(): Transport? = withContext(Dispatchers.Main) {
        try {
            val ch = Channel<String>(Channel.UNLIMITED)
            val wv = WebView(app)
            wv.settings.javaScriptEnabled = true
            wv.settings.allowFileAccess = false
            wv.settings.allowContentAccess = false
            wv.addJavascriptInterface(Bridge(ch), "Bridge")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView, request: WebResourceRequest,
                ): WebResourceResponse? {
                    val u = request.url
                    if (u.host != HOST) return null
                    val name = u.lastPathSegment ?: return null
                    val mime = when {
                        name.endsWith(".html") -> "text/html"
                        name.endsWith(".js") -> "text/javascript"
                        name.endsWith(".wasm") -> "application/wasm"
                        else -> "application/octet-stream"
                    }
                    return try {
                        WebResourceResponse(mime, "utf-8", app.assets.open("stockfish/$name"))
                    } catch (_: IOException) {
                        WebResourceResponse(null, null, 404, "Not Found", emptyMap(), null)
                    }
                }
            }
            wv.onResume()
            wv.resumeTimers()
            wv.loadUrl(BASE + "engine.html")
            WebTransport(ch, wv, main)
        } catch (_: Exception) {
            null
        }
    }

    // ---------- Khởi động ----------

    private suspend fun ensureStarted() {
        if (transport != null) return
        val candidates: List<suspend () -> Transport?> =
            if (skipNative) listOf(::createWeb) else listOf(::createNative, ::createWeb)
        for (create in candidates) {
            val t = create() ?: continue
            transport = t
            lines = t.ch
            if (handshake(t)) {
                backendName = if (t.isNative) "native" else "wasm"
                multiPv = if (t.isNative) NATIVE_MULTIPV else 1
                searches = 0
                Log.i(TAG, "Engine khởi động: $backendName")
                return
            }
            t.close()
            transport = null
        }
        backendName = "none"
        Log.e(TAG, "Lỗi phân tích: không khởi động được engine nào (native lẫn wasm)")
        error("Không khởi động được engine nào (native lẫn wasm)")
    }

    private suspend fun handshake(t: Transport): Boolean {
        if (!t.isNative && !waitFor("info string page-ready", 15_000)) return false
        t.send("uci")
        if (!waitFor("uciok", if (t.isNative) 10_000 else 30_000)) return false
        if (t.isNative) {
            nnuePath()?.let { t.send("setoption name EvalFile value $it") }
            t.send("setoption name Threads value ${config.threads}")
            t.send("setoption name Hash value ${config.hashMb}")
            t.send("setoption name MultiPV value $NATIVE_MULTIPV")
        } else {
            // Wasm không có đơn luồng đa nhân và bộ nhớ chặt: giữ Hash nhỏ.
            t.send("setoption name Hash value ${minOf(config.hashMb, MAX_WASM_HASH_MB)}")
            t.send("setoption name MultiPV value 1") // wasm: tắt MultiPV, không có Great/Miss
        }
        t.send("ucinewgame")
        t.send("isready")
        return waitFor("readyok", 15_000)
    }

    /**
     * Stockfish bản mới nhúng sẵn NNUE trong file .so. Nếu app có kèm file .nnue trong assets/stockfish/
     * (bản cũ cần EvalFile) thì chép ra filesDir và trả đường dẫn để nạp; không có thì null.
     */
    private fun nnuePath(): String? = runCatching {
        val name = app.assets.list("stockfish")?.firstOrNull { it.endsWith(".nnue", ignoreCase = true) }
            ?: return@runCatching null
        val dir = File(app.filesDir, "stockfish").apply { mkdirs() }
        val out = File(dir, name)
        if (!out.exists() || out.length() == 0L) {
            app.assets.open("stockfish/$name").use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        }
        out.absolutePath
    }.onFailure { Log.e(TAG, "Lỗi phân tích: không nạp được file .nnue: ${it.message}") }.getOrNull()

    private fun send(cmd: String) { transport?.send(cmd) }

    private suspend fun waitFor(prefix: String, timeoutMs: Long): Boolean =
        withTimeoutOrNull(timeoutMs) {
            var found = false
            while (!found) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith(prefix)) found = true
            }
            found
        } ?: false

    // ---------- Phân tích ----------

    /** Một dòng phân tích (multipv 1 hoặc 2), điểm theo góc nhìn bên đang đi. */
    private class Line {
        var seen = false
        var cp = 0
        var mate: Int? = null
        var depth = 0
        var pv: List<String> = emptyList()
    }

    private class Acc {
        val lines = arrayOf(Line(), Line())
        var best: String? = null
    }

    private fun parse(line: String, acc: Acc): Boolean {
        BEST.find(line)?.let {
            acc.best = it.groupValues[1].takeIf { m -> m != "(none)" }
            return true
        }
        if (!line.startsWith("info") || " lowerbound" in line || " upperbound" in line) return false
        val m = SCORE.find(line) ?: return false
        val idx = (MULTIPV.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 1) - 1
        if (idx !in 0..1) return false
        val l = acc.lines[idx]
        l.seen = true
        val v = m.groupValues[2].toInt()
        if (m.groupValues[1] == "mate") {
            l.mate = v
            l.cp = if (v > 0) 10_000 - minOf(v, 99) * 10 else -10_000 + minOf(-v, 99) * 10
        } else {
            l.mate = null
            l.cp = v
        }
        DEPTH.find(line)?.let { d -> l.depth = d.groupValues[1].toInt() }
        PV.find(line)?.let { p -> l.pv = p.groupValues[1].trim().split(' ').filter { it.isNotEmpty() } }
        return false
    }

    /**
     * Phân tích 1 thế cờ: `position fen <fen>` rồi `go depth D movetime T` (engine tự dừng ở mốc nào tới trước).
     * Quá hạn -> `stop`. Engine im lặng/chết -> dựng lại tiến trình (native hỏng thì chuyển sang wasm);
     * vẫn không có kết quả thì ném IllegalStateException (KHÔNG trả điểm 0 giả làm review trông như "không phân tích").
     */
    suspend fun analyzeSilently(fen: String, depth: Int = config.depth): EngineResult =
        mutex.withLock {
            var lastError: Throwable? = null
            for (attempt in 0..1) {
                try {
                    if (backendName == "native" && searches >= RECYCLE_NATIVE_EVERY) {
                        Log.i(TAG, "Giải phóng engine native sau $searches lượt (stop -> quit)")
                        close()
                    }
                    ensureStarted()
                    searches++
                    val r = searchOnce(fen, depth)
                    if (r != null) return@withLock r
                    Log.e(TAG, "Lỗi phân tích: engine ($backendName) không trả kết quả cho FEN $fen")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastError = e
                    Log.e(TAG, "Lỗi phân tích: ${e.message}", e)
                }
                // Hỏng giữa chừng: bỏ native (nếu đang dùng) và dựng lại.
                if (backendName == "native") skipNative = true
                close()
            }
            throw IllegalStateException("Engine không trả về kết quả phân tích", lastError)
        }

    /** null = engine không cho ra dữ liệu nào dùng được. */
    private suspend fun searchOnce(fen: String, depth: Int): EngineResult? {
        val native = transport?.isNative == true
        val backend = backendName
        val mpv = multiPv
        val moveTime = if (native) config.moveTimeoutMs else config.moveTimeoutMs * 2
        while (lines.tryReceive().isSuccess) { /* xả dòng cũ */ }
        send("position fen $fen")
        send("go depth $depth movetime $moveTime")

        val acc = Acc()
        var closed = false
        val done = withTimeoutOrNull(moveTime + GRACE_MS) {
            var finished = false
            while (!finished) {
                val l = lines.receiveCatching().getOrNull()
                if (l == null) { closed = true; break }
                finished = parse(l, acc)
            }
            finished
        } ?: false

        var timedOut = false
        if (!done) {
            timedOut = true
            if (closed) return null
            send("stop")
            val gotBest = withTimeoutOrNull(STOP_WAIT_MS) {
                var finished = false
                while (!finished) {
                    val l = lines.receiveCatching().getOrNull() ?: break
                    finished = parse(l, acc)
                }
                finished
            } ?: false
            // bestmove đến muộn sẽ lọt sang thế sau và làm lệch kết quả: dựng lại tiến trình.
            if (!gotBest) { close() }
        }
        val first = acc.lines[0]
        if (!first.seen && acc.best == null) return null
        val second = acc.lines[1].takeIf { mpv >= 2 && it.seen && it.pv.isNotEmpty() }
        return EngineResult(
            bestMove = acc.best ?: first.pv.firstOrNull(),
            scoreCp = first.cp,
            mate = first.mate,
            depthReached = first.depth,
            timedOut = timedOut,
            pv = first.pv,
            secondMove = second?.pv?.firstOrNull(),
            secondCp = second?.cp,
            secondMate = second?.mate,
            engine = backend,
            multiPv = mpv,
        )
    }

    /** Dừng search đang chạy (vô hại nếu engine đang rảnh). */
    fun stopSearch() = send("stop")

    override fun close() {
        val t = transport ?: return
        transport = null
        backendName = "none"
        multiPv = 1
        runCatching { t.close() }
        lines.close()
    }

    fun shutdown() = close()
}
