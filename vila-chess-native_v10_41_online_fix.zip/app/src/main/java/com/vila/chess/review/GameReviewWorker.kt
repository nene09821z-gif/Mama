package com.vila.chess.review

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class GameReviewWorker(
    ctx: Context,
    params: WorkerParameters,
) : CoroutineWorker(ctx, params) {

    companion object {
        private const val KEY_GAME_ID = "gameId"
        const val KEY_DONE = "done"
        const val KEY_TOTAL = "total"
        /** Tên work duy nhất của một ván: GameReviewViewModel quan sát bằng tên này. */
        fun uniqueName(gameId: String) = "game_review_$gameId"

        private fun queueFile(context: Context, gameId: String) =
            File(File(context.filesDir, "review_queue").apply { mkdirs() }, "$gameId.txt")

        /** Xóa file hàng đợi của một ván (khi màn Review đã tự phân tích xong, Worker không cần chạy nữa). */
        fun discardQueue(context: Context, gameId: String) {
            runCatching { queueFile(context.applicationContext, gameId).delete() }
        }

        /**
         * Gọi khi ván kết thúc. FEN đầu ván + các nước UCI được ghi ra file thay vì nhét vào inputData
         * vì Data của WorkManager giới hạn 10KB — ván dài sẽ crash. Worker tự dựng lại FEN/SAN từng nước.
         *
         * KHÔNG gọi setExpedited(): không có hàm "setExpedited(false)", cách tắt là không gọi nó,
         * nên work chạy ở mức ưu tiên thường, nhường tài nguyên cho app đang mở.
         */
        fun enqueueAnalysis(context: Context, gameId: String, startFen: String, ucis: List<String>) {
            val app = context.applicationContext
            val qf = queueFile(app, gameId)
            val tmp = File(qf.parentFile, qf.name + ".tmp")
            tmp.writeText(ReviewReplay.encodeQueue(startFen, ucis))
            if (!tmp.renameTo(qf)) { qf.delete(); tmp.renameTo(qf) }

            // WorkManager chỉ có AND giữa các constraint. "BatteryNotLow" (mức hệ thống ~15%)
            // tự được bỏ qua khi đang sạc, nên tương đương "đang sạc HOẶC pin > 15%".
            val constraints = Constraints.Builder().setRequiresBatteryNotLow(true).build()

            val req = OneTimeWorkRequestBuilder<GameReviewWorker>()
                .setInputData(workDataOf(KEY_GAME_ID to gameId))
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(app)
                .enqueueUniqueWork(uniqueName(gameId), ExistingWorkPolicy.KEEP, req)
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.Default) {
        val gameId = inputData.getString(KEY_GAME_ID) ?: return@withContext Result.failure()
        val store = GameReviewStore(applicationContext)
        // load() tự xóa file rác (engine từng hỏng) nên ván đó sẽ được phân tích lại.
        if (store.load(gameId) != null) return@withContext Result.success()

        val qf = queueFile(applicationContext, gameId)
        if (!qf.exists()) return@withContext Result.failure()
        val replay = ReviewReplay.parseQueue(qf.readLines())
        if (replay == null) { qf.delete(); return@withContext Result.failure() }
        if (replay.plies.isEmpty()) { qf.delete(); return@withContext Result.success() }
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }

        val config = DeviceTierManager.getDeviceTier(applicationContext)
        val monitor = DeviceHealthMonitor(applicationContext)
        val engine = SilentStockfishEngine(applicationContext, config)

        try {
            val evals = ArrayList<EngineResult>(fens.size)

            for ((i, fen) in fens.withIndex()) {
                ensureActive()
                setProgress(workDataOf(KEY_DONE to i, KEY_TOTAL to fens.size))
                // Thế đã hết ván (chiếu hết/hòa) tính bằng luật cờ, không cần engine.
                val terminal = ReviewReplay.terminalEval(fen)
                if (terminal != null) { evals += terminal; continue }

                // Nóng > 40°C: stop + giải phóng engine, chờ 1 phút/lượt. Quá 5 lượt -> retry sau.
                val cool = monitor.awaitCoolDown(onHot = { engine.stopSearch(); engine.close() })
                if (!cool) return@withContext Result.retry()

                evals += engine.analyzeSilently(fen, config.depth)
            }

            val review = ReviewAssembler.assemble(
                gameId, replay.startFen, replay.plies, evals,
                config.tier.name, System.currentTimeMillis(),
            )
            store.save(review)
            qf.delete()
            com.vila.chess.cloud.SupabaseCloud.pushReview(applicationContext, review)   // không ném lỗi
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: IllegalStateException) {
            // Engine không khởi động / không trả kết quả: retry vô ích.
            Log.e("GameReview", "Lỗi phân tích: ${e.message}", e)
            Result.failure()
        } catch (e: Throwable) {
            // Mọi lỗi khác (parse, OOM, IO...) chỉ được log, không làm văng app.
            Log.e("GameReview", "Lỗi phân tích: ${e.message}", e)
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        } finally {
            engine.shutdown() // stop -> quit -> destroy
        }
    }
}
