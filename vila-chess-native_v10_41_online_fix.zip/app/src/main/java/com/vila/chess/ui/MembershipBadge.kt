package com.vila.chess.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vila.chess.billing.MembershipTier
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

// =============================================================================
// Huy hiệu thành viên (VIP). Vẽ bằng Canvas — không cần ảnh/icon ngoài, sắc nét ở mọi kích thước.
//   FREE     → không hiển thị
//   GOLD     → ngôi sao vàng
//   PLATINUM → vương miện bạc
//   DIAMOND  → kim cương xanh lam, có hiệu ứng lấp lánh
// =============================================================================

object BadgeColors {
    val GoldLight = Color(0xFFFFE27A)
    val GoldDark = Color(0xFFF5A800)
    val SilverLight = Color(0xFFFFFFFF)
    val SilverDark = Color(0xFF9AA7B5)
    val DiamondLight = Color(0xFF8FE3FF)
    val DiamondDark = Color(0xFF1E88E5)
}

/** Dạng nhận tên gói dạng chuỗi ("free" | "gold" | "platinum" | "diamond", không phân biệt hoa thường). Chuỗi lạ → không hiện. */
@Composable
fun MembershipBadge(tier: String, modifier: Modifier = Modifier, size: Dp = 18.dp) {
    MembershipBadge(MembershipTier.fromId(tier.trim().lowercase()), modifier, size)
}

@Composable
fun MembershipBadge(tier: MembershipTier, modifier: Modifier = Modifier, size: Dp = 18.dp) {
    val desc = "Thành viên " + tier.displayName
    val m = modifier.size(size).semantics { contentDescription = desc }
    when (tier) {
        MembershipTier.FREE -> Unit                      // FREE: không hiển thị gì (kể cả khoảng trống)
        MembershipTier.GOLD -> StarBadge(m)
        MembershipTier.PLATINUM -> CrownBadge(m)
        MembershipTier.DIAMOND -> DiamondBadge(m)
    }
}

// ------------------------------------------------------------------ Gold: ngôi sao

@Composable
private fun StarBadge(modifier: Modifier) {
    Canvas(modifier) {
        val path = Path()
        val cx = size.width / 2f
        val cy = size.height * 0.53f
        val outer = size.minDimension * 0.48f
        val inner = outer * 0.42f
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -PI / 2 + i * PI / 5
            val p = Offset(cx + (r * kotlin.math.cos(a)).toFloat(), cy + (r * sin(a)).toFloat())
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        path.close()
        drawPath(path, Brush.verticalGradient(listOf(BadgeColors.GoldLight, BadgeColors.GoldDark)))
        drawPath(path, BadgeColors.GoldDark.copy(alpha = 0.9f), style = Stroke(width = size.minDimension * 0.05f))
    }
}

// ------------------------------------------------------------------ Platinum: vương miện bạc

@Composable
private fun CrownBadge(modifier: Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val crown = Path().apply {
            moveTo(w * 0.08f, h * 0.78f)
            lineTo(w * 0.08f, h * 0.30f)
            lineTo(w * 0.30f, h * 0.52f)
            lineTo(w * 0.50f, h * 0.18f)
            lineTo(w * 0.70f, h * 0.52f)
            lineTo(w * 0.92f, h * 0.30f)
            lineTo(w * 0.92f, h * 0.78f)
            close()
        }
        val silver = Brush.verticalGradient(listOf(BadgeColors.SilverLight, BadgeColors.SilverDark))
        drawPath(crown, silver)
        drawPath(crown, BadgeColors.SilverDark, style = Stroke(width = w * 0.05f))
        // Dải đế + ba viên ngọc trên đỉnh
        drawRect(BadgeColors.SilverDark, topLeft = Offset(w * 0.08f, h * 0.78f), size = androidx.compose.ui.geometry.Size(w * 0.84f, h * 0.10f))
        val gem = Color(0xFF5B6B7B)
        drawCircle(gem, radius = w * 0.06f, center = Offset(w * 0.08f, h * 0.28f))
        drawCircle(gem, radius = w * 0.07f, center = Offset(w * 0.50f, h * 0.16f))
        drawCircle(gem, radius = w * 0.06f, center = Offset(w * 0.92f, h * 0.28f))
    }
}

// ------------------------------------------------------------------ Diamond: kim cương lấp lánh

@Composable
private fun DiamondBadge(modifier: Modifier) {
    // MỘT transition duy nhất (0→1, lặp). Giá trị chỉ được đọc trong khối vẽ ⇒ chỉ vẽ lại, không recompose.
    val transition = rememberInfiniteTransition(label = "diamondShine")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "shine",
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun p(x: Float, y: Float) = Offset(w * x, h * y)

        val gem = Path().apply {
            moveTo(w * 0.24f, h * 0.20f); lineTo(w * 0.76f, h * 0.20f)
            lineTo(w * 0.94f, h * 0.42f); lineTo(w * 0.50f, h * 0.90f); lineTo(w * 0.06f, h * 0.42f)
            close()
        }
        drawPath(gem, Brush.linearGradient(listOf(BadgeColors.DiamondLight, BadgeColors.DiamondDark), p(0.1f, 0.1f), p(0.9f, 0.95f)))

        // Mặt cắt (đường sáng mờ)
        val facet = Color.White.copy(alpha = 0.55f)
        val sw = w * 0.035f
        drawLine(facet, p(0.06f, 0.42f), p(0.94f, 0.42f), strokeWidth = sw)
        drawLine(facet, p(0.24f, 0.20f), p(0.36f, 0.42f), strokeWidth = sw)
        drawLine(facet, p(0.76f, 0.20f), p(0.64f, 0.42f), strokeWidth = sw)
        drawLine(facet, p(0.36f, 0.42f), p(0.50f, 0.90f), strokeWidth = sw)
        drawLine(facet, p(0.64f, 0.42f), p(0.50f, 0.90f), strokeWidth = sw)
        drawLine(facet, p(0.36f, 0.42f), p(0.50f, 0.20f), strokeWidth = sw)
        drawLine(facet, p(0.64f, 0.42f), p(0.50f, 0.20f), strokeWidth = sw)
        drawPath(gem, Color(0xFF0D47A1).copy(alpha = 0.75f), style = Stroke(width = w * 0.045f))

        // Vệt sáng quét chéo qua viên kim cương (cắt theo hình viên ngọc)
        val bandX = w * (-0.5f + 2.0f * t)
        clipPath(gem) {
            drawRect(
                brush = Brush.linearGradient(
                    colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.85f), Color.Transparent),
                    start = Offset(bandX, 0f),
                    end = Offset(bandX + w * 0.45f, h * 0.45f),
                ),
            )
        }

        // Hai ngôi sao lấp lánh nhấp nháy lệch pha ở góc
        sparkle(Offset(w * 0.90f, h * 0.12f), w * 0.17f, twinkle(t, 0.0f))
        sparkle(Offset(w * 0.10f, h * 0.60f), w * 0.12f, twinkle(t, 0.5f))
    }
}

/** 0→1→0 theo chu kỳ, lệch pha [phase]. */
private fun twinkle(t: Float, phase: Float): Float = abs(sin(((t + phase) % 1f) * PI)).toFloat()

/** Ngôi sao bốn cánh, bán kính [r] nhân [scale] (0 = ẩn). */
private fun DrawScope.sparkle(c: Offset, r: Float, scale: Float) {
    if (scale <= 0.02f) return
    val rr = r * scale
    val path = Path().apply {
        moveTo(c.x, c.y - rr)
        quadraticTo(c.x, c.y, c.x + rr, c.y)
        quadraticTo(c.x, c.y, c.x, c.y + rr)
        quadraticTo(c.x, c.y, c.x - rr, c.y)
        quadraticTo(c.x, c.y, c.x, c.y - rr)
        close()
    }
    drawPath(path, Color.White.copy(alpha = 0.55f + 0.45f * scale))
}
