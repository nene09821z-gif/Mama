package com.vila.chess.review

import android.content.Context
import java.io.File
import kotlin.math.exp

object ReviewClassifier {
    /** Công thức win% từ centipawn (góc nhìn bên đang xét): WP = 50 + 50 * (2 / (1 + e^(-0.00368208 * cp)) - 1). */
    fun winPct(cp: Int): Double = 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * cp)) - 1.0)

    /**
     * Win% có xét mate (không dùng cp khi engine báo mate). Cùng góc nhìn với [cp]/[mate]:
     * mate > 0 = bên xét sắp chiếu hết (100%), mate < 0 = sắp bị chiếu hết (0%),
     * mate == 0 = thế đã bị chiếu hết, bên thắng là bên có cp dương.
     */
    fun winPct(cp: Int, mate: Int?): Double = when {
        mate == null -> winPct(cp)
        mate > 0 -> 100.0
        mate < 0 -> 0.0
        else -> if (cp >= 0) 100.0 else 0.0
    }

    /** File review lưu từ lần engine hỏng (mọi thế depth 0, điểm 0) là rác: phải phân tích lại. */
    fun isUsable(r: GameReview): Boolean =
        r.moves.isEmpty() || r.moves.any { it.depthBefore > 0 || it.depthAfter > 0 || it.mateBeforeWhite != null }

    // Ngưỡng là giả định của mình — chỉnh lại theo mức bạn đã bàn.
    fun classify(loss: Double): MoveLabel = when {
        loss <= 2.0 -> MoveLabel.BEST
        loss <= 5.0 -> MoveLabel.EXCELLENT
        loss <= 10.0 -> MoveLabel.GOOD
        loss <= 20.0 -> MoveLabel.INACCURACY
        loss <= 30.0 -> MoveLabel.MISTAKE
        else -> MoveLabel.BLUNDER
    }

    fun moveAccuracy(loss: Double): Double =
        (103.1668 * exp(-0.04354 * loss) - 3.1669).coerceIn(0.0, 100.0)
}

class GameReviewStore(context: Context) {
    private val dir = File(context.filesDir, "reviews").apply { mkdirs() }
    private fun file(id: String) = File(dir, "${id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }}.json")

    fun exists(gameId: String) = file(gameId).exists()

    fun delete(gameId: String) { runCatching { file(gameId).delete() } }

    fun save(r: GameReview) {
        // Ghi tạm rồi đổi tên: không bao giờ để file review dở dang.
        val target = file(r.gameId)
        val tmp = File(dir, target.name + ".tmp")
        tmp.writeText(ReviewJson.encode(r))
        if (!tmp.renameTo(target)) { target.delete(); tmp.renameTo(target) }
    }

    /** null = chưa có (chưa phân tích xong) hoặc file hỏng. Đọc được cả file phiên bản 1. */
    fun load(gameId: String): GameReview? {
        val f = file(gameId)
        if (!f.exists()) return null
        val r = runCatching { ReviewJson.decode(f.readText()) }.getOrNull()
        if (r == null || !ReviewClassifier.isUsable(r)) { f.delete(); return null }
        return r
    }
}
