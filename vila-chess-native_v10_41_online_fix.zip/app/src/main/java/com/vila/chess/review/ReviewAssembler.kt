package com.vila.chess.review

import com.vila.chess.core.Position
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveUci

/** Một nước đi đã dựng lại từ ván: UCI, SAN và FEN trước/sau. */
data class ReplayPly(val uci: String, val san: String, val fenBefore: String, val fenAfter: String)

data class ReplayResult(val startFen: String, val plies: List<ReplayPly>)

/** Hàm thuần (không Android, không engine): dựng lại ván và ráp dữ liệu review. */
object ReviewReplay {
    const val QUEUE_HEADER = "#v2"

    /** File hàng đợi: dòng 1 = "#v2", dòng 2 = FEN đầu ván, các dòng sau = nước đi UCI. */
    fun encodeQueue(startFen: String, ucis: List<String>): String =
        (listOf(QUEUE_HEADER, startFen) + ucis).joinToString("\n")

    /** Đọc file hàng đợi. Cũng đọc được định dạng cũ (mỗi dòng là một FEN). null nếu hỏng. */
    fun parseQueue(rawLines: List<String>): ReplayResult? {
        val lines = rawLines.map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        return runCatching {
            if (lines[0] == QUEUE_HEADER) {
                if (lines.size < 2) null else replay(lines[1], lines.drop(2))
            } else {
                replayFromFens(lines)
            }
        }.getOrNull()
    }

    fun replay(startFen: String, ucis: List<String>): ReplayResult? {
        val pos = Position.fromFen(startFen)
        val start = pos.fen()
        val out = ArrayList<ReplayPly>(ucis.size)
        for (uci in ucis) {
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci } ?: return null
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    /** Định dạng hàng đợi cũ: tìm nước đi nối từng cặp FEN liên tiếp. */
    private fun replayFromFens(fens: List<String>): ReplayResult? {
        val pos = Position.fromFen(fens[0])
        val start = pos.fen()
        val out = ArrayList<ReplayPly>()
        for (i in 1 until fens.size) {
            val target = key(fens[i])
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { m ->
                pos.make(m)
                val hit = key(pos.fen()) == target
                pos.unmake()
                hit
            } ?: return null
            val uci = moveUci(mv)
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    private fun key(fen: String) = fen.trim().split(Regex("\\s+")).take(4).joinToString(" ")

    /**
     * Thế đã kết thúc ván (chiếu hết, hết nước đi = hòa, không đủ quân chiếu) thì tính bằng luật cờ,
     * không hỏi engine. Điểm theo góc nhìn bên đang đi. Chiếu hết: mate = 0, cp = -10000.
     */
    fun terminalEval(fen: String): EngineResult? {
        val pos = Position.fromFen(fen)
        return when {
            pos.legalMoves().isEmpty() ->
                if (pos.inCheck()) EngineResult(null, -10_000, 0, 0, false, engine = MoveReview.ENGINE_RULES)
                else EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            pos.insufficientMaterial() ->
                EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            else -> null
        }
    }
}

object ReviewAssembler {

    /**
     * evals[i] = kết quả phân tích thế SAU i nước (evals[0] = thế đầu ván), tức evals.size == plies.size + 1.
     * Điểm trong evals là góc nhìn bên đang đi; ở đây đổi hết sang góc nhìn Trắng.
     */
    fun assemble(
        gameId: String,
        startFen: String,
        plies: List<ReplayPly>,
        evals: List<EngineResult>,
        tier: String,
        createdAt: Long,
    ): GameReview {
        require(evals.size == plies.size + 1) { "evals phải nhiều hơn plies đúng 1 phần tử" }

        fun fenAt(i: Int) = if (i == 0) (plies.firstOrNull()?.fenBefore ?: startFen) else plies[i - 1].fenAfter
        fun whiteToMoveAt(i: Int) = fenAt(i).split(' ').getOrNull(1) != "b"

        val cpWhite = IntArray(evals.size) { i -> (if (whiteToMoveAt(i)) 1 else -1) * evals[i].scoreCp }
        val mateWhite = Array(evals.size) { i ->
            evals[i].mate?.let { m -> if (m == 0) 0 else (if (whiteToMoveAt(i)) m else -m) }
        }

        val moves = ArrayList<MoveReview>(plies.size)
        for (i in 1..plies.size) {
            val p = plies[i - 1]
            val before = evals[i - 1]
            val whiteMoved = whiteToMoveAt(i - 1)
            val sign = if (whiteMoved) 1 else -1
            // Góc nhìn BÊN VỪA ĐI: nhân sign cho cả cp lẫn mate (mate == 0 giữ nguyên, bên thắng suy từ dấu cp).
            fun moverWin(k: Int) = ReviewClassifier.winPct(
                sign * cpWhite[k],
                mateWhite[k]?.let { m -> if (m == 0) 0 else sign * m },
            )
            val winBefore = moverWin(i - 1)
            val winAfter = moverWin(i)
            val loss = (winBefore - winAfter).coerceAtLeast(0.0)
            moves += MoveReview(
                ply = i,
                whiteMoved = whiteMoved,
                label = ReviewClassifier.classify(loss),
                winLoss = loss,
                evalAfterCpWhite = cpWhite[i],
                bestMoveBefore = before.bestMove,
                uci = p.uci,
                san = p.san,
                fenBefore = p.fenBefore,
                fenAfter = p.fenAfter,
                evalBeforeCpWhite = cpWhite[i - 1],
                mateBeforeWhite = mateWhite[i - 1],
                mateAfterWhite = mateWhite[i],
                pv = before.pv,
                depthBefore = before.depthReached,
                depthAfter = evals[i].depthReached,
                secondBestMove = before.secondMove,
                secondBestCpWhite = before.secondCp?.let { sign * it },
                secondBestMateWhite = before.secondMate?.let { m -> if (m == 0) 0 else sign * m },
                engine = before.engine,
                multiPv = before.multiPv,
            )
        }

        fun acc(white: Boolean) = moves.filter { it.whiteMoved == white }
            .map { ReviewClassifier.moveAccuracy(it.winLoss) }
            .let { if (it.isEmpty()) 100.0 else it.average() }

        val main = evals.firstOrNull { it.engine != MoveReview.ENGINE_RULES }
        return GameReview(
            gameId = gameId,
            moves = moves,
            accuracyWhite = acc(true),
            accuracyBlack = acc(false),
            tier = tier,
            createdAt = createdAt,
            startFen = startFen,
            engine = main?.engine ?: "none",
            multiPv = main?.multiPv ?: 1,
        )
    }
}
