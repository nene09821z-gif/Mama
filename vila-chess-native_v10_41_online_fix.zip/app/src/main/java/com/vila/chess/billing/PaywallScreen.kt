package com.vila.chess.billing

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.ui.VilaColors
import java.text.NumberFormat
import java.util.Currency

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun accent(t: MembershipTier): Color = when (t) {
    MembershipTier.GOLD -> Color(0xFFF2B63D)
    MembershipTier.PLATINUM -> Color(0xFF9FB3C8)
    MembershipTier.DIAMOND -> Color(0xFF4FC3F7)
    MembershipTier.FREE -> VilaColors.Green
}

@Composable
fun PaywallScreen(onBack: () -> Unit, vm: PaywallViewModel = viewModel()) {
    val state by vm.ui.collectAsState()
    val ctx = LocalContext.current
    // null = đóng; Pair(gói, null-gói = chỉ nhập mã)
    var manual by remember { mutableStateOf<Pair<MembershipTier?, Boolean>?>(null) }
    var adminTaps by remember { mutableStateOf(0) }
    var showAdmin by remember { mutableStateOf(false) }
    if (showAdmin) AdminDialog(onDismiss = { showAdmin = false })
    manual?.let { (t, _) ->
        ManualPayDialog(tier = t, period = state.period, onDismiss = { manual = null }, onRedeem = vm::redeem)
    }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = Color.White)
            }
            Text(
                "Nâng cấp ChessPlus", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.clickable { adminTaps++; if (adminTaps >= 7) { adminTaps = 0; showAdmin = true } },   // bấm 7 lần → admin
            )
        }

        Column(
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            PeriodToggle(state.period, onChange = vm::setPeriod)

            state.error?.let { Banner(it.message(), isError = true, onClose = vm::dismissMessage) }
            state.notice?.let { Banner(it, isError = false, onClose = vm::dismissMessage) }

            when {
                state.isLoading -> Box(Modifier.fillMaxWidth().height(160.dp), Alignment.Center) {
                    CircularProgressIndicator(color = VilaColors.Green)
                }
                state.tiers.isEmpty() -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                    Button(onClick = vm::reload) { Text("Thử lại") }
                }
                else -> state.tiers.forEach { plans ->
                    TierCard(
                        plans = plans,
                        period = state.period,
                        isCurrent = plans.tier == state.currentTier,
                        isSelected = plans.tier == state.selected,
                        busy = state.isPurchasing,
                        onSelect = { vm.selectTier(plans.tier) },
                        onBuy = { ctx.findActivity()?.let { vm.purchase(it, plans.tier) } },
                        onManual = { manual = plans.tier to true },
                    )
                }
            }

            TextButton(onClick = { manual = null to false }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Nhập mã kích hoạt", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold)
            }
            TextButton(onClick = vm::restore, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Khôi phục giao dịch", color = Color(0xFFE3ECFA))
            }
            Text(
                "Thanh toán qua Google Play: tự động gia hạn cho đến khi bạn hủy (quản lý trong Google Play › Thanh toán & gói đăng ký). Thanh toán chuyển khoản: gói có thời hạn, không tự gia hạn.",
                color = VilaColors.TextDim, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            )
        }
    }
}

@Composable
private fun PeriodToggle(period: BillingPeriod, onChange: (BillingPeriod) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(VilaColors.PanelDark).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        listOf(BillingPeriod.MONTHLY to "Theo tháng", BillingPeriod.YEARLY to "Theo năm").forEach { (p, label) ->
            val on = p == period
            Box(
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (on) VilaColors.Green else Color.Transparent)
                    .clickable { onChange(p) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun Banner(text: String, isError: Boolean, onClose: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (isError) Color(0x33E05A47) else Color(0x3381B64C))
            .clickable(onClick = onClose).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun TierCard(
    plans: TierPlans,
    period: BillingPeriod,
    isCurrent: Boolean,
    isSelected: Boolean,
    busy: Boolean,
    onSelect: () -> Unit,
    onBuy: () -> Unit,
    onManual: () -> Unit,
) {
    val color = accent(plans.tier)
    val option = plans.option(period)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VilaColors.Glass),
        border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) color else VilaColors.GlassBorder),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    plans.tier.displayName, color = color, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
                )
                if (isCurrent) Text("Gói hiện tại", color = VilaColors.Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            val priceText = option?.formattedPrice ?: formatVnd(BillingCatalog.priceVnd(plans.tier, period))
            Text(
                priceText + if (period == BillingPeriod.MONTHLY) " / tháng" else " / năm",
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            )
            priceHint(plans, period)?.let { Text(it, color = VilaColors.TextDim, fontSize = 13.sp) }
            Spacer(Modifier.height(2.dp))
            TierInfo.highlights(plans.tier).forEach { line ->
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Check, null, tint = color, modifier = Modifier.size(18.dp))
                    Text(line, color = Color.White, fontSize = 14.sp)
                }
            }
            Button(
                onClick = { if (option != null) onBuy() else onManual() },
                enabled = !busy && !isCurrent,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = VilaColors.Green),
            ) {
                Text(if (isCurrent) "Đang sử dụng" else "Chọn gói", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
            if (option != null && !isCurrent) {
                TextButton(onClick = onManual, modifier = Modifier.fillMaxWidth()) {
                    Text("Hoặc thanh toán chuyển khoản", color = Color(0xFFE3ECFA), fontSize = 13.sp)
                }
            }
        }
    }
}

/** Gói năm: "≈ 41.667 ₫/tháng · tiết kiệm 17%". Gói tháng: không có dòng phụ. */
private fun priceHint(plans: TierPlans, period: BillingPeriod): String? {
    if (period != BillingPeriod.YEARLY) return null
    val y = plans.yearly ?: return staticHint(plans.tier)
    return try {
        val fmt = NumberFormat.getCurrencyInstance().apply { currency = Currency.getInstance(y.currencyCode) }
        val perMonth = fmt.format(y.priceMicros / 12_000_000.0)
        val m = plans.monthly
        val save = if (m != null && m.currencyCode == y.currencyCode && m.priceMicros > 0) {
            val pct = (100 - (y.priceMicros * 100.0 / (m.priceMicros * 12))).toInt()
            if (pct > 0) " · tiết kiệm " + pct + "%" else ""
        } else ""
        "≈ " + perMonth + "/tháng" + save
    } catch (_: Exception) {
        null
    }
}

/** Gợi ý giá cho bảng giá chuyển khoản (VND). */
private fun staticHint(tier: MembershipTier): String? {
    val y = BillingCatalog.priceVnd(tier, BillingPeriod.YEARLY)
    val m = BillingCatalog.priceVnd(tier, BillingPeriod.MONTHLY)
    if (y <= 0L || m <= 0L) return null
    val pct = (100 - (y * 100.0 / (m * 12))).toInt()
    return "≈ " + formatVnd(y / 12) + "/tháng" + if (pct > 0) " · tiết kiệm " + pct + "%" else ""
}
