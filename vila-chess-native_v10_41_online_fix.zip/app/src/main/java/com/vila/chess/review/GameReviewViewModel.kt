package com.vila.chess.review

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.vila.chess.core.Position
import com.vila.chess.core.START_FEN
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveUci
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface ReviewUiState {
    /** Chưa bắt đầu (màn Review vẽ nền trống, không nháy Loading khi kết quả có sẵn trong cache). */
    data object Idle : ReviewUiState

    /** progress null = chưa có tiến độ. analyzed/total tính theo số THẾ CỜ (nước đi + thế đầu ván). */
    data class Loading(val progress: Float?, val analyzed: Int, val total: Int) : ReviewUiState

    data class Ready(val data: ReviewData) : ReviewUiState

    data class Failed(val reason: String) : ReviewUiState
}

/**
 * ViewModel của màn Game Review.
 *
 * Nguồn kết quả, theo thứ tự:
 *  1. File cache (GameReviewStore): có sẵn -> Ready ngay, không qua Loading.
 *  2. Worker nền (GameReviewWorker, chạy từ lúc ván kết thúc) đang RUNNING -> chỉ theo dõi tiến độ, KHÔNG chạy engine thứ hai.
 *  3. Còn lại -> tự phân tích từng thế cờ bằng SilentStockfishEngine (native, dự phòng wasm) trên Dispatchers.IO,
 *     cập nhật [state] sau mỗi thế, xong thì lưu cache.
 * Rời màn khi bước 3 chưa xong -> giao lại cho Worker để phân tích vẫn hoàn tất ở nền.
 */
class GameReviewViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx: Application = app
    private val store = GameReviewStore(app)

    private val _state = MutableStateFlow<ReviewUiState>(ReviewUiState.Idle)
    val state: StateFlow<ReviewUiState> = _state.asStateFlow()

    /** Nước đang xem: 0 = thế đầu ván, n = thế sau n nước. */
    private val _ply = MutableStateFlow(0)
    val ply: StateFlow<Int> = _ply.asStateFlow()

    private var job: Job? = null
    private var activeId: String? = null

    private class Args(val gameId: String, val startFen: String, val ucis: List<String>)

    /** Khác null khi chính ViewModel này đang chạy engine (chưa xong). */
    @Volatile
    private var inProcess: Args? = null

    /**
     * Bắt đầu (hoặc nối lại) việc phân tích một ván. Gọi nhiều lần với cùng [gameId] là vô hại.
     * [moves] = các nước đi UCI theo thứ tự; [startFen] = thế đầu ván.
     */
    fun startGameAnalysis(gameId: String, moves: List<String>, startFen: String = START_FEN) {
        if (activeId == gameId && _state.value !is ReviewUiState.Failed) return
        releaseInProcess()
        job?.cancel()
        activeId = gameId
        _ply.value = 0
        _state.value = ReviewUiState.Idle
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                runAnalysis(gameId, moves, startFen)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.e("GameReview", "Lỗi phân tích: ${e.message}", e)
                _state.value = ReviewUiState.Failed("Không phân tích được ván này. Bấm Quay lại rồi thử lại.")
            }
        }
    }

    /** Gọi khi rời màn Review. */
    fun onLeave() = releaseInProcess()

    override fun onCleared() {
        releaseInProcess()
        super.onCleared()
    }

    // ------------------------------------------------------------------ Tua nước đi

    fun goTo(target: Int) {
        val max = (_state.value as? ReviewUiState.Ready)?.data?.review?.moves?.size ?: return
        _ply.value = target.coerceIn(0, max)
    }

    fun step(delta: Int) = goTo(_ply.value + delta)

    // ------------------------------------------------------------------ Phân tích

    private suspend fun runAnalysis(gameId: String, moves: List<String>, startFen: String) {
        val replay = ReviewReplay.replay(startFen, moves)
        if (replay == null || replay.plies.isEmpty()) {
            _state.value = ReviewUiState.Failed("Không đọc được danh sách nước đi của ván này.")
            return
        }

        // 1) Đã phân tích xong từ trước: hiện kết quả ngay.
        loadCached(gameId, replay)?.let { _state.value = ReviewUiState.Ready(it); return }

        _state.value = ReviewUiState.Loading(null, 0, replay.plies.size + 1)

        // 2) Worker nền đang chạy đúng ván này: chờ nó thay vì chạy engine thứ hai.
        val wm = WorkManager.getInstance(ctx)
        val workName = GameReviewWorker.uniqueName(gameId)
        val workerRunning =
            wm.getWorkInfosForUniqueWorkFlow(workName).first().firstOrNull()?.state == WorkInfo.State.RUNNING
        if (workerRunning && awaitWorker(wm, workName, gameId, replay)) return

        // 3) Không có Worker đang chạy: tự phân tích tại đây.
        wm.cancelUniqueWork(workName)
        analyzeHere(gameId, startFen, moves, replay)
    }

    /** true = Worker đã xong và kết quả đã được nạp vào [state]. false = Worker thất bại/bị hủy, cần tự phân tích. */
    private suspend fun awaitWorker(wm: WorkManager, workName: String, gameId: String, replay: ReplayResult): Boolean {
        val last = wm.getWorkInfosForUniqueWorkFlow(workName)
            .map { it.firstOrNull() }
            .onEach { info ->
                if (info != null && info.state == WorkInfo.State.RUNNING) {
                    val done = info.progress.getInt(GameReviewWorker.KEY_DONE, -1)
                    val total = info.progress.getInt(GameReviewWorker.KEY_TOTAL, 0)
                    _state.value =
                        if (done >= 0 && total > 0) {
                            ReviewUiState.Loading((done.toFloat() / total).coerceIn(0f, 1f), done, total)
                        } else {
                            ReviewUiState.Loading(null, 0, total)
                        }
                }
            }
            .first { it == null || it.state != WorkInfo.State.RUNNING }
        if (last?.state != WorkInfo.State.SUCCEEDED) return false
        val data = loadCached(gameId, replay) ?: return false
        _state.value = ReviewUiState.Ready(data)
        return true
    }

    private suspend fun analyzeHere(gameId: String, startFen: String, ucis: List<String>, replay: ReplayResult) {
        val args = Args(gameId, startFen, ucis)
        inProcess = args
        val config = DeviceTierManager.getDeviceTier(ctx)
        val monitor = DeviceHealthMonitor(ctx)
        val engine = SilentStockfishEngine(ctx, config)
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
        try {
            val evals = ArrayList<EngineResult>(fens.size)
            _state.value = ReviewUiState.Loading(0f, 0, fens.size)
            for ((i, fen) in fens.withIndex()) {
                currentCoroutineContext().ensureActive()
                // Thế đã hết ván (chiếu hết/hòa) tính bằng luật cờ, không cần engine.
                val terminal = ReviewReplay.terminalEval(fen)
                evals += terminal ?: engine.analyzeSilently(fen, depthFor(config, monitor))
                _state.value = ReviewUiState.Loading((i + 1).toFloat() / fens.size, i + 1, fens.size)
            }
            val review = ReviewAssembler.assemble(
                gameId, replay.startFen, replay.plies, evals, config.tier.name, System.currentTimeMillis(),
            )
            store.save(review)
            GameReviewWorker.discardQueue(ctx, gameId)
            _state.value = ReviewUiState.Ready(buildData(review, replay))
            com.vila.chess.cloud.SupabaseCloud.pushReview(ctx, review)   // sau khi đã hiện kết quả; không ném lỗi
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Log.e("GameReview", "Lỗi phân tích: ${e.message}", e)
            _state.value = ReviewUiState.Failed("Engine phân tích không chạy được trên máy này.")
        } finally {
            if (inProcess === args) inProcess = null
            withContext(NonCancellable) { engine.shutdown() }
        }
    }

    /** Máy đang nóng: giảm độ sâu thay vì bắt người dùng chờ nguội (Worker nền mới là nơi chờ nguội). */
    private fun depthFor(config: EngineConfig, monitor: DeviceHealthMonitor): Int =
        if (monitor.isTooHot()) (config.depth - 4).coerceAtLeast(6) else config.depth

    /** Hủy phân tích tại chỗ (nếu có) và giao lại cho Worker nền để vẫn hoàn tất. */
    private fun releaseInProcess() {
        val a = inProcess ?: return
        inProcess = null
        job?.cancel()
        activeId = null
        _state.value = ReviewUiState.Idle
        runCatching { GameReviewWorker.enqueueAnalysis(ctx, a.gameId, a.startFen, a.ucis) }
    }

    // ------------------------------------------------------------------ Dựng dữ liệu hiển thị

    private fun loadCached(gameId: String, replay: ReplayResult): ReviewData? {
        val r = store.load(gameId) ?: return null            // load() đã loại file rác
        if (r.moves.size != replay.plies.size) { store.delete(gameId); return null }   // file không khớp ván (hỏng/cũ)
        return buildData(r, replay)
    }

    private fun buildData(review: GameReview, replay: ReplayResult): ReviewData {
        val fens = listOf(replay.startFen) + replay.plies.map { it.fenAfter }
        val bestSans = replay.plies.indices.map { i -> sanOf(fens[i], review.moves[i].bestMoveBefore) }
        return ReviewData(review, fens, replay.plies.map { it.san }, bestSans)
    }

    private fun sanOf(fen: String, uci: String?): String? {
        if (uci == null) return null
        return runCatching {
            val pos = Position.fromFen(fen)
            val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci }
            if (mv == null) null else moveToSan(pos, mv)
        }.getOrNull()
    }
}
