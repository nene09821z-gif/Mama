package com.vila.chess

import com.vila.chess.core.BISHOP
import com.vila.chess.core.EMPTY
import com.vila.chess.core.KNIGHT
import com.vila.chess.core.PAWN
import com.vila.chess.core.Position
import com.vila.chess.core.applyPremoveOnCopy
import com.vila.chess.core.makePiece
import com.vila.chess.game.PremoveMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PremoveQueueTest {
    @Test
    fun chainedPremovesBuildVirtualBoard() {
        val v = Position.start()
        assertTrue(applyPremoveOnCopy(v, true, 12, 28))   // e2-e4
        assertTrue(applyPremoveOnCopy(v, true, 6, 21))    // g1-f3
        assertTrue(applyPremoveOnCopy(v, true, 5, 26))    // f1-c4: chỉ hợp lệ vì e2 đã trống ở bàn cờ ảo
        assertEquals(makePiece(PAWN, true), v.board[28])
        assertEquals(makePiece(KNIGHT, true), v.board[21])
        assertEquals(makePiece(BISHOP, true), v.board[26])
        assertEquals(EMPTY, v.board[12])
    }

    @Test
    fun invalidPremoveIsRejected() {
        val v = Position.start()
        assertTrue(applyPremoveOnCopy(v, true, 12, 28))
        assertFalse(applyPremoveOnCopy(v, true, 12, 28))  // e2 đã trống
        assertFalse(applyPremoveOnCopy(v, true, 0, 40))   // xe a1 không nhảy qua tốt
    }

    @Test
    fun premoveModeIdsRoundTrip() {
        for (m in PremoveMode.values()) assertEquals(m, PremoveMode.fromId(m.id))
        assertEquals(PremoveMode.MULTI, PremoveMode.fromId(99))
    }
}
