package com.vila.chess.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object VilaColors {
    val Bg = Color(0xFF262522)
    val Panel = Color(0xFF302E2B)
    val PanelDark = Color(0xFF21201D)
    val Green = Color(0xFF81B64C)
    val GreenPressed = Color(0xFF6A9A3E)
    val GreenShadow = Color(0xFF45753C)
    val Text = Color(0xFFFFFFFF)
    val TextDim = Color(0xFFBABABA)
    val BoardLight: Color get() = BoardThemes.current.light   // đổi được ở Tùy chỉnh > Màu bàn cờ
    val BoardDark: Color get() = BoardThemes.current.dark
    val Highlight = Color(0xBFF5F682)
    val PremoveRed = Color(0xA6EB6150)
    val ClockActive = Color(0xFFFFFFFF)
    val ClockIdle = Color(0xFF403D39)
    val Danger = Color(0xFFE05A47)

    // Home screen ("space" look)
    val SpaceTop = Color(0xFF0A1530)
    val SpaceMid = Color(0xFF10264A)
    val SpaceBottom = Color(0xFF0A1226)
    val Glass = Color(0xA61B2D4A)
    val GlassBorder = Color(0x22FFFFFF)
    val NavIdle = Color(0xFF9AA6BA)
    val Badge = Color(0xFFE5392B)
    val GreenDeep = Color(0xFF2C4A24)

    // Nền tảng giao diện chung (màn chơi, hộp thoại, thanh công cụ)
    val PanelRaised = Color(0xFF3A3834)      // mặt nổi hơn Panel: nút, chip, thẻ bấm được
    val Hairline = Color(0x14FFFFFF)         // đường kẻ mảnh phân vùng
    val AvatarBorder = Color(0x26FFFFFF)     // viền mảnh quanh ảnh đại diện
    val ClockIdleText = Color(0xFFA7A39C)
    val ClockActiveText = Color(0xFF1F1E1B)
    val ClockLowActive = Color(0xFFFFE1DC)   // nền đồng hồ khi sắp hết giờ (đang chạy)
}

/** Kích thước / bo góc dùng chung để các màn nhìn đồng bộ. */
object VilaDimens {
    val ScreenPad = 12.dp
    val CardRadius = 12.dp
    val ChipRadius = 8.dp
    val AvatarRadius = 8.dp
    val DialogRadius = 18.dp
}

/** Kiểu chữ dùng chung. Số dùng "tnum" (chữ số cùng bề rộng) để đồng hồ không rung khi đổi số. */
object VilaText {
    val Clock = TextStyle(fontFeatureSettings = "tnum", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, letterSpacing = 0.sp)
    val PlayerName = TextStyle(fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = (-0.1).sp)
    val Caption = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.1.sp)
    val DialogTitle = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, letterSpacing = (-0.2).sp)
    val Move = TextStyle(fontFeatureSettings = "tnum", fontSize = 14.sp)
}

/** Brush dùng chung (tạo một lần, không cấp phát lại mỗi frame). */
object VilaBrushes {
    /** Thẻ kính: sáng nhẹ ở trên, tối dần xuống dưới - tạo cảm giác có độ sâu như chess.com. */
    val Glass = Brush.verticalGradient(listOf(Color(0xCC243B5E), Color(0xB3182A47)))
    /** Viền sáng ở cạnh trên, mờ dần xuống dưới. */
    val GlassStroke = Brush.verticalGradient(listOf(Color(0x44FFFFFF), Color(0x12FFFFFF)))
    /** Mặt nút xanh (hơi sáng hơn ở trên). */
    val ButtonFace = Brush.verticalGradient(listOf(Color(0xFF8DC351), Color(0xFF7BB145)))
}

@Composable
fun ViLaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = VilaColors.Green,
            onPrimary = Color.White,
            secondary = VilaColors.Green,
            background = VilaColors.Bg,
            onBackground = VilaColors.Text,
            surface = VilaColors.Panel,
            onSurface = VilaColors.Text,
            surfaceVariant = VilaColors.PanelDark,
            onSurfaceVariant = VilaColors.TextDim
        ),
        content = content
    )
}
