package com.vila.chess.billing

/**
 * Định nghĩa gói thành viên + phân quyền tính năng.
 * BẢN NÀY PHẢI KHỚP với web-paywall/shared/membership-spec.js (nguồn sự thật dùng chung hai nền tảng).
 * Muốn đổi quyền lợi: sửa Ở HAI NƠI, không rải `if (tier == ...)` trong UI.
 */
enum class MembershipTier(val id: String, val displayName: String, val rank: Int) {
    FREE("free", "Miễn phí", 0),
    GOLD("gold", "Gold", 1),
    PLATINUM("platinum", "Platinum", 2),
    DIAMOND("diamond", "Diamond", 3),
    /** Friends & Family: 2–6 thành viên, chỉ bán theo năm, gồm toàn bộ quyền lợi Diamond. */
    FAMILY("family", "Friends & Family", 4);

    companion object {
        fun fromId(id: String?): MembershipTier = values().firstOrNull { it.id == id } ?: FREE
    }
}

/** Tính năng "có / không". Các gói cao hơn tự động gồm gói thấp hơn (so theo rank). */
enum class Feature(val minTier: MembershipTier, val label: String) {
    AD_FREE(MembershipTier.GOLD, "Không quảng cáo"),
    UNLIMITED_PUZZLES(MembershipTier.GOLD, "Câu đố không giới hạn"),
    UNLIMITED_LESSONS(MembershipTier.GOLD, "Bài học không giới hạn"),
    GAME_REVIEW(MembershipTier.PLATINUM, "Game Review không giới hạn"),
    COACH_EXPLANATIONS(MembershipTier.DIAMOND, "Huấn luyện viên giải thích nước đi"),
    INSIGHTS(MembershipTier.DIAMOND, "Insights"),
    ADVANCED_STATS(MembershipTier.DIAMOND, "Thống kê nâng cao"),
}

/** Hạn mức theo ngày cho gói chưa mở khóa [unlockedBy]. */
enum class Quota(val unlockedBy: Feature, val limitWhenLocked: Int) {
    PUZZLES(Feature.UNLIMITED_PUZZLES, 3),
    LESSONS(Feature.UNLIMITED_LESSONS, 5), // Free: 5 bài MỚI/ngày, sang ngày mới (0h) được làm mới như chess.com
    GAME_REVIEW(Feature.GAME_REVIEW, 1),   // Free và Gold: 1 ván/ngày
}

fun hasAccess(feature: Feature, tier: MembershipTier): Boolean = tier.rank >= feature.minTier.rank

/** null = không giới hạn. */
fun dailyLimit(quota: Quota, tier: MembershipTier): Int? =
    if (hasAccess(quota.unlockedBy, tier)) null else quota.limitWhenLocked

fun showAds(tier: MembershipTier): Boolean = !hasAccess(Feature.AD_FREE, tier)

/** Gói rẻ nhất mở khóa tính năng này (dùng cho dòng "Cần gói Platinum"). */
fun requiredTier(feature: Feature): MembershipTier = feature.minTier

/** Nội dung hiển thị trên thẻ gói (đã cộng dồn kiểu "Gồm tất cả của gói trước"). */
object TierInfo {
    fun highlights(tier: MembershipTier): List<String> = when (tier) {
        MembershipTier.FREE -> listOf("Game Review 1 ván/ngày", "3 câu đố/ngày", "5 bài học/ngày", "Có quảng cáo")
        MembershipTier.GOLD -> listOf(
            "Không quảng cáo",
            "Câu đố & bài học không giới hạn",
            "Game Review 1 ván/ngày",
        )
        MembershipTier.PLATINUM -> listOf(
            "Gồm tất cả quyền lợi Gold",
            "Game Review không giới hạn",
        )
        MembershipTier.DIAMOND -> listOf(
            "Gồm tất cả quyền lợi Platinum",
            "Huấn luyện viên giải thích nước đi",
            "Insights",
            "Thống kê nâng cao",
        )
        MembershipTier.FAMILY -> listOf(
            "Gồm tất cả quyền lợi Diamond",
            "2–6 thành viên dùng chung",
            "Chỉ bán gói năm · tiết kiệm đến 71%",
        )
    }

    /** Danh sách tính năng hiển thị trên thẻ gói (đã cộng dồn, khớp bảng giá chess.com). Dùng cho màn Paywall. */
    fun featureLines(tier: MembershipTier): List<String> {
        val base = listOf(
            "Không giới hạn câu đố",
            "Không giới hạn bài học",
            "Không giới hạn Ván đấu huấn luyện viên",
            "Mở khóa tất cả bot",
            "Không quảng cáo",
        )
        val review = "Xem lại ván đấu không giới hạn"
        val diamondOnly = listOf("Giải thích về Di chuyển không giới hạn", "Thống kê nâng cao")
        return when (tier) {
            MembershipTier.FREE -> emptyList()
            MembershipTier.GOLD -> base
            MembershipTier.PLATINUM -> listOf(review) + base
            MembershipTier.DIAMOND -> diamondOnly + base
            MembershipTier.FAMILY -> listOf(review) + diamondOnly + base
        }
    }
}
