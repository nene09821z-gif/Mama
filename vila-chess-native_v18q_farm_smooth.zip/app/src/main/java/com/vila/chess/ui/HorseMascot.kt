package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/*
 * NGỰA 3D – linh vật nhảy từ ô này sang ô kế khi xong bài học / câu đố.
 *
 * Vẽ hoàn toàn bằng Canvas (không asset) trên hệ toạ độ đơn vị 130×124, quay mặt sang PHẢI, chân chạm y = 116.
 * Cảm giác 3D đến từ: gradient sáng-tối theo hướng ánh sáng từ trên-trái, viền sáng (rim light) ở mép trên,
 * bóng đổ dưới bụng/hàm, đường cơ vai–đùi, chân xa tối hơn chân gần, mắt bóng có 2 điểm sáng, tất trắng, móng
 * có điểm sáng, yên + chăn đổi màu theo chủ đề vùng; ở ngoài còn có bóng đổ thật trên mặt ô co lại khi bay cao,
 * squash & stretch, bờm/đuôi bay theo gió và bụi khi tiếp đất.
 */

private const val UW = 130f
private const val UH = 124f
private const val FOOT_X = 58f
private const val FOOT_Y = 116f
private const val TAU = 6.2831855f

// ── Bảng màu ─────────────────────────────────────────────────────────────────────────────────────
private val Coat = Color(0xFFC98240)
private val CoatLight = Color(0xFFEFB874)
private val CoatDark = Color(0xFF8A4A20)
private val CoatDeep = Color(0xFF55290F)
private val Mane = Color(0xFF3A1F10)
private val ManeLight = Color(0xFF74422A)
private val Sock = Color(0xFFF7EEDC)
private val SockDark = Color(0xFFD2C2A8)
private val Hoof = Color(0xFF3B2B24)
private val HoofLight = Color(0xFF8A7360)
private val Ink = Color(0x993A1B0B)       // viền mềm kiểu hoạt hình
private val EyeDark = Color(0xFF24120A)
private val Gold = Color(0xFFFFD45A)
private val Leather = Color(0xFF6B3A1A)

private fun farSide(c: Color): Color = lerp(c, CoatDeep, 0.38f)

// ── Hình khối tĩnh (dựng 1 lần) ──────────────────────────────────────────────────────────────────
private val BodyPath = Path().apply { addOval(Rect(26f, 56f, 90f, 96f)) }

private val NeckPath = Path().apply {
    moveTo(64f, 62f)
    cubicTo(66f, 44f, 76f, 26f, 90f, 14f)
    lineTo(110f, 30f)
    cubicTo(104f, 48f, 98f, 62f, 92f, 78f)
    lineTo(64f, 80f)
    close()
}
private val NeckEdgeBack = Path().apply { moveTo(64f, 62f); cubicTo(66f, 44f, 76f, 26f, 90f, 14f) }
private val NeckEdgeFront = Path().apply { moveTo(110f, 30f); cubicTo(104f, 48f, 98f, 62f, 92f, 78f) }

private val HeadPath = Path().apply {
    moveTo(84f, 24f)
    cubicTo(84f, 12f, 96f, 6f, 108f, 10f)
    cubicTo(116f, 13f, 120f, 22f, 124f, 32f)
    cubicTo(128f, 40f, 127f, 50f, 119f, 52f)
    cubicTo(112f, 54f, 106f, 50f, 102f, 46f)
    cubicTo(92f, 50f, 82f, 40f, 84f, 24f)
    close()
}
private val EarNear = Path().apply {
    moveTo(88f, 16f); cubicTo(86f, 8f, 90f, 2f, 95f, 1f); cubicTo(98f, 6f, 99f, 11f, 98f, 15f); close()
}
private val EarNearInner = Path().apply {
    moveTo(91f, 14f); cubicTo(90f, 9f, 92f, 5f, 95f, 4f); cubicTo(96f, 8f, 96f, 11f, 96f, 14f); close()
}
private val EarFar = Path().apply {
    moveTo(99f, 14f); cubicTo(98f, 7f, 102f, 2f, 107f, 2f); cubicTo(109f, 7f, 109f, 12f, 107f, 16f); close()
}
private val Blaze = Path().apply {
    moveTo(100f, 10f); cubicTo(106f, 12f, 114f, 22f, 121f, 36f)
    cubicTo(117f, 38f, 111f, 34f, 107f, 28f); cubicTo(102f, 22f, 100f, 16f, 100f, 10f); close()
}
private val Forelock = Path().apply {
    moveTo(93f, 12f); cubicTo(95f, 2f, 106f, 3f, 110f, 10f)
    cubicTo(106f, 10f, 104f, 16f, 105f, 22f); cubicTo(100f, 16f, 96f, 14f, 93f, 12f); close()
}
private val CheekPiece = Path().apply { moveTo(96f, 13f); cubicTo(93f, 26f, 97f, 38f, 103f, 46f) }
private val NoseBand = Path().apply { moveTo(112f, 35f); cubicTo(117f, 41f, 118f, 47f, 114f, 52f) }
private val Mouth = Path().apply { moveTo(110f, 50f); quadTo(116f, 52.5f, 121f, 48.5f) }
private val Reins = Path().apply { moveTo(115f, 50f); quadTo(92f, 76f, 62f, 54f) }
private val Scratch = Path()   // dùng lại cho bờm/đuôi (đổi hình theo gió mỗi khung) – chỉ vẽ trên luồng UI

// ── Brush tĩnh (toạ độ đơn vị cố định ⇒ dùng chung mọi khung hình) ───────────────────────────────
private val BodyBrush = Brush.linearGradient(
    0f to CoatLight, 0.45f to Coat, 1f to CoatDark, start = Offset(40f, 54f), end = Offset(78f, 98f),
)
private val NeckBrush = Brush.linearGradient(
    0f to CoatLight, 0.55f to Coat, 0.95f to lerp(Coat, CoatDark, 0.3f), start = Offset(70f, 20f), end = Offset(96f, 80f),
)
private val HeadBrush = Brush.linearGradient(
    0f to CoatLight, 0.5f to Coat, 1f to CoatDark, start = Offset(90f, 8f), end = Offset(120f, 54f),
)
private val ManeBrush = Brush.linearGradient(listOf(ManeLight, Mane), start = Offset(60f, 10f), end = Offset(100f, 70f))
private val BellyShade = Brush.verticalGradient(listOf(Color(0x00000000), Color(0x66401800)), startY = 76f, endY = 98f)
private val JawShade = Brush.verticalGradient(listOf(Color(0x00000000), Color(0x55401800)), startY = 38f, endY = 54f)
private val NeckShade = Brush.radialGradient(listOf(Color(0x66301000), Color(0x00301000)), center = Offset(100f, 50f), radius = 20f)
private val MuzzleGlow = Brush.radialGradient(listOf(Color(0x66FFE9C8), Color(0x00FFE9C8)), center = Offset(119f, 43f), radius = 11f)
private val Spec = Brush.radialGradient(listOf(Color(0x55FFFFFF), Color(0x00FFFFFF)), center = Offset(55f, 61f), radius = 18f)
private val IrisBrush = Brush.radialGradient(listOf(Color(0xFFA8642E), Color(0xFF4B2610)), center = Offset(104f, 28f), radius = 6f)

// ── Điều khiển cú nhảy ───────────────────────────────────────────────────────────────────────────
/**
 * Một cú nhảy của ngựa. [t] 0 → 1 do [play] chạy; chỉ được ĐỌC trong graphicsLayer/draw ⇒ không recomposition.
 * [faceLeft]: ngựa quay mặt về hướng nhảy (đặt TRƯỚC khi gọi [play]); giữ nguyên sau khi đáp.
 */
@Stable
class HorseHop {
    val t = Animatable(0f)
    var faceLeft = false

    suspend fun play(ms: Int = HORSE_HOP_MS) {
        t.snapTo(0f)
        t.animateTo(1f, tween(ms, easing = LinearEasing))
    }
}

// ── Lớp phủ ──────────────────────────────────────────────────────────────────────────────────────
/**
 * Ngựa + bóng đổ, vẽ ĐÈ lên danh sách (nên nhảy được qua nhiều hàng, không bị LazyColumn tái chế/cắt).
 * Mọi toạ độ là px trong hệ của lớp phủ (= hệ của màn hình bản đồ).
 *  • [from]: chân ngựa khi đứng yên / lúc bắt đầu nhảy. Trả về điểm ngoài màn hình để ẩn.
 *  • [to]  : điểm đáp. null = đứng yên (không nhảy). Trùng [from] = nhảy tại chỗ (mừng).
 * [from]/[to] được gọi trong graphicsLayer ⇒ đọc trạng thái cuộn ở đó thì ngựa bám ô khi cuộn mà không recomposition.
 */
@Composable
internal fun HorseOverlay(
    width: Dp,
    accent: Color,
    hop: HorseHop,
    clock: State<Float>,
    from: () -> Offset,
    to: () -> Offset?,
    modifier: Modifier = Modifier,
) {
    val f = remember { HorseFrame() }
    val pShadow = remember { FloatArray(3) }
    val pHorse = remember { FloatArray(3) }
    val wPx = with(LocalDensity.current) { width.toPx() }
    val k = wPx / UW
    val horseH = width * (UH / UW)
    val shadowH = width * 0.36f

    Box(modifier.fillMaxSize()) {
        // Bóng đổ trên mặt ô: ở lại mặt đất, nhỏ và nhạt dần khi ngựa bay cao.
        Canvas(
            Modifier
                .requiredSize(width, shadowH)
                .graphicsLayer {
                    f.set(hop.t.value, 0f)
                    horsePlace(from(), to(), f, wPx, pShadow)
                    translationX = pShadow[0] - wPx / 2f
                    translationY = pShadow[1] - wPx * 0.18f
                },
        ) {
            f.set(hop.t.value, clock.value)
            val c = center
            val rx = size.width * 0.42f * (1f - 0.4f * f.lift)
            withTransform({ scale(1f, 0.3f, c) }) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0x99000000), Color(0x00000000)), center = c, radius = rx),
                    radius = rx, center = c, alpha = 1f - 0.5f * f.lift,
                )
            }
            if (f.dust > 0.001f) {   // bụi bay quanh chân lúc tiếp đất
                val u = f.dust
                for (i in 0 until 6) {
                    val a = i * (TAU / 6f) + 0.4f
                    val d = size.width * (0.18f + 0.32f * u)
                    drawCircle(
                        Color(0xFFFFF3D6),
                        radius = size.width * (0.05f - 0.02f * u),
                        center = Offset(c.x + cos(a) * d, c.y + sin(a) * d * 0.32f),
                        alpha = (1f - u) * 0.75f,
                    )
                }
            }
        }
        // Ngựa.
        Canvas(
            Modifier
                .requiredSize(width, horseH)
                .graphicsLayer {
                    f.set(hop.t.value, 0f)
                    horsePlace(from(), to(), f, wPx, pHorse)
                    translationX = pHorse[0] - FOOT_X * k
                    translationY = pHorse[1] - FOOT_Y * k - pHorse[2]
                },
        ) {
            f.set(hop.t.value, clock.value)
            val feet = Offset(FOOT_X * k, FOOT_Y * k)
            // Thứ tự: lật theo hướng nhảy → dồn/giãn quanh bàn chân → nghiêng quanh thân → đổi sang px (gọi sau = áp trước).
            withTransform({
                if (hop.faceLeft) scale(-1f, 1f, Offset(feet.x, 0f))
                scale(1f + (1f - f.squashY) * 0.6f, f.squashY, feet)
                rotate(f.pitch, Offset(58f * k, 80f * k))
                scale(k, k, Offset.Zero)
            }) { drawHorse(f, accent) }
        }
    }
}

/** out = [chân x, chân y (mặt đất, không tính độ cao), độ cao px]. */
private fun horsePlace(a: Offset, b: Offset?, f: HorseFrame, wPx: Float, out: FloatArray) {
    if (b == null) {
        out[0] = a.x; out[1] = a.y; out[2] = 0f
        return
    }
    val dx = b.x - a.x
    val dy = b.y - a.y
    val arc = (sqrt(dx * dx + dy * dy) * 0.42f).coerceIn(wPx * 0.55f, wPx * 1.5f)   // nhảy tại chỗ vẫn bật ~nửa thân
    out[0] = a.x + dx * f.s
    out[1] = a.y + dy * f.s
    out[2] = f.lift * arc
}

// ── Vẽ ngựa ──────────────────────────────────────────────────────────────────────────────────────
private fun DrawScope.drawHorse(f: HorseFrame, accent: Color) {
    val lg = f.legs
    val a1f = if (lg >= 0f) -30f * lg else 40f * lg   // chân trước: hông
    val a2f = if (lg >= 0f) 85f * lg else 0f          //             gối
    val a1h = if (lg >= 0f) 30f * lg else -40f * lg   // chân sau
    val a2h = if (lg >= 0f) -75f * lg else 0f

    drawTail(f)
    // Mọi chân nằm SAU thân (đỉnh đùi chìm trong thân): chân xa tối hơn, lệch pha nhẹ cho tự nhiên.
    drawLeg(46f, a1h * 0.9f, a2h * 0.9f, far = true)
    drawLeg(70f, a1f * 0.85f, a2f * 0.85f, far = true)
    drawLeg(38f, a1h, a2h, far = false)
    drawLeg(78f, a1f, a2f, far = false)
    drawNeck()
    drawBody(accent)
    drawMane(f)
    drawHead(f, accent)
}

private fun DrawScope.drawLeg(hx: Float, a1: Float, a2: Float, far: Boolean) {
    val hy = 82f
    val skin = if (far) farSide(Coat) else Coat
    val sock = if (far) farSide(Sock) else Sock
    val hoof = if (far) farSide(Hoof) else Hoof
    withTransform({ rotate(a1, Offset(hx, hy)) }) {
        drawRoundRect(skin, Offset(hx - 6f, hy - 4f), Size(12f, 20f), CornerRadius(5f))                       // đùi
        drawRoundRect(Color(0x33FFFFFF), Offset(hx - 5f, hy - 2f), Size(3.2f, 16f), CornerRadius(1.6f))      // mép sáng
        drawRoundRect(Color(0x33000000), Offset(hx + 2.6f, hy - 2f), Size(3.2f, 17f), CornerRadius(1.6f))    // mép tối
        withTransform({ rotate(a2, Offset(hx, hy + 15f)) }) {
            drawRoundRect(sock, Offset(hx - 4.4f, hy + 13f), Size(8.8f, 15f), CornerRadius(3.5f))            // cẳng (tất trắng)
            drawRoundRect(SockDark, Offset(hx + 1.6f, hy + 14f), Size(2.8f, 13f), CornerRadius(1.4f))
            drawRoundRect(hoof, Offset(hx - 5.4f, hy + 26f), Size(10.8f, 8f), CornerRadius(2.6f))            // móng
            drawRoundRect(HoofLight, Offset(hx - 3.8f, hy + 27.4f), Size(3.2f, 1.8f), CornerRadius(0.9f))    // điểm sáng
        }
    }
}

private fun DrawScope.drawTail(f: HorseFrame) {
    for (j in 2 downTo 0) {
        val bx = 30f
        val by = 64f + j * 3f
        val tx = bx - 14f - 2f * j - 3f * f.swing
        val ty = by + 26f + 5f * j + 4f * f.swing
        Scratch.reset()
        Scratch.moveTo(bx + 3f, by - 6f)
        Scratch.cubicTo(bx - 12f, by - 4f, tx + 9f, ty - 14f, tx, ty)
        Scratch.cubicTo(tx + 11f, ty - 5f, bx - 2f, by + 10f, bx + 3f, by + 6f)
        Scratch.close()
        drawPath(Scratch, ManeBrush)
        drawPath(Scratch, Ink, style = Stroke(1f, join = StrokeJoin.Round))
    }
}

private fun DrawScope.drawNeck() {
    drawPath(NeckPath, NeckBrush)
    clipPath(NeckPath) {
        drawCircle(NeckShade, radius = 20f, center = Offset(100f, 50f))                           // bóng dưới hàm
        drawRoundRect(Color(0x33FFFFFF), Offset(71f, 28f), Size(8f, 26f), CornerRadius(4f))      // vệt sáng bên cổ
    }
    val edge = Stroke(1.3f, cap = StrokeCap.Round)
    drawPath(NeckEdgeBack, Ink, style = edge)
    drawPath(NeckEdgeFront, Ink, style = edge)
}

private fun DrawScope.drawBody(accent: Color) {
    drawPath(BodyPath, BodyBrush)
    clipPath(BodyPath) {
        drawRect(BellyShade, Offset(20f, 70f), Size(76f, 34f))
        // Chăn yên theo màu chủ đề + 2 sọc vàng.
        val blanket = Brush.verticalGradient(
            listOf(lerp(accent, Color.White, 0.22f), accent, lerp(accent, Color.Black, 0.32f)), startY = 48f, endY = 104f,
        )
        drawRect(blanket, Offset(41f, 48f), Size(26f, 56f))
        drawRect(Color(0xCCFFE9A0), Offset(41f, 66f), Size(26f, 2f))
        drawRect(Color(0xCCFFE9A0), Offset(41f, 86f), Size(26f, 2f))
        // Cơ đùi & vai: 2 cung tối tạo khối.
        val muscle = Stroke(1.5f, cap = StrokeCap.Round)
        drawArc(Color(0x33000000), -70f, 150f, false, Offset(22f, 62f), Size(30f, 32f), style = muscle)
        drawArc(Color(0x33000000), 110f, 140f, false, Offset(64f, 60f), Size(28f, 34f), style = muscle)
        drawCircle(Spec, radius = 18f, center = Offset(55f, 61f))                                   // điểm sáng trên lưng
    }
    clipRect(top = 0f, bottom = 66f) { drawPath(BodyPath, Color(0x77FFFFFF), style = Stroke(1.6f)) }   // rim light
    drawPath(BodyPath, Ink, style = Stroke(1.3f, join = StrokeJoin.Round))
    // Yên da.
    drawRoundRect(Leather, Offset(42f, 50f), Size(22f, 10f), CornerRadius(5f))
    drawRoundRect(Color(0x55FFFFFF), Offset(45f, 51.5f), Size(14f, 2.2f), CornerRadius(1.1f))
}

private fun maneAt(t: Float): Offset {
    val u = 1f - t
    val x = u * u * u * 90f + 3f * u * u * t * 76f + 3f * u * t * t * 66f + t * t * t * 64f
    val y = u * u * u * 14f + 3f * u * u * t * 24f + 3f * u * t * t * 42f + t * t * t * 62f
    return Offset(x, y)
}

private fun DrawScope.drawMane(f: HorseFrame) {
    for (i in 4 downTo 0) {
        val b = maneAt(0.03f + i * 0.235f)
        val len = 14f + (i % 2) * 3f
        val tx = b.x - len * 0.7f - 4f * f.swing
        val ty = b.y + len * 0.85f + 5f * f.swing
        Scratch.reset()
        Scratch.moveTo(b.x + 6f, b.y - 4f)
        Scratch.cubicTo(b.x - 3f, b.y - 2f, tx + 4f, ty - 8f, tx, ty)
        Scratch.cubicTo(tx + 8f, ty - 6f, b.x + 9f, b.y + 8f, b.x + 6f, b.y - 4f)
        Scratch.close()
        drawPath(Scratch, ManeBrush)
        drawPath(Scratch, Ink, style = Stroke(1f, join = StrokeJoin.Round))
    }
}

private fun DrawScope.drawHead(f: HorseFrame, accent: Color) {
    val accentDark = lerp(accent, Color.Black, 0.3f)
    // Tai xa.
    drawPath(EarFar, farSide(Coat))
    drawPath(EarFar, Ink, style = Stroke(1f, join = StrokeJoin.Round))
    // Đầu.
    drawPath(HeadPath, HeadBrush)
    clipPath(HeadPath) {
        drawPath(Blaze, Color(0xF2FFF5E4))
        drawRect(JawShade, Offset(80f, 36f), Size(50f, 20f))
        drawCircle(MuzzleGlow, radius = 11f, center = Offset(119f, 43f))
        drawOval(Color(0x33FFFFFF), Offset(90f, 12f), Size(22f, 10f))                  // sáng trên trán
        drawOval(Color(0x40FF8FA3), Offset(103f, 36f), Size(11f, 7f))                  // má hồng
    }
    clipRect(top = 0f, bottom = 26f) { drawPath(HeadPath, Color(0x77FFFFFF), style = Stroke(1.4f)) }
    drawPath(HeadPath, Ink, style = Stroke(1.3f, join = StrokeJoin.Round))
    // Tai gần.
    drawPath(EarNear, Coat)
    drawPath(EarNearInner, Color(0xCCE59A8A))
    drawPath(EarNear, Ink, style = Stroke(1f, join = StrokeJoin.Round))
    drawPath(Forelock, ManeBrush)
    drawPath(Forelock, Ink, style = Stroke(1f, join = StrokeJoin.Round))
    // Dây cương + khoá vàng.
    drawPath(CheekPiece, accentDark, style = Stroke(2.4f, cap = StrokeCap.Round))
    drawPath(NoseBand, accent, style = Stroke(2.6f, cap = StrokeCap.Round))
    drawCircle(Gold, radius = 2.4f, center = Offset(98f, 30f))
    drawCircle(Color(0xCCFFFFFF), radius = 0.9f, center = Offset(97.3f, 29.3f))
    drawCircle(Gold, radius = 2.1f, center = Offset(115f, 50.5f), style = Stroke(1.1f))
    // Mắt bóng: nhắm lại theo f.blink.
    val open = (1f - f.blink).coerceAtLeast(0.08f)
    withTransform({ scale(1f, open, Offset(104f, 28f)) }) {
        drawOval(EyeDark, Offset(99f, 22f), Size(10f, 12.5f))
        drawOval(IrisBrush, Offset(100.2f, 23.5f), Size(7.6f, 10f))
        drawCircle(Color.White, radius = 2.1f, center = Offset(102.4f, 25f))
        drawCircle(Color(0xCCFFFFFF), radius = 1f, center = Offset(106f, 31f))
    }
    drawArc(EyeDark, 200f, 140f, false, Offset(98.5f, 20.5f), Size(11f, 9f), style = Stroke(1.2f, cap = StrokeCap.Round))
    // Mũi + miệng.
    drawOval(Color(0xFF3A1B0B), Offset(118.4f, 39f), Size(3.4f, 5f))
    drawOval(Color(0x66FFFFFF), Offset(119.2f, 39.8f), Size(1.2f, 1.6f))
    drawPath(Mouth, Color(0xFF4A2410), style = Stroke(1.1f, cap = StrokeCap.Round))
    // Dây cương buông về yên.
    drawPath(Reins, accentDark, style = Stroke(1.6f, cap = StrokeCap.Round))
}
