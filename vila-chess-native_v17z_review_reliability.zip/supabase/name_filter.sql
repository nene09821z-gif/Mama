-- Bộ lọc tên bậy cho cột public.users.display_name (lớp phòng thủ phía server).
-- Ứng dụng đã chặn ở phía máy (NameFilter.kt); file này để người sửa app / gọi thẳng API vẫn không đặt được tên bậy.
-- Thuật toán và danh sách GIỐNG NameFilter.kt (sinh từ cùng một danh sách). Khác biệt nhỏ: server KHÔNG ghép chữ cái lẻ
-- ("s h i t") và chỉ tách từ theo dấu ASCII, nên server dễ tính hơn một chút so với app — không bao giờ khắt khe hơn.
--
-- Cách chạy: Supabase > SQL Editor > dán toàn bộ file > Run (chạy lại nhiều lần vẫn an toàn). Cần PostgreSQL 13+ (normalize()).
-- Hành vi: tên bậy KHÔNG làm lỗi lệnh ghi (để việc đồng bộ Elo/ván cờ vẫn chạy) mà bị thay bằng 'Người chơi'.

-- 1) Bỏ dấu tiếng Việt + đổi chữ Kirin giống Latin (cùng số ký tự 2 vế, đã kiểm khi sinh file).
create or replace function public.vila_fold_vi(s text)
returns text language sql immutable as $fn$
  select translate(s, 'àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐаеорсхуі', 'aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyydaaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyydaeopcxyi')
$fn$;

-- 2) Hàm kiểm tra.
create or replace function public.vila_is_offensive_name(raw text)
returns boolean language plpgsql immutable as $fn$
declare
  bad_tokens  constant text[] := array['ditme', 'dmm', 'dcm', 'dcmm', 'dkm', 'dkmm', 'vcl', 'vkl', 'vl', 'vlz', 'cmm', 'cmn', 'clgt', 'cac', 'cak', 'lon', 'loz', 'buoi', 'concac', 'dick', 'cock', 'ass', 'porn', 'sex', 'hentai', 'rape', 'rapist', 'nazi', 'kkk', 'tits', 'boobs', 'fag', 'slut', 'cum', 'twat', 'prick', 'shit', 'shitty', 'chink', 'gook', 'spic', 'tranny', 'cunt', 'cunts', 'fck', 'fuk', 'fvck', 'milf', 'dildo', 'nude', 'nudes', 'xxx', 'horny', 'bdsm', 'pedo'];
  phrases     constant text[] := array['dit me', 'dit con me', 'dit cu', 'du ma', 'du me', 'dau buoi', 'me may', 'con cho', 'thang cho', 'cho chet', 'oc cho', 'thang ngu', 'con ngu', 'do ngu', 'suc vat', 'khon nan', 'vai lon', 'white power'];
  strongs     constant text[] := array['fuck', 'bitch', 'nigger', 'nigga', 'faggot', 'whore', 'asshole', 'bastard', 'bollocks', 'wanker', 'jizz', 'pedophile', 'paedophile', 'retard', 'hitler', 'dickhead', 'cocksucker', 'bullshit', 'shithead', 'dipshit', 'pussy', 'ditme', 'ditmay', 'ditcon', 'dumamay', 'dumemay', 'daubuoi'];
  orig_bad    constant text[] := array['đĩ', 'đéo', 'đụ', 'điếm', 'địt'];
  allow_words constant text[] := array['bưởi', 'buổi', 'bưới', 'lớn', 'ngư', 'các'];
  -- dấu tách từ: sep_a coi @ $ ! là dấu tách; sep_b coi chúng là chữ (kiểu viết lách)
  sep_a constant text := '[\s.\-_,;:!?@$#*+=~^/\\|(){}<>"''`&%\[\]]+';
  sep_b constant text := '[\s.\-_,;:?#*+=~^/\\|(){}<>"''`&%\[\]]+';
  lowered text; toks_o text[]; t text; x text; v text; p text; s text; compact text; toks text[];
  m int; k int;
begin
  if raw is null then return false; end if;
  lowered := lower(normalize(regexp_replace(raw, '[\u200B-\u200D\u2060\uFEFF\u00AD]', '', 'g'), NFKC));
  if regexp_split_to_array(lowered, sep_a) && orig_bad then return true; end if;
  for m in 0..1 loop
    toks_o := regexp_split_to_array(lowered, case when m = 0 then sep_a else sep_b end);
    x := ' ';
    foreach t in array toks_o loop
      if t = '' then continue; end if;
      if t = any(allow_words) then
        x := x || '# ';
      else
        x := x || translate(public.vila_fold_vi(t), '013457$!@', 'oieastsia') || ' ';
      end if;
    end loop;
    for k in 0..2 loop            -- 0: nguyên văn, 1: gom chuỗi lặp 3+ về 1 ký tự, 2: về 2 ký tự
      v := case k
             when 0 then x
             when 1 then regexp_replace(x, '(.)\1{2,}', '\1', 'g')
             else regexp_replace(x, '(.)\1{2,}', '\1\1', 'g')
           end;
      toks := string_to_array(btrim(v), ' ');
      if toks && bad_tokens then return true; end if;
      foreach p in array phrases loop
        if strpos(v, ' ' || p || ' ') > 0 then return true; end if;
      end loop;
      compact := regexp_replace(v, '[^a-z]', '', 'g');
      foreach s in array strongs loop
        if strpos(compact, s) > 0 then return true; end if;
      end loop;
    end loop;
  end loop;
  return false;
end
$fn$;

-- 3) Trigger: tên bậy -> 'Người chơi' (cả khi thêm mới lẫn khi sửa tên).
create or replace function public.vila_name_guard()
returns trigger language plpgsql as $fn$
begin
  if new.display_name is not null and public.vila_is_offensive_name(new.display_name) then
    new.display_name := 'Người chơi';
  end if;
  return new;
end
$fn$;

drop trigger if exists vila_name_guard on public.users;
create trigger vila_name_guard
  before insert or update of display_name on public.users
  for each row execute function public.vila_name_guard();

-- 4) (Tùy chọn) Dọn các tên bậy đã có sẵn. Bỏ dấu "--" đầu dòng rồi chạy:
-- update public.users set display_name = 'Người chơi' where public.vila_is_offensive_name(display_name);

-- 5) Tự kiểm tra (chạy riêng, kết quả mong đợi ghi bên phải):
-- select public.vila_is_offensive_name('Địt mẹ mày');   -- true
-- select public.vila_is_offensive_name('f u c k');      -- true
-- select public.vila_is_offensive_name('D1t me');       -- true
-- select public.vila_is_offensive_name('Cún Tí');       -- false
-- select public.vila_is_offensive_name('Bưởi');         -- false
-- select public.vila_is_offensive_name('Takeshita');    -- false
-- select public.vila_is_offensive_name('Nguyễn Văn An');-- false
