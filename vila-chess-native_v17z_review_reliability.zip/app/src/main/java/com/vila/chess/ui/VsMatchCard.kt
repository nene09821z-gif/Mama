package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.vila.chess.billing.MembershipTier
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.UiState
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.ProfileError
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.UserSessionManager
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

// =============================================================================
// Thẻ "VS" khi vào ván online (giống chess.com)
//
// Hai thẻ người chơi trượt vào từ trên/dưới bàn cờ, nút VS bật ra ở giữa, giữ ~2,8 giây rồi mờ dần.
//   • Thẻ trên = đối thủ, thẻ dưới = bạn (khớp với hai thanh PlayerBar của màn chơi online).
//   • KHÔNG chặn thao tác: lớp phủ không nhận cảm ứng nên bạn vẫn kéo quân được ngay (đồng hồ máy chủ vẫn chạy).
//   • Tự tắt khi có nước đi đầu tiên hoặc ván kết thúc.
//   • Chỉ hiện khi ván MỚI bắt đầu (chưa có nước nào). Vào lại ván đang dở thì không hiện.
//   • Chờ tối đa 0,7 giây để tải hồ sơ đối thủ (ảnh, cờ, Elo) rồi mới chạy hiệu ứng → thẻ không bị đổi nội dung giữa chừng.
//
// Gắn vào: Box(Modifier.fillMaxWidth()) { ChessBoard(vm, ui); OnlineVsIntro(..., modifier = Modifier.matchParentSize()) }
// =============================================================================

private const val HOLD_MS = 2800L
private const val READY_WAIT_MS = 700L

/** Dữ liệu một bên đã gom sẵn để vẽ thẻ. */
@Immutable
private data class VsSide(
    val name: String,
    val avatarKey: String,
    val country: String,
    val tier: MembershipTier,
    /** null = chưa biết / không lấy được → không hiện Elo. */
    val elo: Int?,
    val eloLoading: Boolean,
    val white: Boolean,
    /** Khác null → avatar là ảnh VectorDrawable của bot thay vì ảnh hồ sơ. */
    val avatarRes: Int? = null,
)

/**
 * Lớp phủ thẻ VS. Đặt TRONG Box bao quanh bàn cờ và truyền `Modifier.matchParentSize()`.
 *
 * @param oppId id người chơi của đối thủ (null → không tải hồ sơ, chỉ hiện tên + huy hiệu đã biết từ ván đấu)
 * @param mode thể loại Elo của ván đang chơi (Bullet / Blitz / Rapid)
 */
@Composable
internal fun OnlineVsIntro(
    vm: GameViewModel,
    ui: UiState,
    oppId: String?,
    oppName: String,
    oppTier: MembershipTier,
    mode: EloMode,
    modifier: Modifier = Modifier,
) {
    // Mỗi ván (gameId) quyết định một lần: ván mới (chưa có nước) mới hiện.
    val gameId = vm.onlineGameId
    var finished by remember(gameId) { mutableStateOf(ui.sans.isNotEmpty() || ui.over) }
    if (finished) return

    val ctx = LocalContext.current
    val me = remember(vm.stats) { UserSessionManager.profile(ctx, vm.stats, withHistory = false) }
    val oppState: LoadState<UserProfile> =
        if (oppId != null) rememberRemoteProfile(oppId).first else LoadState.Error(ProfileError.NOT_FOUND)
    val opp = (oppState as? LoadState.Success)?.data

    val oppSide = VsSide(
        name = oppName,
        avatarKey = opp?.avatarKey.orEmpty(),
        country = opp?.countryCode.orEmpty(),
        tier = opp?.tier ?: oppTier,
        elo = opp?.elo(mode),
        eloLoading = oppState is LoadState.Loading,
        white = !ui.humanWhite,
    )
    val meSide = VsSide(
        name = "Bạn",
        avatarKey = me.avatarKey,
        country = me.countryCode,
        tier = me.tier,
        elo = me.elo(mode),
        eloLoading = false,
        white = ui.humanWhite,
    )

    VsIntroContent(
        top = oppSide,
        bottom = meSide,
        modeTitle = mode.title,
        opponentReady = oppState !is LoadState.Loading,
        moved = ui.sans.isNotEmpty() || ui.over,
        onFinished = { finished = true },
        modifier = modifier,
    )
}

/**
 * Thẻ VS cho ván với máy (bot / cấp độ / giải đấu): thẻ trên = bot, thẻ dưới = hồ sơ của bạn (ảnh, tên, cờ, Elo).
 * Chỉ hiện khi ván MỚI bắt đầu và chạy lại ở mỗi ván mới (khóa theo vm.gameSerial). Không chặn thao tác.
 * Nếu bot cầm Trắng đi trước, thẻ vẫn giữ đến khi BẠN đi nước đầu tiên (hoặc hết ~2,8 giây).
 */
@Composable
internal fun BotVsIntro(
    vm: GameViewModel,
    ui: UiState,
    botName: String,
    botAvatarRes: Int,
    botElo: Int,
    modifier: Modifier = Modifier,
) {
    val serial = vm.gameSerial
    var finished by remember(serial) { mutableStateOf(ui.sans.isNotEmpty() || ui.over) }
    if (finished) return

    val tier = com.vila.chess.billing.rememberTier()
    val mode = vm.ratingModeNow
    val myName = UserSessionManager.displayName.ifBlank { "Bạn" }
    val humanMoved = ui.sans.size >= (if (ui.humanWhite) 1 else 2)

    val botSide = VsSide(
        name = botName,
        avatarKey = "",
        country = "",
        tier = MembershipTier.FREE,
        elo = botElo,
        eloLoading = false,
        white = !ui.humanWhite,
        avatarRes = botAvatarRes,
    )
    val meSide = VsSide(
        name = myName,
        avatarKey = UserSessionManager.avatarKey,
        country = UserSessionManager.countryCode,
        tier = tier,
        elo = vm.stats.rating(mode),
        eloLoading = false,
        white = ui.humanWhite,
    )

    VsIntroContent(
        top = botSide,
        bottom = meSide,
        modeTitle = mode.label,
        opponentReady = true,
        moved = humanMoved || ui.over,
        onFinished = { finished = true },
        modifier = modifier,
    )
}

@Composable
private fun VsIntroContent(
    top: VsSide,
    bottom: VsSide,
    modeTitle: String,
    opponentReady: Boolean,
    moved: Boolean,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val topP = remember { Animatable(0f) }
    val botP = remember { Animatable(0f) }
    val vsP = remember { Animatable(0f) }
    val exitP = remember { Animatable(0f) }
    var leaving by remember { mutableStateOf(false) }
    val readyNow by rememberUpdatedState(opponentReady)

    LaunchedEffect(Unit) {
        // Chờ hồ sơ đối thủ (tối đa 0,7 giây) để ảnh / cờ / Elo có sẵn trước khi thẻ hiện ra.
        withTimeoutOrNull(READY_WAIT_MS) { snapshotFlow { readyNow }.first { it } }
        coroutineScope {
            launch { topP.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow)) }
            launch { delay(90); botP.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessLow)) }
            launch { delay(260); vsP.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = Spring.StiffnessMedium)) }
        }
        delay(HOLD_MS)
        leaving = true
    }
    LaunchedEffect(moved) { if (moved) leaving = true }
    LaunchedEffect(leaving) {
        if (leaving) {
            exitP.animateTo(1f, tween(280))
            onFinished()
        }
    }

    val density = LocalDensity.current
    val slidePx = with(density) { 56.dp.toPx() }
    val a11y = top.name + (top.elo?.let { " ($it)" } ?: "") + " đấu với " + bottom.name + (bottom.elo?.let { " ($it)" } ?: "")

    BoxWithConstraints(
        modifier = modifier
            .semantics { contentDescription = a11y }
            .drawBehind {
                // Màn mờ nhẹ phủ bàn cờ: hiện theo thẻ trên, tắt theo exitP. Đọc ở bước vẽ → không vẽ lại cả cây.
                val a = 0.38f * topP.value.coerceIn(0f, 1f) * (1f - exitP.value)
                drawRect(Color.Black.copy(alpha = a))
            },
    ) {
        val cardW = (maxWidth * 0.46f).coerceIn(140.dp, 210.dp)
        val avatar = (maxWidth * 0.13f).coerceIn(40.dp, 56.dp)

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    val e = exitP.value
                    alpha = 1f - e
                    scaleX = 1f - 0.04f * e
                    scaleY = 1f - 0.04f * e
                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy((-14).dp),
        ) {
            VsPlayerCard(
                side = top,
                avatarSize = avatar,
                modifier = Modifier
                    .width(cardW)
                    .graphicsLayer {
                        val p = topP.value
                        translationY = -(1f - p) * slidePx
                        alpha = p.coerceIn(0f, 1f)
                    },
            )
            VsBadge(
                modifier = Modifier
                    .zIndex(1f)
                    .graphicsLayer {
                        val s = vsP.value
                        scaleX = s
                        scaleY = s
                        rotationZ = (1f - s) * -24f
                    },
            )
            VsPlayerCard(
                side = bottom,
                avatarSize = avatar,
                modifier = Modifier
                    .width(cardW)
                    .graphicsLayer {
                        val p = botP.value
                        translationY = (1f - p) * slidePx
                        alpha = p.coerceIn(0f, 1f)
                    },
            )
            Box(
                modifier = Modifier
                    .padding(top = 22.dp)
                    .graphicsLayer { alpha = vsP.value.coerceIn(0f, 1f) }
                    .clip(CircleShape)
                    .background(Color(0x99000000))
                    .padding(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text("Elo $modeTitle", color = VilaColors.TextDim, style = VilaText.Caption)
            }
        }
    }
}

/** Một thẻ người chơi: avatar, tên + huy hiệu VIP, cờ quốc gia, Elo, ô màu quân. */
@Composable
private fun VsPlayerCard(side: VsSide, avatarSize: Dp, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier = modifier
            .shadow(14.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF3B3935), Color(0xFF2B2926))))
            .border(1.dp, Color(0x1FFFFFFF), shape)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        AnimatedAvatarFrame(
            seed = if (side.white) 0 else 1, active = true, ringShape = CircleShape,
            motion = com.vila.chess.bots.BotMotions.forAvatarRes(side.avatarRes),
        ) {
            if (side.avatarRes != null) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(side.avatarRes),
                    contentDescription = null,
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier
                        .size(avatarSize)
                        .clip(CircleShape)
                        .border(2.dp, Color(0x33FFFFFF), CircleShape),
                )
            } else {
                ProfileAvatar(name = side.name, avatarKey = side.avatarKey, size = avatarSize)
            }
        }
        NameWithBadge(name = side.name, tier = side.tier, fontSize = 15f, badgeSize = 16.dp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val flag = Countries.flag(side.country)
            if (flag.isNotEmpty()) Text(flag, fontSize = 15.sp)
            EloPill(side.elo, side.eloLoading)
            SideSquare(side.white)
        }
    }
}

/** Viên Elo: số khi có, "···" khi đang tải, ẩn hẳn khi không lấy được. */
@Composable
private fun EloPill(elo: Int?, loading: Boolean) {
    if (elo == null && !loading) return
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(VilaColors.PanelDark)
            .padding(horizontal = 9.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = elo?.toString() ?: "···",
            color = if (elo != null) VilaColors.Text else VilaColors.TextDim,
            style = TextStyle(fontFeatureSettings = "tnum", fontWeight = FontWeight.ExtraBold, fontSize = 13.sp),
        )
    }
}

/** Ô nhỏ cho biết cầm quân trắng hay đen. */
@Composable
private fun SideSquare(white: Boolean) {
    val desc = if (white) "Cầm quân trắng" else "Cầm quân đen"
    Box(
        modifier = Modifier
            .size(14.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(if (white) Color(0xFFF4F3EF) else Color(0xFF1B1A18))
            .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(3.dp))
            .semantics { contentDescription = desc },
    )
}

/** Nút tròn "VS" màu xanh VILA, có cạnh dưới dày tạo cảm giác nổi như các nút khác trong app. */
@Composable
private fun VsBadge(modifier: Modifier = Modifier) {
    Box(modifier = modifier.size(52.dp), contentAlignment = Alignment.TopCenter) {
        Box(Modifier.offset(y = 3.dp).size(48.dp).clip(CircleShape).background(VilaColors.GreenShadow))
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(VilaBrushes.ButtonFace)
                .border(1.dp, Color(0x40FFFFFF), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "VS",
                color = Color(0xFF1F3312),
                style = TextStyle(fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 18.sp, letterSpacing = 0.sp),
            )
        }
    }
}
