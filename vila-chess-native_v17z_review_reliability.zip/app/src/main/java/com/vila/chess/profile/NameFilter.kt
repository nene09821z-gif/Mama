package com.vila.chess.profile

import java.text.Normalizer
import java.util.Locale

/**
 * Bộ lọc tên bậy (tiếng Việt + tiếng Anh) cho tên hiển thị. Thuần Kotlin, không phụ thuộc Android nên test được trên JVM.
 *
 * Cách làm (ưu tiên KHÔNG chặn nhầm tên thật, rồi mới đến bắt được nhiều kiểu né):
 *  1. Chuẩn hóa: bỏ ký tự vô hình, NFKC (chữ full-width), chữ thường, bỏ dấu tiếng Việt (đ -> d), đổi chữ Kirin giống Latin,
 *     đổi kiểu viết lách (0->o 1->i 3->e 4->a 5->s 7->t @->a $->s !->i).
 *  2. So khớp:
 *     - [TOKENS]: khớp NGUYÊN CẢ TỪ (tách theo dấu cách/dấu câu) -> "Hancock", "Dickson", "Takeshita" không bị chặn.
 *     - [PHRASES]: dãy từ liền nhau ("dit me", "con cho").
 *     - [STRONG]: chuỗi dài, tìm trong chuỗi đã dồn liền -> bắt "f u c k", "xXfuckXx", "fuuuck".
 *     - Chữ cái lẻ cách nhau ("đ.m", "s h i t") được ghép lại rồi mới so.
 *  3. [ORIGINAL_BAD]: từ chỉ xấu khi ĐÚNG dấu (đĩ, đéo, đụ...). [ALLOW]: từ hợp lệ bỏ dấu lại trùng từ cấm (bưởi, lớn, ngư...).
 *
 * Danh sách bên dưới được sinh từ nf/lists.py; sửa ở đó rồi sinh lại, hoặc sửa thẳng ở đây (nhớ sửa cả supabase/name_filter.sql).
 */
object NameFilter {
    const val MESSAGE = "Tên chứa từ không phù hợp, hãy chọn tên khác"

    // ----------------------------------------------------------------------------- DANH SÁCH
    private val TOKENS = hashSetOf(
        "ditme", "dmm", "dcm", "dcmm", "dkm", "dkmm", "vcl", "vkl", "vl", "vlz",
        "cmm", "cmn", "clgt", "cac", "cak", "lon", "loz", "buoi", "concac", "dick", "cock",
        "ass", "porn", "sex", "hentai", "rape", "rapist", "nazi", "kkk", "tits", "boobs",
        "fag", "slut", "cum", "twat", "prick", "shit", "shitty", "chink", "gook", "spic",
        "tranny", "cunt", "cunts", "fck", "fuk", "fvck", "milf", "dildo", "nude", "nudes",
        "xxx", "horny", "bdsm", "pedo",
    )

    /**
     * Từ ngắn dễ trùng tên thật / tên viết tắt ("Dm", "DM Chess", "Lê Đình Dit"): đứng riêng thì KHÔNG chặn,
     * chỉ chặn khi bị ghép từ chữ cái lẻ ("d.m", "D M", "d i t"). "địt" có dấu nằm trong [ORIGINAL_BAD].
     */
    private val JOINED_ONLY = hashSetOf("dm", "dit")

    private val PHRASES = listOf(
        "dit me", "dit con me", "dit cu", "du ma", "du me", "dau buoi", "me may", "con cho",
        "thang cho", "cho chet", "oc cho", "thang ngu", "con ngu", "do ngu", "suc vat",
        "khon nan", "vai lon", "white power",
    )

    private val STRONG = listOf(
        "fuck", "bitch", "nigger", "nigga", "faggot", "whore", "asshole", "bastard",
        "bollocks", "wanker", "jizz", "pedophile", "paedophile", "retard", "hitler",
        "dickhead", "cocksucker", "bullshit", "shithead", "dipshit", "pussy", "ditme",
        "ditmay", "ditcon", "dumamay", "dumemay", "daubuoi",
    )

    private val ORIGINAL_BAD = hashSetOf(
        "đĩ", "đéo", "đụ", "điếm", "địt",
    )

    private val ALLOW = hashSetOf(
        "bưởi", "buổi", "bưới", "lớn", "ngư", "các",
    )

    // ----------------------------------------------------------------------------- THUẬT TOÁN
    private val INVISIBLE = Regex("[\\u200B-\\u200D\\u2060\\uFEFF\\u00AD]")
    private val SPLIT_A = Regex("[^\\p{L}\\p{N}]+")            // mọi ký hiệu là dấu tách
    private val SPLIT_B = Regex("[^\\p{L}\\p{N}@\$!]+")        // @ $ ! được coi là chữ (kiểu viết lách)
    private val MARKS = Regex("\\p{Mn}+")
    private val RUN3 = Regex("(.)\\1{2,}")

    @Volatile private var memo: Pair<String, Boolean>? = null

    /** true nếu [raw] chứa từ không phù hợp. Có nhớ kết quả gần nhất vì UserSessionManager.displayName được đọc rất nhiều lần. */
    fun isOffensive(raw: String): Boolean {
        memo?.let { if (it.first == raw) return it.second }
        val r = check(raw)
        memo = raw to r
        return r
    }

    private fun check(raw: String): Boolean {
        val base = Normalizer.normalize(INVISIBLE.replace(raw, ""), Normalizer.Form.NFKC).lowercase(Locale.ROOT)
        if (SPLIT_A.split(base).any { it in ORIGINAL_BAD }) return true
        for (split in listOf(SPLIT_A, SPLIT_B)) {
            val toks = split.split(base).filter { it.isNotEmpty() }.map { if (it in ALLOW) "#" else fold(it) }
            if (hits(toks)) return true
        }
        return strong(base)
    }

    private fun mapChar(c: Char): Char = when (c) {
        '\u0111' -> 'd'                         // đ
        '0' -> 'o'
        '1' -> 'i'
        '3' -> 'e'
        '4' -> 'a'
        '5' -> 's'
        '7' -> 't'
        '@' -> 'a'
        '\$' -> 's'
        '!' -> 'i'
        '\u0430' -> 'a'                         // Kirin giống Latin: а е о р с х у і
        '\u0435' -> 'e'
        '\u043E' -> 'o'
        '\u0440' -> 'p'
        '\u0441' -> 'c'
        '\u0445' -> 'x'
        '\u0443' -> 'y'
        '\u0456' -> 'i'
        else -> c
    }

    /** Bỏ dấu + đổi kiểu viết lách cho MỘT từ. */
    private fun fold(token: String): String {
        val sb = StringBuilder(token.length)
        for (ch in MARKS.replace(Normalizer.normalize(token, Normalizer.Form.NFD), "")) sb.append(mapChar(ch))
        return sb.toString()
    }

    /** "shiiit" -> "shit" / "shiit": gom chuỗi lặp 3+ ký tự về 1 hoặc 2 ký tự. */
    private fun variants(t: String): List<String> {
        val one = RUN3.replace(t) { it.groupValues[1] }
        val two = RUN3.replace(t) { it.groupValues[1] + it.groupValues[1] }
        return listOf(t, one, two).distinct()
    }

    private fun hits(toks: List<String>): Boolean {
        val all = ArrayList<String>(toks)
        val joined = ArrayList<String>()   // chuỗi ghép từ chữ lẻ: được so thêm với JOINED_ONLY
        // Cả tên chỉ gồm chữ cái lẻ ("đ.m", "v c l") hoặc một dãy 3+ chữ lẻ ("s h i t") -> ghép lại.
        if (toks.size >= 2 && toks.all { it.length == 1 && it != "#" }) joined.add(toks.joinToString(""))
        val run = StringBuilder()
        for (t in toks + "") {                  // "" là mốc kết thúc
            if (t.length == 1 && t != "#") run.append(t)
            else {
                if (run.length >= 3) joined.add(run.toString())
                run.setLength(0)
            }
        }
        if (all.any { t -> variants(t).any { it in TOKENS } }) return true
        if (joined.any { t -> variants(t).any { it in TOKENS || it in JOINED_ONLY } }) return true
        val line = " " + toks.joinToString(" ") + " "
        return PHRASES.any { " $it " in line }
    }

    /** Dồn toàn tên thành một chuỗi a-z liền nhau rồi tìm các chuỗi dài trong [STRONG]. */
    private fun strong(base: String): Boolean {
        val sb = StringBuilder()
        for (ch in MARKS.replace(Normalizer.normalize(base, Normalizer.Form.NFD), "")) {
            val m = mapChar(ch)
            if (m in 'a'..'z') sb.append(m)
        }
        return variants(sb.toString()).any { v -> STRONG.any { it in v } }
    }
}
