package com.vila.chess.review

/**
 * Tóm tắt "engine thực sự chạy thế nào" trong một lần phân tích ván, để debug khi nhãn bị lệch trên từng máy.
 * Hàm thuần (không Android, không engine) nên test được trên JVM; [GameAnalysisWorker] chỉ việc ghi ra Logcat (tag "GameAnalysis").
 *
 * Chỉ tính các thế engine THẬT SỰ tìm (bỏ qua thế do luật quyết định: chiếu hết / hòa, engine = "rules").
 */
data class AnalysisDiagnostics(
    val tier: String,
    val configDepth: Int,
    val configThreads: Int,
    val configHashMb: Int,
    val configTimeoutMs: Long,
    val engines: List<String>,
    /** Số thế engine đã tìm (không tính thế do luật). */
    val searched: Int,
    val minDepth: Int,
    val avgDepth: Double,
    val maxDepth: Int,
    /** Số thế dừng vì hết giờ (chưa chạm depth trần). */
    val timedOut: Int,
    /** Số thế có độ sâu < [LabelEvidence] mức "tin hoàn toàn" nhưng đủ để giữ nhãn nặng (độ sâu <= 9 thì nhãn nặng/chói bị hạ bậc). */
    val shallowForLabels: Int,
    /** Số thế có độ sâu < [MoveClassifier.BRILLIANT_MIN_DEPTH] (nước ở đó không thể là Brilliant, trừ chiếu hết). */
    val belowBrilliantDepth: Int,
    /** MultiPV cấu hình (giá trị lớn nhất thấy được) và số thế THỰC SỰ có nước tốt nhì. */
    val multiPvConfigured: Int,
    val withSecondLine: Int,
) {
    val secondLineCoverage: Double get() = if (searched == 0) 1.0 else withSecondLine.toDouble() / searched
    val belowBrilliantShare: Double get() = if (searched == 0) 0.0 else belowBrilliantDepth.toDouble() / searched

    /** Cảnh báo (rỗng = ổn): các tình huống làm nhãn dễ lệch. */
    fun warnings(): List<String> = buildList {
        if (searched == 0) return@buildList
        if (multiPvConfigured >= 2 && secondLineCoverage < MIN_SECOND_LINE_COVERAGE)
            add("chỉ ${withSecondLine}/$searched thế có nước tốt nhì (MultiPV) → Great/Brilliant/Miss ít tin cậy")
        if (multiPvConfigured < 2) add("MultiPV = $multiPvConfigured → không có Great/Brilliant")
        if (belowBrilliantShare > MAX_SHALLOW_SHARE)
            add("$belowBrilliantDepth/$searched thế có độ sâu < ${MoveClassifier.BRILLIANT_MIN_DEPTH} → Brilliant bị giới hạn")
        if (shallowForLabels > 0)
            add("$shallowForLabels thế có độ sâu <= ${LabelEvidence.SHAKY_MAX_DEPTH} → nhãn nặng/chói bị hạ bậc")
        if (timedOut * 2 > searched)
            add("hơn nửa số thế dừng vì hết giờ ($timedOut/$searched) → máy chậm so với trần depth $configDepth")
    }

    /** Một dòng log gọn. */
    fun summary(): String =
        "tier=$tier cfg[depth=$configDepth threads=$configThreads hash=${configHashMb}MB timeout=${configTimeoutMs}ms] " +
            "engine=${engines.joinToString("+").ifEmpty { "none" }} searched=$searched " +
            "depth[min=$minDepth avg=${"%.1f".format(java.util.Locale.ROOT, avgDepth)} max=$maxDepth] timedOut=$timedOut " +
            "multiPV=$multiPvConfigured secondLine=$withSecondLine/$searched(${(secondLineCoverage * 100).toInt()}%) " +
            "<d${MoveClassifier.BRILLIANT_MIN_DEPTH}=$belowBrilliantDepth <=d${LabelEvidence.SHAKY_MAX_DEPTH}=$shallowForLabels"

    companion object {
        const val MIN_SECOND_LINE_COVERAGE = 0.8
        const val MAX_SHALLOW_SHARE = 0.3

        fun from(config: EngineConfig, evals: List<EngineResult>): AnalysisDiagnostics {
            val real = evals.filter { it.engine != MoveReview.ENGINE_RULES }
            val depths = real.map { it.depthReached }
            return AnalysisDiagnostics(
                tier = config.tier.name,
                configDepth = config.depth,
                configThreads = config.threads,
                configHashMb = config.hashMb,
                configTimeoutMs = config.moveTimeoutMs,
                engines = real.map { it.engine }.distinct(),
                searched = real.size,
                minDepth = depths.minOrNull() ?: 0,
                avgDepth = if (depths.isEmpty()) 0.0 else depths.average(),
                maxDepth = depths.maxOrNull() ?: 0,
                timedOut = real.count { it.timedOut },
                shallowForLabels = depths.count { it in 1..LabelEvidence.SHAKY_MAX_DEPTH },
                belowBrilliantDepth = depths.count { it < MoveClassifier.BRILLIANT_MIN_DEPTH },
                multiPvConfigured = real.maxOfOrNull { it.multiPv } ?: 1,
                withSecondLine = real.count { it.secondMove != null },
            )
        }
    }
}
