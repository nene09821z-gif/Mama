package com.vila.chess

import com.vila.chess.review.AnalysisDiagnostics
import com.vila.chess.review.DeviceTier
import com.vila.chess.review.EngineConfig
import com.vila.chess.review.EngineResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AnalysisDiagnosticsTest {

    private val cfg = EngineConfig(DeviceTier.LOW, depth = 14, threads = 1, hashMb = 16, moveTimeoutMs = 800L)

    private fun ev(depth: Int, second: Boolean = true, timedOut: Boolean = false, mpv: Int = 2, engine: String = "native") = EngineResult(
        bestMove = "e2e4", scoreCp = 20, mate = null, depthReached = depth, timedOut = timedOut,
        secondMove = if (second) "d2d4" else null, secondCp = if (second) 10 else null, engine = engine, multiPv = mpv,
    )

    private val rules = EngineResult(null, -10_000, 0, 0, false, engine = "rules")

    @Test
    fun summarisesRealDepthsAndIgnoresRuleDecidedPositions() {
        val d = AnalysisDiagnostics.from(cfg, listOf(ev(8), ev(12), ev(16), rules))
        assertEquals(3, d.searched)
        assertEquals(8, d.minDepth)
        assertEquals(12.0, d.avgDepth, 1e-9)
        assertEquals(16, d.maxDepth)
        assertEquals(listOf("native"), d.engines)
        assertEquals(1, d.shallowForLabels)        // depth 8 <= 9
        assertEquals(1, d.belowBrilliantDepth)     // depth 8 < 12
        assertEquals("LOW", d.tier)
        assertEquals(14, d.configDepth)
    }

    @Test
    fun healthyRunHasNoWarnings() {
        val d = AnalysisDiagnostics.from(cfg, List(10) { ev(15) })
        assertTrue(d.warnings().isEmpty())
        assertTrue(d.summary().contains("tier=LOW"))
        assertTrue(d.summary().contains("secondLine=10/10(100%)"))
    }

    @Test
    fun warnsWhenMultiPvLinesAreMissing() {
        val d = AnalysisDiagnostics.from(cfg, List(10) { ev(15, second = it < 5) })
        assertEquals(5, d.withSecondLine)
        assertTrue(d.warnings().any { it.contains("MultiPV") })
    }

    @Test
    fun warnsWhenMultiPvIsOne() {
        val d = AnalysisDiagnostics.from(cfg, List(4) { ev(15, second = false, mpv = 1) })
        assertEquals(1, d.multiPvConfigured)
        assertTrue(d.warnings().any { it.contains("MultiPV = 1") })
    }

    @Test
    fun warnsWhenTooShallowOrTimedOut() {
        val d = AnalysisDiagnostics.from(cfg, List(10) { ev(10, timedOut = it < 6) })
        val w = d.warnings()
        assertTrue(w.any { it.contains("độ sâu <") })
        assertTrue(w.any { it.contains("hết giờ") })
        assertFalse(w.any { it.contains("MultiPV") })
    }

    @Test
    fun emptyOrAllRuleGameDoesNotCrash() {
        val d = AnalysisDiagnostics.from(cfg, listOf(rules))
        assertEquals(0, d.searched)
        assertTrue(d.warnings().isEmpty())
        assertTrue(d.summary().contains("engine=none"))
        assertEquals(1.0, d.secondLineCoverage, 0.0)
    }
}
