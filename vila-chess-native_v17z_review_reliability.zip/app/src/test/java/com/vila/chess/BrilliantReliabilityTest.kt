package com.vila.chess

import com.vila.chess.review.EngineResult
import com.vila.chess.review.LabelEvidence
import com.vila.chess.review.MoveClassifier
import com.vila.chess.review.MoveLabel
import com.vila.chess.review.ReviewAssembler
import com.vila.chess.review.ReviewReplay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Brilliant trên máy yếu: engine tìm nông / thiếu MultiPV thì không được gán nhầm. */
class BrilliantReliabilityTest {

    private fun cls(
        before: Double, after: Double, second: String? = "d2d4", epSecond: Double? = 0.30,
        mate: Int? = null, minDepth: Int = MoveClassifier.NO_DEPTH_INFO,
    ) = MoveClassifier.classifyMove(
        epBefore = before, epAfter = after, movePlayed = "e2e4", bestMove = "e2e4", secondBestMove = second,
        isSacrifice = true, isOpponentJustBlundered = false, epSecondBest = epSecond, mateAfter = mate, minDepth = minDepth,
    )

    @Test
    fun brilliantNeedsEnoughDepthWhenNotMate() {
        val d = MoveClassifier.BRILLIANT_MIN_DEPTH
        assertEquals(MoveLabel.BRILLIANT, cls(0.60, 0.60, minDepth = d))
        // nông hơn một bậc: không Brilliant; nước tốt nhất lệch xa nước tốt nhì (30%) => rơi xuống Great
        assertEquals(MoveLabel.GREAT, cls(0.60, 0.60, minDepth = d - 1))
        assertEquals(MoveLabel.GREAT, cls(0.60, 0.60, minDepth = 6))
    }

    @Test
    fun overwhelmingBranchAlsoNeedsDepth() {
        assertEquals(MoveLabel.BRILLIANT, cls(0.97, 0.97, second = null, epSecond = null, minDepth = 14))
        assertEquals(MoveLabel.BEST, cls(0.97, 0.97, second = null, epSecond = null, minDepth = 8))
    }

    @Test
    fun matingSacrificeStaysBrilliantEvenWhenShallow() {
        // điểm mate đã được chứng minh, không phụ thuộc độ sâu
        assertEquals(MoveLabel.BRILLIANT, cls(1.0, 1.0, mate = 3, minDepth = 5))
        assertEquals(MoveLabel.BRILLIANT, cls(1.0, 1.0, mate = 0, minDepth = 3))
        // mate ÂM (mình sắp bị mate) thì không tính
        assertEquals(MoveLabel.BEST, cls(1.0, 1.0, second = null, epSecond = null, mate = -2, minDepth = 5))
    }

    @Test
    fun withoutSecondLineAlternativeIsNotGuessed() {
        // đã đi nước tốt nhất mà không biết nước thay thế (thiếu MultiPV): không đoán => không Brilliant (nhánh thường)
        assertEquals(MoveLabel.BEST, cls(0.60, 0.60, second = null, epSecond = null, minDepth = 18))
        // có nước tốt nhì => Brilliant
        assertEquals(MoveLabel.BRILLIANT, cls(0.60, 0.60, minDepth = 18))
        // nước tốt nhì cũng thắng đậm (92%) => không phải nước duy nhất
        assertEquals(MoveLabel.BEST, cls(0.93, 0.93, epSecond = 0.92, minDepth = 18))
    }

    @Test
    fun noDepthInfoKeepsOldBehaviour() {
        assertEquals(MoveLabel.BRILLIANT, cls(0.60, 0.60))
    }

    @Test
    fun searchDepthUsesTheShallowerKnownSearch() {
        assertEquals(10, MoveClassifier.searchDepth(10, 14))
        assertEquals(10, MoveClassifier.searchDepth(14, 10))
        // thế do luật quyết định (depth 0) không kéo độ sâu xuống 0
        assertEquals(14, MoveClassifier.searchDepth(0, 14))
        assertEquals(14, MoveClassifier.searchDepth(14, 0))
        assertEquals(MoveClassifier.NO_DEPTH_INFO, MoveClassifier.searchDepth(0, 0))
    }

    @Test
    fun brilliantThresholdIsStricterThanLabelSofteningAndShakyConstantMatches() {
        assertTrue(MoveClassifier.BRILLIANT_MIN_DEPTH > LabelEvidence.SHAKY_MAX_DEPTH)
        assertTrue(LabelEvidence.depthConfidence(LabelEvidence.SHAKY_MAX_DEPTH) < LabelEvidence.SHAKY_BELOW)
        assertTrue(LabelEvidence.depthConfidence(LabelEvidence.SHAKY_MAX_DEPTH + 1) >= LabelEvidence.SHAKY_BELOW)
    }

    // ---------------------------------------------------------------- cả ván (smothered mate)

    private val startFen = "r1b1kb1r/p1p1pppp/2p5/8/3q2n1/8/PPPN2PP/RNBQ1R1K w kq - 0 10"
    private val ucis = listOf("f1e1", "g4f2", "h1g1", "f2h3", "g1h1", "d4g1", "e1g1", "h3f2")

    private fun ev(depth: Int, best: String?, cp: Int, mate: Int? = null, second: String? = null, secondCp: Int? = null) = EngineResult(
        bestMove = best,
        scoreCp = if (mate != null && mate != 0) (if (mate > 0) 10_000 - 10 * mate else -10_000 - 10 * mate) else cp,
        mate = mate, depthReached = depth, timedOut = false, pv = listOfNotNull(best),
        secondMove = second, secondCp = secondCp, secondMate = null, engine = "native", multiPv = 2,
    )

    /** [qg1AfterMate] = true: sau 12...Qg1+ engine báo mate; false: chỉ báo điểm (+6 cho Đen), không mate. */
    private fun labels(depth: Int, qg1AfterMate: Boolean): List<MoveLabel> {
        val evals = listOf(
            ev(depth, "d1f3", -500, second = "d2f3", secondCp = -520),
            ev(depth, "g4f2", 0, mate = 4, second = "d4f2", secondCp = 800),
            ev(depth, "h1g1", 0, mate = -3),
            ev(depth, "f2h3", 0, mate = 3, second = "d4g1", secondCp = 600),
            ev(depth, "g1h1", 0, mate = -2),
            ev(depth, "d4g1", 0, mate = 2, second = "d4d2", secondCp = 350),
            if (qg1AfterMate) ev(depth, "e1g1", 0, mate = -1) else ev(depth, "e1g1", -600),
            ev(depth, "h3f2", 0, mate = 1, second = "h3g1", secondCp = -300),
            EngineResult(null, -10_000, 0, 0, false, engine = "rules"),
        )
        val replay = ReviewReplay.replay(startFen, ucis)!!
        return ReviewAssembler.assemble("t", replay.startFen, replay.plies, evals, "LOW", 0L).moves.map { it.label }
    }

    @Test
    fun matingQueenSacrificeIsBrilliantEvenOnWeakDevice() {
        assertEquals(MoveLabel.BRILLIANT, labels(depth = 8, qg1AfterMate = true)[5])
        assertEquals(MoveLabel.BRILLIANT, labels(depth = 18, qg1AfterMate = true)[5])
    }

    @Test
    fun scoreBasedBrilliantNeedsDepthEndToEnd() {
        // cùng hy sinh hậu nhưng engine chỉ báo điểm (không mate): sâu thì Brilliant, nông thì không
        assertEquals(MoveLabel.BRILLIANT, labels(depth = 18, qg1AfterMate = false)[5])
        val shallow = labels(depth = 10, qg1AfterMate = false)[5]
        assertTrue("độ sâu 10 không được Brilliant, nhận $shallow", shallow != MoveLabel.BRILLIANT)
        assertEquals(MoveLabel.GREAT, shallow)
    }
}
