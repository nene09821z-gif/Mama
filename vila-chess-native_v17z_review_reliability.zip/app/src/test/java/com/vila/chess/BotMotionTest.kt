package com.vila.chess

import com.vila.chess.bots.BotMotionData
import com.vila.chess.bots.BotMotions
import com.vila.chess.bots.BotRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertTrue
import org.junit.Test

class BotMotionTest {
    @Test fun every_bot_has_generated_motion() {
        val missing = BotRepository.bots.filter { it.id !in BotMotionData.byId }.map { it.id }
        assertTrue("Bot thiếu chuyển động (chạy scripts/gen_bot_motion.py): $missing", missing.isEmpty())
    }

    @Test fun motion_values_are_sane() {
        for ((id, m) in BotMotionData.byId) {
            assertTrue("$id breathMs", m.breathMs in 1000..4000)
            assertTrue("$id breathScale", m.breathScale in 0.005f..0.08f)
            assertTrue("$id swayDeg", m.swayDeg in 0.5f..8f)
            assertTrue("$id hopDp", m.hopDp in 2f..14f)
            assertTrue("$id shakeDp", m.shakeDp in 1f..8f)
        }
    }

    @Test fun weak_bots_move_more_than_strong_bots() {
        val weak = BotMotions.forBot("martin")
        val strong = BotMotions.forBot("mittens")
        assertTrue(weak.breathMs < strong.breathMs)
        assertTrue(weak.hopDp > strong.hopDp)
    }

    @Test fun unknown_or_null_falls_back_to_default() {
        assertEquals(BotMotions.forBot(null), BotMotions.forBot("khong-co"))
        assertEquals(BotMotions.forAvatarRes(null), BotMotions.forBot(null))
    }
}
