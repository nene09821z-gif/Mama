# v16c – Premove ăn quân kiểu chess.com, hết "nhảy về chỗ cũ", bớt khựng

## 1. Quân nhảy về chỗ cũ khi thả premove (BoardView + GameViewModel)
- Nguyên nhân: đối thủ (bot/online) đi NGAY giữa lúc ngón tay đang kéo quân premove -> `refreshUi()` xóa `selected/targets`
  -> lúc thả tay `ui.targets` rỗng nên nước bị coi là sai -> quân trượt về ô cũ, premove không được đặt.
- Sửa:
  - `GameViewModel.dragTargets(sq)`: luôn tính lại ô đích theo lượt HIỆN TẠI (nước thật khi tới lượt mình, premove khi chưa tới).
  - `releaseDrag()` trả về Boolean (nhận / từ chối); `BoardView` dùng kết quả này để quyết định quân ở lại ô đích hay trượt về.
  - `restoreSelection()`: sau khi đối thủ đi / premove chạy xong, giữ lại quân đang chọn và tính lại chấm ô đích (không xóa).
  - Quân đang kéo bị đối thủ ăn mất: không vẽ quân "ma" bay về ô cũ.

## 2. Premove chậm
- Bỏ `delay(60)` trước khi chạy premove trong `playEngine`: premove chạy ngay trong cùng frame với nước đối thủ.
  Hiệu ứng trượt của nước đối thủ vẫn giữ (`carrySlides`).

## 3. Khựng khi máy đang nghĩ
- `BotEngineManager`: Stockfish của bot chạy qua `/system/bin/nice -n 10` (tự rơi về chạy thường nếu máy không có), tối đa 2 luồng.
- Engine Kotlin dự phòng: hạ ưu tiên luồng tìm nước (`THREAD_PRIORITY_BACKGROUND`) và trả lại khi xong.

## 4. Luật premove ăn quân (core/Position.kt)
- `generatePremoveMoves()` (+ `generatePseudoCopyForPremove` giữ tên cũ) và `applyPremoveOnCopy()` dùng chung bộ sinh nước mới:
  - Được premove vào ô có quân MÌNH nếu ô đó đang bị đối thủ đe dọa => "ăn lại" (recapture) như chess.com.
  - Tốt chéo được vào ô có quân (địch, hoặc quân mình đang bị đe dọa); đi thẳng chỉ vào ô trống.
  - Quân trượt dừng ở quân đầu tiên gặp (không đi xuyên).
- Test mới trong `PremoveQueueTest`: ăn lại vào ô quân mình, không vào ô quân mình không bị đe dọa.

## 5. Sửa lỗi build `Platform declaration clash` (TeacherController.kt)
- `setPersona` / `setTalkiness` trùng chữ ký JVM với setter private của thuộc tính `by mutableStateOf` cùng tên
  -> thêm `@JvmName("applyPersona")` / `@JvmName("applyTalkiness")` (nơi gọi Kotlin không đổi).
