package com.vila.chess.ui

import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.rememberTier
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.game.GameViewModel
import com.vila.chess.magic.MagicCard
import com.vila.chess.magic.MagicCatalog
import com.vila.chess.magic.MagicGame
import com.vila.chess.magic.MagicResult
import com.vila.chess.magic.MagicState
import com.vila.chess.magic.Rarity
import com.vila.chess.magic.idx
import com.vila.chess.magic.pieceNameVi
import com.vila.chess.magic.sideName
import kotlin.math.roundToInt

/** Ván Cờ Phép Thuật nằm trong ViewModel riêng để không mất khi xoay màn hình; không đụng tới GameViewModel của ván thường. */
class MagicChessViewModel : ViewModel() {
    var game by mutableStateOf(MagicGame())
        private set
    /** Tăng sau mỗi thao tác để giao diện vẽ lại (MagicGame là đối tượng thường, không phải state). */
    var tick by mutableIntStateOf(0)
        private set
    /** Chế độ chuyền máy: bài chỉ hiện sau khi người chơi chạm xác nhận. */
    var revealed by mutableStateOf(false)

    fun bump() { tick++ }
    fun newGame(tier: MembershipTier = game.tier) { game = MagicGame(tier = tier); revealed = false; tick++ }

    /** Gói đổi (mua/hết hạn) trước nước đi đầu tiên → dựng lại bộ bài cho đúng gói. */
    fun syncTier(tier: MembershipTier) { if (game.tier != tier && game.s.turnNo == 0) newGame(tier) }
}

private val Purple = Color(0xFFB37DE8)

private fun rarityColor(r: Rarity) = when (r) {
    Rarity.COMMON -> Color(0xFFBABABA)
    Rarity.UNCOMMON -> Color(0xFF81B64C)
    Rarity.RARE -> Color(0xFF4F9DE8)
    Rarity.EPIC -> Purple
    Rarity.LEGENDARY -> Color(0xFFF2B134)
}

@Composable
fun MagicChessScreen(gvm: GameViewModel, onBack: () -> Unit) {
    val mvm: MagicChessViewModel = viewModel()
    val tier = rememberTier()
    LaunchedEffect(tier) { mvm.syncTier(tier) }
    mvm.tick   // đăng ký đọc để vẽ lại khi có thay đổi
    val game = mvm.game
    val s = game.s
    val white = game.whiteToMove
    val images = gvm.pieceImages
    // 3 lá bài mở ra đầu lượt (rỗng sau khi đã chọn / bỏ qua)
    val offers = s.offers[idx(white)].toList()

    var selSq by remember { mutableIntStateOf(-1) }
    var castIdx by remember { mutableIntStateOf(-1) }
    var chosen by remember { mutableStateOf(listOf<Int>()) }
    var promo by remember { mutableStateOf<List<Int>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var showRules by remember { mutableStateOf(false) }
    var showResult by remember(game.result) { mutableStateOf(game.result != null) }
    var confirmExit by remember { mutableStateOf(false) }
    var offerSel by remember { mutableIntStateOf(-1) }

    // Đổi lượt: bỏ chọn và che bài cho lượt mới (chuyền máy).
    LaunchedEffect(s.turnNo) { selSq = -1; castIdx = -1; chosen = emptyList(); offerSel = -1; mvm.revealed = false }

    fun reset() { selSq = -1; castIdx = -1; chosen = emptyList(); offerSel = -1 }

    fun after(error: String? = null) {
        message = error ?: game.notice
        mvm.bump()
    }

    fun onTap(sq: Int) {
        if (game.result != null) return
        if (offers.isNotEmpty()) { message = "Chọn 1 trong ${offers.size} lá bài mới (hoặc Bỏ qua) trước khi đi"; return }
        if (castIdx >= 0) {
            val card = game.card(castIdx) ?: run { reset(); return }
            if (sq in game.spellTargets(card, chosen)) {
                val next = chosen + sq
                if (next.size >= game.stepsOf(card)) {
                    val err = game.castSpell(castIdx, next)
                    reset(); after(err)
                } else chosen = next
            }
            return
        }
        if (selSq >= 0) {
            val mv = game.movesFrom(selSq).filter { moveTo(it) == sq }
            if (mv.size == 1) { selSq = -1; game.playMove(mv[0]); after(); return }
            if (mv.size > 1) { promo = mv; return }
        }
        selSq = if (s.own(sq, white) && game.movesFrom(sq).isNotEmpty()) sq else -1
    }

    BackHandler { if (castIdx >= 0) reset() else confirmExit = true }

    val card = if (castIdx >= 0) game.card(castIdx) else null
    val targets = if (card != null) game.spellTargets(card, chosen) else emptyList()
    val legalTo = if (selSq >= 0 && card == null) game.movesFrom(selSq).map { moveTo(it) }.toSet() else emptySet()

    Column(Modifier.fillMaxSize().background(VilaColors.Bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { confirmExit = true }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE)) }
            Text("Cờ Phép Thuật", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            TextButton(onClick = { showRules = true }) { Text("Luật chơi", color = Purple) }
        }

        SideBar(s, white = false, active = !white)
        MagicBoard(
            s = s, images = images, selSq = selSq, legalTo = legalTo, targets = targets.toSet(), chosen = chosen.toSet(),
            onTap = ::onTap,
        )
        SideBar(s, white = true, active = white)

        // dòng trạng thái / thông báo
        val offerCard = if (offers.isNotEmpty() && offerSel in offers.indices) MagicCatalog.get(offers[offerSel]) else null
        val hint = when {
            offerCard != null -> "«${offerCard.name}» (${game.costOf(offerCard)} mana): ${offerCard.description}"
            offers.isNotEmpty() -> "🎁 Chọn 1 trong ${offers.size} lá mới — hoặc Bỏ qua để nhận +1 mana"
            card != null && game.stepsOf(card) > 0 -> "«${card.name}»: chạm ô sáng tím (${chosen.size + 1}/${game.stepsOf(card)})"
            card != null -> "«${card.name}»: ${card.description}"
            s.extraPending >= 0 -> "Nước đi thêm của ${sideName(white)}"
            s.turnNo < s.lockedUntil[idx(white)] -> "${sideName(white)} đang bị phong ấn, không thể dùng bài"
            else -> "Lượt của ${sideName(white)}"
        }
        Text(
            text = message?.let { "$it\n$hint" } ?: hint,
            color = Color(0xFFD7DCE6), fontSize = 13.sp, maxLines = 4, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).height(60.dp),
        )

        // tay bài
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val hand = s.hands[idx(white)]
            if (!mvm.revealed) {
                Box(
                    Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                        .background(VilaColors.Panel).clickable { mvm.revealed = true },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (offers.isNotEmpty()) "Lượt của ${sideName(white)}\nChạm để mở ${offers.size} lá bài mới 🎁"
                        else "Lượt của ${sideName(white)}\nChạm để xem ${hand.size} lá bài",
                        color = Color.White, fontSize = 16.sp,
                        fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            } else if (offers.isNotEmpty()) {
                OfferRow(offers = offers, selected = offerSel, costOf = { game.costOf(it) }) { offerSel = if (offerSel == it) -1 else it }
            } else {
                LazyRow(
                    Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                ) {
                    itemsIndexed(hand) { i, id ->
                        val c = MagicCatalog.get(id)
                        CardView(
                            card = c, cost = game.costOf(c), selected = i == castIdx,
                            usable = game.castBlocker(c) == null,
                        ) {
                            if (castIdx == i) reset() else { selSq = -1; castIdx = i; chosen = emptyList(); message = game.castBlocker(c) }
                        }
                    }
                }
            }
        }

        // nút hành động
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val c = card
            if (offers.isNotEmpty() && mvm.revealed) {
                ActionButton("Bỏ qua (+1 mana)", Modifier.weight(1f)) { val err = game.skipOffer(); offerSel = -1; after(err) }
                ActionButton(if (offerSel >= 0) "Nhận lá này" else "Chạm 1 lá để chọn", Modifier.weight(2f), primary = offerSel >= 0) {
                    if (offerSel >= 0) { val err = game.takeOffer(offerSel); offerSel = -1; after(err) }
                }
            } else if (c != null) {
                ActionButton("Hủy", Modifier.weight(1f)) { reset(); message = null }
                if (game.stepsOf(c) == 0) {
                    ActionButton("Dùng bài (${game.costOf(c)} mana)", Modifier.weight(2f), primary = true) {
                        val err = game.castSpell(castIdx, emptyList()); reset(); after(err)
                    }
                }
            } else {
                ActionButton("Đầu hàng", Modifier.weight(1f)) { game.resign(white); after() }
                ActionButton("Ván mới", Modifier.weight(1f)) { reset(); message = null; mvm.newGame() }
            }
        }
    }

    promo?.let { list ->
        AlertDialog(
            onDismissRequest = { promo = null },
            title = { Text("Phong cấp thành") },
            text = { Text("Chọn quân để phong cấp") },
            confirmButton = {
                Row {
                    list.forEach { m ->
                        TextButton(onClick = { promo = null; selSq = -1; game.playMove(m); after() }) { Text(pieceNameVi(movePromo(m))) }
                    }
                }
            },
        )
    }

    if (showRules) AlertDialog(
        onDismissRequest = { showRules = false },
        title = { Text("Luật Cờ Phép Thuật") },
        text = {
            Text(
                "• Cờ vua bình thường, thêm bài phép.\n" +
                    "• Mỗi lượt: +1 mana (tối đa 10) và mở ${MagicCatalog.OFFER_SIZE} lá bài ngẫu nhiên — chọn 1 lá vào tay (cầm tối đa 7) hoặc bỏ qua để nhận +1 mana.\n" +
                    "• Gói VIP luôn có ít nhất 1 lá đặc quyền ★ trong số các lá mở ra; có cả «Tuyệt kỹ» mạnh hơn mua rời.\n" +
                    "• Bài 🎉 giải trí (xúc xắc, đồng xu, mũ ảo thuật…) có kết quả may rủi — ai cũng có thể gặp.\n" +
                    "• Mỗi lượt dùng tối đa 1 bài (trừ bài «Thần Tốc»), rồi đi 1 nước cờ.\n" +
                    "• Phép không được để Vua bạn bị chiếu hoặc mất Vua.\n" +
                    "• Quân bị đóng băng không đi được; quân có khiên không bị ăn; bẫy diệt quân địch bước vào.\n" +
                    "• Kho có ${MagicCatalog.size} lá bài khác nhau, độ hiếm theo giá mana.\n" +
                    "• Gói Gold/Platinum/Diamond/Family có thêm ${MagicCatalog.exclusive.size} bài đặc quyền ★ (gộp 2 phép). Cả hai người chơi cùng dùng bộ bài của tài khoản, nên luôn công bằng.\n" +
                    "• Hai người chuyền máy: sau mỗi lượt, bài được che — chạm để xem.\n" +
                    "• Thắng bằng chiếu hết như cờ vua.",
            )
        },
        confirmButton = { TextButton(onClick = { showRules = false }) { Text("Đã hiểu") } },
    )

    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false },
        title = { Text("Thoát ván?") },
        text = { Text("Ván đang chơi sẽ được giữ lại cho tới khi bạn bấm «Ván mới».") },
        confirmButton = { TextButton(onClick = { confirmExit = false; onBack() }) { Text("Thoát") } },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Ở lại") } },
    )

    val res = game.result
    if (res != null && showResult) AlertDialog(
        onDismissRequest = { showResult = false },
        title = {
            Text(when (res) { is MagicResult.Win -> "${sideName(res.white)} thắng!"; is MagicResult.Draw -> "Hòa" })
        },
        text = { Text(when (res) { is MagicResult.Win -> res.reason; is MagicResult.Draw -> res.reason }) },
        confirmButton = { TextButton(onClick = { showResult = false; reset(); mvm.newGame() }) { Text("Ván mới") } },
        dismissButton = { TextButton(onClick = { showResult = false }) { Text("Xem bàn cờ") } },
    )
}

@Composable
private fun SideBar(s: MagicState, white: Boolean, active: Boolean) {
    val i = idx(white)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (active) VilaColors.Green else Color(0xFF55524D)))
        Spacer(Modifier.width(8.dp))
        Text(sideName(white), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("💧 ${s.mana[i]}/${MagicState.MANA_MAX}", color = Color(0xFF7CC4FF), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.width(14.dp))
        Text("🃏 ${s.hands[i].size}", color = Color(0xFFD7DCE6), fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun ActionButton(label: String, modifier: Modifier, primary: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(10.dp))
            .background(if (primary) VilaColors.Green else VilaColors.PanelRaised).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable
private fun CardView(card: MagicCard, cost: Int, selected: Boolean, usable: Boolean, onClick: () -> Unit) {
    val exclusive = card.tier != MembershipTier.FREE
    val rc = if (exclusive) Color(0xFFFFD54F) else rarityColor(card.rarity)
    Column(
        Modifier.width(138.dp).fillMaxHeight()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Color(0xFF4A4358) else VilaColors.Panel)
            .border(BorderStroke(if (selected) 3.dp else 1.5.dp, if (usable) rc else rc.copy(alpha = 0.35f)), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(card.icon, fontSize = 22.sp, modifier = Modifier.weight(1f))
            Box(Modifier.size(26.dp).clip(CircleShape).background(if (usable) Color(0xFF2F6FB5) else Color(0xFF45474C)), contentAlignment = Alignment.Center) {
                Text("$cost", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
            }
        }
        Text(card.name, color = if (usable) Color.White else Color(0xFF9A9A9A), fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(card.description, color = Color(0xFFBABABA), fontSize = 10.sp, lineHeight = 12.sp, maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text(cardTag(card), color = rc, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Nhãn dưới lá bài: ★ gói (+ Tuyệt kỹ) cho bài đặc quyền, 🎉 cho bài giải trí, còn lại là độ hiếm. */
private fun cardTag(c: MagicCard): String = when {
    c.tier != MembershipTier.FREE -> "★ ${c.tier.displayName}" + if (c.isSignature) " · Tuyệt kỹ" else ""
    c.isFun -> "🎉 ${c.rarity.label}"
    else -> c.rarity.label
}

/** Hàng 3 lá bài mới, thu gọn vừa khu tay bài: chạm 1 lá để chọn (mô tả hiện ở dòng trạng thái), rồi bấm «Nhận lá này». */
@Composable
private fun OfferRow(offers: List<Int>, selected: Int, costOf: (MagicCard) -> Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 2.dp)) {
        Text("🎁 Chọn 1 trong ${offers.size} lá mới", color = Color(0xFFFFD54F), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.weight(1f).fillMaxWidth().padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            offers.forEachIndexed { i, id ->
                val c = MagicCatalog.get(id)
                MiniCard(c, costOf(c), i == selected, Modifier.weight(1f).fillMaxHeight()) { onSelect(i) }
            }
        }
    }
}

@Composable
private fun MiniCard(card: MagicCard, cost: Int, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val exclusive = card.tier != MembershipTier.FREE
    val base = if (exclusive) Color(0xFFFFD54F) else rarityColor(card.rarity)
    val pulse = rememberInfiniteTransition(label = "vip")
    val glow by pulse.animateFloat(0.4f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "glow")
    val border = if (exclusive) base.copy(alpha = glow) else base
    Column(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0xFF4A4358) else VilaColors.Panel)
            .border(BorderStroke(if (selected) 3.dp else 1.5.dp, border), RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(5.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(card.icon, fontSize = 18.sp, modifier = Modifier.weight(1f))
            Box(Modifier.size(20.dp).clip(CircleShape).background(Color(0xFF2F6FB5)), contentAlignment = Alignment.Center) {
                Text("$cost", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
            }
        }
        Text(
            card.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp, lineHeight = 13.sp,
            maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        Text(cardTag(card), color = base, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun MagicBoard(
    s: MagicState,
    images: Array<androidx.compose.ui.graphics.ImageBitmap?>,
    selSq: Int,
    legalTo: Set<Int>,
    targets: Set<Int>,
    chosen: Set<Int>,
    onTap: (Int) -> Unit,
) {
    val measurer = rememberTextMeasurer()
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(1f).pointerInput(Unit) {
            detectTapGestures { o ->
                val cell = size.width / 8f
                val file = (o.x / cell).toInt().coerceIn(0, 7)
                val rowTop = (o.y / cell).toInt().coerceIn(0, 7)
                onTap((7 - rowTop) * 8 + file)
            }
        },
    ) {
        val cell = size.width / 8f
        val tag = TextStyle(fontSize = (cell * 0.3f).toSp())
        for (sq in 0 until 64) {
            val file = sq and 7
            val rank = sq shr 3
            val x = file * cell
            val y = (7 - rank) * cell
            val light = (file + rank) % 2 == 1
            drawRect(if (light) VilaColors.BoardLight else VilaColors.BoardDark, Offset(x, y), Size(cell, cell))
            if (sq == selSq) drawRect(VilaColors.Highlight, Offset(x, y), Size(cell, cell))
            if (sq in chosen) drawRect(Purple.copy(alpha = 0.55f), Offset(x, y), Size(cell, cell))
            if (s.isFrozen(sq)) drawRect(Color(0x663FA9F5), Offset(x, y), Size(cell, cell))
            val piece = s.pos.board[sq]
            if (piece != 0) {
                val img = images.getOrNull(piece)
                if (img != null) drawImage(
                    img, srcOffset = IntOffset.Zero, srcSize = IntSize(img.width, img.height),
                    dstOffset = IntOffset(x.roundToInt(), y.roundToInt()), dstSize = IntSize(cell.roundToInt(), cell.roundToInt()),
                )
            }
            if (s.isShielded(sq)) drawCircle(Color(0xFFF2B134), radius = cell * 0.46f, center = Offset(x + cell / 2, y + cell / 2), style = Stroke(cell * 0.06f))
            if (s.isFrozen(sq)) drawText(measurer.measure("❄️", tag), topLeft = Offset(x + cell * 0.02f, y))
            if (s.trapAt(sq) != null) drawText(measurer.measure("🕳️", tag), topLeft = Offset(x + cell * 0.62f, y + cell * 0.6f))
            if (sq in legalTo) drawCircle(
                Color(0x66000000), radius = if (piece == 0) cell * 0.16f else cell * 0.45f, center = Offset(x + cell / 2, y + cell / 2),
                style = if (piece == 0) androidx.compose.ui.graphics.drawscope.Fill else Stroke(cell * 0.08f),
            )
            if (sq in targets) drawCircle(Purple, radius = cell * 0.4f, center = Offset(x + cell / 2, y + cell / 2), style = Stroke(cell * 0.09f))
        }
    }
}
