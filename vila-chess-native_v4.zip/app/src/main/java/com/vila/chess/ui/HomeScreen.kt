package com.vila.chess.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vila.chess.game.GameViewModel

// ---------------------------------------------------------------------------
// Quick time presets shown in the Hero card.
// timeIndex values map 1-to-1 to TimeControls.all defined in Config.kt:
//   index 4 → "3 | 2"   (3 phút + 2 giây tăng)
//   index 2 → "5 | 0"   (5 phút không tăng)
//   index 3 → "10 | 0"  (10 phút không tăng)
// ---------------------------------------------------------------------------
data class QuickTime(val label: String, val timeIndex: Int)

private val QUICK_TIMES = listOf(
    QuickTime("3 | 2",  4),
    QuickTime("5 | 0",  2),
    QuickTime("10 | 0", 3),
)

// ---------------------------------------------------------------------------
// HomeScreen
// ---------------------------------------------------------------------------
@Composable
fun HomeScreen(vm: GameViewModel) {
    // Which bottom-nav tab is highlighted (local UI state only – no nav graph yet)
    var selectedNavItem by remember { mutableIntStateOf(0) }

    // Which chip index is currently active based on the ViewModel's timeIndex
    val selectedChip = QUICK_TIMES.indexOfFirst { it.timeIndex == vm.timeIndex }.coerceAtLeast(0)

    Scaffold(
        containerColor = VilaColors.Bg,
        // Let Scaffold handle status-bar + bottom-nav insets automatically.
        // NavigationBar inside BottomNavBar handles its own windowInsets.
        bottomBar = {
            BottomNavBar(
                selectedIndex  = selectedNavItem,
                onItemSelected = { selectedNavItem = it },
            )
        },
    ) { innerPadding ->
        // innerPadding already bakes in status-bar top + bottom nav height.
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp),
        ) {
            item(key = "header") {
                TopHeader(username = "vilaadmin", elo = 1200)
            }

            item(key = "spacer_1") { Spacer(Modifier.height(4.dp)) }

            item(key = "hero") {
                HeroPlayCard(
                    quickTimes   = QUICK_TIMES,
                    selectedChip = selectedChip,
                    onChipSelect = { idx -> vm.updateTimeIndex(QUICK_TIMES[idx].timeIndex) },
                    onPlayNow    = { vm.startGame() },
                    modifier     = Modifier.padding(horizontal = 12.dp),
                )
            }

            item(key = "spacer_2") { Spacer(Modifier.height(16.dp)) }

            item(key = "features") {
                FeatureGrid(modifier = Modifier.padding(horizontal = 12.dp))
            }
        }
    }
}
