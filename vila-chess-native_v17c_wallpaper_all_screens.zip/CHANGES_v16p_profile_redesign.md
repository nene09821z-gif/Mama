# v16p — Thiết kế lại Hồ sơ + đổi ảnh từ thư viện

## Mới
- profile/AvatarPhotos.kt : lưu ảnh đại diện "photo:<file>" (JPEG 512x512 trong filesDir/avatars), giải mã đúng chiều EXIF, cache.
- ui/AvatarCrop.kt : rememberAvatarPicker (Photo Picker hệ thống, KHÔNG cần xin quyền) + màn cắt ảnh tròn (kéo, chụm/thanh trượt zoom, lưới 1/3).
## Sửa
- ui/MyProfileScreen.kt : hero banner (hoa văn bàn cờ), avatar vòng sáng theo gói + nút máy ảnh, danh hiệu theo Elo, thẻ Elo,
  biểu đồ Elo (7 ngày/30 ngày/1 năm), thống kê (vòng % thắng, thanh T/H/B, chuỗi). Sheet chỉnh sửa: chọn ảnh thư viện hoặc biểu tượng.
- ui/ProfileComponents.kt : ProfileAvatar hiển thị ảnh thật (mọi nơi: trang chủ, tài khoản, bạn bè...).
- profile/*: rankTitle, bestElo; updateProfile xoá ảnh cũ.
- NGƯỜI KHÁC THẤY ẢNH: ảnh tự tải lên Supabase Storage (bucket công khai "avatars", thư mục = uid), avatar_key trên cloud = "cloud:<uid>/avatar_<ts>.jpg".
  Người xem tải ảnh về, lưu cache RAM + đĩa. Đổi/bỏ ảnh thì ảnh cloud cũ bị xoá. Mất mạng thì tự thử lại ở lần đồng bộ sau.
  BẮT BUỘC chạy SQL trong supabase/avatars/ (xem HUONG_DAN.md, 4 file nhỏ) hoặc supabase/avatars.sql (gộp một lần).
## Lưu ý
- Chưa build được trong môi trường này (không có Android SDK) - chạy ./gradlew assembleDebug / testDebugUnitTest.
