# v17c - hình nền động hiện ở mọi màn

- MainActivity.kt (AppRoot): một SpaceBackground duy nhất phía sau mọi màn, có graphicsLayer riêng nên chỉ lớp nền được vẽ lại mỗi frame (không kéo theo bàn cờ/UI) và không bị khởi động lại khi đổi màn.
- HomeScreen.kt: bỏ nền riêng (nền giờ nằm ở AppRoot).
- BotGameScreen, PvpGameScreen, OnlineGameScreen, GameReviewScreen, MagicChessScreen (sảnh + ván): nền đặc VilaColors.Bg đổi thành GameScrim (đen mờ 35%, khai báo trong SpaceBackground.kt) để vẫn thấy nền động mà chữ/bàn cờ vẫn rõ.
- Muốn nền sáng/tối hơn ở màn chơi: đổi alpha của GameScrim (0x59 = 35%).
