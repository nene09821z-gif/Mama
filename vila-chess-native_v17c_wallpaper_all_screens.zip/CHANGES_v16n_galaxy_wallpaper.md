# v16n — Hình nền "Ngân hà" chuyển động

## Mới
- Wallpapers.kt: thêm cờ `animated` + hình nền "Ngân hà" (id `galaxy`, đứng ngay sau "Không gian").
- SpaceBackground.kt: `GalaxyBackground` — thiên hà xoắn ốc 2 nhánh xoay chậm (~225s/vòng, nghiêng xiên),
  lõi sáng + sương bụi mềm, 6 nhóm sao trôi ngang theo thị sai và lấp lánh lệch pha, sao băng ~7.5s/lần.
  Hiệu năng: toạ độ dựng 1 lần, `time` chỉ đọc ở pha vẽ (không recompose), cập nhật 30 fps, ~35 lệnh drawPoints/frame.
- ThemeScreen.kt: ô xem trước của nền động có đĩa thiên hà nghiêng.

## Sửa
- AppearanceTest: bỏ ràng buộc số nền chia hết cho 5 (giờ 11 nền), thêm kiểm tra có nền động & nền mặc định là nền tĩnh.

## Lưu ý
- Chưa build được ở đây (không có Gradle/Android SDK) — chạy ./gradlew assembleDebug hoặc đẩy lên GitHub Actions.
