# v16l — Bot luôn đấu bằng Stockfish thật, mạnh theo Elo từng bot

- `BotEngineManager` giờ có 2 backend Stockfish dùng chung bộ lệnh UCI theo Elo của bot (UCI_LimitStrength / UCI_Elo / Skill Level / MultiPV):
  1. NATIVE: `libstockfish.so` do main.yml tải (bản đầy đủ).
  2. WASM: Stockfish 19 lite trong WebView ẩn (`assets/stockfish/`) — tự dùng khi không có hoặc không chạy được bản native.
- Trước đây thiếu `libstockfish.so` thì bot rơi thẳng về engine Kotlin tự viết (yếu). Nay chỉ rơi về engine Kotlin khi CẢ HAI Stockfish đều lỗi, và đã thử lại 1 lần.
- Engine im lặng/chết giữa ván -> tự khởi động lại ở lượt sau (không treo bot).
- Không còn gửi lại `ucinewgame` + xoá bảng băm ở mỗi nước (chỉ khi ván mới hoặc đổi bot).
- Elo -> sức mạnh: 1320..3190 dùng UCI_Elo; dưới 1320 dùng Skill Level thấp + giới hạn depth + thỉnh thoảng đi nước kém; từ 3190 trở lên chạy tối đa.
- Log tag `BotEngine` cho biết đang chạy backend nào (native/wasm).
