# v17 (trên nền v16p_profile) — Bảng xếp hạng · Chat · Cờ Phép Thuật online · Nhãn thông minh hơn

> Bản này đã được ghép lên **v16p_profile** (giữ nguyên bot, bạn bè, hình nền, thành tựu, hồ sơ mới). Thành tựu «Pháp sư cờ» của v16p được nối vào màn Cờ Phép Thuật mới (online bị hủy không tính).

> **Quan trọng:** bản này được viết trong môi trường KHÔNG có trình biên dịch Kotlin và KHÔNG có mạng, nên **chưa được biên dịch hay chạy thử**.
> Đã kiểm tra tĩnh (cân ngoặc/chuỗi, import tồn tại, kiểu chưa khai báo, trùng khai báo) nhưng lần build GitHub Actions đầu tiên mới là phép thử thật.
> Nếu CI báo lỗi biên dịch: gửi nguyên log, sẽ sửa ngay. Không thêm thư viện mới nào.

## Việc bắt buộc để dùng phần online
Chạy SQL trong Supabase: **`supabase/social_parts/01…07`** lần lượt (xem `HUONG_DAN.md`), hoặc cả `supabase/social.sql` một lần. Cần đã chạy `schema.sql` và `online.sql` trước.
Không chạy file này thì: bảng xếp hạng "Toàn cầu" vẫn tải được hạng cơ bản nhưng không có số hạng của bạn; Chat và Cờ Phép Thuật online sẽ báo lỗi máy chủ.

## 1) Thuật toán nhãn — lớp "độ tin cậy dữ liệu" (`review/LabelEvidence.kt`)
- Nhãn chỉ đáng tin khi engine tìm đủ sâu ở **cả hai thế** (trước và sau nước đi). Độ tin cậy = nước kém hơn trong hai độ sâu: ≥ 14 → 1.0, ≤ 4 → 0.2, tuyến tính ở giữa.
- Độ sâu **≥ 10**: giữ nguyên nhãn (mọi test cũ dùng độ sâu ≥ 12 nên không đổi).
- Độ sâu **≤ 9** (máy yếu / hết thời gian): nhãn "chói" và "nặng" bị hạ một bậc thay vì phán quyết sai — Brilliant→Great→Best, Blunder→Mistake→Inaccuracy, Miss→Inaccuracy (rất nông ≤ 6 thì Blunder→Inaccuracy).
- **Không** hạ khi có mate trong điểm / nhãn do "sàn mate" quyết định (điểm mate đã được chứng minh), khi độ sâu = 0 (thế kết thúc do luật), hay với Sách/Best/Excellent/Good.
- Thêm `estimateGameElo(accuracy)`: "Elo ván ước tính" (chỉ để xem, không cộng/trừ điểm) hiện ở hộp thoại tổng kết.
- Nối vào `ReviewAssembler` bằng đúng một chỗ; `MoveClassifier` không đổi.

## 2) Hộp thoại tổng kết — 4 nhãn mượt hơn
- Cả lúc chờ lẫn lúc xong đều hiện **4 nhãn** (`ReviewHighlightCount = 4`). Vẫn khởi động Stockfish native như trước.
- Lúc chờ: 4 nhãn đổi liên tục, mỗi nhãn nảy lò xo + hơi xoay rồi chính lại.
- Lúc xong: nhãn thật hiện lần lượt, **quầng sáng cùng màu nhãn** thở nhẹ phía sau, **số nước đếm tăng dần** từ 0.

## 3) Bảng xếp hạng (`ui/LeaderboardScreen.kt`, `profile/Leaderboard*.kt`)
- Vào từ Trang chủ (thẻ "Bảng xếp hạng") và Tùy chỉnh. Tab Bullet / Blitz / Rapid với thanh trượt mượt; phạm vi Toàn cầu / Bạn bè.
- Podium top 3 (bục dâng lên, vương miện nhún), danh sách xuất hiện lần lượt, khung xương khi tải, thẻ "Hạng của bạn" ghim đáy, nhớ kết quả từng tab trong bộ nhớ.
- Hạng kiểu thi đấu (bằng Elo thì cùng hạng). Dữ liệu từ bảng `users` + RPC `leaderboard_rank`.

## 4) Chat trong ván online
- Khung chat trượt từ dưới lên (`ui/ChatPanel.kt`): bong bóng tin, trả lời nhanh 1 chạm, số tin chưa đọc trên nút 💬.
- Có ở **ván cờ thường online** (thanh công cụ) và **Cờ Phép Thuật online** (thanh trên). Chống spam 0,6 giây/tin, tối đa 200 ký tự.

## 5) Cờ Phép Thuật
**Sảnh mới** (`ui/MagicLobbyScreen.kt`): chọn **Cùng máy / Online** và **bảng chọn giờ** (cùng máy có cả "Không giới hạn"; online yêu cầu có đồng hồ).

**Online:** hai bên luân phiên Trắng – Đen, ghép trận theo thể loại giờ. Ván là hàm tất định của (hạt giống, chuỗi hành động): máy chủ chỉ lưu hạt giống + hành động, kiểm lượt và đồng hồ; hai máy tự chạy lại luật nên luôn khớp thế cờ, bài và mana. Đồng hồ do máy chủ tính (chỉ chạy sau khi mỗi bên xong 1 lượt). Online dùng bộ bài thường (FREE) để công bằng. Mất mạng: tự gửi lại; lệch dữ liệu: tự dựng lại từ máy chủ.
- Điều kiện kỹ thuật: `MagicRandom` (cùng dãy số với `java.util.Random`) + bản sao thử phép có bộ ngẫu nhiên riêng, nên "hỏi thử lá nào dùng được" không làm trôi dãy ngẫu nhiên.

**3 lá bài giữa màn hình** (`ui/MagicCardViews.kt`): lớp phủ giữa màn hình, 3 lá bay vào lệch nhau → lật mặt → trôi nhẹ; lá hiếm có ánh sáng quét, Sử thi/Huyền thoại/VIP có quầng sáng thở + đốm lấp lánh; chọn thì nổi lên và hiện mô tả đầy đủ; nhận xong bay về tay.

**Nhãn lá bài** (`magic/MagicCardInfo.kt`): LOẠI (Triệu hồi · Tấn công · Phòng thủ · Khống chế · Cơ động · Năng lượng · May rủi · Tuyệt kỹ) · ĐỘ HIẾM (số viên ngọc + màu) · ★ Gói VIP · phần thưởng.

**Bài "không dùng được" — đã xử lý ở 4 tầng:**
1. Sửa lỗi thật: tay đầy 7 lá thì bài "rút thêm" không dùng được (lá đang dùng giờ rời tay trước khi phép chạy).
2. 3 lá đầu lượt: lá **thường** nào chưa có mục tiêu hợp lệ thì tự bốc lại (lá ★ VIP giữ nguyên luật "luôn có ≥ 1 lá ★").
3. Mỗi lá trên tay hiện trạng thái "● Dùng được" hoặc "○ lý do cụ thể" (hết mana, đang phong ấn, Vua đang bị chiếu, không có Hậu địch để thiêu…).
4. **Tái chế ♻**: lá nào kẹt thì bỏ để nhận +1 mana (mỗi lượt 1 lá, không tốn lượt dùng bài) — không còn "bài chết".

Cùng máy có thêm đồng hồ (tạm dừng khi bài đang bị che) và tùy chọn "Tự xoay bàn theo lượt".

## Không làm được
- "Tìm GitHub và tải": môi trường này không có mạng. Mọi hiệu ứng được viết thuần Jetpack Compose, **không thêm thư viện** nên không rủi ro xung đột phiên bản.

## File mới / sửa
Mới: `magic/{MagicRandom,MagicClock,MagicActions,MagicUse,MagicCardInfo}.kt`, `online/{ChatModels,ChatRepository,MagicOnlineRepository}.kt`, `profile/{LeaderboardModels,LeaderboardRepository}.kt`, `review/LabelEvidence.kt`, `ui/{MagicChessViewModel,MagicCardViews,MagicLobbyScreen,ChatPanel,LeaderboardScreen}.kt`, `supabase/social.sql`, `SocialFeaturesTest.kt`.
Sửa: `MagicState`, `MagicGame`, `MagicChessScreen` (viết lại), `ReviewAssembler`, `ReviewLoadingParts`, `PostGameSummaryScreen`, `OnlineGameScreen`, `GameViewModel` (+1 getter), `HomeScreen`, `MoreTab`, `Modes.kt` (+route LEADERBOARD).
