# v17b - 6 hình nền động vũ trụ

Tab Chủ đề > Hình nền có thêm 6 hình nền chuyển động: Hố đen, Siêu tốc, Hành tinh, Tinh vân, Mưa sao băng, Hệ mặt trời.

- Mới: ui/SpaceScenes.kt (vẽ cảnh + ảnh xem trước)
- Sửa: Wallpapers.kt (trường scene + 6 mục), SpaceBackground.kt (chọn cảnh), ThemeScreen.kt (ô xem trước)
- Cảnh chậm vẽ 30 fps, siêu tốc và sao băng ~60 fps; tự dừng khi app ra nền.
