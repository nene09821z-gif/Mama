# v16m - Thiết kế lại trang Bạn bè (chuyên nghiệp)

`ui/FriendsPanel.kt` (viết lại) + `ui/HomeScreen.kt` (FriendsTab chỉ còn 1 FriendsPanel). Không đổi ViewModel / repository.

- Tiêu đề "Bạn bè" + mô tả
- Thẻ ID của bạn: gradient + hoa văn bàn cờ, chạm ô ID để chép, nút "Sao chép" (đổi thành "Đã chép ✓"), nút "Chia sẻ ID" (gửi lời mời kèm ID)
- Ô thêm bạn: kiểm tra ID (UUID) ngay khi gõ/dán, viền xanh khi hợp lệ, đỏ + gợi ý khi sai, nút Dán một chạm, chỉ cho "Thêm" khi ID đúng
- 2 ô hành động: Chơi chung máy / Mời bạn bè
- Danh sách: chọn Elo Bullet/Blitz/Rapid, sắp xếp Elo cao nhất / Tên A–Z, ô tìm kiếm (hiện khi có từ 6 bạn)
- Thẻ bạn: avatar viền sáng theo hạng VIP, huy hiệu top 1-2-3 theo Elo, tên + huy hiệu, cờ + quốc gia, thanh thắng/hòa/thua, chuỗi thắng 🔥 (từ 3), Elo lớn, menu ⋮ (Xem hồ sơ / Xóa bạn)
- Trạng thái: đang tải (shimmer) · lỗi (Thử lại) · trống (nút Mời bạn bè) · không tìm thấy
