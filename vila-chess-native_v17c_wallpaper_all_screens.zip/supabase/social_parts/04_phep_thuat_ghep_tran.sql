-- ===== CỜ PHÉP THUẬT ONLINE (3/4): ghép trận + hủy tìm =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

-- Ghép trận. App gọi lại hàm này mỗi ~1,5 giây trong lúc chờ (đồng thời là nhịp "còn online").
create or replace function public.magic_find_match(p_base int, p_inc int)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.magic_queue;
  opp public.magic_queue;
  g   public.magic_games;
  wid uuid;
  bid uuid;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_base < 30 or p_base > 7200 or p_inc < 0 or p_inc > 60 then raise exception 'bad_time_control'; end if;

  delete from public.magic_queue where game_id is null and heartbeat < now() - interval '20 seconds';

  -- 1) Người khác đã ghép trúng mình
  select * into q from public.magic_queue where user_id = uid for update;
  if found and q.game_id is not null then
    delete from public.magic_queue where user_id = uid;
    select * into g from public.magic_games where id = q.game_id for update;
    if found then
      g := public._magic_settle(g);
      if g.status = 'active' then
        return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
      end if;
    end if;
  end if;

  -- 2) Đang có ván dở -> vào lại đúng ván đó
  select * into g from public.magic_games
    where status = 'active' and uid in (white_id, black_id)
    order by created_at desc limit 1 for update;
  if found then
    g := public._magic_settle(g);
    if g.status = 'active' then
      delete from public.magic_queue where user_id = uid;
      return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
    end if;
  end if;

  -- 3) Tìm đối thủ đang chờ cùng thể loại giờ
  select * into opp from public.magic_queue
    where user_id <> uid and game_id is null and base_sec = p_base and inc_sec = p_inc
      and heartbeat >= now() - interval '20 seconds'
    order by heartbeat limit 1 for update skip locked;
  if found then
    if random() < 0.5 then wid := uid; bid := opp.user_id; else wid := opp.user_id; bid := uid; end if;
    insert into public.magic_games (white_id, black_id, base_sec, inc_sec, white_ms, black_ms, seed)
      values (wid, bid, p_base, p_inc, p_base * 1000::bigint, p_base * 1000::bigint, floor(random() * 9007199254740991)::bigint)
      returning * into g;
    update public.magic_queue set game_id = g.id where user_id = opp.user_id;
    delete from public.magic_queue where user_id = uid;
    return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
  end if;

  -- 4) Chưa có ai: vào / giữ chỗ trong hàng đợi
  insert into public.magic_queue (user_id, base_sec, inc_sec, heartbeat)
    values (uid, p_base, p_inc, now())
    on conflict (user_id) do update
      set base_sec = excluded.base_sec, inc_sec = excluded.inc_sec, heartbeat = now(), game_id = null;
  return jsonb_build_object('status', 'waiting');
end $$;

create or replace function public.magic_cancel_search()
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.magic_queue;
  g   public.magic_games;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  delete from public.magic_queue where user_id = uid returning * into q;
  if found and q.game_id is not null then
    select * into g from public.magic_games where id = q.game_id;
    if found then return jsonb_build_object('status', 'matched', 'game', public._magic_view(g)); end if;
  end if;
  return jsonb_build_object('status', 'cancelled');
end $$;
