-- ===== CỜ PHÉP THUẬT ONLINE (1/4): bảng hàng đợi + bảng ván =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

create table if not exists public.magic_queue (
  user_id   uuid primary key references auth.users(id) on delete cascade,
  base_sec  int  not null,
  inc_sec   int  not null,
  game_id   uuid,
  heartbeat timestamptz not null default now()
);
alter table public.magic_queue enable row level security;   -- không có policy: chỉ truy cập qua RPC

create table if not exists public.magic_games (
  id              uuid primary key default gen_random_uuid(),
  white_id        uuid not null references auth.users(id) on delete cascade,
  black_id        uuid not null references auth.users(id) on delete cascade,
  base_sec        int  not null,
  inc_sec         int  not null,
  seed            bigint not null,                         -- hạt giống của bộ bài / xúc xắc: cả hai máy dùng chung
  actions         text not null default '',                -- các hành động cách nhau bằng dấu cách: "o1 c0:12 me2e4"
  n               int  not null default 0,                 -- số hành động đã ghi
  turn            text not null default 'w' check (turn in ('w', 'b')),
  turns_done      int  not null default 0,                 -- số lần đổi lượt
  white_ms        bigint not null,                         -- giờ còn lại tại turn_started_at (chưa trừ thời gian đang chạy)
  black_ms        bigint not null,
  turn_started_at timestamptz not null default clock_timestamp(),
  status          text not null default 'active' check (status in ('active', 'finished', 'aborted')),
  result          text check (result in ('1-0', '0-1', '1/2-1/2')),
  reason          text,
  created_at      timestamptz not null default now(),
  finished_at     timestamptz,
  check (white_id <> black_id)
);
alter table public.magic_games enable row level security;
drop policy if exists "magic_games_select_players" on public.magic_games;
create policy "magic_games_select_players" on public.magic_games
  for select to authenticated using (auth.uid() in (white_id, black_id));
create index if not exists magic_games_white  on public.magic_games (white_id, created_at desc);
create index if not exists magic_games_black  on public.magic_games (black_id, created_at desc);
create index if not exists magic_games_active on public.magic_games (status) where status = 'active';
