-- ===== CỜ PHÉP THUẬT ONLINE (2/4): hàm xử hết giờ + hàm trả JSON =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

-- Xử ván hết giờ / bị bỏ dở (gọi khi đang giữ khóa dòng của ván).
create or replace function public._magic_settle(g public.magic_games)
returns public.magic_games
language plpgsql security definer set search_path = public as $$
declare
  el bigint;
  mover_ms bigint;
begin
  if g.status <> 'active' then return g; end if;
  el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
  if g.turns_done >= 2 then
    mover_ms := case when g.turn = 'w' then g.white_ms else g.black_ms end;
    if el >= mover_ms then
      update public.magic_games set
        status = 'finished', reason = 'timeout', finished_at = now(),
        result = case when g.turn = 'w' then '0-1' else '1-0' end,
        white_ms = case when g.turn = 'w' then 0 else g.white_ms end,
        black_ms = case when g.turn = 'w' then g.black_ms else 0 end
      where id = g.id returning * into g;
    end if;
  elsif el >= 120000 then
    update public.magic_games set status = 'aborted', reason = 'no_start', finished_at = now()
    where id = g.id returning * into g;
  end if;
  return g;
end $$;

-- JSON gửi về app: giờ còn lại đã trừ thời gian đang chạy của bên đến lượt (do máy chủ tính).
create or replace function public._magic_view(g public.magic_games)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  w bigint := g.white_ms;
  b bigint := g.black_ms;
  el bigint;
  wn text; wt text; bn text; bt text;
begin
  if g.status = 'active' and g.turns_done >= 2 then
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    if g.turn = 'w' then w := greatest(0, w - el); else b := greatest(0, b - el); end if;
  end if;
  select display_name, tier into wn, wt from public.users where id = g.white_id;
  select display_name, tier into bn, bt from public.users where id = g.black_id;
  return jsonb_build_object(
    'id', g.id,
    'white_id', g.white_id, 'black_id', g.black_id,
    'white_name', coalesce(wn, 'Người chơi'), 'black_name', coalesce(bn, 'Người chơi'),
    'white_tier', coalesce(wt, 'free'), 'black_tier', coalesce(bt, 'free'),
    'base_sec', g.base_sec, 'inc_sec', g.inc_sec,
    'seed', g.seed, 'actions', g.actions, 'n', g.n,
    'turn', g.turn, 'turns_done', g.turns_done,
    'white_ms', w, 'black_ms', b,
    'status', g.status, 'result', g.result, 'reason', g.reason
  );
end $$;
