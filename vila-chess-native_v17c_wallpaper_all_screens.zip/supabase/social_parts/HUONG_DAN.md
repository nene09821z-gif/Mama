# Cách dán SQL (chia nhỏ)

Điều kiện: đã chạy `schema.sql` và `online.sql` từ trước (bảng `users`, `online_games`).

Supabase → **SQL Editor** → **New query**. Dán **lần lượt từng file** 01 → 07, mỗi file bấm **Run** và chờ "Success" rồi mới sang file tiếp theo (đúng thứ tự: 02 trước 03–05, 02–05 trước 07, 02 trước 06).
Có thể chạy lại bất cứ phần nào mà không mất dữ liệu.

Nếu Supabase hỏi "Run this query? destructive operations" (do có lệnh `revoke` / `drop policy`) → bấm **Run this query**.

Kiểm tra cuối: Database → Functions phải có `leaderboard_rank`, `magic_find_match`, `magic_cancel_search`, `magic_get_game`, `magic_act`, `magic_resign`, `chat_send`, `chat_list`.
