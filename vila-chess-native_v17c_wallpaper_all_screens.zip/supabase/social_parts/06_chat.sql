-- ===== CHAT TRONG VÁN: bảng + 3 hàm =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

create table if not exists public.game_chat (
  id         bigint generated always as identity primary key,
  game_id    uuid not null,
  kind       text not null default 'chess' check (kind in ('chess', 'magic')),
  user_id    uuid not null references auth.users(id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 200),
  created_at timestamptz not null default now()
);
alter table public.game_chat enable row level security;      -- không có policy: chỉ truy cập qua RPC
create index if not exists game_chat_game on public.game_chat (game_id, kind, id);

-- Người gọi có phải người chơi của ván không.
create or replace function public._chat_member(p_game uuid, p_kind text, p_uid uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_uid is null then return false; end if;
  if p_kind = 'magic' then
    return exists (select 1 from public.magic_games where id = p_game and p_uid in (white_id, black_id));
  end if;
  return exists (select 1 from public.online_games where id = p_game and p_uid in (white_id, black_id));
end $$;

create or replace function public.chat_send(p_game uuid, p_kind text, p_body text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid  uuid := auth.uid();
  txt  text := btrim(coalesce(p_body, ''));
  last_at timestamptz;
  new_id bigint;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_kind not in ('chess', 'magic') then raise exception 'bad_kind'; end if;
  if not public._chat_member(p_game, p_kind, uid) then raise exception 'not_found'; end if;
  if char_length(txt) < 1 or char_length(txt) > 200 then raise exception 'bad_body'; end if;

  select max(created_at) into last_at from public.game_chat where game_id = p_game and user_id = uid;
  if last_at is not null and clock_timestamp() - last_at < interval '600 milliseconds' then raise exception 'too_fast'; end if;

  insert into public.game_chat (game_id, kind, user_id, body) values (p_game, p_kind, uid, txt) returning id into new_id;
  return jsonb_build_object('id', new_id);
end $$;

-- Tin nhắn mới hơn p_after (tối đa 100 tin gần nhất), cũ -> mới.
create or replace function public.chat_list(p_game uuid, p_kind text, p_after bigint default 0)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  result_json jsonb;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_kind not in ('chess', 'magic') then raise exception 'bad_kind'; end if;
  if not public._chat_member(p_game, p_kind, uid) then raise exception 'not_found'; end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'id', c.id, 'user_id', c.user_id,
      'name', coalesce(u.display_name, 'Người chơi'),
      'body', c.body,
      'ts', (extract(epoch from c.created_at) * 1000)::bigint
    ) order by c.id), '[]'::jsonb)
    into result_json
  from (
    select * from public.game_chat
      where game_id = p_game and kind = p_kind and id > coalesce(p_after, 0)
      order by id desc limit 100
  ) c
  left join public.users u on u.id = c.user_id;
  return result_json;
end $$;
