-- ===== PHÂN QUYỀN: chỉ tài khoản đã đăng nhập được gọi =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

revoke all on function public._magic_settle(public.magic_games) from public, anon, authenticated;
revoke all on function public._magic_view(public.magic_games) from public, anon, authenticated;
revoke all on function public._chat_member(uuid, text, uuid) from public, anon, authenticated;

revoke all on function public.leaderboard_rank(text) from public, anon;
revoke all on function public.magic_find_match(int, int) from public, anon;
revoke all on function public.magic_cancel_search() from public, anon;
revoke all on function public.magic_get_game(uuid) from public, anon;
revoke all on function public.magic_act(uuid, int, text, text, text, text) from public, anon;
revoke all on function public.magic_resign(uuid) from public, anon;
revoke all on function public.chat_send(uuid, text, text) from public, anon;
revoke all on function public.chat_list(uuid, text, bigint) from public, anon;

grant execute on function public.leaderboard_rank(text) to authenticated;
grant execute on function public.magic_find_match(int, int) to authenticated;
grant execute on function public.magic_cancel_search() to authenticated;
grant execute on function public.magic_get_game(uuid) to authenticated;
grant execute on function public.magic_act(uuid, int, text, text, text, text) to authenticated;
grant execute on function public.magic_resign(uuid) to authenticated;
grant execute on function public.chat_send(uuid, text, text) to authenticated;
grant execute on function public.chat_list(uuid, text, bigint) to authenticated;
