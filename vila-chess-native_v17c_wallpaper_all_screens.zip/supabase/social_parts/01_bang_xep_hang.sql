-- ===== BẢNG XẾP HẠNG: hàm tính hạng của bạn + chỉ mục =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

create or replace function public.leaderboard_rank(p_mode text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid   uuid := auth.uid();
  mine  int;
  r     bigint;
  total bigint;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_mode not in ('bullet', 'blitz', 'rapid') then raise exception 'bad_mode'; end if;

  select case p_mode when 'bullet' then bullet_elo when 'blitz' then blitz_elo else rapid_elo end
    into mine from public.users where id = uid;
  if mine is null then return jsonb_build_object('rank', null, 'total', 0, 'elo', null); end if;

  select count(*) into total from public.users where games_played > 0;
  select count(*) + 1 into r from public.users
    where games_played > 0
      and (case p_mode when 'bullet' then bullet_elo when 'blitz' then blitz_elo else rapid_elo end) > mine;
  return jsonb_build_object('rank', r, 'total', total, 'elo', mine);
end $$;

-- Chỉ mục để sắp xếp bảng xếp hạng nhanh
create index if not exists users_bullet_rank on public.users (bullet_elo desc) where games_played > 0;
create index if not exists users_blitz_rank  on public.users (blitz_elo desc)  where games_played > 0;
create index if not exists users_rapid_rank  on public.users (rapid_elo desc)  where games_played > 0;
