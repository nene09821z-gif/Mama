-- ===== CỜ PHÉP THUẬT ONLINE (4/4): lấy ván, gửi hành động, đầu hàng =====
-- Dán nguyên khối này vào Supabase > SQL Editor > New query > Run. Chạy lại được, không mất dữ liệu.

-- Lấy trạng thái ván (app gọi liên tục). Tự xử hết giờ / hủy ván bỏ dở.
create or replace function public.magic_get_game(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  g public.magic_games;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or auth.uid() is null or auth.uid() not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._magic_settle(g);
  return public._magic_view(g);
end $$;

-- Gửi một hành động. p_n = số hành động đã ghi TRƯỚC hành động này (chống gửi trùng / lệch thứ tự).
-- p_next = bên có lượt sau hành động này. p_result/p_reason chỉ điền khi hành động này kết thúc ván theo luật.
create or replace function public.magic_act(
  p_id uuid, p_n int, p_act text, p_next text, p_result text default null, p_reason text default null
)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.magic_games;
  el bigint;
  mover_ms bigint;
  new_w bigint;
  new_b bigint;
  switched boolean;
  fin boolean := false;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;

  g := public._magic_settle(g);
  if g.status <> 'active' then return public._magic_view(g); end if;
  if p_n < g.n then return public._magic_view(g); end if;      -- hành động này đã được ghi nhận trước đó
  if p_n > g.n then raise exception 'n_gap'; end if;

  if (g.turn = 'w' and uid <> g.white_id) or (g.turn = 'b' and uid <> g.black_id) then raise exception 'not_your_turn'; end if;
  if p_act is null or p_act !~ '^(o[0-9]|s|r[0-9]|m[a-h][1-8][a-h][1-8][qrbn]?|c[0-9]{1,2}:([0-9]{1,2}(,[0-9]{1,2}){0,3})?)$' then
    raise exception 'bad_action';
  end if;
  if p_next is null or p_next not in ('w', 'b') then raise exception 'bad_next'; end if;

  new_w := g.white_ms;
  new_b := g.black_ms;
  switched := (p_next <> g.turn);
  if switched and g.turns_done >= 2 then
    -- hết lượt khi đồng hồ đang chạy: trừ thời gian đã suy nghĩ, rồi cộng giờ thưởng
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    mover_ms := case when g.turn = 'w' then g.white_ms else g.black_ms end;
    mover_ms := mover_ms - el + g.inc_sec * 1000::bigint;
    if g.turn = 'w' then new_w := mover_ms; else new_b := mover_ms; end if;
  end if;

  if p_result is not null then
    if p_result not in ('1-0', '0-1', '1/2-1/2') then raise exception 'bad_result'; end if;
    fin := true;
  end if;

  update public.magic_games set
    actions = case when actions = '' then p_act else actions || ' ' || p_act end,
    n = n + 1,
    turn = p_next,
    turns_done = turns_done + (case when switched then 1 else 0 end),
    white_ms = new_w, black_ms = new_b,
    turn_started_at = case when switched then clock_timestamp() else turn_started_at end,
    status = case when fin then 'finished' else 'active' end,
    result = case when fin then p_result else null end,
    reason = case when fin then left(coalesce(nullif(p_reason, ''), 'rule'), 60) else null end,
    finished_at = case when fin then now() else null end
  where id = g.id returning * into g;

  return public._magic_view(g);
end $$;

-- Đầu hàng. Trước khi mỗi bên xong 1 lượt thì chỉ là hủy ván (không ai thắng/thua).
create or replace function public.magic_resign(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.magic_games;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._magic_settle(g);
  if g.status <> 'active' then return public._magic_view(g); end if;
  if g.turns_done < 2 then
    update public.magic_games set status = 'aborted', reason = 'abort', finished_at = now()
      where id = g.id returning * into g;
  else
    update public.magic_games set
      status = 'finished', reason = 'resign', finished_at = now(),
      result = case when uid = g.white_id then '0-1' else '1-0' end
    where id = g.id returning * into g;
  end if;
  return public._magic_view(g);
end $$;
