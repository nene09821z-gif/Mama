-- =============================================================================
-- BẢNG XẾP HẠNG + CHAT TRONG VÁN + CỜ PHÉP THUẬT ONLINE (đồng hồ do MÁY CHỦ tính).
-- Chạy 1 lần trong Supabase: SQL Editor -> New query -> dán -> Run (chạy lại được, không mất dữ liệu).
-- Cần đã chạy schema.sql (bảng public.users) và online.sql (bảng public.online_games) trước.
--
-- Cờ Phép Thuật online hoạt động thế nào:
--   * Ván là hàm tất định của (seed, chuỗi hành động). Máy chủ KHÔNG chạy luật cờ: chỉ lưu seed + danh sách hành động
--     theo thứ tự, kiểm lượt đi, định dạng hành động và đồng hồ. Hai máy tự chạy lại chuỗi hành động nên luôn ra cùng thế cờ.
--   * Mỗi hành động gửi kèm "p_next" = bên có lượt SAU hành động đó ('w' | 'b'). Khi lượt đổi, máy chủ trừ giờ bên vừa đi
--     (+ giờ thưởng) và bắt đầu tính giờ bên kia. Đồng hồ chỉ chạy sau khi mỗi bên đã xong 1 lượt (giống ván thường).
--   * Hết giờ: ai gọi magic_get_game thấy bên đến lượt đã hết giờ thì máy chủ tự xử thua.
--   * Không ai đi xong lượt đầu trong 120 giây -> ván bị hủy (không tính thắng/thua).
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1) BẢNG XẾP HẠNG: dữ liệu lấy thẳng từ bảng users (đọc được bởi mọi tài khoản đăng nhập). Hàm dưới chỉ tính HẠNG của mình.
-- -----------------------------------------------------------------------------
create or replace function public.leaderboard_rank(p_mode text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid   uuid := auth.uid();
  mine  int;
  r     bigint;
  total bigint;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_mode not in ('bullet', 'blitz', 'rapid') then raise exception 'bad_mode'; end if;

  select case p_mode when 'bullet' then bullet_elo when 'blitz' then blitz_elo else rapid_elo end
    into mine from public.users where id = uid;
  if mine is null then return jsonb_build_object('rank', null, 'total', 0, 'elo', null); end if;

  select count(*) into total from public.users where games_played > 0;
  select count(*) + 1 into r from public.users
    where games_played > 0
      and (case p_mode when 'bullet' then bullet_elo when 'blitz' then blitz_elo else rapid_elo end) > mine;
  return jsonb_build_object('rank', r, 'total', total, 'elo', mine);
end $$;

-- Chỉ mục để sắp xếp bảng xếp hạng nhanh
create index if not exists users_bullet_rank on public.users (bullet_elo desc) where games_played > 0;
create index if not exists users_blitz_rank  on public.users (blitz_elo desc)  where games_played > 0;
create index if not exists users_rapid_rank  on public.users (rapid_elo desc)  where games_played > 0;

-- -----------------------------------------------------------------------------
-- 2) CỜ PHÉP THUẬT ONLINE
-- -----------------------------------------------------------------------------
create table if not exists public.magic_queue (
  user_id   uuid primary key references auth.users(id) on delete cascade,
  base_sec  int  not null,
  inc_sec   int  not null,
  game_id   uuid,
  heartbeat timestamptz not null default now()
);
alter table public.magic_queue enable row level security;   -- không có policy: chỉ truy cập qua RPC

create table if not exists public.magic_games (
  id              uuid primary key default gen_random_uuid(),
  white_id        uuid not null references auth.users(id) on delete cascade,
  black_id        uuid not null references auth.users(id) on delete cascade,
  base_sec        int  not null,
  inc_sec         int  not null,
  seed            bigint not null,                         -- hạt giống của bộ bài / xúc xắc: cả hai máy dùng chung
  actions         text not null default '',                -- các hành động cách nhau bằng dấu cách: "o1 c0:12 me2e4"
  n               int  not null default 0,                 -- số hành động đã ghi
  turn            text not null default 'w' check (turn in ('w', 'b')),
  turns_done      int  not null default 0,                 -- số lần đổi lượt
  white_ms        bigint not null,                         -- giờ còn lại tại turn_started_at (chưa trừ thời gian đang chạy)
  black_ms        bigint not null,
  turn_started_at timestamptz not null default clock_timestamp(),
  status          text not null default 'active' check (status in ('active', 'finished', 'aborted')),
  result          text check (result in ('1-0', '0-1', '1/2-1/2')),
  reason          text,
  created_at      timestamptz not null default now(),
  finished_at     timestamptz,
  check (white_id <> black_id)
);
alter table public.magic_games enable row level security;
drop policy if exists "magic_games_select_players" on public.magic_games;
create policy "magic_games_select_players" on public.magic_games
  for select to authenticated using (auth.uid() in (white_id, black_id));
create index if not exists magic_games_white  on public.magic_games (white_id, created_at desc);
create index if not exists magic_games_black  on public.magic_games (black_id, created_at desc);
create index if not exists magic_games_active on public.magic_games (status) where status = 'active';

-- Xử ván hết giờ / bị bỏ dở (gọi khi đang giữ khóa dòng của ván).
create or replace function public._magic_settle(g public.magic_games)
returns public.magic_games
language plpgsql security definer set search_path = public as $$
declare
  el bigint;
  mover_ms bigint;
begin
  if g.status <> 'active' then return g; end if;
  el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
  if g.turns_done >= 2 then
    mover_ms := case when g.turn = 'w' then g.white_ms else g.black_ms end;
    if el >= mover_ms then
      update public.magic_games set
        status = 'finished', reason = 'timeout', finished_at = now(),
        result = case when g.turn = 'w' then '0-1' else '1-0' end,
        white_ms = case when g.turn = 'w' then 0 else g.white_ms end,
        black_ms = case when g.turn = 'w' then g.black_ms else 0 end
      where id = g.id returning * into g;
    end if;
  elsif el >= 120000 then
    update public.magic_games set status = 'aborted', reason = 'no_start', finished_at = now()
    where id = g.id returning * into g;
  end if;
  return g;
end $$;

-- JSON gửi về app: giờ còn lại đã trừ thời gian đang chạy của bên đến lượt (do máy chủ tính).
create or replace function public._magic_view(g public.magic_games)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  w bigint := g.white_ms;
  b bigint := g.black_ms;
  el bigint;
  wn text; wt text; bn text; bt text;
begin
  if g.status = 'active' and g.turns_done >= 2 then
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    if g.turn = 'w' then w := greatest(0, w - el); else b := greatest(0, b - el); end if;
  end if;
  select display_name, tier into wn, wt from public.users where id = g.white_id;
  select display_name, tier into bn, bt from public.users where id = g.black_id;
  return jsonb_build_object(
    'id', g.id,
    'white_id', g.white_id, 'black_id', g.black_id,
    'white_name', coalesce(wn, 'Người chơi'), 'black_name', coalesce(bn, 'Người chơi'),
    'white_tier', coalesce(wt, 'free'), 'black_tier', coalesce(bt, 'free'),
    'base_sec', g.base_sec, 'inc_sec', g.inc_sec,
    'seed', g.seed, 'actions', g.actions, 'n', g.n,
    'turn', g.turn, 'turns_done', g.turns_done,
    'white_ms', w, 'black_ms', b,
    'status', g.status, 'result', g.result, 'reason', g.reason
  );
end $$;

-- Ghép trận. App gọi lại hàm này mỗi ~1,5 giây trong lúc chờ (đồng thời là nhịp "còn online").
create or replace function public.magic_find_match(p_base int, p_inc int)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.magic_queue;
  opp public.magic_queue;
  g   public.magic_games;
  wid uuid;
  bid uuid;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_base < 30 or p_base > 7200 or p_inc < 0 or p_inc > 60 then raise exception 'bad_time_control'; end if;

  delete from public.magic_queue where game_id is null and heartbeat < now() - interval '20 seconds';

  -- 1) Người khác đã ghép trúng mình
  select * into q from public.magic_queue where user_id = uid for update;
  if found and q.game_id is not null then
    delete from public.magic_queue where user_id = uid;
    select * into g from public.magic_games where id = q.game_id for update;
    if found then
      g := public._magic_settle(g);
      if g.status = 'active' then
        return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
      end if;
    end if;
  end if;

  -- 2) Đang có ván dở -> vào lại đúng ván đó
  select * into g from public.magic_games
    where status = 'active' and uid in (white_id, black_id)
    order by created_at desc limit 1 for update;
  if found then
    g := public._magic_settle(g);
    if g.status = 'active' then
      delete from public.magic_queue where user_id = uid;
      return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
    end if;
  end if;

  -- 3) Tìm đối thủ đang chờ cùng thể loại giờ
  select * into opp from public.magic_queue
    where user_id <> uid and game_id is null and base_sec = p_base and inc_sec = p_inc
      and heartbeat >= now() - interval '20 seconds'
    order by heartbeat limit 1 for update skip locked;
  if found then
    if random() < 0.5 then wid := uid; bid := opp.user_id; else wid := opp.user_id; bid := uid; end if;
    insert into public.magic_games (white_id, black_id, base_sec, inc_sec, white_ms, black_ms, seed)
      values (wid, bid, p_base, p_inc, p_base * 1000::bigint, p_base * 1000::bigint, floor(random() * 9007199254740991)::bigint)
      returning * into g;
    update public.magic_queue set game_id = g.id where user_id = opp.user_id;
    delete from public.magic_queue where user_id = uid;
    return jsonb_build_object('status', 'matched', 'game', public._magic_view(g));
  end if;

  -- 4) Chưa có ai: vào / giữ chỗ trong hàng đợi
  insert into public.magic_queue (user_id, base_sec, inc_sec, heartbeat)
    values (uid, p_base, p_inc, now())
    on conflict (user_id) do update
      set base_sec = excluded.base_sec, inc_sec = excluded.inc_sec, heartbeat = now(), game_id = null;
  return jsonb_build_object('status', 'waiting');
end $$;

create or replace function public.magic_cancel_search()
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  q   public.magic_queue;
  g   public.magic_games;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  delete from public.magic_queue where user_id = uid returning * into q;
  if found and q.game_id is not null then
    select * into g from public.magic_games where id = q.game_id;
    if found then return jsonb_build_object('status', 'matched', 'game', public._magic_view(g)); end if;
  end if;
  return jsonb_build_object('status', 'cancelled');
end $$;

-- Lấy trạng thái ván (app gọi liên tục). Tự xử hết giờ / hủy ván bỏ dở.
create or replace function public.magic_get_game(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  g public.magic_games;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or auth.uid() is null or auth.uid() not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._magic_settle(g);
  return public._magic_view(g);
end $$;

-- Gửi một hành động. p_n = số hành động đã ghi TRƯỚC hành động này (chống gửi trùng / lệch thứ tự).
-- p_next = bên có lượt sau hành động này. p_result/p_reason chỉ điền khi hành động này kết thúc ván theo luật.
create or replace function public.magic_act(
  p_id uuid, p_n int, p_act text, p_next text, p_result text default null, p_reason text default null
)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.magic_games;
  el bigint;
  mover_ms bigint;
  new_w bigint;
  new_b bigint;
  switched boolean;
  fin boolean := false;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;

  g := public._magic_settle(g);
  if g.status <> 'active' then return public._magic_view(g); end if;
  if p_n < g.n then return public._magic_view(g); end if;      -- hành động này đã được ghi nhận trước đó
  if p_n > g.n then raise exception 'n_gap'; end if;

  if (g.turn = 'w' and uid <> g.white_id) or (g.turn = 'b' and uid <> g.black_id) then raise exception 'not_your_turn'; end if;
  if p_act is null or p_act !~ '^(o[0-9]|s|r[0-9]|m[a-h][1-8][a-h][1-8][qrbn]?|c[0-9]{1,2}:([0-9]{1,2}(,[0-9]{1,2}){0,3})?)$' then
    raise exception 'bad_action';
  end if;
  if p_next is null or p_next not in ('w', 'b') then raise exception 'bad_next'; end if;

  new_w := g.white_ms;
  new_b := g.black_ms;
  switched := (p_next <> g.turn);
  if switched and g.turns_done >= 2 then
    -- hết lượt khi đồng hồ đang chạy: trừ thời gian đã suy nghĩ, rồi cộng giờ thưởng
    el := greatest(0, floor(extract(epoch from (clock_timestamp() - g.turn_started_at)) * 1000))::bigint;
    mover_ms := case when g.turn = 'w' then g.white_ms else g.black_ms end;
    mover_ms := mover_ms - el + g.inc_sec * 1000::bigint;
    if g.turn = 'w' then new_w := mover_ms; else new_b := mover_ms; end if;
  end if;

  if p_result is not null then
    if p_result not in ('1-0', '0-1', '1/2-1/2') then raise exception 'bad_result'; end if;
    fin := true;
  end if;

  update public.magic_games set
    actions = case when actions = '' then p_act else actions || ' ' || p_act end,
    n = n + 1,
    turn = p_next,
    turns_done = turns_done + (case when switched then 1 else 0 end),
    white_ms = new_w, black_ms = new_b,
    turn_started_at = case when switched then clock_timestamp() else turn_started_at end,
    status = case when fin then 'finished' else 'active' end,
    result = case when fin then p_result else null end,
    reason = case when fin then left(coalesce(nullif(p_reason, ''), 'rule'), 60) else null end,
    finished_at = case when fin then now() else null end
  where id = g.id returning * into g;

  return public._magic_view(g);
end $$;

-- Đầu hàng. Trước khi mỗi bên xong 1 lượt thì chỉ là hủy ván (không ai thắng/thua).
create or replace function public.magic_resign(p_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  g public.magic_games;
begin
  select * into g from public.magic_games where id = p_id for update;
  if not found or uid is null or uid not in (g.white_id, g.black_id) then raise exception 'not_found'; end if;
  g := public._magic_settle(g);
  if g.status <> 'active' then return public._magic_view(g); end if;
  if g.turns_done < 2 then
    update public.magic_games set status = 'aborted', reason = 'abort', finished_at = now()
      where id = g.id returning * into g;
  else
    update public.magic_games set
      status = 'finished', reason = 'resign', finished_at = now(),
      result = case when uid = g.white_id then '0-1' else '1-0' end
    where id = g.id returning * into g;
  end if;
  return public._magic_view(g);
end $$;

-- -----------------------------------------------------------------------------
-- 3) CHAT TRONG VÁN (cờ thường online + Cờ Phép Thuật online)
-- -----------------------------------------------------------------------------
create table if not exists public.game_chat (
  id         bigint generated always as identity primary key,
  game_id    uuid not null,
  kind       text not null default 'chess' check (kind in ('chess', 'magic')),
  user_id    uuid not null references auth.users(id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 200),
  created_at timestamptz not null default now()
);
alter table public.game_chat enable row level security;      -- không có policy: chỉ truy cập qua RPC
create index if not exists game_chat_game on public.game_chat (game_id, kind, id);

-- Người gọi có phải người chơi của ván không.
create or replace function public._chat_member(p_game uuid, p_kind text, p_uid uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_uid is null then return false; end if;
  if p_kind = 'magic' then
    return exists (select 1 from public.magic_games where id = p_game and p_uid in (white_id, black_id));
  end if;
  return exists (select 1 from public.online_games where id = p_game and p_uid in (white_id, black_id));
end $$;

create or replace function public.chat_send(p_game uuid, p_kind text, p_body text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid  uuid := auth.uid();
  txt  text := btrim(coalesce(p_body, ''));
  last_at timestamptz;
  new_id bigint;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_kind not in ('chess', 'magic') then raise exception 'bad_kind'; end if;
  if not public._chat_member(p_game, p_kind, uid) then raise exception 'not_found'; end if;
  if char_length(txt) < 1 or char_length(txt) > 200 then raise exception 'bad_body'; end if;

  select max(created_at) into last_at from public.game_chat where game_id = p_game and user_id = uid;
  if last_at is not null and clock_timestamp() - last_at < interval '600 milliseconds' then raise exception 'too_fast'; end if;

  insert into public.game_chat (game_id, kind, user_id, body) values (p_game, p_kind, uid, txt) returning id into new_id;
  return jsonb_build_object('id', new_id);
end $$;

-- Tin nhắn mới hơn p_after (tối đa 100 tin gần nhất), cũ -> mới.
create or replace function public.chat_list(p_game uuid, p_kind text, p_after bigint default 0)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  result_json jsonb;
begin
  if uid is null then raise exception 'not_signed_in'; end if;
  if p_kind not in ('chess', 'magic') then raise exception 'bad_kind'; end if;
  if not public._chat_member(p_game, p_kind, uid) then raise exception 'not_found'; end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'id', c.id, 'user_id', c.user_id,
      'name', coalesce(u.display_name, 'Người chơi'),
      'body', c.body,
      'ts', (extract(epoch from c.created_at) * 1000)::bigint
    ) order by c.id), '[]'::jsonb)
    into result_json
  from (
    select * from public.game_chat
      where game_id = p_game and kind = p_kind and id > coalesce(p_after, 0)
      order by id desc limit 100
  ) c
  left join public.users u on u.id = c.user_id;
  return result_json;
end $$;

-- -----------------------------------------------------------------------------
-- Quyền: chỉ người đã đăng nhập được gọi RPC; hàm nội bộ không mở cho ai.
-- -----------------------------------------------------------------------------
revoke all on function public._magic_settle(public.magic_games) from public, anon, authenticated;
revoke all on function public._magic_view(public.magic_games) from public, anon, authenticated;
revoke all on function public._chat_member(uuid, text, uuid) from public, anon, authenticated;

revoke all on function public.leaderboard_rank(text) from public, anon;
revoke all on function public.magic_find_match(int, int) from public, anon;
revoke all on function public.magic_cancel_search() from public, anon;
revoke all on function public.magic_get_game(uuid) from public, anon;
revoke all on function public.magic_act(uuid, int, text, text, text, text) from public, anon;
revoke all on function public.magic_resign(uuid) from public, anon;
revoke all on function public.chat_send(uuid, text, text) from public, anon;
revoke all on function public.chat_list(uuid, text, bigint) from public, anon;

grant execute on function public.leaderboard_rank(text) to authenticated;
grant execute on function public.magic_find_match(int, int) to authenticated;
grant execute on function public.magic_cancel_search() to authenticated;
grant execute on function public.magic_get_game(uuid) to authenticated;
grant execute on function public.magic_act(uuid, int, text, text, text, text) to authenticated;
grant execute on function public.magic_resign(uuid) to authenticated;
grant execute on function public.chat_send(uuid, text, text) to authenticated;
grant execute on function public.chat_list(uuid, text, bigint) to authenticated;
