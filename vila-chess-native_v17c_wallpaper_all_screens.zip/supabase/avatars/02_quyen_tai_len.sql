-- BƯỚC 2/4: chỉ chủ tài khoản được TẢI LÊN ảnh vào thư mục mang uid của chính mình.
drop policy if exists "avatars_insert_own" on storage.objects;
create policy "avatars_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
