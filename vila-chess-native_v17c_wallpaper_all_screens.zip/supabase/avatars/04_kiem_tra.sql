-- BƯỚC 4/4 (chỉ để kiểm tra, không thay đổi gì).
-- Kỳ vọng: 1 dòng bucket (public = true) và 3 dòng policy avatars_*.
select id, public, file_size_limit, allowed_mime_types from storage.buckets where id = 'avatars';
select policyname, cmd from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname like 'avatars_%' order by policyname;
