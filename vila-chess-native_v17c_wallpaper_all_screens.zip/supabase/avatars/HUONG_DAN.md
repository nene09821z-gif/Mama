# Triển khai SQL cho ảnh đại diện (Supabase → SQL Editor)

Chạy lần lượt, mỗi file dán vào một tab "New query" rồi bấm Run:
1. 01_tao_bucket.sql      → tạo kho ảnh `avatars`
2. 02_quyen_tai_len.sql   → quyền tải lên
3. 03_quyen_sua_xoa.sql   → quyền sửa/xoá
4. 04_kiem_tra.sql        → phải thấy 1 bucket + 3 policy

(Muốn chạy một lần: dùng ../avatars.sql — gộp cả 3 bước đầu.)

Nếu bước 2/3 báo "must be owner of table objects": vào Storage → bucket `avatars` → Policies → New policy → "For full customization",
tạo 3 policy (INSERT / UPDATE / DELETE), role `authenticated`, biểu thức:
  bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text

Đã chạy schema.sql (bảng users) từ trước thì KHÔNG cần chạy lại.
