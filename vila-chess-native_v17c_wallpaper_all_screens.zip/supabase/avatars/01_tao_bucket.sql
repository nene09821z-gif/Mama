-- BƯỚC 1/4: tạo kho ảnh công khai "avatars" (tối đa 512KB/ảnh, chỉ JPEG). Chạy lại nhiều lần vẫn an toàn.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 524288, array['image/jpeg'])
on conflict (id) do update
  set public = true, file_size_limit = 524288, allowed_mime_types = array['image/jpeg'];
