# v16k — Mỗi bot một khai cuộc riêng

- Thêm `bots/BotRepertoire.kt`: đọc `assets/openings.tsv` (main.yml tải về từ Lichess; thiếu thì dùng bộ rút gọn) và tạo bộ khai cuộc riêng cho từng bot.
- Mỗi nước, bot gom các dòng khai cuộc khớp với ván, chọn nước kế tiếp ngẫu nhiên có trọng số: gu riêng của bot (băm từ id bot + thế cờ, cố định) x độ phổ biến của nước.
- Theo Elo: Elo thấp = sách ngắn (Martin ~5 nước), hay quên sách, gu "lạ"; Elo cao = sách sâu (Mittens ~21 nước), thiên về dòng chính.
- Hết sách / người chơi đi lệch sách / bot quên sách -> Stockfish theo Elo của bot tự đi tiếp (BotEngineManager giữ nguyên).
- `GameViewModel.startEngineIfNeeded`: gọi sách trước, chỉ khi ván bắt đầu từ thế chuẩn; "Ván mới" chọn lại khai cuộc.
- Test mới: `BotRepertoireTest`.
- main.yml KHÔNG cần sửa: bước "Download full opening book" đã tải openings.tsv.
