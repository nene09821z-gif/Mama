# v16o — Hệ thống 30 thành tựu

## Mới
- game/Achievements.kt (thuần Kotlin): 30 thành tựu chia 5 nhóm × 6, 4 hạng (Đồng 10đ · Bạc 25đ · Vàng 50đ · Kim cương 100đ), tổng 1.065 điểm.
  Có `GameFactsBuilder` rút số liệu từ danh sách nước đi (nhập thành, phong Hậu/phong cấp thấp, bắt tốt qua đường, chiếu hết trong N nước, lội ngược dòng) và `AchEngine` chấm điểm.
- game/AchievementStore.kt: lưu bền (SharedPreferences "vila_ach"), mở khóa là mở mãi mãi kèm ngày đạt, phát sự kiện cho banner.
  Lần chạy đầu sau khi cập nhật chỉ ghi nhận thầm lặng thành tựu đã đạt từ trước (không bắn banner hàng loạt).
- ui/AchievementsUi.kt: thẻ tổng quan (đã đạt/30, điểm, số huy chương từng hạng), lọc Tất cả/Đã đạt/Chưa đạt, danh sách theo nhóm có thanh tiến độ, chạm xem chi tiết + ngày đạt, banner trượt từ trên xuống khi mở khóa.
- test: AchievementsTest.kt (danh mục, rút số liệu từ ván thật bằng GameSession, kỷ lục không tụt…).

## 30 thành tựu
Chăm chỉ: Ván đầu tiên · Chăm chỉ (10 ván) · Cày cuốc (100 ván) · Chuỗi 3 ngày · Tuần lễ cờ (7 ngày) · Kiên trì bền bỉ (30 ngày)
Chiến thắng: Chiến thắng đầu tiên · Quen mùi chiến thắng (25) · Bách chiến bách thắng (100) · Khởi động nóng (3 liên tiếp) · Thế chẻ tre (5) · Bất khả chiến bại (10)
Kỹ năng: Vua về nhà · Tốt hóa Hậu · Bắt tốt qua đường · Phong cấp tinh tế · Chiếu hết chớp nhoáng (≤25 nước) · Lội ngược dòng (từng kém ≥5 điểm quân)
Đối thủ & Hệ số: Hệ số 1000 · Kỳ thủ khá (1400) · Cao thủ (1800) · Hạ gục Bot cấp 4 · Chinh phục Bot tối thượng (cấp 8) · Hoàn thành giải đấu
Học tập & Khám phá: Tập giải đố (10 màn) · Thiên tài chiến thuật (100 màn) · Học trò ngoan · Nhà phân tích (5 lần Game Review) · Pháp sư cờ · Nhà thiết kế (đổi bàn cờ, quân, nền, âm thanh)

## Nối vào app
- GameViewModel.finishIfOver: chấm lại sau mỗi ván; kỹ năng chỉ tính ván Bot/Giải đấu/Online từ thế cờ chuẩn (không tính 2 người cùng máy, tàn cuộc, FEN tự chọn).
- GameViewModel: đếm Game Review, đổi bàn cờ/quân/nền/âm thanh, hoàn thành bài học.
- PuzzleMapViewModel.onPuzzleSolved, MagicChessScreen (ván có kết quả), MainActivity (banner).
- Hồ sơ > tab Thành tựu và nút "Giải thưởng" ở màn chính dùng chung `AchievementsPanel`.

## Đã bỏ
- 6 thành tích cũ trong Stats.kt và 4 huy hiệu giả lập trong ProfileTabs.kt (thay bằng 30 thành tựu thật).

## Lưu ý
- Số liệu có từ trước (số ván, thắng, chuỗi, hệ số, câu đố, giải đấu, bài học) được tính hồi tố; các bộ đếm mới (nhập thành, phong cấp, cấp bot đã thắng…) chỉ tính từ bản này.
- Chưa build được ở đây (không có Android SDK / Maven bị chặn) — chạy ./gradlew testDebugUnitTest assembleDebug hoặc đẩy lên GitHub Actions.
