package com.vila.chess.game

import com.vila.chess.core.EMPTY
import com.vila.chess.core.FLAG_CASTLE
import com.vila.chess.core.FLAG_EP
import com.vila.chess.core.QUEEN
import com.vila.chess.core.moveFlag
import com.vila.chess.core.movePromo
import com.vila.chess.core.pieceType
import com.vila.chess.core.pieceValue

// =============================================================================
// HỆ THỐNG 30 THÀNH TỰU (thuần Kotlin, không Android -> test bằng JVM).
//   • AchDef      : định nghĩa 1 thành tựu (tên, mô tả, nhóm, hạng, mục tiêu, cách đo tiến độ).
//   • AchStats    : bộ đếm trọn đời mà PlayerStats chưa có (nhập thành, phong cấp, bắt tốt qua đường…).
//   • AchSnapshot : mọi số liệu đầu vào cho 1 lần chấm điểm (AchStats + số liệu từ PlayerStats/câu đố/bài học…).
//   • AchEngine   : hàm thuần cập nhật AchStats sau mỗi ván và chấm điểm 30 thành tựu.
// Lưu bền + thông báo mở khóa nằm ở AchievementStore.kt.
// =============================================================================

/** Hạng huy chương; [points] = điểm thành tựu nhận được khi mở khóa. */
enum class AchTier(val label: String, val points: Int) {
    BRONZE("Đồng", 10),
    SILVER("Bạc", 25),
    GOLD("Vàng", 50),
    DIAMOND("Kim cương", 100),
}

enum class AchCategory(val label: String) {
    HABIT("Chăm chỉ"),
    WINS("Chiến thắng"),
    SKILL("Kỹ năng"),
    RANK("Đối thủ & Hệ số"),
    LEARN("Học tập & Khám phá"),
}

/** Bit của [AchStats.designMask]: mỗi loại tùy chỉnh giao diện đã từng đổi. */
object DesignBit {
    const val BOARD = 1
    const val PIECES = 2
    const val WALLPAPER = 4
    const val SOUND = 8
    const val ALL = BOARD or PIECES or WALLPAPER or SOUND
}

/** Bộ đếm trọn đời (lưu SharedPreferences). Chỉ tăng, không bao giờ giảm. */
data class AchStats(
    val castles: Int = 0,
    val queenPromos: Int = 0,
    val underPromos: Int = 0,
    val enPassants: Int = 0,
    /** Số nước ít nhất mà người chơi đã chiếu hết đối thủ; 0 = chưa từng thắng bằng chiếu hết. */
    val fastestMate: Int = 0,
    val comebackWins: Int = 0,
    /** Chuỗi thắng dài nhất từng đạt. */
    val bestWinStreak: Int = 0,
    /** Chuỗi ngày chơi liên tiếp dài nhất từng đạt. */
    val bestDayStreak: Int = 0,
    /** Hệ số cao nhất từng đạt ở bất kỳ thể loại nào. */
    val peakRating: Int = 0,
    /** Cấp bot cao nhất từng thắng (0 = chưa thắng bot nào). */
    val maxLevelBeaten: Int = 0,
    val reviews: Int = 0,
    val magicGames: Int = 0,
    val designMask: Int = 0,
)

/** Số liệu thô của 1 ván, rút ra từ danh sách nước đi. */
data class GameFacts(
    val castles: Int = 0,
    val queenPromos: Int = 0,
    val underPromos: Int = 0,
    val enPassants: Int = 0,
    /** Người chơi thắng bằng chiếu hết trong bao nhiêu nước (0 nếu không phải thắng chiếu hết). */
    val mateInMoves: Int = 0,
    val comeback: Boolean = false,
)

object GameFactsBuilder {
    /** Kém quân tối thiểu (centipawn, theo quân đã bị bắt) để tính là "lội ngược dòng": 500 = một quân Xe. */
    const val COMEBACK_DEFICIT = 500

    /**
     * [humanWhite]: người chơi cầm Trắng? [checkmate]: ván kết thúc bằng chiếu hết?
     * Cán cân quân chỉ được đo SAU mỗi nước của người chơi (đã kịp ăn lại) để các cuộc đổi quân
     * giữa chừng không bị tính nhầm là đang kém quân.
     */
    fun from(records: List<MoveRecord>, humanWhite: Boolean, humanWon: Boolean, checkmate: Boolean): GameFacts {
        var castles = 0
        var queenPromos = 0
        var underPromos = 0
        var enPassants = 0
        var humanMoves = 0
        var balance = 0
        var minBalance = 0
        for (r in records) {
            val captured = if (r.captured != EMPTY) pieceValue(pieceType(r.captured)) else 0
            if (r.whiteMoved == humanWhite) {
                humanMoves++
                when (moveFlag(r.move)) {
                    FLAG_CASTLE -> castles++
                    FLAG_EP -> enPassants++
                }
                val promo = movePromo(r.move)
                if (promo == QUEEN) queenPromos++ else if (promo != 0) underPromos++
                balance += captured
                if (balance < minBalance) minBalance = balance
            } else {
                balance -= captured
            }
        }
        return GameFacts(
            castles = castles,
            queenPromos = queenPromos,
            underPromos = underPromos,
            enPassants = enPassants,
            mateInMoves = if (humanWon && checkmate) humanMoves else 0,
            comeback = humanWon && minBalance <= -COMEBACK_DEFICIT,
        )
    }
}

/** Mọi đầu vào cho 1 lần chấm điểm. */
data class AchSnapshot(
    val stats: AchStats = AchStats(),
    val played: Int = 0,
    val won: Int = 0,
    val tournamentsDone: Int = 0,
    /** Số màn câu đố đã vượt (= level hiện tại - 1). */
    val puzzlesSolved: Int = 0,
    val lessonsDone: Int = 0,
)

class AchDef(
    val id: String,
    val title: String,
    val desc: String,
    val category: AchCategory,
    val tier: AchTier,
    val target: Int,
    /** Khóa biểu tượng; lớp UI đổi sang ImageVector (giữ file này thuần Kotlin). */
    val icon: String,
    val value: (AchSnapshot) -> Int,
)

class AchState(val def: AchDef, val value: Int) {
    val progress: Int get() = value.coerceIn(0, def.target)
    val done: Boolean get() = value >= def.target
    val fraction: Float get() = if (def.target <= 0) 1f else progress.toFloat() / def.target
}

object Achievements {
    /** Nhanh nhất để tính là "chiếu hết chớp nhoáng". */
    const val BLITZ_MATE_MOVES = 25

    val all: List<AchDef> = listOf(
        // ---- Chăm chỉ (6)
        AchDef("first_game", "Ván đầu tiên", "Chơi xong 1 ván cờ", AchCategory.HABIT, AchTier.BRONZE, 1, "play") { it.played },
        AchDef("diligent", "Chăm chỉ", "Chơi xong 10 ván", AchCategory.HABIT, AchTier.BRONZE, 10, "fitness") { it.played },
        AchDef("grinder", "Cày cuốc", "Chơi xong 100 ván", AchCategory.HABIT, AchTier.SILVER, 100, "games") { it.played },
        AchDef("days_3", "Chuỗi 3 ngày", "Chơi 3 ngày liên tiếp", AchCategory.HABIT, AchTier.BRONZE, 3, "fire") { it.stats.bestDayStreak },
        AchDef("days_7", "Tuần lễ cờ", "Chơi 7 ngày liên tiếp", AchCategory.HABIT, AchTier.SILVER, 7, "history") { it.stats.bestDayStreak },
        AchDef("days_30", "Kiên trì bền bỉ", "Chơi 30 ngày liên tiếp", AchCategory.HABIT, AchTier.DIAMOND, 30, "premium") { it.stats.bestDayStreak },

        // ---- Chiến thắng (6)
        AchDef("first_win", "Chiến thắng đầu tiên", "Thắng 1 ván với máy", AchCategory.WINS, AchTier.BRONZE, 1, "trophy") { it.won },
        AchDef("wins_25", "Quen mùi chiến thắng", "Thắng 25 ván", AchCategory.WINS, AchTier.SILVER, 25, "military") { it.won },
        AchDef("wins_100", "Bách chiến bách thắng", "Thắng 100 ván", AchCategory.WINS, AchTier.GOLD, 100, "premium") { it.won },
        AchDef("streak_3", "Khởi động nóng", "Thắng liên tiếp 3 ván", AchCategory.WINS, AchTier.BRONZE, 3, "bolt") { it.stats.bestWinStreak },
        AchDef("streak_5", "Thế chẻ tre", "Thắng liên tiếp 5 ván", AchCategory.WINS, AchTier.SILVER, 5, "fire") { it.stats.bestWinStreak },
        AchDef("streak_10", "Bất khả chiến bại", "Thắng liên tiếp 10 ván", AchCategory.WINS, AchTier.DIAMOND, 10, "shield") { it.stats.bestWinStreak },

        // ---- Kỹ năng (6)
        AchDef("castle", "Vua về nhà", "Nhập thành trong một ván", AchCategory.SKILL, AchTier.BRONZE, 1, "shield") { it.stats.castles },
        AchDef("promote", "Tốt hóa Hậu", "Phong một quân Tốt thành Hậu", AchCategory.SKILL, AchTier.BRONZE, 1, "star") { it.stats.queenPromos },
        AchDef("en_passant", "Bắt tốt qua đường", "Ăn quân bằng nước bắt tốt qua đường (en passant)", AchCategory.SKILL, AchTier.SILVER, 1, "swap") { it.stats.enPassants },
        AchDef("underpromo", "Phong cấp tinh tế", "Phong Tốt thành Mã, Tượng hoặc Xe", AchCategory.SKILL, AchTier.GOLD, 1, "puzzle") { it.stats.underPromos },
        AchDef("blitz_mate", "Chiếu hết chớp nhoáng", "Chiếu hết đối thủ trong vòng $BLITZ_MATE_MOVES nước", AchCategory.SKILL, AchTier.SILVER, 1, "bolt") {
            if (it.stats.fastestMate in 1..BLITZ_MATE_MOVES) 1 else 0
        },
        AchDef("comeback", "Lội ngược dòng", "Thắng sau khi từng kém từ 5 điểm quân trở lên", AchCategory.SKILL, AchTier.GOLD, 1, "refresh") { it.stats.comebackWins },

        // ---- Đối thủ & Hệ số (6)
        AchDef("elo_1000", "Hệ số 1000", "Đạt hệ số 1000 ở một thể loại", AchCategory.RANK, AchTier.SILVER, 1000, "flag") { it.stats.peakRating },
        AchDef("elo_1400", "Kỳ thủ khá", "Đạt hệ số 1400", AchCategory.RANK, AchTier.GOLD, 1400, "military") { it.stats.peakRating },
        AchDef("elo_1800", "Cao thủ", "Đạt hệ số 1800", AchCategory.RANK, AchTier.DIAMOND, 1800, "premium") { it.stats.peakRating },
        AchDef("beat_lvl4", "Hạ gục Bot cấp 4", "Thắng Bot từ cấp 4 trở lên", AchCategory.RANK, AchTier.SILVER, 4, "bot") { it.stats.maxLevelBeaten },
        AchDef("beat_lvl8", "Chinh phục Bot tối thượng", "Thắng Bot cấp 8", AchCategory.RANK, AchTier.DIAMOND, 8, "trophy") { it.stats.maxLevelBeaten },
        AchDef("tournament", "Hoàn thành giải đấu", "Đấu hết 8 vòng giải đấu bot", AchCategory.RANK, AchTier.GOLD, 1, "groups") { it.tournamentsDone },

        // ---- Học tập & Khám phá (6)
        AchDef("puzzles_10", "Tập giải đố", "Vượt 10 màn câu đố", AchCategory.LEARN, AchTier.BRONZE, 10, "puzzle") { it.puzzlesSolved },
        AchDef("puzzles_100", "Thiên tài chiến thuật", "Vượt 100 màn câu đố", AchCategory.LEARN, AchTier.GOLD, 100, "brain") { it.puzzlesSolved },
        AchDef("lesson_1", "Học trò ngoan", "Hoàn thành 1 bài học tàn cuộc", AchCategory.LEARN, AchTier.BRONZE, 1, "lightbulb") { it.lessonsDone },
        AchDef("review_5", "Nhà phân tích", "Dùng Game Review cho 5 ván", AchCategory.LEARN, AchTier.SILVER, 5, "search") { it.stats.reviews },
        AchDef("magic_1", "Pháp sư cờ", "Chơi trọn 1 ván Cờ Phép Thuật", AchCategory.LEARN, AchTier.SILVER, 1, "star") { it.stats.magicGames },
        AchDef("designer", "Nhà thiết kế", "Đổi bàn cờ, quân cờ, hình nền và âm thanh", AchCategory.LEARN, AchTier.SILVER, 4, "palette") {
            Integer.bitCount(it.stats.designMask and DesignBit.ALL)
        },
    )

    val total: Int get() = all.size
    val totalPoints: Int get() = all.sumOf { it.tier.points }
}

object AchEngine {
    /** Chấm điểm toàn bộ 30 thành tựu theo thứ tự trong [Achievements.all]. */
    fun evaluate(s: AchSnapshot): List<AchState> = Achievements.all.map { AchState(it, it.value(s)) }

    /** Cộng số liệu của một ván vừa xong. [level] = cấp bot (0 nếu không phải ván với bot). */
    fun applyGame(old: AchStats, facts: GameFacts, humanWon: Boolean, level: Int): AchStats = old.copy(
        castles = old.castles + facts.castles,
        queenPromos = old.queenPromos + facts.queenPromos,
        underPromos = old.underPromos + facts.underPromos,
        enPassants = old.enPassants + facts.enPassants,
        fastestMate = when {
            facts.mateInMoves <= 0 -> old.fastestMate
            old.fastestMate <= 0 -> facts.mateInMoves
            else -> minOf(old.fastestMate, facts.mateInMoves)
        },
        comebackWins = old.comebackWins + if (facts.comeback) 1 else 0,
        maxLevelBeaten = if (humanWon && level > 0) maxOf(old.maxLevelBeaten, level) else old.maxLevelBeaten,
    )

    /** Kéo các kỷ lục "đỉnh" từ PlayerStats vào AchStats (chuỗi thắng, chuỗi ngày, hệ số cao nhất). */
    fun syncPeaks(old: AchStats, p: PlayerStats, today: Long): AchStats = old.copy(
        bestWinStreak = maxOf(old.bestWinStreak, p.resultStreak),
        bestDayStreak = maxOf(old.bestDayStreak, p.activeStreak(today)),
        peakRating = maxOf(old.peakRating, p.ratings.maxOrNull() ?: 0),
    )

    fun totalPoints(states: List<AchState>): Int = states.filter { it.done }.sumOf { it.def.tier.points }
}
