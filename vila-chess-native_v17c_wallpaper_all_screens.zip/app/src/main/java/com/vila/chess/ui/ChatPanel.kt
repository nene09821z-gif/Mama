package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.online.ChatKind
import com.vila.chess.online.ChatLogic
import com.vila.chess.online.ChatMessage
import com.vila.chess.online.ChatRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Trạng thái chat của một ván: danh sách tin + mốc đã đọc. Do [rememberChat] giữ suốt ván. */
class ChatState(val myId: String?) {
    var messages by mutableStateOf(listOf<ChatMessage>())
    var seenUpTo by mutableLongStateOf(0L)
    var error by mutableStateOf<String?>(null)

    val unread: Int get() = ChatLogic.unread(messages, myId, seenUpTo)
}

/**
 * Giữ khung chat của ván [gameId] và kéo tin mới liên tục (1,5 giây khi đang mở khung, 5 giây khi đóng để còn đếm tin chưa đọc).
 * [gameId] = null: chưa có ván => không làm gì.
 */
@Composable
fun rememberChat(gameId: String?, kind: ChatKind, panelOpen: Boolean): ChatState {
    val ctx = LocalContext.current.applicationContext
    val state = remember(gameId) { ChatState(SupabaseCloud.userId(ctx)) }
    LaunchedEffect(gameId, panelOpen) {
        if (gameId == null) return@LaunchedEffect
        while (true) {
            val r = ChatRepository.list(ctx, gameId, kind, ChatLogic.lastId(state.messages))
            val more = r.getOrNull()
            if (more != null && more.isNotEmpty()) state.messages = ChatLogic.merge(state.messages, more)
            delay(if (panelOpen) 1500L else 5000L)
        }
    }
    LaunchedEffect(panelOpen, state.messages.size) {
        if (panelOpen) state.seenUpTo = ChatLogic.lastId(state.messages)
    }
    return state
}

/** Khung chat trượt từ dưới lên: danh sách tin, câu trả lời nhanh, ô nhập. Chạm vùng tối phía trên để đóng. */
@Composable
fun ChatPanel(state: ChatState, gameId: String, kind: ChatKind, opponentName: String, onClose: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) listState.animateScrollToItem(state.messages.lastIndex)
    }

    val send: (String) -> Unit = { raw ->
        val body = ChatLogic.clean(raw)
        if (body.isNotEmpty() && !sending) {
            sending = true
            scope.launch {
                val r = ChatRepository.send(ctx, gameId, kind, body)
                if (r.isSuccess) {
                    text = ""
                    state.error = null
                    val more = ChatRepository.list(ctx, gameId, kind, ChatLogic.lastId(state.messages)).getOrNull()
                    if (more != null) state.messages = ChatLogic.merge(state.messages, more)
                } else {
                    state.error = "Chưa gửi được. Gửi chậm lại một chút hoặc kiểm tra mạng."
                }
                sending = false
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClose),
        )
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .imePadding()
                .fillMaxHeight(0.62f)
                .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                .background(Color(0xFF262522))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { /* nuốt chạm để không đóng khung */ }
                .navigationBarsPadding(),
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("💬 Chat với $opponentName", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("Đóng", color = VilaColors.Green, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable(onClick = onClose).padding(6.dp))
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (state.messages.isEmpty()) {
                    Text(
                        "Chưa có tin nhắn. Hãy chào đối thủ nhé 👋", color = VilaColors.TextDim, fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.Center),
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        items(state.messages, key = { it.id }) { m -> Bubble(m, mine = m.userId.equals(state.myId, ignoreCase = true)) }
                    }
                }
            }

            state.error?.let {
                Text(it, color = VilaColors.Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp))
            }

            LazyRow(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(ChatLogic.QUICK_REPLIES) { q ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(VilaColors.PanelRaised)
                            .clickable { send(q) }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                    ) { Text(q, color = Color(0xFFE6E6E6), fontSize = 13.sp, maxLines = 1) }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box(
                    Modifier
                        .weight(1f)
                        .heightIn(min = 44.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF3A3834))
                        .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(22.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart,
                ) {
                    BasicTextField(
                        value = text,
                        onValueChange = { v -> text = v.take(ChatLogic.MAX_LEN) },
                        textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                        cursorBrush = SolidColor(VilaColors.Green),
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            if (text.isEmpty()) Text("Nhập tin nhắn…", color = VilaColors.TextDim, fontSize = 15.sp)
                            inner()
                        },
                    )
                }
                Box(
                    Modifier
                        .clip(RoundedCornerShape(22.dp))
                        .background(if (text.isNotBlank() && !sending) VilaColors.Green else VilaColors.PanelRaised)
                        .clickable(enabled = text.isNotBlank() && !sending) { send(text) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Gửi", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier
                .widthIn(max = 260.dp)
                .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomStart = if (mine) 14.dp else 4.dp, bottomEnd = if (mine) 4.dp else 14.dp))
                .background(if (mine) Color(0xFF3F6B2C) else Color(0xFF3A3834))
                .padding(horizontal = 11.dp, vertical = 7.dp),
        ) {
            if (!mine) Text(m.name, color = Color(0xFFB9C1CE), fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(m.body, color = Color.White, fontSize = 14.sp, lineHeight = 18.sp)
        }
    }
}
