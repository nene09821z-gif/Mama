package com.vila.chess.online

import android.content.Context
import com.vila.chess.cloud.SupabaseCloud
import org.json.JSONArray
import org.json.JSONObject

/** Loại ván của chat: ván cờ thường online hay Cờ Phép Thuật online. */
enum class ChatKind(val key: String) { CHESS("chess"), MAGIC("magic") }

/** Gọi chat_send / chat_list trong supabase/social.sql. Không ném lỗi: trả [Result]. */
object ChatRepository {
    suspend fun send(ctx: Context, gameId: String, kind: ChatKind, body: String): Result<Long> {
        val text = ChatLogic.clean(body)
        if (text.isEmpty()) return Result.failure(IllegalArgumentException("empty"))
        val args = JSONObject().put("p_game", gameId).put("p_kind", kind.key).put("p_body", text)
        return SupabaseCloud.restCall(ctx, "POST", "/rest/v1/rpc/chat_send", args.toString())
            .mapCatching { JSONObject(it).optLong("id", 0L) }
    }

    /** Tin nhắn có id lớn hơn [afterId], cũ -> mới. */
    suspend fun list(ctx: Context, gameId: String, kind: ChatKind, afterId: Long): Result<List<ChatMessage>> {
        val args = JSONObject().put("p_game", gameId).put("p_kind", kind.key).put("p_after", afterId)
        return SupabaseCloud.restCall(ctx, "POST", "/rest/v1/rpc/chat_list", args.toString())
            .mapCatching { text ->
                val arr = JSONArray(text)
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    ChatMessage(
                        id = o.getLong("id"),
                        userId = o.optString("user_id", ""),
                        name = o.optString("name", "Người chơi"),
                        body = o.optString("body", ""),
                        ts = o.optLong("ts", 0L),
                    )
                }
            }
    }
}
