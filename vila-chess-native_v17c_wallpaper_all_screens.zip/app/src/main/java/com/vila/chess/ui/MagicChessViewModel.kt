package com.vila.chess.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.core.moveUci
import com.vila.chess.game.TimeControls
import com.vila.chess.magic.MagicActions
import com.vila.chess.magic.MagicClock
import com.vila.chess.magic.MagicGame
import com.vila.chess.magic.MagicResult
import com.vila.chess.magic.idx
import com.vila.chess.magic.sideName
import com.vila.chess.online.MagicMatchResult
import com.vila.chess.online.MagicOnlineGame
import com.vila.chess.online.MagicOnlineRepository
import com.vila.chess.profile.ProfileError
import com.vila.chess.profile.ProfileException
import com.vila.chess.profile.message
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Màn hình đang hiện của Cờ Phép Thuật: sảnh (chọn chế độ + giờ), đang tìm đối thủ, hoặc đang chơi. */
enum class MagicStage { LOBBY, SEARCHING, PLAYING }

/** Cùng máy (2 người chuyền máy) hoặc online (ghép trận qua máy chủ). */
enum class MagicMode { LOCAL, ONLINE }

/** Kết quả ván để hiện trong hộp thoại. [iWon] = null khi hòa / ván cùng máy / ván bị hủy. */
class MagicEndInfo(val title: String, val detail: String, val iWon: Boolean?)

private class PendingAction(val n: Int, val action: String, val next: Char, val result: String?, val reason: String?)

/**
 * Trạng thái Cờ Phép Thuật nằm trong ViewModel riêng để không mất khi xoay màn hình; không đụng tới GameViewModel của ván thường.
 *
 * Mọi hành động của người chơi (nhận bài, dùng bài, tái chế, đi quân) đi qua [perform] với cùng một bộ mã hóa [MagicActions],
 * nên ván cùng máy và ván online chạy đúng cùng một luật. Ván online: hành động áp dụng ngay lên máy mình rồi xếp hàng gửi lên
 * máy chủ; hành động của đối thủ được kéo về và áp dụng theo thứ tự. Ván là hàm tất định của (hạt giống, chuỗi hành động).
 */
class MagicChessViewModel(private val app: Application) : AndroidViewModel(app) {
    var game by mutableStateOf(MagicGame())
        private set

    /** Tăng sau mỗi thao tác để giao diện vẽ lại (MagicGame là đối tượng thường, không phải state). */
    var tick by mutableIntStateOf(0)
        private set

    /** Chế độ chuyền máy: bài chỉ hiện sau khi người chơi chạm xác nhận. Ván online luôn là true. */
    var revealed by mutableStateOf(false)

    var stage by mutableStateOf(MagicStage.LOBBY)
        private set

    /** Chế độ của ván ĐANG chơi. */
    var mode by mutableStateOf(MagicMode.LOCAL)
        private set

    /** Chế độ đang chọn ở sảnh (không đổi ván đang chơi). */
    var lobbyMode by mutableStateOf(MagicMode.LOCAL)

    /** Cùng máy: tự xoay bàn để bên đang đi luôn ở phía dưới. */
    var autoFlip by mutableStateOf(false)

    var localTimeIndex by mutableIntStateOf(0)
    var onlineTimeIndex by mutableIntStateOf(2)

    var lobbyError by mutableStateOf<String?>(null)
        private set
    var searchStartedAt by mutableLongStateOf(0L)
        private set
    var connectionLost by mutableStateOf(false)
        private set

    /** Tăng ~5 lần/giây khi đang chơi: chỉ các ô đồng hồ đọc giá trị này nên chỉ chúng vẽ lại. */
    var clockTick by mutableLongStateOf(0L)
        private set

    // ---- ván online ----
    var myWhite by mutableStateOf(true)
        private set
    var oppName by mutableStateOf("")
        private set
    var oppTier by mutableStateOf(MembershipTier.FREE)
        private set
    var onlineGameId by mutableStateOf<String?>(null)
        private set

    /** Đã tính thành tựu cho ván hiện tại chưa (tránh đếm lại khi vào lại màn hình). */
    var resultCounted: Boolean = false

    /** Thông báo do hành động của ĐỐI THỦ tạo ra (vd. «Đen dùng …»). */
    var remoteNotice by mutableStateOf<String?>(null)
        private set

    private var serverOver by mutableStateOf<MagicOnlineGame?>(null)
    private var onlineGame: MagicOnlineGame? = null
    private var outbox = Channel<PendingAction>(Channel.UNLIMITED)
    private var localCount = 0
    private var failCount = 0

    private var searchJob: Job? = null
    private var sendJob: Job? = null
    private var pollJob: Job? = null
    private var clockJob: Job? = null

    // ---- đồng hồ ----
    private var localClock = MagicClock(0, 0)
    private var clockEnabled = false
    private var incMs = 0L
    private var onlineTurns = 0
    private var running = -1
    private val msAt = LongArray(2)
    private val sinceNanos = LongArray(2)

    // ------------------------------------------------------------------ Truy vấn

    val isOnline: Boolean get() = mode == MagicMode.ONLINE && stage == MagicStage.PLAYING

    /** Có ván cùng máy đang dở để "Tiếp tục". */
    val hasLocalGame: Boolean get() = mode == MagicMode.LOCAL && game.result == null && game.s.turnNo > 0

    /** Online: tới lượt mình chưa. Cùng máy: luôn true. */
    val myTurn: Boolean
        get() = if (mode == MagicMode.ONLINE) (serverOver == null && game.result == null && game.whiteToMove == myWhite) else true

    /** Bên nào ở phía DƯỚI màn hình (true = Trắng). */
    val bottomWhite: Boolean
        get() = if (mode == MagicMode.ONLINE) myWhite else !(autoFlip && !game.whiteToMove)

    /** Tay bài của bên nào đang hiện (online: luôn của mình; cùng máy: bên đang có lượt). */
    val viewWhite: Boolean
        get() = if (mode == MagicMode.ONLINE) myWhite else game.whiteToMove

    val clockOn: Boolean get() = clockEnabled

    /** Giờ còn lại (ms) của một bên; -1 nếu không giới hạn giờ. */
    fun clockMs(white: Boolean): Long {
        if (!clockEnabled) return -1L
        val i = idx(white)
        if (mode == MagicMode.LOCAL) return localClock.ms[i]
        val el = if (running == i) (System.nanoTime() - sinceNanos[i]) / 1_000_000L else 0L
        return (msAt[i] - el).coerceAtLeast(0L)
    }

    fun endInfo(): MagicEndInfo? {
        val local = game.result
        val so = serverOver
        if (mode == MagicMode.ONLINE) {
            if (so != null && so.aborted && local == null) return MagicEndInfo("Ván bị hủy", "Chưa tính thắng/thua.", null)
            val code: String? = when (local) {
                is MagicResult.Win -> if (local.white) "1-0" else "0-1"
                is MagicResult.Draw -> "1/2-1/2"
                null -> so?.result
            }
            val detail: String = when (local) {
                is MagicResult.Win -> local.reason
                is MagicResult.Draw -> local.reason
                null -> reasonVi(so?.reason)
            }
            if (code == null) return null
            val draw = code == "1/2-1/2"
            val iWon: Boolean? = if (draw) null else ((code == "1-0") == myWhite)
            val title = when {
                draw -> "Hòa"
                iWon == true -> "Bạn thắng!"
                else -> "Bạn thua"
            }
            return MagicEndInfo(title, detail, iWon)
        }
        return when (local) {
            is MagicResult.Win -> MagicEndInfo("${sideName(local.white)} thắng!", local.reason, null)
            is MagicResult.Draw -> MagicEndInfo("Hòa", local.reason, null)
            null -> null
        }
    }

    private fun reasonVi(r: String?): String = when (r) {
        "timeout" -> "Hết giờ"
        "resign" -> "Đầu hàng"
        "abort", "no_start" -> "Ván bị hủy"
        null -> ""
        else -> r
    }

    private fun reasonOf(r: MagicResult): String = when (r) {
        is MagicResult.Win -> r.reason
        is MagicResult.Draw -> r.reason
    }

    // ------------------------------------------------------------------ Điều hướng sảnh

    fun bump() {
        tick++
    }

    /** Về sảnh nhưng giữ ván cùng máy đang dở (nếu có). */
    fun toLobby() {
        if (mode == MagicMode.ONLINE) return
        stage = MagicStage.LOBBY
        lobbyError = null
    }

    fun resumeLocal() {
        if (hasLocalGame) {
            stage = MagicStage.PLAYING
            revealed = false
            startClockJob()
        }
    }

    /** Gói đổi (mua/hết hạn) trước nước đi đầu tiên → dựng lại bộ bài cho đúng gói. Chỉ ván cùng máy. */
    fun syncTier(tier: MembershipTier) {
        if (mode == MagicMode.LOCAL && stage == MagicStage.PLAYING && game.tier != tier && game.s.turnNo == 0) startLocal(tier)
    }

    // ------------------------------------------------------------------ Ván cùng máy

    fun startLocal(tier: MembershipTier) {
        cancelOnlineJobs()
        val tc = TimeControls.get(localTimeIndex)
        mode = MagicMode.LOCAL
        onlineGame = null
        serverOver = null
        onlineGameId = null
        remoteNotice = null
        game = MagicGame(tier = tier)
        resultCounted = false
        localClock = MagicClock(tc.baseSec, tc.incSec)
        clockEnabled = localClock.enabled
        revealed = false
        lobbyError = null
        stage = MagicStage.PLAYING
        startClockJob()
        tick++
    }

    /** "Ván mới" khi đang chơi cùng máy: giữ nguyên giờ đã chọn. */
    fun restartLocal(tier: MembershipTier) = startLocal(tier)

    fun resignLocal() {
        if (mode != MagicMode.LOCAL) return
        game.resign(game.whiteToMove)
        tick++
    }

    // ------------------------------------------------------------------ Hành động của người chơi

    fun takeOffer(index: Int): String? = perform(MagicActions.take(index))
    fun skipOffer(): String? = perform(MagicActions.SKIP)
    fun recycle(handIndex: Int): String? = perform(MagicActions.recycle(handIndex))
    fun cast(handIndex: Int, targets: List<Int>): String? = perform(MagicActions.cast(handIndex, targets))
    fun move(m: Int): String? = perform(MagicActions.move(moveUci(m)))

    private fun perform(action: String): String? {
        if (stage != MagicStage.PLAYING) return "Chưa vào ván"
        if (mode == MagicMode.ONLINE) {
            if (serverOver != null) return "Ván đã kết thúc"
            if (game.whiteToMove != myWhite) return "Chưa tới lượt bạn"
        }
        val turnBefore = game.s.turnNo
        val whiteBefore = game.whiteToMove
        val err = MagicActions.apply(game, action)
        if (err != null) return err
        val flipped = game.s.turnNo != turnBefore || game.whiteToMove != whiteBefore
        remoteNotice = null
        if (mode == MagicMode.LOCAL) {
            if (flipped) localClock.addIncrement(idx(whiteBefore))
        } else {
            val res = game.result
            val p = PendingAction(
                n = localCount,
                action = action,
                next = MagicActions.sideToMove(game),
                result = MagicActions.resultCode(game),
                reason = if (res == null) null else reasonOf(res),
            )
            localCount++
            outbox.trySend(p)
            if (flipped) onlineTurnChanged(whiteBefore)
        }
        tick++
        return null
    }

    // ------------------------------------------------------------------ Đồng hồ

    private fun startClockJob() {
        clockJob?.cancel()
        clockJob = viewModelScope.launch {
            var last = System.nanoTime()
            while (true) {
                delay(200L)
                val now = System.nanoTime()
                val dt = (now - last) / 1_000_000L
                last = now
                if (stage == MagicStage.PLAYING && mode == MagicMode.LOCAL && game.result == null && localClock.enabled && revealed) {
                    val side = idx(game.whiteToMove)
                    if (localClock.tick(side, dt)) {
                        game.flag(whiteLost = side == 0)
                        tick++
                    }
                }
                clockTick = clockTick + 1L
            }
        }
    }

    private fun applyServerClock(g: MagicOnlineGame) {
        val now = System.nanoTime()
        msAt[0] = g.whiteMs
        msAt[1] = g.blackMs
        sinceNanos[0] = now
        sinceNanos[1] = now
        onlineTurns = g.turnsDone
        running = if (g.active && g.turnsDone >= 2) (if (g.whiteToMove) 0 else 1) else -1
    }

    /** Sau khi mình đi xong lượt: cập nhật đồng hồ tạm thời (máy chủ sẽ chỉnh lại khi trả lời). */
    private fun onlineTurnChanged(whiteBefore: Boolean) {
        val old = idx(whiteBefore)
        val ni = idx(game.whiteToMove)
        onlineTurns++
        if (!clockEnabled || ni == old) return
        if (running == old) msAt[old] = clockMs(whiteBefore) + incMs
        running = if (onlineTurns >= 2) ni else -1
        if (running == ni) sinceNanos[ni] = System.nanoTime()
    }

    // ------------------------------------------------------------------ Tìm trận online

    fun startOnlineSearch() {
        if (stage == MagicStage.SEARCHING) return
        val tc = TimeControls.get(onlineTimeIndex)
        if (tc.baseSec <= 0) {
            lobbyError = "Ván online cần có đồng hồ. Hãy chọn một thể loại giờ."
            return
        }
        lobbyError = null
        searchStartedAt = System.currentTimeMillis()
        stage = MagicStage.SEARCHING
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            var fails = 0
            while (true) {
                val r = MagicOnlineRepository.findMatch(app, tc.baseSec, tc.incSec)
                val m = r.getOrNull()
                if (m is MagicMatchResult.Matched) {
                    beginOnline(m.game)
                    return@launch
                }
                if (r.isFailure) {
                    fails++
                    val kind = (r.exceptionOrNull() as? ProfileException)?.kind
                    val fatal = kind == ProfileError.NOT_SIGNED_IN || kind == ProfileError.NOT_CONFIGURED
                    if (fatal || fails >= 4) {
                        val friendly: String? =
                            if (fatal || kind == ProfileError.NETWORK) kind?.message() else null
                        lobbyError = friendly
                            ?: "Máy chủ Cờ Phép Thuật chưa phản hồi. Nếu bạn là người cài đặt: hãy chạy supabase/social.sql trong Supabase."
                        stage = MagicStage.LOBBY
                        return@launch
                    }
                } else {
                    fails = 0
                }
                delay(1500L)
            }
        }
    }

    fun cancelOnlineSearch() {
        if (stage != MagicStage.SEARCHING) return
        searchJob?.cancel()
        searchJob = null
        stage = MagicStage.LOBBY
        viewModelScope.launch {
            val r = MagicOnlineRepository.cancelSearch(app).getOrNull()
            // Đúng lúc đó đã có người ghép trúng mình: hủy ván để người kia không phải chờ.
            if (r is MagicMatchResult.Matched) MagicOnlineRepository.resign(app, r.game.id)
        }
    }

    private fun beginOnline(g: MagicOnlineGame) {
        val me = SupabaseCloud.userId(app)
        val white = me != null && g.whiteId.equals(me, ignoreCase = true)
        cancelOnlineJobs()
        mode = MagicMode.ONLINE
        myWhite = white
        oppName = if (white) g.blackName else g.whiteName
        oppTier = if (white) g.blackTier else g.whiteTier
        onlineGame = g
        onlineGameId = g.id
        serverOver = null
        remoteNotice = null
        failCount = 0
        connectionLost = false
        // Ván online luôn dùng bộ bài thường (FREE) để hai bên công bằng; chạy lại toàn bộ hành động đã có.
        val rep = MagicActions.replay(g.seed, g.actions)
        game = rep.game
        resultCounted = false
        localCount = rep.applied
        clockEnabled = g.baseSec > 0
        incMs = g.incSec * 1000L
        applyServerClock(g)
        revealed = true
        outbox = Channel(Channel.UNLIMITED)
        stage = MagicStage.PLAYING
        startOnlineLoops(g.id)
        if (!g.active) finishOnline(g)
        tick++
    }

    // ------------------------------------------------------------------ Vòng đồng bộ online

    private fun startOnlineLoops(gameId: String) {
        sendJob?.cancel()
        pollJob?.cancel()
        val box = outbox
        sendJob = viewModelScope.launch { sendLoop(gameId, box) }
        pollJob = viewModelScope.launch { pollLoop(gameId) }
        startClockJob()
    }

    private fun noteOk() {
        failCount = 0
        if (connectionLost) connectionLost = false
    }

    private fun noteFail() {
        failCount++
        if (failCount >= 3 && !connectionLost) connectionLost = true
    }

    private suspend fun sendLoop(gameId: String, box: Channel<PendingAction>) {
        for (p in box) {
            while (true) {
                if (onlineGame?.id != gameId || stage != MagicStage.PLAYING) return
                val r = MagicOnlineRepository.act(app, gameId, p.n, p.action, p.next, p.result, p.reason)
                val g = r.getOrNull()
                if (g != null) {
                    noteOk()
                    handleServer(g)
                    break
                }
                val kind = (r.exceptionOrNull() as? ProfileException)?.kind
                if (kind == ProfileError.NETWORK) {
                    noteFail()
                    delay(1200L)
                    continue
                }
                // Máy chủ từ chối (lệch thứ tự / không phải lượt / lỗi khác): bỏ phần chưa gửi và dựng lại từ máy chủ.
                while (!resyncFromServer(gameId)) {
                    if (onlineGame?.id != gameId || stage != MagicStage.PLAYING) return
                    delay(1500L)
                }
                break
            }
            val cur = onlineGame
            if (cur != null && !cur.active) return
        }
    }

    private suspend fun pollLoop(gameId: String) {
        while (true) {
            delay(if (myTurn) 2500L else 900L)
            if (onlineGame?.id != gameId || stage != MagicStage.PLAYING) return
            val g = MagicOnlineRepository.getGame(app, gameId).getOrNull()
            if (g == null) {
                noteFail()
                continue
            }
            noteOk()
            handleServer(g)
            if (!g.active) return
        }
    }

    /** Áp dụng trạng thái mới từ máy chủ: hành động của đối thủ, đồng hồ, kết thúc ván. */
    private fun handleServer(g: MagicOnlineGame) {
        if (onlineGame?.id != g.id) return
        onlineGame = g
        if (g.actions.size > localCount) {
            var i = localCount
            var failed = false
            while (i < g.actions.size) {
                val err = MagicActions.apply(game, g.actions[i])
                if (err != null) {
                    failed = true
                    break
                }
                i++
                localCount = i
            }
            if (failed) {
                val gid = g.id
                viewModelScope.launch { resyncFromServer(gid) }
                return
            }
            remoteNotice = game.notice
            tick++
        }
        if (g.actions.size >= localCount) applyServerClock(g)
        if (!g.active) finishOnline(g)
    }

    /** Dựng lại ván từ máy chủ (bỏ hành động chưa gửi). Trả false nếu chưa lấy được dữ liệu máy chủ. */
    private suspend fun resyncFromServer(gameId: String): Boolean {
        val g = MagicOnlineRepository.getGame(app, gameId).getOrNull() ?: return false
        if (onlineGame?.id != gameId) return true
        while (outbox.tryReceive().isSuccess) {
            // bỏ hết hành động đang chờ gửi
        }
        val rep = MagicActions.replay(g.seed, g.actions)
        game = rep.game
        localCount = rep.applied
        onlineGame = g
        remoteNotice = "Đã đồng bộ lại với máy chủ"
        applyServerClock(g)
        if (!g.active) finishOnline(g)
        tick++
        return true
    }

    private fun finishOnline(g: MagicOnlineGame) {
        serverOver = g
        running = -1
        msAt[0] = g.whiteMs
        msAt[1] = g.blackMs
        tick++
    }

    // ------------------------------------------------------------------ Kết thúc / rời ván online

    fun resignOnline() {
        val g = onlineGame ?: return
        if (mode != MagicMode.ONLINE || serverOver != null) return
        viewModelScope.launch {
            val r = MagicOnlineRepository.resign(app, g.id).getOrNull()
            if (r != null) handleServer(r)
        }
    }

    /** Rời ván online. Ván còn đang chơi thì bị xử thua (hoặc hủy nếu chưa ai đi xong lượt). */
    fun leaveOnline() {
        val g = onlineGame
        val live = g != null && serverOver == null && game.result == null
        if (g != null && live) {
            viewModelScope.launch { MagicOnlineRepository.resign(app, g.id) }
        }
        cancelOnlineJobs()
        onlineGame = null
        onlineGameId = null
        serverOver = null
        remoteNotice = null
        mode = MagicMode.LOCAL
        game = MagicGame()
        clockEnabled = false
        stage = MagicStage.LOBBY
        tick++
    }

    private fun cancelOnlineJobs() {
        searchJob?.cancel()
        sendJob?.cancel()
        pollJob?.cancel()
        clockJob?.cancel()
        searchJob = null
        sendJob = null
        pollJob = null
        clockJob = null
    }

    override fun onCleared() {
        cancelOnlineJobs()
        super.onCleared()
    }
}
