package com.vila.chess.profile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.media.ExifInterface
import android.net.Uri
import android.util.LruCache
import java.io.File
import java.io.FileOutputStream

// =============================================================================
// Ảnh đại diện lấy từ thư viện ảnh của máy.
//   • avatarKey có dạng "photo:<tên file>" → ảnh JPEG vuông 512×512 nằm trong filesDir/avatars/.
//   • Không cần quyền đọc bộ nhớ: ảnh chọn qua Photo Picker của hệ thống, app chỉ giữ BẢN ĐÃ CẮT của riêng mình.
//   • Khoá ảnh KHÔNG được đẩy lên cloud (người khác không có file này) → xem [cloudKey].
// =============================================================================
object AvatarPhotos {
    const val PREFIX = "photo:"
    const val OUTPUT_PX = 512
    private const val DIR = "avatars"
    private const val DECODE_MAX = 1600

    const val CLOUD_PREFIX = "cloud:"
    private val CLOUD_PATH = Regex("^[0-9a-fA-F-]{36}/avatar_[0-9]{1,16}\\.jpg$")

    /** Khoá ảnh đã tải lên cloud: "cloud:<uid>/avatar_<ts>.jpg" (người khác xem được). */
    fun isCloud(key: String?): Boolean = key != null && key.startsWith(CLOUD_PREFIX) && CLOUD_PATH.matches(key.removePrefix(CLOUD_PREFIX))

    fun cloudPath(key: String): String = key.removePrefix(CLOUD_PREFIX)

    /** Khoá này có ảnh thật để vẽ (ảnh máy hoặc ảnh cloud)? */
    fun hasImage(key: String?): Boolean = isPhoto(key) || isCloud(key)

    fun isPhoto(key: String?): Boolean = key != null && key.startsWith(PREFIX) && fileName(key).isNotEmpty()

    /** Tên file an toàn: chỉ chữ/số/_/./- (chặn "../"). Rỗng nếu không hợp lệ. */
    fun fileName(key: String): String {
        val n = key.removePrefix(PREFIX)
        return if (n.isNotEmpty() && n.all { it.isLetterOrDigit() || it == '_' || it == '.' || it == '-' } && !n.startsWith(".")) n else ""
    }

    /** Khoá gửi lên cloud: ảnh cục bộ thì gửi rỗng (người khác sẽ thấy chữ cái đầu). */
    fun cloudKey(key: String): String = if (key.startsWith(PREFIX)) "" else key

    private fun dir(ctx: Context) = File(ctx.applicationContext.filesDir, DIR).apply { mkdirs() }

    fun file(ctx: Context, key: String): File? {
        if (!isPhoto(key)) return null
        val f = File(dir(ctx), fileName(key))
        return if (f.exists()) f else null
    }

    fun delete(ctx: Context, key: String?) {
        if (key == null || !isPhoto(key)) return
        runCatching { File(dir(ctx), fileName(key)).delete() }
        cache.evictAll()
    }

    // ------------------------------------------------------------------ Giải mã ảnh gốc để cắt

    /** Đọc ảnh từ [uri], thu nhỏ còn tối đa 1600px, xoay đúng chiều theo EXIF. Lỗi → null. */
    fun decodeForCrop(ctx: Context, uri: Uri): Bitmap? = runCatching {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= DECODE_MAX) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val raw = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
        val orientation = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val m = orientationMatrix(orientation)
        if (m == null) raw else Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true).also { if (it !== raw) raw.recycle() }
    }.getOrNull()

    private fun orientationMatrix(o: Int): Matrix? {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return null
        }
        return m
    }

    // ------------------------------------------------------------------ Cắt + lưu

    /**
     * Cắt vùng vuông ([cx],[cy] = tâm, [half] = nửa cạnh, đều tính theo pixel của [src]) rồi lưu 512×512 JPEG.
     * Trả khoá "photo:…" hoặc null nếu lỗi ghi file.
     */
    fun saveCropped(ctx: Context, src: Bitmap, cx: Float, cy: Float, half: Float): String? = runCatching {
        val out = Bitmap.createBitmap(OUTPUT_PX, OUTPUT_PX, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(0xFF10264A.toInt())   // phòng khi vùng cắt lọt ra ngoài ảnh
        val srcRect = RectF(cx - half, cy - half, cx + half, cy + half)
        val clipped = Rect(
            srcRect.left.toInt().coerceIn(0, src.width - 1),
            srcRect.top.toInt().coerceIn(0, src.height - 1),
            srcRect.right.toInt().coerceIn(1, src.width),
            srcRect.bottom.toInt().coerceIn(1, src.height),
        )
        val scale = OUTPUT_PX / (half * 2f)
        val dst = RectF(
            (clipped.left - srcRect.left) * scale, (clipped.top - srcRect.top) * scale,
            (clipped.right - srcRect.left) * scale, (clipped.bottom - srcRect.top) * scale,
        )
        c.drawBitmap(src, clipped, dst, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        val name = "avatar_${System.currentTimeMillis()}.jpg"
        val f = File(dir(ctx), name)
        FileOutputStream(f).use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        out.recycle()
        PREFIX + name
    }.getOrNull()

    // ------------------------------------------------------------------ Nạp ảnh đã lưu (có cache)

    private val cache = object : LruCache<String, Bitmap>(24) {}

    /** Chỉ lấy từ cache (gọi được ở luồng UI, không đọc đĩa ngoài việc hỏi mốc sửa file). */
    fun peek(ctx: Context, key: String): Bitmap? {
        if (isCloud(key)) return cache.get(key)
        val f = file(ctx, key) ?: return null
        return cache.get(key + "@" + f.lastModified())
    }

    /** Ảnh cloud của người khác: cache RAM → cache đĩa (cacheDir) → tải về. Gọi ở luồng nền. */
    private suspend fun loadCloud(ctx: Context, key: String): Bitmap? {
        cache.get(key)?.let { return it }
        val path = cloudPath(key)
        val disk = File(File(ctx.applicationContext.cacheDir, "avatars_remote").apply { mkdirs() }, path.replace('/', '_'))
        var bmp = if (disk.exists()) runCatching { BitmapFactory.decodeFile(disk.absolutePath) }.getOrNull() else null
        if (bmp == null) {
            val bytes = com.vila.chess.cloud.SupabaseCloud.downloadAvatar(ctx, path) ?: return null
            bmp = runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull() ?: return null
            runCatching { disk.writeBytes(bytes) }
        }
        cache.put(key, bmp)
        return bmp
    }

    /** Nạp ảnh avatar từ máy hoặc cloud (gọi ở luồng nền). Không có/lỗi → null. */
    suspend fun loadAny(ctx: Context, key: String): Bitmap? =
        if (isCloud(key)) loadCloud(ctx, key) else load(ctx, key)

    /** Nạp ảnh avatar trong máy (gọi ở luồng nền). Không có file/lỗi → null. */
    fun load(ctx: Context, key: String): Bitmap? {
        val f = file(ctx, key) ?: return null
        val tag = key + "@" + f.lastModified()
        cache.get(tag)?.let { return it }
        val bmp = runCatching { BitmapFactory.decodeFile(f.absolutePath) }.getOrNull() ?: return null
        cache.put(tag, bmp)
        return bmp
    }
}
