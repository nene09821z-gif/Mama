package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.magic.CardKind
import com.vila.chess.magic.CardUse
import com.vila.chess.magic.MagicCard
import com.vila.chess.magic.MagicCardInfo
import com.vila.chess.magic.MagicCatalog
import com.vila.chess.magic.Rarity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

// =====================================================================================
// Giao diện lá bài Cờ Phép Thuật.
//  · Nhãn: LOẠI (Triệu hồi / Tấn công / …) · ĐỘ HIẾM (Thường → Huyền thoại, có màu + viên ngọc) · ★ Gói VIP · phần thưởng
//  · HandCard   : lá bài trên tay, có trạng thái "dùng được / chưa dùng được + lý do"
//  · CardOfferOverlay : 3 lá bài ngẫu nhiên hiện GIỮA màn hình — bay vào, lật mặt, trôi nhẹ, ánh sáng quét ở lá hiếm,
//    lá được chọn nổi lên; nhận xong thì bay về tay.
// =====================================================================================

internal val Purple = Color(0xFFB37DE8)
private val Gold = Color(0xFFFFD54F)

internal fun rarityColor(r: Rarity): Color = when (r) {
    Rarity.COMMON -> Color(0xFFBABABA)
    Rarity.UNCOMMON -> Color(0xFF81B64C)
    Rarity.RARE -> Color(0xFF4F9DE8)
    Rarity.EPIC -> Purple
    Rarity.LEGENDARY -> Color(0xFFF2B134)
}

/** Màu chủ đạo của lá: vàng cho bài VIP, còn lại theo độ hiếm. */
internal fun cardAccent(card: MagicCard): Color =
    if (card.tier != MembershipTier.FREE) Gold else rarityColor(card.rarity)

private fun kindColor(k: CardKind): Color = when (k) {
    CardKind.SUMMON -> Color(0xFF7BD88F)
    CardKind.STRIKE -> Color(0xFFFF7A59)
    CardKind.GUARD -> Color(0xFF6CB6FF)
    CardKind.CONTROL -> Color(0xFF8FD3FF)
    CardKind.MOVE -> Color(0xFFB8A1FF)
    CardKind.ENERGY -> Color(0xFF5CC8FF)
    CardKind.CHANCE -> Color(0xFFFFC857)
    CardKind.SIGNATURE -> Color(0xFFFFD54F)
}

/** Viên ngọc độ hiếm: số viên tăng theo độ hiếm (Thường 1 → Huyền thoại 5). */
private fun gems(r: Rarity): Int = r.ordinal + 1

private fun useColor(u: CardUse?): Color = when {
    u == null -> Color(0xFF9AA4B2)
    u.ok -> Color(0xFF7BD88F)
    else -> Color(0xFFFFB067)
}

/** Dòng trạng thái ngắn ghi trên lá bài. */
internal fun useLine(u: CardUse?): String = when {
    u == null -> ""
    u.ok -> "● Dùng được"
    else -> "○ " + u.reason
}

// ------------------------------------------------------------------ Hàng nhãn

/** Dải viên ngọc độ hiếm (vẽ bằng Canvas, không dùng icon). */
@Composable
private fun RarityGems(rarity: Rarity, color: Color, modifier: Modifier = Modifier) {
    val n = gems(rarity)
    Canvas(modifier.size(width = (n * 9 + 2).dp, height = 9.dp)) {
        val d = size.height
        for (i in 0 until n) {
            val cx = d / 2f + i * (d + 1.5.dp.toPx())
            drawCircle(color, radius = d / 2f * 0.85f, center = Offset(cx, size.height / 2f))
            drawCircle(Color.White.copy(alpha = 0.55f), radius = d / 2f * 0.3f, center = Offset(cx - d * 0.12f, size.height / 2f - d * 0.14f))
        }
    }
}

// ------------------------------------------------------------------ Lá bài trên tay

/**
 * Lá bài trên tay. [use] = null: chưa tính (ví dụ ngoài lượt mình). Lá chưa dùng được vẫn chạm được để xem mô tả;
 * lý do hiện ngay dưới tên lá, và có thể «Tái chế» ở thanh hành động.
 */
@Composable
internal fun HandCard(card: MagicCard, cost: Int, selected: Boolean, use: CardUse?, onClick: () -> Unit) {
    val accent = cardAccent(card)
    val kind = MagicCardInfo.kindOf(card)
    val ok = use?.ok != false
    val lift by androidx.compose.animation.core.animateFloatAsState(
        if (selected) -8f else 0f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow), label = "handLift",
    )
    Column(
        Modifier
            .width(138.dp)
            .fillMaxHeight()
            .graphicsLayer { translationY = lift.dp.toPx() }
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    listOf(if (selected) Color(0xFF4A4358) else Color(0xFF37343A), VilaColors.Panel),
                ),
            )
            .border(BorderStroke(if (selected) 3.dp else 1.5.dp, if (ok) accent else accent.copy(alpha = 0.35f)), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(card.icon, fontSize = 22.sp, modifier = Modifier.weight(1f))
            ManaOrb(cost, if (ok) 26.dp else 24.dp, ok)
        }
        Text(
            card.name, color = if (ok) Color.White else Color(0xFFB0B0B0), fontWeight = FontWeight.Bold, fontSize = 12.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
        )
        Text(
            card.description, color = Color(0xFFBABABA), fontSize = 10.sp, lineHeight = 12.sp,
            maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        if (use != null) {
            Text(
                useLine(use), color = useColor(use), fontSize = 9.sp, lineHeight = 11.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            RarityGems(card.rarity, rarityColor(card.rarity))
            Text(
                cardTagLine(card), color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Text(kind.emoji + " " + kind.label, color = kindColor(kind), fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** Nhãn cuối lá: ★ gói (+ Tuyệt kỹ) cho bài đặc quyền, 🎉 cho bài may rủi, còn lại là tên độ hiếm. */
internal fun cardTagLine(c: MagicCard): String = when {
    c.tier != MembershipTier.FREE -> "★ ${c.tier.displayName}" + if (c.isSignature) " · Tuyệt kỹ" else ""
    c.isFun -> "🎉 ${c.rarity.label}"
    else -> c.rarity.label
}

/** Viên mana tròn hiện giá lá bài. */
@Composable
internal fun ManaOrb(cost: Int, size: Dp, active: Boolean = true) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(
                if (active) Brush.radialGradient(listOf(Color(0xFF6FB6FF), Color(0xFF2F6FB5)))
                else Brush.radialGradient(listOf(Color(0xFF5A5D63), Color(0xFF45474C))),
            )
            .border(1.dp, Color(0x66FFFFFF), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text("$cost", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (size.value * 0.5f).sp)
    }
}

// ------------------------------------------------------------------ 3 lá giữa màn hình

/**
 * Lớp phủ giữa màn hình: 3 lá bài ngẫu nhiên đầu lượt. Chạm 1 lá để chọn (lá nổi lên, mô tả đầy đủ hiện bên dưới),
 * rồi «Nhận lá này»; hoặc «Bỏ qua (+1 mana)».
 *
 * Hiệu ứng: bay vào từ dưới lệch nhau từng lá → lật mặt (rotationY) → trôi nhẹ lên xuống; lá hiếm có ánh sáng quét chéo,
 * lá Sử thi / Huyền thoại / VIP có quầng sáng nhịp thở và vài đốm sáng lấp lánh; lá được nhận bay xuống tay rồi mới đóng.
 * Mọi hoạt ảnh liên tục dùng MỘT InfiniteTransition và đọc ở pha draw/graphicsLayer nên không vẽ lại cả cây giao diện mỗi khung hình.
 */
@Composable
internal fun CardOfferOverlay(
    offers: List<Int>,
    costOf: (MagicCard) -> Int,
    useOf: (MagicCard) -> CardUse?,
    selected: Int,
    onSelect: (Int) -> Unit,
    onTake: (Int) -> Unit,
    onSkip: () -> Unit,
    title: String = "🎁 Chọn 1 trong ${offers.size} lá bài mới",
    enabled: Boolean = true,
) {
    val infinite = rememberInfiniteTransition(label = "offerFx")
    val t = infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart), label = "t",
    )
    val scope = rememberCoroutineScope()
    val leave = remember { Animatable(0f) }
    var leaving by remember { mutableStateOf(-1) }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = 1f - leave.value * 0.9f }
            .background(
                Brush.radialGradient(
                    listOf(Color(0xE61E1A2B), Color(0xF2090812)),
                ),
            )
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { /* chặn chạm xuyên xuống bàn cờ */ }
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        // Đốm sáng nền
        Canvas(Modifier.fillMaxSize()) {
            val n = 22
            for (i in 0 until n) {
                val p = (t.value * (0.6f + (i % 4) * 0.25f) + i * 0.137f) % 1f
                val a = sin(PI.toFloat() * p).coerceIn(0f, 1f) * 0.5f * (1f - leave.value)
                val x = size.width * ((i * 0.6180339f) % 1f)
                val y = size.height * (1f - p)
                val c = when (i % 3) { 0 -> Color(0xFFFFD54F); 1 -> Color(0xFFB37DE8); else -> Color.White }
                drawCircle(c.copy(alpha = a), radius = (1.5f + (i % 3)) * density, center = Offset(x, y))
            }
        }

        Column(
            Modifier.fillMaxSize().padding(horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(title, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Text(
                "Chạm một lá để xem chi tiết", color = Color(0xFFB9C1CE), fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp),
            )

            Row(
                Modifier.fillMaxWidth().height(238.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                offers.forEachIndexed { i, id ->
                    val c = MagicCatalog.get(id)
                    OfferCard(
                        card = c,
                        cost = costOf(c),
                        use = useOf(c),
                        index = i,
                        time = t,
                        selected = selected == i,
                        dimmed = selected >= 0 && selected != i,
                        leaving = leaving == i,
                        leaveProgress = if (leaving == i) leave.value else 0f,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        onClick = { if (enabled && leaving < 0) onSelect(i) },
                    )
                }
            }

            // Mô tả chi tiết của lá đang chọn
            val sel = offers.getOrNull(selected)?.let { MagicCatalog.get(it) }
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .height(86.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x33FFFFFF))
                    .padding(10.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (sel == null) {
                    Text(
                        "Mỗi lượt bạn chọn 1 lá vào tay (tối đa 7 lá). Không thích lá nào thì bỏ qua để nhận +1 mana.",
                        color = Color(0xFFD7DCE6), fontSize = 13.sp, lineHeight = 17.sp,
                    )
                } else {
                    Column {
                        Text(
                            sel.name + "  ·  " + costOf(sel) + " mana", color = cardAccent(sel), fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(sel.description, color = Color(0xFFE6E9F0), fontSize = 12.sp, lineHeight = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Text(MagicCardInfo.usageLine(sel), color = Color(0xFF9FB0C8), fontSize = 11.sp, maxLines = 1)
                    }
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OfferButton("Bỏ qua (+1 mana)", Modifier.weight(1f), primary = false, enabled = enabled && leaving < 0) { onSkip() }
                OfferButton(
                    if (selected >= 0) "Nhận lá này" else "Chạm 1 lá để chọn", Modifier.weight(1.4f),
                    primary = selected >= 0, enabled = enabled && selected >= 0 && leaving < 0,
                ) {
                    val pick = selected
                    leaving = pick
                    scope.launch {
                        leave.snapTo(0f)
                        leave.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
                        onTake(pick)
                        // Nếu lá chưa được nhận (bị từ chối), trả lớp phủ về trạng thái bình thường.
                        leave.snapTo(0f)
                        leaving = -1
                    }
                }
            }
        }
    }
}

@Composable
private fun OfferButton(label: String, modifier: Modifier, primary: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier
            .height(48.dp)
            .graphicsLayer { alpha = if (enabled) 1f else 0.5f }
            .clip(RoundedCornerShape(12.dp))
            .background(if (primary) VilaColors.Green else VilaColors.PanelRaised)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1) }
}

/** Một lá trong 3 lá giữa màn hình. */
@Composable
private fun OfferCard(
    card: MagicCard,
    cost: Int,
    use: CardUse?,
    index: Int,
    time: androidx.compose.runtime.State<Float>,
    selected: Boolean,
    dimmed: Boolean,
    leaving: Boolean,
    leaveProgress: Float,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val dens = LocalDensity.current
    val accent = cardAccent(card)
    val kind = MagicCardInfo.kindOf(card)
    val fancy = card.rarity.ordinal >= Rarity.EPIC.ordinal || card.tier != MembershipTier.FREE
    val shiny = card.rarity.ordinal >= Rarity.RARE.ordinal || card.tier != MembershipTier.FREE

    // Bay vào + lật mặt, lệch nhau từng lá.
    val fly = remember { Animatable(0f) }
    val flip = remember { Animatable(180f) }
    LaunchedEffect(card.id, index) {
        delay(140L * index)
        fly.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(card.id, index) {
        delay(140L * index + 260L)
        flip.animateTo(0f, tween(520, easing = FastOutSlowInEasing))
    }
    val lift by androidx.compose.animation.core.animateFloatAsState(
        if (selected) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "lift",
    )

    Box(
        modifier
            .graphicsLayer {
                val f = fly.value
                val bob = sin(2f * PI.toFloat() * (time.value + index * 0.33f)) * 3.dp.toPx() * (1f - lift)
                translationY = (1f - f) * 420.dp.toPx() - lift * 16.dp.toPx() + bob + leaveProgress * 360.dp.toPx()
                translationX = (index - 1) * (1f - f) * -40.dp.toPx()
                rotationZ = (index - 1) * 7f * (1f - f) + (1f - lift) * (index - 1) * 1.2f
                val s = (0.55f + 0.45f * f) * (1f + 0.07f * lift) * (1f - 0.55f * leaveProgress)
                scaleX = s
                scaleY = s
                alpha = (if (dimmed) 0.72f else 1f) * (1f - leaveProgress * 0.6f) * f.coerceIn(0f, 1f)
            }
            .graphicsLayer {
                rotationY = flip.value
                cameraDistance = 14f * dens.density
            }
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    ) {
        // Mặt sau (khi flip > 90)
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    rotationY = 180f
                    alpha = if (flip.value > 90f) 1f else 0f
                }
                .background(Brush.linearGradient(listOf(Color(0xFF3B2E63), Color(0xFF1D1736))))
                .border(BorderStroke(2.dp, accent.copy(alpha = 0.7f)), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center,
        ) { Text("🪄", fontSize = 40.sp) }

        // Mặt trước (khi flip <= 90)
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = if (flip.value > 90f) 0f else 1f }
                .drawBehind {
                    if (fancy) {
                        val pulse = 0.5f + 0.5f * sin(2f * PI.toFloat() * (time.value * 2f + index * 0.25f))
                        drawRect(
                            Brush.radialGradient(
                                listOf(accent.copy(alpha = 0.22f + 0.2f * pulse), Color.Transparent),
                                center = Offset(size.width / 2f, size.height * 0.28f), radius = size.width * 0.95f,
                            ),
                        )
                    }
                }
                .background(
                    Brush.verticalGradient(
                        listOf(
                            if (selected) Color(0xFF4A4358) else Color(0xFF34313A),
                            Color(0xFF211F26),
                        ),
                    ),
                )
                .border(BorderStroke(if (selected) 3.dp else 2.dp, accent.copy(alpha = if (use == null || use.ok) 1f else 0.5f)), RoundedCornerShape(16.dp))
                .drawWithContent {
                    drawContent()
                    if (shiny) {
                        // Ánh sáng quét chéo
                        val p = ((time.value * 1.5f + index * 0.31f) % 1f)
                        val x = -size.width * 0.6f + p * size.width * 2.2f
                        drawRect(
                            Brush.linearGradient(
                                listOf(Color.Transparent, Color.White.copy(alpha = if (fancy) 0.22f else 0.12f), Color.Transparent),
                                start = Offset(x, 0f), end = Offset(x + size.width * 0.5f, size.height * 0.6f),
                            ),
                        )
                    }
                    if (fancy) {
                        // Đốm sáng lấp lánh quanh lá
                        for (k in 0 until 5) {
                            val ph = (time.value * 2f + k * 0.2f + index * 0.13f) % 1f
                            val a = sin(PI.toFloat() * ph).coerceIn(0f, 1f) * 0.85f
                            val px = size.width * (0.12f + 0.76f * ((k * 0.37f + index * 0.21f) % 1f))
                            val py = size.height * (0.1f + 0.8f * ((k * 0.53f + 0.17f) % 1f))
                            drawCircle(Color.White.copy(alpha = a), radius = (1.2f + (k % 2)) * dens.density, center = Offset(px, py))
                        }
                    }
                }
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(kind.emoji, fontSize = 13.sp)
                Spacer(Modifier.weight(1f))
                ManaOrb(cost, 26.dp, use?.ok != false)
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(card.icon, fontSize = 46.sp)
            }
            Text(
                card.name, color = Color.White, fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(4.dp))
            RarityGems(card.rarity, rarityColor(card.rarity))
            Text(
                cardTagLine(card), color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp),
            )
            Text(
                kind.label, color = kindColor(kind), fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                maxLines = 1,
            )
            if (use != null) {
                Text(
                    if (use.ok) "● Dùng được ngay" else "○ Chưa có mục tiêu", color = useColor(use), fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 1, modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
    }
}
