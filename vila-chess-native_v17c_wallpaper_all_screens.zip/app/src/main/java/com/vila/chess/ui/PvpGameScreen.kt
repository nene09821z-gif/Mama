package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.vila.chess.core.makePiece
import com.vila.chess.game.GameKind
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Tournament
import com.vila.chess.game.UiState
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.runtime.getValue
import com.vila.chess.game.Levels
import com.vila.chess.game.levelRating

/** Màn chơi 2 người (PvP). Không có Gợi ý / Hoàn tác / Thanh đánh giá. Dùng chung GameViewModel với màn Bot. */
@Composable
fun PvpGameScreen(vm: GameViewModel) {
    val ui = vm.ui
    val images = vm.pieceImages
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showResult by remember(ui.over) { mutableStateOf(ui.over) }

    BackHandler { if (ui.over) vm.backToHome() else confirm = Confirm.EXIT }

    val topIsWhite = ui.flipped
    fun nameFor(white: Boolean) = if (white) "Người chơi 1" else "Người chơi 2"

    Column(Modifier.fillMaxSize().background(GameScrim).systemBarsPadding()) {
        GameTopBar(sans = ui.sans, onBack = { if (ui.over) vm.backToHome() else confirm = Confirm.EXIT })
        Spacer(Modifier.weight(1f))
        // Hai avatar + đồng hồ của cả hai bên (PlayerBar tự hiện đồng hồ khi ván có giờ)
        PlayerBar(vm, ui, images, topIsWhite, nameFor(topIsWhite))
        androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth()) {
            ChessBoard(vm, ui)
        }
        PlayerBar(vm, ui, images, !topIsWhite, nameFor(!topIsWhite))

        Spacer(Modifier.weight(1.3f))

        // Thanh công cụ: Cầu hòa (→ Tái đấu khi hết ván) · Đầu hàng
        GameToolbar {
            if (ui.over) {
                ToolbarButton("Tái đấu", true, { vm.rematch() }) { ToolbarIcon(ToolIcon.REFRESH) }
            } else {
                ToolbarButton("Cầu hòa", true, { confirm = Confirm.DRAW }) {
                    Text("½", color = VilaColors.TextDim, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            ToolbarButton("Đầu hàng", !ui.over, { confirm = Confirm.RESIGN }) { ToolbarIcon(ToolIcon.FLAG) }
        }
    }

    if (ui.promotion != null) PromotionDialog(vm = vm, images = images, humanWhite = ui.whiteToMove)

    ConfirmDialog(confirm, friend = true, onDismiss = { confirm = null }) { c ->
        confirm = null
        when (c) {
            Confirm.EXIT -> vm.backToHome()
            Confirm.NEW_GAME -> vm.rematch()
            Confirm.RESIGN -> vm.resign()
            Confirm.DRAW -> vm.offerDraw()
        }
    }

    if (ui.over && showResult) PostGameDialog(vm = vm, onDismiss = { showResult = false })
}
