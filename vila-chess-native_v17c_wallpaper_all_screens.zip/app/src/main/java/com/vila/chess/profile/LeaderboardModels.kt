package com.vila.chess.profile

import com.vila.chess.billing.MembershipTier

/** Phạm vi của bảng xếp hạng. */
enum class BoardScope(val title: String) {
    GLOBAL("Toàn cầu"),
    FRIENDS("Bạn bè"),
}

/** Một dòng của bảng xếp hạng. [rank] theo kiểu thi đấu: bằng điểm thì cùng hạng (1, 2, 2, 4…). */
data class LeaderboardEntry(val rank: Int, val profile: UserProfile)

/** Hạng của chính mình trong toàn bộ người chơi (từ máy chủ). [rank] = null khi chưa có dữ liệu. */
data class MyRank(val rank: Int?, val total: Int, val elo: Int)

/** Hàm thuần (không Android) của bảng xếp hạng: dễ test trên JVM. */
object Leaderboard {
    /** Số dòng tối đa tải về một lần. */
    const val PAGE = 50

    /**
     * Xếp [profiles] theo Elo của [mode] giảm dần; bằng Elo thì người chơi nhiều ván hơn đứng trước, rồi theo tên.
     * Hạng kiểu thi đấu: cùng Elo => cùng hạng.
     */
    fun rank(profiles: List<UserProfile>, mode: EloMode): List<LeaderboardEntry> {
        val sorted = profiles
            .distinctBy { it.userId }
            .sortedWith(
                compareByDescending<UserProfile> { it.elo(mode) }
                    .thenByDescending { it.played }
                    .thenBy { it.displayName.lowercase() },
            )
        val out = ArrayList<LeaderboardEntry>(sorted.size)
        var rank = 1
        for (i in sorted.indices) {
            if (i > 0 && sorted[i].elo(mode) != sorted[i - 1].elo(mode)) rank = i + 1
            out += LeaderboardEntry(rank, sorted[i])
        }
        return out
    }

    /** Vị trí của [userId] trong danh sách đã xếp hạng, hoặc null. */
    fun find(entries: List<LeaderboardEntry>, userId: String?): LeaderboardEntry? =
        if (userId == null) null else entries.firstOrNull { it.profile.userId.equals(userId, ignoreCase = true) }

    /** Bậc danh hiệu theo Elo (hiện cạnh tên). */
    fun title(elo: Int): String = when {
        elo >= 2400 -> "Đại kiện tướng"
        elo >= 2000 -> "Kiện tướng"
        elo >= 1600 -> "Cao thủ"
        elo >= 1200 -> "Tinh anh"
        elo >= 900 -> "Tiến bộ"
        else -> "Tân binh"
    }

    /** Cờ quốc gia dạng emoji từ mã 2 chữ cái ("VN" -> 🇻🇳); rỗng nếu mã không hợp lệ. */
    fun flag(countryCode: String): String {
        val cc = countryCode.trim().uppercase()
        if (cc.length != 2 || cc.any { it !in 'A'..'Z' }) return ""
        val base = 0x1F1E6 - 'A'.code
        return String(Character.toChars(base + cc[0].code)) + String(Character.toChars(base + cc[1].code))
    }

    /** Tỉ lệ thắng 0..100 (làm tròn), 0 nếu chưa chơi. */
    fun winRate(p: UserProfile): Int = p.winRatePct

    /** Có phải thành viên VIP (hiện huy hiệu). */
    fun isVip(p: UserProfile): Boolean = p.tier != MembershipTier.FREE
}
