package com.vila.chess.profile

import android.content.Context
import com.vila.chess.cloud.SupabaseCloud
import org.json.JSONArray
import org.json.JSONObject

/**
 * Tải bảng xếp hạng từ bảng `users` (đọc được bởi mọi tài khoản đăng nhập) + hạng của mình (supabase/social.sql).
 * Không ném lỗi: mọi hàm trả [Result] mang [ProfileException] đã phân loại (chưa đăng nhập / mất mạng / lỗi máy chủ).
 */
object LeaderboardRepository {
    private const val COLS =
        "id,display_name,avatar_key,country_code,tier,bullet_elo,blitz_elo,rapid_elo," +
            "games_played,wins,draws,losses,result_streak"

    /** Top [limit] người chơi toàn cầu của [mode] (chỉ người đã chơi ít nhất 1 ván). */
    suspend fun fetchTop(ctx: Context, mode: EloMode, limit: Int = Leaderboard.PAGE): Result<List<UserProfile>> {
        val n = limit.coerceIn(1, 100)
        val path = "/rest/v1/users?select=$COLS&games_played=gt.0" +
            "&order=${mode.key}_elo.desc,games_played.desc&limit=$n"
        return SupabaseCloud.restCall(ctx, "GET", path).mapCatching { text ->
            val arr = JSONArray(text)
            (0 until arr.length()).map { i -> ProfileRepository.parseProfile(arr.getJSONObject(i)) }
        }.recoverParse()
    }

    /** Bạn bè + chính mình (để so hạng trong nhóm bạn). */
    suspend fun fetchFriendsBoard(ctx: Context): Result<List<UserProfile>> {
        val friends = ProfileRepository.fetchFriends(ctx).getOrElse { return Result.failure(it) }
        val myId = SupabaseCloud.userId(ctx) ?: return Result.success(friends)
        val me = ProfileRepository.fetchProfile(ctx, myId).getOrNull()
        return Result.success(if (me == null) friends else friends + me)
    }

    /** Hạng của mình trong toàn bộ người chơi ở [mode]. */
    suspend fun fetchMyRank(ctx: Context, mode: EloMode): Result<MyRank> =
        SupabaseCloud.restCall(
            ctx, "POST", "/rest/v1/rpc/leaderboard_rank", JSONObject().put("p_mode", mode.key).toString(),
        ).mapCatching { text ->
            val j = JSONObject(text)
            MyRank(
                rank = if (j.isNull("rank")) null else j.optInt("rank"),
                total = j.optInt("total", 0),
                elo = j.optInt("elo", DEFAULT_ELO),
            )
        }.recoverParse()

    private fun <T> Result<T>.recoverParse(): Result<T> {
        val ex = exceptionOrNull() ?: return this
        return if (ex is ProfileException) this else Result.failure(ProfileException(ProfileError.SERVER, ex.message))
    }
}
