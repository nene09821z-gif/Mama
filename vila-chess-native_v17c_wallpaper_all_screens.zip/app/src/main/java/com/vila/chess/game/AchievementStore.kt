package com.vila.chess.game

import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Kho thành tựu: giữ AchStats + danh sách thành tựu đã mở khóa (kèm thời điểm) trong SharedPreferences "vila_ach",
 * đọc thêm số liệu từ các kho sẵn có (PlayerStats, giải đấu, câu đố, bài học) rồi chấm điểm 30 thành tựu.
 *
 *  • [states]  : trạng thái 30 thành tựu cho UI (mở khóa là mở mãi mãi, kể cả khi số liệu nguồn sau này giảm).
 *  • [events]  : phát đúng 1 lần mỗi khi một thành tựu VỪA mở khóa (banner chúc mừng).
 *  • Lần chạy đầu tiên sau khi cập nhật app chỉ ghi nhận thầm lặng các thành tựu đã đạt từ trước, không bắn banner hàng loạt.
 *
 * Mọi hàm on...() chỉ cần gọi 1 dòng ở nơi sự kiện xảy ra; chúng tự lưu và chấm lại.
 */
class AchievementStore private constructor(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("vila_ach", Context.MODE_PRIVATE)
    private val nativePrefs = app.getSharedPreferences("vila_native", Context.MODE_PRIVATE)

    private var stats: AchStats = loadStats()
    private val unlocked = HashMap<String, Long>(decodeUnlocked(prefs.getString("unlocked", null)))

    private val _states = MutableStateFlow<List<AchState>>(emptyList())
    val states: StateFlow<List<AchState>> = _states.asStateFlow()

    private val _unlockedAt = MutableStateFlow<Map<String, Long>>(emptyMap())
    val unlockedAt: StateFlow<Map<String, Long>> = _unlockedAt.asStateFlow()

    private val _events = MutableSharedFlow<AchState>(extraBufferCapacity = 32)
    val events: SharedFlow<AchState> = _events.asSharedFlow()

    init { refresh() }

    // ------------------------------------------------------------------ sự kiện từ game

    /**
     * Gọi 1 lần khi một ván kết thúc (SAU khi PlayerStats và số giải đấu đã cập nhật).
     * [facts] = null nếu ván không tính kỹ năng (2 người cùng máy, tàn cuộc, FEN tự chọn).
     * [level] = cấp bot (0 nếu không phải ván với bot).
     */
    @Synchronized
    fun onGameFinished(facts: GameFacts?, humanWon: Boolean, level: Int) {
        if (facts != null) stats = AchEngine.applyGame(stats, facts, humanWon, level)
        refresh()
    }

    @Synchronized fun onReview() { stats = stats.copy(reviews = stats.reviews + 1); refresh() }

    @Synchronized fun onMagicGame() { stats = stats.copy(magicGames = stats.magicGames + 1); refresh() }

    /** [bit] là một giá trị của [DesignBit]. */
    @Synchronized
    fun onDesign(bit: Int) {
        if (stats.designMask and bit == bit) return
        stats = stats.copy(designMask = stats.designMask or bit)
        refresh()
    }

    // ------------------------------------------------------------------ chấm điểm

    /** Đọc lại mọi nguồn, chấm điểm, lưu và phát sự kiện cho thành tựu mới mở. Gọi được từ bất kỳ luồng nào. */
    @Synchronized
    fun refresh() {
        val p = StatsStore.load(nativePrefs)
        stats = AchEngine.syncPeaks(stats, p, StatsStore.today())
        val snap = AchSnapshot(
            stats = stats,
            played = p.played,
            won = p.won,
            tournamentsDone = nativePrefs.getInt("tourneyDone", 0),
            puzzlesSolved = puzzlesSolved(),
            lessonsDone = lessonsDone(),
        )
        val raw = AchEngine.evaluate(snap)
        val now = System.currentTimeMillis()
        val fresh = ArrayList<AchState>()
        for (st in raw) {
            if (st.done && st.def.id !in unlocked) {
                unlocked[st.def.id] = now
                fresh.add(st)
            }
        }
        val firstRun = !prefs.getBoolean("init", false)
        saveAll()
        // Thành tựu đã mở thì giữ nguyên là "đạt", dù số liệu nguồn có đổi.
        _states.value = raw.map { if (!it.done && it.def.id in unlocked) AchState(it.def, it.def.target) else it }
        _unlockedAt.value = HashMap(unlocked)
        if (!firstRun) for (st in fresh) _events.tryEmit(st)
    }

    private fun puzzlesSolved(): Int = try {
        (app.getSharedPreferences("vila_puzzle_map", Context.MODE_PRIVATE).getInt("current_level", 1) - 1).coerceAtLeast(0)
    } catch (_: Throwable) { 0 }

    private fun lessonsDone(): Int = try {
        LessonStore.get(app).state.value.done.size
    } catch (_: Throwable) { 0 }

    // ------------------------------------------------------------------ lưu trữ

    private fun loadStats() = AchStats(
        castles = prefs.getInt("castles", 0),
        queenPromos = prefs.getInt("queenPromos", 0),
        underPromos = prefs.getInt("underPromos", 0),
        enPassants = prefs.getInt("enPassants", 0),
        fastestMate = prefs.getInt("fastestMate", 0),
        comebackWins = prefs.getInt("comebackWins", 0),
        bestWinStreak = prefs.getInt("bestWinStreak", 0),
        bestDayStreak = prefs.getInt("bestDayStreak", 0),
        peakRating = prefs.getInt("peakRating", 0),
        maxLevelBeaten = prefs.getInt("maxLevelBeaten", 0),
        reviews = prefs.getInt("reviews", 0),
        magicGames = prefs.getInt("magicGames", 0),
        designMask = prefs.getInt("designMask", 0),
    )

    private fun saveAll() {
        prefs.edit()
            .putInt("castles", stats.castles)
            .putInt("queenPromos", stats.queenPromos)
            .putInt("underPromos", stats.underPromos)
            .putInt("enPassants", stats.enPassants)
            .putInt("fastestMate", stats.fastestMate)
            .putInt("comebackWins", stats.comebackWins)
            .putInt("bestWinStreak", stats.bestWinStreak)
            .putInt("bestDayStreak", stats.bestDayStreak)
            .putInt("peakRating", stats.peakRating)
            .putInt("maxLevelBeaten", stats.maxLevelBeaten)
            .putInt("reviews", stats.reviews)
            .putInt("magicGames", stats.magicGames)
            .putInt("designMask", stats.designMask)
            .putString("unlocked", encodeUnlocked(unlocked))
            .putBoolean("init", true)
            .apply()
    }

    companion object {
        @Volatile private var instance: AchievementStore? = null
        fun get(context: Context): AchievementStore =
            instance ?: synchronized(this) { instance ?: AchievementStore(context).also { instance = it } }

        /** "id:thờiGian,id:thờiGian" — id chỉ gồm a-z, 0-9, _ nên không cần escape. */
        internal fun encodeUnlocked(m: Map<String, Long>): String = m.entries.joinToString(",") { it.key + ":" + it.value }

        internal fun decodeUnlocked(raw: String?): Map<String, Long> {
            if (raw.isNullOrEmpty()) return emptyMap()
            val out = HashMap<String, Long>()
            for (part in raw.split(',')) {
                val i = part.indexOf(':')
                if (i <= 0) continue
                val t = part.substring(i + 1).toLongOrNull() ?: continue
                out[part.substring(0, i)] = t
            }
            return out
        }
    }
}
