package com.vila.chess.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.AchCategory
import com.vila.chess.game.AchEngine
import com.vila.chess.game.AchState
import com.vila.chess.game.AchTier
import com.vila.chess.game.AchievementStore
import com.vila.chess.game.Achievements
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================================================================
// Giao diện 30 thành tựu: bảng tổng quan + danh sách theo nhóm (có tiến độ) + banner chúc mừng khi mở khóa.
// Dữ liệu lấy từ AchievementStore (game/AchievementStore.kt); file này chỉ vẽ.
// =============================================================================

private val Bronze = Color(0xFFCD7F32)
private val Silver = Color(0xFFC3CBD8)
private val Gold = Color(0xFFFFC83D)
private val Diamond = Color(0xFF5CE1FF)
private val RowBg = Color(0x14FFFFFF)

fun tierColor(t: AchTier): Color = when (t) {
    AchTier.BRONZE -> Bronze
    AchTier.SILVER -> Silver
    AchTier.GOLD -> Gold
    AchTier.DIAMOND -> Diamond
}

fun achievementIcon(key: String): ImageVector = when (key) {
    "play" -> Icons.Filled.PlayArrow
    "fitness" -> Icons.Filled.FitnessCenter
    "games" -> Icons.Filled.SportsEsports
    "fire" -> Icons.Filled.LocalFireDepartment
    "history" -> Icons.Filled.History
    "premium" -> Icons.Filled.WorkspacePremium
    "trophy" -> Icons.Filled.EmojiEvents
    "military" -> Icons.Filled.MilitaryTech
    "bolt" -> Icons.Filled.Bolt
    "shield" -> Icons.Filled.Shield
    "star" -> Icons.Filled.Star
    "swap" -> Icons.Filled.SwapVert
    "puzzle" -> Icons.Filled.Extension
    "refresh" -> Icons.Filled.Refresh
    "flag" -> Icons.Filled.Flag
    "bot" -> Icons.Filled.SmartToy
    "groups" -> Icons.Filled.Groups
    "brain" -> Icons.Filled.Psychology
    "lightbulb" -> Icons.Filled.Lightbulb
    "search" -> Icons.Filled.Search
    "palette" -> Icons.Filled.Palette
    else -> Icons.Filled.Star
}

private enum class AchFilter(val label: String) { ALL("Tất cả"), DONE("Đã đạt"), TODO("Chưa đạt") }

private fun formatDate(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale("vi", "VN")).format(Date(ms))

/** Huy chương tròn: đã đạt = sáng màu hạng; chưa đạt = mờ + ổ khóa. */
@Composable
private fun Medal(s: AchState, size: Int) {
    val c = tierColor(s.def.tier)
    if (s.done) {
        Box(
            Modifier.size(size.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(c.copy(alpha = 0.65f), Color(0xFF1B2D4A))))
                .border(2.dp, c, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(achievementIcon(s.def.icon), contentDescription = s.def.title, tint = Color.White, modifier = Modifier.size((size * 0.5f).dp))
        }
    } else {
        Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(size.dp).alpha(0.3f).clip(CircleShape).background(Color(0xFF2B3F63)).border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(achievementIcon(s.def.icon), contentDescription = null, tint = Color.White, modifier = Modifier.size((size * 0.5f).dp))
            }
            Icon(Icons.Filled.Lock, contentDescription = "Chưa đạt", tint = Color.White, modifier = Modifier.size((size * 0.38f).dp))
        }
    }
}

@Composable
private fun ProgressBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x26FFFFFF))) {
        if (fraction > 0f) Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(6.dp).clip(RoundedCornerShape(3.dp)).background(color))
    }
}

@Composable
private fun SummaryCard(states: List<AchState>) {
    val done = states.count { it.done }
    val points = AchEngine.totalPoints(states)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(RowBg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Thành tựu", color = VilaColors.TextDim, fontSize = 13.sp)
                Text("$done / ${states.size}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Điểm", color = VilaColors.TextDim, fontSize = 13.sp)
                Text("$points / ${Achievements.totalPoints}", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.height(10.dp))
        ProgressBar(if (states.isEmpty()) 0f else done.toFloat() / states.size, VilaColors.Green, Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            for (t in AchTier.values()) {
                val n = states.count { it.def.tier == t && it.done }
                val of = states.count { it.def.tier == t }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(tierColor(t)))
                    Spacer(Modifier.width(5.dp))
                    Text("$n/$of", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun FilterChips(selected: AchFilter, onSelect: (AchFilter) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (f in AchFilter.values()) {
            val on = f == selected
            Text(
                f.label,
                color = if (on) Color.White else VilaColors.TextDim,
                fontSize = 13.sp,
                fontWeight = if (on) FontWeight.ExtraBold else FontWeight.SemiBold,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (on) VilaColors.Green else RowBg)
                    .clickable { onSelect(f) }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
            )
        }
    }
}

@Composable
private fun AchievementRow(s: AchState, onClick: () -> Unit) {
    val c = tierColor(s.def.tier)
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(RowBg).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Medal(s, 52)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    s.def.title, color = if (s.done) Color.White else VilaColors.TextDim,
                    fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(Modifier.width(8.dp))
                Text(s.def.tier.label, color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(s.def.desc, color = VilaColors.TextDim, fontSize = 12.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (s.def.target > 1) {
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ProgressBar(s.fraction, c, Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    Text("${s.progress}/${s.def.target}", color = VilaColors.TextDim, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (s.done) {
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Filled.CheckCircle, contentDescription = "Đã đạt", tint = VilaColors.Green, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
private fun AchievementDetail(s: AchState, unlockedAt: Long?, onDismiss: () -> Unit) {
    val c = tierColor(s.def.tier)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF16233B),
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(20.dp),
        title = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Medal(s, 84)
                Spacer(Modifier.height(10.dp))
                Text(s.def.title, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
        },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(s.def.desc, fontSize = 14.sp, color = Color.White)
                Text("${s.def.category.label} · ${s.def.tier.label} · +${s.def.tier.points} điểm", color = c, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                if (s.def.target > 1) {
                    ProgressBar(s.fraction, c, Modifier.fillMaxWidth())
                    Text("${s.progress}/${s.def.target}", fontSize = 12.sp)
                }
                Text(
                    if (s.done) (if (unlockedAt != null) "Đạt ngày " + formatDate(unlockedAt) else "Đã đạt") else "Chưa đạt",
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    color = if (s.done) VilaColors.Green else VilaColors.TextDim,
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) } },
    )
}

/** Toàn bộ nội dung thành tựu (dùng cho tab Hồ sơ và hộp thoại ở màn chính). */
@Composable
fun AchievementsPanel(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val store = remember { AchievementStore.get(ctx) }
    val states by store.states.collectAsState()
    val times by store.unlockedAt.collectAsState()
    // Mở panel là chấm lại ngay để câu đố / bài học vừa xong cũng được tính.
    LaunchedEffect(Unit) { store.refresh() }
    var filter by rememberSaveable { mutableStateOf(AchFilter.ALL) }
    var detail by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item(key = "summary") { SummaryCard(states) }
        item(key = "filters") {
            Spacer(Modifier.height(4.dp))
            FilterChips(filter) { filter = it }
        }
        for (cat in AchCategory.values()) {
            val inCat = states.filter { it.def.category == cat }.filter {
                when (filter) {
                    AchFilter.ALL -> true
                    AchFilter.DONE -> it.done
                    AchFilter.TODO -> !it.done
                }
            }
            if (inCat.isEmpty()) continue
            item(key = "h_" + cat.name) {
                val all = states.filter { it.def.category == cat }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(cat.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Text("${all.count { it.done }}/${all.size}", color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            items(inCat.size, key = { inCat[it].def.id }) { i ->
                val s = inCat[i]
                AchievementRow(s, onClick = { detail = s.def.id })
            }
        }
        if (states.isNotEmpty() && states.none {
                when (filter) { AchFilter.ALL -> true; AchFilter.DONE -> it.done; AchFilter.TODO -> !it.done }
            }
        ) {
            item(key = "empty") {
                Text(
                    if (filter == AchFilter.DONE) "Chưa có thành tựu nào. Chơi một ván để bắt đầu!" else "Bạn đã đạt hết mọi thành tựu!",
                    color = VilaColors.TextDim, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(24.dp),
                )
            }
        }
    }
    val d = states.firstOrNull { it.def.id == detail }
    if (d != null) AchievementDetail(d, times[d.def.id], onDismiss = { detail = null })
}

/** Hộp thoại ở màn chính (nút "Giải thưởng" / cúp). */
@Composable
fun AchievementsDialog(onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Column(
            Modifier.fillMaxWidth(0.94f).height(560.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF16233B)),
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Thành tựu", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                TextButton(onClick = onDismiss) { Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.ExtraBold) }
            }
            AchievementsPanel(Modifier.weight(1f))
        }
    }
}

/**
 * Banner trượt từ trên xuống khi một thành tựu vừa mở khóa. Đặt 1 lần ở gốc app (MainActivity.AppRoot);
 * nhiều thành tựu cùng lúc sẽ hiện lần lượt, mỗi cái ~3 giây. Không chặn thao tác (không nhận chạm).
 */
@Composable
fun AchievementBanner(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val store = remember { AchievementStore.get(ctx) }
    var current by remember { mutableStateOf<AchState?>(null) }
    var last by remember { mutableStateOf<AchState?>(null) }
    LaunchedEffect(store) {
        store.events.collect { st ->
            last = st
            current = st
            delay(3200)
            current = null
            delay(350)
        }
    }
    Box(modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = current != null,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
        ) {
            val s = last
            if (s != null) {
                val c = tierColor(s.def.tier)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF16233B)).border(1.5.dp, c, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Medal(AchState(s.def, s.def.target), 48)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Thành tựu mới · ${s.def.tier.label}", color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(s.def.title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.def.desc, color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("+${s.def.tier.points}", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}
