package com.vila.chess.bots

import android.content.Context
import com.vila.chess.core.Position
import com.vila.chess.core.findMoveBySan
import com.vila.chess.core.moveUci
import com.vila.chess.review.OpeningBook
import kotlin.math.pow
import kotlin.random.Random

/**
 * Bộ khai cuộc RIÊNG cho từng Bot.
 *
 * Dữ liệu: assets/openings.tsv (lichess-org/chess-openings, do main.yml tải lúc build). Thiếu file thì dùng
 * [OpeningBook.BUILT_IN] để Bot vẫn có khai cuộc.
 *
 * Cách hoạt động: ở mỗi nước, lấy mọi dòng khai cuộc khớp với các nước đã đi, gom theo nước kế tiếp rồi chọn
 * ngẫu nhiên có trọng số. Trọng số = "gu" riêng của bot (băm từ id bot + thế cờ, cố định) x độ phổ biến của nước.
 *  - Mỗi bot có gu khác nhau nên bot khác nhau đi khai cuộc khác nhau; cùng một bot vẫn đổi khai cuộc giữa các ván.
 *  - Elo thấp: ít theo sách (ngắn), dễ rời sách sớm, gu "lạ". Elo cao: theo sách sâu, thiên về dòng chính.
 *  - Hết sách / người chơi đi lệch sách / bot "quên sách" -> trả null để Stockfish theo Elo của bot tự đi tiếp.
 */
class BotRepertoire private constructor(private val lines: List<Line>) {

    class Line(val eco: String, val name: String, val ucis: List<String>)

    val lineCount: Int get() = lines.size

    /** Số nước (ply) tối đa bot còn theo sách: Elo càng cao càng sâu (250 -> 5, 1500 -> 12, 3200 -> 21). */
    fun maxBookPlies(bot: BotProfile): Int = (4 + bot.elo / 180).coerceIn(4, 22)

    /** Xác suất mỗi nước (từ nước thứ 2 của bot) bot "quên sách" và rời sách: Elo thấp hay quên hơn. */
    fun forgetChance(bot: BotProfile): Double = ((1.0 - bot.elo / 3300.0) * 0.12).coerceIn(0.0, 0.2)

    /**
     * Trọng số (đã chuẩn hoá tổng = 1) của từng nước kế tiếp mà [bot] có thể chọn sau [history] (danh sách UCI từ thế ban đầu).
     * Rỗng nếu hết sách. Cố định theo (bot, thế cờ) nên kiểm thử được.
     */
    fun preferences(bot: BotProfile, history: List<String>): Map<String, Double> {
        if (history.size >= maxBookPlies(bot)) return emptyMap()
        val counts = LinkedHashMap<String, Int>()
        for (l in lines) {
            if (l.ucis.size <= history.size) continue
            if (!startsWith(l.ucis, history)) continue
            val mv = l.ucis[history.size]
            counts[mv] = (counts[mv] ?: 0) + 1
        }
        if (counts.isEmpty()) return emptyMap()
        val prefixKey = history.joinToString(" ")
        // Elo cao -> thiên về nước phổ biến (dòng chính); Elo thấp -> gu riêng quyết định nhiều hơn.
        val alpha = 0.3 + bot.elo.coerceIn(0, 3200) / 3200.0 * 0.8
        val w = HashMap<String, Double>(counts.size * 2)
        var sum = 0.0
        for ((mv, n) in counts) {
            val t = hash01(bot.id + "@" + prefixKey + "@" + mv)
            val x = (0.05 + t * t) * n.toDouble().pow(alpha)
            w[mv] = x
            sum += x
        }
        if (sum <= 0.0) return emptyMap()
        for (k in w.keys) w[k] = w.getValue(k) / sum
        return w
    }

    /** Một ván của một bot: nhớ việc bot đã rời sách hay chưa (rời rồi thì không quay lại sách). */
    inner class BookGame(val bot: BotProfile) {
        @Volatile var offBook = false
            private set

        /** Nước UCI theo sách cho [history] (các nước đã đi từ thế ban đầu), hoặc null = để Stockfish tự đi. */
        fun next(history: List<String>, rnd: Random = Random.Default): String? {
            if (offBook) return null
            if (history.size >= 2 && rnd.nextDouble() < forgetChance(bot)) { offBook = true; return null }
            val pref = preferences(bot, history)
            if (pref.isEmpty()) { offBook = true; return null }
            var r = rnd.nextDouble()
            var last: String? = null
            for ((mv, p) in pref) {
                last = mv
                r -= p
                if (r <= 0.0) return mv
            }
            return last
        }
    }

    fun newGame(bot: BotProfile): BookGame = BookGame(bot)

    private fun startsWith(full: List<String>, prefix: List<String>): Boolean {
        if (prefix.size > full.size) return false
        for (i in prefix.indices) if (full[i] != prefix[i]) return false
        return true
    }

    companion object {
        @Volatile private var cached: BotRepertoire? = null

        /** Nạp (và nhớ) bộ khai cuộc. Gọi từ luồng nền: parse ~3.600 dòng mất vài trăm ms. */
        fun load(context: Context): BotRepertoire {
            cached?.let { return it }
            synchronized(this) {
                cached?.let { return it }
                val fromAsset = runCatching {
                    context.applicationContext.assets.open(OpeningBook.ASSET_NAME).bufferedReader().useLines { fromTsv(it) }
                }.getOrNull()
                val rep = fromAsset?.takeIf { it.lineCount >= 200 } ?: fromRows(OpeningBook.BUILT_IN)
                cached = rep
                return rep
            }
        }

        /** TSV lichess: dòng đầu là tiêu đề (eco name pgn); cột thừa bị bỏ qua. */
        fun fromTsv(input: Sequence<String>): BotRepertoire {
            val rows = ArrayList<Triple<String, String, String>>(4096)
            for (raw in input) {
                val line = raw.trimEnd('\r', '\n')
                if (line.isBlank()) continue
                val c = line.split('\t')
                if (c.size < 3) continue
                if (c[0].equals("eco", ignoreCase = true)) continue
                rows += Triple(c[0].trim(), c[1].trim(), c[2].trim())
            }
            return fromRows(rows)
        }

        /** Dựng từ (eco, tên, các nước SAN). Dòng sai luật bị bỏ qua. */
        fun fromRows(rows: List<Triple<String, String, String>>): BotRepertoire {
            val out = ArrayList<Line>(rows.size)
            for ((eco, name, pgn) in rows) {
                val pos = Position.start()
                val ucis = ArrayList<String>(16)
                var valid = true
                for (tok in pgn.split(' ', '\t')) {
                    val san = tok.replace(MOVE_NUMBER, "")
                    if (san.isEmpty() || san == "*" || san == "1-0" || san == "0-1" || san == "1/2-1/2") continue
                    val mv = findMoveBySan(pos, san)
                    if (mv == null) { valid = false; break }
                    ucis += moveUci(mv)
                    pos.make(mv)
                }
                if (valid && ucis.isNotEmpty()) out += Line(eco, name, ucis)
            }
            return BotRepertoire(out)
        }

        private val MOVE_NUMBER = Regex("^\\d+\\.+")

        /** FNV-1a 64-bit -> số thực [0,1): cố định giữa các lần chạy và các máy. */
        internal fun hash01(s: String): Double {
            var h = -3750763034362895579L          // 0xcbf29ce484222325
            for (ch in s) {
                h = h xor ch.code.toLong()
                h *= 1099511628211L
            }
            return (h ushr 11).toDouble() / (1L shl 53).toDouble()
        }
    }
}
