package com.vila.chess

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import com.vila.chess.ui.SpaceBackground
import androidx.compose.ui.platform.LocalContext
import com.vila.chess.auth.AccountStore
import com.vila.chess.billing.BillingRepository
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Screen
import com.vila.chess.game.GameKind
import com.vila.chess.ui.BotGameScreen
import com.vila.chess.ui.GameReviewScreen
import com.vila.chess.ui.OnlineGameScreen
import com.vila.chess.ui.PvpGameScreen
import com.vila.chess.ui.GoogleLoginGate
import com.vila.chess.ui.HomeScreen
import com.vila.chess.ui.SkillLevelSetupScreen
import com.vila.chess.ui.ViLaTheme
import com.vila.chess.ui.VilaColors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ngầm, không hiện gì: mở app là tự đẩy lại các review còn kẹt (offline lần trước). Lỗi chỉ ghi log.
        lifecycleScope.launch { runCatching { com.vila.chess.cloud.SupabaseCloud.flushPending(applicationContext) } }
        AccountStore.load(this)   // nạp tài khoản trước khi vẽ UI để không nháy trang đăng nhập
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            ViLaTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    // Đồng bộ gói với Google Play lúc mở app (offline thì giữ gói đã lưu).
    LaunchedEffect(Unit) { BillingRepository.get(ctx).refreshEntitlements() }
    // Hồ sơ: nạp tên/quốc gia/avatar và bắt đầu theo dõi gói (mua gói → tier trong hồ sơ + cloud tự cập nhật).
    LaunchedEffect(Unit) { com.vila.chess.profile.UserSessionManager.init(ctx) }
    // Đổi tài khoản (đăng nhập/đăng xuất) → đẩy lại hồ sơ.
    LaunchedEffect(AccountStore.current?.email) { com.vila.chess.profile.UserSessionManager.requestSync(ctx) }
    // Cổng đăng nhập Google: chưa có tài khoản thì chỉ hiện trang đăng nhập.
    // Nếu google_web_client_id chưa được điền (còn YOUR_...) thì bỏ qua cổng để không bị kẹt ngoài app.
    val gateOn = !ctx.getString(R.string.google_web_client_id).startsWith("YOUR_")
    if (gateOn && AccountStore.current == null) {
        // Đã đăng xuất: huỷ mọi ViewModel (Elo, ván đang chơi, cài đặt...) để tài khoản sau không thừa hưởng trạng thái trong bộ nhớ.
        DisposableEffect(Unit) {
            (ctx as? ComponentActivity)?.viewModelStore?.clear()
            onDispose { }
        }
        GoogleLoginGate()
        return
    }
    // Tạo SAU cổng đăng nhập: mỗi lần đăng nhập là một GameViewModel mới, đọc dữ liệu của đúng tài khoản.
    val vm: GameViewModel = viewModel()
    // Sau đăng nhập: chọn trình độ một lần (lưu Elo khởi điểm) rồi vào màn hình chính.
    if (!vm.skillSetupDone) {
        SkillLevelSetupScreen(onSelect = { vm.completeSkillSetup(it) })
        return
    }
    // Crossfade + nền đặc: chuyển Dialog tổng kết -> Game Review không bị nháy trắng/đen giữa hai màn.
    Box(Modifier.fillMaxSize().background(VilaColors.Bg)) {
        // Hình nền động dùng chung cho TẤT CẢ màn (chủ đề, chơi cờ, review): chỉ một bản, không bị khởi động lại khi đổi màn.
        // graphicsLayer: tách thành lớp riêng, mỗi frame chỉ vẽ lại lớp nền chứ không kéo theo bàn cờ/UI phía trên => mượt hơn.
        SpaceBackground(Modifier.graphicsLayer())
        Crossfade(targetState = vm.screen, animationSpec = tween(220), label = "root") { screen ->
            when (screen) {
                Screen.HOME -> HomeScreen(vm)
                // Mỗi chế độ một màn riêng (cùng dùng GameViewModel + bàn cờ):
                //   Bot / Tàn cuộc / Giải đấu -> BotGameScreen · 2 người cùng máy -> PvpGameScreen · Online -> OnlineGameScreen
                Screen.GAME -> when (vm.ui.kind) {
                    GameKind.FRIEND -> PvpGameScreen(vm)
                    GameKind.ONLINE -> OnlineGameScreen(vm)
                    else -> BotGameScreen(vm)
                }
                Screen.REVIEW -> GameReviewScreen(vm)
            }
        }
        // Banner chúc mừng khi mở khóa thành tựu (nổi phía trên mọi màn, không chặn chạm).
        com.vila.chess.ui.AchievementBanner(Modifier.align(androidx.compose.ui.Alignment.TopCenter))
    }
}
