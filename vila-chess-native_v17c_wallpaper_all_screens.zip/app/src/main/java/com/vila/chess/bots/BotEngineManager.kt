package com.vila.chess.bots

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.vila.chess.review.DeviceTierManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Thông số làm yếu Stockfish cho một Bot.
 *
 * Lưu ý quan trọng: UCI_Elo của Stockfish chỉ nhận 1320..3190. Giá trị ngoài khoảng bị engine bỏ qua
 * (giữ mặc định 3190 = mạnh tối đa), nên với Bot dưới 1320 Elo ta KHÔNG dùng UCI_LimitStrength mà làm yếu bằng
 * Skill Level thấp + giới hạn depth + thời gian nghĩ ngắn + thỉnh thoảng chọn nước tốt thứ 2/3 (MultiPV).
 */
data class BotTuning(
    val limitStrength: Boolean,
    val uciElo: Int,
    val skill: Int,
    val depthCap: Int,
    val moveTimeMs: Long,
    val multiPv: Int,
    val blunderChance: Double,
    val blunderWindowCp: Int,
) {
    companion object {
        const val UCI_ELO_MIN = 1320
        const val UCI_ELO_MAX = 3190

        /** Skill Level 0..20 tăng tuyến tính theo Elo 250..2800. */
        fun skillFor(elo: Int): Int = (((elo - 250) / 2550.0) * 20.0).roundToInt().coerceIn(0, 20)

        fun forBot(bot: BotProfile): BotTuning {
            val elo = bot.elo
            val skill = skillFor(elo)
            val moveMs = (150 + elo * 0.4).toLong()
            val depthCap = when {
                elo < 500 -> 2
                elo < 800 -> 3
                elo < 1100 -> 5
                elo < 1320 -> 7
                else -> 0
            }
            val weak = elo < UCI_ELO_MIN
            val blunder = if (weak) ((UCI_ELO_MIN - elo) / UCI_ELO_MIN.toDouble() * 0.6) else 0.0
            return BotTuning(
                limitStrength = elo in UCI_ELO_MIN until UCI_ELO_MAX,
                uciElo = elo.coerceIn(UCI_ELO_MIN, UCI_ELO_MAX),
                skill = if (elo >= UCI_ELO_MAX) 20 else skill,
                depthCap = depthCap,
                moveTimeMs = moveMs,
                multiPv = if (weak) 3 else 1,
                blunderChance = blunder,
                blunderWindowCp = if (weak) 150 + (UCI_ELO_MIN - elo) / 4 else 0,
            )
        }
    }
}

/**
 * Quản lý MỘT engine Stockfish dùng chung cho các Bot. Hai backend, đều là Stockfish thật (không dùng engine tự viết):
 *  1. NATIVE: libstockfish.so (bản đầy đủ do main.yml tải) chạy bằng ProcessBuilder.
 *  2. WASM:   Stockfish 19 lite trong WebView ẩn (assets/stockfish/) — tự dùng khi không có/không chạy được bản native.
 * Cả hai nhận cùng bộ lệnh UCI (UCI_LimitStrength / UCI_Elo / Skill Level / MultiPV) theo Elo của từng bot.
 * Toàn bộ I/O không chạm UI thread. Một Mutex đảm bảo mỗi lúc chỉ một lệnh cấu hình/tìm nước; huỷ coroutine sẽ gửi
 * `stop` và xả hết dòng cũ nên lượt sau không bị lẫn kết quả. Engine im lặng/chết -> tự khởi động lại ở lượt sau.
 */
class BotEngineManager(context: Context) : AutoCloseable {

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val mutex = Mutex()
    private var transport: Transport? = null
    private var lines: Channel<String> = Channel(Channel.UNLIMITED)
    private var bot: BotProfile? = null
    private var tuning: BotTuning? = null
    private var optionsApplied = false
    private var needNewGame = true

    /** Đã thử native mà không chạy được -> các lần sau đi thẳng wasm. */
    @Volatile private var skipNative = false

    /** "native", "wasm" hoặc "none": để log/gỡ lỗi. */
    @Volatile var backendName: String = "none"
        private set

    private class Cand(val move: String, val cp: Int)

    /** Có engine Stockfish nào để dùng không: native hoặc wasm lite đi kèm trong assets. */
    val isEngineAvailable: Boolean
        get() = File(app.applicationInfo.nativeLibraryDir, BIN).exists() || wasmAssetsPresent()

    private fun wasmAssetsPresent(): Boolean = runCatching {
        app.assets.list("stockfish")?.any { it.endsWith(".wasm") } == true
    }.getOrDefault(false)

    /** Đánh dấu ván mới: lần tìm nước kế tiếp sẽ gửi `ucinewgame` (xoá bảng băm). */
    fun newGame() { needNewGame = true }

    /** Gửi các lệnh UCI để Stockfish chơi đúng sức của [bot]. Trả về false nếu không khởi động được engine nào. */
    suspend fun configureEngineForBot(bot: BotProfile): Boolean = mutex.withLock {
        withContext(Dispatchers.IO) {
            if (!ensureStarted()) return@withContext false
            if (this@BotEngineManager.bot?.id != bot.id) {
                this@BotEngineManager.bot = bot
                optionsApplied = false
            }
            if (!optionsApplied) applyOptions(bot)
            sync()
        }
    }

    /**
     * Nước đi (UCI, vd "e2e4") của Bot cho thế = [startFen] + [uciMoves]. Null nếu engine lỗi/không có.
     * [remainingMs] > 0 thì giới hạn thời gian nghĩ theo đồng hồ còn lại.
     */
    suspend fun bestMove(startFen: String, uciMoves: List<String>, remainingMs: Long = -1L): String? =
        mutex.withLock {
            withContext(Dispatchers.IO) {
                if (!ensureStarted()) return@withContext null
                val b = bot ?: return@withContext null
                if (!optionsApplied) applyOptions(b)       // engine vừa khởi động lại giữa ván
                val t = tuning ?: return@withContext null
                if (needNewGame) { send("ucinewgame"); needNewGame = false }
                if (!sync()) { stopProcess(); return@withContext null }

                var ms = t.moveTimeMs
                if (remainingMs > 0) ms = minOf(ms, (remainingMs / 20).coerceAtLeast(120L))
                send("position fen $startFen" + if (uciMoves.isEmpty()) "" else " moves " + uciMoves.joinToString(" "))
                send("go movetime $ms" + if (t.depthCap > 0) " depth ${t.depthCap}" else "")

                val cands = HashMap<Int, Cand>()
                var best: String? = null
                try {
                    // wasm khởi động search chậm hơn native một chút -> chừa thêm thời gian chờ.
                    best = collect(ms + if (transport?.isNative == false) 5000 else 2500, cands)
                    if (best == null) {
                        send("stop")
                        best = collect(1500, cands)
                    }
                } catch (e: CancellationException) {
                    withContext(NonCancellable) { send("stop"); collect(800, cands) }
                    throw e
                }
                // Engine không trả bestmove (treo/chết): bỏ tiến trình, lượt sau dựng lại từ đầu.
                if (best == null) { Log.w(TAG, "Bot engine ($backendName) không trả nước đi — khởi động lại"); stopProcess() }
                pickHumanLike(best, cands, t)
            }
        }

    // ---------- Transport ----------

    private abstract class Transport(val ch: Channel<String>, val isNative: Boolean) {
        abstract fun send(cmd: String)
        abstract fun isAlive(): Boolean
        abstract fun close()
    }

    private class NativeTransport(ch: Channel<String>, private val process: Process) : Transport(ch, true) {
        private val writer: BufferedWriter = process.outputStream.bufferedWriter()

        init {
            Thread {
                try {
                    process.inputStream.bufferedReader().forEachLine { ch.trySend(it) }
                } catch (_: IOException) {
                } finally {
                    ch.close()
                }
            }.apply { isDaemon = true; name = "bot-engine-reader" }.start()
        }

        @Synchronized
        override fun send(cmd: String) {
            runCatching { writer.write(cmd); writer.newLine(); writer.flush() }
        }

        override fun isAlive(): Boolean = process.isAlive

        override fun close() {
            Thread {
                send("stop"); send("quit")
                runCatching { if (!process.waitFor(300, TimeUnit.MILLISECONDS)) process.destroy() }
                runCatching { process.destroyForcibly() }
                runCatching { writer.close() }
            }.apply { isDaemon = true }.start()
        }
    }

    private class WebTransport(ch: Channel<String>, val view: WebView, private val main: Handler) :
        Transport(ch, false) {
        @Volatile private var closed = false

        override fun send(cmd: String) {
            if (closed) return
            val js = "send(" + JSONObject.quote(cmd) + ");"
            main.post { if (!closed) view.evaluateJavascript(js, null) }
        }

        override fun isAlive(): Boolean = !closed

        override fun close() {
            if (closed) return
            main.post {
                view.evaluateJavascript("try{send('stop');send('quit');}catch(e){}", null)
                main.postDelayed({
                    closed = true
                    runCatching {
                        view.loadUrl("about:blank")
                        view.removeJavascriptInterface("Bridge")
                        view.destroy()
                    }
                }, 300)
            }
            closed = true
        }
    }

    private class Bridge(private val ch: Channel<String>) {
        @JavascriptInterface
        fun line(s: String) { ch.trySend(s) }
    }

    // ---------- nội bộ ----------

    private fun applyOptions(b: BotProfile) {
        val t = BotTuning.forBot(b)
        tuning = t
        send("setoption name UCI_LimitStrength value ${t.limitStrength}")
        if (t.limitStrength) send("setoption name UCI_Elo value ${t.uciElo}")
        send("setoption name Skill Level value ${t.skill}")
        send("setoption name MultiPV value ${t.multiPv}")
        optionsApplied = true
        needNewGame = true
    }

    private fun pickHumanLike(best: String?, cands: Map<Int, Cand>, t: BotTuning): String? {
        if (best == null || t.blunderChance <= 0.0) return best
        if (Random.nextDouble() >= t.blunderChance) return best
        val bestCp = cands[1]?.cp ?: return best
        val alt = cands.filter { it.key > 1 && it.value.cp >= bestCp - t.blunderWindowCp && it.value.cp > -9000 }
            .values.randomOrNull()
        return alt?.move ?: best
    }

    private suspend fun collect(timeoutMs: Long, cands: MutableMap<Int, Cand>): String? =
        withTimeoutOrNull(timeoutMs) {
            var best: String? = null
            var done = false
            while (!done) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith("bestmove")) {
                    best = l.split(' ').getOrNull(1)?.takeIf { it != "(none)" }
                    done = true
                } else {
                    parseInfo(l, cands)
                }
            }
            best
        }

    private fun parseInfo(line: String, cands: MutableMap<Int, Cand>) {
        if (!line.startsWith("info") || " lowerbound" in line || " upperbound" in line) return
        val sc = SCORE.find(line) ?: return
        val pv = PV.find(line)?.groupValues?.get(1)?.trim()?.split(' ')?.firstOrNull() ?: return
        val idx = MULTIPV.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: 1
        val v = sc.groupValues[2].toInt()
        val cp = if (sc.groupValues[1] == "mate") (if (v > 0) 10_000 - v else -10_000 - v) else v
        cands[idx] = Cand(pv, cp)
    }

    private suspend fun ensureStarted(): Boolean {
        if (transport?.isAlive() == true) return true
        stopProcess()
        val bin = File(app.applicationInfo.nativeLibraryDir, BIN)
        val candidates = ArrayList<suspend () -> Transport?>(3)
        if (!skipNative && bin.exists()) {
            // Chạy qua `nice` (độ ưu tiên CPU thấp) để Stockfish không giành CPU của luồng vẽ => kéo quân / premove không bị khựng.
            if (File(NICE_BIN).exists()) candidates += { createNative(bin, niced = true) }
            candidates += { createNative(bin, niced = false) }
        }
        if (wasmAssetsPresent()) candidates += { createWeb() }
        var nativeFailed = false
        for (create in candidates) {
            val t = create() ?: continue
            transport = t
            lines = t.ch
            if (handshake(t)) {
                backendName = if (t.isNative) "native" else "wasm"
                // Native hỏng mà wasm chạy được -> các lần khởi động lại sau đi thẳng wasm, khỏi thử native nữa.
                if (!t.isNative && nativeFailed) skipNative = true
                Log.i(TAG, "Bot engine khởi động: $backendName")
                return true
            }
            t.close()
            transport = null
            if (t.isNative) nativeFailed = true
        }
        backendName = "none"
        Log.e(TAG, "Bot engine: không khởi động được Stockfish nào (native lẫn wasm)")
        return false
    }

    private suspend fun createNative(bin: File, niced: Boolean): Transport? = withContext(Dispatchers.IO) {
        val cmd = if (niced) listOf(NICE_BIN, "-n", "10", bin.absolutePath) else listOf(bin.absolutePath)
        try {
            NativeTransport(Channel(Channel.UNLIMITED), ProcessBuilder(cmd).redirectErrorStream(true).start())
        } catch (_: Exception) {
            null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun createWeb(): Transport? = withContext(Dispatchers.Main) {
        try {
            val ch = Channel<String>(Channel.UNLIMITED)
            val wv = WebView(app)
            wv.settings.javaScriptEnabled = true
            wv.settings.allowFileAccess = false
            wv.settings.allowContentAccess = false
            wv.addJavascriptInterface(Bridge(ch), "Bridge")
            wv.webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                    val u = request.url
                    if (u.host != WEB_HOST) return null
                    val name = u.lastPathSegment ?: return null
                    val mime = when {
                        name.endsWith(".html") -> "text/html"
                        name.endsWith(".js") -> "text/javascript"
                        name.endsWith(".wasm") -> "application/wasm"
                        else -> "application/octet-stream"
                    }
                    return try {
                        WebResourceResponse(mime, "utf-8", app.assets.open("stockfish/$name"))
                    } catch (_: IOException) {
                        WebResourceResponse(null, null, 404, "Not Found", emptyMap(), null)
                    }
                }
            }
            wv.onResume()
            wv.resumeTimers()
            wv.loadUrl(WEB_BASE + "engine.html")
            WebTransport(ch, wv, main)
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun handshake(t: Transport): Boolean {
        if (!t.isNative && !waitFor("info string page-ready", 15_000)) return false
        t.send("uci")
        if (!waitFor("uciok", if (t.isNative) 8_000 else 30_000)) return false
        val cfg = DeviceTierManager.getDeviceTier(app)
        if (t.isNative) {
            // Tối đa 2 luồng khi đang chơi: máy nhiều nhân vẫn chừa nhân cho giao diện.
            t.send("setoption name Threads value ${minOf(cfg.threads, 2)}")
            t.send("setoption name Hash value ${minOf(cfg.hashMb, 64)}")
        } else {
            // Wasm đơn luồng, bộ nhớ chặt: giữ Hash nhỏ.
            t.send("setoption name Hash value ${minOf(cfg.hashMb, MAX_WASM_HASH_MB)}")
        }
        optionsApplied = false
        needNewGame = true
        t.send("isready")
        return waitFor("readyok", 15_000)
    }

    /** isready/readyok: chắc chắn mọi dòng cũ (kể cả bestmove thừa sau stop) đã được xả. */
    private suspend fun sync(): Boolean {
        while (lines.tryReceive().isSuccess) { /* xả */ }
        send("isready")
        return waitFor("readyok", if (transport?.isNative == false) 6_000 else 3_000)
    }

    private suspend fun waitFor(prefix: String, timeoutMs: Long): Boolean =
        withTimeoutOrNull(timeoutMs) {
            var found = false
            while (!found) {
                val l = lines.receiveCatching().getOrNull() ?: break
                if (l.startsWith(prefix)) found = true
            }
            found
        } ?: false

    private fun send(cmd: String) { transport?.send(cmd) }

    private fun stopProcess() {
        val t = transport
        transport = null
        optionsApplied = false
        needNewGame = true
        t?.close()
    }

    /** Giải phóng engine (không chặn UI thread). Gọi lại configure/bestMove sẽ tự khởi động lại. */
    override fun close() {
        stopProcess()
        lines.close()
        bot = null
    }

    private companion object {
        const val TAG = "BotEngine"
        const val BIN = "libstockfish.so"
        const val NICE_BIN = "/system/bin/nice"
        const val WEB_HOST = "appassets.androidplatform.net"
        const val WEB_BASE = "https://$WEB_HOST/assets/stockfish/"
        const val MAX_WASM_HASH_MB = 32
        val SCORE = Regex("""\bscore (cp|mate) (-?\d+)""")
        val MULTIPV = Regex("""\bmultipv (\d+)""")
        val PV = Regex(""" pv (.+)$""")
    }
}
