package com.vila.chess.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/**
 * Hình nền của app (tab "Hình nền" trong trang Chủ đề).
 * [top]/[mid]/[bottom] = gradient dọc; [glowA] góc dưới phải, [glowB] mép trái, [glowC] đỉnh; [stars] = có rải sao hay không;
 * [animated] = nền động.
 */
data class Wallpaper(
    val id: String,
    val label: String,
    val top: Color,
    val mid: Color,
    val bottom: Color,
    val glowA: Color,
    val glowB: Color,
    val glowC: Color,
    val stars: Boolean = true,
    /** true = nền chuyển động (thiên hà xoay, sao lấp lánh/trôi, sao băng) - xem GalaxyBackground trong SpaceBackground.kt. */
    val animated: Boolean = false,
    /** Tên cảnh động vũ trụ (blackhole/warp/planet/nebula/meteor/solar) - xem SceneBackground trong SpaceScenes.kt; rỗng = không dùng. */
    val scene: String = "",
)

/** [current] là state của Compose: SpaceBackground đọc từ đây nên đổi hình nền là cả app đổi ngay. */
object Wallpapers {
    const val DEFAULT = "space"

    val all: List<Wallpaper> = listOf(
        Wallpaper("space", "Không gian", Color(0xFF0A1530), Color(0xFF10264A), Color(0xFF0A1226), Color(0x552F6FD0), Color(0x33A24FD0), Color(0x2238A1FF)),
        Wallpaper("galaxy", "Ngân hà", Color(0xFF040716), Color(0xFF0A0F2C), Color(0xFF03050F), Color(0x553F6BFF), Color(0x44B04FD0), Color(0x2238A1FF), animated = true),
        Wallpaper("blackhole", "Hố đen", Color(0xFF020208), Color(0xFF080610), Color(0xFF020205), Color(0x22FF8A3C), Color(0x11803010), Color(0x11402010), animated = true, scene = "blackhole"),
        Wallpaper("warp", "Siêu tốc", Color(0xFF02030E), Color(0xFF070B2A), Color(0xFF02030C), Color(0x333F6BFF), Color(0x228A4FFF), Color(0x1138A1FF), animated = true, scene = "warp"),
        Wallpaper("planet", "Hành tinh", Color(0xFF030614), Color(0xFF081030), Color(0xFF030614), Color(0x222F6FD0), Color(0x11A24FD0), Color(0x1138A1FF), animated = true, scene = "planet"),
        Wallpaper("nebula_live", "Tinh vân", Color(0xFF06030F), Color(0xFF120A2A), Color(0xFF05030C), Color(0x22B04FD0), Color(0x1130C0E8), Color(0x11E0409A), animated = true, scene = "nebula"),
        Wallpaper("meteor", "Mưa sao băng", Color(0xFF020510), Color(0xFF0A1636), Color(0xFF030814), Color(0x223F6BFF), Color(0x11A24FD0), Color(0x1138A1FF), animated = true, scene = "meteor"),
        Wallpaper("solar", "Hệ mặt trời", Color(0xFF03040C), Color(0xFF0A0C1E), Color(0xFF020309), Color(0x22FFB050), Color(0x112F6FD0), Color(0x11FF8A2A), animated = true, scene = "solar"),
        Wallpaper("aurora", "Cực quang", Color(0xFF04161C), Color(0xFF0B3A3F), Color(0xFF061A22), Color(0x5538D9A9), Color(0x3340C4FF), Color(0x2280FFC8)),
        Wallpaper("sunset", "Hoàng hôn", Color(0xFF1D0F2E), Color(0xFF4A1F4D), Color(0xFF1A0E22), Color(0x55FF7A45), Color(0x33D94F9B), Color(0x22FFB36B)),
        Wallpaper("night", "Đêm đen", Color(0xFF05060A), Color(0xFF0C0E16), Color(0xFF040509), Color(0x223A4A80), Color(0x1A5A4A8A), Color(0x112F3A5F)),
        Wallpaper("ocean", "Biển sâu", Color(0xFF031A2E), Color(0xFF06406B), Color(0xFF031524), Color(0x5531B5F0), Color(0x3320D0C0), Color(0x2260C8FF)),
        Wallpaper("forest", "Rừng đêm", Color(0xFF08160F), Color(0xFF12361F), Color(0xFF07120B), Color(0x5547B86B), Color(0x3380C060), Color(0x22A0E080)),
        Wallpaper("sakura", "Anh đào", Color(0xFF2A0F20), Color(0xFF5A1F44), Color(0xFF220C1A), Color(0x55FF7FB0), Color(0x33FFB0D0), Color(0x22FF99C0)),
        Wallpaper("nebula", "Thiên hà tím", Color(0xFF140A30), Color(0xFF2D1566), Color(0xFF0F0825), Color(0x558A5CFF), Color(0x33D04FD0), Color(0x226C7CFF)),
        Wallpaper("graphite", "Than chì", Color(0xFF1B1C1F), Color(0xFF26282C), Color(0xFF151618), Color(0x1AFFFFFF), Color(0x0FFFFFFF), Color(0x0CFFFFFF), stars = false),
        Wallpaper("ember", "Dung nham", Color(0xFF1F0A08), Color(0xFF4A140E), Color(0xFF190806), Color(0x55FF5A2A), Color(0x33FF9A2A), Color(0x22FF6A3A)),
    )

    fun exists(id: String): Boolean = all.any { it.id == id }

    fun byId(id: String): Wallpaper = all.firstOrNull { it.id == id } ?: all[0]

    var current: Wallpaper by mutableStateOf(all[0])
        private set

    fun select(id: String) {
        current = byId(id)
    }
}
