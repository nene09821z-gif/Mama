package com.vila.chess.ui

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.vila.chess.profile.AvatarPhotos
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// =============================================================================
// Chọn ảnh đại diện từ thư viện ảnh của máy:
//   rememberAvatarPicker { key -> … }  →  trả về hàm "mở thư viện". Khi người dùng chọn ảnh sẽ hiện màn CẮT ẢNH
//   (kéo để di chuyển, chụm 2 ngón / thanh trượt để phóng to, khung tròn + lưới 1/3), bấm "Dùng ảnh này" thì
//   ảnh được cắt vuông 512px, lưu vào bộ nhớ riêng của app và [onPicked] nhận khoá "photo:…".
// Dùng Photo Picker của hệ thống (Android 13+; máy cũ tự lùi về trình chọn tài liệu) → KHÔNG cần xin quyền đọc ảnh.
// =============================================================================

@Composable
fun rememberAvatarPicker(onPicked: (String) -> Unit): () -> Unit {
    var pending by remember { mutableStateOf<Uri?>(null) }
    val latest by rememberUpdatedState(onPicked)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) pending = uri
    }
    pending?.let { uri ->
        AvatarCropDialog(
            uri = uri,
            onDismiss = { pending = null },
            onDone = { key -> pending = null; latest(key) },
        )
    }
    return { launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
}

private const val MAX_ZOOM = 6f

@Composable
fun AvatarCropDialog(uri: Uri, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    // Giải mã ảnh ở luồng nền. second = đã xong (kể cả thất bại).
    val loaded by produceState<Pair<Bitmap?, Boolean>>(initialValue = null to false, uri) {
        val bmp = withContext(Dispatchers.IO) { AvatarPhotos.decodeForCrop(ctx, uri) }
        value = bmp to true
    }
    val bmp = loaded.first
    val image = remember(bmp) { bmp?.asImageBitmap() }

    var zoom by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var area by remember { mutableStateOf(IntSize.Zero) }
    var saving by remember { mutableStateOf(false) }

    // ---- hình học: khung tròn S, hệ số phủ kín khung (base), tỉ lệ hiển thị (s)
    fun frame(): Float = min(area.width, area.height) * 0.86f
    fun scaleOf(b: Bitmap, z: Float): Float = frame() / min(b.width, b.height) * z
    fun clamp(b: Bitmap, o: Offset, z: Float): Offset {
        val s = scaleOf(b, z)
        val mx = max(0f, (b.width * s - frame()) / 2f)
        val my = max(0f, (b.height * s - frame()) / 2f)
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    fun confirm() {
        val b = bmp ?: return
        if (saving || area == IntSize.Zero) return
        saving = true
        val s = scaleOf(b, zoom)
        val o = clamp(b, offset, zoom)
        val cx = b.width / 2f - o.x / s
        val cy = b.height / 2f - o.y / s
        val half = frame() / (2f * s)
        scope.launch {
            val key = withContext(Dispatchers.IO) { AvatarPhotos.saveCropped(ctx, b, cx, cy, half) }
            saving = false
            if (key != null) onDone(key)
            else Toast.makeText(ctx, "Không lưu được ảnh. Thử ảnh khác nhé.", Toast.LENGTH_SHORT).show()
        }
    }

    Dialog(
        onDismissRequest = { if (!saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
    ) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF070D1C)).statusBarsPadding().navigationBarsPadding(),
        ) {
            // ---- thanh trên
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).clickable(enabled = !saving, onClick = onDismiss),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.Close, "Đóng", tint = Color.White) }
                Text("Cắt ảnh đại diện", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 6.dp))
            }

            // ---- vùng cắt
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    image != null && bmp != null -> {
                        Canvas(
                            Modifier
                                .fillMaxSize()
                                .onSizeChanged { area = it }
                                .pointerInput(bmp) {
                                    detectTransformGestures { _, pan, zoomChange, _ ->
                                        val nz = (zoom * zoomChange).coerceIn(1f, MAX_ZOOM)
                                        offset = clamp(bmp, offset + pan, nz)
                                        zoom = nz
                                    }
                                },
                        ) {
                            val s = scaleOf(bmp, zoom)
                            val o = clamp(bmp, offset, zoom)
                            val dw = bmp.width * s
                            val dh = bmp.height * s
                            val c = Offset(size.width / 2f, size.height / 2f)
                            val r = frame() / 2f
                            drawImage(
                                image = image,
                                srcOffset = IntOffset.Zero,
                                srcSize = IntSize(bmp.width, bmp.height),
                                dstOffset = IntOffset((c.x + o.x - dw / 2f).roundToInt(), (c.y + o.y - dh / 2f).roundToInt()),
                                dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
                                filterQuality = FilterQuality.High,
                            )
                            // Màn phủ tối có lỗ tròn ở giữa
                            val scrim = Path().apply {
                                fillType = PathFillType.EvenOdd
                                addRect(Rect(0f, 0f, size.width, size.height))
                                addOval(Rect(center = c, radius = r))
                            }
                            drawPath(scrim, Color(0xC8070D1C))
                            // Lưới 1/3 trong khung
                            clipPath(Path().apply { addOval(Rect(center = c, radius = r)) }) {
                                val grid = Color(0x33FFFFFF)
                                val w = 1.dp.toPx()
                                for (i in 1..2) {
                                    val t = -r + 2f * r * i / 3f
                                    drawLine(grid, Offset(c.x + t, c.y - r), Offset(c.x + t, c.y + r), w)
                                    drawLine(grid, Offset(c.x - r, c.y + t), Offset(c.x + r, c.y + t), w)
                                }
                            }
                            drawCircle(Color.White, radius = r, center = c, style = Stroke(2.dp.toPx()))
                        }
                    }
                    loaded.second -> Text(
                        "Không đọc được ảnh này.\nHãy thử chọn một ảnh khác.",
                        color = VilaColors.TextDim, fontSize = 15.sp, textAlign = TextAlign.Center,
                    )
                    else -> CircularProgressIndicator(color = VilaColors.Green, modifier = Modifier.size(34.dp), strokeWidth = 3.dp)
                }
            }

            // ---- điều khiển dưới
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Kéo để di chuyển · chụm hai ngón để phóng to", color = VilaColors.TextDim, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.ZoomOut, null, tint = VilaColors.TextDim, modifier = Modifier.size(22.dp))
                    Slider(
                        value = zoom,
                        onValueChange = { z ->
                            zoom = z
                            if (bmp != null) offset = clamp(bmp, offset, z)
                        },
                        valueRange = 1f..MAX_ZOOM,
                        enabled = bmp != null,
                        colors = SliderDefaults.colors(
                            thumbColor = VilaColors.Green, activeTrackColor = VilaColors.Green,
                            inactiveTrackColor = Color(0x33FFFFFF),
                        ),
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    )
                    Icon(Icons.Filled.ZoomIn, null, tint = VilaColors.TextDim, modifier = Modifier.size(22.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .weight(1f).height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1FFFFFFF))
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                            .clickable(enabled = !saving) { zoom = 1f; offset = Offset.Zero },
                        contentAlignment = Alignment.Center,
                    ) { Text("Đặt lại", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    ChunkyButton(
                        text = if (saving) "Đang lưu…" else "Dùng ảnh này",
                        onClick = { if (bmp != null) confirm() },
                        modifier = Modifier.weight(1.6f), height = 48.dp, fontSize = 17.sp,
                    )
                }
                Spacer(Modifier.width(1.dp))
            }
        }
    }
}
