package com.vila.chess.online

/** Một tin nhắn trong ván online. [ts] = epoch ms do máy chủ ghi. */
data class ChatMessage(val id: Long, val userId: String, val name: String, val body: String, val ts: Long)

/** Hàm thuần của khung chat (không Android) — test được trên JVM. */
object ChatLogic {
    const val MAX_LEN = 200

    /** Câu trả lời nhanh, chạm 1 lần là gửi. */
    val QUICK_REPLIES: List<String> = listOf(
        "Chúc may mắn! 🍀",
        "Nước hay đó 👏",
        "Hơi bất ngờ 😅",
        "Đi nhanh nào ⏱",
        "GG, chơi vui nhé 🤝",
    )

    /** Chuẩn hóa nội dung trước khi gửi: bỏ khoảng trắng thừa, gộp xuống dòng, cắt tối đa [MAX_LEN]. Rỗng nếu không còn gì. */
    fun clean(raw: String): String =
        raw.replace(Regex("\\s+"), " ").trim().take(MAX_LEN)

    /** Gộp tin mới vào danh sách cũ: bỏ trùng id, xếp theo id tăng dần, giữ tối đa [cap] tin gần nhất. */
    fun merge(existing: List<ChatMessage>, incoming: List<ChatMessage>, cap: Int = 200): List<ChatMessage> {
        if (incoming.isEmpty()) return existing
        val seen = HashSet<Long>(existing.size + incoming.size)
        val out = ArrayList<ChatMessage>(existing.size + incoming.size)
        for (m in existing) if (seen.add(m.id)) out += m
        for (m in incoming) if (seen.add(m.id)) out += m
        out.sortBy { it.id }
        return if (out.size > cap) ArrayList(out.subList(out.size - cap, out.size)) else out
    }

    /** Id lớn nhất đã có (0 nếu chưa có tin nào) — dùng làm mốc "tin mới hơn". */
    fun lastId(messages: List<ChatMessage>): Long = messages.maxOfOrNull { it.id } ?: 0L

    /** Số tin của người KHÁC có id lớn hơn [seenUpTo] (để hiện số chưa đọc). */
    fun unread(messages: List<ChatMessage>, myId: String?, seenUpTo: Long): Int =
        messages.count { it.id > seenUpTo && !it.userId.equals(myId, ignoreCase = true) }
}
