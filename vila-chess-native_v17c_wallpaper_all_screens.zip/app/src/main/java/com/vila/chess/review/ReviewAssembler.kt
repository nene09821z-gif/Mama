package com.vila.chess.review

import com.vila.chess.core.Position
import com.vila.chess.core.moveToSan
import com.vila.chess.core.moveUci

/** Một nước đi đã dựng lại từ ván: UCI, SAN và FEN trước/sau. */
data class ReplayPly(val uci: String, val san: String, val fenBefore: String, val fenAfter: String)

data class ReplayResult(val startFen: String, val plies: List<ReplayPly>)

/** Hàm thuần (không Android, không engine): dựng lại ván và ráp dữ liệu review. */
object ReviewReplay {
    const val QUEUE_HEADER = "#v2"

    /** File hàng đợi: dòng 1 = "#v2", dòng 2 = FEN đầu ván, các dòng sau = nước đi UCI. */
    fun encodeQueue(startFen: String, ucis: List<String>): String =
        (listOf(QUEUE_HEADER, startFen) + ucis).joinToString("\n")

    /** Đọc file hàng đợi. Cũng đọc được định dạng cũ (mỗi dòng là một FEN). null nếu hỏng. */
    fun parseQueue(rawLines: List<String>): ReplayResult? {
        val lines = rawLines.map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return null
        return runCatching {
            if (lines[0] == QUEUE_HEADER) {
                if (lines.size < 2) null else replay(lines[1], lines.drop(2))
            } else {
                replayFromFens(lines)
            }
        }.getOrNull()
    }

    fun replay(startFen: String, ucis: List<String>): ReplayResult? {
        val pos = Position.fromFen(startFen)
        val start = pos.fen()
        val out = ArrayList<ReplayPly>(ucis.size)
        for (uci in ucis) {
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { moveUci(it) == uci } ?: return null
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    /** Định dạng hàng đợi cũ: tìm nước đi nối từng cặp FEN liên tiếp. */
    private fun replayFromFens(fens: List<String>): ReplayResult? {
        val pos = Position.fromFen(fens[0])
        val start = pos.fen()
        val out = ArrayList<ReplayPly>()
        for (i in 1 until fens.size) {
            val target = key(fens[i])
            val before = pos.fen()
            val mv = pos.legalMoves().firstOrNull { m ->
                pos.make(m)
                val hit = key(pos.fen()) == target
                pos.unmake()
                hit
            } ?: return null
            val uci = moveUci(mv)
            val san = moveToSan(pos, mv)
            pos.make(mv)
            out += ReplayPly(uci, san, before, pos.fen())
        }
        return ReplayResult(start, out)
    }

    private fun key(fen: String) = fen.trim().split(Regex("\\s+")).take(4).joinToString(" ")

    /**
     * Thế đã kết thúc ván (chiếu hết, hết nước đi = hòa, không đủ quân chiếu) thì tính bằng luật cờ,
     * không hỏi engine. Điểm theo góc nhìn bên đang đi. Chiếu hết: mate = 0, cp = -10000.
     */
    fun terminalEval(fen: String): EngineResult? {
        val pos = Position.fromFen(fen)
        return when {
            pos.legalMoves().isEmpty() ->
                if (pos.inCheck()) EngineResult(null, -10_000, 0, 0, false, engine = MoveReview.ENGINE_RULES)
                else EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            pos.insufficientMaterial() ->
                EngineResult(null, 0, null, 0, false, engine = MoveReview.ENGINE_RULES)
            else -> null
        }
    }
}

object ReviewAssembler {

    /** Tăng khi cách phân loại thay đổi: kết quả cũ hơn bị coi là chưa phân tích (xem ReviewRepository). */
    const val ANALYSIS_VERSION = ReviewJson.CURRENT_VERSION

    /**
     * evals[i] = kết quả phân tích thế SAU i nước (evals[0] = thế đầu ván), tức evals.size == plies.size + 1.
     * Điểm trong evals là góc nhìn bên đang đi; ở đây đổi hết sang góc nhìn Trắng rồi đưa cho [MoveClassifier].
     * [book] = sổ khai cuộc (null = không gán Book / tên khai cuộc). Chỉ dùng khi ván bắt đầu từ thế cờ chuẩn.
     */
    fun assemble(
        gameId: String,
        startFen: String,
        plies: List<ReplayPly>,
        evals: List<EngineResult>,
        tier: String,
        createdAt: Long,
        book: OpeningBook? = null,
    ): GameReview {
        require(evals.size == plies.size + 1) { "evals phải nhiều hơn plies đúng 1 phần tử" }

        fun fenAt(i: Int) = if (i == 0) (plies.firstOrNull()?.fenBefore ?: startFen) else plies[i - 1].fenAfter
        fun whiteToMoveAt(i: Int) = fenAt(i).split(' ').getOrNull(1) != "b"

        val cpWhite = IntArray(evals.size) { i -> (if (whiteToMoveAt(i)) 1 else -1) * evals[i].scoreCp }
        val mateWhite = Array(evals.size) { i ->
            evals[i].mate?.let { m -> if (m == 0) 0 else (if (whiteToMoveAt(i)) m else -m) }
        }

        val useBook = book != null && OpeningBook.positionKey(fenAt(0)) == OpeningBook.START_KEY
        var inBookChain = useBook
        var lastOpening: OpeningInfo? = null

        // Lượt 1 (nhẹ): mất EP thô mỗi nước của từng bên -> hồ sơ nhãn thích ứng theo trình độ thật của ván (ZARS-lite).
        val rawW = ArrayList<Double>()
        val rawB = ArrayList<Double>()
        for (i in 1..plies.size) {
            val wm = whiteToMoveAt(i - 1)
            val sg = if (wm) 1 else -1
            val eb = MoveClassifier.calculateWinProbability(cpWhite[i - 1], mateWhite[i - 1], wm)
            val ea = MoveClassifier.calculateWinProbability(cpWhite[i], mateWhite[i], wm)
            val b0 = evals[i - 1]
            val es = if (b0.secondMove != null && b0.secondCp != null) {
                MoveClassifier.calculateWinProbability(sg * b0.secondCp, b0.secondMate?.let { m -> if (m == 0) 0 else sg * m }, wm)
            } else null
            val l = MoveClassifier.moveLoss(eb, ea, plies[i - 1].uci, b0.bestMove, b0.secondMove, es)
            (if (wm) rawW else rawB) += l
        }
        val profileWhite = MoveClassifier.adaptiveProfile(rawW)
        val profileBlack = MoveClassifier.adaptiveProfile(rawB)

        val moves = ArrayList<MoveReview>(plies.size)
        val lossesWhite = ArrayList<Double>()
        val lossesBlack = ArrayList<Double>()
        for (i in 1..plies.size) {
            val p = plies[i - 1]
            val before = evals[i - 1]
            val whiteMoved = whiteToMoveAt(i - 1)
            val sign = if (whiteMoved) 1 else -1

            // EP của bên vừa đi trước / sau nước đi (calculateWinProbability tự đảo góc nhìn khi là lượt Đen).
            val epBefore = MoveClassifier.calculateWinProbability(cpWhite[i - 1], mateWhite[i - 1], whiteMoved)
            val epAfter = MoveClassifier.calculateWinProbability(cpWhite[i], mateWhite[i], whiteMoved)
            // Nước tốt nhì (MultiPV 2) cùng một lượt tìm kiếm với nước tốt nhất => so sánh sạch, không nhiễu độ sâu.
            val epSecond = if (before.secondMove != null && before.secondCp != null) {
                MoveClassifier.calculateWinProbability(
                    sign * before.secondCp, before.secondMate?.let { m -> if (m == 0) 0 else sign * m }, whiteMoved,
                )
            } else null

            val best = MoveClassifier.isBestMove(p.uci, before.bestMove, before.secondMove, epBefore, epSecond)

            // Book: thế SAU nước đi còn nằm trong sổ, và mọi nước trước đó cũng vậy.
            var inBook = false
            if (useBook && inBookChain) {
                val hit = book!!.lookup(p.fenAfter)
                if (hit != null) { inBook = true; lastOpening = hit } else inBookChain = false
            }

            val loss = if (inBook) 0.0
            else MoveClassifier.moveLoss(epBefore, epAfter, p.uci, before.bestMove, before.secondMove, epSecond)

            // Mate của thế SAU nước đi, góc nhìn bên VỪA ĐI: dương = mình sắp chiếu hết, 0 = vừa chiếu hết, âm = mình sắp bị chiếu hết.
            val mateAfterMover = evals[i].mate?.let { m -> if (m == 0) 0 else -m }

            // Luật mate của Lichess: sàn cho NHÃN (đi vào thế bị mate / bỏ lỡ mate). Nước tốt nhất không bao giờ bị phạt.
            val floor = if (best || inBook) 0.0 else MoveClassifier.mateRuleFloor(
                mateBefore = before.mate,
                cpBefore = before.scoreCp,
                mateAfter = mateAfterMover,
                cpAfter = -evals[i].scoreCp,
            )

            val prevPly = plies.getOrNull(i - 2)
            val isRecapture = prevPly != null && prevPly.san.contains('x') && p.san.contains('x') &&
                prevPly.uci.substring(2, 4) == p.uci.substring(2, 4)
            val prevLabel = moves.lastOrNull()?.label
            val opponentBlundered = prevLabel == MoveLabel.MISTAKE || prevLabel == MoveLabel.BLUNDER

            val rawLabel = MoveClassifier.classifyMove(
                epBefore = epBefore,
                epAfter = epAfter,
                movePlayed = p.uci,
                bestMove = before.bestMove,
                secondBestMove = before.secondMove,
                isSacrifice = best && !inBook && epAfter >= MoveClassifier.BRILLIANT_MIN_EP_AFTER &&
                    SacrificeDetector.isSacrifice(p.fenBefore, p.uci),
                isOpponentJustBlundered = opponentBlundered,
                epSecondBest = epSecond,
                isRecapture = isRecapture,
                inBook = inBook,
                lossFloor = floor,
                mateAfter = mateAfterMover,
                profile = if (whiteMoved) profileWhite else profileBlack,
            )
            // Lớp độ tin cậy: engine mới tìm nông (độ sâu <= 9) thì hạ nhãn chói / nhãn nặng một bậc; mate và sàn mate giữ nguyên.
            val label = LabelEvidence.settle(
                label = rawLabel,
                depthBefore = before.depthReached,
                depthAfter = evals[i].depthReached,
                decidedByMate = before.mate != null || evals[i].mate != null || floor > 0.0,
            )

            (if (whiteMoved) lossesWhite else lossesBlack) += loss

            moves += MoveReview(
                ply = i,
                whiteMoved = whiteMoved,
                label = label,
                winLoss = loss * 100.0,
                evalAfterCpWhite = cpWhite[i],
                bestMoveBefore = before.bestMove,
                uci = p.uci,
                san = p.san,
                fenBefore = p.fenBefore,
                fenAfter = p.fenAfter,
                evalBeforeCpWhite = cpWhite[i - 1],
                mateBeforeWhite = mateWhite[i - 1],
                mateAfterWhite = mateWhite[i],
                pv = before.pv,
                depthBefore = before.depthReached,
                depthAfter = evals[i].depthReached,
                secondBestMove = before.secondMove,
                secondBestCpWhite = before.secondCp?.let { sign * it },
                secondBestMateWhite = before.secondMate?.let { m -> if (m == 0) 0 else sign * m },
                engine = before.engine,
                multiPv = before.multiPv,
                ecoCode = lastOpening?.eco,
                openingName = lastOpening?.name,
                epBefore = epBefore,
                epAfter = epAfter,
            )
        }

        val main = evals.firstOrNull { it.engine != MoveReview.ENGINE_RULES }
        return GameReview(
            gameId = gameId,
            moves = moves,
            accuracyWhite = MoveClassifier.calculateGameAccuracy(lossesWhite),
            accuracyBlack = MoveClassifier.calculateGameAccuracy(lossesBlack),
            tier = tier,
            createdAt = createdAt,
            startFen = startFen,
            engine = main?.engine ?: "none",
            multiPv = main?.multiPv ?: 1,
        )
    }
}


/**
 * Chọn các thế cờ cần tìm kiếm lại SÂU HƠN (vòng kiểm chứng) sau lượt phân tích đầu.
 * Chỉ những nước nghi sai (không phải nước tốt nhất mà mất >= [SUSPECT_LOSS] win) mới đáng tốn thêm thời gian:
 * kết luận Mistake/Blunder/Miss dựa trên số liệu sâu hơn nên ít bị "oan" do nhiễu độ sâu. Hàm thuần, test được trên JVM.
 */
object ReviewVerify {
    const val SUSPECT_LOSS = 0.06
    const val MAX_PLIES = 8   // tối đa 8 nước x 2 thế = 16 lượt tìm kiếm thêm

    /** Chỉ số thế (0..plies.size) cần tìm lại, tăng dần, không trùng. Thế kết thúc ván (engine = rules) bị bỏ qua. */
    fun suspectPositions(plies: List<ReplayPly>, evals: List<EngineResult>, maxPlies: Int = MAX_PLIES): List<Int> {
        if (evals.size != plies.size + 1) return emptyList()
        val scored = ArrayList<Pair<Int, Double>>()
        for (i in 1..plies.size) {
            val before = evals[i - 1]
            val after = evals[i]
            if (before.engine == MoveReview.ENGINE_RULES) continue
            if (before.bestMove == null || before.bestMove == plies[i - 1].uci) continue
            val epBefore = MoveClassifier.winProbability(before.scoreCp, before.mate)
            // Thế sau do đối thủ đi => đảo góc nhìn về bên vừa đi.
            val afterMate = after.mate?.let { m -> if (m == 0) 0 else -m }
            val epAfter = MoveClassifier.winProbability(-after.scoreCp, afterMate)
            // Liên quan mate (đi vào thế bị mate / bỏ lỡ mate) cũng đáng tìm lại sâu hơn vì sàn Lichess có thể nâng nhãn lên Blunder.
            val mateFloor = MoveClassifier.mateRuleFloor(before.mate, before.scoreCp, afterMate, -after.scoreCp)
            val loss = maxOf(epBefore - epAfter, mateFloor)
            if (loss >= SUSPECT_LOSS) scored += i to loss
        }
        return scored.sortedByDescending { it.second }
            .take(maxPlies)
            .flatMap { (i, _) -> listOf(i - 1, i) }
            .filter { evals[it].engine != MoveReview.ENGINE_RULES }
            .distinct()
            .sorted()
    }
}
