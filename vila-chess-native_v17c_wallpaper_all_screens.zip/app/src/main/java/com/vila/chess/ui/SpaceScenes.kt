package com.vila.chess.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

// =====================================================================================================
// 6 HÌNH NỀN ĐỘNG CHỦ ĐỀ VŨ TRỤ: Hố đen · Siêu tốc · Hành tinh · Tinh vân · Mưa sao băng · Hệ mặt trời
// Cách làm giống GalaxyBackground: toạ độ dựng MỘT lần trong drawWithCache, mỗi frame chỉ đọc `time`
// ở pha VẼ => không recomposition. Cảnh chậm vẽ 30 fps, cảnh nhanh (siêu tốc, sao băng) vẽ ~60 fps.
// Vòng lặp tự dừng khi app ra nền (withFrameNanos).
// =====================================================================================================

private const val TWO_PI = 6.2831855f

/** Một nhóm sao cùng cỡ/độ sáng, lấp lánh cùng nhịp. */
private class ScStarGroup(val pts: List<Offset>, val rDp: Float, val alpha: Float, val tw: Float, val phase: Float)

private fun scStars(w: Float, h: Float, seed: Int, scale: Float): List<ScStarGroup> {
    val rnd = Random(seed)
    // (số sao, bán kính dp, độ sáng, nhịp lấp lánh, pha) - mỗi cỡ có 2 nhóm lệch pha => lấp lánh tự nhiên
    val spec = listOf(
        floatArrayOf(45f, 0.6f, 0.30f, 0.9f, 0.0f), floatArrayOf(45f, 0.6f, 0.30f, 1.3f, 2.1f),
        floatArrayOf(22f, 0.95f, 0.50f, 1.1f, 0.7f), floatArrayOf(22f, 0.95f, 0.50f, 1.7f, 3.9f),
        floatArrayOf(8f, 1.4f, 0.85f, 1.5f, 1.3f), floatArrayOf(8f, 1.4f, 0.85f, 2.2f, 4.4f),
    )
    return spec.map { sp ->
        val n = (sp[0] * scale).toInt()
        ScStarGroup(List(n) { Offset(rnd.nextFloat() * w, rnd.nextFloat() * h) }, sp[1], sp[2], sp[3], sp[4])
    }
}

private fun DrawScope.scDrawStars(groups: List<ScStarGroup>, t: Float, dim: Float) {
    for (g in groups) {
        val a = g.alpha * dim * (0.72f + 0.28f * sin(t * g.tw + g.phase))
        drawPoints(g.pts, PointMode.Points, Color.White.copy(alpha = a), g.rDp * 2f * density, StrokeCap.Round)
    }
}

@Composable
private fun scRememberClock(minDeltaNanos: Long): MutableFloatState {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(minDeltaNanos) {
        val start = withFrameNanos { it }
        var last = start
        while (true) {
            withFrameNanos { now ->
                if (now - last >= minDeltaNanos) {
                    last = now
                    time.floatValue = (now - start) / 1_000_000_000f
                }
            }
        }
    }
    return time
}

/** Nền động vũ trụ: chọn cảnh theo Wallpapers.current.scene. */
@Composable
fun SceneBackground(modifier: Modifier = Modifier) {
    val scene = Wallpapers.current.scene
    val fast = scene == "warp" || scene == "meteor"
    val time = scRememberClock(if (fast) 14_000_000L else 33_000_000L)
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val wp = Wallpapers.current   // đọc state TRONG khối cache: đổi hình nền thì cache tự dựng lại
                val dens = density
                val base = Brush.verticalGradient(listOf(wp.top, wp.mid, wp.bottom))
                val painter: DrawScope.(Float) -> Unit = when (wp.scene) {
                    "blackhole" -> scBlackHole(w, h, dens)
                    "warp" -> scWarp(w, h, dens)
                    "planet" -> scPlanet(w, h, dens)
                    "meteor" -> scMeteor(w, h, dens)
                    "solar" -> scSolar(w, h, dens)
                    else -> scNebula(w, h, dens)
                }
                onDrawBehind {
                    drawRect(base)
                    painter(this, time.floatValue)
                }
            },
    )
}

// -----------------------------------------------------------------------------------------------------
// 1) HỐ ĐEN: đĩa bồi tụ nghiêng xoay (trong nhanh, ngoài chậm), vòng photon sáng, cung lệch hướng ánh sáng
// -----------------------------------------------------------------------------------------------------
private fun DrawScope.scDiskPass(
    t: Float, front: Boolean, cx: Float, cy: Float, rad: Float,
    rr: FloatArray, a0: FloatArray, om: FloatArray, band: IntArray,
    colors: List<Color>, lists: Array<ArrayList<Offset>>,
) {
    for (l in lists) l.clear()
    for (i in rr.indices) {
        val a = a0[i] + t * om[i]
        val s = sin(a)
        if ((s >= 0f) != front) continue
        val c = cos(a)
        val side = if (c > 0f) 1 else 0
        lists[band[i] * 2 + side].add(Offset(c * rr[i] * rad, s * rr[i] * rad))
    }
    withTransform({
        translate(cx, cy)
        rotate(-16f, Offset.Zero)
        scale(1f, 0.26f, Offset.Zero)
    }) {
        for (b in 0..2) for (side in 0..1) {
            val l = lists[b * 2 + side]
            if (l.isNotEmpty()) {
                // phía đang lao về phía mình sáng hơn (hiệu ứng Doppler)
                drawPoints(l, PointMode.Points, colors[b].copy(alpha = if (side == 1) 0.95f else 0.5f), 2.4f * density, StrokeCap.Round)
            }
        }
    }
}

private fun scBlackHole(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val stars = scStars(w, h, 5, 0.9f)
    val cx = w * 0.5f
    val cy = h * 0.36f
    val rad = w * 0.135f
    val rnd = Random(31)
    val n = 380
    val rr = FloatArray(n) { 1.25f + rnd.nextFloat().pow(1.3f) * 2.0f }
    val a0 = FloatArray(n) { rnd.nextFloat() * TWO_PI }
    val om = FloatArray(n) { 1.5f / (rr[it] * sqrt(rr[it])) }   // tốc độ góc ~ r^-1.5 (định luật Kepler)
    val band = IntArray(n) { if (rr[it] < 1.8f) 0 else if (rr[it] < 2.5f) 1 else 2 }
    val colors = listOf(Color(0xFFFFF0CC), Color(0xFFFFA84D), Color(0xFFE0562B))
    val lists = Array(6) { ArrayList<Offset>(n) }
    val haze = Brush.radialGradient(listOf(Color(0x99FF9A40), Color(0x44D0502A), Color.Transparent), Offset.Zero, rad * 3.6f)
    val outerGlow = Brush.radialGradient(listOf(Color(0x33FF8A3C), Color.Transparent), Offset(cx, cy), rad * 6f)
    val center = Offset(cx, cy)
    return { t ->
        scDrawStars(stars, t, 0.9f)
        drawCircle(outerGlow, rad * 6f, center)
        withTransform({
            translate(cx, cy)
            rotate(-16f, Offset.Zero)
            scale(1f, 0.26f, Offset.Zero)
        }) {
            drawCircle(haze, rad * 3.6f, Offset.Zero)
        }
        // nửa đĩa phía sau hố đen
        scDiskPass(t, false, cx, cy, rad, rr, a0, om, band, colors, lists)
        // ánh sáng bị uốn cong quanh hố đen: cung phía trên + dưới
        val flick = 0.85f + 0.15f * sin(t * 1.7f)
        withTransform({ rotate(-16f, center) }) {
            drawArc(
                color = Color(0xFFFFB866).copy(alpha = 0.55f * flick), startAngle = 195f, sweepAngle = 150f, useCenter = false,
                topLeft = Offset(cx - rad * 1.35f, cy - rad * 1.35f), size = Size(rad * 2.7f, rad * 2.7f),
                style = Stroke(rad * 0.16f, cap = StrokeCap.Round),
            )
            drawArc(
                color = Color(0xFFFF9A40).copy(alpha = 0.30f * flick), startAngle = 15f, sweepAngle = 150f, useCenter = false,
                topLeft = Offset(cx - rad * 1.28f, cy - rad * 1.28f), size = Size(rad * 2.56f, rad * 2.56f),
                style = Stroke(rad * 0.10f, cap = StrokeCap.Round),
            )
        }
        drawCircle(Color(0x55FF9A40).copy(alpha = 0.33f * flick), rad * 1.16f, center, style = Stroke(rad * 0.24f))
        drawCircle(Color.Black, rad * 1.02f, center)
        drawCircle(Color(0xFFFFE2B0).copy(alpha = flick), rad * 1.045f, center, style = Stroke(rad * 0.035f))
        // nửa đĩa phía trước (vắt ngang qua mặt hố đen)
        scDiskPass(t, true, cx, cy, rad, rr, a0, om, band, colors, lists)
    }
}

// -----------------------------------------------------------------------------------------------------
// 2) SIÊU TỐC: bay xuyên không gian - sao kéo thành vệt tỏa ra từ tâm, càng gần càng nhanh và dày
// -----------------------------------------------------------------------------------------------------
private fun scWarp(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val rnd = Random(41)
    val n = 150
    val ang = FloatArray(n) { rnd.nextFloat() * TWO_PI }
    val ph = FloatArray(n) { rnd.nextFloat() }
    val sp = FloatArray(n) { 0.22f + rnd.nextFloat() * 0.30f }
    val tone = IntArray(n) { rnd.nextInt(3) }
    val cols = listOf(Color.White, Color(0xFFBFD9FF), Color(0xFFD6C4FF))
    val cx = w * 0.5f
    val cy = h * 0.46f
    val maxR = sqrt(w * w + h * h) * 0.62f
    val core = Brush.radialGradient(listOf(Color(0x883F6BFF), Color(0x333A1F9A), Color.Transparent), Offset(cx, cy), w * 0.55f)
    val center = Offset(cx, cy)
    return { t ->
        drawCircle(core, w * 0.55f, center, alpha = 0.7f + 0.3f * sin(t * 1.3f))
        for (i in 0 until n) {
            val p = (ph[i] + t * sp[i]) % 1f
            val pt = max(0f, p - 0.05f - 0.16f * p)
            val rh = maxR * p * p
            val rt = maxR * pt * pt
            val ca = cos(ang[i])
            val sa = sin(ang[i])
            val a = min(1f, p * 3f) * 0.9f
            drawLine(
                color = cols[tone[i]].copy(alpha = a),
                start = Offset(cx + ca * rt, cy + sa * rt),
                end = Offset(cx + ca * rh, cy + sa * rh),
                strokeWidth = (0.7f + 2.2f * p) * dens,
                cap = StrokeCap.Round,
            )
        }
    }
}

// -----------------------------------------------------------------------------------------------------
// 3) HÀNH TINH: hành tinh xanh khổng lồ dưới đáy, mây quay quanh, khí quyển phát sáng, mặt trăng + vệ tinh bay ngang
// -----------------------------------------------------------------------------------------------------
private fun scPlanet(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val stars = scStars(w, h, 9, 1f)
    val rad = w * 0.9f
    val pc = Offset(w * 0.40f, h + rad * 0.30f)
    val glow = Brush.radialGradient(
        0f to Color.Transparent, 0.84f to Color.Transparent, 0.90f to Color(0x884FA8FF), 1f to Color.Transparent,
        center = pc, radius = rad * 1.14f,
    )
    val body = Brush.radialGradient(
        0f to Color(0xFF8CC4FF), 0.35f to Color(0xFF3A74CC), 0.7f to Color(0xFF10285C), 1f to Color(0xFF040918),
        center = Offset(pc.x + rad * 0.35f, pc.y - rad * 0.5f), radius = rad * 1.5f,
    )
    val rim = Brush.radialGradient(
        0f to Color.Transparent, 0.9f to Color.Transparent, 1f to Color(0x884FA8FF),
        center = pc, radius = rad,
    )
    val rnd = Random(61)
    val n = 26
    val lon0 = FloatArray(n) { rnd.nextFloat() * TWO_PI }
    val lat = FloatArray(n) { 0.3f + rnd.nextFloat() * 1.2f }
    val csz = FloatArray(n) { 0.04f + rnd.nextFloat() * 0.06f }
    val moonC = Offset(w * 0.72f, h * 0.30f)
    return { t ->
        scDrawStars(stars, t, 1f)
        // mặt trăng bay vòng elip trên nền trời
        val ma = t * (TWO_PI / 120f)
        val mr = w * (0.045f + 0.006f * sin(ma))
        val mp = Offset(moonC.x + cos(ma) * w * 0.30f, moonC.y + sin(ma) * h * 0.035f)
        drawCircle(Color(0x22FFFFFF), mr * 1.7f, mp)
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFFF4F1E8), Color(0xFFB9B6AA), Color(0xFF45465A)),
                Offset(mp.x + mr * 0.3f, mp.y - mr * 0.3f), mr * 1.7f,
            ),
            mr, mp,
        )
        drawCircle(Color(0x1F000010), mr * 0.22f, Offset(mp.x - mr * 0.30f, mp.y + mr * 0.10f))
        drawCircle(Color(0x1F000010), mr * 0.15f, Offset(mp.x + mr * 0.25f, mp.y + mr * 0.40f))
        drawCircle(Color(0x1F000010), mr * 0.12f, Offset(mp.x + mr * 0.10f, mp.y - mr * 0.35f))

        // vệ tinh nhân tạo: chấm nhỏ nhấp nháy bay ngang mỗi 40 giây
        val sp = (t % 40f) / 40f
        drawCircle(
            Color.White.copy(alpha = 0.55f + 0.4f * sin(t * 6f)),
            1.7f * dens,
            Offset(w * (1.1f - 1.2f * sp), h * 0.13f + h * 0.02f * sin(sp * 3.1415927f)),
        )

        // hành tinh
        drawCircle(glow, rad * 1.14f, pc)
        drawCircle(body, rad, pc)
        for (i in 0 until n) {
            val lon = lon0[i] + t * 0.02f
            val z = cos(lat[i]) * cos(lon)
            if (z > 0.08f) {
                val x = pc.x + rad * cos(lat[i]) * sin(lon)
                val y = pc.y - rad * sin(lat[i])
                val r = rad * csz[i] * (0.4f + 0.6f * z)
                val al = 0.07f + 0.10f * z
                drawCircle(Color.White.copy(alpha = al), r, Offset(x, y))
                drawCircle(Color.White.copy(alpha = al), r * 0.8f, Offset(x + r * 1.1f, y + r * 0.1f))
            }
        }
        drawCircle(rim, rad, pc)
    }
}

// -----------------------------------------------------------------------------------------------------
// 4) TINH VÂN: các đám mây màu trôi và "thở", cộng sáng chồng lên nhau, vài ngôi sao sáng lóe tia
// -----------------------------------------------------------------------------------------------------
private class ScBlob(val fx: Float, val fy: Float, val rad: Float, val color: Color, val amp: Float, val spd: Float, val ph: Float)

private fun scNebula(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val stars = scStars(w, h, 13, 1.1f)
    val blobs = listOf(
        ScBlob(0.25f, 0.22f, 0.75f, Color(0xFFE0409A), 0.06f, 0.11f, 0.0f),
        ScBlob(0.78f, 0.30f, 0.70f, Color(0xFF30C0E8), 0.07f, 0.09f, 1.7f),
        ScBlob(0.50f, 0.52f, 0.80f, Color(0xFF7A4DFF), 0.05f, 0.07f, 3.1f),
        ScBlob(0.20f, 0.74f, 0.65f, Color(0xFF2F5BFF), 0.07f, 0.10f, 4.4f),
        ScBlob(0.82f, 0.80f, 0.70f, Color(0xFFFF7A5C), 0.06f, 0.08f, 5.6f),
        ScBlob(0.55f, 0.12f, 0.55f, Color(0xFFB04FD0), 0.05f, 0.12f, 2.4f),
    )
    val brushes = blobs.map { b ->
        Brush.radialGradient(
            listOf(b.color.copy(alpha = 0.42f), b.color.copy(alpha = 0.14f), Color.Transparent),
            Offset.Zero, w * b.rad * 0.7f,
        )
    }
    val flares = listOf(
        Offset(w * 0.22f, h * 0.30f), Offset(w * 0.72f, h * 0.18f), Offset(w * 0.60f, h * 0.62f),
        Offset(w * 0.12f, h * 0.80f), Offset(w * 0.88f, h * 0.70f),
    )
    return { t ->
        scDrawStars(stars, t, 1f)
        for (i in blobs.indices) {
            val b = blobs[i]
            val x = w * (b.fx + b.amp * sin(t * b.spd + b.ph))
            val y = h * (b.fy + b.amp * 0.7f * cos(t * b.spd * 0.8f + b.ph))
            val a = 0.55f + 0.25f * sin(t * b.spd * 1.6f + b.ph * 1.3f)
            translate(left = x, top = y) {
                drawCircle(brushes[i], w * b.rad * 0.7f, Offset.Zero, alpha = a, blendMode = BlendMode.Plus)
            }
        }
        for (i in flares.indices) {
            val c = flares[i]
            val pulse = 0.5f + 0.5f * sin(t * 0.9f + i * 1.7f)
            val len = (8f + 14f * pulse) * dens
            val col = Color.White.copy(alpha = 0.25f + 0.35f * pulse)
            drawLine(col, Offset(c.x - len, c.y), Offset(c.x + len, c.y), 1f * dens, StrokeCap.Round)
            drawLine(col, Offset(c.x, c.y - len), Offset(c.x, c.y + len), 1f * dens, StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = 0.9f), 1.6f * dens, c)
        }
    }
}

// -----------------------------------------------------------------------------------------------------
// 5) MƯA SAO BĂNG: nhiều sao băng rơi chéo lệch nhịp, đuôi sáng mờ dần, trăng mờ ở góc
// -----------------------------------------------------------------------------------------------------
private fun scMeteor(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val stars = scStars(w, h, 17, 1.2f)
    val m = 10
    val rnd = Random(51)
    val period = FloatArray(m) { 3.2f + rnd.nextFloat() * 4.5f }
    val off = FloatArray(m) { rnd.nextFloat() * 8f }
    val dur = FloatArray(m) { 0.9f + rnd.nextFloat() * 0.8f }
    val ang = FloatArray(m) { (24f + rnd.nextFloat() * 18f) * 0.017453292f }
    val seedA = FloatArray(m) { rnd.nextFloat() }
    val seedB = FloatArray(m) { rnd.nextFloat() }
    val len = FloatArray(m) { w * (0.22f + rnd.nextFloat() * 0.22f) }
    val wid = FloatArray(m) { 1.2f + rnd.nextFloat() * 1.4f }
    val moonC = Offset(w * 0.82f, h * 0.14f)
    val moonGlow = Brush.radialGradient(listOf(Color(0x33BBD4FF), Color.Transparent), moonC, w * 0.5f)
    return { t ->
        scDrawStars(stars, t, 1f)
        drawCircle(moonGlow, w * 0.5f, moonC)
        drawCircle(Color(0xCCEAF1FF), w * 0.028f, moonC)
        for (i in 0 until m) {
            val tt = t + off[i]
            val k = floor(tt / period[i])
            val local = tt - k * period[i]
            if (local < dur[i]) {
                val p = local / dur[i]
                // vị trí xuất phát lấy từ số thứ tự chu kỳ (số vàng) - không cấp phát/ngẫu nhiên mỗi frame
                val sx = ((k * 0.6180339f + seedA[i]) % 1f) * w * 1.25f
                val sy = ((k * 0.3819660f + seedB[i]) % 1f) * h * 0.45f - h * 0.05f
                val dx = -cos(ang[i])
                val dy = sin(ang[i])
                val travel = h * 0.6f
                val head = Offset(sx + dx * travel * p, sy + dy * travel * p)
                val tail = Offset(head.x - dx * len[i], head.y - dy * len[i])
                val fade = sin(p * PI.toFloat())
                drawLine(
                    brush = Brush.linearGradient(
                        listOf(Color.Transparent, Color(0xFFCFE4FF).copy(alpha = 0.95f * fade)),
                        start = tail, end = head,
                    ),
                    start = tail, end = head, strokeWidth = wid[i] * dens, cap = StrokeCap.Round,
                )
                drawCircle(Color.White.copy(alpha = fade), wid[i] * 1.3f * dens, head)
            }
        }
    }
}

// -----------------------------------------------------------------------------------------------------
// 6) HỆ MẶT TRỜI: mặt trời đập nhẹ, 6 hành tinh quay quanh (xa chậm, gần nhanh), vành đai thiên thạch, sao Thổ có vành
// -----------------------------------------------------------------------------------------------------
private fun DrawScope.scDrawPlanet(pos: Offset, r: Float, base: Color, hi: Color, lo: Color) {
    drawCircle(
        Brush.radialGradient(listOf(hi, base, lo), Offset(pos.x + r * 0.3f, pos.y - r * 0.3f), r * 1.7f),
        r, pos,
    )
}

private fun scSolar(w: Float, h: Float, dens: Float): DrawScope.(Float) -> Unit {
    val stars = scStars(w, h, 23, 1f)
    val cx = w * 0.5f
    val cy = h * 0.38f
    val tilt = 0.40f
    val orbit = floatArrayOf(0.13f, 0.21f, 0.30f, 0.41f, 0.53f, 0.66f)
    val period = floatArrayOf(14f, 23f, 34f, 52f, 78f, 115f)
    val psize = floatArrayOf(3.2f, 4.6f, 5.0f, 4.0f, 8.5f, 7.0f)
    val phase0 = floatArrayOf(0.5f, 2.2f, 4.1f, 1.0f, 3.3f, 5.6f)
    val base = listOf(
        Color(0xFFC8B8A0), Color(0xFFE8C07A), Color(0xFF4F8FEA),
        Color(0xFFD9694A), Color(0xFFE6C98F), Color(0xFF8FD0E0),
    )
    val hi = base.map { lerp(it, Color.White, 0.5f) }
    val lo = base.map { lerp(it, Color.Black, 0.65f) }
    val sunBrush = Brush.radialGradient(
        listOf(Color(0xFFFFF3C8), Color(0xFFFFC555), Color(0x66FF8A2A), Color.Transparent), Offset.Zero, w * 0.2f,
    )
    val corona = Brush.radialGradient(listOf(Color(0x44FFB050), Color.Transparent), Offset.Zero, w * 0.5f)
    val rnd = Random(71)
    val belt = List(90) {
        val a = rnd.nextFloat() * TWO_PI
        val r = w * (0.355f + (rnd.nextFloat() - 0.5f) * 0.04f)
        Offset(cos(a) * r, sin(a) * r)
    }
    return { t ->
        scDrawStars(stars, t, 0.9f)
        // quỹ đạo + vành đai thiên thạch (xoay trong mặt phẳng quỹ đạo rồi mới ép dẹt)
        withTransform({
            translate(cx, cy)
            scale(1f, tilt, Offset.Zero)
        }) {
            for (i in orbit.indices) {
                drawCircle(Color(0x22FFFFFF), w * orbit[i], Offset.Zero, style = Stroke(1.1f * dens))
            }
            withTransform({ rotate(t * 1.5f, Offset.Zero) }) {
                drawPoints(belt, PointMode.Points, Color(0x88C8B8A0), 1.3f * dens, StrokeCap.Round)
            }
        }
        // hành tinh phía xa (sau mặt trời)
        for (i in orbit.indices) {
            val a = phase0[i] + TWO_PI * t / period[i]
            if (sin(a) < 0f) {
                scDrawPlanet(Offset(cx + cos(a) * w * orbit[i], cy + sin(a) * w * orbit[i] * tilt), psize[i] * dens, base[i], hi[i], lo[i])
            }
        }
        // mặt trời
        translate(left = cx, top = cy) {
            drawCircle(corona, w * 0.5f, Offset.Zero, alpha = 0.7f + 0.3f * sin(t * 0.8f))
            val s = 1f + 0.04f * sin(t * 1.7f)
            drawCircle(sunBrush, w * 0.2f * s, Offset.Zero)
        }
        // hành tinh phía gần (trước mặt trời)
        for (i in orbit.indices) {
            val a = phase0[i] + TWO_PI * t / period[i]
            if (sin(a) >= 0f) {
                val pos = Offset(cx + cos(a) * w * orbit[i], cy + sin(a) * w * orbit[i] * tilt)
                val r = psize[i] * dens
                scDrawPlanet(pos, r, base[i], hi[i], lo[i])
                if (i == 4) {   // sao Thổ: vành nghiêng
                    withTransform({ rotate(-18f, pos) }) {
                        drawOval(
                            color = Color(0xAAE8D49A),
                            topLeft = Offset(pos.x - r * 2.1f, pos.y - r * 0.6f),
                            size = Size(r * 4.2f, r * 1.2f),
                            style = Stroke(1.6f * dens),
                        )
                    }
                }
                if (i == 2) {   // Trái Đất có mặt trăng
                    val ma = t * 2.4f
                    drawCircle(Color(0xFFCFCFD8), 1.8f * dens, Offset(pos.x + cos(ma) * r * 2.4f, pos.y + sin(ma) * r))
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------------------
// Ảnh xem trước (tĩnh) cho ô trong tab "Hình nền" - gọi trong Canvas của ThemeScreen
// -----------------------------------------------------------------------------------------------------
internal fun DrawScope.drawWallpaperPreview(scene: String) {
    val w = size.width
    val h = size.height
    when (scene) {
        "blackhole" -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            withTransform({
                translate(c.x, c.y)
                rotate(-16f, Offset.Zero)
                scale(1f, 0.3f, Offset.Zero)
            }) {
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFFFFB060), Color(0x66E0562B), Color.Transparent), Offset.Zero, w * 0.5f),
                    w * 0.5f, Offset.Zero,
                )
            }
            drawCircle(Color.Black, w * 0.17f, c)
            drawCircle(Color(0xFFFFE2B0), w * 0.18f, c, style = Stroke(w * 0.025f))
        }
        "warp" -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            drawCircle(Brush.radialGradient(listOf(Color(0x883F6BFF), Color.Transparent), c, w * 0.6f), w * 0.6f, c)
            for (i in 0 until 16) {
                val a = i * 0.3927f + 0.2f
                val dx = cos(a)
                val dy = sin(a)
                val far = w * (0.28f + 0.14f * (i % 3))
                drawLine(
                    Color.White.copy(alpha = 0.8f),
                    Offset(c.x + dx * w * 0.10f, c.y + dy * w * 0.10f),
                    Offset(c.x + dx * far, c.y + dy * far),
                    w * 0.012f, StrokeCap.Round,
                )
            }
        }
        "planet" -> {
            val r = w * 0.85f
            val pc = Offset(w * 0.4f, h * 1.25f)
            drawCircle(
                Brush.radialGradient(
                    0f to Color(0xFF8CC4FF), 0.4f to Color(0xFF3A74CC), 1f to Color(0xFF040918),
                    center = Offset(pc.x + r * 0.3f, pc.y - r * 0.5f), radius = r * 1.4f,
                ),
                r, pc,
            )
            drawCircle(Color(0xAACFE4FF), w * 0.07f, Offset(w * 0.75f, h * 0.22f))
        }
        "nebula" -> {
            val cols = listOf(Color(0xFFE0409A), Color(0xFF30C0E8), Color(0xFF7A4DFF))
            val xs = floatArrayOf(0.3f, 0.7f, 0.5f)
            val ys = floatArrayOf(0.3f, 0.35f, 0.7f)
            for (i in 0..2) {
                val c = Offset(w * xs[i], h * ys[i])
                drawCircle(
                    Brush.radialGradient(listOf(cols[i].copy(alpha = 0.7f), Color.Transparent), c, w * 0.55f),
                    w * 0.55f, c, blendMode = BlendMode.Plus,
                )
            }
        }
        "meteor" -> {
            for (i in 0..2) {
                val head = Offset(w * (0.55f - 0.2f * i), h * (0.45f + 0.2f * i))
                val tail = Offset(head.x + w * 0.4f, head.y - w * 0.28f)
                drawLine(
                    brush = Brush.linearGradient(listOf(Color.Transparent, Color.White), start = tail, end = head),
                    start = tail, end = head, strokeWidth = w * 0.02f, cap = StrokeCap.Round,
                )
            }
        }
        "solar" -> {
            val c = Offset(w * 0.5f, h * 0.5f)
            for (r in floatArrayOf(0.22f, 0.36f, 0.5f)) {
                drawCircle(Color(0x44FFFFFF), w * r, c, style = Stroke(w * 0.008f))
            }
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF3C8), Color(0xFFFFB040), Color.Transparent), c, w * 0.2f), w * 0.2f, c)
            drawCircle(Color(0xFF4F8FEA), w * 0.03f, Offset(w * 0.5f + w * 0.22f, h * 0.5f))
            drawCircle(Color(0xFFD9694A), w * 0.025f, Offset(w * 0.5f - w * 0.36f * 0.7f, h * 0.5f - w * 0.36f * 0.7f))
        }
    }
}
