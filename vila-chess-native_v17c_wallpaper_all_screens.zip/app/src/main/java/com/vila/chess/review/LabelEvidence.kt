package com.vila.chess.review

import kotlin.math.max
import kotlin.math.min

/**
 * LỚP "ĐỘ TIN CẬY DỮ LIỆU" của bộ phân loại nhãn (thiết kế riêng của ViLa Chess, đứng trên [MoveClassifier]).
 *
 * Ý tưởng: nhãn cùng một mức mất xác suất thắng chỉ đáng tin khi engine đã tìm ĐỦ SÂU ở cả hai thế (trước và sau nước đi).
 * Máy yếu / WASM / hết thời gian chỉ chạy tới độ sâu nông thì điểm số dao động mạnh, nhãn "nặng" (Blunder, Mistake, Miss) và
 * nhãn "chói" (Brilliant, Great) rất dễ sai. Khi dữ liệu còn nông, lớp này HẠ MỘT BẬC những nhãn đó thay vì phán quyết sai:
 *   Brilliant → Great → Best      Blunder → Mistake → Inaccuracy      Miss → Inaccuracy
 *
 * Không đụng tới:
 *  - nhãn Sách khai cuộc, Best / Excellent / Good (không cần "phán quyết nặng");
 *  - các thế có MATE trong điểm (điểm mate là điểm đã chứng minh, không phụ thuộc độ sâu) hoặc nhãn do "sàn mate" quyết định;
 *  - nước có độ sâu = 0 (thế kết thúc do luật: chiếu hết / hòa — chính xác tuyệt đối).
 *
 * Độ tin cậy 0.2..1.0: ≥ [SOLID_DEPTH] → 1.0 (tin hoàn toàn); [FLOOR_DEPTH] hoặc nông hơn → 0.2. Dưới [SHAKY_BELOW] là "nông".
 * Với [SOLID_DEPTH] = 14, [FLOOR_DEPTH] = 4, [SHAKY_BELOW] = 0.6: độ sâu ≥ 10 giữ nguyên nhãn; ≤ 9 bị hạ bậc.
 */
object LabelEvidence {
    const val SOLID_DEPTH = 14
    const val FLOOR_DEPTH = 4
    const val SHAKY_BELOW = 0.6
    const val VERY_SHAKY_BELOW = 0.35

    /** Độ tin cậy của MỘT độ sâu. depth <= 0 nghĩa là "thế do luật quyết định / không có độ sâu" → tin hoàn toàn. */
    fun depthConfidence(depth: Int): Double {
        if (depth <= 0) return 1.0
        val raw = (depth - FLOOR_DEPTH).toDouble() / (SOLID_DEPTH - FLOOR_DEPTH).toDouble()
        return max(0.2, min(1.0, raw))
    }

    /** Độ tin cậy của một nước đi: lấy phía kém hơn trong hai lần tìm kiếm (thế trước và thế sau). */
    fun confidence(depthBefore: Int, depthAfter: Int): Double =
        min(depthConfidence(depthBefore), depthConfidence(depthAfter))

    /** Hạ nhãn theo mức nông. Chỉ dùng cho nhãn "chói" và nhãn "nặng". */
    fun soften(label: MoveLabel, veryShaky: Boolean): MoveLabel = when (label) {
        MoveLabel.BRILLIANT -> MoveLabel.GREAT
        MoveLabel.GREAT -> MoveLabel.BEST
        MoveLabel.BLUNDER -> if (veryShaky) MoveLabel.INACCURACY else MoveLabel.MISTAKE
        MoveLabel.MISTAKE -> MoveLabel.INACCURACY
        MoveLabel.MISS -> MoveLabel.INACCURACY
        else -> label
    }

    /**
     * Nhãn cuối cùng sau khi xét độ tin cậy.
     * [decidedByMate] = true khi thế có mate trong điểm hoặc nhãn do sàn mate quyết định → giữ nguyên.
     */
    fun settle(label: MoveLabel, depthBefore: Int, depthAfter: Int, decidedByMate: Boolean): MoveLabel {
        if (decidedByMate) return label
        val c = confidence(depthBefore, depthAfter)
        if (c >= SHAKY_BELOW) return label
        return soften(label, c < VERY_SHAKY_BELOW)
    }

    /**
     * Elo ước tính của ván theo độ chính xác (0..100), nội suy tuyến tính giữa các mốc. Chỉ là con số tham khảo vui,
     * không phải Elo thật (không dùng để cộng/trừ điểm).
     */
    fun estimateGameElo(accuracy: Double): Int {
        val pts = ACCURACY_TO_ELO
        val a = accuracy.coerceIn(0.0, 100.0)
        for (i in 1 until pts.size) {
            if (a <= pts[i].first) {
                val (x0, y0) = pts[i - 1]
                val (x1, y1) = pts[i]
                val t = if (x1 == x0) 0.0 else (a - x0) / (x1 - x0)
                return (y0 + (y1 - y0) * t + 0.5).toInt()
            }
        }
        return pts.last().second.toInt()
    }

    private val ACCURACY_TO_ELO: List<Pair<Double, Double>> = listOf(
        0.0 to 250.0, 30.0 to 400.0, 50.0 to 700.0, 65.0 to 1000.0, 75.0 to 1300.0,
        82.0 to 1600.0, 88.0 to 1900.0, 93.0 to 2200.0, 97.0 to 2500.0, 100.0 to 2800.0,
    )
}
