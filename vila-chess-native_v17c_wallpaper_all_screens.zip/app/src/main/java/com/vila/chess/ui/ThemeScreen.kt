package com.vila.chess.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.SoundPacks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val TabDim = Color(0xFFB9C1CE)
private val SubDim = Color(0xFF8E9BB0)
private val TabLine = Color(0x66B9C1CE)
private val TileShape = RoundedCornerShape(8.dp)

/** Thế cờ bắt đầu, đọc từ trên (hàng 8) xuống dưới (hàng 1). Mã quân: 1..6 trắng P N B R Q K, 9..14 đen. */
private val START_POSITION: IntArray = IntArray(64).also { a ->
    val back = intArrayOf(4, 2, 3, 5, 6, 3, 2, 4)
    for (c in 0 until 8) {
        a[c] = back[c] + 8
        a[8 + c] = 9
        a[48 + c] = 1
        a[56 + c] = back[c]
    }
}

/**
 * Trang "Chủ đề" (tách riêng khỏi Tài khoản và Các tùy chỉnh): bàn cờ xem trước ở trên, 4 tab bên dưới
 * - Bàn cờ · Quân cờ · Hình nền · Âm thanh - mỗi tab là một lưới/danh sách chọn. Chạm là áp dụng ngay.
 */
@Composable
fun ThemeScreen(vm: GameViewModel, onBack: () -> Unit) {
    val titles = remember { listOf("Bàn cờ", "Quân cờ", "Hình nền", "Âm thanh") }
    val pager = rememberPagerState(pageCount = { titles.size })
    val scope = rememberCoroutineScope()
    val cfg = LocalConfiguration.current
    val boardSide = minOf((cfg.screenWidthDp - 24).dp, (cfg.screenHeightDp * 0.40f).dp)

    val subtitle = when (pager.currentPage) {
        0 -> BoardThemes.byId(vm.boardThemeId).label
        1 -> PieceSets.get(vm.pieceSet).label
        2 -> Wallpapers.byId(vm.wallpaperId).label
        else -> SoundPacks.all.firstOrNull { it.id == vm.soundPack }?.label ?: ""
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(60.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = TabDim)
            }
            Text(
                "Chủ đề", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                maxLines = 1, modifier = Modifier.align(Alignment.Center),
            )
        }
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            PreviewBoard(images = vm.pieceImages, side = boardSide)
        }
        Box(Modifier.height(10.dp))
        ThemeTabs(titles, pager) { i -> scope.launch { pager.animateScrollToPage(i) } }
        Text(
            subtitle, color = SubDim, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        )
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth(), key = { it }) { page ->
            when (page) {
                0 -> BoardTab(vm)
                1 -> PieceTab(vm)
                2 -> WallpaperTab(vm)
                else -> SoundTab(vm)
            }
        }
    }
}

// =============================================================================
// Bàn cờ xem trước + thanh tab
// =============================================================================

/** Bàn cờ thế bắt đầu, vẽ bằng một Canvas, đổi màu/bộ quân là đổi ngay. */
@Composable
private fun PreviewBoard(images: Array<ImageBitmap?>, side: Dp) {
    val light = VilaColors.BoardLight
    val dark = VilaColors.BoardDark
    Canvas(Modifier.size(side)) {
        val cell = size.width / 8f
        val px = cell.roundToInt()
        for (r in 0 until 8) for (c in 0 until 8) {
            drawRect(
                color = if ((r + c) % 2 == 0) light else dark,
                topLeft = Offset(c * cell, r * cell),
                size = Size(cell + 0.5f, cell + 0.5f),
            )
            val img = images.getOrNull(START_POSITION[r * 8 + c]) ?: continue
            drawImage(
                image = img,
                dstOffset = IntOffset((c * cell).roundToInt(), (r * cell).roundToInt()),
                dstSize = IntSize(px, px),
                filterQuality = FilterQuality.High,
            )
        }
    }
}

/** 4 tab chữ + đường kẻ mảnh, vạch sáng trượt theo ngón vuốt giữa các trang. */
@Composable
private fun ThemeTabs(titles: List<String>, pager: PagerState, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth()) {
            titles.forEachIndexed { i, t ->
                val sel = pager.currentPage == i
                Box(
                    Modifier.weight(1f).height(48.dp).clickable(
                        interactionSource = remember { MutableInteractionSource() }, indication = null,
                    ) { onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        t, color = if (sel) Color.White else TabDim, fontSize = 16.sp,
                        fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                    )
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(3.dp)) {
            Box(Modifier.fillMaxWidth().height(1.dp).align(Alignment.Center).background(TabLine))
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val tabW = maxWidth / titles.size
                val pos = pager.currentPage + pager.currentPageOffsetFraction
                Box(
                    Modifier.offset(x = tabW * pos).width(tabW).fillMaxHeight()
                        .clip(RoundedCornerShape(2.dp)).background(TabDim),
                )
            }
        }
    }
}

// =============================================================================
// Các tab
// =============================================================================

private val GridPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp)
private val GridGap = Arrangement.spacedBy(12.dp)

@Composable
private fun BoardTab(vm: GameViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(5), contentPadding = GridPadding,
        horizontalArrangement = GridGap, verticalArrangement = GridGap, modifier = Modifier.fillMaxSize(),
    ) {
        items(BoardThemes.all, key = { it.id }) { t ->
            ThemeTile(selected = t.id == vm.boardThemeId, label = t.label, onClick = { vm.updateBoardTheme(t.id) }) {
                Canvas(Modifier.fillMaxSize()) {
                    val h = size.width / 2f
                    val s = Size(h + 0.5f, h + 0.5f)
                    drawRect(t.light, Offset(0f, 0f), s)
                    drawRect(t.dark, Offset(h, 0f), s)
                    drawRect(t.dark, Offset(0f, h), s)
                    drawRect(t.light, Offset(h, h), s)
                }
            }
        }
    }
}

@Composable
private fun PieceTab(vm: GameViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(5), contentPadding = GridPadding,
        horizontalArrangement = GridGap, verticalArrangement = GridGap, modifier = Modifier.fillMaxSize(),
    ) {
        items(PieceSets.all, key = { it.id }) { info ->
            ThemeTile(selected = info.id == vm.pieceSet, label = info.label, onClick = { vm.updatePieceSet(info.id) }) {
                PieceTileFace(info.id)
            }
        }
    }
}

/** Mặt ô bộ quân: bàn 2x2 theo màu bàn đang chọn, mã nặng (giải mã ảnh) chạy nền để lưới cuộn mượt. */
@Composable
private fun PieceTileFace(setId: String) {
    val ctx = LocalContext.current
    val pair by produceState(Pair<ImageBitmap?, ImageBitmap?>(null, null), setId) {
        value = withContext(Dispatchers.Default) { loadPiecePair(ctx, setId) }
    }
    val light = VilaColors.BoardLight
    val dark = VilaColors.BoardDark
    val white = pair.first
    val black = pair.second
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.weight(1f)) {
            PieceCell(light, black, Modifier.weight(1f))
            PieceCell(dark, white, Modifier.weight(1f))
        }
        Row(Modifier.weight(1f)) {
            PieceCell(dark, white, Modifier.weight(1f))
            PieceCell(light, black, Modifier.weight(1f))
        }
    }
}

@Composable
private fun PieceCell(bg: Color, img: ImageBitmap?, modifier: Modifier) {
    Box(modifier.fillMaxHeight().background(bg), contentAlignment = Alignment.Center) {
        if (img != null) Image(bitmap = img, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
    }
}

@Composable
private fun WallpaperTab(vm: GameViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(5), contentPadding = GridPadding,
        horizontalArrangement = GridGap, verticalArrangement = GridGap, modifier = Modifier.fillMaxSize(),
    ) {
        items(Wallpapers.all, key = { it.id }) { w ->
            ThemeTile(selected = w.id == vm.wallpaperId, label = w.label, onClick = { vm.updateWallpaper(w.id) }) {
                Canvas(Modifier.fillMaxSize()) {
                    drawRect(Brush.verticalGradient(listOf(w.top, w.mid, w.bottom)))
                    drawRect(Brush.radialGradient(listOf(w.glowA, Color.Transparent), Offset(size.width * 0.9f, size.height * 0.9f), size.width * 0.9f))
                    drawRect(Brush.radialGradient(listOf(w.glowB, Color.Transparent), Offset(size.width * 0.1f, size.height * 0.4f), size.width * 0.7f))
                    if (w.scene.isNotEmpty()) {
                        drawWallpaperPreview(w.scene)
                    } else if (w.animated) {   // xem trước: đĩa thiên hà nghiêng + lõi sáng
                        withTransform({ translate(size.width * 0.6f, size.height * 0.4f); rotate(-22f, Offset.Zero); scale(1f, 0.5f, Offset.Zero) }) {
                            val r = size.width * 0.6f
                            drawCircle(Brush.radialGradient(listOf(Color(0xCCFFE9B8), Color(0x66B07AFF), Color.Transparent), Offset.Zero, r), r, Offset.Zero)
                        }
                    }
                    if (w.stars) {
                        val dot = size.width * 0.03f
                        for ((fx, fy) in STAR_SPOTS) drawCircle(Color.White.copy(alpha = 0.7f), dot, Offset(size.width * fx, size.height * fy))
                    }
                }
            }
        }
    }
}

private val STAR_SPOTS = listOf(0.2f to 0.18f, 0.62f to 0.12f, 0.82f to 0.4f, 0.34f to 0.55f, 0.12f to 0.78f, 0.7f to 0.7f, 0.5f to 0.34f)

@Composable
private fun SoundTab(vm: GameViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        if (!vm.soundOn) {
            item(key = "muted") {
                Text(
                    "Âm thanh đang tắt. Bật lại ở Các tùy chỉnh để nghe bộ âm thanh.",
                    color = SubDim, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                )
            }
        }
        items(SoundPacks.all, key = { it.id }) { info ->
            val selected = info.id == vm.soundPack
            val shape = RoundedCornerShape(12.dp)
            Row(
                Modifier.fillMaxWidth().glass(shape)
                    .then(if (selected) Modifier.border(2.dp, VilaColors.Green, shape) else Modifier)
                    .clickable { vm.updateSoundPack(info.id) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(info.label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(info.desc, color = VilaColors.TextDim, fontSize = 13.sp)
                }
                if (selected) CheckBadge(22.dp) else PlayGlyph(22.dp)
            }
        }
    }
}

// =============================================================================
// Ô chọn dùng chung + biểu tượng vẽ tay (không emoji/ký tự hệ thống)
// =============================================================================

/** Ô vuông bo góc như trong ảnh mẫu; ô đang chọn có viền trắng dày và dấu tích xanh ở góc. */
@Composable
private fun ThemeTile(selected: Boolean, label: String, onClick: () -> Unit, face: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color(0x33FFFFFF), TileShape)
            .clip(TileShape)
            .clickable(onClickLabel = label, onClick = onClick),
    ) {
        face()
        if (selected) CheckBadge(18.dp, Modifier.align(Alignment.BottomEnd).padding(3.dp))
    }
}

@Composable
private fun CheckBadge(diameter: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(diameter).clip(CircleShape).background(VilaColors.Green)) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * 0.26f, w * 0.52f); lineTo(w * 0.44f, w * 0.68f); lineTo(w * 0.76f, w * 0.34f)
        }
        drawPath(p, Color.White, style = Stroke(width = w * 0.13f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun PlayGlyph(diameter: Dp) {
    Canvas(Modifier.size(diameter)) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * 0.28f, w * 0.18f); lineTo(w * 0.28f, w * 0.82f); lineTo(w * 0.84f, w * 0.5f); close()
        }
        drawPath(p, VilaColors.TextDim)
    }
}
