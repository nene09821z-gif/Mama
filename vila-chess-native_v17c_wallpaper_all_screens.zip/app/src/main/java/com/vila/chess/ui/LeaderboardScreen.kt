package com.vila.chess.ui

import android.app.Application
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.profile.BoardScope
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.Leaderboard
import com.vila.chess.profile.LeaderboardEntry
import com.vila.chess.profile.LeaderboardRepository
import com.vila.chess.profile.MyRank
import com.vila.chess.profile.ProfileException
import com.vila.chess.profile.message
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Tải + giữ bảng xếp hạng. Mỗi (phạm vi, thể loại) được nhớ trong bộ nhớ nên chuyển tab là hiện ngay, rồi làm mới nền. */
class LeaderboardViewModel(private val app: Application) : AndroidViewModel(app) {
    var mode by mutableStateOf(EloMode.BLITZ)
        private set
    var scope by mutableStateOf(BoardScope.GLOBAL)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var entries by mutableStateOf(listOf<LeaderboardEntry>())
        private set
    var myRank by mutableStateOf<MyRank?>(null)
        private set
    var myId by mutableStateOf<String?>(null)
        private set

    private val cache = HashMap<String, List<LeaderboardEntry>>()
    private var job: Job? = null

    fun pickMode(m: EloMode) {
        if (m == mode) return
        mode = m
        load()
    }

    fun pickScope(s: BoardScope) {
        if (s == scope) return
        scope = s
        load()
    }

    fun load(force: Boolean = false) {
        val key = scope.name + ":" + mode.key
        val cached = cache[key]
        entries = cached ?: emptyList()
        if (cached != null && !force) error = null
        job?.cancel()
        loading = true
        if (cached == null) error = null
        val sc = scope
        val md = mode
        job = viewModelScope.launch {
            myId = SupabaseCloud.userId(app)
            val result = if (sc == BoardScope.GLOBAL) {
                LeaderboardRepository.fetchTop(app, md).map { Leaderboard.rank(it, md) }
            } else {
                LeaderboardRepository.fetchFriendsBoard(app).map { Leaderboard.rank(it, md) }
            }
            if (!isActive) return@launch
            val list = result.getOrNull()
            if (list != null) {
                cache[key] = list
                entries = list
                error = null
            } else {
                val kind = (result.exceptionOrNull() as? ProfileException)?.kind
                error = kind?.message() ?: "Không tải được bảng xếp hạng. Thử lại sau."
            }
            myRank = if (sc == BoardScope.GLOBAL && list != null) LeaderboardRepository.fetchMyRank(app, md).getOrNull() else null
            if (!isActive) return@launch
            loading = false
        }
    }
}

private val RANK_GOLD = Color(0xFFF2B134)
private val RANK_SILVER = Color(0xFFC9D1DC)
private val RANK_BRONZE = Color(0xFFD08A4E)

private fun medalColor(rank: Int): Color = when (rank) {
    1 -> RANK_GOLD
    2 -> RANK_SILVER
    3 -> RANK_BRONZE
    else -> Color(0xFF8C8A85)
}

/** Bảng xếp hạng Elo: podium top 3, danh sách bên dưới, thẻ "Hạng của bạn" ghim đáy. */
@Composable
fun LeaderboardScreen(onBack: () -> Unit) {
    val vm: LeaderboardViewModel = viewModel()
    LaunchedEffect(Unit) { vm.load() }

    val entries = vm.entries
    val mine = Leaderboard.find(entries, vm.myId)

    Column(Modifier.fillMaxSize().background(VilaColors.Bg).statusBarsPadding().navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE))
            }
            Text("🏆 Bảng xếp hạng", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
            Text(
                "Làm mới", color = VilaColors.Green, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterEnd).clickable { vm.load(force = true) }.padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }

        SlidingTabs(
            labels = EloMode.values().map { it.title },
            selected = vm.mode.ordinal,
            modifier = Modifier.padding(horizontal = 12.dp),
        ) { vm.pickMode(EloMode.values()[it]) }
        Spacer(Modifier.height(8.dp))
        SlidingTabs(
            labels = BoardScope.values().map { it.title },
            selected = vm.scope.ordinal,
            height = 38.dp,
            modifier = Modifier.padding(horizontal = 12.dp),
        ) { vm.pickScope(BoardScope.values()[it]) }
        Text(
            vm.mode.subtitle + " · " + (if (vm.scope == BoardScope.GLOBAL) "Top ${Leaderboard.PAGE} người chơi" else "Bạn và bạn bè"),
            color = VilaColors.TextDim, fontSize = 12.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp),
        )

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                entries.isEmpty() && vm.loading -> Skeleton()
                entries.isEmpty() && vm.error != null -> StateCard("😕", vm.error ?: "", "Thử lại") { vm.load(force = true) }
                entries.isEmpty() -> StateCard(
                    "🏁",
                    if (vm.scope == BoardScope.FRIENDS) "Chưa có bạn bè nào trên bảng. Hãy kết bạn rồi cùng chơi nhé!"
                    else "Chưa có ai trên bảng này. Chơi một ván online để lên bảng!",
                    "Tải lại",
                ) { vm.load(force = true) }
                else -> {
                    val podium = entries.filter { it.rank <= 3 }.take(3)
                    val rest = entries.drop(podium.size)
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        item(key = "podium:" + vm.scope.name + ":" + vm.mode.key) {
                            Podium(podium, vm.mode, vm.myId)
                        }
                        items(rest, key = { vm.scope.name + vm.mode.key + it.profile.userId }) { e ->
                            val idx = rest.indexOf(e)
                            BoardRow(e, vm.mode, mine = e.profile.userId.equals(vm.myId, ignoreCase = true), order = idx)
                        }
                    }
                }
            }
            if (vm.loading && entries.isNotEmpty()) {
                Box(Modifier.align(Alignment.TopCenter).padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text("Đang cập nhật…", color = Color.White, fontSize = 11.sp)
                }
            }
        }

        MyRankCard(vm, mine)
    }
}

// ------------------------------------------------------------------ Thành phần

/** Thanh tab có thanh trượt mượt (viên thuốc xanh chạy theo tab được chọn). */
@Composable
private fun SlidingTabs(
    labels: List<String>,
    selected: Int,
    modifier: Modifier = Modifier,
    height: Dp = 44.dp,
    onSelect: (Int) -> Unit,
) {
    val shape = RoundedCornerShape(12.dp)
    BoxWithConstraints(
        modifier.fillMaxWidth().height(height).clip(shape).background(Color(0x66101C33)).border(1.dp, Color(0x26FFFFFF), shape),
    ) {
        val n = labels.size.coerceAtLeast(1)
        val tabW = maxWidth / n
        val x by animateDpAsState(tabW * selected.coerceIn(0, n - 1), spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow), label = "tabX")
        Box(
            Modifier
                .offset(x = x)
                .width(tabW)
                .fillMaxHeight()
                .padding(3.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(VilaColors.Green),
        )
        Row(Modifier.fillMaxSize()) {
            labels.forEachIndexed { i, label ->
                Box(Modifier.weight(1f).fillMaxHeight().clickable { onSelect(i) }, contentAlignment = Alignment.Center) {
                    Text(label, color = if (i == selected) Color.White else VilaColors.TextDim, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun Podium(top: List<LeaderboardEntry>, mode: EloMode, myId: String?) {
    if (top.isEmpty()) return
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val rise by animateFloatAsState(if (shown) 1f else 0f, tween(800, easing = FastOutSlowInEasing), label = "rise")

    // Thứ tự hiển thị: hạng 2 – hạng 1 – hạng 3 (nếu thiếu thì giữ chỗ trống)
    val first = top.getOrNull(0)
    val second = top.getOrNull(1)
    val third = top.getOrNull(2)
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        PodiumSlot(second, mode, 78.dp, 52.dp, rise, myId, Modifier.weight(1f))
        PodiumSlot(first, mode, 104.dp, 64.dp, rise, myId, Modifier.weight(1.15f))
        PodiumSlot(third, mode, 60.dp, 52.dp, rise, myId, Modifier.weight(1f))
    }
}

@Composable
private fun PodiumSlot(e: LeaderboardEntry?, mode: EloMode, pedestal: Dp, avatar: Dp, rise: Float, myId: String?, modifier: Modifier) {
    if (e == null) {
        Spacer(modifier)
        return
    }
    val p = e.profile
    val c = medalColor(e.rank)
    val isMe = p.userId.equals(myId, ignoreCase = true)
    val infinite = rememberInfiniteTransition(label = "crown")
    val bob by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "bob")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        if (e.rank == 1) {
            Text("👑", fontSize = 24.sp, modifier = Modifier.graphicsLayer { translationY = -bob * 4.dp.toPx(); alpha = rise })
        } else {
            Spacer(Modifier.height(24.dp))
        }
        Box(
            Modifier
                .graphicsLayer { alpha = rise; translationY = (1f - rise) * 30.dp.toPx() }
                .border(3.dp, c, androidx.compose.foundation.shape.CircleShape),
        ) { ProfileAvatar(name = p.displayName, avatarKey = p.avatarKey, size = avatar) }
        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            MembershipBadge(p.tier, size = 14.dp)
            Text(
                p.displayName, color = if (isMe) VilaColors.Green else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = if (p.tier == com.vila.chess.billing.MembershipTier.FREE) 0.dp else 3.dp),
            )
        }
        Text("${p.elo(mode)}", color = c, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        Box(
            Modifier
                .fillMaxWidth()
                .height(pedestal * rise)
                .padding(top = 4.dp)
                .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
                .background(Brush.verticalGradient(listOf(c.copy(alpha = 0.55f), c.copy(alpha = 0.12f)))),
            contentAlignment = Alignment.TopCenter,
        ) {
            Text("${e.rank}", color = Color.White.copy(alpha = 0.92f), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun BoardRow(e: LeaderboardEntry, mode: EloMode, mine: Boolean, order: Int) {
    val p = e.profile
    // Xuất hiện lần lượt cho 12 dòng đầu; dòng sau hiện ngay.
    val appear = remember { Animatable(if (order < 12) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (appear.value < 1f) {
            delay(order * 35L)
            appear.animateTo(1f, tween(280, easing = FastOutSlowInEasing))
        }
    }
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { alpha = appear.value; translationY = (1f - appear.value) * 18.dp.toPx() }
            .clip(shape)
            .background(if (mine) Color(0x333F6B2C) else VilaColors.Panel)
            .border(if (mine) 1.5.dp else 0.dp, if (mine) VilaColors.Green else Color.Transparent, shape)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("${e.rank}", color = Color(0xFFB9C1CE), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, modifier = Modifier.width(34.dp))
        ProfileAvatar(name = p.displayName, avatarKey = p.avatarKey, size = 40.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MembershipBadge(p.tier, size = 15.dp)
                Text(
                    p.displayName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = if (p.tier == com.vila.chess.billing.MembershipTier.FREE) 0.dp else 4.dp, end = 4.dp),
                )
                val flag = Leaderboard.flag(p.countryCode)
                if (flag.isNotEmpty()) Text(flag, fontSize = 14.sp)
            }
            Text(
                Leaderboard.title(p.elo(mode)) + " · " + p.won + "T " + p.drawn + "H " + p.lost + "B · " + Leaderboard.winRate(p) + "%",
                color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Text("${p.elo(mode)}", color = if (mine) VilaColors.Green else Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun MyRankCard(vm: LeaderboardViewModel, mine: LeaderboardEntry?) {
    val shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    val rank = vm.myRank
    val globalRank = if (vm.scope == BoardScope.GLOBAL) rank?.rank else null
    val shownRank = globalRank ?: mine?.rank
    val elo = mine?.profile?.elo(vm.mode) ?: rank?.elo
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color(0xFF2E2D2A)).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Hạng của bạn", color = VilaColors.TextDim, fontSize = 12.sp)
            Text(
                if (shownRank != null) "#$shownRank" + (if (vm.scope == BoardScope.GLOBAL && rank != null && rank.total > 0) " / ${rank.total}" else "")
                else if (vm.myId == null) "Đăng nhập để lên bảng" else "Chưa xếp hạng",
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
            )
        }
        if (elo != null) {
            Column(horizontalAlignment = Alignment.End) {
                Text(vm.mode.title + " Elo", color = VilaColors.TextDim, fontSize = 12.sp)
                Text("$elo", color = VilaColors.Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun Skeleton() {
    val infinite = rememberInfiniteTransition(label = "skeleton")
    val a by infinite.animateFloat(0.35f, 0.75f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a")
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(8) {
            Box(
                Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(12.dp)).graphicsLayer { alpha = a }.background(VilaColors.Panel),
            )
        }
    }
}

@Composable
private fun StateCard(emoji: String, text: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(emoji, fontSize = 44.sp)
        Text(text, color = Color(0xFFD7DCE6), fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp, bottom = 16.dp))
        Box(
            Modifier.clip(RoundedCornerShape(12.dp)).background(VilaColors.Green).clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 12.dp),
        ) { Text(button, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
    }
}
