package com.vila.chess.online

import android.content.Context
import androidx.compose.runtime.Immutable
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import org.json.JSONObject

/** Một ván Cờ Phép Thuật online theo góc nhìn máy chủ (supabase/social.sql). Giờ còn lại đã trừ thời gian đang chạy. */
class MagicOnlineGame(
    val id: String,
    val whiteId: String,
    val blackId: String,
    val whiteName: String,
    val blackName: String,
    val whiteTier: MembershipTier,
    val blackTier: MembershipTier,
    val baseSec: Int,
    val incSec: Int,
    /** Hạt giống chung của bộ bài / xúc xắc. */
    val seed: Long,
    /** Các hành động đã ghi, theo thứ tự (xem [com.vila.chess.magic.MagicActions]). */
    val actions: List<String>,
    /** "w" | "b": bên đang có lượt. */
    val turn: String,
    val turnsDone: Int,
    val whiteMs: Long,
    val blackMs: Long,
    /** "active" | "finished" | "aborted". */
    val status: String,
    /** "1-0" | "0-1" | "1/2-1/2" | null. */
    val result: String?,
    val reason: String?,
) {
    val active: Boolean get() = status == "active"
    val aborted: Boolean get() = status == "aborted"
    val whiteToMove: Boolean get() = turn != "b"
}

sealed interface MagicMatchResult {
    object Waiting : MagicMatchResult
    class Matched(val game: MagicOnlineGame) : MagicMatchResult
    object Cancelled : MagicMatchResult
}

/** Trạng thái ghép trận Cờ Phép Thuật mà UI cần. */
@Immutable
data class MagicSearchUi(
    val phase: OnlinePhase = OnlinePhase.IDLE,
    val error: String? = null,
    val searchStartedAt: Long = 0L,
)

/** Gọi các hàm RPC magic_* trong supabase/social.sql qua [SupabaseCloud.restCall]. Không ném lỗi: trả [Result]. */
object MagicOnlineRepository {
    private suspend fun rpc(ctx: Context, fn: String, args: JSONObject): Result<JSONObject> =
        SupabaseCloud.restCall(ctx, "POST", "/rest/v1/rpc/$fn", args.toString()).mapCatching { JSONObject(it) }

    suspend fun findMatch(ctx: Context, baseSec: Int, incSec: Int): Result<MagicMatchResult> =
        rpc(ctx, "magic_find_match", JSONObject().put("p_base", baseSec).put("p_inc", incSec)).mapCatching { parseMatch(it) }

    suspend fun cancelSearch(ctx: Context): Result<MagicMatchResult> =
        rpc(ctx, "magic_cancel_search", JSONObject()).mapCatching { parseMatch(it) }

    suspend fun getGame(ctx: Context, id: String): Result<MagicOnlineGame> =
        rpc(ctx, "magic_get_game", JSONObject().put("p_id", id)).mapCatching { parseGame(it) }

    /**
     * Gửi một hành động. [n] = số hành động đã ghi TRƯỚC hành động này; [next] = 'w' | 'b' là bên có lượt SAU hành động;
     * [result]/[reason] chỉ điền khi hành động này kết thúc ván theo luật.
     */
    suspend fun act(
        ctx: Context, id: String, n: Int, action: String, next: Char, result: String?, reason: String?,
    ): Result<MagicOnlineGame> {
        val args = JSONObject().put("p_id", id).put("p_n", n).put("p_act", action).put("p_next", next.toString())
        if (result != null) args.put("p_result", result).put("p_reason", reason ?: "")
        return rpc(ctx, "magic_act", args).mapCatching { parseGame(it) }
    }

    suspend fun resign(ctx: Context, id: String): Result<MagicOnlineGame> =
        rpc(ctx, "magic_resign", JSONObject().put("p_id", id)).mapCatching { parseGame(it) }

    // ------------------------------------------------------------------ JSON

    private fun parseMatch(j: JSONObject): MagicMatchResult = when (j.optString("status")) {
        "matched" -> MagicMatchResult.Matched(parseGame(j.getJSONObject("game")))
        "cancelled" -> MagicMatchResult.Cancelled
        else -> MagicMatchResult.Waiting
    }

    private fun JSONObject.strOrNull(key: String): String? = if (isNull(key)) null else optString(key).takeIf { it.isNotEmpty() }

    private fun parseGame(j: JSONObject): MagicOnlineGame = MagicOnlineGame(
        id = j.getString("id"),
        whiteId = j.getString("white_id"),
        blackId = j.getString("black_id"),
        whiteName = j.optString("white_name", "Người chơi"),
        blackName = j.optString("black_name", "Người chơi"),
        whiteTier = MembershipTier.fromId(j.optString("white_tier", "free")),
        blackTier = MembershipTier.fromId(j.optString("black_tier", "free")),
        baseSec = j.getInt("base_sec"),
        incSec = j.getInt("inc_sec"),
        seed = j.getLong("seed"),
        actions = j.optString("actions", "").trim().split(' ').filter { it.isNotEmpty() },
        turn = j.optString("turn", "w"),
        turnsDone = j.optInt("turns_done", 0),
        whiteMs = j.getLong("white_ms"),
        blackMs = j.getLong("black_ms"),
        status = j.optString("status", "active"),
        result = j.strOrNull("result"),
        reason = j.strOrNull("reason"),
    )
}
