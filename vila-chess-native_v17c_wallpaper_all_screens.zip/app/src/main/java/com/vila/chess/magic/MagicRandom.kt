package com.vila.chess.magic

import java.util.Random

/**
 * Bộ sinh số ngẫu nhiên CÓ THỂ SAO CHÉP trạng thái, cho đúng cùng một dãy số với `java.util.Random(seed)`
 * (cùng thuật toán đồng dư tuyến tính 48 bit, chỉ khác là trạng thái nằm trong lớp này nên sao chép được).
 *
 * Vì sao cần: hiệu ứng ngẫu nhiên (xúc xắc, đồng xu, mũ ảo thuật…) được thử trên BẢN SAO của thế cờ để kiểm tra mục tiêu hợp lệ.
 * Nếu bản sao dùng chung bộ ngẫu nhiên với ván thật thì mỗi lần giao diện "hỏi thử" lại làm dãy số trôi đi — hai máy chơi online
 * sẽ lệch nhau. Với lớp này mỗi bản sao có bộ ngẫu nhiên riêng, nên cùng hạt giống + cùng chuỗi hành động => cùng kết quả trên mọi máy.
 */
class MagicRandom(seed: Long) : Random() {
    private var state: Long = (seed xor MULT) and MASK

    /** Bản sao độc lập, tiếp tục đúng từ vị trí hiện tại của dãy số. */
    fun copyState(): MagicRandom {
        val c = MagicRandom(0L)
        c.state = state
        return c
    }

    override fun next(bits: Int): Int {
        state = (state * MULT + ADD) and MASK
        return (state ushr (48 - bits)).toInt()
    }

    private companion object {
        const val MULT = 0x5DEECE66DL
        const val ADD = 0xBL
        const val MASK = (1L shl 48) - 1
    }
}
