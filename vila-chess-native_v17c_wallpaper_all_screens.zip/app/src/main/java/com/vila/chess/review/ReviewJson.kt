package com.vila.chess.review

import org.json.JSONArray
import org.json.JSONObject

/**
 * Mã hóa/giải mã file review. Không đụng Android Context nên test được trên JVM.
 *
 * Phiên bản 1 (cũ): ply, white, label, loss, eval, best | gameId, accW, accB, tier, createdAt, moves.
 * Phiên bản 2: giữ nguyên các khóa trên (app cũ đọc file mới vẫn không crash) và thêm khóa mới.
 * Phiên bản 3: bộ 10 nhãn + khóa "eco"/"open" (khai cuộc). Kết quả phiên bản < 3 dùng ngưỡng nhãn cũ nên bị phân tích lại.
 * Phiên bản 4: engine sâu hơn + kiểm chứng lại các nước nghi sai + MultiPV 2 cả trên wasm + chấm Miss khi bỏ lỡ chiếu hết + độ chính xác kiểu trung bình điều hòa. Kết quả phiên bản < 4 được phân tích lại.
 * Đọc: khóa nào thiếu thì dùng giá trị mặc định; file hỏng -> null.
 */
object ReviewJson {
    // v5: độ chính xác theo chuẩn Lichess (volatility-weighted + harmonic)
    // v7: viết lại bộ chấm (MoveClassifier): EP 0–1, thế ngã ngũ giảm phạt, Miss/Great/Brilliant theo Chess.com, accuracy = trung bình cộng; thêm "epB"/"epA"
    // v6: nhãn theo luật mate của Lichess (đi vào thế bị mate / bỏ lỡ mate) + Brilliant xét "nước thay thế" như Chess.com
    // v8: Miss chỉ khi KHÔNG phải nước tốt nhất và mất > 10% EP; Brilliant thêm nhánh hy sinh dẫn tới chiếu hết / thế áp đảo (bất kể epBefore)
    const val CURRENT_VERSION = 9

    fun encode(r: GameReview): String {
        val arr = JSONArray()
        r.moves.forEach { m ->
            val o = JSONObject()
                .put("ply", m.ply).put("white", m.whiteMoved).put("label", m.label.name)
                .put("loss", m.winLoss).put("eval", m.evalAfterCpWhite)
                .put("best", m.bestMoveBefore ?: JSONObject.NULL)
                .put("uci", m.uci ?: JSONObject.NULL)
                .put("san", m.san ?: JSONObject.NULL)
                .put("fenB", m.fenBefore ?: JSONObject.NULL)
                .put("fenA", m.fenAfter ?: JSONObject.NULL)
                .put("evalB", m.evalBeforeCpWhite ?: JSONObject.NULL)
                .put("mateB", m.mateBeforeWhite ?: JSONObject.NULL)
                .put("mateA", m.mateAfterWhite ?: JSONObject.NULL)
                .put("pv", JSONArray(m.pv))
                .put("depthB", m.depthBefore).put("depthA", m.depthAfter)
                .put("best2", m.secondBestMove ?: JSONObject.NULL)
                .put("eval2", m.secondBestCpWhite ?: JSONObject.NULL)
                .put("mate2", m.secondBestMateWhite ?: JSONObject.NULL)
                .put("engine", m.engine).put("mpv", m.multiPv)
                .put("eco", m.ecoCode ?: JSONObject.NULL)
                .put("open", m.openingName ?: JSONObject.NULL)
                .put("epB", m.epBefore ?: JSONObject.NULL)
                .put("epA", m.epAfter ?: JSONObject.NULL)
            arr.put(o)
        }
        return JSONObject()
            .put("version", r.version)
            .put("gameId", r.gameId).put("accW", r.accuracyWhite).put("accB", r.accuracyBlack)
            .put("tier", r.tier).put("createdAt", r.createdAt)
            .put("startFen", r.startFen ?: JSONObject.NULL)
            .put("engine", r.engine).put("mpv", r.multiPv)
            .put("moves", arr)
            .toString()
    }

    fun decode(text: String): GameReview? = runCatching {
        val j = JSONObject(text)
        val a = j.getJSONArray("moves")
        val moves = (0 until a.length()).map { i -> decodeMove(a.getJSONObject(i)) }
        GameReview(
            gameId = j.getString("gameId"),
            moves = moves,
            accuracyWhite = j.getDouble("accW"),
            accuracyBlack = j.getDouble("accB"),
            tier = j.optString("tier", ""),
            createdAt = j.optLong("createdAt", 0L),
            version = j.optInt("version", 1),
            startFen = j.optStr("startFen"),
            engine = j.optStr("engine") ?: MoveReview.ENGINE_UNKNOWN,
            multiPv = j.optInt("mpv", 1),
        )
    }.getOrNull()

    private fun decodeMove(o: JSONObject): MoveReview {
        val pvArr = o.optJSONArray("pv")
        val pv = if (pvArr == null) emptyList() else (0 until pvArr.length()).map { pvArr.getString(it) }
        return MoveReview(
            ply = o.getInt("ply"),
            whiteMoved = o.getBoolean("white"),
            label = MoveLabel.values().firstOrNull { it.name == o.optString("label") } ?: MoveLabel.GOOD,
            winLoss = o.getDouble("loss"),
            evalAfterCpWhite = o.getInt("eval"),
            bestMoveBefore = o.optStr("best"),
            uci = o.optStr("uci"),
            san = o.optStr("san"),
            fenBefore = o.optStr("fenB"),
            fenAfter = o.optStr("fenA"),
            evalBeforeCpWhite = o.optIntOrNull("evalB"),
            mateBeforeWhite = o.optIntOrNull("mateB"),
            mateAfterWhite = o.optIntOrNull("mateA"),
            pv = pv,
            depthBefore = o.optInt("depthB", 0),
            depthAfter = o.optInt("depthA", 0),
            secondBestMove = o.optStr("best2"),
            secondBestCpWhite = o.optIntOrNull("eval2"),
            secondBestMateWhite = o.optIntOrNull("mate2"),
            engine = o.optStr("engine") ?: MoveReview.ENGINE_UNKNOWN,
            multiPv = o.optInt("mpv", 1),
            ecoCode = o.optStr("eco"),
            openingName = o.optStr("open"),
            epBefore = if (!o.has("epB") || o.isNull("epB")) null else o.getDouble("epB"),
            epAfter = if (!o.has("epA") || o.isNull("epA")) null else o.getDouble("epA"),
        )
    }

    private fun JSONObject.optStr(key: String): String? =
        if (!has(key) || isNull(key)) null else getString(key)

    private fun JSONObject.optIntOrNull(key: String): Int? =
        if (!has(key) || isNull(key)) null else getInt(key)
}
