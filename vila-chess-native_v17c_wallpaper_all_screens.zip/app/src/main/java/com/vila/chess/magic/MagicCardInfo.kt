package com.vila.chess.magic

/**
 * Nhãn phân loại lá bài (thiết kế để người chơi nhìn là biết lá làm gì):
 *  - [CardKind] = LOẠI phép (Triệu hồi, Tấn công, Phòng thủ, Khống chế, Cơ động, Năng lượng, May rủi, Tuyệt kỹ)
 *  - [Rarity]   = ĐỘ HIẾM theo giá mana (Thường → Huyền thoại)
 *  - ★ Gói      = bài đặc quyền của gói thành viên
 *  - Modifier   = phần thưởng/điều kiện đi kèm (Vang Vọng, Lời Nguyền, Thần Tốc…)
 */
enum class CardKind(val label: String, val emoji: String, val blurb: String) {
    SUMMON("Triệu hồi", "✨", "Thêm hoặc biến đổi quân của bạn"),
    STRIKE("Tấn công", "🔥", "Tiêu diệt hoặc hạ cấp quân địch"),
    GUARD("Phòng thủ", "🛡️", "Bảo vệ quân và đặt bẫy"),
    CONTROL("Khống chế", "❄️", "Làm đối thủ chậm, mất bài hoặc mất mana"),
    MOVE("Cơ động", "🌀", "Dịch chuyển và đi thêm nước"),
    ENERGY("Năng lượng", "💧", "Nhận mana và rút bài"),
    CHANCE("May rủi", "🎲", "Kết quả ngẫu nhiên, có thể rất lời"),
    SIGNATURE("Tuyệt kỹ", "🌟", "Bài VIP mạnh hơn mua rời"),
}

object MagicCardInfo {
    fun kindOfEffect(e: MagicEffect): CardKind = when (e) {
        is Spawn, is Resurrect, is Clone, is Mirror, is Promote -> CardKind.SUMMON
        is Smite, is Lightning, is Demote -> CardKind.STRIKE
        is Shield, is Trap -> CardKind.GUARD
        is Freeze, is Push, is Swap, is Charm, is SpellLock, is Discard, is ManaDrain -> CardKind.CONTROL
        is Teleport, is KingBlink, is ExtraMove, is PawnStorm -> CardKind.MOVE
        is ManaGain, is DrawCards -> CardKind.ENERGY
        is DiceRoll, is CoinFlip, is LuckyWheel, is MagicHat, is Meteor -> CardKind.CHANCE
        is Combo -> e.partsForTest().firstOrNull()?.let { kindOfEffect(it) } ?: CardKind.SIGNATURE
        else -> CardKind.SUMMON
    }

    fun kindOf(card: MagicCard): CardKind = if (card.isSignature) CardKind.SIGNATURE else kindOfEffect(card.effect)

    /** Các nhãn nhỏ hiện trên lá bài, theo thứ tự ưu tiên (giao diện cắt bớt nếu hết chỗ). */
    fun tags(card: MagicCard): List<String> {
        val out = ArrayList<String>(4)
        out += kindOf(card).emoji + " " + kindOf(card).label
        if (card.tier != com.vila.chess.billing.MembershipTier.FREE) out += "★ " + card.tier.displayName
        if (card.isFun && kindOf(card) != CardKind.CHANCE) out += "🎉 May rủi"
        if (card.modifier != Modifier.NONE) out += card.modifier.prefix
        return out
    }

    /** Câu mô tả ngắn cách chơi: cần chạm mấy ô. */
    fun usageLine(card: MagicCard): String {
        val steps = card.effect.picks.size
        return when (steps) {
            0 -> "Dùng ngay — không cần chọn ô"
            1 -> "Chạm 1 ô sáng để dùng"
            else -> "Chạm $steps ô lần lượt để dùng"
        }
    }
}
