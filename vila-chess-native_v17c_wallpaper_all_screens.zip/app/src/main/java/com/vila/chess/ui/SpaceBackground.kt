package com.vila.chess.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/** Lớp phủ tối nhẹ trên hình nền ở các màn chơi/review: nhìn rõ bàn cờ, đồng hồ, chữ mà vẫn thấy nền động phía sau. */
val GameScrim = Color(0x59000000)

/** Một lớp sao cùng độ sáng/kích thước: vẽ bằng MỘT lệnh drawPoints thay vì hàng trăm drawCircle. */
private class StarLayer(val xs: FloatArray, val ys: FloatArray, val radiusDp: Float, val alpha: Float)

private fun buildStarLayers(): List<StarLayer> {
    val rnd = Random(7)
    // (số sao, bán kính dp, độ sáng): nhiều sao mờ nhỏ, ít sao sáng lớn -> có chiều sâu
    val spec = listOf(
        Triple(72, 0.6f, 0.22f),
        Triple(38, 0.95f, 0.42f),
        Triple(14, 1.4f, 0.70f),
    )
    return spec.map { (count, r, a) ->
        StarLayer(
            xs = FloatArray(count) { rnd.nextFloat() },
            ys = FloatArray(count) { rnd.nextFloat() },
            radiusDp = r,
            alpha = a,
        )
    }
}

/**
 * Nền không gian xanh thẫm phía sau màn hình chính.
 * Tối ưu: gradient + toạ độ sao được cache theo kích thước (drawWithCache), sao gom thành 3 lệnh
 * drawPoints. Không animation, không recomposition => gần như 0 chi phí mỗi frame.
 */
@Composable
fun SpaceBackground(modifier: Modifier = Modifier) {
    if (Wallpapers.current.scene.isNotEmpty()) {
        SceneBackground(modifier)   // 6 cảnh vũ trụ động trong SpaceScenes.kt
        return
    }
    if (Wallpapers.current.animated) {
        GalaxyBackground(modifier)
        return
    }
    val layers = remember { buildStarLayers() }
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val wp = Wallpapers.current   // đọc state TRONG khối cache: đổi hình nền thì cache tự dựng lại
                val base = Brush.verticalGradient(
                    colors = listOf(wp.top, wp.mid, wp.bottom),
                )
                val glowBlue = Brush.radialGradient(
                    colors = listOf(wp.glowA, Color.Transparent),
                    center = Offset(w * 0.88f, h * 0.84f),
                    radius = w * 0.95f,
                )
                val glowPurple = Brush.radialGradient(
                    colors = listOf(wp.glowB, Color.Transparent),
                    center = Offset(w * 0.08f, h * 0.36f),
                    radius = w * 0.7f,
                )
                val glowTop = Brush.radialGradient(
                    colors = listOf(wp.glowC, Color.Transparent),
                    center = Offset(w * 0.5f, 0f),
                    radius = w * 0.9f,
                )
                val points = layers.map { l ->
                    List(l.xs.size) { Offset(l.xs[it] * w, l.ys[it] * h) }
                }
                onDrawBehind {
                    drawRect(base)
                    drawRect(glowTop)
                    drawRect(glowBlue)
                    drawRect(glowPurple)
                    if (wp.stars) for (i in layers.indices) {
                        drawPoints(
                            points = points[i],
                            pointMode = PointMode.Points,
                            color = Color.White.copy(alpha = layers[i].alpha),
                            strokeWidth = layers[i].radiusDp * 2f * density,
                            cap = StrokeCap.Round,
                        )
                    }
                }
            },
    )
}


// =====================================================================================================
// NỀN "NGÂN HÀ" CHUYỂN ĐỘNG
// =====================================================================================================
// Chi phí thấp: toàn bộ toạ độ dựng MỘT lần (remember + drawWithCache); mỗi frame chỉ đọc `time` TRONG
// pha vẽ => KHÔNG recomposition, chỉ vẽ lại ~35 lệnh drawPoints. Cập nhật 30 fps (chuyển động chậm nên
// không cần 60) để đỡ pin; vòng lặp tự dừng khi màn hình tắt/thoát composable (withFrameNanos).

/** Một nhóm hạt của thiên hà (cùng màu/cỡ/độ sáng), toạ độ chuẩn hoá trong đĩa thiên hà: x,y ∈ [-1,1]. */
private class GalaxyBucket(val xy: FloatArray, val color: Color, val radiusDp: Float, val alpha: Float)

private class GalaxyData(val buckets: List<GalaxyBucket>, val dustXy: FloatArray)

private class DriftStars(
    val xs: FloatArray, val ys: FloatArray, val radiusDp: Float, val alpha: Float,
    val driftDpPerSec: Float, val twinkleRadPerSec: Float, val phase: Float,
)

private val CoreColor = Color(0xFFFFE9B8)   // lõi vàng ấm
private val ArmColor = Color(0xFFCFE0FF)    // nhánh xanh trắng
private val RimColor = Color(0xFFC9A4FF)    // rìa tím

private fun gauss(rnd: Random): Float = (rnd.nextFloat() + rnd.nextFloat() + rnd.nextFloat() - 1.5f) / 1.5f  // ~[-1,1], chuông

private fun buildGalaxy(): GalaxyData {
    val rnd = Random(11)
    val colors = listOf(CoreColor, ArmColor, RimColor)
    val sizes = listOf(Triple(0.7f, 0.55f, 0.70f), Triple(1.1f, 0.75f, 0.25f), Triple(1.6f, 0.95f, 0.05f)) // (dp, alpha, tỉ lệ)
    val lists = Array(3) { Array(3) { ArrayList<Float>() } }   // [màu][cỡ]
    fun add(x: Float, y: Float, r: Float) {
        val c = if (r < 0.25f) 0 else if (r < 0.65f) 1 else 2
        val u = rnd.nextFloat()
        val s = if (u < sizes[0].third) 0 else if (u < sizes[0].third + sizes[1].third) 1 else 2
        lists[c][s].add(x); lists[c][s].add(y)
    }
    // 2 nhánh xoắn ốc
    repeat(520) { i ->
        val r = rnd.nextFloat().pow(1.5f)
        val theta = (i % 2) * PI.toFloat() + r * 3.6f + gauss(rnd) * (0.55f - 0.25f * r)
        add(r * cos(theta), r * sin(theta), r)
    }
    // lõi (bulge) dày và sáng
    repeat(150) {
        val r = kotlin.math.abs(gauss(rnd)) * 0.16f
        val a = rnd.nextFloat() * 2f * PI.toFloat()
        add(r * cos(a), r * sin(a), r)
    }
    // sương bụi mềm dọc nhánh (chấm to, rất mờ)
    val dust = ArrayList<Float>()
    repeat(110) { i ->
        val r = 0.12f + rnd.nextFloat() * 0.85f
        val theta = (i % 2) * PI.toFloat() + r * 3.6f + gauss(rnd) * 0.22f
        dust.add(r * cos(theta)); dust.add(r * sin(theta))
    }
    val buckets = ArrayList<GalaxyBucket>()
    for (c in 0..2) for (s in 0..2) {
        if (lists[c][s].isNotEmpty()) buckets += GalaxyBucket(lists[c][s].toFloatArray(), colors[c], sizes[s].first, sizes[s].second)
    }
    return GalaxyData(buckets, dust.toFloatArray())
}

private fun buildDriftStars(): List<DriftStars> {
    val rnd = Random(21)
    // (số sao, bán kính dp, độ sáng, tốc độ trôi dp/s, tốc độ lấp lánh rad/s, pha) - hai nhóm/cỡ lệch pha => lấp lánh tự nhiên, trôi khác tốc độ => thị sai
    val spec = listOf(
        floatArrayOf(40f, 0.6f, 0.30f, 1.5f, 0.9f, 0.0f), floatArrayOf(40f, 0.6f, 0.30f, 1.5f, 1.3f, 2.1f),
        floatArrayOf(22f, 0.95f, 0.50f, 3.0f, 1.1f, 0.7f), floatArrayOf(22f, 0.95f, 0.50f, 3.0f, 1.7f, 3.9f),
        floatArrayOf(8f, 1.4f, 0.85f, 5.0f, 1.5f, 1.3f), floatArrayOf(8f, 1.4f, 0.85f, 5.0f, 2.2f, 4.4f),
    )
    return spec.map { sp ->
        val n = sp[0].toInt()
        DriftStars(FloatArray(n) { rnd.nextFloat() }, FloatArray(n) { rnd.nextFloat() }, sp[1], sp[2], sp[3], sp[4], sp[5])
    }
}

@Composable
private fun GalaxyBackground(modifier: Modifier = Modifier) {
    val galaxy = remember { buildGalaxy() }
    val drift = remember { buildDriftStars() }
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        var last = start
        while (true) {
            withFrameNanos { now ->
                if (now - last >= 33_000_000L) {   // ~30 fps
                    last = now
                    time.floatValue = (now - start) / 1_000_000_000f
                }
            }
        }
    }
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val w = size.width
                val h = size.height
                val wp = Wallpapers.current
                val base = Brush.verticalGradient(listOf(wp.top, wp.mid, wp.bottom))
                val glowBlue = Brush.radialGradient(listOf(wp.glowA, Color.Transparent), Offset(w * 0.88f, h * 0.84f), w * 0.95f)
                val glowPurple = Brush.radialGradient(listOf(wp.glowB, Color.Transparent), Offset(w * 0.08f, h * 0.36f), w * 0.7f)
                val glowTop = Brush.radialGradient(listOf(wp.glowC, Color.Transparent), Offset(w * 0.5f, 0f), w * 0.9f)

                // thiên hà: tâm lệch phải-trên, bán kính lớn hơn nửa chiều rộng => tràn mép, nhìn như một đĩa khổng lồ
                val cx = w * 0.62f
                val cy = h * 0.34f
                val radius = w * 0.82f
                val coreGlow = Brush.radialGradient(
                    colors = listOf(Color(0xAAFFE9B8), Color(0x44FFB070), Color(0x22B04FD0), Color.Transparent),
                    center = Offset.Zero, radius = radius * 0.42f,
                )
                val dustPts = List(galaxy.dustXy.size / 2) { Offset(galaxy.dustXy[it * 2] * radius, galaxy.dustXy[it * 2 + 1] * radius) }
                val bucketPts = galaxy.buckets.map { b -> List(b.xy.size / 2) { Offset(b.xy[it * 2] * radius, b.xy[it * 2 + 1] * radius) } }
                val driftPts = drift.map { g -> List(g.xs.size) { Offset(g.xs[it] * w, g.ys[it] * h) } }
                val shootLen = w * 0.28f

                onDrawBehind {
                    val t = time.floatValue     // đọc state ở pha VẼ: chỉ vẽ lại, không recompose
                    drawRect(base)
                    drawRect(glowTop)
                    drawRect(glowBlue)
                    drawRect(glowPurple)

                    // 1) sao nền: trôi ngang chậm (thị sai) + lấp lánh
                    for (i in drift.indices) {
                        val g = drift[i]
                        val a = g.alpha * (0.72f + 0.28f * sin(t * g.twinkleRadPerSec + g.phase))
                        val off = (t * g.driftDpPerSec * density) % w
                        for (copy in 0..1) translate(left = copy * w - off, top = 0f) {
                            drawPoints(driftPts[i], PointMode.Points, Color.White.copy(alpha = a), g.radiusDp * 2f * density, StrokeCap.Round)
                        }
                    }

                    // 2) thiên hà xoay chậm (~225 giây/vòng), nghiêng như nhìn xiên
                    withTransform({
                        translate(cx, cy)
                        rotate(-22f, Offset.Zero)
                        scale(1f, 0.55f, Offset.Zero)
                        rotate(t * 1.6f, Offset.Zero)
                    }) {
                        drawCircle(coreGlow, radius * 0.42f, Offset.Zero)
                        drawPoints(dustPts, PointMode.Points, wp.glowA.copy(alpha = 0.07f), radius * 0.16f, StrokeCap.Round)
                        drawPoints(dustPts, PointMode.Points, wp.glowB.copy(alpha = 0.05f), radius * 0.09f, StrokeCap.Round)
                        for (i in galaxy.buckets.indices) {
                            val b = galaxy.buckets[i]
                            drawPoints(bucketPts[i], PointMode.Points, b.color.copy(alpha = b.alpha), b.radiusDp * 2f * density, StrokeCap.Round)
                        }
                    }

                    // 3) sao băng: mỗi ~7.5s một vệt 0.9s, vị trí lấy từ số thứ tự chu kỳ (không cấp phát/ngẫu nhiên mỗi frame)
                    val cycle = 7.5f
                    val k = floor(t / cycle)
                    val local = t - k * cycle
                    if (local < 0.9f) {
                        val p = local / 0.9f
                        val sx = ((k * 0.6180339f) % 1f) * w * 0.7f + w * 0.3f
                        val sy = ((k * 0.3819660f + 0.2f) % 1f) * h * 0.35f
                        val dx = -0.82f
                        val dy = 0.57f
                        val head = Offset(sx + dx * shootLen * 1.6f * p, sy + dy * shootLen * 1.6f * p)
                        val tail = Offset(head.x - dx * shootLen, head.y - dy * shootLen)
                        val fade = sin(p * PI.toFloat())
                        drawLine(
                            brush = Brush.linearGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.9f * fade)),
                                start = tail, end = head,
                            ),
                            start = tail, end = head, strokeWidth = 1.6f * density, cap = StrokeCap.Round,
                        )
                    }
                }
            },
    )
}
