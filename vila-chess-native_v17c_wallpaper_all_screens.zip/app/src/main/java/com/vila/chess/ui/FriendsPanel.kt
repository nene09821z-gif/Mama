package com.vila.chess.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.billing.MembershipTier
import com.vila.chess.cloud.SupabaseCloud
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloMode
import com.vila.chess.profile.FriendsViewModel
import com.vila.chess.profile.LoadState
import com.vila.chess.profile.ProfileRepository
import com.vila.chess.profile.UserProfile
import kotlinx.coroutines.delay

// =============================================================================
// Trang Bạn bè (v16m) — thiết kế lại hoàn chỉnh
//
//   Tiêu đề  →  Thẻ "ID của bạn" (sao chép / chia sẻ)  →  Ô thêm bạn (kiểm tra ID ngay khi dán)
//   →  2 ô hành động nhanh  →  Danh sách: chọn Elo (Bullet/Blitz/Rapid) · sắp xếp · tìm kiếm
//   →  Thẻ bạn bè: avatar có viền theo hạng VIP, huy hiệu top 3, Elo lớn, thanh thắng/hòa/thua, chuỗi thắng.
//
// 4 trạng thái: đang tải (shimmer) · lỗi (Thử lại) · trống (CTA mời bạn) · có dữ liệu (+ không tìm thấy).
// Không đổi ViewModel / repository.
// =============================================================================

private val SurfaceDeep = Color(0xFF16253F)
private val MenuBg = Color(0xFF16233B)
private val IdCardBrush = Brush.linearGradient(listOf(Color(0xFF2E5C2B), Color(0xFF1B3B66), Color(0xFF13284A)))
private val AddGreenBrush = Brush.verticalGradient(listOf(Color(0xFF8DC351), Color(0xFF7BB145)))
private val SoftBlue = Color(0xFF6CB4FF)
private val StreakOrange = Color(0xFFFFB04A)
private val MedalGold = Color(0xFFFFD24A)
private val MedalSilver = Color(0xFFC9D1DC)
private val MedalBronze = Color(0xFFD99158)

@Composable
fun FriendsPanel(
    onViewProfile: (String) -> Unit,
    modifier: Modifier = Modifier,
    /** Có truyền → hiện ô "Chơi chung máy". */
    onPlayLocal: (() -> Unit)? = null,
    /** Có truyền → hiện ô "Mời bạn bè" (chia sẻ link app) và nút mời ở trạng thái trống. */
    onInvite: (() -> Unit)? = null,
    /** Vẽ tiêu đề "Bạn bè" + mô tả ở đầu trang. */
    showHeader: Boolean = true,
    fvm: FriendsViewModel = viewModel(),
) {
    val ctx = LocalContext.current
    val state by fvm.state.collectAsState()
    val message by fvm.message.collectAsState()
    val busy by fvm.busy.collectAsState()
    var sheetFor by remember { mutableStateOf<UserProfile?>(null) }
    var removeFor by remember { mutableStateOf<UserProfile?>(null) }
    var modeIndex by rememberSaveable { mutableIntStateOf(EloMode.BLITZ.ordinal) }
    var sortByName by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val myId = SupabaseCloud.userId(ctx)
    val mode = EloMode.values()[modeIndex.coerceIn(0, EloMode.values().size - 1)]

    LaunchedEffect(message) {
        message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); fvm.consumeMessage() }
    }

    val friends: List<UserProfile> = (state as? LoadState.Success)?.data.orEmpty()
    val shown: List<UserProfile> = remember(friends, mode, sortByName, query) {
        val q = query.trim()
        val filtered = if (q.isEmpty()) friends else friends.filter { it.displayName.contains(q, ignoreCase = true) }
        if (sortByName) {
            filtered.sortedBy { it.displayName.lowercase() }
        } else {
            filtered.sortedWith(compareByDescending<UserProfile> { it.elo(mode) }.thenBy { it.displayName.lowercase() })
        }
    }
    val showRanks = !sortByName && query.isBlank() && shown.size >= 2

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (showHeader) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Bạn bè", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp)
                Text("Kết nối, thách đấu và theo dõi bạn cờ", color = VilaColors.TextDim, fontSize = 14.sp)
            }
        }

        if (myId != null) {
            MyIdCard(
                myId = myId,
                onCopy = {
                    clipboard.setText(AnnotatedString(myId))
                    Toast.makeText(ctx, "Đã sao chép ID", Toast.LENGTH_SHORT).show()
                },
                onShareId = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Kết bạn với mình trên ViLa Chess nhé! ID của mình:\n$myId")
                    }
                    try {
                        ctx.startActivity(Intent.createChooser(send, "Chia sẻ ID"))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, "Không mở được hộp chia sẻ", Toast.LENGTH_SHORT).show()
                    }
                },
            )
        }

        AddFriendField(busy = busy, clipboard = clipboard, onAdd = { fvm.add(it) })

        if (onPlayLocal != null || onInvite != null) {
            Row(
                modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (onPlayLocal != null) {
                    ActionTile(
                        icon = Icons.Filled.SportsEsports,
                        title = "Chơi chung máy",
                        subtitle = "2 người, 1 điện thoại",
                        tint = VilaColors.Green,
                        onClick = onPlayLocal,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
                if (onInvite != null) {
                    ActionTile(
                        icon = Icons.Filled.Share,
                        title = "Mời bạn bè",
                        subtitle = "Gửi link ViLa Chess",
                        tint = SoftBlue,
                        onClick = onInvite,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    )
                }
            }
        }

        ListToolbar(
            total = friends.size,
            sortByName = sortByName,
            onToggleSort = { sortByName = !sortByName },
            onRefresh = { fvm.refresh() },
        )

        when (val s = state) {
            is LoadState.Loading -> FriendSkeleton()
            is LoadState.Error -> Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp))) {
                ErrorBlock(s.kind, onRetry = { fvm.refresh() })
            }
            is LoadState.Success -> if (s.data.isEmpty()) {
                EmptyFriends(onInvite = onInvite)
            } else {
                EloSegment(selected = mode, onSelect = { modeIndex = it.ordinal })
                AnimatedVisibility(visible = s.data.size >= 6) {
                    SearchField(query = query, onChange = { query = it })
                }
                if (shown.isEmpty()) {
                    NoResults(query = query)
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth().animateContentSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        shown.forEachIndexed { i, f ->
                            key(f.userId) {
                                FriendListCard(
                                    f = f,
                                    mode = mode,
                                    index = i,
                                    rank = if (showRanks && i < 3) i + 1 else null,
                                    onClick = { sheetFor = f },
                                    onRemove = { removeFor = f },
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    sheetFor?.let { f ->
        OpponentProfileSheet(
            userId = f.userId,
            fallbackName = f.displayName,
            fallbackTier = f.tier,
            mode = mode,
            onDismiss = { sheetFor = null },
            onViewFull = { id -> sheetFor = null; onViewProfile(id) },
        )
    }
    removeFor?.let { f ->
        AlertDialog(
            onDismissRequest = { removeFor = null },
            containerColor = MenuBg,
            titleContentColor = Color.White,
            textContentColor = VilaColors.TextDim,
            shape = RoundedCornerShape(VilaDimens.DialogRadius),
            title = { Text("Xóa bạn bè?", fontWeight = FontWeight.ExtraBold) },
            text = { Text("Xóa ${f.displayName} khỏi danh sách bạn bè của bạn?") },
            confirmButton = {
                TextButton(onClick = { fvm.remove(f.userId); removeFor = null }) {
                    Text("Xóa", color = LossColor, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { removeFor = null }) { Text("Hủy", color = VilaColors.TextDim) } },
        )
    }
}

// =============================================================================
// Thẻ "ID của bạn"
// =============================================================================

@Composable
private fun MyIdCard(myId: String, onCopy: () -> Unit, onShareId: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1700)
            copied = false
        }
    }
    val copyBg by animateColorAsState(
        targetValue = if (copied) VilaColors.Green else Color(0x2EFFFFFF),
        animationSpec = tween(220),
        label = "copyBg",
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(IdCardBrush)
            .drawBehind {
                // Ánh sáng mờ góc trên trái
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x2681B64C), Color.Transparent),
                        center = Offset(size.width * 0.12f, 0f),
                        radius = size.width * 0.7f,
                    ),
                    radius = size.width * 0.7f,
                    center = Offset(size.width * 0.12f, 0f),
                )
                // Hoa văn bàn cờ mờ dần ở góc phải
                val sq = 24.dp.toPx()
                for (r in 0 until 5) {
                    for (c in 0 until 8) {
                        if ((r + c) % 2 == 0) {
                            drawRect(
                                color = Color.White.copy(alpha = 0.075f * (1f - c / 8f)),
                                topLeft = Offset(size.width - (c + 1) * sq, r * sq),
                                size = Size(sq, sq),
                            )
                        }
                    }
                }
            }
            .border(1.dp, VilaBrushes.GlassStroke, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0x26FFFFFF)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("ID CỦA BẠN", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                Text("Gửi ID này để bạn bè thêm bạn", color = Color(0xB3FFFFFF), fontSize = 12.sp)
            }
        }

        // Ô ID (chạm để sao chép)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x40000000))
                .clickable(onClickLabel = "Sao chép ID") { copied = true; onCopy() }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = myId,
                color = Color.White,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Sao chép
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .pressable(onClickLabel = "Sao chép ID", pressedScale = 0.96f, onClick = { copied = true; onCopy() })
                    .clip(RoundedCornerShape(13.dp))
                    .background(copyBg),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text(if (copied) "Đã chép" else "Sao chép", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            }
            // Chia sẻ ID
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .pressable(onClickLabel = "Chia sẻ ID", pressedScale = 0.96f, onClick = onShareId)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Color.White),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Share, contentDescription = null, tint = Color(0xFF13284A), modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Chia sẻ ID", color = Color(0xFF13284A), fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

// =============================================================================
// Ô thêm bạn
// =============================================================================

@Composable
private fun AddFriendField(busy: Boolean, clipboard: ClipboardManager, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var focused by remember { mutableStateOf(false) }
    val trimmed = text.trim()
    val valid = remember(trimmed) { ProfileRepository.isValidUserId(trimmed) }
    val showError = trimmed.length >= 8 && !valid
    val canAdd = !busy && valid
    val shape = RoundedCornerShape(16.dp)
    val borderColor by animateColorAsState(
        targetValue = when {
            valid -> VilaColors.Green
            showError -> LossColor
            focused -> Color(0x99FFFFFF)
            else -> Color.Transparent
        },
        animationSpec = tween(180),
        label = "addBorder",
    )
    val submit: () -> Unit = {
        if (canAdd) {
            onAdd(trimmed)
            text = ""
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .glass(shape)
                .border(1.5.dp, borderColor, shape)
                .padding(start = 14.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.PersonAdd, contentDescription = null, tint = VilaColors.NavIdle, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(VilaColors.Green),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) {
                            Text("Dán ID bạn bè để kết bạn", color = VilaColors.NavIdle, fontSize = 15.sp, maxLines = 1)
                        }
                        inner()
                    }
                },
            )
            Spacer(Modifier.width(8.dp))
            when {
                text.isEmpty() -> Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0x1FFFFFFF))
                        .clickable(role = Role.Button, onClickLabel = "Dán ID") {
                            val pasted = clipboard.getText()?.text?.trim().orEmpty()
                            if (pasted.isNotEmpty()) text = pasted
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.ContentPaste, contentDescription = "Dán", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                valid -> Box(
                    modifier = Modifier
                        .height(42.dp)
                        .clip(RoundedCornerShape(13.dp))
                        .background(AddGreenBrush)
                        .clickable(enabled = canAdd, role = Role.Button, onClick = submit)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (busy) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                    } else {
                        Text("Thêm", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    }
                }
                else -> Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClickLabel = "Xóa") { text = "" },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Xóa", tint = VilaColors.NavIdle, modifier = Modifier.size(20.dp))
                }
            }
        }
        AnimatedVisibility(visible = showError) {
            Text(
                text = "ID chưa đúng định dạng. Hãy nhờ bạn bè sao chép ID rồi dùng nút Dán để tránh gõ sai.",
                color = LossColor,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 6.dp),
            )
        }
    }
}

// =============================================================================
// Ô hành động nhanh
// =============================================================================

@Composable
private fun ActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier = modifier
            .pressable(onClickLabel = title, onClick = onClick)
            .glass(shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.34f), tint.copy(alpha = 0.14f)))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = VilaColors.NavIdle, modifier = Modifier.size(22.dp))
        }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = VilaColors.TextDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// =============================================================================
// Thanh công cụ danh sách
// =============================================================================

@Composable
private fun ListToolbar(total: Int, sortByName: Boolean, onToggleSort: () -> Unit, onRefresh: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("BẠN CỦA BẠN", color = VilaColors.TextDim, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
        if (total > 0) {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x3381B64C)).padding(horizontal = 8.dp, vertical = 2.dp),
            ) {
                Text(total.toString(), color = VilaColors.Green, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        Spacer(Modifier.weight(1f))
        if (total >= 2) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x1AFFFFFF))
                    .clickable(role = Role.Button, onClickLabel = "Đổi cách sắp xếp", onClick = onToggleSort)
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.SwapVert, contentDescription = null, tint = VilaColors.TextDim, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (sortByName) "Tên A–Z" else "Elo cao nhất", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(6.dp))
        }
        Box(
            modifier = Modifier
                .size(36.dp)
                .pressable(onClickLabel = "Tải lại", pressedScale = 0.86f, onClick = onRefresh)
                .clip(CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Refresh, contentDescription = "Tải lại", tint = VilaColors.NavIdle, modifier = Modifier.size(20.dp))
        }
    }
}

/** Chọn Elo hiển thị trên thẻ bạn bè: Bullet / Blitz / Rapid. */
@Composable
private fun EloSegment(selected: EloMode, onSelect: (EloMode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x1AFFFFFF))
            .padding(3.dp),
    ) {
        for (m in EloMode.values()) {
            val sel = m == selected
            val bg by animateColorAsState(if (sel) VilaColors.Green else Color.Transparent, tween(200), label = "segBg")
            val fg by animateColorAsState(if (sel) Color.White else VilaColors.TextDim, tween(200), label = "segFg")
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .clickable(role = Role.Tab, onClickLabel = "Xem Elo ${m.title}") { onSelect(m) },
                contentAlignment = Alignment.Center,
            ) {
                Text(m.title, color = fg, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(46.dp)
            .clip(shape)
            .background(Color(0x1AFFFFFF))
            .padding(start = 12.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = VilaColors.NavIdle, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value = query,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
            cursorBrush = SolidColor(VilaColors.Green),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) Text("Tìm bạn theo tên", color = VilaColors.NavIdle, fontSize = 14.sp, maxLines = 1)
                    inner()
                }
            },
        )
        if (query.isNotEmpty()) {
            Box(
                modifier = Modifier.size(34.dp).clip(CircleShape).clickable(role = Role.Button, onClickLabel = "Xóa tìm kiếm") { onChange("") },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Close, contentDescription = "Xóa tìm kiếm", tint = VilaColors.NavIdle, modifier = Modifier.size(18.dp))
            }
        }
    }
}

// =============================================================================
// Thẻ bạn bè
// =============================================================================

private fun tierRing(t: MembershipTier): Brush? = when (t) {
    MembershipTier.FREE -> null
    MembershipTier.GOLD -> Brush.sweepGradient(listOf(Color(0xFFFFE27A), Color(0xFFF5A800), Color(0xFFFFE27A)))
    MembershipTier.PLATINUM -> Brush.sweepGradient(listOf(Color(0xFFFFFFFF), Color(0xFF9AA7B5), Color(0xFFFFFFFF)))
    MembershipTier.DIAMOND -> Brush.sweepGradient(listOf(Color(0xFF8FE3FF), Color(0xFF1E88E5), Color(0xFF8FE3FF)))
    MembershipTier.FAMILY -> Brush.sweepGradient(listOf(Color(0xFF9CD35A), Color(0xFF5FA23A), Color(0xFF9CD35A)))
}

/** Avatar có viền sáng theo hạng VIP + huy hiệu số thứ hạng (top 3). */
@Composable
private fun FriendAvatar(f: UserProfile, rank: Int?) {
    val ring = tierRing(f.tier)
    Box(modifier = Modifier.size(60.dp), contentAlignment = Alignment.Center) {
        if (ring != null) {
            Box(Modifier.size(60.dp).clip(CircleShape).background(ring))
            Box(Modifier.size(55.dp).clip(CircleShape).background(SurfaceDeep))
            ProfileAvatar(name = f.displayName, avatarKey = f.avatarKey, size = 50.dp)
        } else {
            ProfileAvatar(name = f.displayName, avatarKey = f.avatarKey, size = 56.dp)
        }
        if (rank != null) {
            val medal = when (rank) {
                1 -> MedalGold
                2 -> MedalSilver
                else -> MedalBronze
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 3.dp, y = 3.dp)
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(medal)
                    .border(2.dp, SurfaceDeep, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(rank.toString(), color = Color(0xFF3A2A06), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/** Thanh mảnh thắng/hòa/thua. */
@Composable
private fun MiniWdl(won: Int, drawn: Int, lost: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x22FFFFFF))) {
        if (won > 0) Box(Modifier.weight(won.toFloat()).fillMaxHeight().background(WinColor))
        if (drawn > 0) Box(Modifier.weight(drawn.toFloat()).fillMaxHeight().background(DrawColor))
        if (lost > 0) Box(Modifier.weight(lost.toFloat()).fillMaxHeight().background(LossColor))
    }
}

@Composable
private fun FriendListCard(
    f: UserProfile,
    mode: EloMode,
    index: Int,
    rank: Int?,
    onClick: () -> Unit,
    onRemove: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(18.dp)
    val country = Countries.byCode(f.countryCode)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .staggerIn(index)
            .pressable(onClickLabel = "Xem hồ sơ ${f.displayName}", onClick = onClick)
            .glass(shape)
            .padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FriendAvatar(f = f, rank = rank)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                NameWithBadge(name = f.displayName, tier = f.tier, fontSize = 16f, modifier = Modifier.weight(1f, fill = false))
                if (f.resultStreak >= 3) {
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.clip(RoundedCornerShape(7.dp)).background(StreakOrange.copy(alpha = 0.16f)).padding(horizontal = 6.dp, vertical = 1.dp)) {
                        Text("🔥 ${f.resultStreak}", color = StreakOrange, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    }
                }
            }
            if (country != null) {
                Text(
                    text = Countries.flag(country.code) + "  " + country.name,
                    color = VilaColors.TextDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (f.played > 0) {
                MiniWdl(f.won, f.drawn, f.lost)
                Text("${f.played} ván · ${f.winRatePct}% thắng", color = VilaColors.TextDim, fontSize = 11.sp, maxLines = 1)
            } else {
                Text("Chưa có ván nào", color = VilaColors.NavIdle, fontSize = 11.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(f.elo(mode).toString(), color = Color.White, style = VilaText.Clock)
            Text(mode.title.uppercase(), color = VilaColors.TextDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp)
        }
        Box {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(role = Role.Button, onClickLabel = "Tùy chọn") { menu = true },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Tùy chọn", tint = VilaColors.NavIdle, modifier = Modifier.size(20.dp))
            }
            DropdownMenu(
                expanded = menu,
                onDismissRequest = { menu = false },
                modifier = Modifier.background(MenuBg),
            ) {
                DropdownMenuItem(
                    text = { Text("Xem hồ sơ", color = Color.White) },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null, tint = VilaColors.TextDim) },
                    onClick = { menu = false; onClick() },
                )
                DropdownMenuItem(
                    text = { Text("Xóa bạn", color = LossColor) },
                    leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = LossColor) },
                    onClick = { menu = false; onRemove() },
                )
            }
        }
    }
}

// =============================================================================
// Trạng thái trống · không tìm thấy · đang tải
// =============================================================================

@Composable
private fun EmptyFriends(onInvite: (() -> Unit)?) {
    Column(
        modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 24.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            modifier = Modifier
                .size(112.dp)
                .drawBehind {
                    drawCircle(Color(0x1281B64C), radius = size.minDimension / 2f)
                    drawCircle(Color(0x1A81B64C), radius = size.minDimension / 2f * 0.76f)
                    drawCircle(Color(0x2681B64C), radius = size.minDimension / 2f * 0.52f)
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Groups, contentDescription = null, tint = VilaColors.Green, modifier = Modifier.size(36.dp))
        }
        Text("Chưa có người bạn nào", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        Text(
            text = "Dán ID của bạn bè vào ô phía trên, hoặc gửi ID của bạn để họ thêm bạn.",
            color = VilaColors.TextDim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        if (onInvite != null) {
            Spacer(Modifier.height(4.dp))
            ChunkyButton(text = "Mời bạn bè", onClick = onInvite, modifier = Modifier.width(200.dp), height = 44.dp, fontSize = 16.sp)
        }
    }
}

@Composable
private fun NoResults(query: String) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = VilaColors.NavIdle, modifier = Modifier.size(32.dp))
        Text("Không tìm thấy “${query.trim()}”", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text("Thử gõ tên khác nhé.", color = VilaColors.TextDim, fontSize = 13.sp)
    }
}

/** Hiệu ứng ánh sáng quét ngang cho khung xương (chỉ chạy ở pha vẽ, không recomposition). */
private fun Modifier.friendShimmer(progress: State<Float>): Modifier = this.drawBehind {
    val w = size.width.coerceAtLeast(1f)
    val x = progress.value * w * 2f - w
    drawRect(Color(0x1FFFFFFF))
    drawRect(
        brush = Brush.linearGradient(
            colors = listOf(Color.Transparent, Color(0x33FFFFFF), Color.Transparent),
            start = Offset(x, 0f),
            end = Offset(x + w * 0.6f, 0f),
        ),
    )
}

@Composable
private fun FriendSkeleton() {
    val transition = rememberInfiniteTransition(label = "friendSkeleton")
    val progress = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmer",
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        repeat(3) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(88.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(VilaColors.Glass)
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(58.dp).clip(CircleShape).friendShimmer(progress))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Box(Modifier.width(150.dp).height(14.dp).clip(RoundedCornerShape(7.dp)).friendShimmer(progress))
                    Box(Modifier.width(100.dp).height(10.dp).clip(RoundedCornerShape(5.dp)).friendShimmer(progress))
                    Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).friendShimmer(progress))
                }
                Spacer(Modifier.width(12.dp))
                Box(Modifier.width(44.dp).height(22.dp).clip(RoundedCornerShape(8.dp)).friendShimmer(progress))
            }
        }
    }
}
