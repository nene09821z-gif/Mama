package com.vila.chess.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vila.chess.billing.MembershipTier
import com.vila.chess.billing.rememberTier
import com.vila.chess.core.movePromo
import com.vila.chess.core.moveTo
import com.vila.chess.game.GameViewModel
import com.vila.chess.magic.CardUse
import com.vila.chess.magic.MagicCatalog
import com.vila.chess.magic.MagicClock
import com.vila.chess.magic.MagicState
import com.vila.chess.magic.idx
import com.vila.chess.magic.pieceNameVi
import com.vila.chess.magic.sideName
import com.vila.chess.online.ChatKind
import kotlin.math.roundToInt

/**
 * Cờ Phép Thuật: sảnh (chọn Cùng máy / Online + giờ) → ván. Ván cùng máy và online dùng chung một giao diện;
 * khác nhau ở chỗ online có đồng hồ do máy chủ tính, chat, bàn cờ xoay theo màu của bạn và chỉ thao tác được khi tới lượt.
 */
@Composable
fun MagicChessScreen(gvm: GameViewModel, onBack: () -> Unit) {
    val mvm: MagicChessViewModel = viewModel()
    val tier = rememberTier()
    LaunchedEffect(tier) { mvm.syncTier(tier) }
    var showRules by remember { mutableStateOf(false) }

    if (mvm.stage == MagicStage.PLAYING) {
        MagicPlay(gvm, mvm, tier, onBack) { showRules = true }
    } else {
        BackHandler { if (mvm.stage == MagicStage.SEARCHING) mvm.cancelOnlineSearch() else onBack() }
        Box(Modifier.fillMaxSize().background(GameScrim)) {
            MagicLobby(mvm, tier, onBack = { if (mvm.stage == MagicStage.SEARCHING) mvm.cancelOnlineSearch() else onBack() }) { showRules = true }
        }
    }

    if (showRules) MagicRulesDialog { showRules = false }
}

@Composable
private fun MagicPlay(gvm: GameViewModel, mvm: MagicChessViewModel, tier: MembershipTier, onBack: () -> Unit, onShowRules: () -> Unit) {
    mvm.tick   // đăng ký đọc để vẽ lại khi có thay đổi
    val game = mvm.game
    val s = game.s
    val online = mvm.mode == MagicMode.ONLINE
    val sideWhite = game.whiteToMove          // bên đang có lượt
    val handWhite = mvm.viewWhite             // tay bài đang hiện
    val myTurn = mvm.myTurn
    val flipped = !mvm.bottomWhite
    val images = gvm.pieceImages
    val info = mvm.endInfo()
    // 3 lá bài mở ra đầu lượt của bên đang đi (rỗng sau khi đã chọn / bỏ qua)
    val offers = if (myTurn && info == null) s.offers[idx(sideWhite)].toList() else emptyList()

    var selSq by remember { mutableIntStateOf(-1) }
    var castIdx by remember { mutableIntStateOf(-1) }
    var chosen by remember { mutableStateOf(listOf<Int>()) }
    var promo by remember { mutableStateOf<List<Int>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var showResult by remember(info != null) { mutableStateOf(info != null) }
    var confirmExit by remember { mutableStateOf(false) }
    var confirmResign by remember { mutableStateOf(false) }
    var offerSel by remember { mutableIntStateOf(-1) }
    var chatOpen by remember { mutableStateOf(false) }

    val chat = rememberChat(mvm.onlineGameId, ChatKind.MAGIC, chatOpen)

    // Thành tựu "Pháp sư cờ": đếm 1 lần khi ván phép thuật có kết quả (ván online bị hủy thì không tính).
    val achCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(info != null) {
        if (info != null && info.title != "Ván bị hủy" && !mvm.resultCounted) {
            mvm.resultCounted = true
            com.vila.chess.game.AchievementStore.get(achCtx).onMagicGame()
        }
    }

    // Đổi lượt / dựng lại ván: bỏ chọn; chuyền máy thì che bài cho người tiếp theo, online thì không cần che.
    LaunchedEffect(mvm.game, s.turnNo) {
        selSq = -1; castIdx = -1; chosen = emptyList(); offerSel = -1; message = null
        mvm.revealed = online
    }

    fun reset() { selSq = -1; castIdx = -1; chosen = emptyList(); offerSel = -1 }

    fun after(error: String? = null) {
        message = error ?: game.notice
        mvm.bump()
    }

    fun onTap(sq: Int) {
        if (info != null) return
        if (!myTurn) { message = "Chưa tới lượt bạn — đối thủ đang suy nghĩ"; return }
        if (offers.isNotEmpty()) { message = "Chọn 1 trong ${offers.size} lá bài mới (hoặc Bỏ qua) trước khi đi"; return }
        if (castIdx >= 0) {
            val c = game.card(castIdx) ?: run { reset(); return }
            if (sq in game.spellTargets(c, chosen)) {
                val next = chosen + sq
                if (next.size >= game.stepsOf(c)) {
                    val err = mvm.cast(castIdx, next)
                    reset(); after(err)
                } else chosen = next
            }
            return
        }
        if (selSq >= 0) {
            val mv = game.movesFrom(selSq).filter { moveTo(it) == sq }
            if (mv.size == 1) { selSq = -1; val err = mvm.move(mv[0]); after(err); return }
            if (mv.size > 1) { promo = mv; return }
        }
        selSq = if (s.own(sq, sideWhite) && game.movesFrom(sq).isNotEmpty()) sq else -1
    }

    BackHandler {
        when {
            castIdx >= 0 -> reset()
            chatOpen -> chatOpen = false
            online && info != null -> mvm.leaveOnline()
            else -> confirmExit = true
        }
    }

    val hand = s.hands[idx(handWhite)]
    val card = if (castIdx >= 0 && myTurn) game.card(castIdx) else null
    val targets = if (card != null) game.spellTargets(card, chosen) else emptyList()
    val legalTo = if (selSq >= 0 && card == null && myTurn) game.movesFrom(selSq).map { moveTo(it) }.toSet() else emptySet()

    // Trạng thái "dùng được / chưa dùng được + lý do" của từng lá trên tay, và của 3 lá đầu lượt (tính 1 lần mỗi thao tác).
    val handUses: List<CardUse?> = remember(mvm.tick, mvm.revealed, myTurn, info != null) {
        hand.map { id -> if (myTurn && mvm.revealed && info == null) game.usability(MagicCatalog.get(id)) else null }
    }
    val offerUses: Map<Int, CardUse> = remember(mvm.tick, offers) {
        offers.associateWith { id -> game.offerUse(MagicCatalog.get(id)) }
    }

    fun nameOf(white: Boolean): String =
        if (!online) sideName(white)
        else if (white == mvm.myWhite) "Bạn · ${sideName(white)}"
        else "${mvm.oppName} · ${sideName(white)}"

    val topWhite = flipped
    val gid = mvm.onlineGameId

    Box(Modifier.fillMaxSize().background(GameScrim)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    if (online && info != null) mvm.leaveOnline() else confirmExit = true
                }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE)) }
                Text(
                    if (online) "Phép Thuật · Online" else "Cờ Phép Thuật", color = Color.White, fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f),
                )
                if (online && gid != null) {
                    val unread = chat.unread
                    Box(Modifier.clickable { chatOpen = true }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Text("💬", fontSize = 22.sp)
                        if (unread > 0) {
                            Box(
                                Modifier.align(Alignment.TopEnd).size(16.dp).clip(CircleShape).background(VilaColors.Danger),
                                contentAlignment = Alignment.Center,
                            ) { Text(if (unread > 9) "9+" else "$unread", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold) }
                        }
                    }
                } else if (!online) {
                    TextButton(onClick = { mvm.toLobby() }) { Text("Sảnh", color = Color(0xFFB9C1CE)) }
                }
                TextButton(onClick = onShowRules) { Text("Luật chơi", color = Purple) }
            }

            if (mvm.connectionLost) {
                Text(
                    "⚠ Mất kết nối — đang thử lại…", color = Color(0xFFFFB067), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 2.dp),
                )
            }

            SideBar(s, topWhite, active = sideWhite == topWhite && info == null, name = nameOf(topWhite), mvm = mvm)
            MagicBoard(
                s = s, images = images, flipped = flipped, selSq = selSq, legalTo = legalTo,
                targets = targets.toSet(), chosen = chosen.toSet(), onTap = ::onTap,
            )
            SideBar(s, !topWhite, active = sideWhite == !topWhite && info == null, name = nameOf(!topWhite), mvm = mvm)

            // dòng trạng thái / thông báo
            val selUse = if (castIdx >= 0) handUses.getOrNull(castIdx) else null
            val hint = when {
                info != null -> info.title + (if (info.detail.isNotEmpty()) " — " + info.detail else "")
                online && !myTurn -> "⏳ Đang chờ ${mvm.oppName} đi…"
                offers.isNotEmpty() -> "🎁 Chọn 1 trong ${offers.size} lá bài mới ở giữa màn hình"
                card != null && selUse != null && !selUse.ok -> "«${card.name}»: ${selUse.reason}. Có thể «Tái chế» lá này để nhận +1 mana."
                card != null && game.stepsOf(card) > 0 -> "«${card.name}»: chạm ô sáng tím (${chosen.size + 1}/${game.stepsOf(card)})"
                card != null -> "«${card.name}»: ${card.description}"
                s.extraPending >= 0 -> "Nước đi thêm của ${sideName(sideWhite)}"
                s.turnNo < s.lockedUntil[idx(sideWhite)] -> "${if (online) "Bạn" else sideName(sideWhite)} đang bị phong ấn, không thể dùng bài"
                online -> "Lượt của bạn"
                else -> "Lượt của ${sideName(sideWhite)}"
            }
            val shownMessage = message ?: mvm.remoteNotice
            Text(
                text = shownMessage?.let { "$it\n$hint" } ?: hint,
                color = Color(0xFFD7DCE6), fontSize = 13.sp, maxLines = 4, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).height(60.dp),
            )

            // tay bài
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (!mvm.revealed) {
                    Box(
                        Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(14.dp))
                            .background(VilaColors.Panel).clickable { mvm.revealed = true },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            if (offers.isNotEmpty()) "Lượt của ${sideName(sideWhite)}\nChạm để mở ${offers.size} lá bài mới 🎁"
                            else "Lượt của ${sideName(sideWhite)}\nChạm để xem ${hand.size} lá bài",
                            color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                        )
                    }
                } else if (hand.isEmpty()) {
                    Text(
                        "Chưa có lá bài nào trên tay.\nMỗi lượt bạn được chọn 1 trong 3 lá mới.", color = VilaColors.TextDim, fontSize = 14.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.Center),
                    )
                } else {
                    LazyRow(
                        Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    ) {
                        itemsIndexed(hand) { i, id ->
                            val c = MagicCatalog.get(id)
                            HandCard(card = c, cost = game.costOf(c), selected = i == castIdx && myTurn, use = handUses.getOrNull(i)) {
                                if (info != null) return@HandCard
                                if (!myTurn) {
                                    message = "Chưa tới lượt bạn — đối thủ đang suy nghĩ"
                                } else if (offers.isNotEmpty()) {
                                    message = "Chọn 1 trong ${offers.size} lá bài mới (hoặc Bỏ qua) trước"
                                } else if (castIdx == i) {
                                    reset()
                                } else {
                                    selSq = -1; castIdx = i; chosen = emptyList()
                                    message = handUses.getOrNull(i)?.takeIf { !it.ok }?.reason
                                }
                            }
                        }
                    }
                }
            }

            // nút hành động
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val c = card
                if (info != null) {
                    if (online) {
                        ActionButton("Về sảnh", Modifier.weight(1f), primary = true) { mvm.leaveOnline() }
                    } else {
                        ActionButton("Sảnh", Modifier.weight(1f)) { mvm.toLobby() }
                        ActionButton("Ván mới", Modifier.weight(1f), primary = true) { reset(); message = null; mvm.restartLocal(tier) }
                    }
                } else if (offers.isNotEmpty() || !myTurn) {
                    if (online) ActionButton("Đầu hàng", Modifier.weight(1f)) { confirmResign = true }
                } else if (c != null) {
                    ActionButton("Hủy", Modifier.weight(1f)) { reset(); message = null }
                    if (game.stepsOf(c) == 0) {
                        ActionButton("Dùng bài (${game.costOf(c)} mana)", Modifier.weight(2f), primary = selUse?.ok == true) {
                            val err = mvm.cast(castIdx, emptyList()); reset(); after(err)
                        }
                    }
                    if (!s.recycled && s.extraPending < 0) {
                        ActionButton("♻ Tái chế +1💧", Modifier.weight(1.5f)) {
                            val at = castIdx; reset(); val err = mvm.recycle(at); after(err)
                        }
                    }
                } else {
                    ActionButton("Đầu hàng", Modifier.weight(1f)) { confirmResign = true }
                    if (!online) ActionButton("Ván mới", Modifier.weight(1f)) { reset(); message = null; mvm.restartLocal(tier) }
                }
            }
        }

        // 3 lá bài ngẫu nhiên GIỮA màn hình
        if (offers.isNotEmpty() && mvm.revealed) {
            CardOfferOverlay(
                offers = offers,
                costOf = { game.costOf(it) },
                useOf = { c -> offerUses[c.id] },
                selected = offerSel,
                onSelect = { offerSel = if (offerSel == it) -1 else it },
                onTake = { i -> val err = mvm.takeOffer(i); offerSel = -1; after(err) },
                onSkip = { val err = mvm.skipOffer(); offerSel = -1; after(err) },
            )
        }

        if (chatOpen && online && gid != null) {
            ChatPanel(chat, gid, ChatKind.MAGIC, mvm.oppName) { chatOpen = false }
        }
    }

    promo?.let { list ->
        AlertDialog(
            onDismissRequest = { promo = null },
            title = { Text("Phong cấp thành") },
            text = { Text("Chọn quân để phong cấp") },
            confirmButton = {
                Row {
                    list.forEach { m ->
                        TextButton(onClick = { promo = null; selSq = -1; val err = mvm.move(m); after(err) }) { Text(pieceNameVi(movePromo(m))) }
                    }
                }
            },
        )
    }

    if (confirmExit) AlertDialog(
        onDismissRequest = { confirmExit = false },
        title = { Text(if (online) "Thoát ván online?" else "Thoát ván?") },
        text = {
            Text(
                if (online) "Thoát lúc này bạn sẽ bị xử thua (hoặc hủy ván nếu chưa ai đi xong lượt đầu)."
                else "Ván đang chơi sẽ được giữ lại cho tới khi bạn bấm «Ván mới».",
            )
        },
        confirmButton = {
            TextButton(onClick = { confirmExit = false; if (online) mvm.leaveOnline() else onBack() }) { Text("Thoát") }
        },
        dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Ở lại") } },
    )

    if (confirmResign) AlertDialog(
        onDismissRequest = { confirmResign = false },
        title = { Text("Đầu hàng?") },
        text = { Text("Bạn sẽ thua ván này.") },
        confirmButton = {
            TextButton(onClick = {
                confirmResign = false
                reset()
                if (online) mvm.resignOnline() else mvm.resignLocal()
            }) { Text("Đầu hàng") }
        },
        dismissButton = { TextButton(onClick = { confirmResign = false }) { Text("Chơi tiếp") } },
    )

    if (info != null && showResult) AlertDialog(
        onDismissRequest = { showResult = false },
        title = { Text(info.title) },
        text = { Text(info.detail.ifEmpty { "Ván đã kết thúc." }) },
        confirmButton = {
            TextButton(onClick = {
                showResult = false
                reset()
                if (online) mvm.leaveOnline() else mvm.restartLocal(tier)
            }) { Text(if (online) "Về sảnh" else "Ván mới") }
        },
        dismissButton = { TextButton(onClick = { showResult = false }) { Text("Xem bàn cờ") } },
    )
}

@Composable
private fun MagicRulesDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Luật Cờ Phép Thuật") },
        text = {
            Text(
                "• Cờ vua bình thường, thêm bài phép. Hai bên luân phiên Trắng – Đen.\n" +
                    "• Đầu mỗi lượt: +1 mana (tối đa 10) và ${MagicCatalog.OFFER_SIZE} lá bài ngẫu nhiên hiện GIỮA màn hình — chọn 1 lá vào tay (cầm tối đa 7) hoặc bỏ qua để nhận +1 mana. Lá thường luôn có mục tiêu dùng được ngay ở thế cờ hiện tại.\n" +
                    "• Mỗi lượt dùng tối đa 1 bài (trừ bài «Thần Tốc»), rồi đi 1 nước cờ. Dùng bài cần đủ mana.\n" +
                    "• Lá nào chưa có mục tiêu: chạm vào để xem lý do, hoặc «Tái chế» (♻) để bỏ lá và nhận +1 mana (mỗi lượt 1 lá).\n" +
                    "• Nhãn lá bài: LOẠI (Triệu hồi, Tấn công, Phòng thủ, Khống chế, Cơ động, Năng lượng, May rủi, Tuyệt kỹ) · ĐỘ HIẾM (số viên ngọc: Thường → Huyền thoại) · ★ Gói VIP.\n" +
                    "• Gói VIP luôn có ít nhất 1 lá đặc quyền ★ trong số các lá mở ra; có cả «Tuyệt kỹ» mạnh hơn mua rời. Ván online dùng bộ bài thường để công bằng.\n" +
                    "• Bài 🎉 may rủi (xúc xắc, đồng xu, mũ ảo thuật…) có kết quả ngẫu nhiên — ai cũng có thể gặp.\n" +
                    "• Phép không được để Vua bạn bị chiếu hoặc mất Vua.\n" +
                    "• Quân bị đóng băng không đi được; quân có khiên không bị ăn; bẫy diệt quân địch bước vào.\n" +
                    "• Đồng hồ: chọn ở sảnh. Hết giờ là thua; online do máy chủ tính giờ.\n" +
                    "• Cùng máy: sau mỗi lượt bài được che — chạm để xem. Có thể bật «Tự xoay bàn».\n" +
                    "• Thắng bằng chiếu hết như cờ vua.",
            )
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Đã hiểu") } },
    )
}

@Composable
private fun ClockChip(mvm: MagicChessViewModel, white: Boolean, active: Boolean) {
    mvm.clockTick   // đăng ký đọc để chỉ ô đồng hồ vẽ lại ~5 lần/giây
    val ms = mvm.clockMs(white)
    if (ms < 0L) return
    val low = ms <= 10_000L
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                when {
                    !active -> Color(0xFF3A3834)
                    low -> Color(0xFF8A2B2B)
                    else -> Color(0xFF3F6B2C)
                },
            )
            .padding(horizontal = 10.dp, vertical = 3.dp),
    ) {
        Text(MagicClock.format(ms), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1)
    }
}

@Composable
private fun SideBar(s: MagicState, white: Boolean, active: Boolean, name: String, mvm: MagicChessViewModel) {
    val i = idx(white)
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (active) VilaColors.Green else Color(0xFF55524D)))
        Spacer(Modifier.width(8.dp))
        Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text("💧 ${s.mana[i]}/${MagicState.MANA_MAX}", color = Color(0xFF7CC4FF), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.width(10.dp))
        Text("🃏 ${s.hands[i].size}", color = Color(0xFFD7DCE6), fontWeight = FontWeight.Bold, fontSize = 15.sp)
        if (mvm.clockOn) {
            Spacer(Modifier.width(10.dp))
            ClockChip(mvm, white, active)
        }
    }
}

@Composable
private fun ActionButton(label: String, modifier: Modifier, primary: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.height(44.dp).clip(RoundedCornerShape(10.dp))
            .background(if (primary) VilaColors.Green else VilaColors.PanelRaised).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1) }
}

@Composable
private fun MagicBoard(
    s: MagicState,
    images: Array<androidx.compose.ui.graphics.ImageBitmap?>,
    flipped: Boolean,
    selSq: Int,
    legalTo: Set<Int>,
    targets: Set<Int>,
    chosen: Set<Int>,
    onTap: (Int) -> Unit,
) {
    val measurer = rememberTextMeasurer()
    Canvas(
        Modifier.fillMaxWidth().aspectRatio(1f).pointerInput(flipped) {
            detectTapGestures { o ->
                val cell = size.width / 8f
                val col = (o.x / cell).toInt().coerceIn(0, 7)
                val row = (o.y / cell).toInt().coerceIn(0, 7)
                onTap(if (flipped) row * 8 + (7 - col) else (7 - row) * 8 + col)
            }
        },
    ) {
        val cell = size.width / 8f
        val tag = TextStyle(fontSize = (cell * 0.3f).toSp())
        for (sq in 0 until 64) {
            val file = sq and 7
            val rank = sq shr 3
            val x = (if (flipped) 7 - file else file) * cell
            val y = (if (flipped) rank else 7 - rank) * cell
            val light = (file + rank) % 2 == 1
            drawRect(if (light) VilaColors.BoardLight else VilaColors.BoardDark, Offset(x, y), Size(cell, cell))
            if (sq == selSq) drawRect(VilaColors.Highlight, Offset(x, y), Size(cell, cell))
            if (sq in chosen) drawRect(Purple.copy(alpha = 0.55f), Offset(x, y), Size(cell, cell))
            if (s.isFrozen(sq)) drawRect(Color(0x663FA9F5), Offset(x, y), Size(cell, cell))
            val piece = s.pos.board[sq]
            if (piece != 0) {
                val img = images.getOrNull(piece)
                if (img != null) drawImage(
                    img, srcOffset = IntOffset.Zero, srcSize = IntSize(img.width, img.height),
                    dstOffset = IntOffset(x.roundToInt(), y.roundToInt()), dstSize = IntSize(cell.roundToInt(), cell.roundToInt()),
                )
            }
            if (s.isShielded(sq)) drawCircle(Color(0xFFF2B134), radius = cell * 0.46f, center = Offset(x + cell / 2, y + cell / 2), style = Stroke(cell * 0.06f))
            if (s.isFrozen(sq)) drawText(measurer.measure("❄️", tag), topLeft = Offset(x + cell * 0.02f, y))
            if (s.trapAt(sq) != null) drawText(measurer.measure("🕳️", tag), topLeft = Offset(x + cell * 0.62f, y + cell * 0.6f))
            if (sq in legalTo) drawCircle(
                Color(0x66000000), radius = if (piece == 0) cell * 0.16f else cell * 0.45f, center = Offset(x + cell / 2, y + cell / 2),
                style = if (piece == 0) androidx.compose.ui.graphics.drawscope.Fill else Stroke(cell * 0.08f),
            )
            if (sq in targets) drawCircle(Purple, radius = cell * 0.4f, center = Offset(x + cell / 2, y + cell / 2), style = Stroke(cell * 0.09f))
        }
    }
}
