package com.vila.chess.magic

import com.vila.chess.core.EMPTY
import com.vila.chess.core.KING
import com.vila.chess.core.PAWN
import com.vila.chess.core.pieceType
import com.vila.chess.core.sqRank

/** Vì sao một lá bài dùng được / chưa dùng được ở thời điểm này. */
enum class UseState { READY, NO_MANA, LOCKED, USED, EXTRA, NO_TARGET, ENDED }

class CardUse(val state: UseState, val reason: String) {
    val ok: Boolean get() = state == UseState.READY
}

/**
 * Kiểm tra "lá bài này có dùng được trên bàn cờ lúc này không" mà KHÔNG làm đổi ván và KHÔNG tiêu thụ bộ ngẫu nhiên của ván
 * (mọi lần thử chạy trên bản sao có bộ ngẫu nhiên riêng). Dùng cho: tô sáng lá dùng được, giải thích lý do chưa dùng được,
 * và chọn 3 lá đầu lượt sao cho lá thường nào cũng có mục tiêu.
 */
object MagicUse {
    /** Số lần thử tối đa cho một lá; hết hạn mức thì coi như dùng được (tránh treo máy ở thế cờ nhiều khả năng). */
    private const val BUDGET = 600
    /** Số lần bốc lại tối đa cho mỗi ô trong 3 lá đầu lượt. */
    private const val REPLACE_TRIES = 12

    /** Thế cờ sau phép: mỗi bên đúng 1 Vua, không có Tốt ở hàng cuối, Vua của người dùng bài không bị chiếu. Giống luật của [MagicGame]. */
    fun validPosition(st: MagicState, casterWhite: Boolean): Boolean {
        var whiteKings = 0
        var blackKings = 0
        for (sq in 0 until 64) {
            val p = st.pos.board[sq]
            if (p == EMPTY) continue
            val t = pieceType(p)
            if (t == KING) {
                if (p <= 6) whiteKings++ else blackKings++
            }
            if (t == PAWN && (sqRank(sq) == 0 || sqRank(sq) == 7)) return false
        }
        return whiteKings == 1 && blackKings == 1 && !st.pos.inCheck(casterWhite)
    }

    /** Có ít nhất một cách dùng [card] hợp lệ ở thế [st] cho bên [white] (bỏ qua mana và giới hạn 1 bài mỗi lượt). */
    fun feasible(st: MagicState, white: Boolean, card: MagicCard): Boolean =
        feasibleEffect(st, white, card.id, card.effect)

    private fun feasibleEffect(st: MagicState, white: Boolean, cardId: Int, effect: MagicEffect): Boolean {
        val picks = effect.picks
        val budget = IntArray(1)
        budget[0] = BUDGET

        fun trial(targets: List<Int>): Boolean {
            budget[0] = budget[0] - 1
            val c = st.copy(MagicRandom(1L))
            val hand = c.hands[idx(white)]
            val at = hand.indexOf(cardId)
            if (at >= 0) hand.removeAt(at)
            return effect.apply(c, white, targets) && validPosition(c, white)
        }

        fun search(chosen: List<Int>): Boolean {
            if (chosen.size == picks.size) return trial(chosen)
            val cands = effect.candidates(st, white, chosen.size, chosen)
            for (sq in cands) {
                if (budget[0] <= 0) return true
                if (search(chosen + sq)) return true
            }
            return false
        }

        return search(emptyList())
    }

    /**
     * Sau khi mở 3 lá đầu lượt: lá THƯỜNG nào chưa có mục tiêu thì bốc lại (tối đa [REPLACE_TRIES] lần) để ra lá dùng được.
     * Lá đặc quyền ★ giữ nguyên (luật "gói VIP luôn có ít nhất 1 lá ★"). Đang bị chiếu thì không chỉnh (hầu hết bài đều không giải được chiếu).
     */
    fun refineOffers(st: MagicState, white: Boolean) {
        val offer = st.offers[idx(white)]
        if (offer.isEmpty() || st.pos.inCheck(white)) return
        for (i in offer.indices) {
            val id = offer[i]
            if (id >= MagicCatalog.size) continue
            if (feasible(st, white, MagicCatalog.get(id))) continue
            var tries = 0
            while (tries < REPLACE_TRIES) {
                tries++
                val cand = MagicCatalog.randomNormalId(st.rng)
                if (cand in offer) continue
                if (feasible(st, white, MagicCatalog.get(cand))) {
                    offer[i] = cand
                    break
                }
            }
        }
    }

    /** Lý do bằng tiếng Việt khi [feasible] = false. */
    fun whyNot(st: MagicState, white: Boolean, card: MagicCard): String {
        if (st.pos.inCheck(white)) return "Vua đang bị chiếu — bài này không hóa giải được"
        val e = card.effect
        val parts: List<MagicEffect> = if (e is Combo) e.partsForTest() else listOf(e)
        for (p in parts) {
            if (!feasibleEffect(st, white, -1, p)) return hint(p)
        }
        return "Các phần của bài này cần mục tiêu mà bàn cờ chưa có"
    }

    private fun hint(e: MagicEffect): String = when (e) {
        is Spawn -> "Không còn ô trống phù hợp để triệu hồi"
        is Smite -> "Không có quân địch phù hợp để thiêu"
        is Lightning -> "Không có quân địch nào trên cột nào bị sét đánh được"
        is Demote -> "Không có quân địch loại này để giáng cấp"
        is Charm -> "Không có quân địch phù hợp để mê hoặc"
        is Freeze -> "Không có quân địch phù hợp để đóng băng"
        is Push -> "Không có quân địch nào đẩy được theo hướng này"
        is Swap -> "Chưa có đủ 2 quân phù hợp để hoán vị"
        is Promote -> "Bạn không có Tốt để thăng cấp"
        is Shield -> "Bạn không có quân phù hợp để che khiên"
        is Teleport -> "Không có quân phù hợp hoặc ô trống trong tầm dịch chuyển"
        is Clone -> "Không có quân phù hợp hoặc ô trống kề bên để phân thân"
        is Mirror -> "Ô đối xứng qua giữa bàn đang bị chiếm"
        is Resurrect -> "Bạn chưa mất quân nào phù hợp để hồi sinh"
        is KingBlink -> "Không có ô trống an toàn cho Vua"
        is Trap -> "Không còn ô trống để đặt bẫy"
        is ExtraMove -> "Bạn đã có nước đi thêm đang chờ"
        is PawnStorm -> "Không có Tốt nào tiến lên được"
        is Discard -> "Đối thủ không còn bài trên tay"
        is ManaDrain -> "Đối thủ đã hết mana"
        is DrawCards -> "Tay bài của bạn đã đầy"
        is LuckyWheel -> "Cần có quân địch và quân của bạn (không tính Vua)"
        is MagicHat -> "Không còn ô trống ở nửa bàn phía bạn (hàng 2–7)"
        is Meteor -> "Đối thủ không còn Tốt nào"
        is CoinFlip -> "Không có quân địch (ngoài Vua) để làm mục tiêu"
        else -> "Chưa có mục tiêu phù hợp trên bàn cờ"
    }
}
