package com.vila.chess.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.billing.MembershipTier
import com.vila.chess.game.TimeControls
import com.vila.chess.game.timeGroups
import com.vila.chess.magic.MagicCatalog
import kotlinx.coroutines.delay

private val MAGIC_LOBBY_SHAPE = RoundedCornerShape(12.dp)

/**
 * Sảnh Cờ Phép Thuật: chọn chế độ (Cùng máy / Online) và BẢNG CHỌN GIỜ, rồi vào ván.
 * Cùng máy: có cả "Không giới hạn". Online: ghép trận với người thật, đồng hồ do máy chủ tính, hai bên luân phiên Trắng – Đen.
 */
@Composable
fun MagicLobby(vm: MagicChessViewModel, tier: MembershipTier, onBack: () -> Unit, onShowRules: () -> Unit) {
    val searching = vm.stage == MagicStage.SEARCHING
    val online = vm.lobbyMode == MagicMode.ONLINE
    val timeIndex = if (online) vm.onlineTimeIndex else vm.localTimeIndex
    val tc = TimeControls.get(timeIndex)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(searching) {
        while (searching) {
            now = System.currentTimeMillis()
            delay(500L)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Box(Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Quay lại", tint = Color(0xFFB9C1CE))
            }
            Text("🪄 Cờ Phép Thuật", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.align(Alignment.Center))
            Text(
                "Luật chơi", color = Purple, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 14.dp).clickable(onClick = onShowRules),
            )
        }

        // Chế độ
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ModePill("👥 Cùng máy", !online, !searching, Modifier.weight(1f)) { vm.lobbyMode = MagicMode.LOCAL }
            ModePill("🌐 Online", online, !searching, Modifier.weight(1f)) { vm.lobbyMode = MagicMode.ONLINE }
        }

        Text(
            text = if (online) {
                "Ghép trận với người chơi thật. Hai bên luân phiên Trắng – Đen, mỗi lượt mở 3 lá bài ngẫu nhiên. Đồng hồ do máy chủ tính nên luôn khớp giờ. Cần đăng nhập Google. Ván online dùng bộ bài thường để công bằng."
            } else {
                "2 người chơi chung 1 máy, luân phiên Trắng – Đen. Mỗi lượt +1 mana, mở 3 lá bài ngẫu nhiên chọn 1, dùng tối đa 1 phép rồi đi 1 nước. Kho ${MagicCatalog.size} lá" +
                    (if (tier != MembershipTier.FREE) " + ${MagicCatalog.exclusiveFor(tier).size} bài đặc quyền ★ của gói ${tier.displayName}." else ".")
            },
            color = VilaColors.TextDim,
            fontSize = 14.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 12.dp),
        )

        if (searching) {
            val elapsed = ((now - vm.searchStartedAt) / 1000L).coerceAtLeast(0L)
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp).glass(MAGIC_LOBBY_SHAPE).padding(vertical = 28.dp, horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                CircularProgressIndicator(color = VilaColors.Green, modifier = Modifier.size(44.dp), strokeWidth = 4.dp)
                Text("Đang tìm đối thủ…", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    tc.label + "  ·  " + (elapsed / 60) + ":" + (if (elapsed % 60 < 10) "0" else "") + (elapsed % 60),
                    color = VilaColors.TextDim, fontSize = 15.sp,
                )
            }
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(47.dp).glass(MAGIC_LOBBY_SHAPE).clickable { vm.cancelOnlineSearch() },
                contentAlignment = Alignment.Center,
            ) { Text("Hủy tìm trận", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        } else {
            // Bảng chọn giờ
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp).glass(MAGIC_LOBBY_SHAPE).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text("⏱ Chọn giờ", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                for (group in timeGroups()) {
                    val mode = group.first
                    val indices = group.second.filter { online.not() || TimeControls.all[it].baseSec > 0 }
                    if (indices.isEmpty()) continue
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            ModeIcon(mode, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(mode.label, color = VilaColors.TextDim, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        ChipGrid(
                            labels = indices.map { TimeControls.all[it].label },
                            selected = indices.indexOf(timeIndex),
                            columns = 3,
                            onSelect = { k -> if (online) vm.onlineTimeIndex = indices[k] else vm.localTimeIndex = indices[k] },
                        )
                    }
                }
            }

            if (!online) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                        .glass(MAGIC_LOBBY_SHAPE)
                        .clickable { vm.autoFlip = !vm.autoFlip }
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Tự xoay bàn theo lượt", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("Bên đang đi luôn ở phía dưới màn hình", color = VilaColors.TextDim, fontSize = 12.sp)
                    }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (vm.autoFlip) VilaColors.Green else VilaColors.PanelRaised)
                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(50))
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                    ) { Text(if (vm.autoFlip) "BẬT" else "TẮT", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }

            val error = vm.lobbyError
            if (error != null) {
                Text(
                    text = error, color = VilaColors.Danger, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 12.dp),
                )
            }

            ChunkyButton(
                text = if (online) "Tìm đối thủ · " + tc.label else "Bắt đầu · " + tc.label,
                onClick = { if (online) vm.startOnlineSearch() else vm.startLocal(tier) },
                modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 16.dp),
                height = 52.dp,
                edge = 4.dp,
                radius = 10.dp,
                fontSize = 20.sp,
            )

            if (!online && vm.hasLocalGame) {
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).height(47.dp).glass(MAGIC_LOBBY_SHAPE).clickable { vm.resumeLocal() },
                    contentAlignment = Alignment.Center,
                ) { Text("Tiếp tục ván đang chơi", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ModePill(label: String, selected: Boolean, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .height(46.dp)
            .clip(shape)
            .background(if (selected) VilaColors.Green.copy(alpha = 0.2f) else Color(0x66101C33))
            .border(if (selected) 1.5.dp else 1.dp, if (selected) VilaColors.Green else Color(0x26FFFFFF), shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Color.White else VilaColors.TextDim, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
    }
}
