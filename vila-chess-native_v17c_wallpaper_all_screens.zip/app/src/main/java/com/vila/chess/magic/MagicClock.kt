package com.vila.chess.magic

import java.util.Locale

/**
 * Đồng hồ Cờ Phép Thuật (hàm thuần, không Android) — dùng cho ván cùng máy; ván online dùng giờ do máy chủ tính
 * và chỉ dùng [format] để hiển thị. [baseSec] = 0 nghĩa là không giới hạn giờ.
 *
 * Chỉ bên đang có lượt bị trừ giờ. Giờ thưởng ([incSec]) cộng cho bên vừa kết thúc lượt.
 */
class MagicClock(baseSec: Int, incSec: Int) {
    val enabled: Boolean = baseSec > 0
    private val incMs: Long = incSec.coerceAtLeast(0) * 1000L

    /** Giờ còn lại (ms) của Trắng (0) và Đen (1). */
    val ms: LongArray = longArrayOf(baseSec.coerceAtLeast(0) * 1000L, baseSec.coerceAtLeast(0) * 1000L)

    /** Trừ [deltaMs] của bên [side] (0 = Trắng, 1 = Đen). Trả true nếu bên đó vừa hết giờ. */
    fun tick(side: Int, deltaMs: Long): Boolean {
        if (!enabled || side !in 0..1 || deltaMs <= 0L) return enabled && side in 0..1 && ms[side] <= 0L
        ms[side] = (ms[side] - deltaMs).coerceAtLeast(0L)
        return ms[side] <= 0L
    }

    /** Cộng giờ thưởng cho bên vừa kết thúc lượt. */
    fun addIncrement(side: Int) {
        if (!enabled || side !in 0..1) return
        ms[side] += incMs
    }

    fun isFlagged(side: Int): Boolean = enabled && side in 0..1 && ms[side] <= 0L

    companion object {
        /** 125000 -> "2:05"; dưới 10 giây hiện thêm phần mười ("0:07.4"); không giới hạn (ms < 0) -> "∞". */
        fun format(ms: Long): String {
            if (ms < 0L) return "∞"
            val total = ms / 1000L
            if (total < 10L) return String.format(Locale.US, "0:%02d.%d", total, (ms % 1000L) / 100L)
            val m = total / 60L
            val s = total % 60L
            return if (m >= 60L) String.format(Locale.US, "%d:%02d:%02d", m / 60L, m % 60L, s) else String.format(Locale.US, "%d:%02d", m, s)
        }
    }
}
