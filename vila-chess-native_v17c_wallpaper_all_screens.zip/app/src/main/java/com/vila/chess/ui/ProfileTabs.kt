package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =============================================================================
// Hai tab của màn Hồ sơ: "Thành tựu" (lưới huy hiệu) và "Bạn bè" (tìm kiếm + danh sách).
// Tab Thành tựu nằm ở AchievementsUi.kt (30 thành tựu thật, lưu bởi AchievementStore).
// Dữ liệu bạn bè: giả lập (chưa có backend trạng thái online/Elo bạn bè).
// =============================================================================

data class Friend(val id: String, val name: String, val elo: Int, val isOnline: Boolean)

private val GoldGlow = Color(0xFFFFC83D)
private val AquaGlow = Color(0xFF4FD1C5)
private val OfflineGray = Color(0xFF7D8696)

val MockFriends: List<Friend> = listOf(
    Friend("f1", "Minh Khoa", 1432, true),
    Friend("f2", "Lan Anh", 1187, false),
    Friend("f3", "Hoàng Long", 1650, true),
    Friend("f4", "Thu Trang", 905, false),
    Friend("f5", "Quốc Bảo", 1320, true),
    Friend("f6", "Gia Hân", 1010, false),
    Friend("f7", "Đức Anh", 1544, true),
)

// ------------------------------------------------------------------ Tab: Bạn bè

@Composable
fun FriendsTab(friends: List<Friend>, onChallenge: (Friend) -> Unit, modifier: Modifier = Modifier) {
    var query by rememberSaveable { mutableStateOf("") }
    val shown = remember(friends, query) {
        val q = query.trim()
        if (q.isEmpty()) friends else friends.filter { it.name.contains(q, ignoreCase = true) }
    }
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it.take(30) },
            singleLine = true,
            placeholder = { Text("Tìm bạn bè", color = VilaColors.TextDim) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = VilaColors.TextDim) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Clear, contentDescription = "Xóa", tint = VilaColors.TextDim) }
                }
            },
            shape = RoundedCornerShape(50),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = VilaColors.Green, unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = VilaColors.Green,
                focusedContainerColor = Color(0x14FFFFFF), unfocusedContainerColor = Color(0x14FFFFFF),
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        )
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (shown.isEmpty()) {
                item(key = "empty", contentType = "empty") {
                    Text(
                        "Không tìm thấy bạn bè phù hợp.", color = VilaColors.TextDim, fontSize = 14.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp),
                    )
                }
            } else {
                items(shown, key = { it.id }, contentType = { "friend" }) { f -> FriendRow(f, onChallenge = { onChallenge(f) }) }
            }
        }
    }
}

@Composable
private fun FriendRow(f: Friend, onChallenge: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(VilaColors.Glass).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Avatar + viền (xanh = online, xám = offline) + chấm xanh ở góc khi online.
        Box(Modifier.size(52.dp)) {
            ProfileAvatar(
                name = f.name, avatarKey = "", size = 48.dp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .border(2.dp, if (f.isOnline) VilaColors.Green else OfflineGray, CircleShape),
            )
            if (f.isOnline) {
                Box(
                    Modifier.align(Alignment.BottomEnd).size(14.dp)
                        .clip(CircleShape).background(VilaColors.Green)
                        .border(2.dp, Color(0xFF16233B), CircleShape),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Elo ${f.elo}", color = VilaColors.TextDim, fontSize = 13.sp)
        }
        if (f.isOnline) {
            Button(
                onClick = onChallenge,
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = VilaColors.Green, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp),
                modifier = Modifier.height(36.dp),
            ) { Text("Thách đấu", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold) }
        } else {
            Text("Offline", color = OfflineGray, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
