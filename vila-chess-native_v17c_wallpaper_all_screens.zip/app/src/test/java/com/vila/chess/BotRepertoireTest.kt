package com.vila.chess

import com.vila.chess.bots.BotRepertoire
import com.vila.chess.bots.BotRepository
import com.vila.chess.core.Position
import com.vila.chess.core.moveUci
import com.vila.chess.review.OpeningBook
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class BotRepertoireTest {
    private val rep = BotRepertoire.fromRows(OpeningBook.BUILT_IN)

    @Test
    fun builtInLinesParse() {
        assertTrue("chỉ parse được ${rep.lineCount} dòng", rep.lineCount >= 40)
    }

    @Test
    fun weightsAreNormalisedAndLegalFirstMoves() {
        val legal = Position.start().legalMoves().map { moveUci(it) }.toSet()
        for (bot in BotRepository.bots) {
            val pref = rep.preferences(bot, emptyList())
            assertTrue(bot.name, pref.isNotEmpty())
            assertEquals(1.0, pref.values.sum(), 1e-9)
            assertTrue(bot.name, legal.containsAll(pref.keys))
        }
    }

    @Test
    fun botsHaveDifferentTastes() {
        val martin = BotRepository.getById("martin")!!
        val magnus = BotRepository.getById("magnus")!!
        assertNotEquals(rep.preferences(martin, emptyList()), rep.preferences(magnus, emptyList()))
        // Cố định: hỏi lại ra đúng kết quả cũ.
        assertEquals(rep.preferences(martin, emptyList()), rep.preferences(martin, emptyList()))
    }

    @Test
    fun strongerBotsFollowBookDeeper() {
        val martin = BotRepository.getById("martin")!!
        val mittens = BotRepository.getById("mittens")!!
        assertTrue(rep.maxBookPlies(martin) < rep.maxBookPlies(mittens))
        assertTrue(rep.forgetChance(martin) > rep.forgetChance(mittens))
        assertTrue(rep.preferences(martin, List(rep.maxBookPlies(martin)) { "a2a3" }).isEmpty())
    }

    @Test
    fun twoBotsPlayOnlyLegalBookMoves() {
        val rnd = Random(12345)
        val white = BotRepository.getById("hiro")!!
        val black = BotRepository.getById("lena")!!
        repeat(20) {
            val gw = rep.newGame(white)
            val gb = rep.newGame(black)
            val pos = Position.start()
            val hist = ArrayList<String>()
            var plies = 0
            while (plies < 40) {
                val g = if (pos.whiteToMove) gw else gb
                val mv = g.next(hist, rnd) ?: break
                val legal = pos.legalMoves().firstOrNull { moveUci(it) == mv }
                assertTrue("nước sách không hợp lệ: $mv sau $hist", legal != null)
                pos.make(legal!!)
                hist += mv
                plies++
            }
            assertTrue(plies >= 1)
        }
    }

    @Test
    fun leavesBookWhenOpponentDeviates() {
        val bot = BotRepository.getById("magnus")!!
        val g = rep.newGame(bot)
        // 1. a3 a6 2. h3 ... không nằm trong sách -> null và ở lại ngoài sách
        assertEquals(null, g.next(listOf("a2a3", "a7a6", "h2h3", "h7h6", "g2g3", "g7g6", "b2b3", "b7b6", "c2c3", "c7c6", "d2d3", "d7d6")))
        assertEquals(null, g.next(emptyList()))
    }
}
