package com.vila.chess

import com.vila.chess.game.Sfx
import com.vila.chess.game.SoundPacks
import com.vila.chess.ui.BoardThemes
import com.vila.chess.ui.Wallpapers
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class AppearanceTest {

    @Test
    fun boardThemesHaveUniqueIdsAndTwoDifferentColors() {
        val ids = BoardThemes.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(BoardThemes.exists(BoardThemes.DEFAULT))
        for (t in BoardThemes.all) assertNotEquals("${t.id}: ô sáng = ô tối", t.light, t.dark)
        assertTrue(BoardThemes.all.size >= 15)
    }

    @Test
    fun unknownThemeFallsBackToFirst() {
        assertEquals(BoardThemes.all[0], BoardThemes.byId("khong-co"))
    }

    @Test
    fun soundPacksUniqueAndDefaultExists() {
        val ids = SoundPacks.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(SoundPacks.exists(SoundPacks.DEFAULT))
        assertEquals("move", SoundPacks.rawName("classic", Sfx.MOVE))
        assertEquals("gameend", SoundPacks.rawName("classic", Sfx.END))
        assertEquals("wood_capture", SoundPacks.rawName("wood", Sfx.CAPTURE))
    }

    /** Mọi (bộ × tiếng) đều phải có file wav thật trong res/raw (thiếu file = im lặng khi chọn bộ đó). */
    @Test
    fun everySoundPackHasAllSixFiles() {
        val raw = listOf("src/main/res/raw", "app/src/main/res/raw").map { File(it) }.firstOrNull { it.isDirectory }
            ?: return   // chạy từ thư mục lạ: bỏ qua thay vì làm CI đỏ oan
        for (p in SoundPacks.all) for (sfx in Sfx.values()) {
            val f = File(raw, SoundPacks.rawName(p.id, sfx) + ".wav")
            assertTrue("thiếu ${f.name}", f.isFile && f.length() > 100)
        }
    }

    /** Lưới Chủ đề có 5 cột: số màu bàn cờ chia hết cho 5 để hàng cuối không bị lẻ. */
    @Test
    fun boardThemeCountFillsFiveColumnGrid() {
        assertEquals(0, BoardThemes.all.size % 5)
        assertTrue(BoardThemes.exists("bubblegum"))
    }

    @Test
    fun wallpapersUniqueAndDefaultFirst() {
        val ids = Wallpapers.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertEquals(Wallpapers.DEFAULT, Wallpapers.all[0].id)
        assertTrue(Wallpapers.all.any { it.animated })   // có nền động (Ngân hà)
        assertTrue(!Wallpapers.all[0].animated)          // mặc định là nền tĩnh nhẹ
        assertEquals(Wallpapers.all.size, Wallpapers.all.map { it.label }.toSet().size)
    }

    @Test
    fun unknownWallpaperFallsBackToFirst() {
        assertEquals(Wallpapers.all[0], Wallpapers.byId("khong-co"))
        assertTrue(!Wallpapers.exists("khong-co"))
    }
}
