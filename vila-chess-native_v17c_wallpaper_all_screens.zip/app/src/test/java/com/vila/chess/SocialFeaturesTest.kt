package com.vila.chess

import com.vila.chess.magic.MagicActions
import com.vila.chess.magic.MagicCatalog
import com.vila.chess.magic.MagicClock
import com.vila.chess.magic.MagicRandom
import com.vila.chess.online.ChatLogic
import com.vila.chess.online.ChatMessage
import com.vila.chess.review.LabelEvidence
import com.vila.chess.review.MoveLabel
import java.util.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Test cho phần mới: đồng hồ Cờ Phép Thuật, bộ ngẫu nhiên tất định, mã hóa hành động online, chat, lớp độ tin cậy của nhãn. */
class SocialFeaturesTest {
    @Test
    fun clockFormatsTimes() {
        assertEquals("2:05", MagicClock.format(125_000L))
        assertEquals("0:07.4", MagicClock.format(7_400L))
        assertEquals("1:02:05", MagicClock.format(3_725_000L))
        assertEquals("∞", MagicClock.format(-1L))
    }

    @Test
    fun clockTicksOnlyTheGivenSideAndFlagsAtZero() {
        val c = MagicClock(60, 2)
        assertFalse(c.tick(0, 10_000L))
        assertEquals(50_000L, c.ms[0])
        assertEquals(60_000L, c.ms[1])
        c.addIncrement(0)
        assertEquals(52_000L, c.ms[0])
        assertTrue(c.tick(1, 61_000L))
        assertEquals(0L, c.ms[1])
        assertTrue(c.isFlagged(1))
        assertFalse(MagicClock(0, 0).enabled)
    }

    @Test
    fun magicRandomMatchesJavaRandomAndCopiesIndependently() {
        val a = MagicRandom(12345L)
        val b = Random(12345L)
        repeat(20) { assertEquals(b.nextInt(1000), a.nextInt(1000)) }
        val copy = a.copyState()
        val x = a.nextInt(1_000_000)
        assertEquals(x, copy.nextInt(1_000_000))
        a.nextInt(10)
        // bản sao không bị ảnh hưởng bởi việc a đi tiếp
        val y = copy.nextInt(1_000_000)
        val ref = MagicRandom(12345L)
        repeat(20) { ref.nextInt(1000) }
        ref.nextInt(1_000_000)
        assertEquals(ref.nextInt(1_000_000), y)
    }

    @Test
    fun actionCodecValidatesAndRoundTrips() {
        assertEquals("o1", MagicActions.take(1))
        assertEquals("c2:12,40", MagicActions.cast(2, listOf(12, 40)))
        assertEquals("c0:", MagicActions.cast(0, emptyList()))
        assertTrue(MagicActions.isValid("me2e4"))
        assertTrue(MagicActions.isValid("me7e8q"))
        assertTrue(MagicActions.isValid("s"))
        assertTrue(MagicActions.isValid("r3"))
        assertTrue(MagicActions.isValid("c2:12,40"))
        assertTrue(MagicActions.isValid("c0:"))
        assertFalse(MagicActions.isValid("cx"))
        assertFalse(MagicActions.isValid("mz9z9"))
        assertFalse(MagicActions.isValid(""))
        assertFalse(MagicActions.isValid("o12"))
    }

    @Test
    fun replayIsDeterministicEvenWhenOneSideQueriesUsability() {
        val actions = listOf("o0", "me2e4", "s", "me7e5")
        val seed = 424242L
        val a = MagicActions.replay(seed, actions)
        val b = MagicActions.replay(seed, actions)
        assertNull(a.error)
        assertNull(b.error)
        assertEquals(actions.size, a.applied)
        assertEquals(b.game.s.hands[0], a.game.s.hands[0])
        assertEquals(b.game.s.hands[1], a.game.s.hands[1])
        assertEquals(b.game.s.offers[0], a.game.s.offers[0])
        assertEquals(b.game.s.offers[1], a.game.s.offers[1])
        assertEquals(b.game.s.mana[0], a.game.s.mana[0])
        assertEquals(b.game.s.mana[1], a.game.s.mana[1])

        // Hỏi "lá nào dùng được" (chạy thử trên bản sao) không được làm trôi dãy ngẫu nhiên của ván thật.
        val c = MagicActions.replay(seed, listOf("o0"))
        val d = MagicActions.replay(seed, listOf("o0"))
        for (id in c.game.s.hands[0].toList()) c.game.usability(MagicCatalog.get(id))
        assertNull(MagicActions.apply(c.game, "me2e4"))
        assertNull(MagicActions.apply(d.game, "me2e4"))
        assertEquals(d.game.s.offers[1], c.game.s.offers[1])
        assertEquals(d.game.s.hands[1], c.game.s.hands[1])
    }

    @Test
    fun recycleGivesOneManaOncePerTurn() {
        val g = MagicActions.replay(7L, listOf("o0")).game
        val before = g.s.mana[0]
        val handBefore = g.s.hands[0].size
        assertNull(g.recycle(0))
        assertEquals(minOf(10, before + 1), g.s.mana[0])
        assertEquals(handBefore - 1, g.s.hands[0].size)
        assertTrue(g.recycle(0) != null)
    }

    @Test
    fun chatLogicCleansAndMerges() {
        assertEquals("hi there", ChatLogic.clean("  hi   there \n"))
        assertEquals("", ChatLogic.clean("   \n  "))
        assertEquals(ChatLogic.MAX_LEN, ChatLogic.clean("x".repeat(500)).length)
        val m1 = ChatMessage(1, "a", "A", "x", 10)
        val m2 = ChatMessage(2, "b", "B", "y", 20)
        val merged = ChatLogic.merge(listOf(m2), listOf(m1, m2))
        assertEquals(listOf(1L, 2L), merged.map { it.id })
        assertEquals(2L, ChatLogic.lastId(merged))
        assertEquals(1, ChatLogic.unread(merged, "a", 0L))
        assertEquals(0, ChatLogic.unread(merged, "a", 2L))
        assertTrue(ChatLogic.QUICK_REPLIES.isNotEmpty())
    }

    @Test
    fun shallowEngineSoftensHeavyLabelsButDeepOrMateKeepsThem() {
        assertEquals(MoveLabel.BLUNDER, LabelEvidence.settle(MoveLabel.BLUNDER, 12, 12, false))
        assertEquals(MoveLabel.BLUNDER, LabelEvidence.settle(MoveLabel.BLUNDER, 10, 14, false))
        assertEquals(MoveLabel.MISTAKE, LabelEvidence.settle(MoveLabel.BLUNDER, 8, 8, false))
        assertEquals(MoveLabel.INACCURACY, LabelEvidence.settle(MoveLabel.BLUNDER, 6, 12, false))
        assertEquals(MoveLabel.GREAT, LabelEvidence.settle(MoveLabel.BRILLIANT, 9, 14, false))
        assertEquals(MoveLabel.BLUNDER, LabelEvidence.settle(MoveLabel.BLUNDER, 5, 5, true))
        assertEquals(MoveLabel.BLUNDER, LabelEvidence.settle(MoveLabel.BLUNDER, 0, 0, false))
        assertEquals(MoveLabel.GOOD, LabelEvidence.settle(MoveLabel.GOOD, 5, 5, false))
    }

    @Test
    fun gameEloEstimateIsMonotonic() {
        assertEquals(250, LabelEvidence.estimateGameElo(0.0))
        assertEquals(1000, LabelEvidence.estimateGameElo(65.0))
        assertEquals(2800, LabelEvidence.estimateGameElo(100.0))
        var prev = 0
        for (a in 0..100) {
            val e = LabelEvidence.estimateGameElo(a.toDouble())
            assertTrue(e >= prev)
            prev = e
        }
    }
}
