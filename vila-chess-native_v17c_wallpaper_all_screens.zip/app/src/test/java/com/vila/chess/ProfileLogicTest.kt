package com.vila.chess

import com.vila.chess.profile.AvatarPhotos
import com.vila.chess.profile.Avatars
import com.vila.chess.profile.rankTitle
import com.vila.chess.profile.Countries
import com.vila.chess.profile.EloHistoryCodec
import com.vila.chess.profile.EloPoint
import com.vila.chess.profile.EloRange
import com.vila.chess.profile.EloSeries
import com.vila.chess.profile.NameRules
import com.vila.chess.profile.ResultStreak
import com.vila.chess.profile.UserProfile
import com.vila.chess.profile.streakLabel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileLogicTest {
    private val day = EloSeries.DAY_MS
    private val now = 1_000 * day

    @Test fun streak_win_loss_draw() {
        assertEquals(1, ResultStreak.next(0, 1.0))
        assertEquals(3, ResultStreak.next(2, 1.0))
        assertEquals(1, ResultStreak.next(-4, 1.0))     // thắng sau chuỗi thua → chuỗi thắng mới
        assertEquals(-1, ResultStreak.next(5, 0.0))
        assertEquals(-3, ResultStreak.next(-2, 0.0))
        assertEquals(0, ResultStreak.next(7, 0.5))      // hòa làm đứt chuỗi
        assertEquals("3 thắng liên tiếp", streakLabel(3))
        assertEquals("2 thua liên tiếp", streakLabel(-2))
    }

    @Test fun series_empty_history_is_empty() {
        assertTrue(EloSeries.window(emptyList(), EloRange.WEEK, now, 900).isEmpty())
    }

    @Test fun series_carries_baseline_to_window_start_and_ends_at_now() {
        val h = listOf(EloPoint(now - 100 * day, 800), EloPoint(now - 3 * day, 830), EloPoint(now - 1 * day, 815))
        val w = EloSeries.window(h, EloRange.WEEK, now, 815)
        assertEquals(EloPoint(now - 7 * day, 800), w.first())   // mức 800 được mang tới đầu cửa sổ 7 ngày
        assertEquals(EloPoint(now, 815), w.last())
        assertEquals(4, w.size)                                  // baseline + 2 điểm trong cửa sổ + điểm hiện tại
    }

    @Test fun series_no_games_in_window_is_flat_line() {
        val h = listOf(EloPoint(now - 200 * day, 900), EloPoint(now - 150 * day, 950))
        val w = EloSeries.window(h, EloRange.MONTH, now, 950)
        assertEquals(listOf(EloPoint(now - 30 * day, 950), EloPoint(now, 950)), w)
    }

    @Test fun series_ignores_future_points_and_sorts() {
        val h = listOf(EloPoint(now - 1 * day, 820), EloPoint(now + 5 * day, 999), EloPoint(now - 2 * day, 800))
        val w = EloSeries.window(h, EloRange.WEEK, now, 820)
        assertTrue(w.none { it.rating == 999 })
        assertEquals(w.sortedBy { it.ts }, w)
    }

    @Test fun series_year_range_includes_old_points() {
        val h = listOf(EloPoint(now - 300 * day, 700), EloPoint(now - 10 * day, 760))
        assertEquals(3, EloSeries.window(h, EloRange.YEAR, now, 760).size)
        assertEquals(3, EloSeries.window(h, EloRange.MONTH, now, 760).size) // baseline 700 + điểm -10 ngày + hiện tại
    }

    @Test fun append_seeds_first_point_and_caps() {
        val first = EloSeries.append(emptyList(), 800, 816, 5_000L)
        assertEquals(listOf(EloPoint(4_999L, 800), EloPoint(5_000L, 816)), first)
        var h = first
        for (i in 1..500) h = EloSeries.append(h, 800, 800 + i, 5_000L + i, cap = 400)
        assertEquals(400, h.size)
        assertEquals(1300, h.last().rating)
    }

    @Test fun codec_roundtrip_and_garbage() {
        val pts = listOf(EloPoint(1L, 800), EloPoint(2L, 815))
        assertEquals(pts, EloHistoryCodec.decode(EloHistoryCodec.encode(pts)))
        assertEquals(listOf(EloPoint(3L, 900)), EloHistoryCodec.decode("x,abc:1,4:z,3:900,:5"))
        assertTrue(EloHistoryCodec.decode(null).isEmpty())
        assertTrue(EloHistoryCodec.decode("").isEmpty())
    }

    @Test fun flag_and_countries() {
        assertEquals("🇻🇳", Countries.flag("vn"))   // 🇻🇳
        assertEquals("", Countries.flag("VNM"))
        assertEquals("", Countries.flag("1A"))
        assertEquals("", Countries.flag(null))
        assertNotNull(Countries.byCode("us"))
        assertNull(Countries.byCode("ZZ"))
        assertEquals(Countries.all.size, Countries.all.map { it.code }.toSet().size)  // không trùng mã
    }

    @Test fun initials_and_name_rules() {
        assertEquals("NA", Avatars.initials("nguyen van an"))
        assertEquals("M", Avatars.initials("magnus"))
        assertEquals("?", Avatars.initials("   "))
        assertNull(NameRules.validate("An"))
        assertNotNull(NameRules.validate("A"))
        assertNotNull(NameRules.validate("x".repeat(21)))
        assertNotNull(NameRules.validate("ab\u0007"))
    }

    @Test fun profile_winrate() {
        assertEquals(0, UserProfile("u", "n").winRatePct)
        assertEquals(67, UserProfile("u", "n", played = 3, won = 2).winRatePct)
    }

    @Test fun avatar_photo_keys() {
        assertTrue(AvatarPhotos.isPhoto("photo:avatar_123.jpg"))
        assertTrue(!AvatarPhotos.isPhoto("king"))
        assertTrue(!AvatarPhotos.isPhoto("photo:../secret"))   // chặn đường dẫn lạ
        assertTrue(!AvatarPhotos.isPhoto("photo:"))
        assertEquals("", AvatarPhotos.cloudKey("photo:avatar_1.jpg"))   // ảnh cục bộ không đẩy lên cloud
        assertEquals("king", AvatarPhotos.cloudKey("king"))
    }

    @Test fun avatar_cloud_keys() {
        val uid = "123e4567-e89b-12d3-a456-426614174000"
        assertTrue(AvatarPhotos.isCloud("cloud:$uid/avatar_1700000000000.jpg"))
        assertTrue(!AvatarPhotos.isCloud("cloud:../../x/avatar_1.jpg"))   // chặn đường dẫn lạ
        assertTrue(!AvatarPhotos.isCloud("cloud:$uid/evil.png"))
        assertEquals("cloud:$uid/avatar_1.jpg", AvatarPhotos.cloudKey("cloud:$uid/avatar_1.jpg"))
        assertTrue(AvatarPhotos.hasImage("photo:a.jpg") && !AvatarPhotos.hasImage("king"))
    }

    @Test fun rank_titles() {
        assertEquals("Tân binh", rankTitle(800))
        assertEquals("Chuyên gia", rankTitle(1800))
        assertEquals("Đại kiện tướng", rankTitle(2500))
    }
}
