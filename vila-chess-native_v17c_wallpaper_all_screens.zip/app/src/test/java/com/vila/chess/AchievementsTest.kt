package com.vila.chess

import com.vila.chess.core.EMPTY
import com.vila.chess.core.QUEEN
import com.vila.chess.core.ROOK
import com.vila.chess.core.findMoveBySan
import com.vila.chess.core.makePiece
import com.vila.chess.game.AchCategory
import com.vila.chess.game.AchEngine
import com.vila.chess.game.AchSnapshot
import com.vila.chess.game.AchStats
import com.vila.chess.game.AchTier
import com.vila.chess.game.Achievements
import com.vila.chess.game.DesignBit
import com.vila.chess.game.GameFacts
import com.vila.chess.game.GameFactsBuilder
import com.vila.chess.game.GameSession
import com.vila.chess.game.MoveRecord
import com.vila.chess.game.PlayerStats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AchievementsTest {
    private fun play(fen: String? = null, vararg sans: String): GameSession {
        val s = if (fen == null) GameSession() else GameSession(fen)
        for (san in sans) {
            val m = findMoveBySan(s.position, san) ?: error("SAN không hợp lệ: $san")
            s.play(m)
        }
        return s
    }

    private fun state(snap: AchSnapshot, id: String) = AchEngine.evaluate(snap).first { it.def.id == id }

    // ------------------------------------------------------------------ danh mục

    @Test fun catalog_has_30_unique_achievements_6_per_category() {
        assertEquals(30, Achievements.total)
        assertEquals(30, Achievements.all.map { it.id }.toSet().size)
        for (c in AchCategory.values()) assertEquals(c.name, 6, Achievements.all.count { it.category == c })
        assertTrue(Achievements.all.all { it.target >= 1 && it.title.isNotBlank() && it.desc.isNotBlank() })
        assertEquals(Achievements.all.sumOf { it.tier.points }, Achievements.totalPoints)
    }

    @Test fun nothing_is_done_for_a_new_player() {
        // Người mới: hệ số khởi điểm 800, các bộ đếm đều 0.
        val states = AchEngine.evaluate(AchSnapshot(stats = AchStats(peakRating = 800)))
        assertTrue(states.none { it.done })
        assertEquals(0, AchEngine.totalPoints(states))
        assertEquals(800, states.first { it.def.id == "elo_1000" }.progress)
    }

    @Test fun counters_map_to_the_right_achievements() {
        val snap = AchSnapshot(
            stats = AchStats(bestWinStreak = 5, bestDayStreak = 7, peakRating = 1450, maxLevelBeaten = 4, reviews = 5, designMask = DesignBit.ALL),
            played = 100, won = 25, tournamentsDone = 1, puzzlesSolved = 10, lessonsDone = 1,
        )
        for (id in listOf("first_game", "diligent", "grinder", "first_win", "wins_25", "streak_3", "streak_5", "days_3", "days_7",
            "elo_1000", "elo_1400", "beat_lvl4", "tournament", "puzzles_10", "lesson_1", "review_5", "designer")) {
            assertTrue(id, state(snap, id).done)
        }
        for (id in listOf("wins_100", "streak_10", "days_30", "elo_1800", "beat_lvl8", "puzzles_100", "magic_1", "castle", "comeback")) {
            assertFalse(id, state(snap, id).done)
        }
    }

    @Test fun designer_needs_all_four_kinds() {
        val three = AchStats(designMask = DesignBit.BOARD or DesignBit.PIECES or DesignBit.SOUND)
        val s = state(AchSnapshot(stats = three), "designer")
        assertFalse(s.done)
        assertEquals(3, s.progress)
        assertTrue(state(AchSnapshot(stats = three.copy(designMask = DesignBit.ALL)), "designer").done)
    }

    @Test fun tiers_have_increasing_points() {
        val p = AchTier.values().map { it.points }
        assertEquals(p.sorted(), p)
    }

    // ------------------------------------------------------------------ rút số liệu từ ván cờ

    @Test fun scholars_mate_is_a_4_move_win_by_checkmate() {
        val g = play(null, "e4", "e5", "Bc4", "Nc6", "Qh5", "Nf6", "Qxf7#")
        val f = GameFactsBuilder.from(g.records, humanWhite = true, humanWon = true, checkmate = true)
        assertEquals(4, f.mateInMoves)
        assertFalse(f.comeback)
        // Thua hoặc không phải chiếu hết thì không có "mateInMoves".
        assertEquals(0, GameFactsBuilder.from(g.records, true, false, true).mateInMoves)
        assertEquals(0, GameFactsBuilder.from(g.records, true, true, false).mateInMoves)
        // Cầm Đen: người chơi chỉ đi 3 nước.
        assertEquals(3, GameFactsBuilder.from(g.records, humanWhite = false, humanWon = true, checkmate = true).mateInMoves)
    }

    @Test fun castling_is_counted_for_the_human_side_only() {
        val g = play(null, "e4", "e5", "Nf3", "Nc6", "Bc4", "Bc5", "O-O", "Nf6", "d3", "O-O")
        assertEquals(1, GameFactsBuilder.from(g.records, true, false, false).castles)
        assertEquals(1, GameFactsBuilder.from(g.records, false, false, false).castles)
    }

    @Test fun en_passant_is_detected() {
        val g = play(null, "e4", "a6", "e5", "d5", "exd6")
        assertEquals(1, GameFactsBuilder.from(g.records, true, false, false).enPassants)
        assertEquals(0, GameFactsBuilder.from(g.records, false, false, false).enPassants)
    }

    @Test fun queen_and_under_promotions_are_separated() {
        val fen = "8/P6k/8/8/8/8/8/K7 w - - 0 1"
        val q = GameFactsBuilder.from(play(fen, "a8=Q").records, true, false, false)
        assertEquals(1, q.queenPromos)
        assertEquals(0, q.underPromos)
        val n = GameFactsBuilder.from(play(fen, "a8=N").records, true, false, false)
        assertEquals(0, n.queenPromos)
        assertEquals(1, n.underPromos)
    }

    @Test fun comeback_needs_a_win_after_being_a_rook_or_more_down() {
        val whiteQueen = makePiece(QUEEN, true)
        val blackRook = makePiece(ROOK, false)
        // Người chơi (Trắng) mất Hậu, sau nước kế tiếp vẫn kém 900 -> thắng = lội ngược dòng.
        val down = listOf(
            MoveRecord(0, "?", whiteQueen, whiteMoved = false),
            MoveRecord(0, "?", EMPTY, whiteMoved = true),
        )
        assertTrue(GameFactsBuilder.from(down, humanWhite = true, humanWon = true, checkmate = true).comeback)
        assertFalse(GameFactsBuilder.from(down, humanWhite = true, humanWon = false, checkmate = false).comeback)
        // Đổi Hậu lấy Hậu (đối thủ ăn trước, người chơi ăn lại) -> không phải kém quân.
        val trade = listOf(
            MoveRecord(0, "?", whiteQueen, whiteMoved = false),
            MoveRecord(0, "?", makePiece(QUEEN, false), whiteMoved = true),
        )
        assertFalse(GameFactsBuilder.from(trade, true, true, true).comeback)
        // Chỉ mất 1 Xe (500) vẫn đủ ngưỡng; mất ít hơn thì không.
        val oneRook = listOf(
            MoveRecord(0, "?", makePiece(ROOK, true), whiteMoved = false),
            MoveRecord(0, "?", EMPTY, whiteMoved = true),
        )
        assertTrue(GameFactsBuilder.from(oneRook, true, true, false).comeback)
        val oneRookBlack = listOf(MoveRecord(0, "?", blackRook, whiteMoved = true))
        assertFalse(GameFactsBuilder.from(oneRookBlack, true, true, false).comeback)
    }

    // ------------------------------------------------------------------ cập nhật bộ đếm

    @Test fun apply_game_accumulates_and_keeps_best_values() {
        var s = AchStats()
        s = AchEngine.applyGame(s, GameFacts(castles = 1, queenPromos = 2, mateInMoves = 30), humanWon = true, level = 3)
        assertEquals(30, s.fastestMate)
        assertEquals(3, s.maxLevelBeaten)
        s = AchEngine.applyGame(s, GameFacts(enPassants = 1, underPromos = 1, mateInMoves = 18, comeback = true), humanWon = true, level = 2)
        assertEquals(18, s.fastestMate)            // lấy số nước ít nhất
        assertEquals(3, s.maxLevelBeaten)          // thắng bot yếu hơn không làm tụt
        assertEquals(1, s.castles); assertEquals(2, s.queenPromos); assertEquals(1, s.enPassants)
        assertEquals(1, s.underPromos); assertEquals(1, s.comebackWins)
        s = AchEngine.applyGame(s, GameFacts(mateInMoves = 0), humanWon = false, level = 8)
        assertEquals(18, s.fastestMate)            // thua thì không đổi
        assertEquals(3, s.maxLevelBeaten)          // thua bot cấp 8 không tính
        s = AchEngine.applyGame(s, GameFacts(), humanWon = true, level = 8)
        assertEquals(8, s.maxLevelBeaten)
        assertTrue(state(AchSnapshot(stats = s), "beat_lvl8").done)
        assertTrue(state(AchSnapshot(stats = s), "blitz_mate").done)
    }

    @Test fun blitz_mate_threshold_is_25_moves() {
        assertTrue(state(AchSnapshot(stats = AchStats(fastestMate = 25)), "blitz_mate").done)
        assertFalse(state(AchSnapshot(stats = AchStats(fastestMate = 26)), "blitz_mate").done)
        assertFalse(state(AchSnapshot(stats = AchStats(fastestMate = 0)), "blitz_mate").done)
    }

    @Test fun sync_peaks_never_goes_down() {
        val today = 20_000L
        val p = PlayerStats(ratings = listOf(900, 1210, 800, 800), streak = 4, lastDay = today, resultStreak = 3)
        var s = AchEngine.syncPeaks(AchStats(), p, today)
        assertEquals(1210, s.peakRating)
        assertEquals(3, s.bestWinStreak)
        assertEquals(4, s.bestDayStreak)
        // Sau này thua, tụt hệ số, đứt chuỗi ngày: kỷ lục cũ vẫn giữ.
        val worse = PlayerStats(ratings = listOf(700, 700, 700, 700), streak = 1, lastDay = today, resultStreak = -2)
        s = AchEngine.syncPeaks(s, worse, today + 10)
        assertEquals(1210, s.peakRating)
        assertEquals(3, s.bestWinStreak)
        assertEquals(4, s.bestDayStreak)
    }
}
