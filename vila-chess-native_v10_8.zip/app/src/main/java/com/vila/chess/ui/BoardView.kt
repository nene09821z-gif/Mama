package com.vila.chess.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.UiState
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val LIFT = 0.45f // dragged piece is drawn this many squares above the finger

fun squareAt(p: Offset, boardPx: Float, flipped: Boolean): Int {
    val s = boardPx / 8f
    val col = (p.x / s).toInt().coerceIn(0, 7)
    val row = (p.y / s).toInt().coerceIn(0, 7)
    val file = if (flipped) 7 - col else col
    val rank = if (flipped) row else 7 - row
    return rank * 8 + file
}

@Composable
fun BoardView(
    vm: GameViewModel,
    ui: UiState,
    images: Array<ImageBitmap?>,
    modifier: Modifier = Modifier
) {
    val slide = remember { Animatable(1f) }
    LaunchedEffect(ui.animToken) {
        if (ui.slides.isNotEmpty()) {
            slide.snapTo(0f)
            slide.animateTo(1f, tween(durationMillis = 150, easing = FastOutSlowInEasing))
        } else {
            slide.snapTo(1f)
        }
    }

    var dragSq by remember { mutableIntStateOf(-1) }
    var dragCenter by remember { mutableStateOf(Offset.Zero) }
    val labelPaint = remember {
        Paint().apply {
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
    }

    Canvas(
        modifier = modifier
            .aspectRatio(1f)
            .pointerInput(Unit) {
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val boardPx = size.width.toFloat()
                    val flipped = vm.ui.flipped
                    val liftPx = boardPx / 8f * LIFT
                    val startSq = squareAt(down.position, boardPx, flipped)
                    val wasSelected = vm.ui.selected == startSq
                    val picked = vm.pressSquare(startSq)
                    var dragging = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        val center = Offset(change.position.x, change.position.y - liftPx)
                        if (!change.pressed) {
                            if (dragging) {
                                val drop = squareAt(center, boardPx, flipped)
                                dragSq = -1
                                vm.releaseDrag(startSq, drop)
                            } else if (picked && wasSelected) {
                                vm.deselect()
                            }
                            break
                        }
                        if (picked) {
                            if (!dragging && (change.position - down.position).getDistance() > slop) {
                                dragging = true
                                dragSq = startSq
                            }
                            if (dragging) {
                                dragCenter = center
                                change.consume()
                            }
                        }
                    }
                    dragSq = -1
                }
            }
    ) {
        drawBoard(ui, images, slide.value, dragSq, dragCenter, labelPaint)
    }
}

private fun DrawScope.drawBoard(
    ui: UiState,
    images: Array<ImageBitmap?>,
    slideValue: Float,
    dragSq: Int,
    dragCenter: Offset,
    labelPaint: Paint
) {
    val s = size.width / 8f
    val flipped = ui.flipped

    fun topLeft(sq: Int): Offset {
        val f = sq and 7
        val r = sq shr 3
        val col = if (flipped) 7 - f else f
        val row = if (flipped) r else 7 - r
        return Offset(col * s, row * s)
    }

    fun center(sq: Int): Offset {
        val o = topLeft(sq)
        return Offset(o.x + s / 2f, o.y + s / 2f)
    }

    fun tint(sq: Int, color: Color) {
        drawRect(color = color, topLeft = topLeft(sq), size = Size(s, s))
    }

    fun piece(code: Int, o: Offset, sz: Float) {
        val img = images[code] ?: return
        drawImage(
            image = img,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(img.width, img.height),
            dstOffset = IntOffset(o.x.roundToInt(), o.y.roundToInt()),
            dstSize = IntSize(sz.roundToInt(), sz.roundToInt()),
            filterQuality = FilterQuality.High
        )
    }

    // squares
    for (sq in 0 until 64) {
        val light = ((sq shr 3) + (sq and 7)) % 2 == 1
        tint(sq, if (light) VilaColors.BoardLight else VilaColors.BoardDark)
    }

    // highlights
    if (ui.lastFrom >= 0) {
        tint(ui.lastFrom, VilaColors.Highlight)
        tint(ui.lastTo, VilaColors.Highlight)
    }
    if (ui.selected >= 0) tint(ui.selected, VilaColors.Highlight)
    if (ui.hintFrom >= 0 && ui.hintTo >= 0) {
        tint(ui.hintFrom, Color(0x663E9BEA))
        tint(ui.hintTo, Color(0x663E9BEA))
    }
    if (ui.premoveFrom >= 0) {
        tint(ui.premoveFrom, VilaColors.PremoveRed)
        tint(ui.premoveTo, VilaColors.PremoveRed)
    }
    if (ui.checkSquare >= 0) {
        val c = center(ui.checkSquare)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xE6FF2A2A), Color(0x00E70000)),
                center = c,
                radius = s * 0.75f
            ),
            radius = s * 0.75f,
            center = c
        )
    }

    // coordinates
    drawIntoCanvas { canvas ->
        labelPaint.textSize = s * 0.2f
        for (sq in 0 until 64) {
            val f = sq and 7
            val r = sq shr 3
            val col = if (flipped) 7 - f else f
            val row = if (flipped) r else 7 - r
            val light = (r + f) % 2 == 1
            val textColor = if (light) VilaColors.BoardDark else VilaColors.BoardLight
            labelPaint.color = textColor.toArgb()
            if (col == 0) {
                labelPaint.textAlign = Paint.Align.LEFT
                canvas.nativeCanvas.drawText(('1' + r).toString(), col * s + s * 0.06f, row * s + s * 0.24f, labelPaint)
            }
            if (row == 7) {
                labelPaint.textAlign = Paint.Align.RIGHT
                canvas.nativeCanvas.drawText(('a' + f).toString(), col * s + s - s * 0.06f, row * s + s - s * 0.08f, labelPaint)
            }
        }
    }

    // move hints
    for (sq in ui.targets) {
        val c = center(sq)
        if (ui.board[sq] != 0) {
            drawCircle(
                color = Color(0x2E000000),
                radius = s * 0.43f,
                center = c,
                style = Stroke(width = s * 0.09f)
            )
        } else {
            drawCircle(color = Color(0x2E000000), radius = s * 0.17f, center = c)
        }
    }

    // pieces
    val sliding = ui.slides.isNotEmpty() && slideValue < 1f
    for (sq in 0 until 64) {
        val pc = ui.board[sq]
        if (pc == 0 || sq == dragSq) continue
        var o = topLeft(sq)
        if (sliding) {
            for (sl in ui.slides) {
                if (sl.to == sq) {
                    val a = topLeft(sl.from)
                    val t = 1f - slideValue
                    o = Offset(o.x + (a.x - o.x) * t, o.y + (a.y - o.y) * t)
                }
            }
        }
        piece(pc, o, s)
    }

    // coach arrow
    if (ui.hintFrom >= 0 && ui.hintTo >= 0) {
        val a = center(ui.hintFrom)
        val b = center(ui.hintTo)
        val dx = b.x - a.x
        val dy = b.y - a.y
        val len = sqrt(dx * dx + dy * dy)
        if (len > 0f) {
            val ux = dx / len
            val uy = dy / len
            val head = s * 0.34f
            val baseX = b.x - ux * head
            val baseY = b.y - uy * head
            val arrow = Color(0xCC2D8CFF)
            drawLine(
                color = arrow,
                start = Offset(a.x + ux * s * 0.2f, a.y + uy * s * 0.2f),
                end = Offset(baseX, baseY),
                strokeWidth = s * 0.16f,
                cap = StrokeCap.Round
            )
            val tip = Path()
            tip.moveTo(b.x, b.y)
            tip.lineTo(baseX - uy * head * 0.75f, baseY + ux * head * 0.75f)
            tip.lineTo(baseX + uy * head * 0.75f, baseY - ux * head * 0.75f)
            tip.close()
            drawPath(tip, arrow)
        }
    }

    // drag feedback
    if (dragSq >= 0) {
        val hover = squareAt(dragCenter, size.width, flipped)
        if (ui.targets.contains(hover)) {
            val o = topLeft(hover)
            drawRect(
                color = Color(0xB3FFFFFF),
                topLeft = Offset(o.x + s * 0.03f, o.y + s * 0.03f),
                size = Size(s * 0.94f, s * 0.94f),
                style = Stroke(width = s * 0.06f)
            )
        }
        val pc = ui.board[dragSq]
        if (pc != 0) {
            val big = s * 1.2f
            piece(pc, Offset(dragCenter.x - big / 2f, dragCenter.y - big / 2f), big)
        }
    }
}
