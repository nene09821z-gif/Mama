package com.vila.chess

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.vila.chess.billing.BillingRepository
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.Screen
import com.vila.chess.ui.GameScreen
import com.vila.chess.ui.HomeScreen
import com.vila.chess.ui.ViLaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )
        setContent {
            ViLaTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val vm: GameViewModel = viewModel()
    val ctx = LocalContext.current
    // Đồng bộ gói với Google Play lúc mở app (offline thì giữ gói đã lưu).
    LaunchedEffect(Unit) { BillingRepository.get(ctx).refreshEntitlements() }
    when (vm.screen) {
        Screen.HOME -> HomeScreen(vm)
        Screen.GAME -> GameScreen(vm)
    }
}
