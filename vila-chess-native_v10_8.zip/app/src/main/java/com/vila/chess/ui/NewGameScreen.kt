package com.vila.chess.ui

import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.game.EndgamePreset
import com.vila.chess.game.EndgamePresets
import com.vila.chess.game.FenCheck
import com.vila.chess.game.GameViewModel
import com.vila.chess.game.HomeRoute
import com.vila.chess.game.Tournament
import com.vila.chess.game.TimeControls
import com.vila.chess.game.modeFor
import com.vila.chess.game.timeGroups

private val CARD_SHAPE = RoundedCornerShape(10.dp)
private val DIALOG_COLOR = Color(0xFF16233B)

/** "Ván cờ mới": time control, quick start and the game-mode menu. */
@Composable
fun NewGameScreen(vm: GameViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var timeOpen by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var showEndgames by remember { mutableStateOf(false) }
    var showFen by remember { mutableStateOf(false) }
    val timeControl = TimeControls.get(vm.timeIndex)
    val mode = modeFor(timeControl)
    val played = vm.tournament.count { it != null }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        // title row: back arrow + pawn icon + "Ván cờ mới"
        Box(modifier = Modifier.fillMaxWidth().height(56.dp)) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart).padding(start = 4.dp)) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Quay lại",
                    tint = Color(0xFFB9C1CE),
                )
            }
            Row(modifier = Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
                PawnIcon(Color(0xFFF2E2C8), Modifier.size(30.dp).rotate(-12f))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Ván cờ mới",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
            }
        }

        // time control card (+ dropdown)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 16.dp)
                .animateContentSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            MenuCard(onClick = { timeOpen = !timeOpen }, trailing = {
                ChevronIcon(
                    up = timeOpen,
                    color = Color(0xFFCBD3DF),
                    modifier = Modifier.align(Alignment.CenterEnd).padding(end = 14.dp).size(24.dp),
                )
            }) {
                ModeIcon(mode, Modifier.size(26.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    text = timeControl.label,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                )
            }
            if (timeOpen) {
                TimePanel(
                    selected = vm.timeIndex,
                    onPick = {
                        vm.updateTimeIndex(it)
                        timeOpen = false
                    },
                )
            }
        }

        ChunkyButton(
            text = "Bắt đầu ván cờ",
            onClick = { vm.startGame() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 8.dp),
            height = 52.dp,
            edge = 4.dp,
            radius = 10.dp,
            fontSize = 22.sp,
        )

        // game modes
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 24.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp),
        ) {
            MenuCard(
                onClick = { vm.navigate(HomeRoute.TOURNAMENT) },
                trailing = {
                    if (played > 0) {
                        Text(
                            text = played.toString() + "/" + Tournament.ROUNDS,
                            color = VilaColors.TextDim,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 14.dp),
                        )
                    }
                },
            ) {
                MedalIcon(Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                MenuLabel("Các giải đấu")
            }
            MenuCard(onClick = { vm.startFriendGame() }) {
                FriendsIcon(Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                MenuLabel("Chơi với một người bạn")
            }
            MenuCard(onClick = { vm.navigate(HomeRoute.BOT_SETUP) }) {
                ComputerIcon(Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                MenuLabel("Chơi với Bot")
            }
            MenuCard(
                onClick = {
                    val on = !vm.coachOn
                    vm.setCoach(on)
                    val msg = if (on) "Đã bật huấn luyện viên: chạm Gợi ý trong ván để xem nước tốt nhất" else "Đã tắt huấn luyện viên"
                    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                },
                trailing = {
                    if (vm.coachOn) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 12.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(VilaColors.GreenDeep)
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                        ) {
                            Text("ĐANG BẬT", color = VilaColors.Green, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                },
            ) {
                CoachIcon(Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                MenuLabel(if (vm.coachOn) "Tắt huấn luyện viên" else "Bật huấn luyện viên")
            }

            if (more) {
                MenuCard(onClick = { showEndgames = true }) {
                    PawnIcon(Color(0xFFFFC83D), Modifier.size(26.dp))
                    Spacer(Modifier.width(10.dp))
                    MenuLabel("Tập tàn cuộc")
                }
                MenuCard(onClick = { showFen = true }) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = null,
                        tint = Color(0xFF9CC0F0),
                        modifier = Modifier.size(24.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    MenuLabel("Chơi từ thế cờ (FEN)")
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clickable { more = !more },
            contentAlignment = Alignment.Center,
        ) {
            ChevronIcon(up = more, color = Color(0xFFCBD3DF), modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showEndgames) {
        EndgameDialog(
            onDismiss = { showEndgames = false },
            onPick = {
                showEndgames = false
                vm.startEndgame(it)
            },
        )
    }
    if (showFen) {
        FenDialog(vm = vm, onDismiss = { showFen = false })
    }
}

@Composable
private fun MenuLabel(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 17.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
    )
}

/** Full-width translucent 47dp card with centered content (icon + label). */
@Composable
private fun MenuCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable BoxScope.() -> Unit = {},
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(47.dp)
            .clip(CARD_SHAPE)
            .background(VilaColors.Glass)
            .border(1.dp, VilaColors.GlassBorder, CARD_SHAPE)
            .clickable(onClick = onClick),
    ) {
        Row(modifier = Modifier.align(Alignment.Center), verticalAlignment = Alignment.CenterVertically) {
            content()
        }
        trailing()
    }
}

/** Time controls grouped by rating bucket; picking one selects it and closes the panel. */
@Composable
private fun TimePanel(selected: Int, onPick: (Int) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(CARD_SHAPE)
            .background(VilaColors.Glass)
            .border(1.dp, VilaColors.GlassBorder, CARD_SHAPE)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        for (group in timeGroups()) {
            val mode = group.first
            val indices = group.second
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ModeIcon(mode, Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = mode.label,
                        color = VilaColors.TextDim,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                ChipGrid(
                    labels = indices.map { TimeControls.all[it].label },
                    selected = indices.indexOf(selected),
                    columns = 3,
                    onSelect = { onPick(indices[it]) },
                )
            }
        }
    }
}

@Composable
private fun EndgameDialog(onDismiss: () -> Unit, onPick: (EndgamePreset) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DIALOG_COLOR,
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(16.dp),
        title = { Text("Tập tàn cuộc", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Bạn cầm quân thắng thế và chiếu hết Bot.", fontSize = 13.sp)
                for (p in EndgamePresets.all) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x33FFFFFF))
                            .clickable { onPick(p) }
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        Text(p.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(p.desc, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Đóng", color = VilaColors.Green, fontWeight = FontWeight.Bold) }
        },
    )
}

/** Paste / type a FEN, pick your colour, play it against the bot. */
@Composable
private fun FenDialog(vm: GameViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    var white by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DIALOG_COLOR,
        titleContentColor = Color.White,
        textContentColor = VilaColors.TextDim,
        shape = RoundedCornerShape(16.dp),
        title = { Text("Chơi từ thế cờ", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        error = null
                    },
                    label = { Text("Chuỗi FEN") },
                    minLines = 2,
                    isError = error != null,
                    supportingText = { if (error != null) Text(error ?: "") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        errorTextColor = Color.White,
                        cursorColor = VilaColors.Green,
                        focusedBorderColor = VilaColors.Green,
                        unfocusedBorderColor = Color(0x66FFFFFF),
                        focusedLabelColor = VilaColors.Green,
                        unfocusedLabelColor = VilaColors.TextDim,
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = {
                        val pasted = clipboard.getText()?.text
                        if (pasted != null) {
                            text = pasted.trim()
                            error = null
                            if (FenCheck.validate(text) == null) white = FenCheck.whiteToMove(text)
                        }
                    }) { Text("Dán", color = VilaColors.Green, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.weight(1f))
                    SideChip("Trắng", white) { white = true }
                    Spacer(Modifier.width(8.dp))
                    SideChip("Đen", !white) { white = false }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = vm.startFromFen(text, white)
            }) { Text("Bắt đầu", color = VilaColors.Green, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Hủy", color = VilaColors.TextDim) }
        },
    )
}

@Composable
private fun SideChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(if (selected) VilaColors.Green.copy(alpha = 0.2f) else Color(0x22FFFFFF))
            .border(1.dp, if (selected) VilaColors.Green else Color(0x33FFFFFF), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) VilaColors.Green else VilaColors.TextDim,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
