package com.vila.chess.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vila.chess.R
import kotlinx.coroutines.launch

// ════════════════════════════════════════════════════════════════════════════════════════════
//  PUZZLE MAP 2.5D  –  1 file duy nhất (thay cho PuzzleMapScreen + WoodenNode + PuzzleScenery cũ)
//
//  Thứ tự lớp (dưới → trên), tất cả nằm trong 1 BoxWithConstraints:
//    1. bg_map          : Image fillMaxSize (Crop)                       – nền cỏ
//    2. TrailCanvas     : Canvas vẽ đường mòn 2 lớp theo toạ độ THỰC của các nút
//    3. SceneryLayer    : cây / ao / nhà / bụi, offset theo % maxWidth, % chiều cao khối
//    4. LazyColumn      : các nút gỗ (key + contentType)
//    5. TopArea / BottomPanel : tiêu đề, HLV + bong bóng chat, tiến độ, nút "Giải các câu đố"
//
//  Nguyên tắc hiệu năng:
//    • Mọi thứ phụ thuộc vị trí cuộn chỉ được ĐỌC trong draw / graphicsLayer lambda  → cuộn không gây recomposition.
//    • Path, Stroke, bảng toạ độ X: tạo 1 lần bằng remember / hằng số, dùng lại bằng rewind().
//    • Ảnh được decode 1 lần ở cấp màn hình (MapArt) rồi truyền xuống, item KHÔNG tự gọi painterResource.
//    • Animation (nhấn nút, nhịp thở hào quang, con tốt nhún) chạy bằng graphicsLayer (GPU), không đụng size/layout.
// ════════════════════════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────── Data

/** Dữ liệu 1 level. isCurrent ⇒ đang chơi; !isUnlocked ⇒ khoá. */
@Immutable
data class PuzzleLevel(val id: Int, val isUnlocked: Boolean, val isCurrent: Boolean)

/** Dữ liệu giả lập để chạy thử ngay: [total] level, level [current] đang chơi, các level sau bị khoá. */
fun demoPuzzleLevels(total: Int = 100, current: Int = 6): List<PuzzleLevel> =
    List(total) { i ->
        val id = i + 1
        PuzzleLevel(id = id, isUnlocked = id <= current, isCurrent = id == current)
    }

private val DefaultLevels = demoPuzzleLevels()

enum class NodeState { Done, Current, Locked }

/** Kích thước nút gỗ (khớp tỉ lệ ảnh nut_go 360x329; ≈ 20% chiều rộng màn như ảnh mẫu). PuzzleTransitionWrapper cũng dùng 2 hằng số này. */
val NodeW = 74.dp
val NodeH = 68.dp

// ─────────────────────────────────────────────────────────── Hình học đường chữ S

private const val BLOCK = 8                 // 1 chu kỳ zig-zag = 8 level
private const val SCENE_BLOCK = 16          // cảnh vật lặp mỗi 16 level (2 chu kỳ)
private const val AMPLITUDE = 0.30f         // biên độ lắc ngang: nút chạy từ 20% đến 80% chiều rộng
private val TopPad = 140.dp                 // chừa chỗ cho tiêu đề + HLV
private val PanelHeight = 176.dp            // chừa chỗ cho thanh tiến độ + nút

/**
 * Bảng tra X (0..1) theo (index mod 8) – tính MỘT lần lúc nạp class, không tính lại mỗi frame.
 * Sóng tam giác (đường chéo isometric như ảnh mẫu): 0.5, 0.65, 0.8, 0.65, 0.5, 0.35, 0.2, 0.35 …
 * Catmull-Rom bo tròn các điểm đổi chiều ⇒ đoạn chéo thẳng, chỗ ngoặt mềm.
 */
private val TriWave = floatArrayOf(0f, 0.5f, 1f, 0.5f, 0f, -0.5f, -1f, -0.5f)
private val XFrac = FloatArray(BLOCK) { j -> 0.5f + AMPLITUDE * TriWave[j] }

/** index = vị trí trong danh sách hiển thị (0 = level cao nhất, ở trên cùng). Cho phép index âm / vượt biên (nút "ảo"). */
internal fun nodeXFrac(index: Int): Float = XFrac[index.mod(BLOCK)]

// ─────────────────────────────────────────────────────────── Ảnh (decode 1 lần)

@Immutable
private class MapArt(
    val bg: Painter, val node: Painter, val tree: Painter, val cabin: Painter, val pond: Painter,
    val coach: Painter, val pawn: Painter, val bush: Painter, val flowers: Painter,
    val bench: Painter, val pine: Painter, val rocks: Painter, val flowers2: Painter,
)

@Composable
private fun rememberMapArt(): MapArt {
    val bg = painterResource(R.drawable.bg_map)
    val node = painterResource(R.drawable.nut_go)
    val tree = painterResource(R.drawable.cay_co)
    val cabin = painterResource(R.drawable.nha_go)
    val pond = painterResource(R.drawable.ao_nuoc)
    val coach = painterResource(R.drawable.hlv)
    val pawn = painterResource(R.drawable.quan_tot)
    val bush = painterResource(R.drawable.bui_cay)
    val flowers = painterResource(R.drawable.hoa_trang)
    val bench = painterResource(R.drawable.ghe_da)
    val pine = painterResource(R.drawable.cay_thong)
    val rocks = painterResource(R.drawable.da_tang)
    val flowers2 = painterResource(R.drawable.hoa_mau)
    return remember(bg, node, tree, cabin, pond, coach, pawn, bush, flowers, bench, pine, rocks, flowers2) {
        MapArt(bg, node, tree, cabin, pond, coach, pawn, bush, flowers, bench, pine, rocks, flowers2)
    }
}

// ─────────────────────────────────────────────────────────── Màn hình chính

@Composable
fun PuzzleMapScreen(
    modifier: Modifier = Modifier,
    levels: List<PuzzleLevel> = DefaultLevels,
    score: Int = 554,
    streak: Int = 9,
    progress: Float = 0.28f,
    hiddenLevel: State<Int?>? = null,
    bottomPad: Dp = 0.dp,
    onNodeClick: (level: Int, center: Offset) -> Unit = { _, _ -> },
    onSolveClick: () -> Unit = {},
) {
    val art = rememberMapArt()
    // Level cao ở trên, level 1 ở đáy. Chỉ tính lại khi danh sách đổi.
    val shown = remember(levels) { levels.sortedByDescending { it.id } }
    val currentIndex = remember(shown) { shown.indexOfFirst { it.isCurrent }.coerceAtLeast(0) }
    val currentId = remember(shown) { shown.getOrNull(currentIndex)?.id ?: 1 }

    BoxWithConstraints(modifier.fillMaxSize()) {
        val screenW = maxWidth
        val screenH = maxHeight
        // Chiều cao mỗi level co giãn theo màn hình (≈ 9 nút / màn) nhưng kẹp trong [76dp, 104dp].
        // Khoảng cách dọc giữa các nút = 12.8% chiều rộng (như ảnh mẫu) ⇒ các nút xen kẽ sát nhau kiểu isometric.
        val itemH = remember(screenW) { (screenW * 0.128f).coerceIn(44.dp, 64.dp) }
        // Đặt level hiện tại ở ~62% chiều cao màn hình.
        val rowsAbove = ((screenH * 0.62f - TopPad) / itemH).toInt().coerceAtLeast(0)
        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = (currentIndex - rowsAbove).coerceAtLeast(0)
        )

        // 1) Nền
        Image(art.bg, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)

        // 2) Đường mòn (Canvas, nằm dưới nút)
        TrailCanvas(listState = listState, itemCount = shown.size, currentIndex = currentIndex, nodeBoxH = NodeH)

        // 3) Cảnh vật
        SceneryLayer(art = art, listState = listState, itemCount = shown.size, screenW = screenW, itemH = itemH)

        // 4) Danh sách nút
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = TopPad, bottom = PanelHeight + bottomPad),
        ) {
            itemsIndexed(
                items = shown,
                key = { _, level -> level.id },
                contentType = { _, _ -> "puzzle_node" },
            ) { index, level ->
                // Độ lệch trái/phải so với tâm: cùng công thức với TrailCanvas ⇒ nút và đường luôn trùng nhau.
                val dx = remember(index, screenW) { screenW * (nodeXFrac(index) - 0.5f) }
                PuzzleMapItem(
                    level = level,
                    dx = dx,
                    itemH = itemH,
                    art = art,
                    hiddenLevel = hiddenLevel,
                    onNodeClick = onNodeClick,
                )
            }
        }

        // 5) HUD
        TopArea(level = currentId, coach = art.coach, modifier = Modifier.align(Alignment.TopCenter))
        BottomPanel(
            score = score, streak = streak, progress = progress, onSolveClick = onSolveClick,
            bottomPad = bottomPad, modifier = Modifier.align(Alignment.BottomCenter),
        )
    }
}

@Composable
private fun PuzzleMapItem(
    level: PuzzleLevel,
    dx: Dp,
    itemH: Dp,
    art: MapArt,
    hiddenLevel: State<Int?>?,
    onNodeClick: (Int, Offset) -> Unit,
) {
    val state = when {
        level.isCurrent -> NodeState.Current
        level.isUnlocked -> NodeState.Done
        else -> NodeState.Locked
    }
    Box(Modifier.fillMaxWidth().height(itemH), contentAlignment = Alignment.Center) {
        WoodenNode(
            level = level.id,
            state = state,
            modifier = Modifier.offset(x = dx),
            painter = art.node,
            pawn = art.pawn,
            onClick = { center -> onNodeClick(level.id, center) },
            // Đọc State trong graphicsLayer ⇒ không recomposition khi chuyển cảnh.
            isHidden = { hiddenLevel?.value == level.id },
        )
    }
}

// ─────────────────────────────────────────────────────────── Đường mòn uốn lượn

private val TrailShadow = Color(0xFF4A2E16)
private val TrailTop = Color(0xFFF7E2A0)
private val TrailHighlight = Color(0xFFFFF3C4)
private val LockedShadow = Color(0x99423426)
private val LockedTop = Color(0xFFBDB6A0)

/**
 * Cách tính toạ độ:
 *   X(i) = W · nodeXFrac(i)                      (cùng bảng tra với offset của nút)
 *   Y(i) = y_item0 + (i − i0)·h + h/2 − shift     y_item0 / h lấy từ layoutInfo của item nhìn thấy đầu tiên
 *                                                 (nên Y là toạ độ THỰC, đã gồm contentPadding và vị trí cuộn)
 *   shift = NodeH·0.08  → đường đi xuyên qua tâm MẶT TRÊN của nút (không phải tâm cả khối có thân gỗ).
 * Nối các điểm bằng Catmull-Rom → cubicTo:
 *   C1 = P1 + (P2 − P0)/6 ,  C2 = P2 − (P3 − P1)/6
 * ⇒ tiếp tuyến liên tục tại mọi nút, không gãy khúc, ra hình chữ S mềm. P0 và P3 là các nút "ảo" tính bằng
 * chính công thức trên (vẫn hợp lệ ngoài màn hình) nên đầu/cuối đoạn nhìn thấy không bị méo.
 */
@Composable
private fun TrailCanvas(listState: LazyListState, itemCount: Int, currentIndex: Int, nodeBoxH: Dp) {
    val density = LocalDensity.current
    // Tất cả đối tượng vẽ tạo MỘT lần – trong draw chỉ rewind()/dùng lại.
    val donePath = remember { Path() }
    val lockPath = remember { Path() }
    val holes = remember { Path() }
    val shadowStroke = remember(density) { Stroke(with(density) { 14.dp.toPx() }, cap = StrokeCap.Round, join = StrokeJoin.Round) }
    val topStroke = remember(density) { Stroke(with(density) { 9.dp.toPx() }, cap = StrokeCap.Round, join = StrokeJoin.Round) }
    val hiStroke = remember(density) { Stroke(with(density) { 2.5.dp.toPx() }, cap = StrokeCap.Round, join = StrokeJoin.Round) }
    val nodeWpx = remember(density) { with(density) { NodeW.toPx() } }
    val nodeHpx = remember(density) { with(density) { nodeBoxH.toPx() } }
    val shiftPx = nodeHpx * 0.08f
    val dropPx = remember(density) { with(density) { 4.dp.toPx() } }
    val liftPx = remember(density) { with(density) { 2.dp.toPx() } }
    val maxPoints = 40

    // Đọc listState ở đây (draw phase) ⇒ cuộn chỉ làm vẽ lại, KHÔNG recomposition.
    Canvas(Modifier.fillMaxSize()) {
        val infos = listState.layoutInfo.visibleItemsInfo
        if (infos.isEmpty()) return@Canvas
        val base = infos[0]
        val stride = base.size.toFloat()
        val w = size.width
        val first = (base.index - 1).coerceAtLeast(0)
        val last = minOf(infos.last().index + 1, itemCount - 1, first + maxPoints)

        fun px(i: Int) = w * nodeXFrac(i)
        fun py(i: Int) = base.offset + (i - base.index) * stride + stride / 2f - shiftPx

        donePath.rewind(); lockPath.rewind(); holes.rewind()
        for (i in first until last) {
            val x0 = px(i - 1); val y0 = py(i - 1)
            val x1 = px(i);     val y1 = py(i)
            val x2 = px(i + 1); val y2 = py(i + 1)
            val x3 = px(i + 2); val y3 = py(i + 2)
            // i ≥ currentIndex  ⇔  cả 2 đầu đoạn đều ≤ level hiện tại  ⇒ đã đi qua.
            val p = if (i >= currentIndex) donePath else lockPath
            p.moveTo(x1, y1)
            p.cubicTo(x1 + (x2 - x0) / 6f, y1 + (y2 - y0) / 6f, x2 - (x3 - x1) / 6f, y2 - (y3 - y1) / 6f, x2, y2)
        }
        // Lỗ hổng đúng bằng thân nút: đường không xuyên qua nút khoá (nút mờ 50%).
        for (info in infos) {
            val cx = px(info.index)
            val cy = base.offset + (info.index - base.index) * stride + stride / 2f
            holes.addRoundRect(
                RoundRect(cx - nodeWpx * 0.48f, cy - nodeHpx * 0.46f, cx + nodeWpx * 0.48f, cy + nodeHpx * 0.46f, CornerRadius(nodeHpx * 0.3f))
            )
        }
        clipPath(holes, ClipOp.Difference) {
            translate(0f, dropPx) {                       // lớp dưới: bóng nâu đậm
                drawPath(lockPath, LockedShadow, style = shadowStroke)
                drawPath(donePath, TrailShadow, style = shadowStroke)
            }
            drawPath(lockPath, LockedTop, style = topStroke)   // lớp trên: mặt đường vàng nhạt
            drawPath(donePath, TrailTop, style = topStroke)
            translate(0f, -liftPx) { drawPath(donePath, TrailHighlight, style = hiStroke) }
        }
    }
}

// ─────────────────────────────────────────────────────────── Cảnh vật (cuộn cùng thế giới bằng GPU)

/**
 * Cảnh vật chia theo "khối" 16 level (đúng 2 chu kỳ zig-zag) ⇒ lặp vô hạn mà không cần ảnh nền dài.
 * Toạ độ của vật thể = % maxWidth (x) và % chiều cao khối (y) ⇒ co giãn theo mọi màn hình.
 * Chỉ dựng 3 khối quanh vị trí cuộn; mỗi khối được dịch bằng graphicsLayer.translationY lấy từ layoutInfo.
 */
@Composable
private fun SceneryLayer(art: MapArt, listState: LazyListState, itemCount: Int, screenW: Dp, itemH: Dp) {
    val blockH = itemH * SCENE_BLOCK
    val firstBlock by remember(listState) { derivedStateOf { listState.firstVisibleItemIndex / SCENE_BLOCK } }
    val lastBlock = ((itemCount - 1) / SCENE_BLOCK).coerceAtLeast(0)
    val from = (firstBlock - 1).coerceAtLeast(0)
    val to = (firstBlock + 1).coerceAtMost(lastBlock)
    for (k in from..to) {
        key(k) { SceneryBlock(art, listState, k, screenW, blockH) }
    }
}

@Composable
private fun SceneryBlock(art: MapArt, listState: LazyListState, k: Int, screenW: Dp, blockH: Dp) {
    Box(
        Modifier
            .requiredSize(screenW, blockH)
            .graphicsLayer {
                val base = listState.layoutInfo.visibleItemsInfo.firstOrNull()
                if (base == null) {
                    alpha = 0f
                } else {
                    alpha = 1f
                    translationY = base.offset + (k * SCENE_BLOCK - base.index) * base.size.toFloat()
                }
            }
    ) {
        // Cây lớn + ghế đá bên trái khi đường lắc sang phải
        Image(art.tree, null, Modifier.offset(x = screenW * -0.03f, y = blockH * 0.04f).width(screenW * 0.4f).aspectRatio(319f / 357f), contentScale = ContentScale.Fit)
        Image(art.bench, null, Modifier.offset(x = screenW * 0.02f, y = blockH * 0.27f).width(screenW * 0.2f).aspectRatio(156f / 118f), contentScale = ContentScale.Fit)
        Image(art.flowers, null, Modifier.offset(x = screenW * 0.86f, y = blockH * 0.06f).width(screenW * 0.12f).aspectRatio(164f / 116f), contentScale = ContentScale.Fit)
        // Ao sen bên phải khi đường lắc sang trái
        Image(art.pond, null, Modifier.offset(x = screenW * 0.56f, y = blockH * 0.31f).width(screenW * 0.46f).aspectRatio(456f / 334f), contentScale = ContentScale.Fit)
        Image(art.flowers2, null, Modifier.offset(x = screenW * -0.02f, y = blockH * 0.52f).width(screenW * 0.12f).aspectRatio(135f / 92f), contentScale = ContentScale.Fit)
        // Nhà gỗ bên trái ở chu kỳ sau
        Image(art.cabin, null, Modifier.offset(x = screenW * -0.02f, y = blockH * 0.59f).width(screenW * 0.42f).aspectRatio(337f / 316f), contentScale = ContentScale.Fit)
        // Thông + đá + bụi bên phải
        Image(art.pine, null, Modifier.offset(x = screenW * 0.8f, y = blockH * 0.79f).width(screenW * 0.17f).aspectRatio(169f / 242f), contentScale = ContentScale.Fit)
        Image(art.bush, null, Modifier.offset(x = screenW * 0.74f, y = blockH * 0.9f).width(screenW * 0.22f).aspectRatio(146f / 131f), contentScale = ContentScale.Fit)
        Image(art.rocks, null, Modifier.offset(x = screenW * 0.55f, y = blockH * 0.94f).width(screenW * 0.15f).aspectRatio(143f / 88f), contentScale = ContentScale.Fit)
    }
}

// ─────────────────────────────────────────────────────────── Nút gỗ

private val NumberStyle = TextStyle(
    fontSize = 26.sp,
    fontWeight = FontWeight.ExtraBold,
    color = Color.White,
    shadow = Shadow(Color(0xB33A1E08), Offset(0f, 4f), 6f),
)

@Composable
private fun rememberPulse(): State<Float> {
    val t = rememberInfiniteTransition(label = "pulse")
    return t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseValue",
    )
}

/**
 * Nút gỗ: Box xếp chồng [glow] + ảnh nut_go + Text số level (hoặc ổ khoá).
 *  • Nhấn: pointerInput(detectTapGestures) → Animatable scale 0.9 → đọc trong graphicsLayer.
 *    Không dùng state "pressed" ⇒ không recomposition; kích thước layout không đổi (chỉ scale ở tầng render).
 *  • Current: vòng sáng radialGradient nhịp thở + con tốt nhún (cả hai chỉ đổi alpha/scale/translation).
 *  • Locked: ảnh alpha 0.5 + icon ổ khoá, bỏ qua chạm.
 * [onClick] trả về tâm nút trong toạ độ root (PuzzleTransitionWrapper dùng để zoom).
 */
@Composable
fun WoodenNode(
    level: Int,
    state: NodeState,
    modifier: Modifier = Modifier,
    painter: Painter = painterResource(R.drawable.nut_go),
    pawn: Painter? = null,
    onClick: ((center: Offset) -> Unit)? = null,
    isHidden: () -> Boolean = { false },
) {
    val scope = rememberCoroutineScope()
    val press = remember { Animatable(1f) }
    val coords = remember { arrayOfNulls<LayoutCoordinates>(1) }
    val locked = state == NodeState.Locked
    val currentOnClick by rememberUpdatedState(onClick)

    Box(
        modifier = modifier
            .requiredSize(NodeW, NodeH)   // nút cao hơn khoảng cách item ⇒ tràn ra ngoài (xen kẽ isometric)
            .onGloballyPositioned { coords[0] = it }
            .graphicsLayer {
                val s = press.value
                scaleX = s
                scaleY = s
                alpha = if (isHidden()) 0f else 1f
            }
            .pointerInput(locked) {
                detectTapGestures(
                    onPress = {
                        scope.launch { press.animateTo(0.9f, spring(dampingRatio = 0.55f, stiffness = 800f)) }
                        tryAwaitRelease()
                        scope.launch { press.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 800f)) }
                    },
                    onTap = {
                        if (!locked) {
                            val c = coords[0]?.takeIf { it.isAttached }?.boundsInRoot()?.center ?: Offset.Zero
                            currentOnClick?.invoke(c)
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        if (state == NodeState.Current) {
            val pulse = rememberPulse()
            Box(
                Modifier
                    .requiredSize(NodeW * 1.9f, NodeH * 1.9f)
                    .graphicsLayer {
                        val p = pulse.value
                        alpha = 0.6f + 0.4f * p
                        scaleX = 1f + 0.08f * p
                        scaleY = 1f + 0.08f * p
                    }
                    .background(
                        Brush.radialGradient(listOf(Color(0xCCFFE55C), Color(0x88A8E64A), Color(0x00A8E64A)))
                    )
            )
        }

        Image(
            painter = painter,
            contentDescription = "Câu đố $level",
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer { alpha = if (locked) 0.5f else 1f },
            contentScale = ContentScale.Fit,
        )

        if (locked) {
            Icon(Icons.Filled.Lock, "Khoá", tint = Color.White, modifier = Modifier.size(24.dp).offset(y = -(NodeH * 0.08f)))
        } else {
            Text(level.toString(), style = NumberStyle, modifier = Modifier.offset(y = -(NodeH * 0.08f)))
        }

        if (state == NodeState.Current && pawn != null) {
            val pulse = rememberPulse()
            Image(
                painter = pawn,
                contentDescription = null,
                modifier = Modifier
                    .offset(x = -(NodeW * 0.26f), y = -(NodeH * 0.5f))
                    .width(28.dp)
                    .aspectRatio(60f / 82f)
                    .graphicsLayer { translationY = -5.dp.toPx() * pulse.value },
            )
        }
    }
}

// ─────────────────────────────────────────────────────────── HUD trên

@Composable
private fun TopArea(level: Int, coach: Painter, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xE60E2616), Color(0x000E2616))))
            .padding(bottom = 24.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().height(52.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Icon(Icons.Filled.Extension, null, tint = Color(0xFFD9A55B), modifier = Modifier.size(38.dp))
                Box(
                    Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF6B3F1D)),
                    contentAlignment = Alignment.Center,
                ) { Text(level.toString(), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold) }
            }
            Spacer(Modifier.width(10.dp))
            Text("Câu đố", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(coach, contentDescription = "Huấn luyện viên", modifier = Modifier.height(68.dp).aspectRatio(349f / 290f), contentScale = ContentScale.Fit)
            SpeechBubble("Đã đến lúc phải giải quyết!", Modifier.weight(1f))
        }
    }
}

/** Bong bóng chat: Canvas vẽ hình chữ nhật bo góc + mũi nhọn bên trái chỉ vào HLV; Text nằm chồng lên. */
@Composable
private fun SpeechBubble(text: String, modifier: Modifier = Modifier) {
    val path = remember { Path() }
    Box(modifier, contentAlignment = Alignment.CenterStart) {
        Canvas(Modifier.matchParentSize()) {
            val tail = 12.dp.toPx()
            val r = 18.dp.toPx()
            path.rewind()
            path.addRoundRect(RoundRect(tail, 0f, size.width, size.height, CornerRadius(r)))
            path.moveTo(tail + 2f, size.height * 0.30f)
            path.lineTo(0f, size.height * 0.50f)
            path.lineTo(tail + 2f, size.height * 0.70f)
            path.close()
            translate(0f, 3.dp.toPx()) { drawPath(path, Color(0x40000000)) }
            drawPath(path, Color.White)
        }
        Text(
            text,
            color = Color(0xFF222222),
            fontSize = 17.sp,
            modifier = Modifier.padding(start = 28.dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
        )
    }
}

// ─────────────────────────────────────────────────────────── HUD dưới

@Composable
private fun BottomPanel(
    score: Int,
    streak: Int,
    progress: Float,
    onSolveClick: () -> Unit,
    bottomPad: Dp,
    modifier: Modifier = Modifier,
) {
    val anim = animateFloatAsState(progress.coerceIn(0.04f, 1f), tween(600), label = "progress")
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = bottomPad)
            .background(Brush.verticalGradient(listOf(Color(0x00102A18), Color(0xF0182E1E)), 0f, 120f))
            .padding(start = 16.dp, end = 16.dp, top = 28.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(score.toString(), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(10.dp))
            Icon(Icons.Filled.LocalFireDepartment, null, tint = Color(0xFFFF8A1F), modifier = Modifier.size(26.dp))
            Text(streak.toString(), color = Color(0xFFFF8A1F), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        // ProgressBar: giá trị animate chỉ được đọc trong drawBehind ⇒ chạy mượt, không recomposition.
        Box(
            Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(RoundedCornerShape(7.dp))
                .background(Color(0x33FFFFFF))
                .drawBehind {
                    val w = size.width * anim.value
                    drawRoundRect(
                        Brush.horizontalGradient(listOf(Color(0xFFFFA43A), Color(0xFFFF6A00)), 0f, w),
                        size = Size(w, size.height),
                        cornerRadius = CornerRadius(size.height / 2f),
                    )
                    drawRoundRect(
                        Color(0x66FFFFFF),
                        topLeft = Offset(5.dp.toPx(), 2.dp.toPx()),
                        size = Size((w - 10.dp.toPx()).coerceAtLeast(0f), 3.dp.toPx()),
                        cornerRadius = CornerRadius(1.5.dp.toPx()),
                    )
                }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.FormatListBulleted, "Danh sách", tint = Color.White) }
            GameButton("Giải các câu đố", onSolveClick, Modifier.weight(1f))
        }
    }
}

/** Nút xanh lá 3D: lớp đáy tối + lớp mặt gradient; khi nhấn mặt trượt xuống bằng graphicsLayer. */
@Composable
private fun GameButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val dy = animateFloatAsState(if (pressed) 4f else 0f, label = "btnPress")
    val shape = RoundedCornerShape(18.dp)
    Box(modifier.height(62.dp)) {
        Box(Modifier.fillMaxWidth().height(56.dp).align(Alignment.BottomCenter).background(Color(0xFF4A7A1E), shape))
        Box(
            Modifier
                .fillMaxWidth()
                .height(56.dp)
                .align(Alignment.TopCenter)
                .graphicsLayer { translationY = dy.value * density }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFFA5D955), Color(0xFF79B22E))))
                .clickable(interactionSource = interaction, indication = ripple(color = Color.White), onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(text, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
